# CHECKPOINT NOTES KELIMAA — Audit Menyeluruh (Serah Terima)

Tanggal checkpoint: 14 Nov 2026
Baseline: `catatan-app.zip` (Rev 293, v0.3.121, SCHEMA 21) + dua workflow (`build-apk-dari-zip.yml` = debug, `build-release.yml` = rilis).
Status: **TAHAP BACA AWAL SELESAI. PART 1 BELUM DIMULAI. TIDAK ADA KODE YANG DIUBAH.**

---

## 0. CARA MELANJUTKAN (untuk AI berikutnya)

1. Minta pengguna mengirim ulang: `catatan-app.zip`, `build-apk-dari-zip.yml`, `build-release.yml`, dan berkas ini.
2. Baca berkas ini lebih dulu, lalu `PROMPT_SERAH_TERIMA.md` dan `RIWAYAT.md` dari dalam ZIP (entri terbaru ada di bagian atas) sebelum menyentuh apa pun.
3. Lanjutkan dari **PART 1**. Jangan mengulang bagian "Temuan awal" kecuali untuk cross-check.
4. Jangan ubah kode sebelum PART 1–9 selesai dan pengguna menyetujui rencana optimasi.

---

## 1. ATURAN DARI PENGGUNA (ringkasan, wajib dipatuhi)

- ZIP = satu-satunya baseline. Jangan mengarang file, fungsi, atau fitur yang tidak ada di kode.
- Jangan ubah kode sebelum seluruh audit selesai dan rencana disetujui.
- Jangan hapus kode hanya karena tampak tidak terpakai; cek dulu ketergantungan tidak langsung.
- Jangan ubah UI/UX tanpa alasan teknis kuat. Jangan hilangkan fitur. Jangan ganti teknologi utama. Jangan refactor besar tanpa manfaat jelas.
- Pertahankan kompatibilitas Android + Capacitor dan data pengguna lama.
- Jangan upgrade dependency secara massal; utamakan stabilitas.
- Jangan ganti sistem penyimpanan sepihak. Bila menyarankan IndexedDB atau lainnya, jelaskan dulu keuntungan, kekurangan, risiko, kompatibilitas.
- Setiap rekomendasi harus punya alasan teknis dan dampak yang bisa dijelaskan.
- Bagian yang belum pasti ditandai **BELUM TERVERIFIKASI**.
- Jangan klaim sesuatu "sudah diuji" bila belum dijalankan. Bedakan: diperiksa statis / lolos automated test / berhasil build / diuji di perangkat Android.
- Prioritas: stabilitas, kecepatan buka, responsivitas, RAM, CPU, penyimpanan, kemudahan pemeliharaan. Targetnya terasa ringan, bukan sekadar kecil.
- Akurasi dan keamanan data lebih penting daripada kecepatan kerja.

### Urutan audit (tiap PART wajib menutup dengan checkpoint)
1. PART 1 Struktur & inventaris berkas
2. PART 2 JavaScript & logika aplikasi
3. PART 3 HTML & CSS (performa)
4. PART 4 Storage, data, database
5. PART 5 Android & Capacitor
6. PART 6 Dependency, build, workflow
7. PART 7 Keamanan, keandalan, integritas data
8. PART 8 Audit silang antar berkas
9. PART 9 Rencana optimasi akhir (tabel: No | Lokasi | Temuan | Dampak | Prioritas | Rekomendasi; kelompok CRITICAL / HIGH / MEDIUM / LOW / CLEANUP)

Hasil akhir yang diminta nanti (setelah optimasi disetujui): ZIP hasil optimasi, daftar berkas dihapus/diubah/baru, penjelasan teknis, perbandingan sebelum-sesudah, hasil uji, catatan kompatibilitas, risiko tersisa, rekomendasi pemeliharaan. Struktur ZIP harus lengkap dan bisa dipakai build APK (jangan hilangkan `www`/`src`/`android`/konfigurasi/workflow tanpa memastikan fungsinya).

---

## 2. CHECKPOINT (format yang diminta pengguna)

**CHECKPOINT NOTES KELIMAA**

- **PART yang selesai:** belum ada. Hanya pembacaan awal ZIP dan dua workflow.
- **File yang sudah diperiksa:** daftar berkas + ukuran seluruh ZIP; `package.json`; `capacitor.config.json`; `src/index.html`; `scripts/build.mjs`; awal `scripts/apply-native.mjs`; awal `.github/workflows/ukur-performa.yml`; awal `README.md` dan `PROMPT_SERAH_TERIMA.md`; kedua workflow build (dibaca penuh).
- **File yang belum diperiksa:** isi seluruh `src/js/**` (87 modul), `src/css/styles.css`, `tests/**` (281 berkas), `tools/**` (17 berkas), `backend/cloudflare/**`, `resources/**`, sisa `apply-native.mjs`, `apply-icons.mjs`, `minify.mjs`, `preload.mjs`, `RIWAYAT.md`, `UJI_HP_RILIS.md`, sisa `PROMPT_SERAH_TERIMA.md`.
- **Temuan penting:** lihat bagian 3 dan 4.
- **Masalah yang ditemukan:** lihat bagian 4 (semua masih sebatas dugaan awal, bukan hasil audit mendalam).
- **Kandidat optimasi:** lihat bagian 5.
- **Risiko:** lihat bagian 6.
- **Keputusan yang dibutuhkan:** lihat bagian 7.
- **PART berikutnya:** PART 1.

---

## 3. INVENTARIS AWAL (terverifikasi dari isi ZIP)

Total 443 berkas, 5,8 MB.

| Lokasi | Isi |
|---|---|
| `src/index.html` | 376 byte; hanya `<div id="app">` + `js/main.js` (module) |
| `src/css/styles.css` | 1 berkas, 231 KB |
| `src/js/` | 74 modul + `ai/` 13 modul; total ±16.200 baris |
| `src/img/` | 6 WebP judul (35–51 KB), `logo-keluar.png` 12,7 KB |
| `tests/` | 281 berkas `*.test.mjs` |
| `scripts/` | `build.mjs`, `minify.mjs`, `preload.mjs`, `apply-native.mjs` (34 KB), `apply-icons.mjs` |
| `tools/` | 17 skrip audit/ukur (Python + Node) |
| `backend/cloudflare/` | `worker.mjs` 38 KB, `PANDUAN_WORKER.md` |
| `resources/android/res/` | ikon launcher (mipmap) + ikon notifikasi `ic_stat_kelimaa` |
| `assets/logo-512.png` | 9 KB |
| `.github/workflows/` | hanya `ukur-performa.yml` |
| Dokumen | `RIWAYAT.md` 802 KB, `PROMPT_SERAH_TERIMA.md` 658 KB, `UJI_HP_RILIS.md` 39 KB, `README.md` 11 KB |
| Konfigurasi | `package.json`, `capacitor.config.json`, `.gitignore` (mengabaikan `node_modules/`, `www/`, `android/`, `.env`, keystore) |

**Berkas JS terbesar:** `notes.js` 193 KB, `lembar-ui.js` 151 KB, `rumus.js` 57 KB, `settings.js` 55 KB, `main.js` 40 KB, `export.js` 39 KB, `logic.js` 36 KB, `share.js` 31 KB.

**Dependency:** `@capacitor/android`, `core`, `filesystem`, `share` (semua `^8.0.0`); dev: `@capacitor/cli ^8.0.0`.

**Konfigurasi Capacitor:** appId `com.kelimaa.notes`, webDir `www`, `allowMixedContent: false`, plugin `SystemBars.insetsHandling = disable`.

**Build web:** `scripts/build.mjs` menyalin `src/` ke `www/` (tanpa bundler), menyisipkan `modulepreload` ke `www/index.html`, dan memperkecil CSS di `www/` saja. Kegagalan preload/minify diabaikan (salinan polos tetap dipakai).

**Yang TIDAK ada di ZIP:** folder `android/` (dibuat saat build lewat `npx cap add android`, lalu `apply-native.mjs` menyuntikkan `MainActivity.java`, izin INTERNET, filter Bagikan teks), `package-lock.json`, folder `www/`, `node_modules/`.

Dari README/handover (klaim dokumen, BELUM TERVERIFIKASI oleh audit): `npm test` exit 0 dengan 1885 butir ok; anggaran JS 1211,1 KB dari 1230 KB; label rilis KANDIDAT RILIS (belum FINAL); fitur Kelimaa AI lewat Worker Cloudflare milik pengguna (kunci penyedia tidak ada di APK); uji HP terakhir untuk Rev 246–293 berstatus BERFUNGSI-BELUM-DIUJI.

---

## 4. TEMUAN AWAL

### 4.1 Struktur proyek
1. Folder `android/` tidak ada di ZIP, jadi `AndroidManifest.xml`, Gradle, dan MainActivity hasil generate hanya bisa diperiksa lewat generatornya. **BELUM TERVERIFIKASI** untuk berkas jadi.
2. Tidak ada lockfile; versi Capacitor memakai `^8.0.0`.
3. Dokumen `RIWAYAT.md` + `PROMPT_SERAH_TERIMA.md` sekitar 1,4 MB, jauh lebih besar dari kode. Tidak masuk APK (build hanya menyalin `src/`), jadi ini soal pemeliharaan.
4. `tests/rev249b.test.mjs` tidak tercantum di skrip `npm test`. Semua berkas lain yang tercantum di `npm test` ada.
5. Skrip `npm test` berupa satu baris `&&` yang sangat panjang dan disusun manual.
6. Scan impor statis awal: tidak ada modul JS yatim selain `main.js` (entry point). Ini belum menghitung muat malas atau impor dinamis lewat string; harus diverifikasi di PART 8.
7. Kandidat tumpang tindih yang perlu dicek: `templat-lama.js` / `templat-admin.js` / `templat-admin-lanjut.js` / `templat-rumus.js` / `templat-rumus-lanjut.js` / `templat-fitur.js`; `cadangan-gambar.js` vs `ai/cadangan.js` vs `backup.js`; `lembar-*` (±25 modul).
8. Tes bernama per revisi (`rev46`…`rev293`) berfungsi sebagai jaring pengaman. **Jangan dihapus tanpa analisis.** Beberapa tes mengunci urutan/jumlah (misal `slice(0, 4)`), jadi perubahan struktur akan memengaruhinya.

### 4.2 Workflow (dibaca penuh)

| | Debug `build-apk-dari-zip` | Rilis `build-release` |
|---|---|---|
| Pemicu | `workflow_dispatch` | `workflow_dispatch` |
| `npm test` | Ya | **Tidak** |
| Instal dependensi | `npm install` | `npm install --no-audit --no-fund` |
| Retry Gradle + timeout wrapper 120 dtk | Ya (4 percobaan) | Tidak |
| Cek kelengkapan ikon notifikasi | Ya | Tidak |
| Cache Gradle | `gradle/actions/setup-gradle@v6` | Tidak |
| Tanda tangan | Menambah blok `signingConfigs.tetap` ke `build.gradle` untuk buildType debug; alias tetap `notes-kelimaa`, password kunci = password keystore; jika secret kosong, jatuh ke kunci debug sementara | `zipalign -p 4` + `apksigner sign` dengan secret `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` |
| versionCode/versionName | Tidak diatur | `versionCode = github.run_number`, `versionName` dari `package.json` (lewat `sed`) |
| Versi actions | checkout v6, setup-node v6, setup-java v5, upload-artifact v7 | checkout v4, setup-node v4, setup-java v4, upload-artifact v4 |
| Timeout job | tidak diset | 40 menit |
| Dekode keystore | `tr -d ' \r\n' \| base64 -d` (toleran spasi/baris baru) | `echo \| base64 -d` (tanpa pembersihan) |
| Keluaran | `app-debug.apk` (artifact `app-debug`) | `NotesKelimaa-rilis.apk` (artifact `NotesKelimaa-rilis`) |

Dugaan masalah dari workflow (semua perlu diverifikasi di PART 5–7):
1. **Rilis tidak menjalankan tes.** Padahal rilis dimaksudkan untuk dipakai setelah audit selesai.
2. **versionCode tidak sinkron.** Debug tidak mengatur versionCode (kemungkinan tetap bawaan template, biasanya 1), rilis memakai nomor run. Setelah APK rilis dipasang, APK debug dengan versionCode lebih kecil bisa ditolak Android sebagai downgrade, sehingga harus uninstall dulu (data lokal hilang). **BELUM TERVERIFIKASI** (bergantung isi `build.gradle` hasil generate).
3. **Konsistensi alias/password.** Pengguna mengonfirmasi keystore dan password dipakai bersama debug dan rilis. Maka `KEY_ALIAS` harus bernilai `notes-kelimaa` dan `KEY_PASSWORD` harus sama dengan `KEYSTORE_PASSWORD`, kalau tidak salah satu workflow gagal atau memakai kunci berbeda. Perlu dikonfirmasi pengguna.
4. Jika keystore sama, APK debug dan rilis bertanda tangan sama dan applicationId sama, sehingga bisa saling menimpa dengan syarat versionCode naik (lihat poin 2). Tidak ada `applicationIdSuffix` yang terlihat di workflow; **BELUM TERVERIFIKASI**.
5. Minify/R8 pada rilis diatur di `build.gradle` hasil generate: **BELUM TERVERIFIKASI** apakah aktif. Jangan klaim rilis lebih ringan sebelum diperiksa.
6. APK yang dipakai sehari-hari adalah debug. Pengaruh build debug terhadap rasa lambat (WebView debuggable, optimasi native) **BELUM TERVERIFIKASI**; periksa di PART 5.
7. Versi actions berbeda antar workflow (v4 vs v5–v7). Berpotensi tidak konsisten; belum dicek apakah semuanya versi yang tersedia.
8. `ukur-performa.yml` adalah satu-satunya workflow di ZIP. Dua workflow build berada di luar ZIP dan harus dikirim terpisah setiap kali dibahas.
9. Kedua workflow bergantung pada `catatan-app.zip` di akar repo.

---

## 5. KANDIDAT OPTIMASI (belum disetujui, jangan diterapkan)

- Tambahkan lockfile dan pakai `npm ci` agar build deterministik (tidak mengubah fungsi aplikasi).
- Sinkronkan versionCode antara debug dan rilis, serta jalankan `npm test` di workflow rilis.
- Seragamkan versi actions dan penanganan keystore antar dua workflow.
- Pecah/atur `notes.js` (193 KB) dan `lembar-ui.js` (151 KB) hanya bila audit menemukan manfaat nyata (PART 2). Anggaran JS sudah mepet (1211 dari 1230 KB menurut dokumen).
- Rapikan skrip `npm test` dan masukkan `rev249b` bila memang tes yang sah.
- Pindahkan atau arsipkan dokumen besar (`RIWAYAT.md`, `PROMPT_SERAH_TERIMA.md`) ke luar jalur kerja AI agar konteks lebih ringan; ini tidak memengaruhi APK.
- Evaluasi tumpang tindih modul templat dan cadangan (PART 1 dan 8).

---

## 6. RISIKO

- Menghapus berkas "yatim" bisa merusak tes yang mengunci keberadaannya atau impor dinamis.
- Mengubah jumlah/urutan templat memengaruhi banyak tes (`rev181`–`rev186`, `rev286`–`rev293`).
- Perubahan versionCode memengaruhi cara pemasangan APK di HP pengguna (downgrade ditolak). Perlu skenario migrasi jelas sebelum diterapkan.
- Perubahan workflow tidak bisa diuji di sini (tidak ada jaringan, tidak ada runner GitHub).
- Perubahan penyimpanan menyentuh data pengguna lama (SCHEMA 21). Jangan diubah tanpa jalur migrasi.

---

## 7. KEPUTUSAN

**Sudah diputuskan pengguna:**
- Workflow debug (`build-apk-dari-zip`) dipakai sehari-hari; workflow rilis (`build-release`) dipakai setelah perbaikan paten dan audit selesai.
- Keystore (`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`) dipakai bersama debug dan rilis, dan keystore sudah dibuat.

**Masih menunggu pengguna:**
1. Apakah secret `KEY_ALIAS` bernilai `notes-kelimaa` dan `KEY_PASSWORD` sama dengan `KEYSTORE_PASSWORD`? (lihat 4.2 poin 3)
2. Apakah repo punya `package-lock.json`? Jika ada, kirim.
3. Bisakah pengguna mengirim `AndroidManifest.xml`, `android/app/build.gradle`, dan `MainActivity.java` hasil build terakhir (misalnya dari artifact atau log)? Tanpa itu PART 5 terbatas pada generator.
4. Apakah pengguna sudah pernah memasang APK rilis di HP yang sama dengan APK debug? (terkait risiko versionCode)

---

## 8. PART BERIKUTNYA: PART 1 — langkah yang direncanakan

1. Peta folder lengkap dan inventaris tiap berkas (ukuran, peran, pengimpor).
2. Graf impor statis dan dinamis dari `js/main.js` (muat malas, `import()`), menentukan modul yang benar-benar terpakai.
3. Cari duplikat/serupa (templat, cadangan, `lembar-*`, `tools/audit_*`).
4. Daftar kandidat hapus vs daftar **jangan dihapus** (dengan alasan ketergantungan: tes, build script, workflow).
5. Cek ketergantungan `tools/` terhadap `ukur-performa.yml`.
6. Tutup dengan checkpoint PART 1.

---

# PEMBARUAN: PART 1 SELESAI (14 Nov 2026)

## Metode (diperiksa statis, bukan dijalankan di HP)
Skrip Node memindai seluruh `src/js/**` (87 modul): impor statis (`import ... from`, `export ... from`) dan dinamis (`import('...')`), lalu menghitung keterjangkauan dari `js/main.js`. Hash md5 untuk duplikat, `grep` lintas `src`, `scripts`, `tests`, `tools`, `.github`, `package.json` untuk ketergantungan.

## Hasil terverifikasi
1. **Semua 87 modul JS terjangkau dari `main.js`.** Tidak ada modul yatim. Tidak ada impor dinamis berargumen non-literal.
2. **53 modul (722,6 KB) dimuat statis saat startup; 34 modul (486,1 KB) dimuat malas.** Total 1208,7 KB (sesuai klaim README ±1211 KB).
   - Dimuat malas: seluruh `ai/*` (kecuali yang dipanggil dari `settings.js`/`notes.js`), `lembar-ui.js` (147 KB), `rumus.js` (56 KB), `lembar-alat.js`, `templat-*.js`, `proyek-ui.js`, dan sebagian besar `lembar-*`.
   - Pemuat malas yang tercatat: `settings.js` -> `ai/layar.js`, `proyek-ui.js`; `notes.js` -> `ai/tulisui.js`; `lembar-pintu.js` -> `lembar-ui.js`, `lembar-templat.js`; `lembar-mesin.js` -> `rumus.js`. Sisa modul malas dicapai lewat rantai impor di dalam modul malas itu sendiri.
3. **Modul paling banyak diimpor:** `ui.js` (15), `native.js` (14), `logic.js` (11), `lembar.js` (8). Jangan diubah antarmukanya tanpa audit silang.
4. **Duplikat isi (md5):** hanya `ic_launcher.xml` = `ic_launcher_round.xml` (wajar untuk ikon adaptif; JANGAN dihapus). Tidak ada duplikat di `tests/`.
5. **Aset gambar semua terpakai:** 6 WebP judul dipetakan di `ui.js` (`JUDUL`, jalur `img/judul/${berkas}.webp`; sekilas tampak tidak terpakai karena nama dirangkai lewat template string); `logo-keluar.png` dipakai `exit.js` dan `settings.js`.
6. **`assets/logo-512.png`** tidak dipakai saat runtime; ia keluaran `tools/buat_ikon.py` dan dikunci `tests/rev95`. SIMPAN.
7. **Tidak ada `@font-face`**; font memakai `var(--sans)` dan font sistem. Tidak ada aset font di ZIP.
8. **Tes:** setiap modul `src/js/**` dirujuk oleh minimal satu tes; semua jalur `src/js/...` yang disebut tes ada. `rev249b.test.mjs` adalah satu-satunya tes yang tidak masuk `npm test` (menguji `worker.mjs` + `ai/riset.js`; bukan tes yatim, cuma belum didaftarkan).
9. **`scripts/` semuanya dipakai:** `build`, `minify`, `preload` (dari `build.mjs`), `apply-icons` (di-`import` oleh workflow dan memanggil `apply-native`). `resources/android/res` hanya dipakai `apply-icons.mjs`.
10. **`tools/`:** dipakai workflow `ukur-performa.yml`: `audit-ukuran.mjs`, `buat_data.mjs`, `ukur_node.mjs`, `ukur_performa.py`. Dikunci tes: `audit_interaksi`, `audit_kriteria`, `audit_riwayat`, `audit_sumber_editor`, `audit_sumber_warna`, `ukur_gulir`. Dirujuk skrip lain: `audit_tolak.py` (oleh `audit_kriteria.py`).

## Kandidat hapus (HANYA kandidat; tidak dihapus, tidak disetujui)
| Berkas | Alasan | Risiko jika dihapus |
|---|---|---|
| `tools/audit_lainnya.py`, `audit_sumber.py`, `audit_validasi.py`, `audit_warna.py`, `ukur_startup.py` | Tidak dirujuk workflow, tes, atau skrip mana pun; alat manual berbasis Playwright (Rev 262-281). | Rendah (bukan bagian APK); hilangnya alat audit manual. Putuskan di PART 9. |
| `PROMPT_SERAH_TERIMA.md` (658 KB), `RIWAYAT.md` (802 KB) | Terlalu besar untuk dibaca AI per sesi; bukan bagian APK. | **Jangan dihapus.** Opsi: arsipkan entri lama + ringkasan, bukan hapus. |
| `UJI_HP_RILIS.md` (39 KB) | Daftar uji HP; masih dipakai pengguna. | JANGAN hapus. |

## Berkas yang TIDAK BOLEH dihapus
`src/**` (semua modul terjangkau), `scripts/**`, `resources/android/**` (termasuk ic_launcher_round.xml), `capacitor.config.json`, `package.json`, `.gitignore`, `backend/cloudflare/**` (dirujuk >10 tes dan fitur AI), `tests/**` (jaring pengaman), `tools/audit-ukuran.mjs`, `tools/buat_data.mjs`, `tools/ukur_node.mjs`, `tools/ukur_performa.py`, `tools/buat_ikon.py`, `assets/logo-512.png`, `.github/workflows/ukur-performa.yml`.

## Temuan baru PART 1 (belum diaudit mendalam)
1. Startup memuat 53 modul / 722,6 KB secara statis (di-`modulepreload` oleh build). Isi terbesar di jalur startup (`notes.js` 193 KB, `settings.js` 55 KB, `main.js` 40 KB, `export.js`, `logic.js`, `share.js`) adalah kandidat utama PART 2. Apakah semuanya benar-benar dibutuhkan sebelum layar pertama tampil: BELUM TERVERIFIKASI.
2. Pemisahan malas sudah ada (486 KB tidak di jalur startup), jadi potensi hemat terbesar bukan "menghapus kode" tetapi memindahkan beban dari jalur startup, bila terbukti.
3. `styles.css` 231 KB dalam satu berkas, tidak dipecah; seluruhnya dimuat saat startup (`<link>` di `index.html`). Selector yang tidak terpakai: BELUM DIAUDIT (PART 3).
4. `package.json` menyebut versi 0.3.121 tetapi README menyebut Rev 293; ini penomoran dua lapis (versi vs rev), bukan konflik.

## CHECKPOINT NOTES KELIMAA (PART 1)
- **PART yang selesai:** PART 1 (inventaris + graf ketergantungan, statis).
- **File diperiksa:** seluruh struktur 443 berkas; graf impor 87 modul; hash duplikat; rujukan aset, script, tool, tes.
- **File belum diperiksa isinya:** semua logika `src/js/**`, `styles.css`, `worker.mjs`, sisa `apply-native.mjs`, `minify.mjs`, `preload.mjs`, sebagian besar `tests/**` dan `tools/**`, `RIWAYAT.md`, sisa `PROMPT_SERAH_TERIMA.md`, `UJI_HP_RILIS.md`.
- **Berkas dari pengguna masih dibutuhkan:** `package-lock.json`, `AndroidManifest.xml`, `android/app/build.gradle`, `MainActivity.java` hasil generate. Pengguna pemula; dibantu dengan workflow bantu `ambil-berkas-android.yml` (workflow baru, tidak mengubah workflow lama; opsional).
- **Keputusan dibutuhkan:** (a) apakah workflow bantu dijalankan; (b) `KEY_ALIAS` = `notes-kelimaa` dan `KEY_PASSWORD` = `KEYSTORE_PASSWORD`?; (c) lanjut PART 2 sekarang atau tunggu berkas Android.
- **PART berikutnya:** PART 2 (JS + logika), dimulai dari jalur startup: `main.js`, `startup.js`, `ui.js`, `native.js`, `storage.js`, `logic.js`, lalu modul besar `notes.js`.

---

# PEMBARUAN 2: BERKAS ANDROID HASIL GENERATE DITERIMA (14 Nov 2026)

Sumber: artifact `berkas-android-audit.zip` dari workflow bantu `ambil-berkas-android.yml` (langkah: npm install, npm run build, cap add android, apply-icons + apply-native, cap sync). Isi: `package-lock.json`, `android/build.gradle`, `variables.gradle`, `settings.gradle`, `gradle.properties`, `gradle-wrapper.properties`, `app/build.gradle`, `app/capacitor.build.gradle`, `proguard-rules.pro`, `AndroidManifest.xml`, `styles.xml`, `strings.xml`, `MainActivity.java`, `ReminderScheduler.java`, `ReminderReceiver.java`, `ReminderBootReceiver.java`, `versi-capacitor.txt`.
**Belum ada di artifact:** `res/xml/file_paths.xml`, `res/values/colors.xml`, `res/drawable/splash*`, `assets/capacitor.config.json`. Statusnya BELUM TERVERIFIKASI.

## Versi terpasang (terverifikasi dari lockfile)
`@capacitor/android` 8.6.2, `core` 8.6.2, `cli` 8.6.2 (butuh Node >= 22), `filesystem` 8.1.5, `share` 8.0.3; transitif produksi `@capacitor/synapse` 1.0.4 dan `tslib` 2.9.1. `package-lock.json`: lockfileVersion 3, 102 paket (95 dev dari cli), tanpa paket bertanda deprecated. **Berkas ini cocok dengan build yang berjalan baik; kandidat untuk disimpan ke repo/ZIP dan dipakai dengan `npm ci` (keputusan di PART 9).**
Android: minSdk 24, compileSdk 36, targetSdk 36, AGP 8.13.0, Gradle 8.14.3 (`-all`), Java 21, `-Xmx1536m`.

## Temuan terverifikasi (dibaca langsung dari berkas)
1. **`app/build.gradle`: `versionCode 1`, `versionName "1.0"`.** Pola `sed` workflow rilis cocok dengan teks ini, jadi pengaturan versi rilis bekerja. Build debug tetap versionCode 1 dan versionName "1.0" (tidak sama dengan `package.json` 0.3.121). Risiko downgrade debug setelah rilis terpasang: TERKONFIRMASI secara logika, belum dicoba di HP.
2. **`gradle-wrapper.properties`: `networkTimeout=10000`.** Workflow debug menaikkannya ke 120000; workflow rilis TIDAK. Risiko unduhan Gradle gagal hanya di rilis (hanya CI).
3. **Rilis: `minifyEnabled false`, tanpa `shrinkResources`.** R8 tidak aktif. Kode Java aplikasi kecil (±25 KB), jadi R8 bukan sumber percepatan; jangan menjanjikan rilis lebih cepat karena minify. Selisih nyata debug vs rilis (flag `debuggable`, debugging WebView) BELUM TERVERIFIKASI dan perlu diukur di HP.
4. **Manifest:** izin `POST_NOTIFICATIONS`, `RECEIVE_BOOT_COMPLETED`, `SCHEDULE_EXACT_ALARM`, `INTERNET`. `allowBackup=false`. Receiver tidak diekspor. Activity utama `singleTask`, `adjustResize`, `configChanges` lengkap (rotasi tidak membuat ulang Activity), filter `SEND text/plain` (fitur Bagikan). Tidak ada izin baca/tulis penyimpanan.
5. **`allowBackup=false` adalah keputusan sengaja** (privasi). Konsekuensi keandalan: data tidak ikut cadangan otomatis Google; ketergantungan pada fitur Cadangan buatan aplikasi sendiri (PART 4/7).
6. **Plugin native:** hanya `filesystem` dan `share` terdaftar (`capacitor.build.gradle`). Pemakaian di JS lewat `Capacitor.registerPlugin` dengan jalur cadangan di `native.js`. Apakah keduanya benar-benar dipakai: BELUM TERVERIFIKASI (periksa di PART 5/8).
7. **Launch/splash:** `styles.xml` masih tema bawaan Capacitor (`Theme.SplashScreen` + `@drawable/splash`). Penambal latar navy (`patchLaunchStyles`) sengaja DIMATIKAN sejak Rev 10e karena dicurigai membuat aplikasi tutup sendiri. Kilat terang saat buka: BELUM TERVERIFIKASI; jangan diaktifkan lagi tanpa uji HP.
8. **`MainActivity.java` (17 KB, hasil generate dari `apply-native.mjs`)** memuat jembatan `KelimaaNative`/`AndroidAPI` (exit, setBars, setBarEdges, takeShared, jadwal/batal notifikasi, canScheduleExactAlarms, openExactAlarmSettings, requestNotificationPermission, takeReminder, openUrl hanya http/https), tombol Kembali yang bertanya ke JS dulu (dengan jalan keluar jika JS macet), dan perhitungan inset di tingkat jendela (status bar + navigasi + takik + IME).
9. **Pengingat native:** `ReminderScheduler` menyimpan jadwal di SharedPreferences (JSON), memakai alarm tepat (`setExactAndAllowWhileIdle`) jika diizinkan, jika tidak jatuh ke alarm tidak tepat dan memberi tahu JS (`inexact_alarm`). Dijadwalkan ulang saat boot dan saat aplikasi diperbarui.

## Dugaan masalah (perlu diverifikasi, bukan sudah terbukti)
| # | Lokasi | Dugaan | Jenis | Prioritas awal |
|---|---|---|---|---|
| A1 | `MainActivity.closeAppTotal` | Proses dimatikan 1,2 detik setelah keluar; bila ada tulis penyimpanan WebView yang belum di-flush, data bisa hilang. Perlu dicek bagaimana `storage.js` menyimpan. | Keandalan/data | MEDIUM (naik jika terbukti) |
| A2 | `MainActivity.onCreate` + manifest | Dua mekanisme untuk keyboard: `adjustResize` di manifest dan padding IME manual di `android.R.id.content`. Berpotensi tumpang tindih dengan penanganan visualViewport di JS/CSS. | Performa/layout | MEDIUM (BELUM TERVERIFIKASI) |
| A3 | `MainActivity` (`addJavascriptInterface`) | Jembatan bisa dipanggil dari frame mana pun di WebView. Aman bila hanya memuat konten lokal; perlu dicek apakah ada iframe/navigasi ke situs luar (pratinjau tautan). | Keamanan | MEDIUM (BELUM TERVERIFIKASI) |
| A4 | `ReminderScheduler` | Tidak ada penerima untuk perubahan izin alarm tepat (`ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED`). Bila izin dicabut lalu diberikan lagi, sebagian alarm bisa hilang tanpa dijadwal ulang sampai aplikasi dibuka. | Keandalan | LOW-MEDIUM (BELUM TERVERIFIKASI) |
| A5 | `ReminderScheduler` | Kode permintaan alarm memakai `id.hashCode()`; tabrakan hash antara dua ID berbeda secara teori mungkin. | Keandalan | LOW |
| A6 | Android 14+ | `SCHEDULE_EXACT_ALARM` tidak diberikan otomatis pada instalasi baru; pengingat jatuh ke alarm tidak tepat sampai pengguna mengizinkan. Aplikasi sudah punya jalur pemberitahuan; perlu dipastikan pesannya jelas di UI. | Keandalan/UX | LOW |
| A7 | `setStatusBarColor`/`setNavigationBarColor` | Dengan targetSdk 36 (edge-to-edge dipaksa di Android 15+), pemanggilan ini tidak berpengaruh; tampilan bar mengandalkan latar jendela. Tidak merusak. | Pemeliharaan | LOW |
| A8 | `build-release.yml` | Tanpa `npm test`, tanpa penyesuaian `networkTimeout`, versi actions lebih lama dari debug. | Build/keandalan | HIGH untuk rilis |

## Perbaikan kandidat (belum disetujui, jangan diterapkan)
- Simpan `package-lock.json` ke repo/ZIP dan ganti `npm install` dengan `npm ci` di kedua workflow.
- Jalankan `npm test` dan naikkan `networkTimeout` di workflow rilis; seragamkan versi actions.
- Sinkronkan versionCode/versionName debug dan rilis (mis. versionName dari `package.json` di keduanya).
- Konfirmasi A1 dengan membaca `storage.js` (PART 4); A2 dengan membaca CSS/JS keyboard (PART 2/3); A3 dengan mencari iframe/navigasi luar (PART 7/8).

## CHECKPOINT NOTES KELIMAA (setelah berkas Android)
- **PART selesai:** PART 1 penuh; PART 5 dan 6 sebagian (konfigurasi Android, Gradle, lockfile, dua workflow dibaca; kode JS pemakai belum).
- **Belum diperiksa:** isi JS/CSS (PART 2–4), `worker.mjs`, `file_paths.xml`, `colors.xml`, splash drawable, `assets/capacitor.config.json`.
- **Keputusan menunggu pengguna:** (a) `KEY_ALIAS`/`KEY_PASSWORD` sama dengan konvensi debug? (b) setuju lockfile + `npm ci` dibahas di PART 9?
- **PART berikutnya:** PART 2 (JS + logika), mulai dari jalur startup: `main.js`, `startup.js`, `ui.js`, `native.js`, `storage.js`, `logic.js`, lalu `notes.js`.

---

# PEMBARUAN 3: PART 2A SELESAI (JavaScript: jalur startup, penyimpanan, editor catatan + pemindaian seluruh kode)

**Cakupan jujur:** PART 2 dibagi dua. **2A (selesai)** = pemindaian metrik otomatis seluruh 87 modul + pembacaan langsung `storage.js`, `startup.js`, `undo.js`, bagian `main.js` (impor, `load`, `persist`, `render`, pendengar global), dan bagian `notes.js` (alur simpan otomatis, riwayat, `sanitize`, `cleanup`, pendengar global). **2B (BELUM)** = pembacaan isi `lembar-ui.js`, `rumus.js`, `settings.js`, `export.js`, `share.js`, `logic.js`, sisa `main.js` dan `notes.js`, `ai/*`, `lembar-*` lain.
Semua temuan di bawah: DIPERIKSA SECARA STATIS. Angka waktu diukur di Node/desktop, BUKAN di HP; tidak ada pengukuran di Android.

## Metrik seluruh kode (terverifikasi dengan pemindai)
- `addEventListener` 242, `removeEventListener` 24 (sebagian besar pendengar menempel pada elemen yang dibuang bersama DOM, jadi selisih ini bukan otomatis kebocoran).
- `setInterval` 1 (`notes.js:1838`, 60 dtk, dilewati bila `document.hidden`, dibersihkan di `cleanup` lewat `clearInterval`). `setTimeout` 47, `requestAnimationFrame` 22.
- `innerHTML =` 13, `innerHTML +=` 0. Observer 2 (`IntersectionObserver` di `gambar-app.js`, `MutationObserver` di `notes.js`, keduanya punya `disconnect`).
- Blok `catch` kosong 86. Pembacaan layout (`getBoundingClientRect`, `offsetHeight`, dll.) 57 tempat.
- Pendengar global (window/document) tercatat: `main.js` (resize, pagehide, visibilitychange; umur aplikasi), `notes.js` (selectionchange x4, pointerdown, keydown, touchmove/pointermove/up), `exit.js:74` (keydown), `penampil.js:102` (keydown, resize), `notes.js:131` (online).
- **Pendengar global `notes.js` seluruhnya dilepas di `cleanup`** (selectionchange x4, pointerdown, keydown menu, vv resize/scroll, interval, observer, gerak seret). Tertulis di kode sebagai perbaikan Rev 195/P5. **Belum diverifikasi:** pelepasan keydown di `exit.js:74` (kemungkinan dilepas di `onKey`, belum dibaca) dan `penampil.js`.
- Ekspor: 0 ekspor yang benar-benar mati; 27 hanya dipakai tes; 242 hanya dipakai di dalam berkas sendiri (boleh jadi privat, tidak menghemat apa pun). Pencocokan berdasarkan nama, jadi bisa meleset bila ada nama yang sama di berkas lain. **Tidak ada kode JS yang aman dihapus** dari hasil ini.

## Hal yang sudah baik (terverifikasi, jangan dirusak)
Muat malas 486 KB; `modulepreload` untuk 53 modul awal; `content-visibility: auto` pada daftar catatan (Rev 194); gambar dimuat lewat `IntersectionObserver` dan disimpan di Filesystem (bukan localStorage); penyimpanan ditunda 400 ms saat mengetik dan dipaksa saat `pagehide`/`visibilitychange`; `MutationObserver` dibatasi satu per frame; `sanitize` memakai `<template>` (inert) dengan daftar putih tag/atribut; riwayat Urungkan dibatasi 100 langkah atau 2 juta karakter.

## Temuan PART 2A
| No | Lokasi | Temuan | Jenis | Prioritas | Status bukti |
|---|---|---|---|---|---|
| 2A-1 | `storage.js:93-101` + `main.js:28` | **Jalur gagal-muat bisa membuat data tampak hilang.** `load()` yang gagal mengembalikan data kosong dan menyalin teks mentah ke `catatan_app_data_rusak`. `persist()` kemudian menimpa kunci utama dengan data kosong pada simpanan pertama. Kunci `_rusak` hanya DITULIS (hanya ada di `storage.js:98`), tidak pernah dibaca, jadi tidak ada layar pemulihan. Kunci itu juga ditimpa bila kegagalan terulang. | Keandalan/data | **HIGH** (jarang terjadi, dampak berat) | Terverifikasi statis (grep). Belum pernah dipicu di HP. |
| 2A-2 | `storage.js` (`KEY`, `save`) | **Seluruh data dalam satu kunci localStorage.** Tiap `persist()` = `JSON.stringify` seluruh data + tulis seluruh blob. Batas model data aplikasi (mis. 50 lembar x ±500 KB) lebih besar dari kuota localStorage WebView (kira-kira 5 MB; angka pasti BELUM TERVERIFIKASI). Tidak ada pengukur ukuran/peringatan dini; saat penuh hanya muncul toast "Gagal menyimpan". Data di memori tetap ada tetapi hilang bila aplikasi ditutup. | Keandalan jangka panjang | **HIGH** | Struktur terverifikasi; kuota dan perilaku di HP belum. |
| 2A-3 | `main.js:24` (`const data = load()`) | `load()` (parse + `normalize` seluruh data) berjalan sinkron sebelum render pertama. Di Node: profil besar 3,5 MB = parse+normalisasi ±31 ms; profil sedang 160 KB ±1 ms. Di HP bisa beberapa kali lebih lambat; angka HP BELUM TERVERIFIKASI. | Performa startup | MEDIUM (naik seiring data) | Diukur di Node saja. |
| 2A-4 | `notes.js:2531-2533`, `1824-1830`, `2508` | **`upd` berjalan dua kali per `selectionchange`**: didaftarkan langsung DAN dipanggil lagi lewat `selChanged`. Tiap panggilan: 6x `document.queryCommandState` + 6x `querySelector`. `selChanged` juga menjalankan `snap`, `tableUi`, `foldUi`. Terjadi di setiap gerakan kursor/ketikan. | Performa runtime | MEDIUM | Terverifikasi statis; dampak ms belum diukur. Perbaikan kecil dan berisiko rendah, tetapi harus dites (urutan dengan `keepCaretRight`). |
| 2A-5 | `notes.js:1350-1376` (`save`) | Tiap simpan otomatis (400 ms setelah berhenti mengetik): `notePlain` + `sanitize(ed.innerHTML)` (parse + telusur DOM seluruh catatan) + `JSON.stringify` seluruh data + tulis localStorage. Biaya naik bersama ukuran catatan DAN ukuran seluruh data. Riwayat Urungkan menyimpan salinan HTML penuh (maks 2 juta karakter, ±4 MB RAM per editor terbuka, dibebaskan saat editor ditutup). | Performa/RAM | MEDIUM | Statis; belum diprofil. |
| 2A-6 | `notes.js` (`openEditor`, baris ±535-2540) | Satu fungsi tertutup ±2.000 baris; `cleanup` (baris 1839) satu baris ±1.800 karakter. Setiap pendengar global baru HARUS ditambahkan manual ke `cleanup`; riwayat kebocoran pernah terjadi (Rev 195). Risiko pemeliharaan, bukan bug saat ini. | Pemeliharaan | MEDIUM | Terverifikasi. Jangan refactor besar tanpa persetujuan. |
| 2A-7 | seluruh kode | 86 blok `catch` kosong; penanganan error tidak seragam (ada `console.error`, ada toast, ada diam). Sebagian disengaja ("best effort"), tetapi menyulitkan debugging. | Pemeliharaan | LOW | Terverifikasi (hitungan). Belum dikelompokkan mana yang aman. |
| 2A-8 | `storage.js` `normalize` | Hanya kunci tingkat atas yang dikenal yang disalin (`habits`, `tasks`, `notes`, `priv`, `trash`, `settings`, `sheets`, `projects`, `habitLog`). Data dari versi aplikasi yang lebih baru dengan kunci tambahan akan kehilangan kunci itu pada simpanan berikutnya (relevan hanya bila pengguna menurunkan versi/memulihkan cadangan dari versi lebih baru). `load()` tidak memeriksa `version`. | Keandalan | LOW | Terverifikasi statis. |

## Kandidat optimasi (belum disetujui, belum diterapkan)
- 2A-1: simpan salinan "terakhir baik" terpisah atau tahan penimpaan sampai pengguna memilih pulihkan/mulai baru (butuh keputusan; menambah pemakaian kuota, lihat 2A-2).
- 2A-2: tambahkan pengukur ukuran data + peringatan dini sebelum evaluasi IndexedDB (migrasi hanya setelah analisis untung-rugi di PART 4).
- 2A-4: hapus pendaftaran langsung `upd` bila terbukti `selChanged` sudah memanggilnya (perubahan kecil, wajib dites).
- 2A-3/2A-5: ukur di HP (alat `tools/ukur_*` berjalan di Chromium, bukan HP) sebelum mengubah apa pun.

## CHECKPOINT NOTES KELIMAA (PART 2A)
- **PART selesai:** PART 1; PART 2A; PART 5 dan 6 sebagian (Android/Gradle/lockfile/workflow dibaca).
- **File sudah diperiksa:** pemindaian metrik 87 modul; baca langsung: `storage.js`, `startup.js`, `undo.js`, `main.js` (sebagian), `notes.js` (sebagian: simpan otomatis, riwayat, sanitize, cleanup, selectionchange), `exit.js` (potongan), `ui.js` (potongan JUDUL).
- **File belum diperiksa isinya:** `lembar-ui.js`, `rumus.js`, `settings.js`, `export.js`, `share.js`, `logic.js`, `lembar-alat.js`, `lembar-validasi.js`, `lembar-pulau.js`, `ingatkan.js`, `lembar.js`, `gambar.js`, `tp-alarm.js`, `lipat.js`, `bilah-chip.js`, `twopockets.js`, seluruh `ai/*`, `native.js`, sisa `main.js`/`notes.js`, `styles.css`, `worker.mjs`.
- **Risiko:** perubahan `selectionchange` menyentuh editor inti (tes `rev*` banyak mengunci perilaku editor); perubahan penyimpanan menyentuh data pengguna lama (SCHEMA 21).
- **Keputusan dibutuhkan:** (a) lanjut PART 2B (baca modul besar lain) atau pindah ke PART 3/4 dulu? (b) Untuk 2A-1: apakah pengguna pernah melihat aplikasi "kosong" tiba-tiba? (petunjuk apakah jalur ini pernah terpicu).
- **PART berikutnya:** PART 2B.

---

# PEMBARUAN 4: PART 4 SELESAI (Storage, data, cadangan) , dengan batasan cakupan

Jawaban pengguna untuk pertanyaan 2A-1: **tidak pernah** melihat aplikasi tiba-tiba kosong. Jalur gagal-muat BELUM PERNAH terpicu menurut pengguna; risikonya tetap dinilai karena dampaknya.

**Dibaca langsung:** `storage.js`, `backup.js`, `privat.js`, `security.js`, bagian `settings.js` (ekspor, pilih/pulihkan cadangan, tempat sampah), `logic.js` (`replaceData`, `purgeTrash`, nama dan jadwal cadangan), `gambar.js` (`refsOfData`, `findOrphans`), `gambar-app.js` (`cleanupOrphanImages`), `cadangan-gambar.js` (`uniqueRefs`), bagian `main.js` (startup).
**Diuji kecil di Node (bukan HP):** `replaceData` terhadap `habitLog`; `save()` saat kuota penuh.
**Belum dibaca:** `export.js` (TXT/MD/PDF/JPG), `zip.js`, `readBackupFile`/`writeBackupImages`/`writeZipToCache` (penggunaan memori ZIP besar), `terima.js`, `ai/ruang.js` (penyimpanan percakapan AI di berkas), `twopockets.js`.

## Peta penyimpanan (terverifikasi)
| Data | Tempat | Ikut cadangan? |
|---|---|---|
| Catatan, tugas, kebiasaan, catatan privat, sampah, lembar kerja, proyek, `habitLog`, pengaturan (termasuk hash PIN, salt, hitungan gagal) | localStorage kunci `catatan_app_data` (satu JSON) | Ya |
| Salinan data yang gagal dimuat | localStorage `catatan_app_data_rusak` | Tidak (tidak pernah dibaca) |
| Izin data AI, sambungan AI, konfigurasi AI | localStorage `kelimaa_ai_ctx`, `kelimaa_ai_conn`, `kelimaa_ai_cfg` | Tidak |
| Sambungan/cache/alarm Two Pockets | localStorage `kelimaa_twopockets`, `_due`, `_alarmcfg` | Tidak |
| Gambar catatan | Filesystem (folder DATA) | JSON: hanya rujukan; ZIP: ikut |
| Percakapan AI | berkas di folder DATA (`ai/ruang.js`) | Tidak ikut cadangan data (keputusan 27.8); cadangan terpisah (`ai/cadangan.js`) |
| Pengingat native | SharedPreferences Android `kelimaa_reminders` | Tidak (dijadwalkan ulang dari data saat dibuka) |
| Warna bar | SharedPreferences `kelimaa_bars` | Tidak |

## Temuan PART 4
| No | Lokasi | Temuan | Jenis | Prioritas | Bukti |
|---|---|---|---|---|---|
| 4-1 | `main.js` afterFirstPaint (~baris 452) + `storage.js:93-101` | **Gagal-muat berantai.** `cleanupOrphanImages(data)` berjalan TIAP buka aplikasi memakai data di memori, tanpa memeriksa apakah `load()` berhasil. Bila `load()` gagal (data kosong), semua berkas gambar yang lebih tua dari 24 jam dianggap yatim dan DIHAPUS PERMANEN, dan simpanan pertama menimpa data utama. Hanya teks mentah yang tersisa di `_rusak` (tanpa layar pemulihan). Gabungan dengan 2A-1. | Keandalan/data | **HIGH** (peluang rendah; dampak tak bisa dipulihkan; layak diperlakukan sebagai CRITICAL-potensial) | Statis (`grep` + baca kode). Tidak pernah terpicu menurut pengguna. |
| 4-2 | `logic.js:242` `replaceData` | **`habitLog` tidak ikut diganti saat Pulihkan cadangan.** Daftar kunci yang disalin tidak memuat `habitLog` (SCHEMA 20+). Setelah pulihkan, riwayat kebiasaan tetap milik HP sekarang, bukan cadangan; bercampur dengan hasil reset harian berikutnya. | Integritas data | MEDIUM | **Diuji di Node:** setelah `replaceData`, `habitLog` tetap nilai lama. |
| 4-3 | `settings.js` `pickBackup/doRestore` | Pulihkan cadangan = dua konfirmasi, tetapi **tidak ada salinan otomatis data saat ini** sebelum diganti, dan tidak ada urungkan. Salah pilih berkas lama = data terbaru hilang. Urutan sudah aman untuk gambar (gambar ditulis dulu; gagal = data tidak diganti). | Keandalan | MEDIUM | Statis. |
| 4-4 | `backup.js`, `logic.js:488` | **Berkas cadangan otomatis tidak pernah dihapus.** Nama berdasarkan tanggal+jam; hanya daftar riwayat di aplikasi dibatasi 20 entri, berkasnya menumpuk di folder pilihan. Tiap berkas berisi seluruh data dan dicetak berspasi (`JSON.stringify(..., null, 2)`), sehingga lebih besar dari perlu. Contoh: mingguan, data 3,5 MB = ±180 MB per tahun (perkiraan, bukan ukuran nyata). Gambar hanya disalin yang baru. | Efisiensi penyimpanan | MEDIUM | Statis; angka tahunan perkiraan. |
| 4-5 | `security.js`, `settings.js` askExport, `backup.js` | **Catatan privat tidak dienkripsi** (pilihan pengguna, tercatat di kode dan dialog ekspor). Konsekuensi terverifikasi: teks catatan privat, hash PIN, salt, dan hitungan gagal ada di localStorage dan di SETIAP berkas cadangan (otomatis ke folder Dokumen juga). PIN 4-6 angka (PBKDF2-SHA256, 100.000 iterasi) hanya pagar tampilan: maksimal 10^6 kemungkinan, bisa ditebak offline bila berkas didapat; penghitung kunci sementara ada di data yang sama dan memakai `Date.now()` (bisa dilewati lewat jam atau pulihkan cadangan lama). APK debug (yang dipakai sehari-hari) bersifat debuggable; pada Android umumnya data aplikasi debuggable dapat dibaca lewat `adb run-as` tanpa root (BELUM TERVERIFIKASI di HP Anda). | **Keamanan** (bukan performa) | MEDIUM (keputusan pengguna; jangan diubah sepihak) | Statis. Peringatan saat mengaktifkan cadangan otomatis: BELUM DIPERIKSA. |
| 4-6 | `lembar.js:12`, `storage.js` | **Batas ukuran hanya untuk lembar kerja** (50 lembar x 500 KB = potensi 25 MB). Catatan dan tugas tanpa batas jumlah/ukuran. Kuota localStorage WebView kira-kira 5 MB (BELUM TERVERIFIKASI). Tidak ada pengukur ukuran. Saat penuh: `save()` mengembalikan `ok:false` dan toast "Gagal menyimpan" (ditiru di Node, tidak crash), tetapi isi di memori hilang bila aplikasi ditutup; toast bisa muncul tiap simpan otomatis. | Keandalan jangka panjang | HIGH (jangka panjang) | Perilaku gagal-simpan diuji di Node; kuota nyata belum diukur. |
| 4-7 | `storage.js` | Tidak ada kunci `version` yang dipakai untuk memutuskan migrasi: `normalize()` toleran terhadap data lama (tidak ada migrasi destruktif; ini baik), tetapi data dari versi lebih baru kehilangan kunci tak dikenal pada simpanan berikutnya. | Keandalan | LOW | Statis. |

## Hal baik (terverifikasi)
Impor divalidasi lewat `normalize` dan ditolak bila bentuk salah; pembersihan gambar yatim konservatif (masa tenggang 24 jam, hanya nama `ID.ext`, aman-gagal bila waktu tak jelas; rujukan mencakup catatan, privat, dan sampah); hapus otomatis tempat sampah meminta konfirmasi bila langsung menghapus; ekspor manual memperingatkan data tidak terenkripsi; kegagalan simpan tidak menjatuhkan aplikasi.

## Evaluasi migrasi ke IndexedDB (BELUM direkomendasikan diterapkan; untuk keputusan di PART 9)
- **Untung:** kuota jauh lebih besar; simpan per catatan (tulis hanya yang berubah, bukan seluruh blob); tidak memblokir main thread saat parse besar; transaksi atomik.
- **Rugi/risiko:** perlu migrasi dari kunci `catatan_app_data` (jalur salah = data hilang); semua modul membaca `ctx.data` sinkron di memori sekarang, jadi perubahan menyentuh `main.js`, `storage.js`, ratusan tes; kompatibilitas cadangan lama harus dijaga; perilaku IndexedDB di WebView Android lama perlu diuji di HP.
- **Alternatif ringan lebih dulu:** (1) penjaga gagal-muat (4-1), (2) pengukur ukuran + peringatan dini, (3) simpan salinan "terakhir baik". Ini menurunkan risiko tanpa mengganti sistem penyimpanan.
- **Kompatibilitas:** `@capacitor/filesystem` sudah dipakai untuk gambar; bisa jadi jalur penyimpanan berkas alternatif (satu berkas per kategori) tetapi tidak lebih sederhana.

## CHECKPOINT NOTES KELIMAA (PART 4)
- **PART selesai:** 1, 2A, 4 (dengan batasan di atas), 5 dan 6 sebagian.
- **File belum diperiksa isinya:** lihat daftar PART 2A + `export.js`, `zip.js`, `terima.js`, `ai/ruang.js`, `twopockets.js`.
- **Temuan penting baru:** 4-1 (HIGH, berantai), 4-2 (bug nyata, terbukti), 4-3, 4-4, 4-5 (keamanan, keputusan pengguna), 4-6.
- **Keputusan dibutuhkan:** (a) setuju 4-1 dan 4-2 diperbaiki di rencana akhir (perbaikan kecil, berisiko rendah)? (b) Berapa lama berkas cadangan lama ingin disimpan (mis. 10 terakhir) atau tetap tidak dihapus? (c) Catatan privat tetap tidak dienkripsi (keputusan lama)? Bila ingin dibahas, jadi PART 7.
- **PART berikutnya:** PART 3 (HTML/CSS) lalu PART 2B (modul JS besar sisanya), PART 7, PART 8, PART 9.

---

# PEMBARUAN 5: PART 3 SELESAI (HTML & CSS) (14 Nov 2026)

**Tidak ada kode yang diubah.** `npm run build` dan alat ukur dijalankan hanya di salinan sementara hasil ekstrak ZIP.

**Cakupan jujur:** `src/index.html` (376 byte) dibaca penuh. `styles.css` (2.298 baris) dipindai dengan skrip (metrik, variabel, kelas, keyframes, transisi, selektor ganda) dan dibaca langsung pada bagian: token tema (baris 3-6, 821-823), blok langit/bintang (638-673), `.fs-capsule`, `.chip`, `.ksheet`, `.vd-*`, serta pemakaian `:has()`, `will-change`, `content-visibility`. **TIDAK dibaca baris demi baris.**
**Jenis bukti:** diperiksa statis + diukur di **Chromium 153 (Playwright) di sandbox, BUKAN HP.** Angka mutlak tidak boleh disamakan dengan HP maupun dengan run GitHub Actions Anda.

## Hasil terverifikasi
1. **HTML:** `index.html` hanya `<div id="app">` + `js/main.js`; `viewport-fit=cover`, `color-scheme: light dark`; tidak ada `user-scalable`/`maximum-scale` (zoom tidak diblokir). Layar pertama sepenuhnya dirender JS (tidak ada kerangka/skeleton; splash native menutupi). Tidak ada temuan.
2. **Ukuran CSS:** 231.389 B (sumber) menjadi 208.133 B setelah minify build (sekitar -10%). Gzip tidak relevan karena aset dimuat lokal dari APK. Tidak ada `@import` dan tidak ada `@font-face` (font sistem).
3. **Animasi:** 16 `@keyframes`, **semuanya hanya `opacity`/`transform`** (ramah compositor). Satu-satunya transisi properti layout: `transition: width .3s` (1 tempat). `backdrop-filter` hanya satu pemakaian nyata (`.fs .dock`, blur 16px); `filter: blur(9px)` hanya di SVG statis `.navbg .navsh`. `will-change` 8 deklarasi.
4. **Hal baik (jangan dirusak):** `prefers-reduced-motion` ditangani di 24 tempat; `content-visibility: auto` + `contain-intrinsic-size` pada `.sw` (kartu daftar); `:has()` hanya 4 pemakaian (di editor/lembar, bukan di daftar besar).
5. **Kelas CSS:** 791 nama kelas. Hanya **`.fbar .numfmt`** yang benar-benar mati (JS tidak membuatnya lagi). **Jangan dihapus begitu saja:** `tests/daftar.test.mjs` dan `tests/rev247.test.mjs` masih mengunci keberadaannya di CSS. 12 nama lain TAMPAK mati tetapi **dibangun dinamis** lewat penyambungan string (`tn-`+tone, `ha-`+st.ha, `md-h`+n, `hs-`+state): TERPAKAI, jangan dihapus.
6. **Variabel CSS:** dideklarasikan tetapi tidak dipakai lewat `var()`: `--tl`, `--r-lg`, `--tile-min`. Dipakai tanpa deklarasi di CSS: `--skyh`, `--a`, `--len`, `--sw`, `--ksn`, `--ksh`, `--wm`, `--wc` (di-set lewat `setProperty` di JS, terverifikasi), `--nb`/`--nbtn` (disebut di JS, caranya belum diperiksa), `--danger` (selalu punya cadangan `#c83248`, aman), dan **`--card` (lihat temuan 3-2)**.
7. **Hasil alat ukur `tools/ukur_performa.py`** (Chromium CPU 4x, sandbox saya; build `www/`):
   - Buka dingin, 3 putaran: sedang (585, 441, 600) ms; besar (746, 626, 932) ms.
   - Buka hangat: sedang (255, 139, 293); besar (337, 294, 343) ms. Pindah Tugas ke Catatan (200 kartu): sekitar 180-350 ms.
   - S4 buka-tutup editor x20: **BERSIH** (selisih 0 node, 0 pendengar; heap naik sekitar 266 KB lalu mendatar).
   - S5b ketukan di catatan 20.000 huruf: median 27-29 ms.
   - S5a (semburan 20.000 huruf, 5,1-6,1 detik): sudah dicatat RIWAYAT Rev 197d sebagai "tidak realistis, hanya informatif". **Bukan temuan.**
   - Pola konsisten dengan hasil lama di RIWAYAT.

## Temuan PART 3
| No | Lokasi | Temuan | Jenis | Prioritas | Status bukti |
|---|---|---|---|---|---|
| 3-1 | `styles.css` 638-650, `--tw1`/`--tw2` (baris 5-6), `notes.js:1327` | **Bintang berkedip tema gelap = animasi `infinite` tanpa henti** pada 2 lapisan layar penuh (`body::before/::after`, `position:fixed`, `will-change: opacity`; `tw 3.4s` dan `tw2 5s`). Saat editor dibuka pada catatan tanpa warna, `.fs.skybg::before/::after` menambah 2 lapisan lagi; lapisan `body` di belakangnya kemungkinan tetap berjalan (hanya dari baca kode). Tema terang tidak punya kedip. Komentar kode: "Selalu aktif" (disengaja). | Baterai/CPU-GPU saat diam | **MEDIUM** (prioritas Anda: terasa ringan; kedip adalah pilihan tampilan, jangan dicabut sepihak) | **Terukur di Chromium** (idle 8 dtk x 2 ulangan, CPU proses): terang renderer 0,0-0,1% / GPU 0,0%; **gelap bawaan renderer 1,4-1,7% / GPU 12,9-15,7%**; gelap dengan kedip dimatikan (uji) 0,2% / 0,1-0,2%. `document.getAnimations()`: terang 1, gelap 3, gelap tanpa kedip 1. **Catatan:** Chromium headless memakai render perangkat lunak, jadi angka GPU mutlak berlebihan dibanding HP; yang terbukti hanya bahwa kedip membuat frame diproduksi terus-menerus saat layar diam. **Dampak baterai/panas di HP: BELUM TERVERIFIKASI.** Jumlah animasi saat editor terbuka: BELUM DIUKUR (percobaan otomatis gagal membuka editor). Apakah pengaturan "hapus animasi" Android memicu `prefers-reduced-motion` di WebView: BELUM TERVERIFIKASI. |
| 3-2 | `styles.css`: `.fs-capsule`, `.fss-dot`, `.tbl-grid-cell.on`, `.ed2 td/th` (color-mix), `.chip`, `.lz-rrow`, `.lz-sw`, `.vd-it`, `.vd-dot`, `.vd-pc`, cadangan di `.ksheet` | **`--card` dipakai di 11 tempat tetapi tidak pernah dideklarasikan** (tidak di CSS, tidak di JS). Terbukti di Chromium: `background: var(--card)` menjadi `rgba(0,0,0,0)` (transparan). RIWAYAT Rev 76 sudah tahu "`--card` tembus pandang" dan mengganti menu tabel ke `--sfo`/`--sfob`; pemakai lain belum diganti. Tampilannya sudah Anda uji dan nyatakan aman, jadi ini bukan kerusakan fungsi. | Konsistensi/keterbacaan | LOW-MEDIUM | Statis + uji kecil Chromium (var tanpa deklarasi = transparan). Seperti apa tiap komponen di HP: BELUM TERVERIFIKASI (mis. `.fs-capsule`, kapsul ukuran huruf yang melayang di atas teks catatan). Baris `.ed2 td, .ed2 th` yang memakai `color-mix(... var(--card) ...)` kemungkinan dibuang browser karena tidak valid: BELUM TERVERIFIKASI. |
| 3-3 | `styles.css` | **Duplikasi bawaan penimpaan antar revisi:** 139 dari 1.724 selektor tingkat atas didefinisikan lebih dari sekali (`:root` 11x, `nav` 8x, `nav button` 6x, dst.). Blok token gelap ada dua salinan identik (otomatis + manual): 6 pasang, sekitar 3.435 B ganda. | Pemeliharaan | LOW | Statis. Belum dinilai mana yang aman digabung (urutan cascade berarti). Jangan digabung tanpa tes tampilan. |
| 3-4 | `styles.css` | Sisa kecil: `.fbar .numfmt` (kelas mati, dikunci 2 tes), `--tl`, `--r-lg`, `--tile-min` (tak dipakai). | Pembersihan | CLEANUP | Statis. `numfmt` butuh perubahan 2 tes bila dihapus. |

## Kandidat optimasi (belum disetujui, jangan diterapkan)
- 3-1: tambah saklar "Bintang berkedip" di Setelan (bawaan tetap menyala), dan/atau jedakan kedip saat editor layar penuh menutupi lapisan `body`, dan/atau kurangi dari 2 ke 1 lapisan. Tes yang mengunci CSS langit perlu dicek lebih dulu. Ukur ulang di HP sebelum klaim hemat.
- 3-2: pilih salah satu: (a) biarkan seperti sekarang, (b) deklarasikan `--card` eksplisit supaya niatnya terbaca (tampilan bisa bergeser sedikit, perlu cek di HP), (c) ganti ke token solid (`--sfo`) per komponen (mengubah tampilan, butuh persetujuan).
- 3-3/3-4: tunda; manfaat kecil, risiko kena tes. Bila dikerjakan, jadikan satu paket "pembersihan CSS" paling akhir.

## CHECKPOINT NOTES KELIMAA (PART 3)
- **PART selesai:** 1, 2A, 3, 4 (dengan batasan), 5 dan 6 sebagian.
- **File diperiksa:** `index.html` penuh; `styles.css` lewat pemindai + cuplikan; `www/` hasil build; `tools/ukur_performa.py` dan `buat_data.mjs` dijalankan (profil sedang dan besar).
- **Belum diperiksa isinya:** `lembar-ui.js`, `rumus.js`, `settings.js`, `export.js`, `share.js`, `logic.js`, `lembar-alat.js`, `lembar-validasi.js`, `lembar-pulau.js`, `ingatkan.js`, `lembar.js`, `gambar.js`, `tp-alarm.js`, `lipat.js`, `bilah-chip.js`, `twopockets.js`, seluruh `ai/*`, `native.js`, `zip.js`, `terima.js`, `export.js`, sisa `main.js`/`notes.js`, `worker.mjs`, `file_paths.xml`, `colors.xml`, splash drawable.
- **Temuan penting baru:** 3-1 (kedip bintang terus-menerus, terukur), 3-2 (`--card` tak terdeklarasi, terbukti transparan).
- **Keputusan menunggu Anda:**
  1. (dari PART 4) 4-1 dan 4-2 diperbaiki di rencana akhir? Berapa lama berkas cadangan lama disimpan? Catatan privat tetap tidak dienkripsi?
  2. (dari PART 1/Android) `KEY_ALIAS` = `notes-kelimaa` dan `KEY_PASSWORD` = `KEYSTORE_PASSWORD`?
  3. (baru) 3-1: kedip bintang tetap seperti sekarang, tambah saklar di Setelan, atau kurangi lapisan?
  4. (baru) 3-2: opsi (a), (b), atau (c)?
- **PART berikutnya:** PART 2B (modul JS besar sisanya), lalu PART 7, PART 8, PART 9.

---

# PEMBARUAN 6: KEPUTUSAN PENGGUNA (14 Nov 2026)

**Diputuskan:**
- **3-1 Bintang berkedip:** TETAP seperti sekarang. Tidak ada saklar dan tidak ada pengurangan lapisan. Keluar dari kandidat optimasi.
- **3-2 `--card`:** DIBIARKAN (tetap transparan seperti tampilan sekarang). Keluar dari kandidat optimasi.
- **4-5 Catatan privat:** TETAP tidak dienkripsi (keputusan lama dipertahankan).
- **Secret rilis:** `KEY_ALIAS` dan `KEY_PASSWORD` sama dengan konvensi asli (alias `notes-kelimaa`, password kunci = password keystore) dan tidak pernah diubah.

**Masih terbuka:**
- 4-1 (jalur gagal-muat berantai) dan 4-2 (`habitLog` tidak ikut Pulihkan): diperbaiki di rencana akhir atau tidak?
- Berapa banyak berkas cadangan otomatis lama yang disimpan (mis. 10 terakhir), atau tetap tidak dihapus?

**PART berikutnya:** PART 2B, lalu PART 7, PART 8, PART 9.

---

# PEMBARUAN 7: KEPUTUSAN TAMBAHAN + REKOMENDASI 4-1/4-2 + PART 2B-1 (14 Nov 2026)

**Tidak ada kode yang diubah.**

## Keputusan pengguna (tambahan)
- Berkas cadangan otomatis lama: **TIDAK PERNAH dihapus** (tetap seperti sekarang). Temuan 4-4 ditutup sebagai keputusan sengaja.
- 4-1 dan 4-2: disambut baik, pengguna minta rekomendasi cara memperbaiki. Rekomendasi di bawah; persetujuan final menunggu pengguna.

## Rekomendasi perbaikan (BELUM diterapkan; dibaca dari `storage.js`, `logic.js`, `main.js`)
**4-1 (gagal-muat berantai), tiga langkah kecil, tanpa mengganti sistem penyimpanan:**
1. `load()` mengingat bahwa pemuatan gagal (penanda modul, mis. `wasLoadFailure()`).
2. `main.js` MELEWATI `cleanupOrphanImages(data)` bila penanda aktif. Ini bagian yang tak bisa dipulihkan (gambar terhapus permanen), nilai terbesar, perubahan ±3 baris.
3. `load()` tidak menimpa `catatan_app_data_rusak` bila sudah ada (simpan yang tertua) dan aplikasi menampilkan satu toast/dialog singkat bahwa data gagal dibaca dan salinan disimpan. Layar pemulihan penuh TIDAK diusulkan. Catatan kuota: salinan `_rusak` memakai kuota localStorage tambahan.
Tes baru: simulasi `load()` gagal, pastikan pembersihan gambar tidak berjalan. Risiko rendah; menyentuh jalur startup, jadi tes `rev*` terkait startup harus dijalankan penuh.

**4-2 (`habitLog` tidak ikut Pulihkan):** `replaceData` menyalin `habits, tasks, notes, priv, trash, settings, sheets, projects` tetapi TIDAK `habitLog` (diverifikasi dengan membaca kode; `normalize` memuat `habitLog`). Perbaikan satu baris di `logic.js` mengikuti pola `sheets`/`projects` (cadangan lama tanpa `habitLog` = nilai kosong yang sah sesuai `cleanHabitLog`). Tes: `replaceData` dengan sumber berisi `habitLog` lalu periksa hasilnya. Risiko rendah.

## PART 2B-1: pemeriksaan JS lanjutan (cakupan SEBAGIAN)
**Cakupan jujur:** dipindai dengan skrip seluruh `src/js/**` (pola berisiko) dan dibaca langsung: `sanitize` + daftar tag diizinkan (`notes.js`), asal tiap `innerHTML =`, `links.js`, `terima.js`, `exit.js`, `ai/obrolan.js` (iframe saran), `ai/riset.js` (`cleanSuggest`, `googleLink`), `ai/sambungan.js` (validasi alamat), sebagian `rumus.js` (batas dan jenis galat), sebagian `cadangan-gambar.js` (batas ukuran), potongan `apply-native.mjs` (`closeAppTotal`). **BELUM dibaca isi:** `lembar-ui.js` (151 KB), sebagian besar `settings.js`, `export.js`/`share.js` (penggambaran), `lembar-alat.js`, `lembar-validasi.js`, `ingatkan.js`, `twopockets.js`, `ai/ruang.js`, `ai/konteks.js`, `ai/aksi.js`, `ai/insight.js`, `worker.mjs`. Semua temuan: diperiksa statis, tidak diuji di HP.

**Terverifikasi baik (jangan dirusak):**
1. Tidak ada `eval`, `new Function`, `document.write`, `insertAdjacentHTML`. Dari 13 `innerHTML =`: lewat `sanitize()`, salinan DOM sendiri, tabel dari angka, atau HTML dari `buildFigure` yang divalidasi lewat `<template>` (inert).
2. `sanitize`: daftar putih tag (tanpa `A`, `IMG`, `SCRIPT`, `IFRAME`), atribut `style` hanya `color`/`font-size` berpola ketat, `INPUT` hanya checkbox, `class` hanya dari daftar.
3. Mesin rumus: tanpa `eval`; hitung topologis iteratif (tanpa rekursi antar sel); batas `MAX_FX` 500, `MAX_DEPTH` 32, `MAX_ARGS` 64, 26 kolom x 500 baris; galat `#CIRC!` menjalar; teks hasil dibatasi.
4. Navigasi luar: tidak ada `iframe` selain kartu saran Google (`sandbox="allow-same-origin"` TANPA izin skrip, `cleanSuggest` menolak script/iframe/object/embed/base/meta, ketukan hanya dibuka bila `https://google.com`); tautan keluar lewat `openExternal` (hanya http/https, `noopener`). Dugaan A3 (jembatan native terpapar) **turun ke LOW**: skrip tidak bisa berjalan di iframe itu. Syarat: Capacitor harus membuka host luar di peramban, bukan di WebView; kode Capacitor tidak ada di ZIP, jadi sisi itu BELUM TERVERIFIKASI.
5. Alamat Worker dikunci regex `*.workers.dev` (https) supaya passcode tidak terkirim ke alamat sembarang. Hanya 3 pemanggil `fetch`: `links.js`, `twopockets.js`, `ai/sambungan.js`; di native, pratinjau tautan lewat `CapacitorHttp`.
6. Pulihkan cadangan: batas `MAX_JSON_BYTES`/`MAX_ZIP_BYTES`/`MAX_ENTRY_BYTES`, ZIP dibaca per potongan lewat `blob.slice` (tidak dimuat seluruhnya).
7. Teks Bagikan masuk lewat `parseShared` (dipotong `SHARE_IN_MAX`, hanya teks), `sharedToHtml` lalu `sanitize`; Catatan Privat dikunci dulu dan tidak pernah menerimanya.
8. Plugin native `Filesystem` (9 pemakaian), `Share` (4), `CapacitorHttp` (3) benar-benar dipakai. Menutup bagian BELUM TERVERIFIKASI A-6 di Pembaruan 2.

**Dugaan A1 (keluar dimatikan 1,2 dtk, data hilang?) diperkecil:** `prepareExit` menjalankan `closeEditor()` lalu `ctx.persist()` (sinkron ke localStorage) SEBELUM native menunda `killProcess` 1.200 ms (`apply-native.mjs:182-193`). Sisa kemungkinan: penulisan localStorage ke DISK oleh Chromium bisa tertunda beberapa detik dan proses dimatikan sebelum itu. Kejadian ini juga bisa terjadi bila aplikasi dibuang dari recents. **BELUM TERVERIFIKASI** (tidak ada bukti di kode ini). Uji HP sederhana bila ingin kepastian: ketik catatan, langsung Keluar, buka lagi. Prioritas LOW-MEDIUM; tidak ada perubahan diusulkan sebelum diuji.

**Temuan baru PART 2B-1:**
| No | Lokasi | Temuan | Jenis | Prioritas | Bukti |
|---|---|---|---|---|---|
| 2B-1 | `index.html` | Tidak ada Content-Security-Policy. Pertahanan utama sudah kuat (sanitasi daftar putih, tanpa `eval`, iframe tanpa skrip), jadi CSP hanya lapisan tambahan. Menambahnya berisiko merusak gaya inline, gambar tautan dari situs luar, dan koneksi ke Worker. | Keamanan (pertahanan berlapis) | LOW | Statis. Kompatibilitas CSP dengan fitur: BELUM TERVERIFIKASI. Tidak disarankan tanpa uji HP menyeluruh. |
| 2B-2 | `ai/riset.js` `cleanSuggest` | Hanya menolak `script/iframe/object/embed/base/meta`; `<link>`/`<style>` dari HTML saran tetap lolos dan bisa memuat sumber luar di dalam iframe (hanya soal privasi, tanpa eksekusi skrip). Sumbernya Worker milik pengguna yang meneruskan Google. | Privasi | LOW | Statis. Tidak perlu diubah kecuali sumber Worker dipercayai kurang. |

## CHECKPOINT NOTES KELIMAA (PART 2B-1)
- **PART selesai:** 1, 2A, 2B-1 (sebagian), 3, 4, 5 dan 6 sebagian.
- **Belum diperiksa isinya:** lihat daftar "BELUM dibaca" di atas.
- **Keputusan menunggu pengguna:** setuju 4-1 (tiga langkah) dan 4-2 (satu baris) masuk rencana akhir?
- **PART berikutnya:** PART 2B-2 (`lembar-ui.js`, `settings.js`, `export.js`/`share.js`, `ingatkan.js`, `twopockets.js`, `ai/ruang.js`, `ai/konteks.js`, `ai/aksi.js`, `worker.mjs`), lalu PART 7, PART 8, PART 9.

---

# PEMBARUAN 8: KEPUTUSAN 4-1/4-2 + PART 2B-2 SELESAI (14 Nov 2026)

**Tidak ada kode yang diubah.** Semua pemeriksaan dilakukan di salinan sementara hasil ekstrak ZIP.

## Keputusan pengguna
- **4-1 (gagal-muat berantai): DISETUJUI masuk rencana akhir** (tiga langkah dari Pembaruan 7: penanda gagal-muat, lewati `cleanupOrphanImages` bila gagal, jangan timpa `catatan_app_data_rusak` + satu toast singkat).
- **4-2 (`habitLog` tidak ikut Pulihkan): DISETUJUI masuk rencana akhir** (satu baris di `logic.js` `replaceData`, plus tes).
- Pengguna menyatakan: "pokok yang bagus". Penerapan kode tetap menunggu PART 7-9 selesai dan rencana akhir disetujui.

## Baseline (terverifikasi)
- ZIP = 443 berkas, `package.json` 0.3.121. `npm test` exit 0 di sandbox (Node 22.23.4), sekitar 1960 baris ok. Ini lolos automated test di sandbox, BUKAN uji HP.
- `worker.mjs` yang diunggah ulang pengguna IDENTIK byte-per-byte dengan `backend/cloudflare/worker.mjs` di ZIP (dicek `cmp`).

## Cakupan PART 2B-2 (jujur)
**Dibaca langsung:** `worker.mjs` PENUH (baris 1-358 + jalur masuk), `ai/aksi.js` (baris 1-80), `ai/ruang.js` (baris 1-70), `ingatkan.js` (awal), cuplikan `lembar-ui.js` (loop seret baris 340-375, pendengar gulir 1292-1306), cuplikan `settings.js` (pendengar seret).
**Dipindai dengan skrip/grep:** pendengar, timer, `innerHTML`, `catch` kosong, canvas/batas ekspor, `AbortController`/timeout di `ingatkan`, `twopockets`, `export`, `share`, `settings`, `lembar-ui`, `lembar-alat`, `lembar-validasi`.
**BELUM dibaca isinya:** badan `lembar-ui.js` (151 KB), badan `settings.js`, penggambaran `export.js`/`share.js` (batas ukuran kanvas per halaman belum dicek), `ai/konteks.js`, badan `twopockets.js`, sisa `ai/aksi.js` dan `ai/ruang.js`.
Semua temuan: diperiksa statis, tidak diuji di HP.

## Hasil terverifikasi (baik, jangan dirusak)
1. **Worker:** passcode dibandingkan lewat hash waktu-tetap dan SEMUA entri selalu diperiksa; penghitung gagal per IP (maks 10 per jam); CORS hanya `localhost`/`capacitor://localhost`; Content-Length dicek sebelum badan dibaca; pesan galat penyedia disaring dari untaian mirip kunci; model divalidasi regex; batas harian, plafon `HARD_DAILY_LIMIT`, dan batas bulanan opsional; tanpa KV = chat ditolak (aman); retry galat sementara + model cadangan Gemini dibatasi `DEADLINE_MS` 52 dtk; `research` memakai sumber `https` saja dan menolak saran berisi script/iframe/object/embed.
2. **Alur teks AI:** selalu `sharedToHtml` lalu `sanitize`; id ruang divalidasi `ID_RE` sebelum jadi nama berkas; fungsi penyimpanan tidak melempar error; batas 20 ruang, 100 pesan, 4000 huruf per pesan.
3. **Pendengar/timer:** `ingatkan`, `twopockets`, `export`, `share`, `lembar-alat`, `lembar-validasi` tanpa pendengar global; `lembar-ui.js` (59 pendengar) dan `settings.js` (6) tidak ada yang menempel di `window`/`document`; pendengar seret di `settings.js` dilepas; tidak ada `setInterval` baru (tetap satu, di `notes.js`).
4. **Ekspor:** PDF maks 60 halaman, JPG maks 12 bagian. Semua `fetch` (`twopockets`, `links`, `ai/sambungan`) punya `AbortController` + timeout 20 dtk.

## Temuan baru PART 2B-2 (semua LOW, tidak ada HIGH/MEDIUM baru)
| No | Lokasi | Temuan | Prioritas | Bukti |
|---|---|---|---|---|
| 2B-3 | `lembar-ui.js` ~354-366 (`hdTick`) | Loop `requestAnimationFrame` seret-pilih hanya berhenti di `hdEnd` (jari diangkat). Bila lembar ditutup di tengah seret, loop bisa berjalan sampai ada `pointerup`/`pointercancel`. Kemungkinan jarang. | LOW | Statis. BELUM TERVERIFIKASI di HP. |
| 2B-4 | `worker.mjs` `chat`/`research` | Jatah harian dihitung SEKALI sebelum memanggil penyedia, jadi permintaan yang gagal di semua jalur tetap memakai jatah. Sengaja ("sekali per permintaan"), tetapi pengguna bisa kehilangan jatah saat penyedia sedang bermasalah. | LOW | Statis. Tidak perlu diubah kecuali mengganggu. |
| 2B-5 | `worker.mjs` | Penghitung KV tidak atomik (sudah dicatat di komentar kodenya); cukup untuk dua orang tepercaya. | LOW (diterima) | Statis. |

Dugaan 2A-4, 2A-5, 3-1 tidak berubah (belum diukur di HP).

## Status temuan (ringkas, untuk PART 9)
- **Masuk rencana akhir (disetujui):** 4-1, 4-2.
- **Ditutup oleh keputusan pengguna:** 3-1 (bintang tetap), 3-2 (`--card` dibiarkan), 4-4 (cadangan lama tidak dihapus), 4-5 (privat tidak dienkripsi), secret rilis (alias `notes-kelimaa`, password kunci = password keystore).
- **Masih perlu keputusan di PART 9:** 4-3 (salinan otomatis sebelum Pulihkan), 4-6 (pengukur ukuran data + peringatan dini), 2A-1 (sudah tercakup 4-1), 2A-4 (`upd` ganda per `selectionchange`; ukur dulu), lockfile + `npm ci`, perbaikan `build-release.yml` (A8: tanpa `npm test`, `networkTimeout`, versi actions), sinkron versionCode debug/rilis.
- **Kandidat CLEANUP (belum disetujui):** `tools/audit_lainnya.py`, `audit_sumber.py`, `audit_validasi.py`, `audit_warna.py`, `ukur_startup.py`; `rev249b` belum masuk `npm test`; `.fbar .numfmt` dan variabel `--tl`, `--r-lg`, `--tile-min`.

## CHECKPOINT NOTES KELIMAA (PART 2B-2)
- **PART selesai:** 1, 2A, 2B-1, 2B-2 (sebagian, lihat cakupan), 3, 4, 5 dan 6 sebagian.
- **File diperiksa:** lihat "Cakupan PART 2B-2".
- **File belum diperiksa isinya:** badan `lembar-ui.js`, `settings.js`, `export.js`, `share.js`, `ai/konteks.js`, `twopockets.js`, sisa `ai/aksi.js`/`ai/ruang.js`, `file_paths.xml`, `colors.xml`, splash drawable, `assets/capacitor.config.json`.
- **Temuan penting:** tidak ada HIGH baru; 4-1 dan 4-2 disetujui.
- **Risiko:** tes `rev*` yang mengunci startup (4-1) dan `replaceData` (4-2) harus dijalankan penuh setelah perbaikan; workflow tidak bisa diuji di sini.
- **Keputusan dibutuhkan:** tidak ada yang memblokir. Opsional: 4-3 dan 4-6 mau masuk rencana atau tidak (dibahas di PART 9).
- **PART berikutnya:** PART 7 (keamanan, keandalan, integritas data: konsolidasi), PART 8 (audit silang), PART 9 (tabel rencana optimasi akhir CRITICAL/HIGH/MEDIUM/LOW/CLEANUP).

---

# PEMBARUAN 9: PART 7 SELESAI (Keamanan, keandalan, integritas data: konsolidasi) (14 Nov 2026)

**Tidak ada kode yang diubah.** Semua diperiksa statis di salinan sementara; tidak ada uji HP.

## Cakupan jujur
PART 7 = konsolidasi temuan PART 2A/2B/4/5 + pemeriksaan baru: `security.js` (baca), `privat.js` (pemakaian kunci sementara PIN), `grep` seluruh `src/js` untuk `console.*`, `window.open`/`_blank`/`location.*`, `storage.js` (`load`/`save`), `logic.js` (`replaceData`), semua pemanggil `cleanupOrphanImages`, dan `apply-native.mjs` (kode alarm: `hashCode`, `PendingIntent`, penerima). **Belum dibaca:** isi lengkap `ReminderReceiver`/`BootReceiver` (hanya dipindai), `ai/konteks.js`, badan `settings.js`.

## Terverifikasi baik
1. Tidak ada `console.log/info/debug` di `src/js`; hanya `console.error` pada jalur galat.
2. Satu-satunya pembuka tautan luar: `links.js:48` memakai `window.open(url,'_blank','noopener')`; tidak ada `location.href/assign`.
3. PIN: 4-6 angka, PBKDF2-SHA256 100.000 iterasi, salt acak 16 byte; kunci sementara tiap 5 salah (30 dtk, berlipat, maks 15 menit). Sesuai catatan 4-5 (pagar tampilan, privat tidak dienkripsi; keputusan pengguna dipertahankan).
4. Alarm native: `PendingIntent` memakai `FLAG_IMMUTABLE`; izin notifikasi dicek di Android 13+; `exported` diatur eksplisit untuk Activity.

## Penyempurnaan rencana 4-1 (BARU, hasil PART 7)
`cleanupOrphanImages` dipanggil dari **TIGA tempat**, bukan satu: `main.js:452` (tiap buka), `main.js:473` (setelah `purgeTrash` otomatis), `settings.js:95` (setelah ubah hari sampah). Penjaga hanya di `main.js:452` akan menyisakan dua jalur. **Rekomendasi:** letakkan penjaga SATU kali di dalam `cleanupOrphanImages` (`gambar-app.js:119`), yang kembali tanpa menghapus bila `load()` pernah gagal pada sesi ini. Tes: `load()` gagal -> tidak ada berkas gambar yang dihapus dari ketiga jalur. Catatan: `clearUnusedImages` (tombol manual di Setelan) adalah aksi pengguna; pertimbangkan penjaga yang sama atau peringatan. Perlu keputusan di PART 9.
Perbaikan 4-2 dikonfirmasi lagi: `replaceData` (`logic.js:242`) menyalin `habits, tasks, notes, priv, trash, settings, sheets, projects` dan TIDAK `habitLog`. Satu baris mengikuti pola `projects`.

## Daftar keandalan/keamanan terkonsolidasi
| No | Lokasi | Temuan | Jenis | Prioritas | Status |
|---|---|---|---|---|---|
| 4-1 | `storage.js:93-101`, `gambar-app.js:119`, 3 pemanggil | Gagal-muat berantai: gambar >24 jam dihapus permanen + data utama tertimpa; `_rusak` tak pernah dibaca | Data | HIGH (peluang rendah) | DISETUJUI, masuk rencana (penjaga di dalam `cleanupOrphanImages`) |
| 4-2 | `logic.js:242` | `habitLog` tidak ikut Pulihkan (diuji Node) | Integritas | MEDIUM | DISETUJUI |
| 4-6 | `storage.js`, `lembar.js:12` | Satu kunci localStorage, tanpa pengukur ukuran/peringatan dini | Keandalan jangka panjang | HIGH (jangka panjang) | Keputusan PART 9 |
| 4-3 | `settings.js` Pulihkan | Tidak ada salinan otomatis data saat ini sebelum diganti | Data | MEDIUM | Keputusan PART 9 |
| 2A-8/4-7 | `storage.js` `normalize` | Kunci tak dikenal (data versi lebih baru) hilang pada simpanan berikutnya | Kompatibilitas | LOW | Catatan |
| 7-1 | `storage.js:96` `console.error('load gagal:', err)` | Pesan galat `JSON.parse` di V8 modern dapat memuat potongan teks data yang rusak; bila WebView meneruskan console ke logcat, potongan catatan (termasuk privat) bisa muncul di log | Privasi | LOW | **BELUM TERVERIFIKASI** (perilaku V8/Capacitor di HP). Bila diperbaiki: log hanya `err.name`, bukan pesan lengkap |
| 7-2 | `ReminderScheduler` | Kode permintaan alarm dan id notifikasi = `id.hashCode()`; tabrakan hash teoritis; tidak ada penerima perubahan izin alarm tepat (A4/A5) | Keandalan | LOW | Statis |
| 7-3 | `MainActivity` | A1 (killProcess 1,2 dtk setelah Keluar) masih BELUM TERVERIFIKASI; persist sinkron sudah dipanggil sebelum kill | Data | LOW-MEDIUM | Uji HP sederhana: ketik, Keluar, buka lagi |
| 7-4 | Pengaturan kunci PIN | Penghitung kunci sementara memakai `Date.now()` dan tersimpan di data yang sama (bisa dilewati lewat jam/pulihkan cadangan) | Keamanan | LOW (diterima; terkait 4-5) | Keputusan pengguna dipertahankan |
| 2B-1 | `index.html` | Tidak ada CSP; pertahanan utama sudah kuat | Keamanan berlapis | LOW | Tidak disarankan tanpa uji HP |
| A3 | `MainActivity` | Jembatan JS native; hanya konten lokal + iframe tanpa skrip | Keamanan | LOW | Sisi Capacitor BELUM TERVERIFIKASI |

## CHECKPOINT NOTES KELIMAA (PART 7)
- **PART selesai:** 1, 2A, 2B-1, 2B-2 (sebagian), 3, 4, 5 dan 6 sebagian, 7.
- **File belum diperiksa isinya:** badan `lembar-ui.js`, `settings.js`, `export.js`, `share.js`, `ai/konteks.js`, `twopockets.js`, isi penuh penerima alarm Java, `file_paths.xml`, `colors.xml`, splash drawable.
- **Temuan penting baru:** penyempurnaan 4-1 (tiga pemanggil, penjaga satu titik); 7-1 (LOW, belum terverifikasi).
- **Risiko:** penjaga di `cleanupOrphanImages` menyentuh `gambar-app.js` + tes `gambar.test` dan tes startup `rev*`; harus dijalankan penuh.
- **Keputusan dibutuhkan (untuk PART 9):** 4-3 dan 4-6 masuk rencana atau tidak; `clearUnusedImages` ikut dijaga atau tidak.
- **PART berikutnya:** PART 8 (audit silang antar berkas: tes vs kode, docs vs kode, workflow vs script), lalu PART 9.

---

# PEMBARUAN 10: PART 8 SELESAI (Audit silang antar berkas) (14 Nov 2026)

**Tidak ada kode yang diubah.** Semua dijalankan di salinan sementara. Jenis bukti: diperiksa statis + dijalankan di Node sandbox (BUKAN HP).

## Cakupan jujur
Dicek silang: (1) `package.json` skrip `npm test` vs isi `tests/`; (2) metode jembatan Java (`apply-native.mjs`) vs pemanggil JS; (3) klaim README/RIWAYAT (jumlah tes, anggaran JS, jumlah templat, versi) vs kenyataan; (4) kunci data yang dipakai kode vs `normalize()`; (5) rujukan `ukur-performa.yml` vs `tools/`. **Tidak bisa dicek di sini:** kedua workflow build (`build-apk-dari-zip.yml`, `build-release.yml`) tidak ada di ZIP versi ini (hanya dibaca pada sesi sebelumnya), jadi kecocokannya dengan `scripts/` hanya berdasar catatan Pembaruan 2; `AndroidManifest`/Gradle hasil generate hanya dari artifact sebelumnya.

## Terverifikasi cocok
1. **`npm test` vs `tests/`:** 280 berkas terdaftar, 281 ada, tanpa duplikat, tanpa rujukan ke berkas yang tak ada. Satu-satunya yang tidak terdaftar: `rev249b.test.mjs`.
2. **Jembatan JS-Java:** 12 metode `@JavascriptInterface` (`scheduleNotification`, `cancelScheduledNotification`, `cancelAllScheduledNotifications`, `canScheduleExactAlarms`, `openExactAlarmSettings`, `requestNotificationPermission`, `takeReminder`, `takeShared`, `exit`, `setBars`, `setBarEdges`, `openUrl`) masing-masing dipakai minimal satu modul JS. Tidak ada pemanggilan JS ke metode yang tak ada di Java.
3. **Anggaran:** JS 1208,7 KB (hitung 1024) dari batas 1230 KB di `tools/audit-ukuran.mjs`; sisa ±21 KB. Cocok dengan klaim ±1211 KB. Jumlah templat di kode = 30, cocok dengan README/RIWAYAT Rev 293.
4. **Kunci data:** kunci tingkat atas yang dipakai kode (`notes, settings, sheets, tasks, trash, projects, priv, habits, habitLog`) semuanya ditangani `normalize()`. SCHEMA = 21 cocok dengan dokumen.
5. **`ukur-performa.yml`:** semua `tools/*` yang dirujuk ada (`audit-ukuran.mjs`, `ukur_node.mjs`, `buat_data.mjs`, `ukur_performa.py`).
6. **`rev249b.test.mjs` dijalankan sendiri: exit 0, 5 lulus, 0 gagal.** Jadi tes itu sah dan lulus, hanya belum didaftarkan di `npm test`.

## Temuan PART 8
| No | Lokasi | Temuan | Jenis | Prioritas | Bukti |
|---|---|---|---|---|---|
| 8-1 | `package.json` `test` | `rev249b` (menguji `worker.mjs` jalur riset tanpa web) tidak ikut `npm test`, sehingga regresi di fitur itu tidak tertangkap otomatis. Tidak disebut di README/PROMPT/RIWAYAT (0 rujukan), jadi tampak terlewat, bukan sengaja. | Jaring pengaman | MEDIUM-LOW | Terverifikasi (dijalankan, lulus 5/5). Perbaikan: daftarkan di skrip `npm test`; risiko sangat rendah. |
| 8-2 | `README.md:32` | Klaim "1885 butir `ok`" sudah usang; RIWAYAT Rev 291 mencatat 1957 dan jalan saya ±1960 (hitungan kasar `grep`, bukan angka resmi). | Dokumen | LOW | Terverifikasi (selisih angka). |
| 8-3 | `README.md` baris riwayat (±36-38) | Daftar bernomor diawali `0000000000.` (artefak penomoran), tampil janggal. Murni kosmetik. | Dokumen | CLEANUP | Terverifikasi (`cat -A`). |
| 8-4 | Anggaran JS | Sisa ruang hanya ±21 KB (1,7%) dari batas 1230 KB; batas sudah dinaikkan 4 kali (1024 -> 1100 -> 1150 -> 1164 -> 1230) atas izin pengguna. Perbaikan 4-1/4-2 dan penjaga kecil muat, tetapi fitur besar berikutnya akan menabrak batas lagi. | Pemeliharaan | LOW | Terverifikasi (hitung). Bukan masalah runtime; 486 KB sudah dimuat malas. |

Tidak ada ketidakcocokan antara kode dan tes yang ditemukan pada pengecekan ini. Tidak ada temuan baru yang HIGH/CRITICAL.

## CHECKPOINT NOTES KELIMAA (PART 8)
- **PART selesai:** 1, 2A, 2B-1, 2B-2 (sebagian), 3, 4, 5 dan 6 sebagian, 7, 8.
- **File belum diperiksa isinya:** badan `lembar-ui.js`, `settings.js`, `export.js`, `share.js`, `ai/konteks.js`, `twopockets.js`, isi penuh penerima alarm Java, `file_paths.xml`, `colors.xml`, splash drawable; kedua workflow build tidak ada di ZIP ini.
- **Temuan penting baru:** 8-1 (rev249b belum masuk `npm test`, tes lulus).
- **Risiko:** menambah `rev249b` ke `npm test` tidak mengubah kode aplikasi; perbaikan dokumen aman.
- **Keputusan dibutuhkan:** untuk PART 9, minta pengguna mengirim ulang `build-apk-dari-zip.yml` dan `build-release.yml` agar rencana workflow (A8, versionCode, `npm ci`) bisa dicocokkan dengan berkas aktual, bukan catatan.
- **PART berikutnya:** PART 9 (tabel rencana optimasi akhir: No | Lokasi | Temuan | Dampak | Prioritas | Rekomendasi; kelompok CRITICAL/HIGH/MEDIUM/LOW/CLEANUP). Kode baru boleh diubah hanya setelah pengguna menyetujui rencana itu.

---

# PEMBARUAN 11: WORKFLOW AKTUAL DITERIMA + PART 9 (RENCANA OPTIMASI AKHIR, MENUNGGU PERSETUJUAN) (14 Nov 2026)

**Tidak ada kode dan tidak ada workflow yang diubah.** Ini RENCANA. Penerapan hanya setelah pengguna menyetujui butir per butir.

## A. Workflow aktual dibaca penuh (`build-apk-dari-zip.yml`, `build-release.yml`)
Cocok dengan catatan Pembaruan 2, ditambah rincian baru:
1. **Debug** (dipakai harian): checkout@v6, setup-node@v6, setup-java@v5, upload-artifact@v7, gradle/actions/setup-gradle@v6; cek ZIP (`unzip -tq`), cek 5 ikon notifikasi, `npm install`, `npm test`, `npm run build`, `cap add android`, naikkan `networkTimeout` 120000, `apply-icons` (memanggil `applyNative`), `cap sync`, tanda tangan tetap lewat blok `signingConfigs.tetap` (alias `notes-kelimaa`, password kunci = `KEYSTORE_PASSWORD`; dilewati bila secret kosong), `assembleDebug` dengan 4 percobaan. **Tidak mengatur versionCode/versionName** (tetap 1 / "1.0").
2. **Rilis:** checkout@v4, setup-node@v4, setup-java@v4, upload-artifact@v4; `npm install`, `npm run build`, `cap add android`, `apply-icons`, `cap sync`; `sed` versionCode = `github.run_number` dan versionName dari `package.json`; `assembleRelease --no-daemon` (satu kali, tanpa retry, tanpa `networkTimeout`, tanpa cache Gradle); `zipalign -p 4` + `apksigner` dengan `KEY_ALIAS`/`KEY_PASSWORD`; `timeout-minutes: 40`. **Tanpa `npm test`, tanpa cek ikon.**
3. **Logika mencari proyek berbeda** antar workflow: debug mengekstrak `catatan-app.zip` ke folder sementara dan menyalin tanpa `.github/`, `node_modules/`, `android/`; rilis hanya mengekstrak bila tak ada `capacitor.config.json` lain di repo (kedalaman 3), lalu memakai berkas pertama yang ditemukan. Bila repo suatu hari punya proyek terbuka di akar, rilis bisa membangun sumber berbeda dari ZIP. **Terverifikasi dari teks; belum pernah dialami.**
4. Urutan `apply-icons` -> `applyNative` sama di keduanya, jadi MainActivity/izin/ReminderScheduler identik di debug dan rilis (terverifikasi dari teks).

## B. Temuan workflow baru (bukti: teks workflow + pencarian web, BUKAN dijalankan)
| No | Lokasi | Temuan | Prioritas |
|---|---|---|---|
| W-1 | `build-release.yml` actions `@v4` | Aksi v4 berbasis Node 20. Changelog resmi GitHub (catatan editor 25 Agu 2026): runner memakai Node 24 sebagai bawaan sejak 16 Jun 2026, dan Node 20 dihapus dari runner pada **23 Sep 2026**, sudah lewat per 14 Nov 2026. Apakah aksi v4 masih berjalan sekarang **BELUM TERVERIFIKASI** (tidak dijalankan). Workflow debug sudah memakai versi lebih baru (v6/v5/v7) dan dipakai harian. | **HIGH untuk rilis** (risiko build rilis gagal saat dibutuhkan) |
| W-2 | versionCode debug = 1 vs rilis = `run_number` | `run_number` dihitung PER workflow, jadi tidak bisa dipakai bersama. Setelah APK rilis (versionCode N) terpasang, APK debug (versionCode 1) ditolak Android sebagai downgrade; jalan keluarnya hapus aplikasi = **data lokal hilang**. Sebaliknya, rilis lama bisa lebih kecil dari debug bila debug kelak diberi `run_number`. | **HIGH** (data pengguna) |
| W-3 | rilis | Tanpa `npm test`, tanpa cek ikon, tanpa `networkTimeout`/retry/cache | MEDIUM |
| W-4 | kedua | `npm install` dengan `^8.0.0` tanpa lockfile di ZIP; versi bisa naik sendiri (saat ini 8.6.2 dari lockfile artifact) | MEDIUM |
| W-5 | rilis | `echo "$KEYSTORE_BASE64" \| base64 -d` tanpa pembersihan spasi/baris baru (debug memakai `tr -d ' \r\n'`) | LOW |
| W-6 | kedua | Logika mencari proyek berbeda (lihat A.3) | LOW |

## C. PART 9: TABEL RENCANA OPTIMASI AKHIR
Dampak ditulis jujur: "data" = melindungi data pengguna; "build" = keandalan build; angka kecepatan/RAM **tidak dijanjikan** karena belum diukur di HP.

### CRITICAL
Tidak ada temuan yang terbukti CRITICAL. (4-1 diperlakukan HIGH karena tidak pernah terpicu; dampaknya berat.)

### HIGH
| No | Lokasi | Temuan | Dampak | Prioritas | Rekomendasi |
|---|---|---|---|---|---|
| 4-1 | `gambar-app.js:119` (+ `storage.js:93-101`, `main.js`) | Gagal-muat berantai: gambar >24 jam dihapus permanen + data utama tertimpa + `_rusak` ditimpa | Data tak bisa dipulihkan | HIGH | **DISETUJUI.** (a) `storage.js` mencatat `loadFailed` (fungsi baca); (b) penjaga SATU titik di awal `cleanupOrphanImages`: bila `loadFailed` sesi ini, kembali tanpa menghapus. Pemanggil di `main.js:452/473` dan `settings.js:95` tidak berubah, sehingga tes `g3`/`rev191`/`rev203` yang mengunci string `cleanupOrphanImages(data)` tetap lulus; (c) `load()` tidak menimpa `_rusak` bila sudah ada + satu toast singkat. Tes baru: simulasi `load()` gagal -> tidak ada gambar terhapus. |
| W-2 | `build-apk-dari-zip.yml` + `build-release.yml` | versionCode tidak sinkron (debug 1, rilis `run_number`) | Risiko hapus-pasang = data hilang | HIGH | Beri KEDUA workflow versionCode yang sama-sama naik: menit sejak 1 Jan 2026 UTC, `$(( ($(date -u +%s) - 1767225600) / 60 ))` (hari ini ±456.835; jauh di bawah batas 2,1 miliar; naik terus; lebih besar dari 1 dan dari `run_number` lama, jadi aman untuk upgrade dari kedua arah). versionName dari `package.json` di keduanya. Tambahkan langkah `sed` seperti di rilis ke workflow debug. **Tidak bisa diuji di sini.** Catatan: setelah dipakai, jangan kembali ke `run_number`. |
| W-1 | `build-release.yml` | Aksi v4 (Node 20; Node 20 sudah dihapus dari runner per changelog) | Rilis bisa gagal | HIGH (rilis) | Samakan versi dengan workflow debug yang terbukti berjalan (checkout@v6, setup-node@v6, setup-java@v5, upload-artifact@v7). Uji dengan satu kali jalan manual SEBELUM dipakai sebagai rilis. |
| 4-6 | `storage.js`, `lembar.js:12` | Satu kunci localStorage; tanpa pengukur ukuran/peringatan dini; kuota WebView ±5 MB BELUM TERVERIFIKASI | Data jangka panjang | HIGH (jangka panjang) | **Keputusan pengguna.** Usulan ringan tanpa ganti sistem: pengukur ukuran data + toast peringatan dini saat mendekati ambang. IndexedDB TIDAK direkomendasikan sekarang (lihat Pembaruan 4). |

### MEDIUM
| No | Lokasi | Temuan | Dampak | Rekomendasi |
|---|---|---|---|---|
| 4-2 | `logic.js:242` `replaceData` | `habitLog` tidak ikut Pulihkan (diuji Node) | Integritas data | **DISETUJUI.** Satu baris mengikuti pola `projects` (cadangan lama tanpa `habitLog` = `cleanHabitLog` nilai kosong sah). Tes: `replaceData` dengan sumber berisi `habitLog`. |
| 4-3 | `settings.js` Pulihkan | Tidak ada salinan otomatis data sekarang sebelum diganti | Data | Keputusan pengguna. Usulan: tulis cadangan otomatis (mekanisme `backup.js` yang ada) sebelum `replaceData`. |
| W-3 | `build-release.yml` | Tanpa `npm test`, cek ikon, `networkTimeout`, retry | Build rilis | Samakan dengan debug: tambah `npm test`, cek ikon, `networkTimeout=120000`, retry 4 kali, cache Gradle. |
| W-4 | kedua workflow | Tanpa lockfile | Build tidak deterministik | Simpan `package-lock.json` (lockfileVersion 3, Capacitor 8.6.2 dari artifact) ke repo/ZIP dan ganti `npm install` dengan `npm ci` di KEDUA workflow. Lockfile dari artifact cocok dengan build yang berjalan. |
| 8-1 | `package.json` `test` | `rev249b` lulus 5/5 tapi tidak ikut `npm test` | Jaring pengaman | Daftarkan di skrip `test`. |
| 2A-4 | `notes.js:2531-2533` | `upd` jalan dua kali per `selectionchange` | CPU saat mengetik (belum diukur) | **Tunda sampai diukur di HP.** Bila dikerjakan: hapus pendaftaran langsung, wajib uji editor penuh. |

### LOW
| No | Lokasi | Temuan | Rekomendasi |
|---|---|---|---|
| 7-1 | `storage.js:96` | `console.error` memuat pesan `JSON.parse` yang mungkin berisi potongan data | Log hanya `err.name`. Belum terverifikasi di HP. Boleh digabung dengan 4-1 (file yang sama). |
| 7-2/A4/A5 | `ReminderScheduler` | `hashCode()` sebagai kode alarm; tak ada penerima perubahan izin alarm | Catat; tidak diubah tanpa uji HP. |
| 7-3/A1 | `closeAppTotal` | Data hilang saat Keluar BELUM terbukti | Uji HP: ketik, Keluar, buka lagi. |
| 2B-3 | `lembar-ui.js` `hdTick` | Loop rAF bisa lanjut bila lembar ditutup saat seret | Catat. |
| 8-2 | `README.md:32` | Jumlah tes usang (1885 vs ±1960) | Perbarui dokumen saat final. |
| 2B-1, A3 | `index.html`, jembatan native | Tanpa CSP; jembatan hanya konten lokal | Tidak disarankan tanpa uji HP. |
| W-5, W-6 | workflow | `base64 -d` tanpa `tr`; logika cari proyek berbeda | Samakan dengan debug (`tr -d ' \r\n'`; satu cara ekstrak). |
| 8-4 | anggaran JS | Sisa ±21 KB dari 1230 KB | Perbaikan 4-1/4-2/7-1 muat; pantau. |
| 2A-8/4-7 | `normalize` | Kunci tak dikenal hilang pada simpanan berikutnya (data versi lebih baru) | Catat. |

### CLEANUP (boleh ditunda; paket terakhir)
| No | Berkas | Catatan |
|---|---|---|
| 3-4 | `.fbar .numfmt`, `--tl`, `--r-lg`, `--tile-min` | `numfmt` dikunci tes `daftar` dan `rev247`; hapus hanya bersama penyesuaian tes. |
| 3-3 | `styles.css` | 139 selektor ganda; jangan digabung tanpa tes tampilan. |
| 1 | `tools/audit_lainnya.py`, `audit_sumber.py`, `audit_validasi.py`, `audit_warna.py`, `ukur_startup.py` | Tidak dirujuk apa pun; bukan bagian APK. Disarankan DIPERTAHANKAN kecuali diminta (hemat tak berarti). |
| 8-3 | `README.md` | Penomoran `0000000000.` di daftar riwayat (kosmetik). |
| docs | `RIWAYAT.md` (802 KB), `PROMPT_SERAH_TERIMA.md` (658 KB) | Jangan dihapus; opsi arsip entri lama + ringkasan. |

### Sudah ditutup keputusan pengguna (tidak masuk rencana)
3-1 bintang tetap; 3-2 `--card` dibiarkan; 4-4 cadangan lama tidak dihapus; 4-5 privat tidak dienkripsi; secret rilis (alias `notes-kelimaa`, password kunci = password keystore).

## D. Urutan penerapan yang diusulkan (setelah disetujui)
1. **Paket Data (kode):** 4-1 + 7-1, lalu 4-2, lalu (opsional) 4-3 dan 4-6. Jalankan `npm test` penuh setelah tiap butir; tes baru untuk 4-1 dan 4-2.
2. **Paket Tes:** daftarkan `rev249b` di `npm test`.
3. **Paket Workflow (tidak bisa diuji di sini):** W-2 (versionCode), W-1/W-3 (samakan rilis dengan debug), W-4 (lockfile + `npm ci`), W-5. Diberikan sebagai berkas workflow baru/diubah; pengguna menjalankan sekali manual dan melaporkan hasilnya.
4. **Paket Dokumen/Cleanup:** README, catatan UJI_HP_RILIS (uji HP untuk 4-1/4-2/Keluar).
5. Hasil akhir sesuai permintaan pengguna: ZIP hasil optimasi, daftar berkas diubah/baru/dihapus, penjelasan teknis, perbandingan sebelum-sesudah, hasil uji (dibedakan: statis / `npm test` / build / HP), catatan kompatibilitas, risiko tersisa, rekomendasi pemeliharaan. Struktur ZIP tetap lengkap (`src`, `scripts`, `resources`, `backend`, `tests`, `tools`, konfigurasi).

## E. Batas yang harus tetap jujur
- Tidak ada pengukuran di HP untuk apa pun; rencana ini TIDAK menjanjikan aplikasi lebih cepat atau lebih hemat RAM. Nilai terbesarnya = keselamatan data (4-1, 4-2, W-2) dan keandalan build (W-1, W-3, W-4).
- Workflow tidak bisa dijalankan di sini; perubahan W-* hanya diperiksa statis.
- Kompatibilitas data lama dijaga: tidak ada perubahan SCHEMA, tidak ada ganti sistem penyimpanan.

## CHECKPOINT NOTES KELIMAA (PART 9)
- **PART selesai:** 1-9 (PART 2B tidak penuh, lihat daftar belum diperiksa; PART 5/6 kini mencakup workflow aktual).
- **File belum diperiksa isinya:** badan `lembar-ui.js`, `settings.js`, `export.js`, `share.js`, `ai/konteks.js`, `twopockets.js`, isi penuh penerima alarm Java, `file_paths.xml`, `colors.xml`, splash drawable.
- **Keputusan dibutuhkan (menunggu pengguna):**
  1. Setujui paket 1 (4-1+7-1, 4-2), paket 2 (rev249b), paket 3 (workflow: W-2, W-1, W-3, W-4, W-5)?
  2. 4-3 (salinan otomatis sebelum Pulihkan): masuk atau tidak?
  3. 4-6 (pengukur ukuran data + peringatan dini): masuk atau tidak?
  4. W-2: pengguna sudah pernah memasang APK rilis di HP yang sama dengan APK debug? (menentukan apakah ada versionCode lama yang lebih besar dari nilai berbasis waktu; nilai usulan ±456.835 hampir pasti lebih besar dari `run_number` biasa.)
  5. `clearUnusedImages` manual ikut dijaga atau tidak (usulan: ikut dijaga).
- **PART berikutnya:** setelah persetujuan, penerapan Paket 1 (kode), lalu Paket 2, lalu Paket 3.

---

# PEMBARUAN 12: PAKET DATA DITERAPKAN = Rev 295 (14 Nov 2026)

Pengguna: "langsung lanjut next step update". Workflow yang diunggah ulang sudah berkomentar Rev 294 (versionCode menit sejak 1 Jan 2026 UTC, cek ikon, `npm test`, `networkTimeout`, cache Gradle, retry, aksi v6/v5/v7 di KEDUA workflow; debug memakai `npm ci` bila ada lockfile; rilis masih `npm install`). Zip dasar tetap Rev 293 (tanpa `package-lock.json`).

**Diterapkan (kode):** 4-1 (penanda `wasLoadFailure`, `_rusak` tidak ditimpa, penjaga satu titik di `cleanupOrphanImages` + `clearUnusedImages`, toast), 7-1 (log hanya `err.name`), 4-2 (`habitLog` di `replaceData`), 8-1 (`rev249b` masuk `npm test`). Tes baru `rev295` (6). Batas JS buka 740000 -> 741500 (rev193/194/284/290).
**Bukti:** `npm test` exit 0 (282 berkas, 1969 baris ok, 0 gagal), `npm run build` berhasil, audit-ukuran "aman". Ini BUKAN uji HP dan bukan bukti APK terbangun.
**Belum dikerjakan:** 4-3, 4-6 (menunggu keputusan pengguna); lockfile + `npm ci` di workflow rilis (butuh `package-lock.json` di repo/ZIP; berkasnya ada di artifact `berkas-android-audit.zip`); 2A-4; CLEANUP.
**Berikutnya:** Rev 296 = keputusan 4-3 dan 4-6, lalu paket dokumen/cleanup.
