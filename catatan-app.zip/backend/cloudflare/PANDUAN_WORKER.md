# Panduan memasang Worker Kelimaa AI (kerangka + aksi chat, research, ocr, dan sync; terbaru Rev 418)

Awalnya (Rev 200) Worker hanya menjawab "ping", mengenali siapa yang masuk lewat passcode, dan menghitung batas pemakaian. Sejak Rev 202 ia juga memanggil penyedia AI (aksi `chat`), lalu `research` (Rev 231) dan `ocr` (Rev 352); bagian di bawah menjelaskan masing-masing.

**Aturan keras:** passcode dan API Key diketik SENDIRI di dasbor Cloudflare. JANGAN dikirim ke chat, JANGAN ditulis di repo, zip, atau catatan. Bila pernah tertempel di mana pun, anggap bocor dan buat ulang.

Nama menu di dasbor Cloudflare bisa sedikit berbeda dari tulisan di sini. Yang sudah dicek di dokumentasi resmi (11 Nov 2026): alur Workers & Pages > Create > Hello World > Deploy > Edit code, jenis variabel Secret, dan binding KV. Letak tepat menu Settings dan Variables belum dicek di layar HP.

## 1. Buat Worker (dari browser HP, boleh mode "Situs desktop")
1. Masuk dasbor Cloudflare, buka **Workers & Pages**.
2. **Create** > **Hello World** (atau Create Worker). Beri nama, mis. `kelimaa-ai`. Tekan **Deploy**.
3. Buka **Edit code**. Hapus isi bawaan, tempel SELURUH isi `worker.mjs`, tekan **Deploy**.
4. Salin alamat `https://kelimaa-ai.<akun>.workers.dev` (alamat ini tidak rahasia).

## 2. Isi passcode (Secret)
Di Worker: **Settings** > **Variables and Secrets** > tambah, jenis **Secret**:
- `PASS_RAMA` = passcode Ram
- `PASS_DESY` = passcode Desy

Minimal 8 karakter, disarankan 12 atau lebih dan acak. Nama setelah `PASS_` (huruf besar/angka) menjadi nama orangnya; menambah orang = menambah satu Secret. Setelah menyimpan, Deploy lagi bila diminta.

## 3. (Disarankan) Penghitung pemakaian dan pembatas percobaan salah: KV
1. Buka **Workers KV** > **Create instance** (namespace), nama bebas, mis. `kelimaa_ai_kv`.
2. Di Worker: **Bindings** > tambah **KV namespace**; nama variabel HARUS `KV`, pilih namespace tadi. Deploy.
3. Opsional: variabel teks `DAILY_LIMIT` (bawaan 100 permintaan per orang per hari, hari menurut WIB). Sejak Rev 209 batas ini hanya cadangan: yang dipakai adalah pilihan di aplikasi (Setelan > Kelimaa AI > Batas harian: 100, 150, 200, atau Tanpa batas).

Tanpa KV, ping dan whoami tetap jalan, tetapi tidak ada pembatas percobaan salah dan tidak ada penghitung harian (permintaan AI nanti akan DITOLAK tanpa KV, demi aman). Paket gratis KV: 1.000 penulisan per hari; hitungan ini kecil dan cukup untuk dua orang. KV tidak atomik dan menyebar sampai sekitar satu menit, jadi hitungan berupa perkiraan.

## 4. Uji
- Buka di browser: `https://kelimaa-ai.<akun>.workers.dev/?ping=1`. Harus tampil `{"ok":true,"app":"KELIMAA AI","v":1}`.
- Uji passcode: belum ada layar di aplikasi (Rev 201). Bila mau uji dari luar aplikasi, pakai alat kirim POST dengan isi `{"key":"<passcode>","action":"whoami"}`. Jawaban benar: `{"ok":true,...,"me":"rama"}`.

## 5. Yang sengaja BELUM ada
Provider kedua dan seterusnya, pemilihan model otomatis, riwayat, aksi ke Catatan/Tugas, dan layar chat di aplikasi (Rev 201 hanya layar sambungan). Semuanya mengikuti `PROMPT_SERAH_TERIMA.md` bagian 27.


## 6. (Rev 202c) Pasang kunci penyedia supaya aksi `chat` hidup
Ada TIGA jalur (keputusan pengguna, 11 Nov 2026): **Sakelar**, **Relay Router**, **Gemini Google**. Jalur Anthropic langsung sudah DIHAPUS. Cukup pasang kunci jalur yang dipakai. Aplikasi di HP belum memanggil `chat` (layarnya Rev 202b), jadi langkah ini aman dilewati dulu.
Semua kunci diketik/ditempel SENDIRI di dasbor Cloudflare (**Settings** > **Variables and Secrets** > **Add** > jenis **Secret**), JANGAN ke chat. Lalu tempel ulang `worker.mjs` TERBARU di **Edit code** dan **Deploy**.

| Jalur | Nama Secret | Variabel teks model | Model bawaan |
|---|---|---|---|
| Sakelar | `SAKELAR_KEY` | `MODEL_SAKELAR` | `deepseek/deepseek-v4-flash` (slug lain dari katalog Sakelar, mis. `anthropic/haiku-5.5`) |
| Relay Router | `RELAY_KEY` | `MODEL_RELAY` | TIDAK ada: WAJIB diisi (nama model belum diketahui) |
| Gemini Google | `GEMINI_KEY` | `MODEL_GEMINI` | `gemini-3.5-flash` (kunci dari Google AI Studio) |

Opsional: `CHAT_PROVIDER` = `sakelar`, `relay`, atau `gemini` untuk memilih jalur; kosong = yang pertama punya kunci (urutan sakelar, relay, gemini).
`chat` WAJIB KV (langkah 3). Tiap chat memakai 1 dari batas harian per orang (`DAILY_LIMIT`), termasuk bila penyedia lalu gagal.
Status verifikasi (11 Nov 2026): alamat dan format Gemini (`https://generativelanguage.googleapis.com/v1beta/openai/chat/completions`, header `Authorization: Bearer`) DIVERIFIKASI dari dokumentasi resmi Google. Sakelar (`https://api.sakelar.web.id/v1/chat/completions`) dan Relay Router (`https://api.relayrouter.ai/v1/chat/completions`) BELUM terverifikasi: dokumentasinya tidak terjangkau; format OpenAI hanya anggapan dari pengumuman mereka. Uji nyata pertama di HP yang membuktikannya.

## 7. (Rev 209) Pilih jalur, model, dan batas dari aplikasi
Di Setelan > Kelimaa AI ada tiga pilihan, tersimpan di HP dan ikut dikirim tiap chat:
- **Jalur**: Otomatis (Worker memilih), Sakelar, Relay, atau Gemini. Jalur yang dipilih harus punya Secret kuncinya di Worker, kalau tidak chat ditolak dengan pesan yang menyebut nama Secret-nya.
- **Model**: Bawaan Worker, salah satu dari daftar (Sakelar: `deepseek/deepseek-v4-flash`, `anthropic/haiku-5.5`; Gemini: `gemini-3.5-flash`, `gemini-3.5-flash-lite`), atau **Ketik manual** untuk nama model apa pun (3-81 karakter: huruf, angka, titik, garis miring, titik dua, minus). Relay Router tidak punya daftar karena nama modelnya belum diketahui: ketik manual, tidak perlu lagi mengisi `MODEL_RELAY`.
- **Batas harian**: 100, 150, 200, atau Tanpa batas. Dihitung per orang per hari (WIB). Tanpa batas tidak pernah memblokir dan tidak wajib KV (hitungan hanya informasi). Batas yang berlaku adalah yang dikirim aplikasi, jadi siapa pun yang punya passcode bisa mengubahnya; itu wajar untuk dua orang tepercaya, tetapi bukan pagar biaya yang kuat. Pagar sebenarnya = batas pemakaian/saldo di akun penyedia.
Tempel ulang `worker.mjs` TERBARU di **Edit code** lalu **Deploy** agar pilihan ini dikenali Worker.

## 8. (Rev 213a) Jalur cadangan otomatis
Bila Jalur di aplikasi = **Otomatis** dan jalur utama gagal (kunci ditolak, saldo habis, kelebihan beban, waktu habis, atau jawaban kosong), Worker mencoba jalur lain yang punya kunci (urutan Sakelar, Relay, Gemini). Jalur yang kamu pilih sendiri (Sakelar/Relay/Gemini) TIDAK pindah otomatis. Jatah harian tetap 1 per pesan. Relay hanya jadi cadangan bila `MODEL_RELAY` diisi. Tempel ulang `worker.mjs` TERBARU dan Deploy; APK tidak perlu diganti.

## 9. (Rev 213b) Rute per jenis pekerjaan
Worker kini mengenal jenis pekerjaan `chat.general`, `analysis.general`, `creative.general`, `utility.small`. Pada Jalur Otomatis tiap jenis punya urutan jalur sendiri (analisis: Gemini dulu; kreatif: Sakelar dulu; kecil: Gemini lite). Urutan bisa diubah tanpa APK baru lewat variabel TEKS (bukan Secret) `ROUTE_CHAT`, `ROUTE_ANALYSIS`, `ROUTE_CREATIVE`, `ROUTE_UTILITY`, isinya nama jalur dipisah koma, mis. `gemini,sakelar`. Aplikasi belum bisa memilih jenis pekerjaan (menunggu Rev 213c), jadi chat tetap berjalan seperti biasa. Tempel ulang `worker.mjs` dan Deploy.

## Aksi riset (Rev 231, Tahap 6a)
Worker kini punya aksi `research` (jawaban bersumber lewat Google Search grounding Gemini). Syarat: Secret `GEMINI_KEY` terpasang (jalur Sakelar dan Relay Router TIDAK dipakai karena alat pencariannya belum terverifikasi). Model bawaan `gemini-3.5-flash` (atau `MODEL_GEMINI`). Jatah harian dihitung 1 per permintaan, tetapi Google menagih Gemini 3 per kueri pencarian yang dijalankan model, jadi satu riset bisa memakai beberapa kueri; cek halaman harga resmi Google. Aplikasi belum memanggil aksi ini (menunggu Rev 232); menempel ulang `worker.mjs` sekarang aman dan tidak mengubah chat. Setelah menempel: Deploy.

**Rev 233 (Tahap 6c):** jawaban riset kini juga membawa `suggest` (Search Suggestions Google: `searchEntryPoint.renderedContent` apa adanya; > 16.000 huruf atau berisi skrip/bingkai = dibuang utuh). Google mewajibkan widget ini tampil di bawah jawaban bersumber. Worker BERUBAH: buka Cloudflare > Workers & Pages > Worker kamu > Edit code, tempel ulang seluruh isi `worker.mjs` dari zip ini, lalu Deploy. Tanpa tempel ulang, riset tetap jalan tetapi bilah meta menulis 'saran pencarian Google tidak dikembalikan'.

## Aksi baca teks dari foto (Rev 352, Paket OCR bagian O1)
Worker kini punya aksi `ocr`: satu foto (JPEG atau WebP, sudah dikecilkan oleh aplikasi, maksimal sekitar 420 KB) dikirim ke Gemini Google untuk dibaca teksnya. Syarat: Secret `GEMINI_KEY` terpasang (jalur lain tidak dipakai untuk gambar). Model bawaan `gemini-3.5-flash`; ganti tanpa APK lewat variabel TEKS `MODEL_OCR` (atau `MODEL_GEMINI`). Satu foto = 1 jatah harian dan ikut batas bulanan serta `HARD_DAILY_LIMIT`. Foto hanya lewat memori Worker selama satu permintaan, tidak disimpan di KV. Aplikasi BELUM memanggil aksi ini (menunggu bagian O3), jadi menempel ulang `worker.mjs` sekarang aman dan tidak mengubah chat atau riset; boleh ditunda sampai fitur Pindai teks jadi. Setelah menempel: Deploy. Perlu diketahui: foto tetap diproses oleh Google, dan kebijakan penggunaan data API Gemini (tingkat gratis vs berbayar) perlu kamu cek sendiri di ketentuan Google.

## Aksi sinkron catatan (Rev 418, Paket SY bagian SY1)
Worker kini punya aksi `sync` untuk menyamakan catatan BIASA antara HP dan laptop (nanti lewat versi web). Syarat: binding KV bernama `KV` sudah terpasang (bagian 3 di atas); tanpa KV aksi ini menjawab galat 503. Catatan Privat tidak pernah ikut, dan Worker menolaknya bila ada yang terkirim. Tiap orang (PASS_RAMA, PASS_DESY, ...) punya ruang sendiri. Sinkron TIDAK memakai jatah harian atau bulanan Kelimaa AI.

Aturan bila dua perangkat mengubah catatan yang sama sebelum sempat sinkron: yang `diubah paling baru` menang, dan versi yang kalah TIDAK dibuang, melainkan disimpan sebagai catatan baru berjudul "(judul) (konflik)". Hapus di satu sisi + ubah di sisi lain = catatan tetap hidup (ubah menang). Catatan yang dihapus ditandai dulu dan baru dibuang sungguhan setelah 180 hari.

Aplikasi BELUM memanggil aksi ini (menunggu bagian SY2 dan SY3), jadi menempel ulang `worker.mjs` sekarang aman tetapi belum terasa; boleh ditunda sampai fitur Sinkron muncul di aplikasi. Setelah menempel: Deploy. Batas yang perlu diketahui: KV tidak punya transaksi dan bisa terlambat sampai sekitar 1 menit antar lokasi, jadi dua perangkat yang menyinkron PERSIS bersamaan bisa saling menimpa catatan indeks (kiriman ulang memulihkannya). Versi web di laptop juga butuh alamat situsnya didaftarkan untuk CORS (bagian SY4, belum dikerjakan).

## Catatan pemandu
Urutan tahap bagi pengguna pemula dan status terkini dicatat di `PROMPT_SERAH_TERIMA.md` bagian 27.12 (Tahap 1 dan 2 sudah berhasil; berikutnya Tahap 3 = Secret passcode).

## 10. (Rev 240) Batas bulanan opsional
Selain batas harian, aplikasi boleh mengirim `monthLimit` (angka >= 1, maks. 100000; tidak dikirim atau 0 = TANPA batas bulanan, bawaan). Dihitung per orang per bulan menurut WIB, disimpan di KV dengan kunci `mon:<orang>:<YYYY-MM>` (kedaluwarsa 40 hari). Bila batas bulanan aktif, Worker memeriksanya LEBIH DULU dari batas harian; tanpa KV atau KV gagal dibaca, permintaan ditolak demi aman. Batas bulanan memakai 1 penulisan KV tambahan per permintaan (paket gratis KV: 1.000 penulisan per hari), jadi biarkan mati bila tidak perlu. Aksi `usage`/`whoami` kini juga mengembalikan `monthUsed`. Tempel ulang `worker.mjs` TERBARU di **Edit code** lalu **Deploy**. Pilihan batas bulanan di layar aplikasi menyusul (Rev 241).

### 10.1 (Rev 242) Token bulanan
Bila batas bulanan AKTIF, Worker juga menjumlah token masuk dan keluar bulan itu (angka `usage` dari penyedia) di nilai KV yang sama (`hitungan|masuk|keluar`; format lama `hitungan` tetap terbaca). Jawaban membawa `monthTokens` (`{in, out}`), dan Setelan > Kelimaa AI > Tes sambungan menampilkannya sebagai "token bulan ini". Biaya: +1 penulisan KV per permintaan berhasil (jadi 3 penulisan per permintaan bila batas harian dan bulanan aktif; paket gratis 1.000 penulisan/hari). Angka token = laporan penyedia, perkiraan; harga dan tagihan TIDAK dihitung (harga belum diverifikasi). Batas bulanan mati = tidak ada penulisan tambahan dan `monthTokens` tidak muncul. Worker perlu ditempel ulang di Cloudflare agar fitur ini aktif; Worker lama tetap jalan (aplikasi menampilkan token hanya bila ada).

### 10.2 (Rev 243) Hasil audit keamanan
Worker kini: menyaring untaian mirip kunci dari pesan galat penyedia, menolak badan permintaan raksasa (Content-Length) sebelum dibaca, dan mengembalikan galat 500 generik untuk kesalahan tak terduga. Batas harian/bulanan masih ditentukan aplikasi (bisa dilewati pemegang passcode); itu sengaja untuk dua pengguna tepercaya.

### 10.3 (Rev 244) Plafon harian di server (opsional)
Tambahkan variabel TEKS (bukan Secret) `HARD_DAILY_LIMIT` di Worker > Settings > Variables, mis. `150`. Batas harian efektif tidak akan pernah melebihi angka itu, apa pun pilihan di aplikasi (termasuk Tanpa batas). Kosongkan/hapus = tanpa plafon. Butuh KV. Setelah mengubah variabel, Deploy ulang; Tes sambungan di aplikasi menampilkan 'Plafon server'.

## Cadangan saat pencarian Google gagal (Rev 249)
Bila Cari di web gagal di Gemini (kena batas, sibuk, waktu habis), Worker otomatis menjawab lewat jalur lain yang punya kunci (Sakelar atau Relay Router) TANPA pencarian web. Jawaban diberi label "Pencarian web sedang tidak tersedia" dan tidak punya sumber. Jatah tetap dihitung 1 per permintaan. Tanpa kunci jalur lain, galat Gemini tampil seperti biasa. Tempel ulang `worker.mjs` TERBARU dan Deploy; aplikasi perlu APK baru agar labelnya tampil.

## Catatan token berpikir (Rev 366)
Pada model Gemini yang berpikir, `maxOutputTokens` ikut menghitung token berpikir. Bila di uji nyata muncul galat "Penyedia tidak mengembalikan teks (MAX_TOKENS)" pada riset atau baca foto, naikkan `MAX_RESEARCH_OUT` (3000) atau `MAX_OCR_OUT` (8000) di `worker.mjs`. Belum diubah karena belum ada bukti galat di uji nyata.

## Mutu baca tulisan tangan (Rev 367, K4)
Petunjuk sistem `ocr` kini meminta model membaca tulisan tangan kata demi kata, menandai kata yang diragukan dengan `[?]`, dan tidak menebak angka, nama, atau alamat yang tidak jelas; batas keluaran dinaikkan ke 12000 (token berpikir ikut terhitung). Worker BERUBAH: tempel ulang `worker.mjs` lalu Deploy. Bila hasil tulisan tangan masih buruk, coba model lain tanpa APK baru lewat variabel teks `MODEL_OCR`. Belum terbukti di foto nyata.

## Jalur OCR: Gemini, Sakelar, Relay (Rev 368, PART OJ1)
Aksi `ocr` kini menerima `provider` (`gemini`, `sakelar`, `relay`). Kosong = Gemini seperti sebelumnya. Variabel teks opsional `OCR_PROVIDER` mengubah bawaan Worker (mis. `sakelar`); pilihan dari aplikasi menang. Worker BERUBAH: tempel ulang `worker.mjs` lalu Deploy. Aplikasi belum memakai pilihan ini (UI = PART OJ3), jadi OCR di aplikasi tetap lewat Gemini sampai APK berikutnya.
- **Gemini:** tidak berubah (`GEMINI_KEY`; model: `MODEL_OCR` > `MODEL_GEMINI` > `gemini-3.5-flash`; cadangan `gemini-3.5-flash-lite` pada galat sementara).
- **Sakelar / Relay Router:** foto dikirim dengan format gambar OpenAI (`image_url` data URI) ke URL chat jalur itu. Butuh Secret `SAKELAR_KEY` atau `RELAY_KEY`. Model: nama dari aplikasi > `MODEL_OCR_SAKELAR` / `MODEL_OCR_RELAY` > `MODEL_SAKELAR` / `MODEL_RELAY` > bawaan jalur. Relay tidak punya model bawaan: isi `MODEL_RELAY` (atau `MODEL_OCR_RELAY`). `MODEL_OCR` hanya untuk Gemini.
- **Tanpa pindah jalur otomatis dan tanpa model cadangan** di Sakelar/Relay: gagal = galat apa adanya.
- **Penting:** model yang dipilih HARUS bisa membaca gambar. Model teks saja bisa menolak atau menjawab kosong (aplikasi akan menerima galat 502 dengan saran ganti model/jalur). Belum terbukti apakah Sakelar/Relay meneruskan gambar; hanya uji nyata yang membuktikan.
- Mempercepat Gemini tanpa kode: variabel teks `MODEL_OCR` = `gemini-3.5-flash-lite`.

## Gambar catatan di R2 (Rev 428, PART SY5a) — langkah untuk pemula
Aksi `img` menyimpan gambar catatan di Cloudflare R2 supaya gambar ikut tersinkron antar HP dan laptop. Tanpa langkah ini Worker tetap jalan seperti biasa (chat, OCR, sinkron teks); aksi `img` saja yang menjawab 503 "butuh R2".
1. Dashboard Cloudflare > **R2 Object Storage** > aktifkan R2 (Cloudflare biasanya meminta metode pembayaran walau pemakaian kecil masih masuk jatah gratis; periksa halaman harga R2 untuk angka terbaru, jangan mengandalkan angka dari dokumen ini).
2. **Create bucket**, nama bebas (usul: `kelimaa-gambar`), biarkan privat (jangan aktifkan akses publik).
3. Buka Worker `kelimaa-ai` > **Settings** > **Bindings** > **Add** > **R2 bucket**. **Variable name harus persis `IMG`**, pilih bucket tadi, simpan, lalu **Deploy**.
4. Tempel ulang `worker.mjs` terbaru (Rev 428 atau lebih baru) bila belum, lalu Deploy.
Kontrak aksi dan batas (maks. 600 KB per gambar, jenis webp/jpg/png, berkas dipisah per orang) ada di komentar blok "Rev 428 / PART SY5a" di `worker.mjs`.
