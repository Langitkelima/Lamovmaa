// Rev 184c-2 / U10e-3b: tinggi baris bebas di ekspor PDF/JPG. Berkas rev190 = Rev 184c-2.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { sheetBlocks, rowMinPx, withRowH, layoutDoc, parseNoteHtml, blocksToText } from '../src/js/export.js';
import * as P from '../src/js/lembar-pulau.js';
import * as L from '../src/js/lembar.js';
const measure = (t, o = {}) => String(t).length * (o.size || 30) * 0.55;
const mk = () => { const sh = L.newSheet({ id: 'sabc123', name: 'T' }); const t = sh.tabs[0]; for (let i = 1; i <= 4; i++) L.setCell(t, 'r' + i, 'cA', { v: 'baris ' + i }); return { sh, t }; };
const o = { width: 1240, pageH: 1754, padX: 110, padTop: 120, padBottom: 130, size: 30, titleSize: 46, measure };
const rowsOf = (sh) => layoutDoc({ title: 'T', blocks: sheetBlocks(P.exportModel(sh, { rows: 20, cols: 8 })) }, o).filter((l) => l.kind === 'tableRow');

test('rowMinPx: skala ukuran huruf/15, batas 40% halaman, tak sah = 0', () => {
  assert.equal(rowMinPx(100, 30, 1754), 200); assert.equal(rowMinPx(100, 15, 1754), 100); assert.equal(rowMinPx(3000, 30, 1754), 701); assert.equal(rowMinPx(0, 30, 1754), 0); assert.equal(rowMinPx(NaN, 30, 1754), 0); assert.equal(rowMinPx(100, 30, undefined) > 0, true);
});
test('withRowH: hanya menaruh h bila ada tinggi khusus', () => { const a = withRowH([], 90); assert.equal(a.h, 90); assert.equal('h' in withRowH([], 0), false); assert.equal('h' in withRowH([], undefined), false); });
test('sheetBlocks: baris tabel membawa h hanya bila rowH ada (data lama persis sama)', () => {
  const { sh, t } = mk(); const b0 = sheetBlocks(P.exportModel(sh)).find((x) => x.kind === 'table'); assert.ok(b0.rows.every((r) => !('h' in r)));
  L.setRowHeight(t, t.rows[1].id, 100); const b1 = sheetBlocks(P.exportModel(sh)).find((x) => x.kind === 'table'); assert.equal(b1.rows[1].h, 100); assert.ok(!('h' in b1.rows[0]));
});
test('layoutDoc: baris ber-tinggi lebih tinggi, baris lain sama, tidak lebih pendek dari isi', () => {
  const { sh, t } = mk(); const base = rowsOf(sh).map((r) => r.lh);
  L.setRowHeight(t, t.rows[1].id, 100); L.setRowHeight(t, t.rows[2].id, 16); const r = rowsOf(sh).map((x) => x.lh);
  assert.equal(r[1], 200); assert.equal(r[0], base[0]); assert.equal(r[3], base[3]); assert.equal(r[2], base[2], 'baris pendek tidak memotong isi');
});
test('baris sangat tinggi dibatasi 40% halaman; TXT tidak berubah', () => {
  const { sh, t } = mk(); const before = blocksToText('', parseNoteHtml('<div class="ksheet" data-sheet="sabc123"></div>', new Date(), (id) => P.exportModel(sh)));
  L.setRowHeight(t, t.rows[0].id, 500000); assert.equal(rowsOf(sh)[0].lh, Math.floor(1754 * 0.4));
  assert.equal(blocksToText('', parseNoteHtml('<div class="ksheet" data-sheet="sabc123"></div>', new Date(), (id) => P.exportModel(sh))), before);
});
test('kabel: export.js memakai rowMinPx pada tinggi baris tabel', () => { assert.match(readFileSync(new URL('../src/js/export.js', import.meta.url), 'utf8'), /Math\.max\(maxLines \* actualLineH \+ padY \* 2, rowMinPx\(rows\[ri\]\.h, o\.size, o\.pageH\)\)/); });
