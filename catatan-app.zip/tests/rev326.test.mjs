// Rev 326 / PART A2: animasi pegas (D4) lewat CSS, memakai token A1. Hanya transform + opacity, hanya saat muncul, mati di reduced-motion.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const a2 = css.slice(css.indexOf('/* Rev 326 / A2'));
test('Rev 326: tiga keyframes A2 hanya memakai opacity dan transform', () => {
  for (const k of ['a2-up', 'a2-pop', 'a2-sheet']) {
    const m = a2.match(new RegExp('@keyframes ' + k + '\\{([^]*?)\\}\\}'));
    assert.ok(m, k);
    assert.ok(!/(width|height|top|left|margin|padding)\s*:/.test(m[1]), k + ' menganimasikan tata letak');
  }
});
test('Rev 326: toast, dialog, kartu tautan, alat blok memakai pegas (--ease-p); lembar bawah memakai --ease-o (tanpa lonjakan)', () => {
  assert.match(a2, /\.toast\[class\]\{animation:a2-up var\(--g3\) var\(--ease-p\) both\}/);
  assert.match(a2, /\.dlgov:not\(\.kai-save\):not\(\.exitq\) \.sheet\{animation:a2-pop var\(--g2\) var\(--ease-p\) both\}/);
  assert.match(a2, /\.lk-card,\.lk-tools,\.mood-tools\{animation:a2-pop var\(--g2\) var\(--ease-p\) both\}/);
  assert.match(a2, /\.ov:not\(\.dlgov\) \.sheet,\.rm-sheet\{animation:a2-sheet var\(--g2\) var\(--ease-o\) both\}/);
});
test('Rev 326: reduced-motion mematikan semua animasi A2; tidak ada hex/rgba di blok A2; tabel dan editor tidak dianimasikan', () => {
  assert.match(a2, /@media \(prefers-reduced-motion:reduce\)\{[^}]*animation:none!important\}\}/);
  assert.ok(!/#[0-9a-f]{3,8}\b|rgba\(/i.test(a2));
  assert.ok(!/\.ed2|table|tbl-wrap|contenteditable/.test(a2.split('\n').filter((l) => l.includes('animation:a2')).join('\n')));
});
