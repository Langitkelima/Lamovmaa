// Rev 159 / U10c-2c: UI simpan/daftar/hapus diagram di dialog Diagram (SCHEMA 18)
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as S from '../src/js/storage.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js');
const body = () => { const a = ui.indexOf('const CHART_MSG = '), b = ui.indexOf('const tabMenu = (t) => namePrompt('); assert.ok(a > 0 && b > a); return ui.slice(a, b); };
const mk = () => L.newSheet({ name: 'A' }).tabs[0];
test('L.saveChart / listCharts / deleteChart: jembatan ke modul grafik, batas MAX_CHARTS', () => {
  const t = mk(); const r = L.saveChart(t, { r1: 0, c1: 0, r2: 4, c2: 1 }, 1, { kind: 'bar', title: 'T', legend: true }); assert.equal(r.ok, true);
  const l = L.listCharts(t); assert.equal(l.length, 1); assert.equal(l[0].ref, 'A1:B5'); assert.equal(l[0].kind, 'bar');
  for (let i = 1; i < L.MAX_CHARTS; i++) assert.ok(L.saveChart(t, { r1: 0, c1: 0, r2: 2, c2: 1 }, 1).ok); assert.equal(L.saveChart(t, { r1: 0, c1: 0, r2: 2, c2: 1 }, 1).reason, 'batas');
  assert.equal(L.deleteChart(t, r.id), true); assert.equal(L.deleteChart(t, r.id), false); assert.equal(L.listCharts(t).length, L.MAX_CHARTS - 1);
});
test('Urungkan: snapshot ser() sebelum simpan/hapus memulihkan diagram lewat cleanSheet', () => {
  const sh = L.newSheet({ name: 'A' }); const tab = sh.tabs[0]; const ser = () => JSON.stringify({ name: sh.name, tabs: sh.tabs });
  const s0 = ser(); L.saveChart(tab, { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, { kind: 'donut' }); const s1 = ser();
  const back1 = L.cleanSheet({ ...sh, ...JSON.parse(s1) }); assert.equal(back1.tabs[0].charts.length, 1);
  const back0 = L.cleanSheet({ ...sh, ...JSON.parse(s0) }); assert.equal('charts' in back0.tabs[0], false);
  const id = tab.charts[0].id; L.deleteChart(tab, id); assert.equal('charts' in tab, false);
  const again = L.cleanSheet({ ...sh, ...JSON.parse(s1) }); assert.equal(again.tabs[0].charts[0].id, id);
});
test('openChart: Simpan = snapshot SEBELUM, lewat L.saveChart, batas ukuran dicek sebelum hist.push, satu push per aksi', () => {
  const b = body(); assert.equal((b.match(/ver\+\+, hist\.push\(snap\)/g) || []).length, 2); // simpan + hapus
  const s = b.slice(b.indexOf('sv.onclick')); assert.ok(s.indexOf('ser()') < s.indexOf('L.saveChart(') && s.indexOf('L.fitsLimit(sheet)') < s.indexOf('hist.push(snap)'));
  assert.ok(s.includes('L.deleteChart(tab, r.id)')); // dibatalkan bila lembar kerja jadi terlalu besar
  const d = b.slice(b.indexOf("'data-a': 'hapus'")); assert.ok(d.indexOf('ser()') < d.indexOf('L.deleteChart(tab, c.id)') && d.indexOf('L.deleteChart(tab, c.id)') < d.indexOf('hist.push(snap)'));
  assert.match(b, /valueCol: c\.valueCol/); assert.match(b, /L\.saveChart\(tab, src, src\.c2/); assert.match(b, /paintSaved\(\); paint\(\)/);
});
test('openChart: daftar tersimpan aman (tanpa innerHTML), Lihat memakai chartData tersimpan, tombol Simpan mati bila tak bisa digambar atau penuh', () => {
  const b = body(); assert.doesNotMatch(b, /innerHTML|insertAdjacentHTML|eval\(|new Function|localStorage/);
  assert.match(b, /Tersimpan di tab ini/); assert.match(b, /'data-a': 'lihat'/); assert.match(b, /sv\.disabled = true/); assert.match(b, /sv\.disabled = L\.listCharts\(tab\)\.length >= L\.MAX_CHARTS/);
  assert.match(b, /DOMParser/); assert.match(b, /saveFiles/);
});
test('Rev 159: lembar-ui tidak mengimpor lembar-grafik; CSS daftar ada; SCHEMA 18; versi 0.3.121; tes terdaftar', () => {
  assert.doesNotMatch(ui, /lembar-grafik/); assert.match(src('src/css/styles.css'), /Rev 159 \/ U10c-2c/); assert.match(src('src/css/styles.css'), /\.lz-chart \.lz-svr/);
  assert.equal(S.SCHEMA, 22); const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev159.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
