// Rev 308b / v0.3.121: lembar pemilih tugas/proyek (UI, modul pemilihui.js) + keterangan `meta` dari pickable. Tes statis + logika; tampilan nyata diaudit di Chromium (tools/audit_pemilih_data.py).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { pickable } from '../src/js/ai/konteks.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const d = { tasks: [{ id: 't1', title: 'Bayar listrik', done: false, due: '2026-11-20', pri: 1 }, { id: 't2', title: 'Cuci mobil', done: false }], projects: [{ id: 'a', name: 'Renovasi', status: 'aktif', at: 1, tasks: ['t1', 't2'], notes: [] }, { id: 'c', name: 'Belajar', status: 'aktif', at: 2, tasks: [], notes: [] }] };
test('pickable: meta tugas = tenggat + penting; meta proyek = kemajuan', () => {
  assert.deepEqual(pickable(d, 'tugas').map((x) => x.meta), ['tenggat 2026-11-20 · penting', '']);
  assert.deepEqual(pickable(d, 'proyek').map((x) => [x.id, x.meta]), [['c', 'belum ada tugas tertaut'], ['a', '0 dari 2 tugas selesai']]);
});
test('pemilihui.js: kolom cari, centang role=checkbox, Pilih semua, Kosongkan, Selesai (N), batas maks., tanpa innerHTML/penyimpanan sendiri', () => {
  const m = src('src/js/ai/pemilihui.js');
  for (const k of ["type: 'search'", "role: 'checkbox'", "'Pilih semua'", "'Kosongkan'", "'Selesai (' + sel.length + ')'", "'Batal'", 'togglePick(', 'setPicks(', 'pickable(data, src)', "t.result === 'full'", 'CTX_PICK_MAX', 'onApply(setPicks(perms, src, sel))']) assert.ok(m.includes(k), k);
  assert.doesNotMatch(m, /innerHTML|localStorage|savePerms|\.priv\b|\.trash\b|\.notes\b/);
});
test('Batal/ketuk luar tidak memanggil onApply; hanya Selesai yang menerapkan', () => {
  const m = src('src/js/ai/pemilihui.js'); assert.equal((m.match(/onApply\(setPicks/g) || []).length, 1); assert.equal((m.match(/tutup\(\); onApply/g) || []).length, 1); assert.match(m, /e\.target === o\) tutup\(\)/);
});
test('obrolan.js: baris sumber membuka pemilih, hasil disimpan lewat savePerms, hitungan memakai livePerms', () => {
  const o = src('src/js/ai/obrolan.js'); assert.match(o, /import \{ bukaPemilihData \} from '\.\/pemilihui\.js'/); assert.match(o, /bukaPemilihData\(\{ data: ctx\.data, src: x\.id, perms, onApply: \(np\) => \{ perms = np; const r = savePerms\(perms\)/);
  assert.match(o, /livePerms\(ctx\.data, perms\)\[sid\]\.length/); assert.doesNotMatch(src('src/js/main.js'), /pemilihui/);
});
