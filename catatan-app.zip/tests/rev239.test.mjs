// Rev 239 / Tahap 8b-2: tren di Insight mingguan (doneAt tugas + habitLog). Murni, dihitung di HP; hanya hitungan.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { buildInsight, insightPrompt } from '../src/js/ai/insight.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 12, 10, 0, 0).getTime(), DAY = 86400000;
const base = (x = {}) => ({ tasks: [], notes: [], projects: [], ...x });
test('tugas selesai: 7 hari terakhir vs 7 hari sebelumnya; lebih lama dan yang belum selesai tidak dihitung', () => {
  const r = buildInsight(base({ tasks: [
    { id: 'a', title: 'RAHASIA-A', done: true, doneAt: NOW - DAY }, { id: 'b', title: 'B', done: true, doneAt: NOW - 6 * DAY },
    { id: 'c', title: 'C', done: true, doneAt: NOW - 8 * DAY }, { id: 'd', title: 'D', done: true, doneAt: NOW - 13 * DAY }, { id: 'e', title: 'E', done: true, doneAt: NOW - 20 * DAY },
    { id: 'f', title: 'F', done: false, doneAt: NOW - DAY }, { id: 'g', title: 'G', done: true }] }), NOW);
  assert.equal(r.trend.doneWeek, 2); assert.equal(r.trend.donePrev, 2); assert.equal(r.trend.hasDone, true);
  assert.match(r.text, /Tugas selesai 7 hari terakhir: 2 \(minggu sebelumnya: 2, sama\)/); assert.equal(r.empty, false);
});
test('kata banding: naik, turun, sama', () => {
  const mk = (w, p) => base({ tasks: [...Array.from({ length: w }, (_, i) => ({ id: 'w' + i, title: 'x', done: true, doneAt: NOW - DAY })), ...Array.from({ length: p }, (_, i) => ({ id: 'p' + i, title: 'x', done: true, doneAt: NOW - 9 * DAY }))] });
  assert.match(buildInsight(mk(3, 1), NOW).text, /: 3 \(minggu sebelumnya: 1, naik 2\)/); assert.match(buildInsight(mk(1, 4), NOW).text, /: 1 \(minggu sebelumnya: 4, turun 3\)/);
});
test('kebiasaan: persen tertimbang per jendela; jendela kosong tidak menampilkan minggu sebelumnya; entri rusak diabaikan', () => {
  const r = buildInsight(base({ habitLog: [{ d: '2026-11-11', done: 2, total: 3 }, { d: '2026-11-10', done: 3, total: 3 }, { d: '2026-11-04', done: 1, total: 4 }, { d: '2026-11-03', done: 1, total: 4 }, { d: '2026-10-20', done: 4, total: 4 }, { d: 'x', done: 1, total: 1 }, { d: '2026-11-09', done: 5, total: 3 }, null] }), NOW);
  assert.equal(r.trend.habitPct, 83); assert.equal(r.trend.habitDays, 2); assert.equal(r.trend.habitPctPrev, 25); assert.equal(r.trend.habitDaysPrev, 2);
  assert.match(r.text, /Kebiasaan 7 hari terakhir: 83% terpenuhi dari 2 hari tercatat \(minggu sebelumnya: 25%, naik 58 poin\)/);
  const s = buildInsight(base({ habitLog: [{ d: '2026-11-11', done: 1, total: 2 }] }), NOW); assert.equal(s.trend.habitPctPrev, null); assert.match(s.text, /50% terpenuhi dari 1 hari tercatat$/m); assert.doesNotMatch(s.text, /minggu sebelumnya: null/);
});
test('tanpa data tren: baris penjelasan, empty tetap true; tidak ada NaN/undefined/null', () => {
  const r = buildInsight({}, NOW); assert.equal(r.empty, true); assert.equal(r.trend.hasDone, false); assert.equal(r.trend.habitPct, null);
  assert.match(r.text, /Tugas selesai: belum ada data/); assert.match(r.text, /Kebiasaan: belum ada riwayat harian/); assert.doesNotMatch(r.text, /NaN|undefined|null/);
  assert.doesNotThrow(() => buildInsight({ tasks: 'x', habitLog: 5 }, NOW)); assert.equal(buildInsight({ habitLog: [{ d: '2026-11-11', done: 1, total: 2 }] }, NOW).empty, false);
});
test('privasi: tanpa judul tugas selesai dan tanpa nama kebiasaan; sumber tidak membaca .habits/.priv/.trash; stats lama tidak berubah', () => {
  const d = base({ habits: [{ id: 'h', title: 'MINUM-AIR-RAHASIA', done: true }], tasks: [{ id: 'a', title: 'JUDUL-SELESAI-RAHASIA', done: true, doneAt: NOW - DAY }], habitLog: [{ d: '2026-11-11', done: 1, total: 1 }] });
  const t = buildInsight(d, NOW).text; assert.doesNotMatch(t, /RAHASIA/);
  const code = src('src/js/ai/insight.js').replace(/^\/\/.*$/gm, ''); assert.doesNotMatch(code, /\.habits\b|\.priv\b|\.trash\b|\.sheets\b|innerHTML|document\.|fetch|localStorage/);
  assert.deepEqual(Object.keys(buildInsight(d, NOW).stats), ['open', 'late', 'soon', 'important', 'notesWeek', 'projects', 'projLate', 'projSoon']);
});
test('teks tetap <= INSIGHT_MAX dan prompt <= batas pesan; prompt meminta komentar tren', () => {
  const r = buildInsight(base({ tasks: Array.from({ length: 40 }, (_, i) => ({ id: 'k' + i, title: 'Tugas panjang ' + 'x'.repeat(80), done: i % 2 === 0, doneAt: NOW - DAY, due: '2026-11-1' + (i % 9) })), habitLog: [{ d: '2026-11-11', done: 1, total: 2 }] }), NOW);
  assert.ok(r.text.length <= 1500); assert.ok(insightPrompt(r.text, 4000).length <= 4000); assert.ok(insightPrompt('x'.repeat(5000), 600).length <= 600);
  assert.match(insightPrompt('abc'), /3 saran prioritas[\s\S]*Komentari tren[\s\S]*abc$/);
});
test('dialog: teks keterangan menyebut hitungan kebiasaan tanpa nama; tetap hanya mengisi kolom pesan; versi 0.3.121; Worker tidak berubah; tes terdaftar', () => {
  const o = src('src/js/ai/obrolan.js'); assert.match(o, /hitungan kebiasaan harian \(tanpa nama kebiasaan\)/);
  const blok = o.slice(o.indexOf('Rev 237: ringkasan'), o.indexOf("'Minta saran AI'")); assert.doesNotMatch(blok, /send\.onclick|kirimChat|send\.click/);
  for (const f of ['main.js', 'notes.js', 'settings.js']) assert.doesNotMatch(src('src/js/' + f), /insight/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev239\.test\.mjs/);
  assert.doesNotMatch(src('backend/cloudflare/worker.mjs'), /habitLog|doneAt|insight/i); // Worker tidak tahu soal tren: semuanya dihitung di HP
});
