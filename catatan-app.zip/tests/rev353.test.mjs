// Rev 353 / PART O2 (Paket OCR): mesin aplikasi `ai/ocr.js`. Tanpa jaringan nyata, tanpa DOM nyata (pengirim dan pengecil PALSU).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, readdirSync } from 'node:fs';
import * as O from '../src/js/ai/ocr.js';
import * as R from '../src/js/ai/riwayat-token.js';
import { staticGraph } from '../scripts/preload.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const conn = { url: 'https://w.example.workers.dev', key: 'rama-secret-12' };
const JPEG = 'A'.repeat(8) + '/9j/' + 'A'.repeat(40); // panjang 52, kelipatan 4, base64 sah
const img = { mime: 'image/jpeg', image: JPEG, w: 800, h: 600, bytes: 39 };
const GOOD = { ok: true, task: 'ocr.read', text: 'Beli susu\nBeli roti', model: 'gemini-3.5-flash', provider: 'gemini', usage: { in: 700, out: 12 }, limit: 100, used: 4 };
const NOW = new Date(2026, 10, 19, 10, 0).getTime();
const mem = () => { const m = {}; return { getItem: (k) => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: (k) => { delete m[k]; }, _m: m }; };

test('b64Len dan bytesToB64: panjang cocok, hasil sah, potongan besar tidak meledak', () => {
  assert.equal(O.b64Len(0), 0); assert.equal(O.b64Len(1), 4); assert.equal(O.b64Len(3), 4); assert.equal(O.b64Len(4), 8); assert.equal(O.b64Len(-5), 0); assert.equal(O.b64Len('x'), 0);
  const big = new Uint8Array(100000).map((_, i) => i % 251); const s = O.bytesToB64(big);
  assert.equal(s.length, O.b64Len(100000)); assert.equal(Buffer.from(s, 'base64').length, 100000); assert.deepEqual([...Buffer.from(s, 'base64').subarray(0, 5)], [0, 1, 2, 3, 4]);
  assert.equal(O.bytesToB64(new Uint8Array(0)), '');
});
test('konstanta: target 400.000 byte muat batas Worker 560.000 huruf; sama dengan Worker', () => {
  assert.ok(O.b64Len(O.OCR_MAX_BYTES) <= O.OCR_B64_MAX); assert.equal(O.b64Len(O.OCR_MAX_BYTES), 533336);
  const w = src('backend/cloudflare/worker.mjs'); assert.match(w, /MAX_OCR_B64 = 560000/); assert.match(w, /MIN_OCR_B64 = 40/); assert.equal(O.OCR_B64_MAX, 560000); assert.equal(O.OCR_B64_MIN, 40);
  assert.ok(O.OCR_TIMEOUT > 52000, 'aplikasi menunggu lebih lama dari batas total Worker (52 dtk)'); assert.equal(O.OCR_MIME, 'image/jpeg');
});
test('planOcr: sisi <= 1600, kualitas 0,8 turun ke 0,5, lalu 1280 dan 1024; foto kecil tidak diperbesar', () => {
  const p = O.planOcr(4000, 3000); assert.equal(p.ok, true); assert.deepEqual([p.width, p.height], [1600, 1200]); assert.equal(p.resized, true); assert.equal(p.maxBytes, 400000);
  assert.deepEqual(p.steps.map((s) => s.quality), [0.8, 0.7, 0.6, 0.5, 0.7, 0.6]); assert.deepEqual(p.steps.slice(0, 4).map((s) => s.width), [1600, 1600, 1600, 1600]); assert.deepEqual([p.steps[4].width, p.steps[4].height, p.steps[5].width, p.steps[5].height], [1280, 960, 1024, 768]);
  const v = O.planOcr(3000, 4000); assert.deepEqual([v.width, v.height], [1200, 1600]);
  const k = O.planOcr(900, 600); assert.deepEqual([k.width, k.height], [900, 600]); assert.equal(k.resized, false); assert.equal(k.steps.length, 4, 'foto kecil: tidak ada langkah perkecil tambahan');
  const m = O.planOcr(1200, 800); assert.equal(m.steps.length, 5, '1200 px: hanya langkah 1024 yang lebih kecil'); assert.equal(m.steps[4].width, 1024);
  for (const bad of [[0, 0], [NaN, 5], [-1, 4], [null, null]]) assert.equal(O.planOcr(...bad).ok, false); assert.match(O.planOcr(0, 0).msg, /tidak terbaca/);
});
test('cekGambar: cermin aturan Worker (mime, panjang, base64, awalan data:)', () => {
  assert.equal(O.cekGambar(img).ok, true); assert.equal(O.cekGambar({ ...img, mime: 'image/webp' }).ok, true);
  for (const bad of [null, {}, { ...img, mime: 'image/png' }, { ...img, image: '' }, { ...img, image: 'AAAA' }, { ...img, image: 12 }, { ...img, image: 'data:image/jpeg;base64,' + JPEG }, { ...img, image: JPEG + 'A' }, { ...img, image: JPEG.slice(0, 48) + ' ABC' }, { ...img, image: 'A'.repeat(560004) }]) assert.equal(O.cekGambar(bad).ok, false);
  assert.match(O.cekGambar({ ...img, image: 'A'.repeat(560004) }).msg, /terlalu besar/);
  assert.equal(O.cekGambar({ ...img, image: 'A'.repeat(560000) }).ok, true, 'tepat di batas = lolos');
});
test('buatPermintaan: bentuk persis kontrak Worker; TANPA provider/task/model bila tidak diminta; limit dan monthLimit hanya bila perlu', () => {
  const q = O.buatPermintaan(conn, img); assert.equal(q.ok, true); assert.equal(q.url, 'https://w.example.workers.dev/');
  const b = JSON.parse(q.body); assert.deepEqual(Object.keys(b).sort(), ['action', 'image', 'key', 'mime']); assert.equal(b.action, 'ocr'); assert.equal(b.mime, 'image/jpeg'); assert.equal(b.image, JPEG); assert.equal(b.key, 'rama-secret-12');
  assert.equal(b.provider, undefined); assert.equal(b.model, undefined); assert.equal(b.task, undefined); assert.equal(b.messages, undefined);
  const c = JSON.parse(O.buatPermintaan(conn, img, { limit: 0, monthLimit: 3000, provider: 'sakelar', task: 'x' }).body); assert.equal(c.limit, 0); assert.equal(c.monthLimit, 3000); assert.equal(c.provider, 'sakelar'); /* Rev 369: DISENGAJA, `provider` kini dikirim bila sah (sebelumnya diabaikan) */ assert.equal(c.task, undefined);
  assert.equal(JSON.parse(O.buatPermintaan(conn, img, { monthLimit: 0 }).body).monthLimit, undefined);
  assert.equal(JSON.parse(O.buatPermintaan(conn, img, { model: 'gemini-3.5-flash' }).body).model, 'gemini-3.5-flash');
  assert.equal(O.buatPermintaan(conn, img, { model: 'model salah!' }).ok, false);
  assert.equal(O.buatPermintaan({ url: '', key: 'abc' }, img).ok, false); assert.equal(O.buatPermintaan({ url: conn.url, key: '' }, img).ok, false); assert.equal(O.buatPermintaan(conn, { ...img, image: '' }).ok, false);
});
test('uraiJawaban: sukses, kosong (tanpa teks), terpotong, token, cadangan model', () => {
  const r = O.uraiJawaban(200, JSON.stringify({ ...GOOD, monthUsed: 3, monthLimit: 3000, monthTokens: { in: 900, out: 40 }, fallbackFrom: 'gemini-3.5-flash' }));
  assert.equal(r.ok, true); assert.equal(r.text, 'Beli susu\nBeli roti'); assert.equal(r.empty, false); assert.equal(r.truncated, false); assert.equal(r.model, 'gemini-3.5-flash'); assert.equal(r.provider, 'gemini'); assert.equal(r.used, 4); assert.equal(r.limit, 100);
  assert.deepEqual(r.usage, { in: 700, out: 12 }); assert.equal(r.monthUsed, 3); assert.equal(r.monthLimit, 3000); assert.deepEqual(r.monthTokens, { in: 900, out: 40 }); assert.equal(r.fallbackFrom, 'gemini-3.5-flash');
  const e = O.uraiJawaban(200, JSON.stringify({ ...GOOD, text: '', empty: true })); assert.equal(e.ok, true); assert.equal(e.empty, true); assert.equal(e.text, '');
  assert.equal(O.uraiJawaban(200, JSON.stringify({ ...GOOD, truncated: true })).truncated, true);
  assert.equal(O.uraiJawaban(200, JSON.stringify({ ...GOOD, usage: { in: 0, out: 0 } })).usage, undefined);
  assert.equal(O.uraiJawaban(200, JSON.stringify({ ok: true, text: '   ' })).ok, false, 'teks kosong tanpa empty:true bukan sukses');
});
test('uraiJawaban: galat Worker apa adanya; 401 dan Worker LAMA diganti petunjuk; jawaban asing', () => {
  const lama = O.uraiJawaban(400, JSON.stringify({ ok: false, error: 'Aksi tidak dikenal' })); assert.equal(lama.ok, false); assert.equal(lama.workerLama, true); assert.match(lama.msg, /tempel ulang worker\.mjs/);
  assert.match(O.uraiJawaban(401, JSON.stringify({ ok: false, error: 'Passcode salah' })).msg, /Setelan > Kelimaa AI/);
  const b = O.uraiJawaban(429, JSON.stringify({ ok: false, error: 'Batas harian tercapai (100/100). Naikkan batas di Setelan > Kelimaa AI, pilih Tanpa batas, atau coba lagi besok.' })); assert.match(b.msg, /Batas harian tercapai/); assert.equal(b.workerLama, undefined);
  assert.match(O.uraiJawaban(503, JSON.stringify({ ok: false, error: 'Baca teks dari foto butuh kunci Gemini Google di Worker (Secret GEMINI_KEY).' })).msg, /GEMINI_KEY/);
  assert.match(O.uraiJawaban(413, JSON.stringify({ ok: false })).msg, /terlalu besar/); assert.match(O.uraiJawaban(500, JSON.stringify({ ok: false })).msg, /kode 500/);
  for (const t of ['<html>', '', 'null', '[1]', undefined]) { const x = O.uraiJawaban(502, t); assert.equal(x.ok, false); assert.match(x.msg, /tidak dikenali \(kode 502\)/); }
  assert.ok(O.jelaskanGalat(400, 'x'.repeat(500)).length <= 220);
});
test('kirimOcr: kirim POST ke alamat/, timeout 60 dtk, jawaban diurai; galat input/jaringan = {ok:false,msg}, tidak melempar', async () => {
  let sent = null; const http = async (r) => { sent = r; return { status: 200, text: JSON.stringify(GOOD) }; };
  const r = await O.kirimOcr(conn, img, http, { limit: 0 }); assert.equal(r.ok, true); assert.equal(sent.method, 'POST'); assert.equal(sent.url, 'https://w.example.workers.dev/'); assert.equal(sent.timeout, 60000); assert.equal(JSON.parse(sent.body).action, 'ocr'); assert.equal(JSON.parse(sent.body).limit, 0);
  let n = 0; const tak = async () => { n++; return { status: 200, text: '{}' }; }; assert.equal((await O.kirimOcr(conn, { ...img, image: '' }, tak)).ok, false); assert.equal((await O.kirimOcr({ url: 'x', key: 'y' }, img, tak)).ok, false); assert.equal(n, 0, 'masukan tak sah tidak memanggil jaringan');
  const off = await O.kirimOcr(conn, img, async () => { throw new Error('Failed to fetch'); }); assert.equal(off.ok, false); assert.match(off.msg, /Tidak tersambung/);
  const to = await O.kirimOcr(conn, img, async () => { throw new Error('timeout'); }); assert.match(to.msg, /Waktu habis/);
  const lama = await O.kirimOcr(conn, img, async () => ({ status: 400, text: JSON.stringify({ ok: false, error: 'Aksi tidak dikenal' }) })); assert.equal(lama.workerLama, true);
  assert.equal((await O.kirimOcr(conn, img, async () => null)).ok, false);
});
test('entriRiwayat: sumber ocr, tanpa isi teks, memakai usage Worker; tanpa usage = perkiraan (est)', () => {
  const e = O.entriRiwayat({ text: 'rahasia isi foto', usage: { in: 700, out: 12 } }, NOW); assert.deepEqual(e, { t: NOW, m: 'Baca teks foto', in: 700, out: 12, src: ['ocr'] }); assert.doesNotMatch(JSON.stringify(e), /rahasia/);
  const p = O.entriRiwayat({ text: 'a'.repeat(70) }, NOW); assert.equal(p.est, true); assert.equal(p.in, Math.ceil(O.OCR_EST_IN_CHARS / 3.5)); assert.equal(p.out, 20); assert.deepEqual(p.src, ['ocr']);
  assert.equal(O.entriRiwayat({ text: '' }, 'bukan angka'), null);
});
test('riwayat token mengenal sumber ocr (dan tetap membuang sumber asing); label tampil Baca foto', () => {
  const e = R.buatEntri({ now: NOW, pesan: 'x', usage: { in: 1, out: 1 }, sumber: ['ocr', 'ocr', 'catatan', 'tugas'] }); assert.deepEqual(e.src, ['ocr', 'tugas']);
  const s = mem(); R.catat(e, NOW, s); assert.deepEqual(R.muat(NOW, s)[0].src, ['ocr', 'tugas']);
  assert.match(src('src/js/ai/riwayatui.js'), /ocr: 'Baca foto'/);
});
test('bacaFoto: perkecil -> kirim -> catat token; hasil membawa ukuran; isi teks/foto TIDAK tersimpan', async () => {
  const s = mem(); let dipanggil = 0, f = null;
  const perkecil = async (file) => { dipanggil++; f = file; return img; };
  const r = await O.bacaFoto(conn, { name: 'a.jpg' }, { perkecil, http: async () => ({ status: 200, text: JSON.stringify(GOOD) }), now: NOW, store: s, limit: 100 });
  assert.equal(r.ok, true); assert.equal(r.text, 'Beli susu\nBeli roti'); assert.equal(r.w, 800); assert.equal(r.h, 600); assert.equal(r.bytes, 39); assert.equal(dipanggil, 1); assert.equal(f.name, 'a.jpg');
  const rw = R.muat(NOW, s); assert.equal(rw.length, 1); assert.deepEqual(rw[0].src, ['ocr']); assert.equal(rw[0].in, 700); assert.equal(rw[0].out, 12);
  const semua = JSON.stringify(s._m); assert.doesNotMatch(semua, /Beli susu/); assert.doesNotMatch(semua, new RegExp(JPEG.slice(0, 20).replace(/\//g, '\\/')));
  assert.deepEqual(Object.keys(s._m), [R.RW_KEY], 'hanya kunci riwayat token yang ditulis');
});
test('bacaFoto: foto kosong (tanpa teks) tetap dicatat; gagal perkecil/kirim = tidak dicatat, tidak melempar', async () => {
  const s = mem(), ok = (j) => async () => ({ status: 200, text: JSON.stringify(j) }), perkecil = async () => img;
  const e = await O.bacaFoto(conn, {}, { perkecil, http: ok({ ...GOOD, text: '', empty: true }), now: NOW, store: s }); assert.equal(e.ok, true); assert.equal(e.empty, true); assert.equal(R.muat(NOW, s).length, 1);
  const g1 = await O.bacaFoto(conn, {}, { perkecil: async () => { throw new Error('Foto tidak bisa dibuka. Gunakan JPG, PNG, atau WebP.'); }, http: ok(GOOD), now: NOW, store: s }); assert.equal(g1.ok, false); assert.match(g1.msg, /tidak bisa dibuka/);
  const g2 = await O.bacaFoto(conn, {}, { perkecil, http: async () => { throw new Error('boom'); }, now: NOW, store: s }); assert.equal(g2.ok, false);
  const g3 = await O.bacaFoto(conn, {}, { perkecil, http: async () => ({ status: 400, text: JSON.stringify({ ok: false, error: 'Aksi tidak dikenal' }) }), now: NOW, store: s }); assert.equal(g3.workerLama, true);
  const g4 = await O.bacaFoto(conn, {}, { perkecil: async () => { throw 'bukan Error'; }, http: ok(GOOD), now: NOW, store: s }); assert.equal(g4.ok, false);
  assert.equal(R.muat(NOW, s).length, 1, 'hanya yang berhasil dicatat');
  const sr = { getItem() { return null; }, setItem() { throw new Error('penuh'); } }; assert.equal((await O.bacaFoto(conn, {}, { perkecil, http: ok(GOOD), now: NOW, store: sr })).ok, true, 'riwayat gagal tidak membatalkan hasil');
});
test('perkecilFoto menolak berkas tak sah SEBELUM menyentuh DOM (Node tanpa createImageBitmap)', async () => {
  await assert.rejects(() => O.perkecilFoto({ type: 'application/pdf', name: 'a.pdf', size: 10 }), /bukan gambar/);
  await assert.rejects(() => O.perkecilFoto({ type: 'image/heic', name: 'a.heic', size: 10 }), /HEIC/);
  await assert.rejects(() => O.perkecilFoto({ type: 'image/jpeg', name: 'a.jpg', size: 31 * 1024 * 1024 }), /terlalu besar/);
});
test('kabel: MALAS (tidak ada jalur buka yang mengimpor ocr.js statis), dimuat lewat import() oleh perkecilFoto, tanpa console/penyimpanan foto', () => {
  const graph = staticGraph('js/main.js'); assert.equal(graph.includes('js/ai/ocr.js'), false, 'ocr.js tidak boleh masuk jalur buka');
  for (const f of readdirSync(new URL('../src/js', import.meta.url), { recursive: true }).filter((x) => /\.js$/.test(x) && x !== 'ai/ocr.js')) assert.doesNotMatch(src('src/js/' + f), /from '\.\/ocr\.js'|from '\.\/ai\/ocr\.js'/, f + ' tidak boleh mengimpor ocr.js statis sebelum UI (O3) memuatnya malas');
  const o = src('src/js/ai/ocr.js'); assert.match(o, /await import\('\.\.\/gambar-app\.js'\)/); assert.doesNotMatch(o, /console\./); assert.doesNotMatch(o, /localStorage\.setItem|sessionStorage|writeFile|IndexedDB/);
  assert.match(src('src/js/ai/sambungan.js'), /export async function nativeHttp\(/);
});
