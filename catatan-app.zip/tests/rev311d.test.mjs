// Rev 311d: teks sel lembar kerja > MAX_CELL (2000) tidak lagi dipotong diam-diam: ada dialog penjelasan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const ui = readFileSync(new URL('../src/js/lembar-ui.js', import.meta.url), 'utf8');
test('Rev 311d: pesan batas 2000 karakter ada di jalur simpan sel', () => {
  assert.ok(/String\(val\.value\)\.length > L\.MAX_CELL\) batas\('Teks dipotong'/.test(ui));
  assert.ok(/pecah ke beberapa sel/.test(ui));
});
test('Rev 311d: pesan muncul SEBELUM nilai diurai dan dipotong parseInput', () => {
  assert.ok(ui.indexOf("batas('Teks dipotong'") < ui.indexOf('next = pct ? pct.v : parseInput(val.value)'));
});
test('Rev 311d: batas isi sel tetap 2000 di model', () => {
  const m = readFileSync(new URL('../src/js/lembar.js', import.meta.url), 'utf8');
  assert.ok(/MAX_CELL = 2000/.test(m));
});
