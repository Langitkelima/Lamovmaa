// Rev 69: tugas dan sub-tugas diketik KAPITAL + tampilan pohon sub-tugas baru.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const main = src('src/js/main.js'), css = src('src/css/styles.css');

test('Rev 69: pengetikan kapital untuk judul tugas, sub-tugas, dan kolom tambah sub-tugas (sejak Rev 70 kebiasaan ikut)', () => {
  assert.match(main, /function capInput\(el\)/);
  assert.match(main, /autocapitalize', 'characters'/);
  assert.match(main, /capInput\(title\)/);
  assert.match(main, /capInput\(subIn\)/);
  assert.match(main, /capInput\(ti\)/);
  assert.match(main, /title: v\.value\.toUpperCase\(\)/);
  assert.match(main, /x\.title = String\(x\.title \|\| ''\)\.toUpperCase\(\)/);
});
test('Rev 69: judul tugas/sub-tugas lama ikut tampil kapital lewat CSS, kebiasaan juga (Rev 70)', () => {
  assert.match(main, /h\('b', \{ class: 'tcap' \}/);
  assert.match(main, /class: 'stt tcap'/);
  assert.match(css, /\.tcap,\.cap-in\{text-transform:uppercase\}/);
});
test('Rev 69: pohon sub-tugas: titik progres, rel melengkung, kartu per sub, tanpa blur/keyframes', () => {
  for (const k of ['.subdot', '.slist>.srow::before', '.srow.hasrem', '.subs::before']) assert.ok(css.includes(k), k);
  assert.ok(main.includes("class: 'subdot'") && main.includes("' hasrem'"));
  const blok = css.slice(css.indexOf('Rev 68'), css.indexOf('Rev 71: menu bawah'));
  assert.ok(!/backdrop-filter|blur\(|infinite|@keyframes/.test(blok));
});
