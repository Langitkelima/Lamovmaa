// Rev 386 / PART AL6: toast peringatan APK lama digeser ke ATAS layar agar kartu pilihan Notifikasi/Alarm tidak tertutup.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const PESAN = 'Versi aplikasi ini belum mendukung alarm berdering. Pengingat berbunyi sebagai notifikasi biasa.';
test('dua tempat pesan APK lama memakai tWarnAtas dengan teks yang sama; tidak ada tWarn/toast biasa untuk pesan itu', () => {
  for (const f of ['src/js/alarm-ui.js', 'src/js/settings.js']) { const s = rd(f); assert.ok(s.includes("tWarnAtas('" + PESAN + "')"), f); assert.ok(!s.includes("tWarn('" + PESAN), f); assert.match(s, /import \{[^}]*\btWarnAtas\b[^}]*\} from '\.\/ui\.js';/, f); }
});
test('ui.js: tWarnAtas ada, tanda tangan toast TIDAK berubah, toast atas tidak ikut tumpukan bawah dan tidak memakai id=toast', () => {
  const u = rd('src/js/ui.js');
  assert.ok(u.includes("export function toast(msg, undo, after, label = 'Urungkan', tone) {"));
  assert.match(u, /export const tWarnAtas = \(m\) => \{ tAtasOn = true; try \{ toast\(m, undefined, undefined, undefined, 'warn'\); \} finally \{ tAtasOn = false; \} \};/);
  assert.ok(u.includes("cur = atas ? null : $('#toast')"));
  assert.ok(u.includes("(atas ? ' ttop' : '')") && u.includes("atas ? {} : { id: 'toast' }"));
  assert.ok(u.includes('kb > 80 && !atas'));
});
test('CSS: .toast.ttop di atas (top + safe area), bottom auto, animasi dari atas', () => {
  const c = rd('src/css/styles.css');
  assert.match(c, /\.toast\.ttop\{bottom:auto;top:calc\(var\(--sat\) \+ 12px\);animation-name:tninAtas\}/);
  assert.match(c, /@keyframes tninAtas\{from\{opacity:0;transform:translateY\(-10px\)\}to\{opacity:1;transform:none\}\}/);
  assert.ok(c.indexOf('.toast.ttop{') > c.indexOf('.toast[class]{--tb:'), 'harus sesudah aturan dasar toast agar menang');
});
test('perilaku: toast atas tidak mengganggu toast bawah (id, tumpukan) dan toast biasa tetap sama', async () => {
  const u = rd('src/js/ui.js'); const i = u.indexOf('let tAtasOn'); const j = u.indexOf('// Rev 330 / TB');
  const body = u.slice(i, j);
  assert.ok(body.includes('const atas = tAtasOn'));
  assert.ok(!/id: 'toast'[^}]*atas/.test(body) || body.includes("atas ? {} : { id: 'toast' }"));
});
test('banner Rev 386 paling atas, kode tidak memuat penanda Rev 385 polos, versi 0.3.121, SCHEMA 22, README < 12000, tes terdaftar', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) { const d = rd(f); assert.ok(/^\*\*Rev (?:3[89]\d|4[0-3][0-9]) \/ v0\.3\.121/.test(d) && d.includes('**Rev 386 / v0.3.121'), f); assert.ok(d.indexOf('**Rev 386 /') < d.indexOf('**Rev 385 /'), f); for (const k of ['PART AL6', 'BELUM TERBUKTI', 'BERFUNGSI-BELUM-DIUJI']) assert.ok(d.slice(d.indexOf('**Rev 386 /'), d.indexOf('**Rev 385 /')).includes(k), f + ' ' + k); }
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.indexOf('rev384.test.mjs') < t.indexOf('rev386.test.mjs'));
  assert.equal(JSON.parse(rd('package.json')).version, '0.3.121'); assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.ok(rd('README.md').length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */);
});
