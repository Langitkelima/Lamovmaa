// Rev 73: alarm tagihan diatur di Notes (bil_<id>), pengingat lama Two Pockets tetap jalan bila belum diatur.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as al from '../src/js/tp-alarm.js';
import * as tp from '../src/js/twopockets.js';
const src = (f) => readFileSync(new URL(f, import.meta.url), 'utf8');
const at = (y, m, d, h = 0, mi = 0) => new Date(y, m - 1, d, h, mi, 0, 0).getTime();
const NOW = at(2026, 11, 7, 9, 0);
const bill = { id: 'b1', name: 'Listrik', nextDue: '2026-11-20', status: 'aman', remind: [] };
let n = 0; const t = (name, fn) => { fn(); n++; console.log('ok', name); };
t('tagihan tanpa pengaturan dan tanpa pengingat lama = bawaan 08.00, H-7 + Hari-H', () => {
  const p = al.planAlarms([], NOW, {}, [bill]);
  assert.deepEqual(p.map((x) => x.id), ['tpb:b1:w', 'tpb:b1:d']);
  assert.equal(p[0].at, at(2026, 11, 13, 8, 0)); assert.equal(p[1].at, at(2026, 11, 20, 8, 0));
});
t('pengaturan di Notes dipakai: jam 21.30, H-1 saja', () => {
  const p = al.planAlarms([], NOW, { bil_b1: { on: true, hour: 21, min: 30, before: [1], late: true } }, [bill]);
  assert.deepEqual(p.map((x) => x.id), ['tpb:b1:b1']); assert.equal(p[0].at, at(2026, 11, 19, 21, 30));
});
t('sakelar mati = tidak ada alarm', () => {
  assert.equal(al.planAlarms([], NOW, { bil_b1: { on: false } }, [bill]).length, 0);
});
t('terlambat + ulang = alarm tiap hari pada jam yang diatur', () => {
  const late = { ...bill, nextDue: '2026-11-01', status: 'terlambat' };
  const p = al.planAlarms([], NOW, { bil_b1: { on: true, hour: 7, min: 15, before: [0], late: true } }, [late]);
  assert.deepEqual(p.map((x) => x.id), ['tpb:b1:n']); assert.equal(p[0].at, at(2026, 11, 8, 7, 15));
});
t('pengingat lama Two Pockets tetap dipakai bila belum diatur di Notes', () => {
  const old = { ...bill, remind: [{ d: 0, t: '01:00' }] };
  const p = al.planAlarms([], NOW, {}, [old]);
  assert.deepEqual(p.map((x) => x.id), ['tpb:b1:b0']); assert.equal(p[0].at, at(2026, 11, 20, 1, 0));
  const v = al.billCfgView(old, {}); assert.equal(v.hour, 1); assert.deepEqual(v.before, [0]);
});
t('setItemCfg menyimpan pengaturan bawaan untuk tagihan (tidak jatuh ke pengingat lama)', () => {
  const m = new Map(); const store = { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) };
  const r = al.setItemCfg(al.billKey('b1'), { on: true, hour: 8, min: 0, before: [7, 0], late: true }, { now: NOW, store, api: null });
  assert.equal(r.ok, true); assert.ok(tp.loadAlarmCfg(store).bil_b1);
});
t('settings.js memakai kunci tagihan + versi 0.3.2', () => {
  const s = src('../src/js/settings.js');
  for (const k of ['billKey(b.id)', 'billCfgView', 'cfgOf', 'Notes Kelimaa v0.3.121']) assert.ok(s.includes(k), k);
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../RIWAYAT.md').includes('versi 0.3.2') || src('../RIWAYAT.md').includes('0.3.121'));
});
console.log('rev73:', n, 'ok');
