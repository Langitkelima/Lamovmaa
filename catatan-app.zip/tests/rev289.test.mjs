// Rev 289 / T4: kelompok templat "Rumus" bagian 2 (Logika dan syarat, Teks, Tanggal, Cari data): nilai kunci dihitung mesin rumus sungguhan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN);
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 14, 12, 0, 0).getTime();
const IDS = ['rumus-logika', 'rumus-teks', 'rumus-tanggal', 'rumus-cari'];
const mk = (id) => T.makeFromTemplate(id, { now: NOW });
const first = (id) => { const tab = mk(id).sheet.tabs[0]; return { tab, d: makeDisplay(tab) }; };
test('Rev 289: empat templat Rumus ada, nama <= 30, keterangan, Panduan terakhir, failed 0, muat batas, tanpa galat rumus', () => {
  const ids = T.templateList().map((t) => t.id); for (const id of IDS) assert.ok(ids.includes(id), id); assert.equal(new Set(ids).size, ids.length);
  for (const id of IDS) {
    const t = T.templateList().find((x) => x.id === id); assert.ok(t.name.startsWith('Rumus · ') && t.name.length <= 30 && t.desc.length >= 20 && t.desc.length <= 100, id);
    const r = mk(id); assert.ok(r, id); assert.equal(r.failed, 0, id); assert.ok(L.fitsLimit(r.sheet)); const tabs = r.sheet.tabs;
    assert.equal(tabs[tabs.length - 1].name, 'Panduan', id); assert.ok(tabs.length <= 5);
    for (const tab of tabs) { const d = makeDisplay(tab); for (let i = 0; i < tab.rows.length; i++) for (let j = 0; j < tab.cols.length; j++) assert.doesNotMatch(String(d.text(i, j)), /^#/, id + ' ' + L.cellAddr(j, i)); }
    assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(r.sheet)))), JSON.stringify(r.sheet), id);
  }
});
test('Rev 289: Logika = hasil kunci benar (Target, Bonus, Non-toko, Toko, 1.850.000, 4, 462.500, 1.600.000, 3) + Status per baris + 2 aturan warna', () => {
  const { tab, d } = first('rumus-logika');
  assert.deepEqual(Array.from({ length: 10 }, (_, i) => d.raw(i + 1, 6)), ['Target', 'Bonus', 'Non-toko', 'Toko', 'Tidak bisa dibagi', 1850000, 4, 462500, 1600000, 3]);
  assert.deepEqual(Array.from({ length: 8 }, (_, i) => d.raw(i + 1, 3)), ['Target', 'Belum', 'Target', 'Belum', 'Target', 'Target', 'Belum', 'Belum']); assert.equal(tab.rules.length, 2);
  L.setCell(tab, tab.rows[3].id, tab.cols[2].id, { v: 100 }); const d2 = makeDisplay(tab); assert.equal(d2.raw(3, 3), 'Belum'); assert.equal(d2.raw(6, 6), 1150100);
});
test('Rev 289: Teks = hasil kunci benar', () => {
  const { d } = first('rumus-teks');
  assert.deepEqual(Array.from({ length: 12 }, (_, i) => d.raw(i + 1, 3)), ['Budi Santoso', 'Budi, Santoso', 'Surat', '015', '2026', 13, 'BUDI SANTOSO', 'ani wulandari', 'Cici Permata', 1250, 'Budi', 'BS']);
});
test('Rev 289: Tanggal = hasil kunci benar (tanggal contoh tetap; TODAY/NOW ikut jam)', () => {
  const { d } = first('rumus-tanggal'), D0 = Date.UTC(1899, 11, 30), nw = new Date(), today = Math.floor((Date.UTC(nw.getFullYear(), nw.getMonth(), nw.getDate()) - D0) / 86400000); // Rev 300c: TODAY() memakai jam NYATA (bukan NOW tiruan), jadi 'hari ini' = tanggal sekarang; dulu dikunci 14 Nov 2026 sehingga gagal di hari lain
  assert.equal(d.raw(1, 3), today); assert.ok(Math.floor(d.raw(2, 3)) === today);
  assert.deepEqual([3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].map((i) => d.raw(i, 3)), [46381, 2026, 11, 14, 18, 15, 6, 52, 26, 5, 26]);
  assert.equal(d.raw(14, 3), 46370); assert.equal(d.raw(15, 3), 46340); assert.equal(String(d.text(16, 3)), '14 November 2026');
});
test('Rev 289: Cari data = hasil kunci benar; kode tak ada tidak galat; berubah saat isian diganti', () => {
  const { tab, d } = first('rumus-cari');
  assert.deepEqual(Array.from({ length: 8 }, (_, i) => d.raw(i + 1, 6)), ['Pulpen', 12000, 'Tidak ada', 5000, 4, 12000, 'C', 150]);
  L.setCell(tab, tab.rows[1].id, tab.cols[5].id, { v: 'K05' }); assert.equal(makeDisplay(tab).raw(1, 6), 'Map');
  L.setCell(tab, tab.rows[7].id, tab.cols[5].id, { v: 95 }); assert.equal(makeDisplay(tab).raw(7, 6), 'A');
});
test('Rev 289: modul data murni; hanya fungsi yang ada; urutan templat tetap; mesin dan settings tidak menyebut berkas data', () => {
  const s = src('src/js/templat-rumus-lanjut.js'); assert.doesNotMatch(s, /import |localStorage|document\.|window\.|eval\(|new Function/);
  const ada = new Set([...src('src/js/rumus.js').matchAll(/^\s{2}([A-Z][A-Z0-9]+): \{ min:/gm)].map((m) => m[1]));
  const used = new Set([...s.matchAll(/'(=[^']*)'/g)].flatMap((m) => [...m[1].matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1]))); assert.ok(used.size >= 25); for (const f of used) assert.ok(ada.has(f), f);
  const ids = T.templateList().map((t) => t.id); assert.equal(ids.length, 35); assert.deepEqual(ids.slice(5, 7), ['rumus-dasar', 'rumus-statistik']); assert.deepEqual(ids.slice(7, 11), IDS);
  for (const f of ['settings', 'lembar', 'lembar-ui', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /templat-rumus-lanjut/, f);
});
