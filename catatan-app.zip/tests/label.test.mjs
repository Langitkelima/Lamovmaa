// Tes Rev 24B: geser urutan label (Kelola Label). Urutan = urutan larik settings.labels, tanpa field baru (SCHEMA 8 sejak Rev 60).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/logic.js';
import * as S from '../src/js/storage.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const mk = () => ['a', 'b', 'c', 'd'].map((id) => ({ id, name: id.toUpperCase() }));
const ids = (a) => a.map((l) => l.id).join('');

await t('moveLabel: geser ke bawah, ke atas, ke ujung', () => {
  const a = mk(); assert.equal(L.moveLabel(a, 'a', 2), true); assert.equal(ids(a), 'bcad');
  assert.equal(L.moveLabel(a, 'd', 0), true); assert.equal(ids(a), 'dbca');
  assert.equal(L.moveLabel(a, 'd', 3), true); assert.equal(ids(a), 'bcad');
});
await t('moveLabel: posisi sama, id tak dikenal, tujuan di luar batas, nilai aneh', () => {
  const a = mk();
  assert.equal(L.moveLabel(a, 'b', 1), false); assert.equal(L.moveLabel(a, 'zz', 0), false);
  assert.equal(L.moveLabel(a, 'a', 99), true); assert.equal(ids(a), 'bcda');
  assert.equal(L.moveLabel(a, 'a', -5), true); assert.equal(ids(a), 'abcd');
  assert.equal(L.moveLabel(a, 'a', NaN), false); assert.equal(L.moveLabel(a, 'a', 'x'), false);
  assert.equal(L.moveLabel(null, 'a', 1), false); assert.equal(ids(a), 'abcd');
  const one = [{ id: 'x', name: 'X' }]; assert.equal(L.moveLabel(one, 'x', 0), false);
});
await t('moveLabel: mengubah larik di tempat (rujukan settings.labels tetap sama), tidak menggandakan atau menghilangkan label', () => {
  const a = mk(); const ref = a; L.moveLabel(a, 'b', 3);
  assert.equal(ref, a); assert.equal(a.length, 4); assert.equal(new Set(a.map((l) => l.id)).size, 4);
});
await t('urutan hasil geser dipakai chip filter dan label catatan (noteLabels)', () => {
  const a = mk(); L.moveLabel(a, 'c', 0); // c a b d
  const notes = [{ id: 'n1', labels: ['a', 'c', 'd'] }, { id: 'n2', labels: ['b'] }];
  const used = L.labelCounts(notes);
  assert.equal(ids(a.filter((l) => used[l.id])), 'cabd'); // persis cara viewNoteList menyusun chip
  assert.equal(ids(L.noteLabels(notes[0], a)), 'cad');
});
await t('urutan bertahan lewat normalize, simpan/muat, dan ekspor/impor cadangan; tanpa field baru', () => {
  const d = S.emptyData(); d.settings.labels = mk(); L.moveLabel(d.settings.labels, 'd', 0);
  const st = new Map(); const store = { getItem: (k) => st.get(k) ?? null, setItem: (k, v) => st.set(k, v) };
  assert.equal(S.save(d, store).ok, true);
  const back = S.load(store); assert.equal(ids(back.settings.labels), 'dabc');
  assert.deepEqual(Object.keys(back.settings.labels[0]).sort(), ['id', 'name']);
  const r = S.importJSON(S.exportJSON(d)); assert.equal(r.ok, true);
  assert.equal(S.SCHEMA, 22);
});
await t('hapus label setelah digeser: urutan sisanya tetap; label baru masuk paling bawah', () => {
  const data = S.emptyData(); data.settings.labels = mk(); L.moveLabel(data.settings.labels, 'c', 0);
  L.removeLabel(data, 'a'); assert.equal(ids(data.settings.labels), 'cbd');
  data.settings.labels.push({ id: 'e', name: 'E' }); assert.equal(ids(data.settings.labels), 'cbde');
});
await t('kode: geser hanya lewat pegangan (touch-action:none), pointer capture, papan tombol panah, simpan saat dilepas', () => {
  const s = src('../src/js/settings.js'); const c = src('../src/css/styles.css');
  assert.match(s, /setPointerCapture/); assert.match(s, /ArrowUp/); assert.match(s, /ArrowDown/);
  assert.match(s, /moveLabel\(labels, l\.id, to\)/); assert.match(s, /pointercancel/);
  assert.match(s, /ev\.type === 'pointerup'/); // batal (pointercancel) tidak mengubah urutan
  assert.match(c, /\.lbh\{[^}]*touch-action:none/);
  assert.doesNotMatch(c, /\.lbl\{[^}]*touch-action:none/);
});
console.log(n + ' tes lulus (label)');
