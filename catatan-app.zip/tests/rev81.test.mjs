import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const notes = read('../src/js/notes.js');
const css = read('../src/css/styles.css');
const pkg = JSON.parse(read('../package.json'));
test('Rev 81: panel Sisipkan memakai kartu 3 kolom dengan ikon SVG konsisten', () => {
  assert.match(notes, /const insertIcon = \(kind\)/);
  assert.match(notes, /const insertBtn = \(kind, label\)/);
  for (const kind of ['mood', 'quote', 'table', 'image']) assert.ok(notes.includes(`insertBtn('${kind}'`));
  assert.match(css, /\.fbar \.fmt \.tile svg\{width:23px/);
});
test('Rev 81: Kutipan, Tabel, Suasana hati dan Gambar tetap menuju handler lama', () => {
  for (const action of ['mood', 'quote', 'table', 'image']) assert.match(notes, new RegExp(`kind === '${action}'`));
  assert.match(notes, /kind === 'quote'\) toggleQuote\(\)/);
  assert.match(notes, /kind === 'table'\) openTableDialog\(\)/);
});
test('Rev 81: panel privat tidak menampilkan opsi Gambar dan versi tetap konsisten', () => {
  assert.match(notes, /\.\.\.\(isP \? \[\] : \[insertBtn\('image'/);
  assert.equal(pkg.version, '0.3.121');
  assert.match(read('../src/js/settings.js'), /v0\.3\.121/);
});
