// Rev 320 / PART U3: lebar kolom tabel (data-w) dihormati ekspor PDF/JPG dan "Ubah jadi lembar kerja". Pratinjau daftar, pencarian, dan cadangan memakai teks/HTML apa adanya (dicek statis).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseNoteHtml, layoutDoc } from '../src/js/export.js';
import { sheetFromMatrix } from '../src/js/lembar-pulau.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const o = { width: 600, padX: 20, size: 16, titleSize: 20, pageH: 800, measure: (s, { size }) => s.length * size * 0.5 };
const tbl = (attr) => `<div class="tbl-wrap"><table${attr}><tbody><tr><th>A</th><th>B</th><th>C</th></tr><tr><td>1</td><td>2</td><td>3</td></tr></tbody></table></div>`;
const dwOf = (h) => parseNoteHtml(h).find((b) => b.kind === 'table').dw;
const widthsOf = (html) => layoutDoc({ title: '', blocks: parseNoteHtml(html) }, o).find((l) => l.kind === 'tableRow').cells.map((c) => c.w);
test('Rev 320: parser membaca data-w yang sah dan menolak yang tidak sah', () => {
  assert.deepEqual(dwOf(tbl(' data-w="200,0,100"')), [200, 0, 100]);
  assert.equal(dwOf(tbl(' data-w="abc"')), null);
  assert.equal(dwOf(tbl('')), null);
  assert.equal(dwOf(tbl(' data-w="1,2,3,4,5,6,7,8,9"')), null);
});
test('Rev 320: ekspor memakai perbandingan lebar kolom; total tetap selebar halaman; tanpa data-w perilaku lama', () => {
  const w = widthsOf(tbl(' data-w="200,0,100"')), inner = o.width - o.padX * 2;
  assert.ok(Math.abs(w.reduce((a, x) => a + x, 0) - inner) < 0.5, 'total ' + w);
  assert.ok(w[0] > w[2] && w[2] < w[1] + 1 && w[0] / w[2] > 1.8 && w[0] / w[2] < 2.2, 'rasio 200:100 -> ' + w); // kolom otomatis = 105
  assert.ok(Math.abs(w[1] / w[2] - 1.05) < 0.05, 'kolom otomatis 105 -> ' + w);
  const base = widthsOf(tbl(''));
  assert.ok(Math.abs(base[0] - base[1]) < 1 && Math.abs(base[1] - base[2]) < 1, 'tanpa data-w sama seperti dulu: ' + base);
});
test('Rev 320: matriks tabel membawa lebar kolom ke lembar kerja baru (dijepit 40-320, 0 = bawaan)', () => {
  const m = [[{ v: 'A' }, { v: 'B' }, { v: 'C' }], [{ v: 1 }, { v: 2 }, { v: 3 }]]; m.w = [200, 0, 56];
  const sh = sheetFromMatrix(m, { name: 'Uji' }), cols = sh.tabs[0].cols;
  assert.equal(cols[0].w, 200); assert.equal(cols[2].w, 56); assert.equal(cols[1].w, 96);
  const plain = sheetFromMatrix([[{ v: 1 }]], { name: 'Uji2' }); assert.equal(plain.tabs[0].cols[0].w, 96);
});
test('Rev 320: matrixFromTable memanggil parseWidths/colCount; pratinjau daftar dan pencarian tidak memakai lebar (teks saja)', () => {
  const p = src('src/js/lembar-pulau.js');
  assert.match(p, /out\.w = parseWidths\(table\.getAttribute\('data-w'\) \|\| '', colCount\(table\)\)/);
  assert.match(p, /import \{ parseWidths, colCount \} from '\.\/tabel\.js'/);
});
test('Rev 320: SCHEMA, versi, anggaran tidak berubah', () => {
  assert.ok(src('package.json').includes('"version": "0.3.121"')); assert.ok(src('src/js/storage.js').includes('export const SCHEMA = 22;'));
  assert.match(src('tools/audit-ukuran.mjs'), /cssMaks: 270 \* 1024, jsMaks: 1600 \* 1024/);
});
