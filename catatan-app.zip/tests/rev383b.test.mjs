// Rev 383b / PART AL3d: dua toast peringatan alarm kini bernada eksplisit (tWarn). Perilaku dan teks pesan tidak berubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const PESAN = "Versi aplikasi ini belum mendukung alarm berdering. Pengingat berbunyi sebagai notifikasi biasa.";
test('alarm-ui.js dan settings.js memakai tWarn untuk pesan alarm tak didukung; teks pesan sama persis; tidak ada toast telanjang', () => {
  for (const f of ['src/js/alarm-ui.js', 'src/js/settings.js']) { const s = rd(f); assert.ok(s.includes("tWarn('" + PESAN + "')") || s.includes("tWarnAtas('" + PESAN + "')"), f); /* Rev 386: pesan ini kini tWarnAtas (toast di atas layar) */ assert.ok(!s.includes("toast('" + PESAN), f); }
});
test('alarm-ui.js mengimpor tWarn dari ui.js dan tidak lagi mengimpor toast yang tak terpakai; settings.js tetap mengimpor tWarn', () => {
  const a = rd('src/js/alarm-ui.js'); assert.match(a, /^import \{[^}]*\btWarn(Atas)?\b[^}]*\} from '\.\/ui\.js';$/m); assert.ok(!/^import \{[^}]*\btoast\b[^}]*\} from '\.\/ui\.js';$/m.test(a)); assert.ok(!/\btoast\(/.test(a));
  assert.match(rd('src/js/settings.js'), /import \{[^}]*\btWarn\b[^}]*\} from '\.\/ui\.js';/);
});
test('banner Rev 383b paling atas, package.json mendaftarkan rev383b sesudah rev383, versi 0.3.121 dan SCHEMA 22 tetap, README < 12000 huruf', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) { const d = rd(f); assert.ok(/\*\*Rev 383b \/ v0\.3\.121/.test(d), f); assert.ok(d.indexOf('**Rev 383b') < d.indexOf('**Rev 383 /'), f); }
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.indexOf('rev383.test.mjs') < t.indexOf('rev383b.test.mjs'));
  assert.equal(JSON.parse(rd('package.json')).version, '0.3.121'); assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/);
  const r = rd('README.md'); assert.ok(r.length < 12400, String(r.length)); assert.match(r, /Rev 383b/);
});
