// Rev 96 / U4a: bilah chip + chip tambah baris/kolom. Tes Node: fungsi murni dan kontrak sumber (perilaku DOM dicek terpisah di Chromium).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { tableLimits, insertIndex, TABLE_CHIPS, CHIP_BACK_ID, TABLE_EDIT_MAX_ROWS, TABLE_EDIT_MAX_COLS, TABLE_EDIT_MIN_ROWS, TABLE_EDIT_MIN_COLS } from '../src/js/bilah-chip.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 96: batas tambah/hapus baris dan kolom (50 x 8, minimal 2 x 2)', () => {
  assert.deepEqual([TABLE_EDIT_MAX_ROWS, TABLE_EDIT_MAX_COLS, TABLE_EDIT_MIN_ROWS, TABLE_EDIT_MIN_COLS], [50, 8, 2, 2]);
  assert.deepEqual(tableLimits(3, 3), { addRow: true, addCol: true, delRow: true, delCol: true });
  assert.deepEqual(tableLimits(50, 8), { addRow: false, addCol: false, delRow: true, delCol: true });
  assert.deepEqual(tableLimits(2, 2), { addRow: true, addCol: true, delRow: false, delCol: false });
  assert.equal(tableLimits(49, 7).addRow && tableLimits(49, 7).addCol, true);
});
test('Rev 96: indeks sisip bawah/atas dan sesudah/sebelum', () => {
  assert.equal(insertIndex(2, 'below'), 3); assert.equal(insertIndex(2, 'after'), 3);
  assert.equal(insertIndex(2, 'above'), 2); assert.equal(insertIndex(2, 'before'), 2);
  assert.equal(insertIndex(0, 'above'), 0); assert.equal(insertIndex(-5, 'below'), 1); assert.equal(insertIndex('x', 'below'), 1);
});
test('Rev 96: isi bilah chip U4a = empat chip struktur urut sesuai spesifikasi', () => {
  assert.deepEqual(TABLE_CHIPS.main.slice(0, 4).map((c) => c.id), ['row-below', 'row-above', 'col-before', 'col-after']); // Rev 97 menambah chip sesudahnya
  assert.deepEqual(TABLE_CHIPS.main.slice(0, 4).map((c) => c.label), ['＋ Baris bawah', '＋ Baris atas', '＋ Kolom kiri', '＋ Kolom kanan'] /* Rev 322: label dipendekkan */);
  assert.equal(CHIP_BACK_ID, '__back');
});
test('Rev 96: kontrak sumber komponen (pointer, bukan click; tidak mencuri fokus; sub-bilah Kembali)', () => {
  const s = src('src/js/bilah-chip.js');
  assert.match(s, /addEventListener\('pointerdown'/); assert.match(s, /addEventListener\('pointerup'/); assert.match(s, /addEventListener\('pointercancel'/);
  assert.match(s, /addEventListener\('mousedown', \(e\) => e\.preventDefault\(\)\)/);
  assert.match(s, /e\.detail === 0/);
  assert.match(s, /‹ Kembali/);
  assert.ok(!/eval\(|new Function|innerHTML = (?!'<br>')/.test(s.replace(/rep\.innerHTML = cell\.innerHTML;/, '')), 'tanpa eval dan tanpa innerHTML dari teks luar');
});
test('Rev 96: notes.js memasang bilah chip lewat DOM, urutan dock lama tetap', () => {
  const n = src('src/js/notes.js');
  assert.ok(n.includes("h('div', { class: 'dock' }, lp, rp, cp, pal, bar)"));
  assert.match(n, /o\.querySelector\('\.dock'\)\.insertBefore\(chipBar\.el, bar\)/);
  assert.match(n, /const tableChip = \(id\) =>/);
  assert.match(n, /chipBar\.hide\(\); o\.classList\.remove\('chips'\)/);
  assert.ok(!n.includes('data-table-action') && !n.includes('tableMenu')); // Rev 97: menu ▦ diganti chip
  // satu aksi = satu langkah Undo (cabang tambah baris/kolom)
  const fn = n.slice(n.indexOf('const tableChip ='), n.indexOf('const openTableDialog ='));
  const add = fn.slice(fn.indexOf('// ＋ Baris di bawah/atas'));
  assert.equal((add.match(/flushHist\(\)/g) || []).length, 2);
  assert.match(fn, /Maksimal ' \+ TABLE_EDIT_MAX_ROWS/); assert.match(fn, /Maksimal ' \+ TABLE_EDIT_MAX_COLS/);
});
test('Rev 96: CSS bilah chip (gulir mendatar, bilah bawah dipudarkan, tersembunyi di mode Baca)', () => {
  const c = src('src/css/styles.css');
  assert.match(c, /\.chipbar \.chips\{[^}]*overflow-x:auto[^}]*touch-action:pan-x/);
  assert.match(c, /\.fs\.chips \.fbar\{opacity:\.55\}/);
  assert.match(c, /\.fs\.ed-baca \.chipbar\{display:none!important\}/);
  assert.match(c, /\.chip\.on\{background:var\(--ink\)/);
});
test('Rev 96: versi 0.3.121, SCHEMA 9, native dan dependensi tidak berubah', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.deepEqual(Object.keys(JSON.parse(src('package.json')).dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(JSON.parse(src('package.json')).scripts.test.includes('node tests/rev96.test.mjs'));
});
