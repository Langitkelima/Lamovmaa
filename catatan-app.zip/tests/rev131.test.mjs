// Rev 131 / U8a-4c: ketuk sel saat mengetik rumus menyisipkan rujukan (refSlot/insertRef/extendRange murni + kabel UI).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { refSlot, insertRef, extendRange } from '../src/js/rumus-bantu.js';
import { a1ToStored } from '../src/js/rumus.js';
import * as L from '../src/js/lembar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('refSlot: slot hanya di posisi rujukan yang masuk akal', () => {
  for (const t of ['=', '=SUM(', '=SUM(A1;', '=A1+', '=1*', '=IF(A1>', '=A1,', '=SUM( ']) assert.equal(refSlot(t, t.length).kind, 'new', t);
  for (const t of ['abc', '5', '=SU', '=SUM(A1)', '=5', '=1+2', '=IF(A1="x', '=SUM(A1)+SUM']) assert.equal(refSlot(t, t.length), null, t);
  assert.deepEqual(refSlot('=SUM(A1', 7), { start: 5, end: 7, kind: 'ref' }); assert.equal(refSlot('=$B$2', 5).kind, 'ref');
  assert.deepEqual(refSlot('=SUM(A1:', 8), { start: 8, end: 8, kind: 'rangeEnd' }); assert.deepEqual(refSlot('=SUM(A1:B3', 10), { start: 8, end: 10, kind: 'rangeEnd' });
});
test('insertRef: sisip, tunjuk ulang, ujung rentang; masukan tidak sah = tidak berubah', () => {
  assert.deepEqual(insertRef('=', 1, 'B2'), { text: '=B2', caret: 3 }); assert.deepEqual(insertRef('=SUM(', 5, 'A1:A3'), { text: '=SUM(A1:A3', caret: 10 });
  assert.deepEqual(insertRef('=A1+', 4, 'C5'), { text: '=A1+C5', caret: 6 }); assert.deepEqual(insertRef('=B2', 3, 'C3'), { text: '=C3', caret: 3 });
  assert.deepEqual(insertRef('=SUM(A1:', 8, 'A9'), { text: '=SUM(A1:A9', caret: 10 }); assert.deepEqual(insertRef('=SUM(A1:A3', 10, 'B9'), { text: '=SUM(A1:B9', caret: 10 });
  assert.deepEqual(insertRef('=SUM(A1)', 8, 'B2'), { text: '=SUM(A1)', caret: 8 }); assert.deepEqual(insertRef('=', 1, 'bukan rujukan'), { text: '=', caret: 1 }); assert.deepEqual(insertRef('abc', 3, 'A1'), { text: 'abc', caret: 3 });
  assert.deepEqual(insertRef('=(A1+)', 5, 'B2'), { text: '=(A1+B2)', caret: 7 }); // kursor di tengah: sisa teks sesudah kursor dipertahankan
});
test('extendRange: hanya sesudah rujukan tunggal', () => {
  assert.deepEqual(extendRange('=SUM(A1', 7), { text: '=SUM(A1:', caret: 8 }); assert.deepEqual(extendRange('=SUM(', 5), { text: '=SUM(', caret: 5 }); assert.deepEqual(extendRange('=SUM(A1:', 8), { text: '=SUM(A1:', caret: 8 });
});
test('alur ketuk: =SUM( + ketuk A1 + Rentang + ketuk A3 + ) lolos a1ToStored', () => {
  const t = L.newTab('T', 5); let r = insertRef('=SUM(', 5, 'A1'); r = extendRange(r.text, r.caret); r = insertRef(r.text, r.caret, 'A3');
  assert.equal(r.text, '=SUM(A1:A3'); assert.equal(a1ToStored(r.text + ')', t).ok, true);
});
test('kabel lembar-ui: pointerdown menjaga fokus, click fase tangkap menyisipkan; pick lama tidak diubah; modul murni', () => {
  const u = src('src/js/lembar-ui.js'), m = src('src/js/rumus-bantu.js');
  assert.match(u, /refSlot, insertRef, extendRange/); assert.match(u, /tapRef = true; e\.preventDefault\(\)/); assert.match(u, /e\.stopImmediatePropagation\(\)/);
  assert.match(u, /insertRef\(val\.value, val\.selectionStart, addr\)/); assert.match(u, /\}, true\);\n  scroller\.addEventListener\('scroll'/);
  assert.match(u, /scroller\.addEventListener\('click', pick\);/); assert.match(u, /'Rentang :'/);
  assert.doesNotMatch(m, /document|window|localStorage|eval\(|new Function/);
});
test('Rev 131: versi 0.3.121, SCHEMA 13 (naik di Rev 132), tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev131.test.mjs'));
});
