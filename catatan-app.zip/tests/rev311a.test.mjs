// Rev 311a: toast bernada, dialog info (malas), validasi form tugas/pengingat sub-tugas tampil sebagai dialog.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { toastTone, toastMs } from '../src/js/ui.js';
const R = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const lum = (hex) => { const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
const cr = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };

test('toastTone: nada otomatis dari isi pesan', () => {
  assert.equal(toastTone('Waktu pengingat harus di masa depan'), 'warn');
  assert.equal(toastTone('Gagal membuka berkas'), 'err');
  assert.equal(toastTone('Tersimpan'), 'ok');
  assert.equal(toastTone('Catatan dipindah'), 'ok'); // Rev 312b: kata kerja sukses (dipindah, dibuat, dst.) kini ok
  assert.equal(toastTone('Pilih sel dulu'), 'warn');
});
test('toastMs: peringatan dan galat lebih lama; pesan panjang lebih lama; ada batas', () => {
  assert.ok(toastMs('a', 'err') > toastMs('a', 'warn') && toastMs('a', 'warn') > toastMs('a', 'info'));
  assert.ok(toastMs('x'.repeat(120), 'info') > toastMs('x', 'info'));
  assert.ok(toastMs('x'.repeat(5000), 'err') <= 14000);
  assert.ok(toastMs('a', 'info', true) >= 6000);
});
test('CSS toast: warna nada kontras >= 4,5:1, di atas dialog, ada animasi dan reduced-motion', () => {
  const css = R('src/css/styles.css');
  assert.ok(cr('#0B7A52', '#FFFFFF') >= 4.5); assert.ok(cr('#C42340', '#FFFFFF') >= 4.5); assert.ok(cr('#FFC83D', '#2B1D00') >= 4.5);
  for (const k of ['.toast.tn-ok,.idl.tn-ok{--tb:rgb(11,122,82)', '.toast.tn-warn,.idl.tn-warn{--tb:rgb(255,200,61)', '.toast.tn-err,.idl.tn-err{--tb:rgb(196,35,64)', '.toast[class]{--tb:var(--ac)', 'z-index:80', 'prefers-reduced-motion:reduce){.toast[class]']) assert.ok(css.includes(k), k);
  assert.ok(80 > 60, 'toast di atas .dlgov (60)');
});
test('ui.js: toast punya tutup, naik di atas keyboard, infoDlg malas, Kembali HP menutup dialog info', () => {
  const u = R('src/js/ui.js');
  assert.match(u, /aria-label': 'Tutup'/); assert.match(u, /visualViewport/); assert.match(u, /import\('\.\/ui-info\.js'\)/);
  assert.match(u, /button\.line,\.dlgb button\[data-close\]/);
  assert.match(R('src/js/ui-info.js'), /data-close/);
});
test('main.js: semua penolakan simpan tugas memakai dialog; waktu lampau di-pilih langsung ditolak', () => {
  const m = R('src/js/main.js');
  assert.ok((m.match(/refuse\(/g) || []).length >= 4);
  assert.match(m, /refusePast\(t, sb\.title\)/); assert.match(m, /remAt\.addEventListener\('change'/);
  assert.ok(!/err\.textContent = '(Judul|Nama|Pilih waktu|Pengingat per)/.test(m), 'tak ada lagi pesan err tanpa dialog');
});
