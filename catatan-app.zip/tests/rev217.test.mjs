// Rev 215 / v0.3.121: Kelimaa AI pindah dari Setelan ke bilah bawah (tab tengah: Tugas, Catatan, AI, Private, Setelan).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { navShape } from '../src/js/logic.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('bilah bawah: 5 tab, AI tepat di tengah antara Catatan dan Private', () => {
  const m = src('src/js/main.js');
  assert.ok(m.includes("[['tugas', 'Tugas'], ['catatan', 'Catatan'], ['ai', 'Kelimaa AI'], ['privat', 'Private'], ['lainnya', 'Setelan']]"));
  assert.match(m, /ui\.tab === 'ai' \? viewKelimaaAI\(ctx\)/);
  assert.match(m, /id === 'ai' \? PATH\.star/);
});
test('penanda aktif selebar 1/5 di semua aturan CSS navind; tidak ada sisa 1/4', () => {
  const c = src('src/css/styles.css');
  assert.doesNotMatch(c, /\.navind\{[^}]*\/ 4\)/);
  assert.equal((c.match(/\/ 5\)/g) || []).length >= 3, true);
  assert.match(c, /width:calc\(\(100% - 12px\) \/ 5\)/);
});
test('navShape: bawaan 4 tab tidak berubah, opsi tabs:5 bergeser sesuai', () => {
  assert.equal(navShape(332, 66, 1), navShape(332, 66, 1, { tabs: 4 }));
  assert.notEqual(navShape(332, 66, 1), navShape(332, 66, 1, { tabs: 5 }));
  assert.ok(!/NaN|Infinity/.test(navShape(332, 66, 2, { tabs: 5 })));
});
test('Setelan tidak lagi punya ubin/rute AI; layar AI memakai gaya sub-layar Setelan', () => {
  const st = src('src/js/settings.js'), m = src('src/js/main.js');
  assert.doesNotMatch(st, /KELIMAA AI', aiTileText|moreView = 'ai'/);
  assert.match(st, /export function viewKelimaaAI/); assert.match(st, /function aiReady\(\)/);
  assert.match(m, /dataset\.tab = ui\.tab === 'ai' \? 'lainnya'/);
  assert.match(src('src/js/ai/layar.js'), /ui\.tab === 'ai' && ui\.aiFrom === 'chat' \? 'Kembali ke chat' : 'Buka chat'/); // Rev 310a: satu tombol chat (Buka chat dan Kembali ke chat disatukan)
});
