// Rev 352 / PART O1: aksi `ocr` di Worker (Gemini native + gambar inline). Fetch PALSU; KV tiruan. BUKAN bukti dari Gemini nyata (bentuk permintaan mengikuti dokumentasi, belum dicoba di server nyata).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), GEMINI_KEY: 'gm-FAKE-0123456789-tes', RETRY_MS: [1, 1], ...x });
const NOW = Date.UTC(2026, 10, 19, 5, 0, 0);
// Gambar tiruan: JPEG (FF D8 FF E0 ...) dan WebP (RIFF....WEBP) cukup untuk lolos pemeriksaan tanda awal berkas.
const JPG = Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(200, 7)]).toString('base64');
const WEBP = Buffer.concat([Buffer.from('RIFF'), Buffer.from([0x20, 0, 0, 0]), Buffer.from('WEBPVP8 '), Buffer.alloc(200, 3)]).toString('base64');
const PNG = Buffer.concat([Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]), Buffer.alloc(200, 1)]).toString('base64');
const req = (o = {}, h = {}) => new Request('https://w.example/', { method: 'POST', headers: h, body: JSON.stringify({ key: 'rama-secret-12', action: 'ocr', mime: 'image/jpeg', image: JPG, ...o }) });
const GEM = (text, um = { promptTokenCount: 300, candidatesTokenCount: 40 }, fin = 'STOP') => ({ candidates: [{ content: { role: 'model', parts: [{ text }] }, finishReason: fin }], usageMetadata: um });
// Jalankan satu permintaan dengan fetch palsu; `answers` = daftar jawaban {status, body} berurutan (yang terakhir diulang).
async function run(env, o, answers, h) {
  const orig = globalThis.fetch, calls = [];
  globalThis.fetch = async (url, init) => { calls.push({ url: String(url), init, body: JSON.parse(init.body) }); const a = answers[Math.min(calls.length - 1, answers.length - 1)]; return { ok: a.status < 400, status: a.status, json: async () => a.body }; };
  try { const r = await T.handle(req(o, h), env, NOW); return { status: r.status, j: await r.json(), calls }; } finally { globalThis.fetch = orig; }
}
const OK = (t, um, fin) => [{ status: 200, body: GEM(t, um, fin) }];

test('ocr: foto JPEG dibaca; permintaan ke Gemini native memuat inline_data + petunjuk sistem; jatah 1; hasil + usage', async () => {
  const e = env0(), r = await run(e, {}, OK('Beli susu\nBeli telur'));
  assert.equal(r.status, 200); assert.equal(r.j.ok, true); assert.equal(r.j.task, 'ocr.read'); assert.equal(r.j.text, 'Beli susu\nBeli telur');
  assert.equal(r.j.provider, 'gemini'); assert.equal(r.j.model, 'gemini-3.5-flash'); assert.deepEqual(r.j.usage, { in: 300, out: 40 });
  assert.equal(r.j.used, 1); assert.ok(!('empty' in r.j) && !('truncated' in r.j));
  assert.equal(r.calls.length, 1); const c = r.calls[0];
  assert.match(c.url, /^https:\/\/generativelanguage\.googleapis\.com\/v1beta\/models\/gemini-3\.5-flash:generateContent$/);
  assert.equal(c.init.headers['x-goog-api-key'], 'gm-FAKE-0123456789-tes'); assert.ok(!('Authorization' in c.init.headers));
  const parts = c.body.contents[0].parts; assert.deepEqual(parts[0], { inline_data: { mime_type: 'image/jpeg', data: JPG } }); assert.equal(typeof parts[1].text, 'string'); // gambar dulu, teks sesudahnya
  assert.equal(c.body.systemInstruction.parts[0].text, T.SYSTEM_OCR); assert.ok(c.body.generationConfig.maxOutputTokens >= 4000); assert.ok(!('temperature' in c.body.generationConfig));
});
test('ocr: WebP dan alias image/jpg diterima; PNG, GIF, tanpa mime, dan campur-aduk ditolak 400 TANPA memakai jatah', async () => {
  const e = env0();
  assert.equal((await run(e, { mime: 'image/webp', image: WEBP }, OK('x'))).status, 200);
  assert.equal((await run(e, { mime: 'IMAGE/JPG' }, OK('x'))).status, 200);
  const e2 = env0(); let n = 0;
  for (const o of [{ mime: 'image/png', image: PNG }, { mime: 'image/gif' }, { mime: undefined }, { mime: 'image/jpeg', image: WEBP }, { mime: 'image/webp', image: JPG }, { mime: 'image/jpeg', image: PNG }]) { const r = await run(e2, o, OK('x')); assert.equal(r.status, 400, JSON.stringify(Object.keys(o))); assert.equal(r.calls.length, 0); n++; }
  assert.equal(n, 6); assert.equal(e2.KV.m.size, 0, 'tidak ada jatah dipakai');
});
test('ocr: gambar rusak ditolak sebelum jatah dipakai: kosong, pendek, awalan data:, bukan base64, panjang bukan kelipatan 4', async () => {
  const e = env0(), bad = [undefined, '', 'abc', 123, 'data:image/jpeg;base64,' + JPG, JPG.slice(0, -1), JPG.slice(0, 40) + '!!!!' + JPG.slice(44), ' ' + JPG, JPG + '\n'];
  for (const image of bad) { const r = await run(e, { image }, OK('x')); assert.equal(r.status, 400, String(image).slice(0, 20)); assert.equal(r.calls.length, 0); }
  assert.equal(e.KV.m.size, 0);
  assert.match((await run(e, { image: 'data:image/jpeg;base64,' + JPG }, OK('x'))).j.error, /tanpa awalan data:/);
});
test('ocr: gambar > batas base64 = 413; tepat di batas lolos; badan > 600000 = 413; Content-Length raksasa = 413 tanpa membaca badan', async () => {
  const e = env0(), big = 'A'.repeat(T.MAX_OCR_B64 + 4);
  const r = await run(e, { image: big }, OK('x')); assert.equal(r.status, 413); assert.equal(r.calls.length, 0);
  // tepat di batas: JPEG sah yang diperpanjang sampai persis MAX_OCR_B64 huruf
  const body = Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF]), Buffer.alloc(T.MAX_OCR_B64 / 4 * 3 - 3, 5)]).toString('base64'); assert.equal(body.length, T.MAX_OCR_B64);
  const ok = await run(env0(), { image: body }, OK('besar')); assert.equal(ok.status, 200); assert.equal(ok.calls.length, 1); assert.equal(ok.calls[0].body.contents[0].parts[0].inline_data.data.length, T.MAX_OCR_B64);
  assert.equal((await run(env0(), { pad: 'x'.repeat(T.MAX_OCR_BODY) }, OK('x'))).status, 413);
  let dibaca = false; const q = req({}, { 'Content-Length': '999999' }), asli = q.text.bind(q); Object.defineProperty(q, 'text', { value: () => { dibaca = true; return asli(); } });
  assert.equal((await T.handle(q, env0(), NOW)).status, 413); assert.equal(dibaca, false);
});
test('ukuran aksi LAIN tidak berubah: whoami > 4096 = 413; chat > 90000 = 413; JSON rusak > 90000 = 413; gambar besar di aksi selain ocr = 413; chat wajar tetap 200', async () => {
  const post = (o) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', ...o }) });
  const e = env0();
  assert.equal((await T.handle(post({ action: 'whoami', pad: 'x'.repeat(5000) }), e, NOW)).status, 413);
  assert.equal((await T.handle(post({ action: 'chat', task: 'chat.general', messages: [{ role: 'user', content: 'a' }], pad: 'x'.repeat(91000) }), e, NOW)).status, 413);
  assert.equal((await T.handle(post({ action: 'research', messages: [{ role: 'user', content: 'a' }], image: JPG.repeat(400) }), e, NOW)).status, 413);
  assert.equal((await T.handle(post({ action: 'whoami', image: JPG.repeat(200) }), e, NOW)).status, 413);
  const bukanJson = new Request('https://w.example/', { method: 'POST', body: 'x'.repeat(95000) }); assert.equal((await T.handle(bukanJson, e, NOW)).status, 413);
  const kecil = new Request('https://w.example/', { method: 'POST', body: '{' + 'x'.repeat(2000) }); assert.equal((await T.handle(kecil, e, NOW)).status, 400);
});
test('ocr: passcode salah = 401 (dan dicatat sebagai percobaan gagal) walau badan besar; tanpa GEMINI_KEY = 503 TANPA jatah', async () => {
  const e = env0(), r = await T.handle(req({ key: 'salah-salah-1' }), e, NOW); assert.equal(r.status, 401);
  const e2 = env0({ GEMINI_KEY: undefined, SAKELAR_KEY: 'sk-FAKE-0123456789-tes' }), r2 = await run(e2, {}, OK('x')); assert.equal(r2.status, 503); assert.match(r2.j.error, /GEMINI_KEY/); assert.equal(r2.calls.length, 0); assert.equal(e2.KV.m.size, 0);
});
test('ocr: batas harian dan bulanan berlaku; satu permintaan = satu jatah; token bulanan tercatat; tanpa KV + batas = ditolak', async () => {
  const e = env0(); await run(e, { limit: 2 }, OK('a')); const r2 = await run(e, { limit: 2 }, OK('b')); assert.equal(r2.j.used, 2);
  const r3 = await run(e, { limit: 2 }, OK('c')); assert.equal(r3.status, 429); assert.equal(r3.calls.length, 0); assert.match(r3.j.error, /Batas harian/);
  const e2 = env0(), a = await run(e2, { monthLimit: 5 }, OK('a', { promptTokenCount: 100, candidatesTokenCount: 10, thoughtsTokenCount: 50 }));
  assert.deepEqual(a.j.usage, { in: 100, out: 60 }); assert.deepEqual(a.j.monthTokens, { in: 100, out: 60 }); assert.equal(a.j.monthUsed, 1);
  const e3 = env0({ KV: undefined }); const nk = await run(e3, { limit: 5 }, OK('x')); assert.equal(nk.status, 503); assert.equal(nk.calls.length, 0);
  assert.equal((await run(e3, { limit: 0 }, OK('x'))).status, 200); // Tanpa batas tidak butuh KV
  const cap = env0({ HARD_DAILY_LIMIT: '1' }); await run(cap, { limit: 0 }, OK('a')); assert.equal((await run(cap, { limit: 0 }, OK('b'))).status, 429); // plafon server tidak bisa dilewati
});
test('ocr: TIDAK_ADA_TEKS jadi empty:true dengan teks kosong (bukan galat, jatah terpakai); pagar kode dibuang; MAX_TOKENS = truncated; teks > 20000 dipotong', async () => {
  const a = await run(env0(), {}, OK(' TIDAK_ADA_TEKS. ')); assert.equal(a.status, 200); assert.equal(a.j.empty, true); assert.equal(a.j.text, ''); assert.equal(a.j.used, 1);
  assert.equal((await run(env0(), {}, OK('`TIDAK_ADA_TEKS`'))).j.empty, true);
  const b = await run(env0(), {}, OK('```\nbaris 1\nbaris 2\n```')); assert.equal(b.j.text, 'baris 1\nbaris 2');
  const c = await run(env0(), {}, OK('terpotong di sini', undefined, 'MAX_TOKENS')); assert.equal(c.j.truncated, true); assert.equal(c.j.text, 'terpotong di sini');
  const d = await run(env0(), {}, OK('x'.repeat(25000))); assert.equal(d.j.text.length, 20000); assert.equal(d.j.truncated, true);
  const p = T.parseOcr({ candidates: [{ content: { parts: [{ text: 'pikir', thought: true }, { text: 'hasil' }] } }] }); assert.equal(p.text, 'hasil'); // bagian pikir dibuang
});
test('ocr: jawaban kosong / diblokir = 502 berpenjelasan; galat penyedia dipetakan (kunci ditolak 502, kena batas 503) tanpa membocorkan kunci', async () => {
  const k = await run(env0(), {}, [{ status: 200, body: { candidates: [{ content: { parts: [] }, finishReason: 'SAFETY' }] } }]); assert.equal(k.status, 502); assert.match(k.j.error, /SAFETY/);
  const b = await run(env0(), {}, [{ status: 200, body: { promptFeedback: { blockReason: 'OTHER' } } }]); assert.equal(b.status, 502); assert.match(b.j.error, /OTHER/);
  const t = await run(env0(), {}, [{ status: 403, body: { error: { message: 'API key bad AIzaSyA-FAKE-FAKE-FAKE-FAKE-1234567' } } }]); assert.equal(t.status, 502); assert.match(t.j.error, /GEMINI_KEY/); assert.ok(!t.j.error.includes('AIzaSyA'));
  const l = await run(env0(), {}, [{ status: 429, body: { error: { message: 'quota' } } }]); assert.equal(l.status, 503);
  const g = await run(env0(), {}, [{ status: 400, body: { error: { message: 'Unable to process input image' } } }]); assert.equal(g.status, 502); assert.match(g.j.error, /menolak permintaan/);
});
test('ocr: galat sementara (503) dicoba ulang; bila tetap gagal beralih ke model cadangan; tidak pindah ke jalur lain (hanya Gemini untuk gambar)', async () => {
  const a = await run(env0(), {}, [{ status: 503, body: { error: { message: 'busy' } } }, { status: 200, body: GEM('pulih') }]); assert.equal(a.status, 200); assert.equal(a.calls.length, 2); assert.equal(a.j.model, 'gemini-3.5-flash'); assert.ok(!('fallbackFrom' in a.j));
  const b = await run(env0(), {}, [{ status: 503, body: {} }, { status: 503, body: {} }, { status: 503, body: {} }, { status: 200, body: GEM('lite') }]); assert.equal(b.status, 200); assert.equal(b.j.model, 'gemini-3.5-flash-lite'); assert.equal(b.j.fallbackFrom, 'gemini-3.5-flash');
  const e = env0({ SAKELAR_KEY: 'sk-FAKE-0123456789-tes' }); const c = await run(e, {}, [{ status: 503, body: {} }]); assert.equal(c.status, 503);
  assert.ok(c.calls.every((x) => x.url.startsWith('https://generativelanguage.googleapis.com/')), 'tidak ada panggilan ke penyedia lain');
});
test('ocr: pilihan model: MODEL_OCR > MODEL_GEMINI > bawaan; model dari aplikasi divalidasi bentuknya (dan tidak diam-diam diganti)', async () => {
  assert.match((await run(env0({ MODEL_OCR: 'gemini-x-ocr', MODEL_GEMINI: 'gemini-y' }), {}, OK('a'))).calls[0].url, /models\/gemini-x-ocr:generateContent$/);
  assert.match((await run(env0({ MODEL_GEMINI: 'gemini-y' }), {}, OK('a'))).calls[0].url, /models\/gemini-y:generateContent$/);
  assert.match((await run(env0({ MODEL_OCR: 'x' }), {}, OK('a'))).calls[0].url, /models\/gemini-3\.5-flash:generateContent$/); // nama rusak diabaikan
  assert.match((await run(env0(), { model: 'gemini-z-9' }, OK('a'))).calls[0].url, /models\/gemini-z-9:generateContent$/);
  const bad = await run(env0(), { model: 'a b!' }, OK('a')); assert.equal(bad.status, 400); assert.equal(bad.calls.length, 0);
});
test('privasi di sumber: gambar tidak masuk KV dan tidak dicatat; tidak ada console di Worker; komentar Rev 352 ada; chat/research tidak disentuh', async () => {
  const w = src('backend/cloudflare/worker.mjs'); assert.ok(w.includes('Rev 352 / PART O1')); assert.doesNotMatch(w, /console\./);
  const e = env0(); await run(e, {}, OK('Rahasia sekali')); for (const [k, v] of e.KV.m) { assert.ok(!String(v).includes(JPG) && !String(v).includes('Rahasia'), k); assert.ok(!k.includes(JPG.slice(0, 20))); }
  assert.deepEqual([...e.KV.m.keys()].sort().map((k) => k.split(':')[0]), ['use']); // hanya penghitung harian
  const ocrSrc = w.slice(w.indexOf('async function ocr('), w.indexOf('async function chat(')); assert.doesNotMatch(ocrSrc, /KV\.put|KV\.get/); // jatah lewat consume(), bukan langsung
  assert.match(w, /MAX_CHAT_BODY = 90000/); assert.match(w, /MAX_MSG_CHARS = 16000/); assert.match(w, /const MAX_BODY = 4096/);
});
test('whoami dan chat tetap jalan di Worker baru (regresi)', async () => {
  const e = env0(), post = (o) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', ...o }) });
  const w = await T.handle(post({ action: 'whoami' }), e, NOW); assert.equal(w.status, 200); assert.equal((await w.json()).ok, true);
  const orig = globalThis.fetch; globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'Halo' } }], usage: { prompt_tokens: 3, completion_tokens: 1 } }) });
  try { const c = await T.handle(post({ action: 'chat', task: 'chat.general', messages: [{ role: 'user', content: 'hai' }] }), e, NOW); const j = await c.json(); assert.equal(c.status, 200); assert.equal(j.text, 'Halo'); } finally { globalThis.fetch = orig; }
  assert.equal((await T.handle(post({ action: 'tidak-ada' }), e, NOW)).status, 400);
});
test('dokumen: banner Rev 352 di PROMPT_SERAH_TERIMA dan RIWAYAT; panduan Worker menyebut ocr, GEMINI_KEY, MODEL_OCR; tes terdaftar; kode aplikasi tidak disentuh', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) { const d = src(f), i = d.indexOf('**Rev 352 / v0.3.121'); assert.ok(i >= 0 && i > d.indexOf('**Rev 353 /') && d.indexOf('**Rev 353 /') >= 0 && i < d.indexOf('**Rev 351 /'), f); /* Rev 383: batas posisi mutlak (66.000) diganti pengecekan URUTAN (353 di atas 352 di atas 351) karena angka mutlak usang tiap ada revisi baru */ /* Rev 377: batas 60.000 -> 66.000 (DISENGAJA; banner Rev 375-377 menambah di atas) */ /* Rev 371: batas 52.000 -> 60.000 (DISENGAJA; banner Rev 368-371 menambah di atas; batas 40.000 asli Rev 363) */ /* Rev 363: batas 28.000 -> 34.000 (DISENGAJA; banner Rev 363 menambah di atas) */ /* Rev 361: batas 24.000 -> 28.000 (DISENGAJA; banner Rev 361 menambah di atas) */ /* Rev 359: batas 20.000 -> 24.000 (DISENGAJA; banner checkpoint Rev 359 menambah di atas, banner Rev 352 ada di sekitar 21.100) */ /* Rev 353: banner Rev 352 tidak lagi paling atas (banner Rev 353 di atasnya), tetap dalam 20.000 huruf pertama */ assert.match(d.slice(i, i + 12000), /PART O1/); assert.match(d.slice(i, i + 12000), /BERFUNGSI-BELUM-DIUJI/); }
  const g = src('backend/cloudflare/PANDUAN_WORKER.md'); assert.match(g, /Aksi baca teks dari foto/); assert.match(g, /MODEL_OCR/); assert.match(g, /GEMINI_KEY/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev352\.test\.mjs/); assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/); assert.match(src('tools/audit-ukuran.mjs'), /cssMaks: 270 \* 1024, jsMaks: 1600 \* 1024, totalMaks: 2100 \* 1024/);
  assert.ok(src('README.md').length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */);
});
