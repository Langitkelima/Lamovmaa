// Rev 284 / V7: WARNA PER PILIHAN untuk daftar bersumber (dari rentang). Warna disimpan per TEKS pilihan dan bertahan walau isi rentang berubah.
// Tes AI saja (mesin murni + kabel editor dibaca dari kode; perilaku layar diaudit di Chromium lewat tools/audit_sumber_warna.py, BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as V from '../src/js/lembar-validasi.js';
import * as S from '../src/js/lembar-sumber.js';
import * as L from '../src/js/lembar.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet({ name: 'T' }); return sh.tabs[0]; };
const cols = ['c1', 'c2', 'c3'].map((id) => ({ id })), rows = ['r1', 'r2', 'r3', 'r4', 'r5'].map((id) => ({ id }));
const ids = (a) => new Set(a.map((x) => x.id));
const base = { id: 'v1', c: 'c2', k: 'list', items: ['Belum', 'Proses'], src: { c1: 'c3', c2: 'c3', r1: 'r1', r2: 'r2' }, cl: { Belum: { bg: '#fecaca' }, Selesai: { bg: '#bbf7d0', fg: '#14532d' } } };

test('cleanCheck: daftar BERSUMBER menyimpan warna teks yang tidak ada di items; daftar biasa tetap membuang', () => {
  const c = V.cleanCheck(base, ids(cols), ids(rows)); assert.deepEqual(c.cl, { Belum: { bg: '#FECACA' }, Selesai: { bg: '#BBF7D0', fg: '#14532D' } });
  const { src: _s, ...plain } = base; const p = V.cleanCheck(plain, ids(cols), ids(rows)); assert.deepEqual(p.cl, { Belum: { bg: '#FECACA' } }); // tanpa src: perilaku lama
});
test('cleanCheck bersumber: hanya #RRGGBB, kunci terlalu panjang dibuang, maks. 20 kunci, __proto__ dilewati', () => {
  const cl = { Ok: { bg: 'merah' }, [('x').repeat(V.MAX_ITEM_LEN + 1)]: { bg: '#112233' }, Baik: { bg: '#112233' } }; for (let i = 0; i < 30; i++) cl['t' + i] = { bg: '#445566' };
  Object.defineProperty(cl, '__proto__', { value: { bg: '#000000' }, enumerable: true });
  const c = V.cleanCheck({ ...base, cl }, ids(cols), ids(rows)); const k = Object.keys(c.cl);
  assert.ok(!k.includes('Ok') && !k.includes('__proto__') && !k.some((t) => t.length > V.MAX_ITEM_LEN)); assert.ok(k.length <= V.MAX_ITEMS); assert.equal(c.cl.Baik.bg, '#112233');
  assert.equal(Object.getPrototypeOf(c.cl), Object.prototype);
});
test('warna BERTAHAN walau isi rentang berubah: item hilang -> tanpa warna; item kembali -> warna kembali', () => {
  const tab = mk(); tab.cols = cols.map((c) => ({ ...c })); tab.rows = rows.map((r) => ({ ...r }));
  const cells = { '0,2': 'Belum', '1,2': 'Selesai' }; const text = (i, j) => cells[i + ',' + j] || '';
  tab.checks = [V.cleanCheck({ ...base, items: [] }, ids(cols), ids(rows))]; assert.ok(tab.checks[0]);
  S.refreshSrc(tab, text); assert.deepEqual(tab.checks[0].items, ['Belum', 'Selesai']);
  assert.equal(V.colorOf(tab.checks[0], 'selesai').bg, '#BBF7D0'); assert.equal(V.colorOf(tab.checks[0], 'belum').bg, '#FECACA');
  cells['1,2'] = 'Tunda'; S.refreshSrc(tab, text); assert.deepEqual(tab.checks[0].items, ['Belum', 'Tunda']);
  assert.equal(V.colorOf(tab.checks[0], 'Tunda'), null); assert.ok(tab.checks[0].cl.Selesai, 'warna Selesai masih diingat');
  const again = V.cleanChecks(tab.checks, tab.cols, tab.rows); assert.ok(again[0].cl.Selesai, 'bertahan lewat cleanChecks (simpan/pulihkan)');
  cells['1,2'] = 'Selesai'; S.refreshSrc(tab, text); assert.equal(V.colorOf(tab.checks[0], 'Selesai').bg, '#BBF7D0');
});
test('sumber dibuang (ID hilang) = daftar biasa: warna teks di luar items ikut terbuang saat dibersihkan', () => {
  const tab = mk(); tab.cols = cols.map((c) => ({ ...c })); tab.rows = rows.map((r) => ({ ...r }));
  tab.checks = [V.cleanCheck(base, ids(cols), ids(rows))]; tab.rows = tab.rows.filter((r) => r.id !== 'r1');
  S.refreshSrc(tab, () => ''); assert.equal(tab.checks[0].src, undefined);
  const c = V.cleanChecks(tab.checks, tab.cols, tab.rows); assert.deepEqual(Object.keys(c[0].cl), ['Belum']);
});
test('pulau + pilih memakai kunci teks yang sama (tanpa kode baru): pickPainter mengikuti colorOf', async () => {
  const P = await import('../src/js/lembar-pulau.js'); assert.equal(typeof P.pickPainter, 'function');
  const ui = src('src/js/lembar-ui.js'); assert.ok(ui.includes('ck.cl && ck.cl[it]'), 'lembar Pilih membaca cl per teks');
});
test('editor: baris hanya-baca untuk range, warna lewat stash per teks, kartu Pilihan tampil, simpan menyimpan warna', () => {
  const ui = src('src/js/lembar-ui.js'), ed = ui.slice(ui.indexOf('const openChecks = () =>'), ui.indexOf('// --- Rev 149 / U9b-1: Filter baris SEMENTARA'));
  assert.match(ed, /manual = \[\], stash = new Map\(\)/); assert.match(ed, /const syncRows = \(\) =>/); assert.match(ed, /\.\.\.\(R \? \{ readonly: '' \} : \{\}\)/);
  assert.match(ed, /if \(kind === 'range'\) stash\.set\(r\.t, \{ bg, fg: '' \}\)/); assert.match(ed, /srcIn\.addEventListener\('input', \(\) => \{ clearTimeout\(tmSrc\); tmSrc = setTimeout\(resync, 350\)/); assert.match(ed, /srcIn\.addEventListener\('change', resync\)/); assert.ok(ed.includes("!== was) { palFor = -1; paintItems(); }")); // jeda + tidak menggambar ulang bila daftar sama (ketukan tidak hilang)
  assert.match(ed, /addB\.hidden = kind === 'range'/); assert.match(ed, /stash = new Map\(Object\.entries\(ck && ck\.src && ck\.cl \? ck\.cl : \{\}\)\)/);
  assert.match(ed, /cl = \{\}; for \(const t of \[\.\.\.items, \.\.\.stash\.keys\(\)\]\)/); // teks yang sedang ada didahulukan agar tidak terpotong batas 20
  assert.ok(ed.includes('R ? h(\'span\', { class: \'vd-mv ph\' })')); assert.ok(ed.includes('if (R) { itemsEl.append(line)')); // tanpa naik/hapus/ketik/tempel
});
test('anggaran + terdaftar: JS buka tetap < 740000; SCHEMA tetap 22; versi tetap; alat audit ada', async () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev284\.test\.mjs/);
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22/);
  for (const f of ['lembar.js', 'lembar-validasi.js', 'main.js']) assert.doesNotMatch(src('src/js/' + f), /lembar-sumber/, f);
  const a = src('tools/audit_sumber_warna.py'); for (const k of ["'light', 'dark'", "select_option('range')", 'Tunda']) assert.ok(a.includes(k), k);
});
