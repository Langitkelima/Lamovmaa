// Rev 313: warna seleksi teks seragam di editor catatan. Teks langsung di .ed2 (tanpa <div>) dulu memakai warna bawaan Android
// karena aturan hanya `.ed2 ::selection` (keturunan). Kini .ed2 sendiri juga diberi warna aplikasi.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const rules = (sel) => css.split('}').filter((r) => r.includes('::selection') && r.includes(sel));
test('Rev 313: .ed2::selection ada (teks langsung di editor)', () => {
  assert.ok(/(^|[\s,}])\.ed2::selection\s*[,{]/.test(css));
  assert.ok(/\.fs \.ed2::selection\s*[,{]/.test(css));
});
test('Rev 313: aturan keturunan tetap ada dan memakai warna tema', () => {
  assert.ok(/\.ed2 ::selection/.test(css) && /\.fs \.ed2 ::selection/.test(css));
  for (const r of rules('.ed2')) assert.ok(/background:\s*var\(--ac2\)/.test(r) && /color:\s*var\(--ink\)/.test(r));
});
test('Rev 313: tanpa warna heks di aturan seleksi', () => {
  for (const r of rules('.ed2')) assert.ok(!/#[0-9a-f]{3,8}\b/i.test(r));
});
