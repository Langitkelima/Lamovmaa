// Rev 184b / U10e-2: TINGGI BARIS BEBAS di grid (garis seret di nomor baris). Berkas rev188 = Rev 184b. Hitungan murni di lembar-baris.js + kabel UI.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as B from '../src/js/lembar-baris.js';
import * as UI from '../src/js/lembar-ui.js';
import * as L from '../src/js/lembar.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');

test('rowTops: jumlah kumulatif; tanpa tinggi khusus sama dengan k*40', () => {
  const r = B.rowTops([40, 40, 40]); assert.deepEqual(r.tops, [0, 40, 80, 120]); assert.deepEqual(r.eff, [40, 40, 40]);
  const q = B.rowTops([40, 120, 16, 40]); assert.deepEqual(q.tops, [0, 40, 160, 176, 216]);
  assert.deepEqual(B.rowTops([]).tops, [0]);
});
test('rowTops: tinggi rusak dinaikkan ke minimal 16; melewati cap = baris belakang dipersempit (data tidak diubah)', () => {
  assert.deepEqual(B.rowTops([NaN, 5, 'x']).eff, [16, 16, 16]);
  const r = B.rowTops([1000000, 1000000, 1000000], 2000000); assert.ok(r.tops[3] <= 2000000); assert.ok(r.eff.every((e) => e >= 16)); assert.equal(r.eff[0], 1000000);
  const big = B.rowTops(new Array(500).fill(1000000)); assert.ok(big.tops[500] <= B.GRID_MAX_H); assert.ok(big.eff.every((e) => e >= 16));
});
test('visibleRangeH: sama dengan jendela tetap saat semua baris 40; baris tinggi menggeser jendela', () => {
  const t = B.rowTops(new Array(100).fill(40)).tops;
  assert.deepEqual(B.visibleRangeH(t, 0, 400), { from: 0, to: 17 }); // baris 0..10 terlihat + buffer 6
  const a = B.visibleRangeH(t, 2000, 400); assert.ok(a.from <= 50 && a.to >= 60 && a.to <= 100);
  assert.deepEqual(B.visibleRangeH([0], 0, 100), { from: 0, to: 0 });
  const u = B.rowTops([40, 5000, 40, 40, 40]).tops; const v = B.visibleRangeH(u, 1000, 400, 0); assert.equal(v.from, 1); assert.equal(v.to, 2); // seluruh layar di dalam baris 1
  const w = B.visibleRangeH(u, 100000, 400); assert.equal(w.to, 5); assert.ok(w.from <= 4);
});
test('dragRowHeight: bulat, minimal 16, menempel ke 40 (+-3), dijaga cap total, masukan rusak = awal', () => {
  assert.equal(B.dragRowHeight(40, 80), 120); assert.equal(B.dragRowHeight(40, -100), 16); assert.equal(B.dragRowHeight(120, -78), 40); // 42 menempel ke 40
  assert.equal(B.dragRowHeight(100, -57), 40); assert.equal(B.dragRowHeight(100, -55), 45); assert.equal(B.dragRowHeight(100, -50), 50); assert.equal(B.dragRowHeight(40, 0.4), 40);
  assert.equal(B.dragRowHeight('abc', 10), 50); assert.equal(B.dragRowHeight(40, 'zz'), 40);
  assert.equal(B.dragRowHeight(40, 99999999, 1000), B.GRID_MAX_H - 32 - 1000); assert.equal(B.dragRowHeight(40, 5, B.GRID_MAX_H), 16);
  assert.equal(B.dragRowHeight(40, 1000000), 1000040); // tanpa batas atas buatan per baris
});
test('gridSize: tinggi mengikuti row.h; tanpa h tetap 32 + baris*40 (data lama sama persis)', () => {
  const t = L.newTab('T', 10); assert.equal(UI.gridSize(t).h, 32 + 10 * 40);
  L.setRowHeight(t, t.rows[2].id, 140); assert.equal(UI.gridSize(t).h, 32 + 10 * 40 + 100);
  L.setRowHeight(t, t.rows[3].id, 16); assert.equal(UI.gridSize(t).h, 32 + 10 * 40 + 100 - 24);
});
test('kabel UI: pegangan .lz-rzr di nomor baris, pointer capture, tanpa gambar ulang saat menyeret, satu langkah Urungkan, ketukan pegangan tidak memilih baris', () => {
  const s = src('js/lembar-ui.js');
  assert.match(s, /from '\.\/lembar-baris\.js'/); assert.match(s, /class: 'lz-rzr'/);
  assert.match(s, /const rrDown/); assert.match(s, /const rrMove/); assert.match(s, /const rrEnd/); assert.match(s, /const relayoutRows/);
  assert.match(s, /L\.setRowHeight\(tab, it\.id, n\); relayoutRows\(\)/); // saat menyeret: hanya relayout, bukan drawRows
  assert.match(s, /hist\.push\(r\.snap\)/); assert.match(s, /body\.addEventListener\('pointerdown', rrDown\)/); assert.match(s, /body\.addEventListener\('lostpointercapture'/);
  assert.match(s, /closest\('\.lz-rzr'\)\) e\.stopPropagation\(\)/); assert.match(s, /fitsLimit\(sheet\)\) \{ back\(\); changed = false;/); // Rev 253 / S4: back() mengembalikan SEMUA baris dalam r.set
  assert.doesNotMatch(s, /\* ROW_H \+ 'px'/); // tidak ada lagi posisi baris = k * ROW_H
  assert.match(s, /lay\.tops\[mg\.pos \+ mg\.count\] - lay\.tops\[mg\.pos\]/); // gabungan membentang sebanyak tinggi barisnya
});
test('CSS: pegangan, baris aktif, dan sel tinggi (teks membungkus)', () => {
  const c = src('css/styles.css');
  assert.match(c, /\.lembarfs \.lz-rzr\{[^}]*touch-action:none[^}]*row-resize/); assert.match(c, /\.lz-c\.tall\{white-space:normal/); assert.match(c, /\.lz-row\.rz \.lz-rzr::after/);
});
test('model 184a tetap: setRowHeight bolak-balik dan 40 = hapus kunci (tak ada perubahan SCHEMA)', () => {
  const t = L.newTab('T', 3); assert.equal(L.setRowHeight(t, t.rows[0].id, 90), true); assert.equal(t.rows[0].h, 90); assert.equal(L.setRowHeight(t, t.rows[0].id, 40), true); assert.equal('h' in t.rows[0], false);
});
