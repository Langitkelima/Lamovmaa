// Rev 430 / SY6a: pesan "Gambar hanya ada di HP" di versi web/laptop (bukan galat); pesan tidak ditulis sebagai teks di dalam <figure>.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import * as G from '../src/js/gambar.js';
const baca = (p) => readFileSync(p, 'utf8');

test('pesanGambarGagal: HP = pesan galat lama, web/laptop = "Gambar hanya ada di HP"', () => {
  assert.equal(G.pesanGambarGagal(true), 'Gambar tidak dapat dimuat');
  assert.equal(G.pesanGambarGagal(false), 'Gambar hanya ada di HP');
  assert.equal(G.MSG_GAMBAR_HANYA_HP, 'Gambar hanya ada di HP');
});

test('gambar-app.js: kegagalan memuat memakai markImageFailed (atribut data-pesan, BUKAN textContent di figure)', () => {
  const s = baca('src/js/gambar-app.js');
  assert.match(s, /export function markImageFailed\(fig, native = isNative\(\)\)/);
  assert.match(s, /fig\.dataset\.pesan = G\.pesanGambarGagal\(native\)/);
  assert.match(s, /export function markImagesUnavailable\(root, native = isNative\(\)\)/);
  assert.match(s, /catch \(e\) \{ markImageFailed\(fig\); onError\(e\); \}/);
  assert.doesNotMatch(s, /fig\.textContent = /);
});

test('notes.js: tanpa Filesystem native (web) semua gambar ditandai "hanya ada di HP"; jalur HP tidak berubah', () => {
  const n = baca('src/js/notes.js');
  assert.match(n, /import \{[^}]*markImagesUnavailable[^}]*\} from '\.\/gambar-app\.js'/);
  assert.match(n, /stopImageObserver = hydrateImages\(ed, imageFS\(\), imageUrls, \(\) => \{\}\); \} catch \(_\) \{ try \{ markImagesUnavailable\(ed\); \}/);
});

test('penampil.js: pesan gagal-muat ikut tergantung native', () => {
  const s = baca('src/js/penampil.js');
  assert.match(s, /import \{ isNative \} from '\.\/native\.js'/);
  assert.match(s, /msg\.textContent = G\.pesanGambarGagal\(isNative\(\)\)/);
  assert.doesNotMatch(s, /msg\.textContent = 'Gambar tidak dapat dimuat'/);
});

test('styles.css: pesan digambar ::after dari data-pesan; atribut itu tidak ada di daftar putih sanitize (tidak tersimpan)', () => {
  assert.match(baca('src/css/styles.css'), /figure\.ki\[data-loaded="error"\]::after\{content:attr\(data-pesan\)\}/);
  const n = baca('src/js/notes.js');
  assert.ok(!/data-pesan/.test(n) && !/'data-loaded'/.test(n), 'sanitize tidak boleh meloloskan data-pesan/data-loaded');
});

test('skrip audit 430 ada; dokumen mencatat Rev 430; versi tetap 0.3.121', () => {
  assert.ok(existsSync('tools/audit_gambar_430.py'));
  assert.match(baca('tools/audit_gambar_430.py'), /Gambar hanya ada di HP/);
  assert.match(baca('RIWAYAT.md'), /\*\*Rev 430 \/ v0\.3\.121/);
  assert.match(baca('PROMPT_SERAH_TERIMA.md'), /\*\*Rev 430 \/ v0\.3\.121/);
  assert.equal(JSON.parse(baca('package.json')).version, '0.3.121');
});
