// Rev 160 / U10c-3a: diagram tersimpan tampil di pulau lembar kerja di catatan (SCHEMA 18, tanpa UI baru selain pulau)
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as P from '../src/js/lembar-pulau.js';
import * as S from '../src/js/storage.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mkSheet = () => { const sh = L.newSheet({ name: 'Jual' }); const t = sh.tabs[0]; const put = (i, j, v) => L.setCell(t, t.rows[i].id, t.cols[j].id, { v });
  put(0, 0, 'Bulan'); put(0, 1, 'Jual'); [['Jan', 10], ['Feb', 30], ['Mar', 20]].forEach(([a, b], k) => { put(k + 1, 0, a); put(k + 1, 1, b); }); return sh; };
test('islandCharts: tanpa diagram = kosong; dengan diagram = SVG berdiri sendiri dari tab pertama', () => {
  const sh = mkSheet(); assert.deepEqual(P.islandCharts(sh), { items: [], more: 0 }); assert.deepEqual(P.islandCharts(null), { items: [], more: 0 });
  const t = sh.tabs[0]; const r = L.saveChart(t, { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, { kind: 'bar', title: 'Penjualan' });
  const c = P.islandCharts(sh); assert.equal(c.items.length, 1); assert.equal(c.more, 0); assert.equal(c.items[0].id, r.id); assert.equal(c.items[0].ref, 'A1:B4'); assert.equal(c.items[0].kind, 'bar');
  assert.match(c.items[0].svg, /^<svg /); assert.ok(c.items[0].svg.includes('Penjualan')); assert.ok(c.items[0].svg.includes('Jan')); assert.doesNotMatch(c.items[0].svg, /<script|href=|<image/i);
});
test('islandCharts: maks. ISLAND_CHARTS digambar, sisanya dihitung; diagram tanpa angka dilewati; tab lain tidak ikut', () => {
  const sh = mkSheet(); const t = sh.tabs[0]; for (let i = 0; i < 4; i++) L.saveChart(t, { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, { kind: 'column' });
  const c = P.islandCharts(sh); assert.equal(c.items.length, P.ISLAND_CHARTS); assert.equal(c.more, 2);
  const kosong = L.newSheet({ name: 'K' }); L.saveChart(kosong.tabs[0], { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, {}); assert.deepEqual(P.islandCharts(kosong), { items: [], more: 0 }); // tidak ada angka
  const dua = mkSheet(); L.addTab(dua); L.saveChart(dua.tabs[1], { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, {}); assert.equal(P.islandCharts(dua).items.length, 0);
});
test('islandModel dan exportModel tidak berubah oleh diagram (PDF/JPG = U10c-3b)', () => {
  const a = mkSheet(), b = mkSheet(); L.saveChart(b.tabs[0], { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, {});
  assert.deepEqual(P.islandModel(a), P.islandModel(b)); assert.deepEqual(P.exportModel(a), P.exportModel(b));
});
test('renderIsland (DOM palsu): diagram dipasang lewat DOMParser + importNode di antara tabel dan kaki; tanpa diagram tidak ada .ks-charts', () => {
  class El { constructor(t) { this.tag = t; this.kids = []; this.attrs = {}; this.cls = new Set(); this.style = { setProperty() {} }; this.nodeType = 1; this.className = ''; this.textContent = ''; }
    get childNodes() { return this.kids; } append(...k) { this.kids.push(...k); } replaceChildren(...k) { this.kids = k; } setAttribute(k, v) { this.attrs[k] = v; } getAttribute(k) { return this.attrs[k] || null; } removeAttribute() {}
    get classList() { const s = this; return { toggle() {}, add(c) { s.cls.add(c); }, remove() {} }; } }
  const prev = { document: globalThis.document, DOMParser: globalThis.DOMParser };
  globalThis.document = { createElement: (t) => new El(t), importNode: (n) => { const e = new El('svg'); e.className = 'imported'; e.src = n.xml; return e; } };
  let parsed = 0; globalThis.DOMParser = class { parseFromString(x) { parsed++; return { documentElement: { nodeName: 'svg', xml: x } }; } };
  try {
    const sh = mkSheet(); P.setSheetsSource(() => ({ [sh.id]: sh })); const el = new El('div'); el.attrs['data-sheet'] = sh.id;
    P.renderIsland(el); assert.ok(!el.kids.some((k) => k.className === 'ks-charts')); assert.equal(parsed, 0);
    L.saveChart(sh.tabs[0], { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, {}); L.saveChart(sh.tabs[0], { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, {}); L.saveChart(sh.tabs[0], { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, {});
    P.renderIsland(el); const names = el.kids.map((k) => k.className); const i = names.indexOf('ks-charts'); assert.ok(i > 1 && i < names.length - 1, names.join()); assert.equal(names[names.length - 1], 'ks-foot');
    const box = el.kids[i]; assert.equal(parsed, P.ISLAND_CHARTS); assert.equal(box.kids.filter((k) => k.className === 'ks-chart').length, P.ISLAND_CHARTS); assert.equal(box.kids[box.kids.length - 1].textContent, '+1 diagram lain (buka lembar kerja)');
  } finally { globalThis.document = prev.document; globalThis.DOMParser = prev.DOMParser; if (prev.document === undefined) delete globalThis.document; if (prev.DOMParser === undefined) delete globalThis.DOMParser; P.setSheetsSource(null); }
});
test('Rev 160: tanpa innerHTML, CSS reset svg di pulau, hanya pulau yang menambah impor mesin diagram; SCHEMA 17; versi 0.3.121; tes terdaftar', () => {
  const m = src('src/js/lembar-pulau.js'); assert.match(m, /from '\.\/lembar-diagram\.js'/); assert.doesNotMatch(m, /innerHTML|insertAdjacentHTML|eval\(|new Function|localStorage|lembar-grafik/);
  for (const f of ['lembar', 'export', 'notes', 'main', 'storage', 'share']) assert.doesNotMatch(src('src/js/' + f + '.js'), /lembar-diagram/, f);
  const css = src('src/css/styles.css'); assert.match(css, /Rev 160 \/ U10c-3a/); assert.match(css, /\.ksheet \.ks-chart svg\{width:100%;max-width:360px;height:auto;[^}]*stroke:none;stroke-width:1/);
  assert.equal(S.SCHEMA, 22); const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev160.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
