// Rev 302b / v0.3.121: Bekukan lewat Menu sel (tahan nomor baris / kepala kolom / pojok / sel), item Bekukan + Lepas bekukan, tahan kepala membuka Menu sel, alat audit, dokumen.
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');

test('applyFreeze menerima indeks eksplisit (ri, ci) dan tetap memakai sel aktif bila tidak diberi; penolakan lebar kolom + snapshot Urungkan tidak berubah urutannya', () => {
  const a = ui.slice(ui.indexOf('const applyFreeze'), ui.indexOf('const openFreeze'));
  assert.match(a, /const applyFreeze = \(mode, ri, ci\) =>/); assert.match(a, /const R = Number\.isInteger\(ri\) \? ri : sel \? sel\.r : -1, C = Number\.isInteger\(ci\) \? ci : sel \? sel\.c : -1/);
  assert.match(a, /freezeBy\(tab, mode, R, C\)\.changed/); assert.match(a, /Math\.min\(MAX_FZ_COLS, mode === 'col1' \? 1 : C \+ 1\)/);
  assert.ok(a.indexOf('Kolom beku terlalu lebar') < a.indexOf('const snap = ser()'));
  assert.ok(!/sel\.r|sel\.c/.test(a.replace('sel ? sel.r : -1', '').replace('sel ? sel.c : -1', '')), 'tidak ada rujukan sel aktif lain di applyFreeze');
});
test('Menu sel: freezeItems per jenis seleksi (baris penuh = sampai baris; kolom penuh = sampai kolom; sel/rentang = keduanya; pojok = hanya Lepas; Lepas hanya bila sudah beku)', () => {
  const f = ui.slice(ui.indexOf('const freezeItems'), ui.indexOf('const onLongPress'));
  assert.match(f, /k !== 'col' && k !== 'all'\) out\.push\(bt\('cm-r', 'frz-rows'/); assert.match(f, /k !== 'row' && k !== 'all'\) out\.push\(bt\('cm-r', 'frz-cols'/);
  assert.match(f, /if \(f\.r \|\| f\.c\) out\.push\(bt\('cm-r', 'frz-off'/); assert.match(f, /applyFreeze\('rows', r2, -1\)/); assert.match(f, /applyFreeze\('cols', -1, c2\)/); assert.match(f, /applyFreeze\('none'\)/);
  assert.match(ui, /\.\.\.freezeItems\(sx, bt\)\)\)\);/, 'item ditambahkan di daftar cm-lst Menu sel');
  assert.ok(ui.indexOf("'Diagram dari sel ini', openChart)") < ui.indexOf('...freezeItems(sx, bt)'), 'urutan: sesudah Diagram');
});
test('tahan nomor baris / kepala kolom / pojok membuka Menu sel; pegangan seret (lz-rz, lz-rzr) dikecualikan; seleksi yang sudah terpilih (hasil seret) dipertahankan', () => {
  assert.match(ui, /!e\.target\.closest\('\.lz-rz, \.lz-rzr'\) && e\.target\.closest\('\.lz-c, \.lz-rn, \.lz-hc, \.lz-corner'\)/);
  const l = ui.slice(ui.indexOf('const onLongPress'), ui.indexOf("scroller.addEventListener('pointerdown', (e) => {\n    clearTimeout(lpT)"));
  assert.match(l, /!c\.classList\.contains\('lz-c'\)/); assert.match(l, /const held = !!selx && selx\.kind === kd/); assert.match(l, /if \(!held\) pick\(\{ target: c \}\)/); assert.match(l, /openCellMenu\(\); return;/);
  assert.match(ui, /scroller\.addEventListener\('contextmenu', \(e\) => \{ const c = e\.target\.closest && e\.target\.closest\('\.lz-c, \.lz-rn, \.lz-hc, \.lz-corner'\)/);
});
test('CSS TIDAK berubah (memakai kelas cm-r yang ada) dan tetap di bawah anggaran resmi cssMaks 270 KB (Rev 383)', () => {
  assert.ok(!css.includes('Rev 302b')); assert.ok(Buffer.byteLength(css) < 270 * 1024, String(Buffer.byteLength(css)));
});
test('alat audit: tools/audit_beku_menu.py ada (360x720, terang + gelap; tahan baris/kolom/pojok/sel, Urungkan, tanpa galat konsol)', () => {
  assert.ok(existsSync(new URL('../tools/audit_beku_menu.py', import.meta.url))); const t = src('tools/audit_beku_menu.py');
  assert.match(t, /360, 'height': 720/); assert.match(t, /\['light', 'dark'\]/); assert.match(t, /frz-rows/); assert.match(t, /frz-cols/); assert.match(t, /frz-off/); assert.match(t, /\.lz-corner/); assert.match(t, /tanpa galat konsol/);
});
test('dokumen: README ringkas + jujur; entri Rev 302b di PROMPT dan RIWAYAT; butir uji HP AH; tes terdaftar; versi + SCHEMA tetap', () => {
  const r = src('README.md'); assert.ok(r.length < 12400, String(r.length)); assert.match(r, /Rev 302b/); assert.match(r, /bukan\*\* bukti APK/);
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 302b / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('**Rev 302b / v0.3.121')); // Rev 302c: startsWith -> includes
  assert.match(src('UJI_HP_RILIS.md'), /## AH\. Bekukan lewat Menu sel \(Rev 302b\)/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev302b\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
console.log('rev302b: ' + n + ' tes');
