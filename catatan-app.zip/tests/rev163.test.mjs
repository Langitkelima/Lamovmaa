// Rev 163 / Q10 tahap 2: fungsi rumus kelompok TANGGAL (DATE YEAR MONTH DAY HOUR MINUTE WEEKDAY DATEDIF). TEXT belum (butuh keputusan kode format).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { argHint } from '../src/js/rumus-bantu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 9, 0, 0).getTime(); // Selasa 10 Nov 2026 09:00
function at(f) { const t = L.newTab('T', 12); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cF = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cF'); }
const D = (y, m, d) => `DATE(${y};${m};${d})`;
const ser = (y, m, d) => at('=' + D(y, m, d));

test('DATE: nomor seri benar (patokan Excel), bulan/hari berlebih bergulir, batas dan galat', () => {
  assert.equal(ser(2000, 1, 1), 36526); assert.equal(ser(2026, 1, 1), 46023); assert.equal(ser(1900, 3, 1), 61); assert.equal(ser(1900, 1, 1), 2); // patokan 1 Mar 1900 = 61 sama dengan Excel; sebelum itu selisih 1 (kekhasan Excel soal 29 Feb 1900), sama dengan serialOf lama
  assert.equal(ser(2026, 13, 1), ser(2027, 1, 1)); assert.equal(ser(2026, 0, 1), ser(2025, 12, 1)); assert.equal(ser(2026, 3, 0), ser(2026, 2, 28)); assert.equal(ser(2024, 3, 0), ser(2024, 2, 29));
  assert.equal(ser(2026, 1, 32), ser(2026, 2, 1)); assert.equal(ser(2026, 14, 31), ser(2027, 3, 3));
  assert.equal(ser(99, 1, 1), ser(1999, 1, 1)); assert.equal(ser(0, 1, 1), ser(1900, 1, 1)); // tahun 0..1899 + 1900
  assert.equal(ser(2026, 11, 10.9), ser(2026, 11, 10)); // desimal dipotong
  assert.equal(ser(-1, 1, 1).e, '#NUM!'); assert.equal(ser(10000, 1, 1).e, '#NUM!'); assert.equal(at('=DATE(1900;1;-1)').e, '#NUM!'); assert.equal(ser(9999, 12, 31), 2958465); assert.equal(ser(9999, 12, 32).e, '#NUM!');
  assert.equal(at('=DATE("a";1;1)').e, '#VALUE!'); assert.equal(at('=DATE(2026;1/0;1)').e, '#DIV/0!'); assert.equal(at('=DATE("2026";"11";"10")'), ser(2026, 11, 10)); // teks angka dikoersi
});
test('YEAR, MONTH, DAY: bolak-balik dengan DATE, termasuk 29 Feb dan batas jangkauan', () => {
  for (const [y, m, d] of [[2026, 11, 10], [2024, 2, 29], [2000, 12, 31], [1900, 3, 1], [9999, 12, 31], [2100, 2, 28]]) {
    assert.equal(at(`=YEAR(${D(y, m, d)})`), y); assert.equal(at(`=MONTH(${D(y, m, d)})`), m); assert.equal(at(`=DAY(${D(y, m, d)})`), d);
  }
  assert.equal(at('=YEAR(NOW())'), 2026); assert.equal(at('=MONTH(TODAY())'), 11); assert.equal(at('=DAY(TODAY())'), 10); assert.equal(at('=DAY(46336,9)'), 10); // pecahan jam diabaikan
  assert.equal(at('=YEAR(0)').e, '#NUM!'); assert.equal(at('=YEAR(-5)').e, '#NUM!'); assert.equal(at('=YEAR(2958466)').e, '#NUM!'); assert.equal(at('=YEAR("x")').e, '#VALUE!'); assert.equal(at('=MONTH(1/0)').e, '#DIV/0!');
});
test('HOUR dan MINUTE: dari bagian pecahan nomor seri, pembulatan detik ke menit/jam terdekat seperti Excel', () => {
  assert.equal(at('=HOUR(NOW())'), 9); assert.equal(at('=MINUTE(NOW())'), 0); assert.equal(at('=HOUR(0,5)'), 12); assert.equal(at('=HOUR(0,75)'), 18); assert.equal(at('=MINUTE(0,76)'), 14);
  assert.equal(at('=HOUR(0,999999999)'), 0); assert.equal(at('=MINUTE(0,999999999)'), 0); assert.equal(at('=HOUR(46336,25)'), 6); assert.equal(at('=HOUR(1)'), 0);
  assert.equal(at('=HOUR(-1)').e, '#NUM!'); assert.equal(at('=MINUTE("x")').e, '#VALUE!'); assert.equal(at('=HOUR(5/0)').e, '#DIV/0!');
});
test('WEEKDAY: tiga tipe (10 Nov 2026 = Selasa; 8 Nov 2026 = Minggu; 14 Nov 2026 = Sabtu), tipe lain #NUM!', () => {
  const w = (y, m, d, t) => at(`=WEEKDAY(${D(y, m, d)}${t === undefined ? '' : ';' + t})`);
  assert.equal(w(2026, 11, 10), 3); assert.equal(w(2026, 11, 10, 1), 3); assert.equal(w(2026, 11, 10, 2), 2); assert.equal(w(2026, 11, 10, 3), 1);
  assert.equal(w(2026, 11, 8), 1); assert.equal(w(2026, 11, 8, 2), 7); assert.equal(w(2026, 11, 8, 3), 6); assert.equal(w(2026, 11, 14), 7); assert.equal(w(2026, 11, 14, 2), 6); assert.equal(w(2026, 11, 14, 3), 5);
  assert.equal(w(2026, 11, 10, 4).e, '#NUM!'); assert.equal(w(2026, 11, 10, 0).e, '#NUM!'); assert.equal(at('=WEEKDAY(NOW())'), 3); assert.equal(at('=WEEKDAY(0)').e, '#NUM!'); assert.equal(at('=WEEKDAY("x")').e, '#VALUE!');
  assert.equal(w(2000, 1, 1), 7); assert.equal(w(1900, 1, 1, 2), 1); // 1 Jan 2000 Sabtu; 1 Jan 1900 Senin
});
test('DATEDIF: Y, M, D, YM, MD, YD; urutan terbalik, satuan salah, tahun kabisat', () => {
  const dd = (a, b, u) => at(`=DATEDIF(${D(...a)};${D(...b)};"${u}")`), S = [2020, 1, 15], E = [2026, 11, 10];
  assert.equal(dd(S, E, 'Y'), 6); assert.equal(dd(S, E, 'M'), 81); assert.equal(dd(S, E, 'YM'), 9); assert.equal(dd(S, E, 'MD'), 26);
  assert.equal(dd(S, E, 'D'), ser(2026, 11, 10) - ser(2020, 1, 15)); assert.equal(dd(S, E, 'YD'), ser(2026, 11, 10) - ser(2026, 1, 15));
  assert.equal(dd([2026, 1, 1], [2026, 1, 1], 'D'), 0); assert.equal(dd([2026, 1, 1], [2026, 1, 1], 'Y'), 0); assert.equal(dd([2026, 1, 31], [2026, 2, 28], 'M'), 0); assert.equal(dd([2026, 1, 31], [2026, 3, 1], 'M'), 1);
  assert.equal(dd([2026, 3, 10], [2026, 11, 10], 'M'), 8); assert.equal(dd([2026, 3, 10], [2026, 11, 10], 'MD'), 0); assert.equal(dd([2026, 3, 10], [2026, 11, 10], 'YM'), 8);
  assert.equal(dd([2024, 2, 29], [2025, 2, 28], 'Y'), 0); assert.equal(dd([2024, 2, 29], [2025, 3, 1], 'Y'), 1); assert.equal(dd([2024, 2, 29], [2028, 2, 29], 'Y'), 4);
  assert.equal(dd([2025, 11, 20], [2026, 11, 10], 'YD'), 355); assert.equal(dd([2025, 11, 20], [2026, 11, 10], 'Y'), 0); assert.equal(dd([2025, 11, 20], [2026, 11, 10], 'M'), 11); // YD memakai tahun sebelumnya bila ulang tahun belum lewat
  assert.equal(dd(E, S, 'D').e, '#NUM!'); assert.equal(dd(S, E, 'X').e, '#NUM!'); assert.equal(dd(S, E, '').e, '#NUM!'); assert.equal(at(`=DATEDIF(${D(...S)};${D(...E)};"y")`), 6); assert.equal(at(`=DATEDIF(${D(...S)};${D(...E)};" Y ")`), 6);
  assert.equal(at('=DATEDIF(0;5;"D")').e, '#NUM!'); assert.equal(at('=DATEDIF("x";5;"D")').e, '#VALUE!'); assert.equal(at('=DATEDIF(1/0;5;"D")').e, '#DIV/0!');
  assert.equal(at(`=DATEDIF(${D(...S)};TODAY();"Y")`), 6); // umur dari TODAY()
});
test('rentang sel sebagai argumen tanggal: sel tunggal ok, rentang >1 sel = #VALUE!; hasil bisa dipakai bersama IF/IFERROR/penjumlahan', () => {
  const t = L.newTab('T', 12); L.setCell(t, t.rows[0].id, t.cols[0].id, { v: '46336' }); L.setCell(t, t.rows[1].id, t.cols[0].id, { v: '46337' });
  const put = (r, f) => { t.rows[r].cells.cF = { fx: R.a1ToStored(f, t).fx }; };
  put(0, '=DAY(A1)'); put(1, '=DAY(A1:A2)'); put(2, '=IFERROR(DATEDIF(A2;A1;"D");"urutan terbalik")'); put(3, '=DATEDIF(A1;A2;"D")+WEEKDAY(A1;2)');
  const c = R.computeTab(t, { now: NOW });
  assert.equal(c.get('r1', 'cF'), 10); assert.equal(c.get('r2', 'cF').e, '#VALUE!'); assert.equal(c.get('r3', 'cF'), 'urutan terbalik'); assert.equal(c.get('r4', 'cF'), 3);
});
test('daftar fungsi: 48 fungsi, kelompok tanggal punya sig + ket + petunjuk argumen; saran huruf awal', () => {
  const names = R.FUNCTION_LIST.map((f) => f.name); assert.equal(names.length, 53);
  for (const n of ['DATE', 'YEAR', 'MONTH', 'DAY', 'HOUR', 'MINUTE', 'WEEKDAY', 'DATEDIF']) { const f = R.FUNCTION_LIST.find((x) => x.name === n); assert.ok(f && f.sig.startsWith(n + '(') && f.ket.length > 3, n); assert.ok(argHint(n, n.length + 1).parts.length >= 1, n); }
  assert.ok(names.includes('TEXT')); // Rev 164
  assert.deepEqual(R.suggestFunctions('da').map((f) => f.name), ['DATE', 'DATEDIF', 'DATEVALUE', 'DAY']); assert.ok(R.suggestFunctions('mi').some((f) => f.name === 'MINUTE'));
  assert.equal(argHint('DATEDIF', 8).parts.length, 3);
});
test('rumus.js tetap murni (tanpa impor/DOM/eval) dan tampilan angka hasil tanggal memakai format Tanggal yang sudah ada', () => {
  const s = src('src/js/rumus.js'); assert.ok(!/^\s*import\s/m.test(s)); assert.ok(!/document\.|window\.|localStorage|eval\(|new Function/.test(s));
  assert.equal(src('src/js/lembar-format.js').includes("formatDate"), true);
});
