// Rev 325 / PART L4: Link Card ikut ekspor (TXT/Markdown/PDF/JPG), pencarian + pratinjau daftar (notePlain), D5 hibrid (pratinjau bawah isi melewati URL kartu),
// dan penolakan berpenjelasan (aturan Rev 311). DOM nyata dicek di Chromium (tools/audit_linkcard_325.py); tes Node ini mengunci perilaku murni + kode.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as E from '../src/js/export.js';
import { skipCardUrls, parseLinkCards, cardPlain, normalizeLinkCard } from '../src/js/linkcard.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const notes = src('src/js/notes.js'), ui = src('src/js/linkcard-ui.js'), exp = src('src/js/export.js');

const CARD = '<div class="lk-card" contenteditable="false" data-u="https://www.google.com/search?q=a&amp;b=1" data-t="Google Search"></div>';

test('Rev 325: ekspor mengubah kartu jadi satu baris "Tautan: judul - alamat" (TXT dan Markdown)', () => {
  const b = E.parseNoteHtml('<p>Awal</p>' + CARD + '<p>Akhir</p>');
  assert.deepEqual(b.map((x) => x.runs[0].t), ['Awal', 'Tautan: Google Search - https://www.google.com/search?q=a&b=1', 'Akhir']);
  assert.match(E.blocksToText('J', b), /Tautan: Google Search - https:\/\/www\.google\.com\/search\?q=a&b=1/);
  assert.match(E.blocksToMarkdown('J', b), /Tautan: Google Search - https:\/\/www\.google\.com/);
});
test('Rev 325: kartu tanpa judul memuat alamat saja; alamat tidak sah (javascript:, kosong, spasi) dilewati tanpa merusak blok sesudahnya', () => {
  const b = E.parseNoteHtml('<div class="lk-card" data-u="https://contoh.id/x"></div><div class="lk-card" data-u="javascript:alert(1)"></div><div class="lk-card"></div><div class="lk-card" data-u="https://a.com/a b"></div><p>Sesudah</p>');
  assert.deepEqual(b.map((x) => x.runs[0].t), ['Tautan: https://contoh.id/x', 'Sesudah']);
});
test('Rev 325: isi kartu yang terlanjur ada (judul/ikon tampilan) tidak ikut dobel ke teks ekspor', () => {
  const b = E.parseNoteHtml('<div class="lk-card" data-u="https://contoh.id/x" data-t="Judul"><span class="lk-ic"></span><span class="lk-tx"><b>Judul</b><small>contoh.id</small></span><button class="lk-go"></button></div><p>Sesudah</p>');
  assert.deepEqual(b.map((x) => x.runs[0].t), ['Tautan: Judul - https://contoh.id/x', 'Sesudah']);
});
test('Rev 325: kartu di dalam tabel/bagian lipat tidak merusak struktur; judul bercampur kontrol dibersihkan dan dipotong 140', () => {
  const t = 'x'.repeat(300), b = E.parseNoteHtml('<div class="lk-card" data-u="https://a.com" data-t="A\nB\t' + t + '"></div>');
  const r = b[0].runs[0].t; assert.ok(r.startsWith('Tautan: A B x'));
  assert.ok(r.length <= 'Tautan: '.length + 140 + ' - '.length + 'https://a.com'.length);
});
test('Rev 325: PDF/JPG - alamat sangat panjang dipatah, tidak keluar kanan dan tidak menggantung', () => {
  const long = 'https://a.com/' + 'x'.repeat(1900);
  const bl = E.parseNoteHtml('<div class="lk-card" data-u="' + long + '" data-t="Judul"></div>');
  const measure = (s, st) => s.length * st.size * 0.5 * (st.b ? 1.1 : 1), O = { width: 600, padX: 40, size: 30, titleSize: 44, measure };
  const lines = E.layoutDoc({ title: '', blocks: bl }, O).filter((x) => x.kind === 'text');
  assert.ok(lines.length >= 2 && lines.length < 400);
  for (const l of lines) for (const s of l.segs) assert.ok(s.x + measure(s.t, { size: s.size, b: s.b }) <= O.width - O.padX + 0.01 || s.x === l.x, 'tidak keluar kanan');
  assert.match(lines.map((l) => l.segs.map((s) => s.t).join('')).join(''), /Tautan: Judul -\s?https:\/\/a\.com\/x+/);
});
test('Rev 325: D5 hibrid - skipCardUrls melewati URL yang sudah jadi kartu (tanpa #, / penutup, huruf besar domain), sisanya utuh', () => {
  const cards = parseLinkCards(CARD);
  assert.equal(cards.length, 1);
  assert.deepEqual(skipCardUrls(['https://www.google.com/search?q=a&b=1', 'https://contoh.id/y'], cards), ['https://contoh.id/y']);
  assert.deepEqual(skipCardUrls(['https://WWW.Google.com/search?q=a&b=1#bagian'], cards), []);
  assert.deepEqual(skipCardUrls(['https://contoh.id/y'], []), ['https://contoh.id/y']);
  assert.deepEqual(skipCardUrls(['https://contoh.id/y'], undefined), ['https://contoh.id/y']);
});
test('Rev 325: format pratinjau daftar notePlain = cardPlain (satu sumber kebenaran)', () => {
  const c = normalizeLinkCard({ u: 'https://contoh.id/x', t: 'Judul' });
  assert.equal(cardPlain(c), 'Tautan: Judul - https://contoh.id/x');
  assert.equal(cardPlain(normalizeLinkCard({ u: 'https://contoh.id/x' })), 'Tautan: https://contoh.id/x');
  assert.match(notes, /const short = 'Tautan: ' \+ \(t \? t \+ ' - ' : ''\) \+ \(b\.getAttribute\('data-u'\) \|\| ''\)/);
  assert.match(notes, /ed\.querySelectorAll\('\.lk-card'\)\.forEach\(\(b\) => \{ \/\/ Rev 325/);
});
test('Rev 325: notes.js - pratinjau bawah isi memakai linkUrls (null selama linkcard.js belum termuat; n.prev tidak dihapus saat menunggu)', () => {
  assert.match(notes, /const linkUrls = \(\) => \{/);
  assert.match(notes, /if \(!lkSkip\) \{ import\('\.\/linkcard\.js'\)/); // MALAS, hanya bila ada kartu
  assert.match(notes, /const urls = linkUrls\(\); if \(!urls\) return;\n/); // dipakai renderLinks DAN syncLinks
  assert.equal((notes.match(/const urls = linkUrls\(\); if \(!urls\) return;/g) || []).length, 2);
  assert.ok(!/from '\.\/linkcard\.js'/.test(notes), 'linkcard.js tidak boleh diimpor statis (anggaran jalur buka)');
  assert.ok(!/from '\.\/linkcard-ui\.js'/.test(notes));
});
test('Rev 325: export.js tidak mengimpor linkcard.js (jalur ekspor tetap ringan) dan kartu dilacak lkSkip seperti blok lain', () => {
  assert.ok(!/linkcard/.test(exp.replace(/lk-card/g, '')));
  assert.match(exp, /lkSkip = 1;\n\s+continue;/);
  assert.match(exp, /if \(lkSkip\) \{ if \(tag === 'DIV'\) lkSkip \+= close \? -1 : 1; continue; \}/);
});
test('Rev 325 (aturan Rev 311): tautan gagal dibuka = toast bernada peringatan dengan penyebab + cara mengatasinya, di tombol Buka DAN panah/kartu mode Baca', () => {
  assert.match(ui, /export function bukaTautan\(url\)/);
  assert.match(ui, /uiToast\('Tautan tidak bisa dibuka\. Pastikan ada aplikasi peramban di HP dan alamatnya masih sah, lalu coba lagi\.', undefined, undefined, undefined, 'warn'\)/);
  assert.match(ui, /bukaTautan\(url\); \}\)/);
  assert.match(ui, /e\.preventDefault\(\); bukaTautan\(card\.getAttribute\('data-u'\)/);
  assert.equal((ui.match(/openExternal\(/g) || []).length, 1, 'hanya bukaTautan yang memanggil openExternal');
  assert.match(ui, /toast\('Tidak bisa membaca salinan otomatis\. Tahan kolom alamat lalu pilih Tempel\.', undefined, undefined, undefined, 'warn'\)/);
});
