// Rev 415: geser bar bawah (src/js/main.js + styles.css). Pemeriksaan statis; perilaku sungguhan ada di tools/audit_geser_415.py (Chromium).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const rd = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const main = rd('../src/js/main.js'), css = rd('../src/css/styles.css');

test('geser bar: logika pindah tab dipakai bersama (pickTab) oleh ketukan dan geseran', () => {
  assert.match(main, /const pickTab = \(id\) => \{/);
  assert.match(main, /onclick: \(\) => pickTab\(id\)/);
  assert.match(main, /navGeser\(navEl, tabs, pickTab\)/);
  const body = main.slice(main.indexOf('const pickTab'), main.indexOf('navEl = h(\'nav\''));
  for (const k of ['if (id === ui.tab) return;', 'exitSelect()', "ui.prevTab = ui.tab", 'navTo(navEl, idx, true)', 'closeEditor(\'priv\')']) assert.ok(body.includes(k), 'pickTab harus memuat ' + k);
});
test('geser bar: pointer events, ambang 6 px, capture hanya sesudah geser, klik susulan diblokir', () => {
  const f = main.slice(main.indexOf('function navGeser'), main.indexOf('function drawNav'));
  assert.match(main, /NAV_GESER_PX = 6/);
  for (const k of ["'pointerdown'", "'pointermove'", "'pointerup'", "'pointercancel'", 'setPointerCapture', 'blokirKlik', 'Math.round(cur)']) assert.ok(f.includes(k), k);
  assert.ok(f.indexOf('setPointerCapture') > f.indexOf('NAV_GESER_PX'), 'capture sesudah melewati ambang (ketukan biasa tak terganggu)');
  assert.match(f, /Math\.max\(0, Math\.min\(tabs\.length - 1/, 'posisi dijepit 0..n-1');
});
test('geser bar: lepas = meluncur ke tengah tab terdekat lewat navTo (easing tanpa pantulan), posisi pecahan memakai lebar tab pecahan', () => {
  assert.match(main, /function navUnit\(ind\)/);
  assert.match(main, /x \* navUnit\(ind\)/);
  assert.ok(!/x \* ind\.offsetWidth/.test(main), 'tidak lagi memakai offsetWidth yang dibulatkan');
  assert.ok(!/backOut|easeOutBack/.test(main), 'tanpa pantulan');
  assert.match(main, /navEl\.classList\.contains\('navhold'\) \? ' scale\(1\.07\)'/);
});
test('geser bar: CSS touch-action:none, tab asal tidak meninggalkan pil/ikon putih saat ditahan', () => {
  assert.match(css, /Rev 415[\s\S]*nav\{touch-action:none\}/);
  assert.match(css, /nav\.navhold button\.on::before\{opacity:0!important\}/);
  assert.match(css, /nav\.navhold button\.on:not\(\.lit\) svg/);
});
