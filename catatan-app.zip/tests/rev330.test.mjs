// Rev 330 / PART TB: pesan toast literal memakai nada EKSPLISIT lewat pembantu tOk/tWarn/tErr/tInfo (bukan tebakan kata).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { inventaris, ringkas } from '../tools/audit_toast_inventaris.mjs';
const ui = readFileSync(new URL('../src/js/ui.js', import.meta.url), 'utf8');
test('Rev 330: ui.js mengekspor empat pembantu nada yang meneruskan nada sebagai argumen ke-5', () => {
  assert.match(ui, /const toastN = \(n\) => \(m, u, a, l\) => toast\(m, u, a, l, n\);/);
  assert.match(ui, /export const tOk = toastN\('ok'\), tWarn = toastN\('warn'\), tErr = toastN\('err'\), tInfo = toastN\('info'\);/);
  assert.match(ui, /export function toast\(msg, undo, after, label = 'Urungkan', tone\)/); // tanda tangan toast tidak berubah
  assert.match(ui, /export function toastTone/); // cadangan untuk pesan dinamis tetap ada
});
test('Rev 330: TIDAK ADA lagi toast literal tanpa nada eksplisit (pesan baru wajib tOk/tWarn/tErr/tInfo)', () => {
  const telanjang = inventaris().filter((x) => x.jenis === 'literal' && !x.eksplisit);
  assert.deepEqual(telanjang.map((x) => x.berkas + ':' + x.baris + ' ' + x.pesan), [], 'pakai tOk/tWarn/tErr/tInfo untuk pesan literal');
});
test('Rev 330: jumlah pesan literal bernada eksplisit tercatat dan tersebar di banyak modul', () => {
  const b = inventaris(), r = ringkas(b), lit = b.filter((x) => x.jenis === 'literal');
  assert.ok(lit.length >= 130, 'literal ' + lit.length);
  assert.ok(lit.every((x) => ['ok', 'warn', 'err', 'info'].includes(x.eksplisit)));
  assert.ok(Object.keys(r.perBerkas).length >= 10);
});
test('Rev 330: setiap berkas yang memakai pembantu mengimpornya dari ui.js', () => {
  const b = inventaris(), per = {};
  for (const x of b) if (x.berkas !== 'ui.js') (per[x.berkas] ||= new Set());
  for (const f of Object.keys(per)) {
    const s = readFileSync(new URL('../src/js/' + f, import.meta.url), 'utf8');
    for (const n of ['tOk', 'tWarn', 'tErr', 'tInfo']) if (new RegExp('(?<![\\w.$])' + n + '\\(').test(s)) {
      const m = /import\s*\{([^}]*)\}\s*from\s*'\.{1,2}\/ui\.js'/.exec(s);
      assert.ok(m && m[1].split(',').map((t) => t.trim()).includes(n), f + ' belum mengimpor ' + n);
    }
  }
});
