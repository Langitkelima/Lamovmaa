// Rev 332 / PART TD: pemotongan teks > MAX_CELL (2000) di impor CSV dan Ganti semua tidak lagi diam-diam.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { importDelimited, replaceAll, textCut } from '../src/js/lembar-alat.js';
const ui = readFileSync(new URL('../src/js/lembar-ui.js', import.meta.url), 'utf8');
const mk = () => L.newSheet({ id: 's1', name: 'T' });
function tabBaru() { const s = mk(); return s.tabs[0]; }
test('Rev 332: textCut hanya benar untuk teks > 2000, bukan angka', () => {
  assert.equal(textCut('a'.repeat(2001)), true);
  assert.equal(textCut('a'.repeat(2000)), false);
  assert.equal(textCut('12345'), false);
  assert.equal(textCut(''), false);
});
test('Rev 332: impor CSV menghitung sel teks yang dipotong', () => {
  const tab = tabBaru(); const long = 'x'.repeat(2500);
  const r = importDelimited(tab, 'a,b\n' + long + ',ok\n', { replace: true });
  assert.equal(r.ok, true); assert.equal(r.truncatedText, 1);
  const r2 = importDelimited(tabBaru(), 'a,b\n1,2\n', { replace: true });
  assert.equal(r2.truncatedText, 0);
});
test('Rev 332: Ganti semua menghitung sel yang jadi terlalu panjang', () => {
  const tab = tabBaru(); importDelimited(tab, 'x\nx\n', { replace: true });
  const res = replaceAll(tab, 'x', 'y'.repeat(2500), {});
  assert.equal(res.cells, 2); assert.equal(res.truncatedText, 2);
  const res0 = replaceAll(tab, 'y', 'z', {}); assert.equal(res0.truncatedText, 0);
});
test('Rev 332: pesan impor dan ganti menyebut pemotongan + nada peringatan', () => {
  assert.ok(/truncatedText\) extra\.push\(r\.truncatedText \+ ' sel dipotong/.test(ui));
  assert.ok(/\(res\.truncatedText \|\| res\.truncatedRows \|\| res\.truncatedCols \? tWarn : toast\)\(importMessage\(res\)\)/.test(ui));
  assert.ok(/\(res\.truncatedText \? tWarn : toast\)\(replaceMessage\(res\)\)/.test(ui));
});
