// Tes Rev 29: mode Baca/Edit, aturan mode awal, ceklis dan tautan di Baca.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { modeFor, urlAtOffset } from '../src/js/logic.js';

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

t('mode awal: catatan baru/kosong Edit; catatan berisi Baca; Bagikan selalu Baca', () => {
  assert.equal(modeFor({ isNew: true, isEmpty: true }), 'edit');
  assert.equal(modeFor({ isNew: false, isEmpty: true }), 'edit');
  assert.equal(modeFor({ isNew: false, isEmpty: false }), 'baca');
  assert.equal(modeFor({ isNew: true, isEmpty: true, fromShare: true }), 'baca');
  assert.equal(modeFor({ isNew: false, isEmpty: false, fromShare: true }), 'baca');
  assert.equal(modeFor({ isNew: false, isEmpty: true, fromRelated: true }), 'baca');
  assert.equal(modeFor(), 'baca');
});
t('urlAtOffset: http, https, www, tanda baca, dan batas akhir URL', () => {
  const s = 'Lihat https://contoh.id/berita, lalu www.kelimaa.app. Selesai.';
  assert.equal(urlAtOffset(s, s.indexOf('https://') + 8), 'https://contoh.id/berita');
  assert.equal(urlAtOffset(s, s.indexOf('berita') + 3), 'https://contoh.id/berita');
  assert.equal(urlAtOffset(s, s.indexOf('www.') + 4), 'https://www.kelimaa.app');
  assert.equal(urlAtOffset(s, s.indexOf('berita') + 7), '');
  assert.equal(urlAtOffset('javascript:alert(1)', 5), '');
  assert.equal(urlAtOffset(s, NaN), '');
});
t('tombol mode ada di header antara penanda dan menu ⋮, ikon tujuan dan label aksesibel', () => {
  const nt = src('../src/js/notes.js');
  assert.match(nt, /marks,\s*modeBtn,\s*moreBtn/);
  assert.ok(nt.includes("class: 'ghost hmode'"));
  assert.ok(nt.includes("PATH.edit : PATH.tugas"));
  assert.ok(nt.includes("'Beralih ke mode Edit'"));
  assert.ok(nt.includes("'Selesai mengedit, beralih ke mode Baca'"));
});
t('mode Baca mematikan edit judul/isi, menyembunyikan bilah, tetapi bukan aksi menu nonteks', () => {
  const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css');
  for (const k of ["tt.readOnly = baca", "ed.contentEditable = baca ? 'false' : 'true'", "o.classList.toggle('ed-baca', baca)", "if (!initial && !baca)", "save();"]) assert.ok(nt.includes(k), k);
  assert.ok(css.includes('.fs.ed-baca .fbar{display:none}'));
  assert.ok(css.includes('@media(max-width:430px)') && css.includes('.fsh .hmode[aria-pressed=true]'));
  assert.ok(nt.includes("mi(PATH.tag, 'Label'") && nt.includes("mi(PATH.share, 'Bagikan'") && nt.includes("mi(PATH.copy, 'Buat salinan'"));
});
t('mode Baca tetap membolehkan seleksi teks, salin, dan klik kotak centang yang tersimpan', () => {
  const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css');
  assert.ok(css.includes('.fs.ed-baca .ed2{user-select:text;-webkit-user-select:text}'));
  assert.ok(nt.includes("ed.addEventListener('change'") && nt.includes("e.target.type === 'checkbox'") && nt.includes('e.target.toggleAttribute'));
  assert.ok(nt.includes("ed.addEventListener('click', openReadLink)"));
});
t('tautan isi dibuka hanya pada mode Baca lewat jembatan/peramban; mode Edit tidak mengambil alih ketukan', () => {
  const nt = src('../src/js/notes.js');
  assert.ok(nt.includes("editorMode !== 'baca'"));
  assert.ok(nt.includes('urlAtOffset(ed.textContent ||'));
  assert.ok(nt.includes('openExternal(url)'));
});
t('Bagikan Android memakai quiet=true sehingga modeFor memilih Baca; chip terkait juga membuka catatan lama', () => {
  const tr = src('../src/js/terima.js'), nt = src('../src/js/notes.js');
  assert.ok(tr.includes("openEditor(ctx, n.id, 'note', false, true)"));
  assert.ok(nt.includes('fromShare: quiet') && nt.includes('fromRelated: keepTrail'));
  assert.ok(nt.includes("openEditor(ctx, id, 'note', true)"));
});
t('mode hanya di memori, tanpa field pengaturan atau migrasi SCHEMA', () => {
  const nt = src('../src/js/notes.js'), st = src('../src/js/storage.js');
  assert.ok(nt.includes("let editorMode = 'edit'"));
  assert.ok(!nt.includes('data.settings.noteMode'));
  assert.match(st, /SCHEMA = 22/);
});
t('Rev 29b: pensil besar (FAB) di pojok kanan bawah hanya di mode Baca, tombol header disembunyikan di Baca', () => {
  const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css');
  assert.ok(nt.includes("class: 'fab efab'") && nt.includes("onclick: () => setMode('edit')"));
  assert.match(nt, /head, body, h\('div', \{ class: 'dock' \}[^\n]*editFab\)/);
  assert.ok(css.includes('.fs.ed-baca .efab{display:flex}'));
  assert.ok(css.includes('.fs .efab{display:none;'));
  assert.ok(css.includes('.fs.ed-baca .hmode{display:none}'));
  assert.ok(css.includes('.fs.ed-baca .fsb{padding-bottom:104px}'));
});
console.log(`\n${n} tes lulus (Rev 29)`);
