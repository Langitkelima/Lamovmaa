// Rev 293: pemilih templat dirapikan = urutan Fitur, Rumus, Admin, lalu templat lama; Penjualan dan Absensi lama dihapus (digantikan Admin).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN);
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const ids = () => T.templateList().map((t) => t.id);
test('Rev 293 (Rev 305: 35 templat dengan kelompok Centang): id unik, urutan = Fitur, Rumus, Admin, Centang, lama; awalan nama sesuai kelompok', () => {
  const l = T.templateList(); assert.equal(l.length, 35); assert.equal(new Set(ids()).size, 35);
  const g = (a, b) => l.slice(a, b).map((t) => t.name);
  for (const n of g(0, 5)) assert.match(n, /^Fitur · /); for (const n of g(5, 11)) assert.match(n, /^Rumus · /); for (const n of g(11, 20)) assert.match(n, /^Admin · /); for (const n of g(20, 25)) assert.match(n, /^Centang · /); for (const n of g(25, 35)) assert.doesNotMatch(n, /^(Fitur|Rumus|Admin|Centang) · /);
  assert.deepEqual(ids().slice(25), ['anggaran', 'bagi', 'jadwal', 'nilai', 'belajar', 'faktur', 'proyek', 'kebiasaan', 'olahraga', 'inventaris']);
});
test('Rev 293: Penjualan dan Absensi lama sudah tidak ada; padanannya (Admin) ada; semua templat tetap sah (failed 0, muat batas, bulat-balik)', () => {
  assert.equal(T.hasTemplate('penjualan'), false); assert.equal(T.hasTemplate('absensi'), false); assert.equal(T.makeFromTemplate('penjualan'), null);
  assert.ok(T.hasTemplate('admin-jual')); assert.ok(T.hasTemplate('admin-hadir'));
  for (const id of ids()) { const r = T.makeFromTemplate(id, { now: new Date(2026, 10, 14, 12).getTime() }); assert.ok(r, id); assert.equal(r.failed, 0, id); assert.ok(L.fitsLimit(r.sheet), id); assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(r.sheet)))), JSON.stringify(r.sheet), id); }
});
test('Rev 293: sumber tidak menyisakan data lama yang dihapus; pemilih di settings.js tidak berubah (daftar datar mengikuti urutan templateList)', () => {
  assert.doesNotMatch(src('src/js/templat-lama.js'), /id: 'penjualan'|id: 'absensi'/);
  assert.match(src('src/js/lembar-templat.js'), /\[\.\.\.FITUR, \.\.\.RUMUS, \.\.\.RUMUS2, \.\.\.ADMIN, \.\.\.ADMIN2, \.\.\.CENTANG, \.\.\.LAMA\]/);
  assert.match(src('src/js/settings.js'), /templateList\(\)\.map\(/); assert.doesNotMatch(src('src/js/settings.js'), /templat-lama|templat-admin|templat-fitur/);
});
