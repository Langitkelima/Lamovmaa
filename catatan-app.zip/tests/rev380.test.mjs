// Rev 380 / PART AL3b-2: pemilih mode pengingat (1B) di lembar baris centang dan kartu hitung mundur, lonceng baris bermode alarm (2B), modul MALAS alarm-ui.js.
import test from 'node:test'; import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { setCbRule, setCdRule, setCdMode, normalizeCbRule } from '../src/js/ingatkan.js';
import { alarmUnsupported, modeIconPath, MODE_CARDS, BELL_PATH, CLOCK_PATH } from '../src/js/alarm-ui.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('alarm-ui.js: dua kartu (Notifikasi, Alarm) dengan keterangan 1B; ikon lonceng vs jam alarm', () => {
  assert.deepEqual(MODE_CARDS.map((c) => c.id), ['notif', 'alarm']);
  assert.equal(MODE_CARDS[0].hint, 'Muncul diam-diam di bilah atas'); assert.equal(MODE_CARDS[1].hint, 'Berdering seperti jam alarm sampai dimatikan');
  assert.equal(modeIconPath('alarm'), CLOCK_PATH); assert.equal(modeIconPath('notif'), BELL_PATH); assert.equal(modeIconPath(undefined), BELL_PATH);
});
test('alarm-ui.js: peringatan APK lama hanya bila jembatan ada tetapi tanpa scheduleAlarm', () => {
  assert.equal(alarmUnsupported(null), false); assert.equal(alarmUnsupported({ scheduleNotification() {} }), true); assert.equal(alarmUnsupported({ scheduleAlarm() {} }), false);
});
test('alarm-ui.js: izin layar penuh lewat jembatan, dialog hanya saat izin false; tanpa kunci rahasia', () => {
  const m = src('src/js/alarm-ui.js');
  assert.ok(m.includes('fullScreenAllowed(a) !== false') && m.includes('openFullScreenSettings(a)') && m.includes("yes: 'Buka pengaturan'"));
  assert.ok(m.includes("role: 'radiogroup'") && m.includes("role: 'radio'") && m.includes('aria-checked'));
});
test('notes.js: alarm-ui.js dimuat MALAS (tidak ada impor statis), sheet baris centang dan hitung mundur memakai pemilih', () => {
  const n = src('src/js/notes.js');
  assert.ok(!/^import .* from '\.\/alarm-ui\.js'/m.test(n)); assert.equal((n.match(/import\('\.\/alarm-ui\.js'\)/g) || []).length, 3); /* Rev 383: 3 = baris centang, hitung mundur, + panel Pengingat catatan (ditambah Rev 381); semuanya malas */
  assert.ok(n.includes('openRemindSheetNow') && n.includes('openCdRemindSheetNow') && n.includes('A.modePicker('));
  assert.ok(n.includes('setCbRule(n, cid, { at, repeat, sticky: false, mode })') && n.includes('if (mp) setCdMode(n, bid, cdm)'));
  assert.ok(n.includes("cr && cr.mode === 'alarm' ? '2' : '1'") && n.includes("'\\u23F0 '"));
});
test('mesin: aturan baris centang menyimpan mode alarm saja; mode hitung mundur lewat setCdMode dan hilang bila notif', () => {
  const n = {}; assert.ok(setCbRule(n, 'cabc1', { at: 1900000000000, repeat: 'none', sticky: false, mode: 'alarm' })); assert.equal(n.cbRem.cabc1.mode, 'alarm');
  setCbRule(n, 'cabc1', { at: 1900000000000, repeat: 'none', sticky: false, mode: 'notif' }); assert.ok(!('mode' in n.cbRem.cabc1));
  assert.equal(normalizeCbRule({ at: 5, mode: 'x' }).mode, undefined);
  const c = {}; assert.equal(setCdMode(c, 'bab1', 'alarm'), false); // belum ada cdRem
  setCdRule(c, 'bab1', [0, 1]); assert.ok(setCdMode(c, 'bab1', 'alarm')); assert.equal(c.cdMode.bab1, 'alarm'); setCdMode(c, 'bab1', 'notif'); assert.ok(!('cdMode' in c));
});
test('CSS: kartu mode dan lonceng alarm (data-rem="2") memakai variabel tema; kurung seimbang; Kurangi Gerakan', () => {
  const css = src('src/css/styles.css'); const i = css.indexOf('Rev 380 / AL3b-2'); assert.ok(i > 0); const b = css.slice(i);
  for (const k of ['.am-cards{', '.am-card[aria-checked="true"]', '[data-rem="2"]::after', 'var(--acs)', 'prefers-reduced-motion']) assert.ok(b.includes(k), k);
  assert.ok(!/#[0-9a-fA-F]{6}/.test(b)); let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('tanpa perubahan SCHEMA/versi/native; modul statis tetap 53; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/); assert.ok(pk.scripts.test.includes('tests/rev380.test.mjs'));
  assert.ok(existsSync(new URL('../src/js/alarm-ui.js', import.meta.url)));
  const w = new URL('../www/index.html', import.meta.url); if (existsSync(w)) assert.equal((readFileSync(w, 'utf8').match(/data-kelimaa-preload/g) || []).length, 53);
});
