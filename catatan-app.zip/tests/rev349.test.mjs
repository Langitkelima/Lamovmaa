// Rev 349 / PART R4: lonceng item bullet/bernomor (li) hanya bila berpengingat; kabel sumber + CSS. Perilaku Chromium diaudit di R6.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { bellState } from '../src/js/ingatkan.js';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('R4: syncBells mengamati .todo dan li ber-cid; data-rem tetap atribut sementara (dibuang sanitize, tidak masuk riwayat)', () => {
  const s = read('src/js/notes.js');
  assert.match(s, /ed\.querySelectorAll\('\.todo,li\[data-cid\],li\[data-rem\]'\)\.forEach\(\(row\) => \{/);
  assert.match(s, /histHtml = \(\) => ed\.innerHTML\.replace\(\/ data-rem="\[\^"\]\*"\/g, ''\)/);
  assert.doesNotMatch(s, /k === 'data-rem'/, 'sanitize tidak pernah meloloskan data-rem');
});
test('R4: bellHit: li hanya bila data-rem ada dan ketukan di zona kanan-atas; baris centang tidak berubah', () => {
  const s = read('src/js/notes.js');
  assert.match(s, /e\.target\.closest\('\.todo,li'\)/);
  assert.match(s, /row\.tagName === 'LI' && \(!row\.hasAttribute\('data-rem'\) \|\| e\.clientY > r\.top \+ BELL_W\)\) return null/);
  assert.match(s, /return e\.clientX >= r\.right - BELL_W && e\.clientX <= r\.right \+ 2 \? row : null;/);
});
test('R4: bellState tanpa aturan = idle (itu sebabnya li butuh penjaga data-rem agar tidak ada lonceng kosong)', () => {
  assert.equal(bellState(null, false), 'idle');
  assert.equal(bellState({ at: Date.now() + 3600e3, repeat: 'none' }, false), 'on');
});
test('R4: CSS: lonceng li memakai gaya lonceng aktif yang sama (tanpa hex baru), hanya [data-rem], posisi absolut kanan-atas, mode nobell menyembunyikan', () => {
  const c = read('src/css/styles.css');
  assert.match(c, /\.ed2 \.todo\[data-rem\]::after,\.ed2 li\[data-rem\]::after\{content:""/);
  assert.match(c, /\.ed2 li\[data-rem\]::after\{border-color/);
  assert.match(c, /\.fs\.nobell \.ed2 \.todo::after,\.fs\.nobell \.ed2 li::after\{content:none!important\}/);
  const m = c.match(/\/\* Rev 349 \/ R4:[^\n]*\*\/\n([^\n]*)\n([^\n]*)/); assert.ok(m, 'blok R4 ada');
  assert.doesNotMatch(m[1] + m[2], /#[0-9a-fA-F]{3,8}\b|rgb\(/, 'blok baru tanpa warna hex/rgb');
  assert.match(m[1], /position:relative;padding-right:40px/); assert.match(m[2], /position:absolute;right:0;top:-2px/);
  assert.doesNotMatch(c, /\.ed2 li:not\(\[data-rem\]\)::after/, 'tidak ada lonceng kosong untuk li');
});
