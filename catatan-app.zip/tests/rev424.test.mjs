// Rev 424 / SY4a: build versi web (PWA). Memeriksa skrip build-web, hasil www-web/, dan bahwa APK (www/, src/) tidak berubah.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import { manifestWeb, tulisSw, sisipkanPwa, HEADERS } from '../scripts/build-web.mjs';

const baca = (p) => readFileSync(p, 'utf8');

test('manifest: standalone, tiga ikon, tanpa alamat Worker', () => {
  const m = manifestWeb();
  assert.equal(m.display, 'standalone');
  assert.equal(m.icons.length, 3);
  assert.ok(m.icons.some((i) => i.purpose === 'maskable'));
  assert.ok(!/workers\.dev|passcode/i.test(JSON.stringify(m)));
});

test('service worker: hanya GET se-asal, cache berversi, tanpa skipWaiting', () => {
  const sw = tulisSw('abc123', ['./', 'index.html']);
  assert.match(sw, /notes-kelimaa-/);
  assert.match(sw, /r\.method !== 'GET'/);
  assert.match(sw, /u\.origin !== self\.location\.origin/);
  assert.ok(!/skipWaiting\(\)/.test(sw.replace(/\/\/.*$/gm, '')));
  assert.doesNotThrow(() => new Function(sw.replace(/self\./g, 'globalThis.')));
});

test('sisipkanPwa: idempoten, hanya menambah manifest, tema, ikon, pendaftaran SW', () => {
  const asal = '<html><head><title>x</title></head><body><div id="app"></div></body></html>';
  const a = sisipkanPwa(asal), b = sisipkanPwa(a);
  assert.equal(a, b);
  assert.match(a, /rel="manifest"/);
  assert.match(a, /serviceWorker/);
  assert.match(a, /protocol!=="file:"/);
});

test('_headers: sw.js dan index.html tidak di-cache lama', () => {
  assert.match(HEADERS, /\/sw\.js\s+Cache-Control: no-cache/);
  assert.match(HEADERS, /\/index\.html\s+Cache-Control: no-cache/);
});

test('build:web menghasilkan www-web lengkap dan TIDAK mengubah www/APK', () => {
  execFileSync(process.execPath, ['scripts/build-web.mjs'], { stdio: 'pipe' });
  for (const f of ['index.html', 'sw.js', 'manifest.webmanifest', '_headers', 'ikon/ikon-192.png', 'ikon/ikon-512.png', 'ikon/ikon-maskable-512.png', 'js/main.js']) assert.ok(existsSync('www-web/' + f), f);
  const w = baca('www-web/index.html'), apk = baca('www/index.html');
  assert.match(w, /manifest\.webmanifest/);
  assert.ok(!/manifest\.webmanifest|serviceWorker/.test(apk), 'www/ (APK) tidak boleh berisi PWA');
  assert.ok(!/manifest\.webmanifest|serviceWorker/.test(baca('src/index.html')), 'src/ tidak boleh berubah');
  const sw = baca('www-web/sw.js');
  assert.ok(sw.includes('"js/main.js"') && sw.includes('"css/styles.css"') && !sw.includes('"sw.js"'));
});

test('tidak ada rahasia di www-web, .gitignore, dan skrip terdaftar', () => {
  for (const f of ['www-web/sw.js', 'www-web/manifest.webmanifest', 'www-web/index.html']) assert.ok(!/PASS_RAMA|PASS_DESY|KEYSTORE|workers\.dev/.test(baca(f)), f);
  assert.match(baca('.gitignore'), /^www-web\/$/m);
  const pk = JSON.parse(baca('package.json'));
  assert.equal(pk.scripts['build:web'], 'node scripts/build-web.mjs');
  assert.match(pk.scripts.test, /rev424\.test\.mjs/);
  assert.equal(pk.version, '0.3.121');
});
