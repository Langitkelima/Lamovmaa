// Rev 209 / v0.3.121: Kelimaa AI: pilih JALUR + MODEL (daftar atau ketik manual) dan BATAS harian (100/150/200/tanpa batas) dari aplikasi.
// Semua tes memakai fetch PALSU dan penyimpanan palsu (tanpa jaringan, tanpa kunci asli).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
import * as S from '../src/js/ai/sambungan.js';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const KEY = 'sk-FAKE-0123456789-tes', GKEY = 'AIza-FAKE-0123456789';
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), SAKELAR_KEY: KEY, GEMINI_KEY: GKEY, ...x });
const NOW = Date.UTC(2026, 10, 11, 5, 0, 0);
const post = (b) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify(b) });
const chatReq = (o = {}) => ({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', messages: [{ role: 'user', content: 'Halo' }], ...o });
const okJson = (o) => ({ ok: true, status: 200, json: async () => o });
const reply = () => okJson({ choices: [{ message: { content: 'Baik!' }, finish_reason: 'stop' }], usage: { prompt_tokens: 5, completion_tokens: 2 } });
async function run(env, b) {
  const calls = []; const orig = globalThis.fetch; globalThis.fetch = async (url, init) => { calls.push({ url, body: JSON.parse(init.body) }); return reply(); };
  try { const r = await T.handle(post(b), env, NOW); return { status: r.status, j: await r.json(), calls }; } finally { globalThis.fetch = orig; }
}
const store = () => { const m = new Map(); return { m, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };

test('Worker: jalur dari aplikasi menang atas CHAT_PROVIDER/urutan; jalur tak dikenal atau tanpa kunci ditolak tanpa memakai jatah', async () => {
  const g = await run(env0(), chatReq({ provider: 'gemini' })); assert.equal(g.j.provider, 'gemini'); assert.match(g.calls[0].url, /generativelanguage/);
  assert.equal((await run(env0({ CHAT_PROVIDER: 'sakelar' }), chatReq({ provider: 'Gemini' }))).j.provider, 'gemini');
  assert.equal((await run(env0(), chatReq({ provider: '' }))).j.provider, 'sakelar'); // kosong = otomatis
  for (const bad of ['anthropic', 'constructor', '__proto__', 5]) { const e = env0(); const r = await run(e, chatReq({ provider: bad })); assert.equal(r.status, 400, String(bad)); assert.equal(r.calls.length, 0); assert.equal(e.KV.m.size, 0); }
  const e = env0({ GEMINI_KEY: undefined }); const r = await run(e, chatReq({ provider: 'gemini' }));
  assert.equal(r.status, 503); assert.match(r.j.error, /GEMINI_KEY/); assert.equal(r.calls.length, 0); assert.equal(e.KV.m.size, 0);
});

test('Worker: model dari aplikasi dipakai apa adanya (daftar atau manual); bentuk tidak sah = 400 tanpa jatah; kosong = bawaan', async () => {
  const a = await run(env0(), chatReq({ model: 'anthropic/haiku-5.5' })); assert.equal(a.j.model, 'anthropic/haiku-5.5'); assert.equal(a.calls[0].body.model, 'anthropic/haiku-5.5');
  const b = await run(env0(), chatReq({ provider: 'gemini', model: '  gemini-9.9-eksperimen  ' })); assert.equal(b.j.model, 'gemini-9.9-eksperimen');
  assert.equal((await run(env0({ MODEL_SAKELAR: 'dari-env-1' }), chatReq({ model: '' }))).j.model, 'dari-env-1'); // kosong = env/bawaan
  for (const bad of ['a', 'model aneh; DROP', 'x'.repeat(90), '../etc', 123, { a: 1 }]) { const e = env0(); const r = await run(e, chatReq({ model: bad })); assert.equal(r.status, 400, String(bad)); assert.equal(r.calls.length, 0); assert.equal(e.KV.m.size, 0); }
  const rl = await run(env0({ SAKELAR_KEY: undefined, GEMINI_KEY: undefined, RELAY_KEY: 'rl-FAKE-0123456789' }), chatReq({ model: 'model-uji-9' })); assert.equal(rl.j.model, 'model-uji-9'); // Relay kini bisa tanpa MODEL_RELAY
});

test('Worker: batas dari aplikasi (100/150/200), 0 = TANPA BATAS tanpa KV, tanpa batas dari aplikasi = DAILY_LIMIT/100', async () => {
  assert.equal(T.limitFor({}, { limit: 150 }), 150); assert.equal(T.limitFor({}, { limit: 0 }), 0); assert.equal(T.limitFor({}, {}), 100);
  assert.equal(T.limitFor({ DAILY_LIMIT: '7' }, {}), 7); assert.equal(T.limitFor({ DAILY_LIMIT: '7' }, { limit: 200 }), 200);
  for (const x of [-5, 0.5, 'abc', null, NaN]) assert.equal(T.limitFor({}, { limit: x }), 100, String(x)); assert.equal(T.limitFor({}, { limit: 99999 }), 10000);
  const e = env0(); for (let i = 1; i <= 2; i++) assert.equal((await run(e, chatReq({ limit: 2 }))).j.used, i);
  const full = await run(e, chatReq({ limit: 2 })); assert.equal(full.status, 429); assert.match(full.j.error, /2\/2/); assert.match(full.j.error, /Tanpa batas/); assert.equal(full.calls.length, 0);
  const naik = await run(e, chatReq({ limit: 150 })); assert.equal(naik.status, 200); assert.equal(naik.j.limit, 150); assert.equal(naik.j.used, 3); // batas dinaikkan = lanjut
  const t = await run(e, chatReq({ limit: 0 })); assert.equal(t.status, 200); assert.equal(t.j.limit, 0); assert.equal(t.j.used, 4); // tanpa batas tetap menghitung (info)
  const hold = env0(); for (let i = 0; i < 5; i++) assert.equal((await run(hold, chatReq({ limit: 0 }))).status, 200);
  const noKv = await run(env0({ KV: undefined }), chatReq({ limit: 0 })); assert.equal(noKv.status, 200); assert.equal(noKv.j.used, null); assert.equal(noKv.j.limit, 0);
  const noKv2 = await run(env0({ KV: undefined }), chatReq({ limit: 100 })); assert.equal(noKv2.status, 503); assert.match(noKv2.j.error, /Tanpa batas/);
  const rusak = env0({ KV: { get: async () => { throw new Error('x'); }, put: async () => { throw new Error('x'); } } }); assert.equal((await run(rusak, chatReq({ limit: 0 }))).status, 200); // KV rusak tidak memblokir mode tanpa batas
});

test('Aplikasi: cleanModel / cleanLimit; pilihan batas persis 100, 150, 200, tanpa batas; daftar model hanya nama yang ada di panduan', () => {
  assert.deepEqual(S.LIMIT_CHOICES.map((x) => x[0]), [100, 150, 200, 0]); assert.equal(S.LIMIT_CHOICES[3][1], 'Tanpa batas');
  assert.deepEqual(S.cleanModel('  gemini-3.5-flash '), { ok: true, value: 'gemini-3.5-flash' }); assert.deepEqual(S.cleanModel(''), { ok: true, value: '' }); assert.equal(S.cleanModel('a b').ok, false); assert.equal(S.cleanModel('ab').ok, false);
  assert.equal(S.cleanLimit(0), 0); assert.equal(S.cleanLimit('0'), 0); assert.equal(S.cleanLimit(150), 150); assert.equal(S.cleanLimit('abc'), 100); assert.equal(S.cleanLimit(-1), 100); assert.equal(S.cleanLimit(1e9), 10000);
  assert.deepEqual(S.MODEL_PRESETS.sakelar, ['deepseek/deepseek-v4-flash', 'anthropic/haiku-5.5']); assert.deepEqual(S.MODEL_PRESETS.gemini, ['gemini-3.5-flash', 'gemini-3.5-flash-lite']); assert.deepEqual(S.MODEL_PRESETS.relay, []);
  const panduan = src('backend/cloudflare/PANDUAN_WORKER.md'); for (const m of Object.values(S.MODEL_PRESETS).flat()) assert.ok(panduan.includes(m), m);
  for (const m of Object.values(S.MODEL_PRESETS).flat()) assert.equal(S.cleanModel(m).ok, true, m);
});

test('Aplikasi: cfg menyimpan on + jalur + model + batas; bawaan mati, otomatis, bawaan Worker, batas 100; data rusak dibersihkan; saveCfg tidak menghapus pilihan lain', () => {
  const st = store(); assert.deepEqual(S.loadCfg(st), { on: false, provider: '', model: '', limit: 100 });
  S.saveCfg({ on: true, provider: 'gemini', model: 'gemini-3.5-flash', limit: 0 }, st); assert.deepEqual(S.loadCfg(st), { on: true, provider: 'gemini', model: 'gemini-3.5-flash', limit: 0 });
  S.saveCfg({ ...S.loadCfg(st), limit: 200 }, st); assert.deepEqual(S.loadCfg(st), { on: true, provider: 'gemini', model: 'gemini-3.5-flash', limit: 200 });
  st.setItem(S.CFG_KEY, JSON.stringify({ on: true, provider: 'anthropic', model: 'a b', limit: 'x' })); assert.deepEqual(S.loadCfg(st), { on: true, provider: '', model: '', limit: 100 });
  st.setItem(S.CFG_KEY, JSON.stringify({ on: true })); assert.equal(S.loadCfg(st).limit, 100); // data lama (hanya on) tetap sah
  st.setItem(S.CFG_KEY, 'bukan json'); assert.deepEqual(S.loadCfg(st), { on: false, provider: '', model: '', limit: 100 });
  assert.deepEqual(S.chatOpts({ on: true, provider: 'sakelar', model: 'anthropic/haiku-5.5', limit: 150 }), { provider: 'sakelar', model: 'anthropic/haiku-5.5', limit: 150 });
  assert.equal(S.pilihanText({ on: true, provider: 'gemini', model: 'gemini-3.5-flash', limit: 0 }), 'Gemini \u00b7 gemini-3.5-flash \u00b7 tanpa batas');
  assert.equal(S.pilihanText(null), 'Jalur otomatis \u00b7 model bawaan Worker \u00b7 batas 100/hari');
});

test('Aplikasi: kirimChat mengirim provider/model/limit hanya bila ada; tanpa opts isi permintaan sama seperti Rev 208; model tak sah ditolak sebelum kirim', async () => {
  const CONN = { url: 'https://kelimaa-ai.contoh.workers.dev', key: 'passcode-uji-123' }, M = [{ role: 'user', content: 'hai' }];
  let seen; const http = async (q) => { seen = JSON.parse(q.body); return { status: 200, text: JSON.stringify({ ok: true, text: 'ya', model: 'm', provider: 'gemini', used: 1, limit: 0 }) }; };
  let r = await S.kirimChat(CONN, M, http); assert.deepEqual(seen, { key: 'passcode-uji-123', action: 'chat', task: 'chat.general', messages: M }); assert.equal(r.limit, 0);
  await S.kirimChat(CONN, M, http, { provider: 'gemini', model: 'gemini-3.5-flash', limit: 0 }); assert.deepEqual(seen, { key: 'passcode-uji-123', action: 'chat', task: 'chat.general', messages: M, provider: 'gemini', model: 'gemini-3.5-flash', limit: 0 });
  await S.kirimChat(CONN, M, http, { provider: '', model: '', limit: 150 }); assert.deepEqual(seen, { key: 'passcode-uji-123', action: 'chat', task: 'chat.general', messages: M, limit: 150 });
  let dikirim = false; r = await S.kirimChat(CONN, M, async () => { dikirim = true; return { status: 200, text: '{}' }; }, { model: 'a b' }); assert.equal(r.ok, false); assert.equal(dikirim, false);
});

test('Struktur: layar punya pilihan jalur, model (daftar + ketik manual), dan 4 tombol batas; chat memakai pilihan itu; tidak menyentuh data aplikasi', () => {
  const lyr = src('src/js/ai/layar.js'); assert.match(lyr, /PROVIDER_CHOICES/); assert.match(lyr, /MODEL_PRESETS/); assert.match(lyr, /LIMIT_CHOICES/); assert.match(lyr, /Ketik manual/); assert.match(lyr, /Bawaan Worker/);
  assert.match(lyr, /saveCfg\(\{ \.\.\.loadCfg\(\), on \}\)/); assert.doesNotMatch(lyr, /innerHTML|insertAdjacentHTML/);
  const ob = src('src/js/ai/obrolan.js'); assert.match(ob, /chatOpts\(loadCfg\(\)\)/); assert.doesNotMatch(ob, /innerHTML|localStorage|catatan_app_data/);
  const lg = src('src/js/ai/sambungan.js'); assert.deepEqual([...lg.matchAll(/^import .*$/gm)].map((x) => x[0]), ["import { isNative, nativePlugin } from '../native.js';"]); assert.doesNotMatch(lg, /document\.|window\./);
  assert.match(src('backend/cloudflare/worker.mjs'), /Rev 209/); assert.match(src('backend/cloudflare/PANDUAN_WORKER.md'), /Rev 209/);
});

test('versi 0.3.121, SCHEMA 18 tetap, tes terdaftar', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev209\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/);
});
