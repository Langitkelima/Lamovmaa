// Rev 212 / v0.3.121: langkah 3 rencana desain = layar CHAT KELIMAA AI bergaya Stiker Tebal (judul KELIMAA AI, balon bergaris tebal, avatar bintang, jam di balon, kolom ketik terbaca di gelap/terang). Alur kirim/riwayat/galat TIDAK berubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as S from '../src/js/ai/sambungan.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('obrolan.js: judul KELIMAA AI, kolom ketik + tombol kirim berikon, jam lewat data-t, balasan tetap lewat textContent, tanpa HTML mentah/penyimpanan', () => {
  const ob = src('src/js/ai/obrolan.js');
  for (const k of ["class: 'kc'", "class: 'kai-logo'", "'KELIMAA '", "class: 'kc-dock'", "class: 'kc-send'", "'aria-label': 'Kirim'", "setAttribute('data-t'", 'isiBot(w, isi)', "'Hapus riwayat?'", 'chatOpts(loadCfg())', "'Mengetik\u2026'"]) assert.ok(ob.includes(k), k);
  assert.doesNotMatch(ob, /innerHTML|insertAdjacentHTML|outerHTML|localStorage|sessionStorage|console\./);
});
test('riwayat membawa jam, tetapi yang dikirim ke Worker tetap hanya {role, content}', () => {
  const m = S.buildMessages([{ role: 'user', content: 'a', t: '10:00' }, { role: 'assistant', content: 'b', t: '10:01' }], 'c');
  assert.deepEqual(m, [{ role: 'user', content: 'a' }, { role: 'assistant', content: 'b' }, { role: 'user', content: 'c' }]);
});
test('CSS Rev 212: balon, avatar bintang (data-URI tanpa heks), jam, galat, kolom ketik berwarna tema, tombol kirim; tanpa blur', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 223'); assert.ok(i > 0); const r = css.slice(i); /* Rev 223: gaya Stiker Tebal di layar chat diganti desain layar penuh */
  for (const k of ['.kc .aib::after{content:attr(data-t)', '.kc .aib.bot{', '.kc-in{', 'color:var(--ink)', '.kc-send{', '.kc .aib.err{', '#app.aifull>nav{display:none}']) assert.ok(r.includes(k), k);
  assert.doesNotMatch(r, /#[0-9a-fA-F]{6}|backdrop-filter|blur\(/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('versi 0.3.121, SCHEMA 18 tetap, tes terdaftar', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev212\.test\.mjs/);
});
