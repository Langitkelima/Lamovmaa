// Rev 252 / S3: titik seret seleksi di lembar-ui.js (kabel + model). Tes Node; BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as S from '../src/js/lembar-seleksi.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
const between = (a, b) => ui.slice(ui.indexOf(a), ui.indexOf(b, ui.indexOf(a)));
test('dua pegangan .lz-hd di luar body; letak per jenis seleksi', () => {
  assert.match(ui, /const hdA = h\('div', \{ class: 'lz-hd'/); assert.match(ui, /inner\.append\(hdA, hdB\)/);
  const p = between('const paintSelBox = () => {', 'let hd = null;');
  for (const w of ["'br'", "'tl'", "'tr'", "'bl'"]) assert.ok(p.includes(w), w); assert.ok(p.includes("sx.kind === 'all'"));
  assert.match(css, /\.lz-hd\{[^}]*width:44px;height:44px[^}]*touch-action:none/); assert.match(css, /\.lz-hd::after\{[^}]*width:14px;height:14px/);
  assert.doesNotMatch(css, /\.lz-scroll\{[^}]*touch-action:none/, 'gulir bawaan tetap');
});
test('seret: jangkar tetap via SX.extend, pointer capture, auto-gulir rAF, hanya hidup di layar', () => {
  const d = between('let hd = null;', '// Rev 184b: posisi atas');
  for (const k of ['SX.extend(', 'setPointerCapture', 'requestAnimationFrame(hdTick)', 'scroller.scrollTop += dy', 'scroller.scrollLeft += dx', 'lostpointercapture', 'pointercancel']) assert.ok(d.includes(k), k);
  assert.doesNotMatch(d, /hist\.push|touched\(|persist|localStorage|onChange|ver\+\+/);
  assert.ok(d.includes("w === 'tl' ? SX.selectRange(dm, { r: rc.r2, c: rc.c2 }"), 'seret kiri-atas = jangkar di kanan-bawah');
  assert.ok(ui.includes('if (hd) { cancelAnimationFrame(hd.raf); hd = null; }'), 'tutup layar membatalkan seret');
  assert.ok(d.includes('SX.sig(n) === SX.sig(selx)'), 'tidak menggambar ulang bila sel yang disentuh tidak berganti');
});
test('Rev 131/148/251 tidak berubah; mode Pilih rentang lama sudah DIHAPUS (Rev 258, D-S2)', () => {
  assert.ok(!ui.includes("item('rentang'") && !ui.includes('startRange')); assert.ok(ui.includes('if (again && (() => { const pk = checkAt(tab, sel.r, sel.c); return !!pk && pk.dd !== false; })()) openPick();'));
  assert.match(ui, /e\.stopImmediatePropagation\(\); e\.preventDefault\(\);\s*const r = insertRef\(/);
});
test('model: extend dari jangkar (cell/range/row/col), semua tak berubah, gabungan utuh', () => {
  const D = { rows: 30, cols: 26 }, a = S.selectRange(D, { r: 1, c: 1 }, { r: 4, c: 3 });
  assert.deepEqual(S.extend(D, a, { r: 6, c: 5 }).rect, { r1: 1, c1: 1, r2: 6, c2: 5 }); assert.deepEqual(S.extend(D, a, { r: 0, c: 0 }).rect, { r1: 0, c1: 0, r2: 1, c2: 1 });
  assert.deepEqual(S.extend(D, S.selectCol(D, 2), { r: 9, c: 4 }).rect, { r1: 0, c1: 2, r2: 29, c2: 4 }); assert.deepEqual(S.extend(D, S.selectRow(D, 3), { r: 6, c: 0 }).rect, { r1: 3, c1: 0, r2: 6, c2: 25 });
  assert.equal(S.extend(D, S.selectAll(D), { r: 2, c: 2 }).kind, 'all'); assert.deepEqual(S.extend(D, S.selectCell(D, 2, 2), { r: 2, c: 4 }, [{ r1: 2, c1: 4, r2: 3, c2: 5 }]).rect, { r1: 2, c1: 2, r2: 3, c2: 5 });
});
test('paket: versi 0.3.121, SCHEMA 20, tes terdaftar, banner Rev 252 + uji HP H', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev252\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.ok(src('RIWAYAT.md').includes('**Rev 252 / v0.3.121')); assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 252 / v0.3.121')); assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('BERIKUTNYA: Rev 253 / S4'));
  assert.match(src('UJI_HP_RILIS.md'), /## H\. Titik seret seleksi \(Rev 252/);
});
