// Rev 184a / U10e-1: TINGGI BARIS BEBAS, model + penyimpanan (SCHEMA 18, tanpa UI). Berkas rev187 = Rev 184a.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as A from '../src/js/lembar-alat.js';
import * as S from '../src/js/storage.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet({ name: 'T' }); return { sh, tab: sh.tabs[0] }; };

test('cleanRowH: bulat, minimal 16, tanpa batas atas buatan, bawaan 40 = tidak disimpan, tak sah = tidak ada', () => {
  assert.equal(L.cleanRowH(80), 80); assert.equal(L.cleanRowH(80.6), 81); assert.equal(L.cleanRowH('120'), 120);
  assert.equal(L.cleanRowH(5), L.ROW_H_MIN); assert.equal(L.cleanRowH(-30), L.ROW_H_MIN); assert.equal(L.cleanRowH(0), L.ROW_H_MIN);
  assert.equal(L.cleanRowH(40), undefined); assert.equal(L.cleanRowH(40.2), undefined);
  for (const bad of [NaN, Infinity, -Infinity, null, undefined, '', '  ', 'abc', {}, [], true]) assert.equal(L.cleanRowH(bad), undefined);
  assert.equal(L.cleanRowH(5000), 5000); assert.equal(L.cleanRowH(250000), 250000); // tinggi besar tetap sah (tanpa batas atas buatan)
  assert.equal(L.cleanRowH(1e12), L.ROW_H_SANE); // hanya pagar data rusak
  assert.equal(L.ROW_H_DEF, 40);
});

test('setRowHeight: mengubah hanya baris itu; baris lain dan data lama tidak punya kunci h', () => {
  const { tab } = mk(); const before = JSON.stringify(tab);
  assert.equal(L.setRowHeight(tab, 'r2', 120), true); assert.equal(tab.rows[1].h, 120);
  assert.equal(tab.rows.filter((r) => 'h' in r).length, 1); assert.equal(L.rowHeight(tab, 'r2'), 120); assert.equal(L.rowHeight(tab, 'r1'), 40);
  assert.equal(L.rowHeightAt(tab, 1), 120); assert.equal(L.rowHeightAt(tab, 0), 40); assert.equal(L.rowHeightAt(tab, 999), 40);
  assert.equal(L.setRowHeight(tab, 'r2', 120), false); // sama = tidak berubah
  assert.equal(L.setRowHeight(tab, 'r2', 40), true); assert.ok(!('h' in tab.rows[1])); // kembali ke bawaan = kunci dibuang
  assert.equal(JSON.stringify(tab), before); // sama persis dengan data lama
  assert.equal(L.setRowHeight(tab, 'r2', 'abc'), false); assert.equal(L.setRowHeight(tab, 'zz', 90), false); assert.equal(L.setRowHeight(tab, 'r1', null), false);
  assert.equal(JSON.stringify(tab), before);
  L.setRowHeight(tab, 'r3', 3); assert.equal(tab.rows[2].h, L.ROW_H_MIN); // terlalu kecil dinaikkan ke batas bawah
  assert.equal(L.setRowHeight(tab, 'r3', null), true); assert.ok(!('h' in tab.rows[2]));
});

test('cleanTab/cleanSheet: h dipertahankan lewat JSON; nilai rusak dibersihkan; tanpa h tetap sama persis', () => {
  const { sh, tab } = mk(); L.setRowHeight(tab, 'r1', 200); L.setRowHeight(tab, 'r4', 17); L.setCell(tab, 'r1', 'cA', { v: 'x' });
  const back = L.cleanSheet(JSON.parse(JSON.stringify(sh))); const t2 = back.tabs[0];
  assert.equal(t2.rows[0].h, 200); assert.equal(t2.rows[3].h, 17); assert.equal(t2.rows[1].h, undefined); assert.equal(t2.rows[0].cells.cA.v, 'x');
  const raw = JSON.parse(JSON.stringify(sh)); raw.tabs[0].rows[1].h = 'jahat'; raw.tabs[0].rows[2].h = { x: 1 }; raw.tabs[0].rows[4].h = 2; raw.tabs[0].rows[5].h = 40;
  const c = L.cleanSheet(raw).tabs[0];
  assert.ok(!('h' in c.rows[1])); assert.ok(!('h' in c.rows[2])); assert.equal(c.rows[4].h, L.ROW_H_MIN); assert.ok(!('h' in c.rows[5]));
  const plain = L.newSheet({ name: 'P' }); assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(plain)))), JSON.stringify(plain));
  assert.ok(!JSON.stringify(plain).includes('"h"'));
});

test('sisip, hapus, dan urut baris: h mengikuti BARISNYA (bukan posisi)', () => {
  const { tab } = mk(); L.setRowHeight(tab, 'r2', 100); L.setRowHeight(tab, 'r3', 60);
  const id = L.insertRow(tab, 1); assert.ok(id); assert.equal(L.rowHeight(tab, id), 40); // baris baru = bawaan
  assert.equal(tab.rows[2].id, 'r2'); assert.equal(tab.rows[2].h, 100); assert.equal(tab.rows[3].h, 60); // yang lama bergeser bersama h-nya
  assert.equal(L.deleteRow(tab, 'r2'), true); assert.equal(tab.rows.some((r) => r.h === 100), false); assert.equal(L.rowHeight(tab, 'r3'), 60);
  const { tab: t2 } = mk(); ['b', 'c', 'a'].forEach((v, i) => L.setCell(t2, 'r' + (i + 2), 'cA', { v })); L.setCell(t2, 'r1', 'cA', { v: 'Nama' });
  L.setRowHeight(t2, 'r2', 111); L.setRowHeight(t2, 'r3', 222); L.setRowHeight(t2, 'r4', 333); // b=111, c=222, a=333
  const res = A.sortTab(t2, 0, 'asc', { header: true }); assert.equal(res.ok, true);
  assert.deepEqual(t2.rows.slice(1, 4).map((r) => [r.cells.cA.v, r.h]), [['a', 333], ['b', 111], ['c', 222]]);
  assert.equal(t2.rows[0].h, undefined);
});

test('Urungkan: snapshot JSON (ser) memulihkan h; ikut batas ukuran lembar (fitsLimit)', () => {
  const { sh, tab } = mk(); L.setRowHeight(tab, 'r2', 90);
  const snap = JSON.stringify({ name: sh.name, tabs: sh.tabs }); L.setRowHeight(tab, 'r2', 400); L.setRowHeight(tab, 'r5', 55);
  const o = JSON.parse(snap); sh.name = o.name; sh.tabs = o.tabs; // sama dengan restore() di lembar-ui.js
  assert.equal(L.rowHeight(sh.tabs[0], 'r2'), 90); assert.equal(L.rowHeight(sh.tabs[0], 'r5'), 40);
  assert.ok(L.fitsLimit(sh)); assert.ok(L.sheetBytes(sh) > L.sheetBytes(L.newSheet({ name: 'T' })));
});

test('storage: SCHEMA 18; data penuh bertahan lewat normalize + ekspor JSON; data SCHEMA 17 lama tetap dimuat', () => {
  assert.equal(S.SCHEMA, 22);
  const { sh, tab } = mk(); L.setRowHeight(tab, 'r3', 150);
  const d = S.emptyData(); d.sheets = { [sh.id]: sh };
  const n = S.normalize(JSON.parse(S.exportJSON ? S.exportJSON(d) : JSON.stringify(d))); assert.ok(n);
  assert.equal(n.sheets[sh.id].tabs[0].rows[2].h, 150); assert.equal(n.version, 22);
  const old = S.emptyData(); const s2 = L.newSheet({ name: 'Lama' }); old.sheets = { [s2.id]: s2 }; old.version = 17;
  const n2 = S.normalize(JSON.parse(JSON.stringify(old))); assert.ok(n2); assert.equal(n2.sheets[s2.id].tabs[0].rows.length, s2.tabs[0].rows.length);
  assert.ok(!JSON.stringify(n2.sheets[s2.id]).includes('"h"'));
});

test('Rev 184a: tanpa UI/CSS/native; ROW_H lembar-ui = ROW_H_DEF; versi 0.3.121; SCHEMA 18; tes terdaftar', () => {
  const ui = src('js/lembar-ui.js'); const m = /export const ROW_H = (\d+)/.exec(ui); assert.equal(Number(m[1]), L.ROW_H_DEF);
  assert.doesNotMatch(ui, /cleanRowH|ROW_H_MIN/); // Rev 184b: grid kini memakai L.setRowHeight (UI seret), tetapi pembersih model tetap hanya di lembar.js
  assert.doesNotMatch(src('js/lembar.js'), /localStorage|document\.|window\.|eval\(|new Function/);
  const pk = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.equal(pk.version, '0.3.121'); assert.ok(src('js/settings.js').includes('Notes Kelimaa v0.3.121')); assert.match(src('js/storage.js'), /SCHEMA\s*=\s*22\b/);
  assert.ok(pk.scripts.test.includes('tests/rev187.test.mjs'));
});
