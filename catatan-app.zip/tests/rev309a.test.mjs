// Rev 309a / v0.3.121: pencatat riwayat token (tanpa UI). Modul murni + penerusan `usage` + anggaran JS.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as R from '../src/js/ai/riwayat-token.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mem = () => { const m = new Map(); return { m, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };
const NOW = new Date(2026, 10, 15, 12, 0, 0).getTime(), HARI = 86400000;
test('buatEntri: pakai usage Worker; kosong/0 = perkiraan estTokens + tanda est', () => {
  const a = R.buatEntri({ now: NOW, pesan: '  halo\n dunia ', usage: { in: 120, out: 30 }, kirimChars: 10, balasChars: 10, sumber: ['tugas'] });
  assert.deepEqual(a, { t: NOW, m: 'halo dunia', in: 120, out: 30, src: ['tugas'] });
  const b = R.buatEntri({ now: NOW, pesan: 'x', usage: { in: 0, out: 0 }, kirimChars: 350, balasChars: 70, sumber: [] });
  assert.equal(b.est, true); assert.equal(b.in, 100); assert.equal(b.out, 20);
  assert.equal(R.buatEntri({ now: 'x', pesan: 'a' }), null);
});
test('awal pesan maks. 40 huruf; sumber asing dan ganda dibuang', () => {
  const e = R.buatEntri({ now: NOW, pesan: 'a'.repeat(100), usage: { in: 1, out: 1 }, sumber: ['tugas', 'tugas', 'catatan', 'lampiran', 7] });
  assert.equal(e.m.length, 40); assert.deepEqual(e.src, ['tugas', 'lampiran']);
});
test('rapikan: buang rusak dan > 30 hari, urut lama ke baru, maks. 200', () => {
  const list = [{ t: NOW - 31 * HARI, in: 1, out: 1 }, null, { t: NOW, in: -1, out: 1 }, { t: NOW - HARI, m: 'b', in: 2, out: 2 }, { t: NOW - 2 * HARI, m: 'a', in: 3, out: 3 }];
  assert.deepEqual(R.rapikan(list, NOW).map((e) => e.m), ['a', 'b']);
  const banyak = Array.from({ length: 250 }, (_, i) => ({ t: NOW - i * 1000, m: String(i), in: 1, out: 1 }));
  const r = R.rapikan(banyak, NOW); assert.equal(r.length, 200); assert.equal(r[r.length - 1].m, '0');
});
test('catat/muat/hapusSemua: simpan terpisah, penyimpanan rusak tidak melempar galat, isi balasan tidak disimpan', () => {
  const st = mem(); assert.deepEqual(R.muat(NOW, st), []);
  assert.equal(R.catat(R.buatEntri({ now: NOW, pesan: 'tes', usage: { in: 5, out: 6 } }), NOW, st).ok, true);
  assert.equal(R.muat(NOW, st).length, 1); assert.ok(st.m.has(R.RW_KEY)); assert.equal(R.RW_KEY, 'kelimaa_ai_riwayat');
  assert.doesNotMatch(st.m.get(R.RW_KEY), /content|text/);
  assert.equal(R.hapusSemua(st).ok, true); assert.deepEqual(R.muat(NOW, st), []);
  const rusak = { getItem() { throw new Error('x'); }, setItem() { throw new Error('x'); }, removeItem() { throw new Error('x'); } };
  assert.deepEqual(R.muat(NOW, rusak), []); assert.equal(R.catat({ t: NOW, m: '', in: 1, out: 1, src: [] }, NOW, rusak).ok, false); assert.equal(R.catat(null, NOW, st).ok, false);
  st.m.set(R.RW_KEY, '{bukan json'); assert.deepEqual(R.muat(NOW, st), []);
});
test('ringkasan: hari ini, 7 hari, bulan ini; est menular; tujuhHari 7 kolom', () => {
  const list = [{ t: NOW, in: 10, out: 5, src: [] }, { t: NOW - 3 * HARI, in: 20, out: 0, est: true, src: [] }, { t: NOW - 9 * HARI, in: 100, out: 100, src: [] }];
  const r = R.ringkasan(list, NOW); assert.deepEqual(r.hari, { in: 10, out: 5, n: 1, est: false }); assert.deepEqual(r.minggu, { in: 30, out: 5, n: 2, est: true }); assert.equal(r.bulan.n, 3);
  const g = R.tujuhHari(list, NOW); assert.equal(g.length, 7); assert.equal(g[6].total, 15); assert.equal(g[3].total, 20); assert.equal(g[3].est, true);
});
test('usage diteruskan: kirimChat dan kirimRiset meneruskan usage Worker yang valid', () => {
  const sb = src('src/js/ai/sambungan.js'); assert.equal((sb.match(/usage: cleanTokens\(j\.usage\)/g) || []).length, 2);
  const ob = src('src/js/ai/obrolan.js'); assert.match(ob, /from '\.\/riwayat-token\.js'/); assert.match(ob, /usage: res\.usage/);
  assert.ok(ob.indexOf('catat(buatEntri(') > ob.indexOf('if (res.ok) {'), 'hanya di jalur berhasil'); assert.match(ob, /riwayat gagal tidak boleh mengganggu chat/);
});
test('modul riwayat tanpa DOM; anggaran JS 1400 KB (Rev 336: 1360 -> 1400 atas izin pengguna; Rev 318)', () => {
  const m = src('src/js/ai/riwayat-token.js'); assert.doesNotMatch(m, /document\.|innerHTML|window\./);
  assert.match(src('tools/audit-ukuran.mjs'), /jsMaks: 1600 \* 1024, totalMaks: 2100 \* 1024/);
});
