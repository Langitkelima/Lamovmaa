import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const notes = fs.readFileSync(new URL('../src/js/notes.js', import.meta.url), 'utf8');
const main = fs.readFileSync(new URL('../src/js/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
test('Rev 66: catatan biasa memiliki kontrol favorit yang persisten pada objek catatan', () => {
  assert.match(notes, /n\.favorite = !n\.favorite/);
  assert.match(notes, /class: 'cbd favb/);
  assert.match(notes, /Tambahkan ke Favorit/);
});
test('Rev 66: ruang Favorit hanya menampilkan catatan biasa yang ditandai', () => {
  assert.match(notes, /allArr\.filter\(\(x\) => x\.favorite === true\)/);
  assert.match(notes, /favoritesRoom \? 'Belum ada catatan favorit/);
  assert.match(notes, /ui\.favoritesRoom = !favoritesRoom/);
});
test('Rev 66: tombol kembali Android keluar dari ruang Favorit dan FAB tidak menutupi ruang', () => {
  assert.match(main, /ui\.tab === 'catatan' && ui\.favoritesRoom/);
  assert.match(main, /ui\.tab === 'catatan' && !ui\.favoritesRoom/);
});
test('Rev 66: pintasan Favorit tampil estetik di kanan header dan kartu punya ikon favorit', () => {
  assert.match(css, /\.notes-heading/);
  assert.match(css, /\.fav-room-btn/);
  assert.match(css, /\.card \.favb/);
});
