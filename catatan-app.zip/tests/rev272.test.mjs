// Rev 272 / V6a (paket Validasi, bagian 29): hapus baris/kolom di tepi rentang = rentang MENYUSUT (tidak melebar), urut baris = aturan tetap di posisi. Tes Node; BUKAN uji HP.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as V from '../src/js/lembar-validasi.js';
import { sortTab } from '../src/js/lembar-alat.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = () => L.newSheet({ id: 'v', name: 'v' }).tabs[0];
const base = (t, extra) => ({ c: t.cols[0].id, k: 'list', items: ['x', 'y'], ...extra });

test('hapus baris: ujung atas/bawah menyusut ke tetangga di dalam rentang, tengah tidak mengubah ID', () => {
  const t = mk(), a = t.cols[0].id, r = t.rows.map((x) => x.id);
  L.setChecks(t, [base(t, { rg: { c2: a, r1: r[2], r2: r[5] } })]);
  L.deleteRow(t, r[3]); assert.deepEqual(t.checks[0].rg, { c2: a, r1: r[2], r2: r[5] }); // tengah
  L.deleteRow(t, r[5]); assert.deepEqual(t.checks[0].rg, { c2: a, r1: r[2], r2: r[4] }); // ujung bawah
  L.deleteRow(t, r[2]); assert.deepEqual(t.checks[0].rg, { c2: a, r1: r[4], r2: r[4] }); // ujung atas (tinggal baris r[4])
  assert.equal(V.rangeText(t, t.checks[0]), 'A' + (t.rows.findIndex((x) => x.id === r[4]) + 1));
});
test('hapus baris: rentang satu baris yang dihapus = aturan dibuang (kunci checks hilang)', () => {
  const t = mk(), a = t.cols[0].id, r = t.rows.map((x) => x.id);
  L.setChecks(t, [base(t, { rg: { c2: a, r1: r[4], r2: r[4] } })]);
  L.deleteRow(t, r[4]); assert.equal(t.checks, undefined); assert.equal('checks' in t, false);
});
test('hapus baris: batas terbuka tetap terbuka; rentang kolom penuh tidak tersentuh; data tanpa aturan tetap bersih', () => {
  const t = mk(), a = t.cols[0].id, b = t.cols[1].id, r = t.rows.map((x) => x.id), last = r[r.length - 1];
  L.setChecks(t, [base(t, { rg: { c2: a, r1: r[3] } }), base(t, { c: b, rg: undefined })]);
  assert.equal(t.checks.length, 2);
  L.deleteRow(t, last); assert.deepEqual(t.checks[0].rg, { c2: a, r1: r[3] }, 'tetap terbuka ke bawah');
  L.deleteRow(t, r[3]); assert.deepEqual(t.checks[0].rg, { c2: a, r1: r[4] }, 'batas atas maju ke baris berikutnya');
  assert.equal(t.checks[1].rg, undefined); assert.equal(t.checks[1].c, b);
  const u = mk(); L.deleteRow(u, u.rows[0].id); assert.equal('checks' in u, false);
});
test('hapus kolom: ujung kiri/kanan menyusut, tengah tidak mengubah, kolom tunggal = aturan dibuang', () => {
  const t = mk(), [a, b, c, d] = t.cols.map((x) => x.id), r = t.rows.map((x) => x.id);
  L.setChecks(t, [{ c: a, k: 'list', items: ['x'], rg: { c2: d, r1: r[1], r2: r[3] } }]);
  L.deleteCol(t, b); assert.deepEqual([t.checks[0].c, t.checks[0].rg.c2], [a, d], 'tengah: ujung tetap');
  L.deleteCol(t, a); assert.deepEqual([t.checks[0].c, t.checks[0].rg.c2], [c, d], 'kiri: maju ke kolom berikutnya dalam rentang');
  assert.deepEqual([t.checks[0].rg.r1, t.checks[0].rg.r2], [r[1], r[3]], 'batas baris ikut terbawa');
  L.deleteCol(t, d); assert.deepEqual([t.checks[0].c, t.checks[0].rg.c2], [c, c], 'kanan: mundur ke kolom sebelumnya');
  L.deleteCol(t, c); assert.equal(t.checks, undefined, 'kolom tunggal terakhir hilang = aturan dibuang');
});
test('hapus kolom: aturan kolom penuh multi-kolom menyusut jadi satu kolom penuh (rg hilang), bukan ikut terhapus', () => {
  const t = mk(), [a, b] = t.cols.map((x) => x.id);
  L.setChecks(t, [{ c: a, k: 'list', items: ['x'], rg: { c2: b } }]);
  L.deleteCol(t, b); assert.equal(t.checks[0].c, a); assert.equal(t.checks[0].rg, undefined); assert.equal(V.rangeText(t, t.checks[0]), 'A:A');
});
test('hapus banyak baris/kolom lewat aksi seleksi memakai jalur yang sama', () => {
  const m = src('src/js/lembar-aksi-seleksi.js'); assert.match(m, /L\.deleteRow\(tab, id\)/); assert.match(m, /L\.deleteCol\(tab, id\)/);
  const t = mk(), a = t.cols[0].id, r = t.rows.map((x) => x.id);
  L.setChecks(t, [base(t, { rg: { c2: a, r1: r[1], r2: r[4] } })]);
  for (const id of [r[4], r[3], r[1]]) L.deleteRow(t, id); assert.deepEqual([t.checks[0].rg.r1, t.checks[0].rg.r2], [r[2], r[2]]);
});
test('urut baris: rentang bertepi tetap di POSISI (indeks), bukan ikut ID baris', () => {
  const t = mk(), a = t.cols[0].id, r = t.rows.map((x) => x.id);
  ['d', 'a', 'c', 'b', 'e'].forEach((v, i) => L.setCell(t, r[i], a, { v }));
  L.setChecks(t, [base(t, { rg: { c2: a, r1: r[1], r2: r[2] } })]);
  const before = V.checkRect(t, t.checks[0]);
  const res = sortTab(t, 0, 'asc', { header: false }); assert.ok(res.ok && res.moved > 0);
  const after = V.checkRect(t, t.checks[0]); assert.deepEqual(after, before, 'persegi indeks sama');
  assert.equal(t.checks[0].rg.r1, t.rows[1].id); assert.equal(t.checks[0].rg.r2, t.rows[2].id);
});
test('urut baris: batas terbuka, kolom penuh, dan urut tanpa perpindahan tidak mengubah aturan', () => {
  const t = mk(), a = t.cols[0].id, b = t.cols[1].id, r = t.rows.map((x) => x.id);
  ['c', 'b', 'a'].forEach((v, i) => L.setCell(t, r[i], a, { v }));
  L.setChecks(t, [base(t, { rg: { c2: a, r1: r[1] } }), base(t, { c: b })]);
  const s0 = JSON.stringify(t.checks); sortTab(t, 0, 'desc', { header: false }); // sudah menurun: tak ada yang pindah
  assert.equal(JSON.stringify(t.checks), s0);
  sortTab(t, 0, 'asc', { header: false }); assert.equal(t.checks[0].rg.r1, t.rows[1].id); assert.equal(t.checks[0].rg.r2, undefined); assert.equal(t.checks[1].rg, undefined);
});
test('gabung/pisah sel tidak mengubah aturan validasi (ID stabil)', () => {
  const t = mk(), a = t.cols[0].id, r = t.rows.map((x) => x.id);
  L.setChecks(t, [base(t, { rg: { c2: a, r1: r[1], r2: r[3] } })]); const s0 = JSON.stringify(t.checks);
  L.mergeCells(t, 5, 0, 5, 1); L.unmergeCell(t, 5, 0); assert.equal(JSON.stringify(t.checks), s0);
});
test('sisip baris/kolom: di DALAM rentang ikut tercakup, di tepi (sebelum awal / sesudah akhir) di LUAR (seperti Sheets)', () => {
  const t = mk(), a = t.cols[0].id, b = t.cols[1].id, r = t.rows.map((x) => x.id);
  L.setChecks(t, [base(t, { rg: { c2: b, r1: r[2], r2: r[4] } })]);
  L.insertRow(t, 3); assert.ok(V.checkAt(t, 3, 0), 'baris baru di tengah tercakup'); assert.deepEqual([V.checkRect(t, t.checks[0]).r1, V.checkRect(t, t.checks[0]).r2], [2, 5]);
  L.insertRow(t, 2); assert.equal(V.checkAt(t, 2, 0), null, 'sisip tepat di atas awal = di luar'); assert.ok(V.checkAt(t, 3, 0), 'rentang bergeser turun');
  const e = V.checkRect(t, t.checks[0]).r2; L.insertRow(t, e + 1); assert.equal(V.checkAt(t, e + 1, 0), null, 'sisip tepat di bawah akhir = di luar');
  L.deleteCol(t, t.cols[t.cols.length - 1].id); // lembar baru sudah 26 kolom (batas): beri ruang dulu
  assert.ok(L.insertCol(t, 1)); assert.ok(V.checkAt(t, 3, 1), 'kolom baru di tengah tercakup'); assert.equal(V.checkRect(t, t.checks[0]).c2, 2);
  L.deleteCol(t, t.cols[t.cols.length - 1].id); assert.ok(L.insertCol(t, 0)); assert.equal(V.checkAt(t, 3, 0), null, 'sisip di kiri awal = di luar');
});
test('kode: trimChecks dipanggil SEBELUM splice; modul tetap murni; SCHEMA tetap 20', () => {
  const l = src('src/js/lembar.js'); assert.ok(l.indexOf("trimChecks(tab, 'r', rowId)") < l.indexOf('tab.rows.splice(i, 1)')); assert.ok(l.indexOf("trimChecks(tab, 'c', colId)") < l.indexOf('tab.cols.splice(i, 1)'));
  assert.doesNotMatch(src('src/js/lembar-validasi.js'), /document\.|localStorage|eval\(|Capacitor|^import /m);
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
});
