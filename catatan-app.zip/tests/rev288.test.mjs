// Rev 288 / T3: kelompok templat "Rumus" bagian 1 (Hitung dasar + Statistik): nilai kunci dihitung mesin rumus sungguhan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN);
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 14, 12, 0, 0).getTime();
const IDS = ['rumus-dasar', 'rumus-statistik'];
const mk = (id) => T.makeFromTemplate(id, { now: NOW });
test('Rev 288: dua templat Rumus ada, nama <= 30, keterangan, Panduan terakhir, failed 0, muat batas, tanpa galat rumus', () => {
  const ids = T.templateList().map((t) => t.id); for (const id of IDS) assert.ok(ids.includes(id), id); assert.equal(new Set(ids).size, ids.length);
  for (const id of IDS) {
    const t = T.templateList().find((x) => x.id === id); assert.ok(t.name.startsWith('Rumus · ') && t.name.length <= 30 && t.desc.length >= 20 && t.desc.length <= 100, id);
    const r = mk(id); assert.ok(r, id); assert.equal(r.failed, 0, id); assert.ok(L.fitsLimit(r.sheet)); const tabs = r.sheet.tabs;
    assert.equal(tabs[tabs.length - 1].name, 'Panduan', id); assert.ok(tabs.length <= 5);
    for (const tab of tabs) { const d = makeDisplay(tab); for (let i = 0; i < tab.rows.length; i++) for (let j = 0; j < tab.cols.length; j++) assert.doesNotMatch(String(d.text(i, j)), /^#/, id + ' ' + L.cellAddr(j, i)); }
    const c = L.cleanSheet(JSON.parse(JSON.stringify(r.sheet))); assert.equal(c.tabs.length, tabs.length, id); assert.equal((c.tabs[0].rules || []).length, (tabs[0].rules || []).length, id);
  }
});
test('Rev 288: Hitung dasar = hasil tiap baris benar; teks rumus tanpa "=" cocok dengan rumus hidup', () => {
  const tab = mk('rumus-dasar').sheet.tabs[0], d = makeDisplay(tab);
  const want = { 1: 150, 2: 90, 3: 96, 4: 12.5, 5: 2, 6: 1024, 7: 12, 8: 0.75, 9: 0.25, 10: 222000, 11: 120000, 12: 2.8, 13: 2.3, 14: 2.7, 15: 7, 16: 45 };
  for (const [i, v] of Object.entries(want)) assert.ok(Math.abs(d.raw(+i, 3) - v) < 1e-9, 'baris ' + (+i + 1) + ': ' + d.raw(+i, 3));
  for (let i = 1; i <= 16; i++) { const t = String(d.text(i, 4)); assert.doesNotMatch(t, /^=/); assert.ok(t.includes('(') || /[+\-*]/.test(t), t); }
  assert.equal(String(d.text(8, 3)), '75%'); assert.equal(String(d.text(9, 3)), '25%');
  // bagi dilindungi IFERROR: pembagi 0 -> 0, bukan galat
  const r2 = mk('rumus-dasar').sheet, t2 = r2.tabs[0]; L.setCell(t2, t2.rows[4].id, t2.cols[2].id, { v: 0 }); assert.equal(makeDisplay(t2).raw(4, 3), 0);
});
test('Rev 288: Statistik = nilai kunci benar (620, 77,5, 55, 92, 8, 8, 81,5, 88, 60, peringkat 4) dan ikut berubah saat data diubah', () => {
  const tab = mk('rumus-statistik').sheet.tabs[0], d = makeDisplay(tab);
  assert.deepEqual(Array.from({ length: 10 }, (_, i) => d.raw(i + 1, 4)), [620, 77.5, 55, 92, 8, 8, 81.5, 88, 60, 4]);
  assert.equal(tab.rules.length, 2);
  L.setCell(tab, tab.rows[1].id, tab.cols[1].id, { v: 100 }); const d2 = makeDisplay(tab); assert.equal(d2.raw(1, 4), 635); assert.equal(d2.raw(10, 4), 1); assert.equal(d2.raw(4, 4), 100); // MAX ikut naik
});
test('Rev 288: modul data murni; hanya fungsi yang ada; templat lama dan Fitur tetap di depan; mesin dan settings tidak menyebut berkas data', () => {
  const s = src('src/js/templat-rumus.js'); assert.doesNotMatch(s, /import |localStorage|document\.|window\.|eval\(|new Function/);
  const ada = new Set([...src('src/js/rumus.js').matchAll(/^\s{2}([A-Z][A-Z0-9]+): \{ min:/gm)].map((m) => m[1]));
  const used = new Set([...s.matchAll(/'(=[^']*)'/g)].flatMap((m) => [...m[1].matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1]))); assert.ok(used.size >= 10); for (const f of used) assert.ok(ada.has(f), f);
  const ids = T.templateList().map((t) => t.id); assert.deepEqual(ids.slice(-10, -6), ['anggaran', 'bagi', 'jadwal', 'nilai']); assert.equal(ids.length, 35); assert.deepEqual(ids.slice(0, 5), ['fitur-tur', 'fitur-warna', 'fitur-dropdown', 'fitur-diagram', 'fitur-filter']);
  for (const f of ['settings', 'lembar', 'lembar-ui', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /templat-rumus/, f);
});
