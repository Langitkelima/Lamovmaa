// Rev 304b / v0.3.121: seret lebar kolom beku saat sedang menyempit dikoreksi faktor (jari 1 px = 1/faktor px data). SCHEMA 22, CSS tidak berubah.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as B from '../src/js/lembar-beku.js';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('rzDown menyimpan faktor hanya untuk kolom beku; rzMove membagi selisih jari dengan faktor', () => {
  const ui = src('src/js/lembar-ui.js'); assert.match(ui, /fs: i < getFreeze\(tab\)\.c \? fzS\(\) : 1/); assert.match(ui, /dragWidth\(rz\.w, \(e\.clientX - rz\.x\) \/ \(rz\.fs \|\| 1\)\)/);
});
test('matematika: faktor 0,5 -> geser jari 20 px = +40 px di data; faktor 1 tidak berubah', () => {
  const s = B.fzScale(400, 200, 200); assert.equal(s, 0.5); assert.equal(20 / s, 40); assert.equal(20 / B.fzScale(150, 200, 200), 20);
});
test('versi 0.3.121, SCHEMA 22', () => { assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA = 22/); });
console.log(n + ' tes rev304b ok');
