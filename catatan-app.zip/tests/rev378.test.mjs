// Rev 378 / PART AL2 + AL2b: model `mode` ('notif' | 'alarm') + pemilih jembatan JS, TANPA UI. Tes Node (jembatan Android palsu).
import test from 'node:test'; import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { normalizeReminder, scheduleReminder, scheduleSubReminder, syncTaskAlarms } from '../src/js/reminders.js';
import { cleanMode, withMode, pushSchedule, canScheduleAlarm, fullScreenAllowed, openFullScreenSettings, cleanSubs } from '../src/js/logic.js';
import { normalizeCbRule, cleanCbRem, planCbAlarms, planCdAlarms, cleanCdMode, cleanNoteRem, setCdMode, clearCdRule } from '../src/js/ingatkan.js';
import { syncNoteAlarms, reconcileNoteAlarms } from '../src/js/cb-alarm.js';
import { cleanCfg, isDefaultCfg, DEFAULT_CFG } from '../src/js/twopockets.js';
import { planAlarms, applyAlarms, setItemCfg } from '../src/js/tp-alarm.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 21, 10, 0).getTime(), HOUR = 3600000, DAY = 86400000;
const fake = (withAlarm = true) => {
  const calls = [];
  const a = { scheduleNotification: (...x) => { calls.push(['notif', ...x]); return 'scheduled'; }, cancelScheduledNotification() {}, requestNotificationPermission() {} };
  if (withAlarm) a.scheduleAlarm = (...x) => { calls.push(['alarm', ...x]); return 'scheduled'; };
  return { a, calls };
};
const withApi = (a, fn) => { const old = globalThis.AndroidAPI; globalThis.AndroidAPI = a; try { return fn(); } finally { if (old === undefined) delete globalThis.AndroidAPI; else globalThis.AndroidAPI = old; } };

test('logic (bagian mode): cleanMode, withMode (kunci hanya bila alarm), pushSchedule memilih jembatan', () => {
  assert.equal(cleanMode('alarm'), 'alarm'); assert.equal(cleanMode('x'), 'notif'); assert.equal(cleanMode(undefined), 'notif');
  assert.deepEqual(withMode({ a: 1 }, 'notif'), { a: 1 }); assert.deepEqual(withMode({ a: 1 }, 'alarm'), { a: 1, mode: 'alarm' });
  const f = fake(); const r1 = pushSchedule(f.a, 'i', 't', 'm', 5000, 0, 'alarm'); const r2 = pushSchedule(f.a, 'i', 't', 'm', 5000, 0, 'notif');
  assert.deepEqual([f.calls[0][0], f.calls[1][0]], ['alarm', 'notif']); assert.equal(r1.fellBack, false); assert.equal(r2.via, 'notif');
  assert.deepEqual(f.calls[0].slice(1), ['i', 't', 'm', 5000, 0]);
});
test('logic (bagian mode): APK lama tanpa scheduleAlarm jatuh ke notifikasi dan diberi tanda fellBack', () => {
  const f = fake(false); assert.equal(canScheduleAlarm(f.a), false);
  const r = pushSchedule(f.a, 'i', 't', 'm', 5000, 0, 'alarm');
  assert.equal(r.via, 'notif'); assert.equal(r.fellBack, true); assert.equal(f.calls[0][0], 'notif');
});
test('logic (bagian mode): izin layar penuh dibaca aman (null bila tak ada, melempar jadi null)', () => {
  assert.equal(fullScreenAllowed(null), null); assert.equal(fullScreenAllowed({}), null);
  assert.equal(fullScreenAllowed({ canUseFullScreenAlarm: () => true }), true); assert.equal(fullScreenAllowed({ canUseFullScreenAlarm: () => false }), false);
  assert.equal(fullScreenAllowed({ canUseFullScreenAlarm() { throw new Error('x'); } }), null);
  let n = 0; assert.equal(openFullScreenSettings({ openFullScreenAlarmSettings: () => { n++; } }), true); assert.equal(n, 1);
  assert.equal(openFullScreenSettings({}), false); assert.equal(openFullScreenSettings({ openFullScreenAlarmSettings() { throw new Error('x'); } }), false);
});

test('tugas/catatan: normalizeReminder menyimpan mode HANYA bila alarm; data lama persis sama', () => {
  assert.deepEqual(normalizeReminder({ at: 5, repeat: 'once' }), { at: 5, repeat: 'once' });
  assert.deepEqual(normalizeReminder({ at: 5, repeat: 'daily', mode: 'alarm' }), { at: 5, repeat: 'daily', mode: 'alarm' });
  assert.deepEqual(normalizeReminder({ at: 5, mode: 'bogus' }), { at: 5, repeat: 'once' });
  assert.equal(normalizeReminder({ at: 0, mode: 'alarm' }), null);
});
test('tugas: scheduleReminder mode alarm memanggil scheduleAlarm, mode notif tetap scheduleNotification', () => {
  const f = fake();
  withApi(f.a, () => {
    scheduleReminder('task', { id: 't1', title: 'Bayar', reminder: { at: NOW + HOUR, repeat: 'once', mode: 'alarm' } }, NOW);
    scheduleReminder('task', { id: 't2', title: 'Biasa', reminder: { at: NOW + HOUR, repeat: 'daily' } }, NOW);
  });
  assert.equal(f.calls[0][0], 'alarm'); assert.equal(f.calls[0][1], 'task:t1'); assert.equal(f.calls[0][4], HOUR);
  assert.equal(f.calls[1][0], 'notif'); assert.equal(f.calls[1][5], DAY);
});
test('tugas: APK lama = notifikasi + alarmFallback true (hasil memberi tahu pemanggil)', () => {
  const f = fake(false);
  const r = withApi(f.a, () => scheduleReminder('task', { id: 't1', title: 'x', reminder: { at: NOW + HOUR, repeat: 'once', mode: 'alarm' } }, NOW));
  assert.equal(r.ok, true); assert.equal(r.alarmFallback, true); assert.equal(f.calls[0][0], 'notif');
  const r2 = withApi(f.a, () => scheduleReminder('task', { id: 't2', title: 'x', reminder: { at: NOW + HOUR, repeat: 'once' } }, NOW));
  assert.equal(r2.alarmFallback, undefined);
});
test('sub-tugas: mode dibersihkan di cleanSubs dan dipakai scheduleSubReminder + syncTaskAlarms', () => {
  const subs = cleanSubs([{ id: 's1', title: 'A', reminder: { at: NOW + HOUR, repeat: 'once', mode: 'alarm' } }, { id: 's2', title: 'B', reminder: { at: NOW + HOUR, repeat: 'once', mode: 'zzz' } }]);
  assert.equal(subs[0].reminder.mode, 'alarm'); assert.equal('mode' in subs[1].reminder, false);
  const f = fake();
  withApi(f.a, () => syncTaskAlarms({ id: 'T', title: 'Induk', remMode: 'subs', subs }, NOW));
  const bySub = Object.fromEntries(f.calls.map((c) => [c[1], c[0]]));
  assert.equal(bySub['sub:T:s1'], 'alarm'); assert.equal(bySub['sub:T:s2'], 'notif');
});

test('baris centang: aturan membawa mode, rencana menyalinnya (harian, bulanan 12 id, sekali)', () => {
  assert.deepEqual(normalizeCbRule({ at: NOW + HOUR, repeat: 'daily', mode: 'alarm' }), { at: NOW + HOUR, repeat: 'daily', sticky: false, mode: 'alarm' });
  assert.equal('mode' in normalizeCbRule({ at: NOW + HOUR, repeat: 'daily' }), false);
  assert.equal(cleanCbRem({ abcde: { at: NOW + HOUR, repeat: 'none', mode: 'alarm' } }).abcde.mode, 'alarm');
  const rows = { abcde: { text: 'Minum obat', done: false }, fghij: { text: 'Biasa', done: false }, klmno: { text: 'Bulan', done: false } };
  const note = { id: 'N1', title: 'Cat', cbRem: { abcde: { at: NOW + HOUR, repeat: 'daily', mode: 'alarm' }, fghij: { at: NOW + HOUR, repeat: 'none' }, klmno: { at: NOW + HOUR, repeat: 'monthly', mode: 'alarm' } } };
  const plan = planCbAlarms(note, rows, NOW);
  assert.equal(plan.find((p) => p.id === 'cb:N1:abcde').mode, 'alarm');
  assert.equal('mode' in plan.find((p) => p.id === 'cb:N1:fghij'), false);
  const bulanan = plan.filter((p) => p.id.startsWith('cb:N1:klmno:m')); assert.equal(bulanan.length, 12); assert.ok(bulanan.every((p) => p.mode === 'alarm'));
});
test('hitung mundur: cdMode terpisah, hanya untuk kartu berpengingat; planCdAlarms menyalin mode', () => {
  assert.deepEqual(cleanCdMode({ abc: 'alarm', def: 'notif', 'x y': 'alarm' }), { abc: 'alarm' });
  assert.deepEqual(cleanCdMode({ abc: 'alarm', def: 'alarm' }, ['def']), { def: 'alarm' });
  const note = { id: 'N2', title: 'Ulang tahun', cdRem: { abc: [0, 1], def: [0] }, cdMode: { abc: 'alarm' } };
  const blocks = { abc: { date: '2026-12-25', time: '09:00', title: 'Natal' }, def: { date: '2026-12-26', time: '09:00', title: 'Lain' } };
  const plan = planCdAlarms(note, blocks, NOW);
  assert.ok(plan.filter((p) => p.id.startsWith('cd:N2:abc')).every((p) => p.mode === 'alarm') && plan.filter((p) => p.id.startsWith('cd:N2:abc')).length === 2);
  assert.equal('mode' in plan.find((p) => p.id.startsWith('cd:N2:def')), false);
  const n = { id: 'N3', cdRem: { abc: [0] } };
  assert.equal(setCdMode(n, 'abc', 'alarm'), true); assert.deepEqual(n.cdMode, { abc: 'alarm' });
  assert.equal(setCdMode(n, 'zzz', 'alarm'), false, 'kartu tanpa pengingat ditolak');
  assert.equal(setCdMode(n, 'abc', 'notif'), true); assert.equal('cdMode' in n, false);
  setCdMode(n, 'abc', 'alarm'); clearCdRule(n, 'abc'); assert.equal('cdMode' in n, false, 'mode ikut hilang bersama aturan');
});
test('cleanNoteRem membuang cdMode kartu yang hilang; reconcileNoteAlarms ikut memangkasnya', () => {
  const html = '<div class="kb-countdown-block" data-kb-id="abc" data-kb-date="2026-12-25" data-kb-time="09:00" data-kb-title="Natal"></div>';
  const c = cleanNoteRem({ html, cdRem: { abc: [0], gone: [0] }, cdMode: { abc: 'alarm', gone: 'alarm' } });
  assert.deepEqual(c.cdRem, { abc: [0] }); assert.deepEqual(c.cdMode, { abc: 'alarm' });
  assert.equal('cdMode' in cleanNoteRem({ html, cdRem: { abc: [0] } }), false, 'tanpa mode, bentuk lama {cbRem, cdRem} utuh');
  const note = { id: 'N4', title: 'x', html, cdRem: { abc: [0], gone: [0] }, cdMode: { abc: 'alarm', gone: 'alarm' } };
  const f = fake();
  const r = withApi(f.a, () => reconcileNoteAlarms(note, NOW));
  assert.equal(r.pruned, true); assert.deepEqual(note.cdMode, { abc: 'alarm' });
});
test('syncNoteAlarms: baris/kartu mode alarm lewat scheduleAlarm, sisanya scheduleNotification', () => {
  const html = '<div class="todo" data-cid="abcde"><input type="checkbox">Minum</div><div class="todo" data-cid="fghij"><input type="checkbox">Biasa</div><div class="kb-countdown-block" data-kb-id="abc" data-kb-date="2026-12-25" data-kb-time="09:00" data-kb-title="Natal"></div>';
  const note = { id: 'N5', title: 'C', html, cbRem: { abcde: { at: NOW + HOUR, repeat: 'none', mode: 'alarm' }, fghij: { at: NOW + HOUR, repeat: 'none' } }, cdRem: { abc: [0] }, cdMode: { abc: 'alarm' } };
  const f = fake(); const res = withApi(f.a, () => syncNoteAlarms(note, NOW));
  const by = Object.fromEntries(f.calls.map((c) => [c[1], c[0]]));
  assert.equal(by['cb:N5:abcde'], 'alarm'); assert.equal(by['cb:N5:fghij'], 'notif'); assert.equal(by['cd:N5:abc:0'], 'alarm');
  assert.ok(res.every((x) => x.ok));
  const f2 = fake(false); const res2 = withApi(f2.a, () => syncNoteAlarms(note, NOW));
  assert.ok(f2.calls.every((c) => c[0] === 'notif')); assert.equal(res2.filter((x) => x.alarmFallback).length, 2);
});

test('Two Pockets: cleanCfg membawa mode hanya bila alarm; isDefaultCfg TIDAK menganggap mode alarm sebagai bawaan', () => {
  assert.deepEqual(cleanCfg({}), { on: true, hour: 8, min: 0, before: [7, 0], late: true });
  assert.equal(cleanCfg({ mode: 'alarm' }).mode, 'alarm'); assert.equal('mode' in cleanCfg({ mode: 'x' }), false);
  assert.equal(isDefaultCfg({ ...DEFAULT_CFG }), true); assert.equal(isDefaultCfg({ ...DEFAULT_CFG, mode: 'alarm' }), false);
});
test('Two Pockets: setItemCfg TIDAK menghapus pengaturan bermode alarm (bahaya yang tercatat di 38.3)', () => {
  const mem = {}; const store = { getItem: (k) => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: (k) => { delete mem[k]; } };
  setItemCfg('it1', { ...DEFAULT_CFG, mode: 'alarm' }, { now: NOW, store });
  const saved = JSON.parse(mem['kelimaa_twopockets_alarmcfg']); assert.equal(saved.it1.mode, 'alarm');
  setItemCfg('it1', { ...DEFAULT_CFG }, { now: NOW, store });
  assert.equal('it1' in (JSON.parse(mem['kelimaa_twopockets_alarmcfg'] || '{}')), false, 'konfigurasi bawaan notif tetap dihapus seperti dulu');
});
test('Two Pockets: planAlarms menyalin mode untuk servis, tagihan, utang; applyAlarms meneruskan ke jembatan', () => {
  const items = [{ id: 'sv1', name: 'Servis', vehicle: 'Motor', status: 'segera', dueDate: '2026-11-28', daysLeft: 7, kmLeft: null }, { id: 'sv2', name: 'Pajak', status: 'segera', dueDate: '2026-11-28', daysLeft: 7, kmLeft: null }];
  const bills = [{ id: 'b1', name: 'Listrik', nextDue: '2026-11-30', status: 'aman' }];
  const debts = [{ id: 'd1', person: 'Budi', kind: 'utang', due: '2026-11-29', left: 50000 }];
  const cfgs = { sv1: cleanCfg({ mode: 'alarm' }), bil_b1: cleanCfg({ mode: 'alarm' }), dbt_d1: cleanCfg({ mode: 'alarm' }) };
  const plan = planAlarms(items, NOW, cfgs, bills, debts);
  assert.ok(plan.filter((p) => p.id.startsWith('tp:sv1')).length >= 1 && plan.filter((p) => p.id.startsWith('tp:sv1')).every((p) => p.mode === 'alarm'));
  assert.ok(plan.filter((p) => p.id.startsWith('tp:sv2')).every((p) => !('mode' in p)));
  assert.ok(plan.filter((p) => p.id.startsWith('tpb:b1')).every((p) => p.mode === 'alarm'));
  assert.ok(plan.filter((p) => p.id.startsWith('tpd:d1')).every((p) => p.mode === 'alarm'));
  const f = fake(); const r = applyAlarms(plan, [], NOW, f.a);
  assert.equal(r.ok, true); assert.equal(r.alarmFallback, undefined);
  const by = Object.fromEntries(f.calls.map((c) => [c[1], c[0]]));
  assert.ok(plan.every((p) => by[p.id] === (p.mode === 'alarm' ? 'alarm' : 'notif')));
  const f2 = fake(false); const r2 = applyAlarms(plan, [], NOW, f2.a);
  assert.equal(r2.alarmFallback, true); assert.ok(f2.calls.every((c) => c[0] === 'notif'));
});
test('Two Pockets: tagihan lama (pengingat lama b.remind, tanpa pengaturan di Notes) tetap notifikasi biasa', () => {
  const bills = [{ id: 'b2', name: 'Air', nextDue: '2026-11-30', status: 'aman', remind: [{ d: 1, t: '08:00' }] }];
  const plan = planAlarms([], NOW, {}, bills, []);
  assert.ok(plan.length >= 1 && plan.every((p) => !('mode' in p)));
});
test('UI Setelan Two Pockets: menyimpan jadwal tidak boleh membuang mode (mode diteruskan), kode memakai logic (bagian mode), tanpa UI baru', () => {
  const st = src('src/js/settings.js'); assert.ok(st.includes("mode: mode === 'alarm' ? 'alarm' : undefined")); // Rev 382: disesuaikan SENGAJA (dulu 'mode: cur.mode'; kini mode berasal dari sakelar Alarm berdering, yang awalnya diisi dari cur.mode)
  assert.ok(st.includes("let mode = cur.mode === 'alarm' ? 'alarm' : 'notif'"));
  const tp = src('src/js/tp-alarm.js'); assert.ok(tp.includes("pushSchedule") && !tp.includes('a.scheduleNotification(p.id'));
  assert.ok(!/scheduleAlarm/.test(src('src/js/notes.js') + src('src/js/main.js')), 'belum ada UI yang memanggil scheduleAlarm langsung (itu AL3b)');
});
test('data lama tanpa mode: bentuk JSON tersimpan TIDAK berubah (SCHEMA tetap 22)', () => {
  assert.equal(JSON.stringify(normalizeReminder({ at: 9, repeat: 'daily' })), '{"at":9,"repeat":"daily"}');
  assert.equal(JSON.stringify(normalizeCbRule({ at: 9, repeat: 'none' })), '{"at":9,"repeat":"none","sticky":false}');
  assert.equal(JSON.stringify(cleanCfg({})), '{"on":true,"hour":8,"min":0,"before":[7,0],"late":true}');
});
