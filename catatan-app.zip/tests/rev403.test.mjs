// Rev 403 / PART K4: kartu bagikan -> "Kirim ke WhatsApp" + "Simpan ke galeri" (jembatan native baru KartuShare). Tes AI (Node).
// Java HANYA dikompilasi terhadap stub Android (tools/cek_java_native.mjs); perilaku di Android SUNGGUHAN BELUM diuji.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs'; import { spawnSync } from 'node:child_process';
import * as N from '../scripts/apply-native.mjs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const PKG = 'com.kelimaa.notes';

test('KartuShare.java: galeri lewat MediaStore (Pictures/NotesKelimaa, IS_PENDING, hanya Android 10+), WhatsApp lewat FileProvider dari CACHE saja, dua paket WhatsApp, tanpa izin baru', () => {
  const j = N.kartuShareSource(PKG);
  for (const x of ['package com.kelimaa.notes;', 'public final class KartuShare', 'Build.VERSION.SDK_INT < 29', 'return "tidak_didukung"', 'MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/NotesKelimaa"', 'IS_PENDING, 1', 'IS_PENDING, 0', '"image/jpeg"', 'MediaStore.Images.Media.EXTERNAL_CONTENT_URI', 'getContentResolver().delete(u, null, null)',
    'getCanonicalPath().startsWith(cache.getCanonicalPath() + File.separator)', 'FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", f)', '"com.whatsapp", "com.whatsapp.w4b"', 'catch (ActivityNotFoundException e)', 'return "tidak_ada"', 'FLAG_GRANT_READ_URI_PERMISSION', 'it.setPackage(paket[i])']) assert.ok(j.includes(x), x);
  assert.ok(!/WRITE_EXTERNAL_STORAGE|READ_EXTERNAL_STORAGE|MANAGE_EXTERNAL/.test(j) && !/WRITE_EXTERNAL_STORAGE/.test(N.ensureReminderManifest('<manifest><application/></manifest>')));
  assert.ok(!/Runtime\.getRuntime|ProcessBuilder|URLConnection|HttpURLConnection/.test(j)); // tanpa jaringan/proses
});

test('MainActivity: dua metode jembatan baru membungkus semua galat (Throwable) dan tidak melempar ke JavaScript; KartuShare ditulis oleh applyNative', () => {
  const m = N.mainActivitySource(PKG);
  assert.match(m, /public String saveImageToGallery\(String b64, String name\) \{\s*try \{ return KartuShare\.saveToGallery\(MainActivity\.this, b64, name\); \}\s*catch \(Throwable e\) \{[^}]*return "error"; \}/);
  assert.match(m, /public String sendImageToWhatsApp\(String fileUri\) \{\s*try \{ return KartuShare\.sendToWhatsApp\(MainActivity\.this, fileUri\); \}\s*catch \(Throwable e\) \{[^}]*return "error"; \}/);
  assert.ok(m.indexOf('saveImageToGallery') < m.indexOf('public void requestNotificationPermission()')); // di dalam potongan yang diperiksa tipenya
  assert.ok(rd('scripts/apply-native.mjs').includes("writeFileSync(join(dir, 'KartuShare.java'), kartuShareSource(pkg));"));
});

test('pemeriksa Java: semua kelas native (termasuk KartuShare) dikompilasi terhadap stub Android (BUKAN bukti jalan di Android)', () => {
  const r = spawnSync('node', ['tools/cek_java_native.mjs'], { encoding: 'utf8', cwd: new URL('..', import.meta.url).pathname });
  assert.equal(r.status, 0, r.stdout + r.stderr); assert.match(r.stdout, /KartuShare dikompilasi terhadap stub Android/);
});

test('share.js K4: tanpa jembatan baru (APK lama) semuanya jatuh ke jalur lama dengan pesan jujur; dengan jembatan: galeri ok, tidak didukung -> Dokumen, WhatsApp ok / tidak ada / galat', async () => {
  const timers = []; const realST = globalThis.setTimeout; globalThis.setTimeout = (fn, ms) => { timers.push(ms); return 0; };
  const calls = []; const fsw = [];
  const FS = { writeFile: async (o) => { fsw.push(o); return { uri: 'file:///data/user/0/x/cache/' + o.path }; }, deleteFile: async () => ({}), checkPermissions: async () => ({ publicStorage: 'granted' }) };
  try {
    const S = await import('../src/js/share.js'); const f = { name: 'a-kartu.jpg', mime: 'image/jpeg', bytes: new Uint8Array([255, 216, 255, 0]) };
    assert.equal(S.bisaGaleri(), false); assert.equal(S.bisaWhatsApp(), false);
    globalThis.Capacitor = { isNativePlatform: () => true, Plugins: { Filesystem: FS } };
    assert.equal(S.bisaGaleri(), false); assert.equal(S.bisaWhatsApp(), false); // native tetapi APK lama tanpa jembatan
    await assert.rejects(() => S.kirimWhatsApp(f), /versi terbaru/);
    let r = await S.simpanGaleri(f); assert.equal(r.galeri, false); assert.match(r.where, /^Dokumen\//); assert.equal(fsw.at(-1).directory, 'DOCUMENTS');
    let wa = 'ok', gal = 'ok';
    globalThis.KelimaaNative = { saveImageToGallery: (b, n) => { calls.push(['gal', n, b]); return gal; }, sendImageToWhatsApp: (u) => { calls.push(['wa', u]); return wa; } };
    assert.equal(S.bisaGaleri(), true); assert.equal(S.bisaWhatsApp(), true);
    r = await S.simpanGaleri(f); assert.deepEqual([r.galeri, r.where], [true, 'galeri, album NotesKelimaa']); assert.equal(calls.at(-1)[2], '/9j/AA=='); // base64 JPEG
    gal = 'tidak_didukung'; r = await S.simpanGaleri(f); assert.equal(r.galeri, false); assert.equal(r.alasan, 'tidak_didukung'); assert.match(r.where, /^Dokumen\//);
    gal = 'error'; r = await S.simpanGaleri(f); assert.equal(r.galeri, false); assert.equal(r.alasan, 'error');
    globalThis.KelimaaNative.saveImageToGallery = () => { throw new Error('boom'); }; r = await S.simpanGaleri(f); assert.equal(r.galeri, false); assert.equal(r.alasan, 'error');
    await S.kirimWhatsApp(f); assert.equal(fsw.at(-1).directory, 'CACHE'); assert.equal(calls.at(-1)[1], 'file:///data/user/0/x/cache/a-kartu.jpg'); assert.ok(timers.includes(600000)); // berkas sementara dibersihkan
    wa = 'tidak_ada'; await assert.rejects(() => S.kirimWhatsApp(f), /WhatsApp belum terpasang di HP ini\./);
    wa = 'error'; await assert.rejects(() => S.kirimWhatsApp(f), /tidak bisa dibuka/);
    globalThis.KelimaaNative.sendImageToWhatsApp = () => { throw new Error('boom'); }; await assert.rejects(() => S.kirimWhatsApp(f), /tidak bisa dibuka/);
    globalThis.AndroidAPI = { sendImageToWhatsApp: () => 'ok' }; assert.equal(S.bisaWhatsApp(), true); // AndroidAPI juga dikenali
  } finally { delete globalThis.Capacitor; delete globalThis.KelimaaNative; delete globalThis.AndroidAPI; globalThis.setTimeout = realST; }
});

test('kartu-ui.js K4: tombol WhatsApp hanya bila jembatan ada, label Simpan berubah, pesan kegagalan jelas; CSS ada', () => {
  const k = rd('src/js/kartu-ui.js');
  for (const x of ["bisaWhatsApp() ? h('button'", "'Kirim ke WhatsApp'", "bisaGaleri() ? 'Simpan ke galeri' : 'Simpan'", "mode === 'wa'", 'await kirimWhatsApp(f)', 'await simpanGaleri(f)', 'galeri tidak tersedia di HP ini', "tErr(mode === 'wa' ? msgOf(e)", 'if (bWa) bWa.disabled']) assert.ok(k.includes(x), x);
  assert.ok(rd('src/css/styles.css').includes('/* Rev 403 / K4') && rd('src/css/styles.css').includes('.kartu-wa{width:100%'));
});

test('pemasangan: tes terdaftar, versi/SCHEMA/dependensi tetap, anggaran aman, banner Rev 403, bagian uji HP dan status 39.11', () => {
  const pk = JSON.parse(rd('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev403\.test\.mjs/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']); // tanpa plugin Capacitor baru
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
  let js = 0; for (const dir of ['src/js', 'src/js/ai']) for (const f of fs.readdirSync(new URL('../' + dir + '/', import.meta.url)).filter((n) => n.endsWith('.js'))) js += fs.statSync(new URL('../' + dir + '/' + f, import.meta.url)).size;
  assert.ok(js <= 1600 * 1024, 'JS ' + js);
  for (const f of ['RIWAYAT.md', 'PROMPT_SERAH_TERIMA.md']) { const d = rd(f); assert.ok(/^\*\*Rev 4(?:0[3-9]|[123]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 403 /') < d.indexOf('**Rev 402 /'), f); }
  assert.ok(rd('PROMPT_SERAH_TERIMA.md').includes('**39.11 STATUS (Rev 403):**')); assert.ok(rd('UJI_HP_RILIS.md').includes('15. (Rev 403, K4)'));
});
