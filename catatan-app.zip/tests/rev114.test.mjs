// Rev 114 / U7a-1: model data lembar kerja (src/js/lembar.js) + SCHEMA 11 (data.sheets). Belum ada UI (grid = U7a-2).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { normalize, importJSON, exportJSON, emptyData, SCHEMA } from '../src/js/storage.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 114: lembar.js murni (tanpa DOM, penyimpanan, native, Intl, eval) dan hanya dipakai settings.js + lembar-ui.js (Rev 115)', () => {
  const s = src('src/js/lembar.js');
  assert.doesNotMatch(s, /localStorage|document\.|window\.|AndroidAPI|Intl\.|eval\(|new Function/);
  for (const f of ['notes.js', 'main.js']) assert.doesNotMatch(src('src/js/' + f), /lembar\.js/);
});
test('Rev 114: alamat sel A1 (kolom A-Z, baris 1-500) dua arah', () => {
  assert.equal(L.colLabel(0), 'A'); assert.equal(L.colLabel(25), 'Z'); assert.equal(L.colLabel(26), '');
  assert.equal(L.cellAddr(1, 3), 'B4'); assert.deepEqual(L.parseAddr('c12'), { col: 2, row: 11 });
  assert.equal(L.parseAddr('A501'), null); assert.equal(L.parseAddr('AA1'), null); assert.equal(L.parseAddr('A0'), null);
});
test('Rev 114: newSheet = satu tab, 26 kolom ber-ID cA..cZ, 30 baris r1..r30, tanpa sel', () => {
  const sh = L.newSheet({ id: 'abc123', now: 5 }); assert.equal(sh.tabs.length, 1);
  const t = sh.tabs[0]; assert.equal(t.cols.length, 26); assert.equal(t.cols[0].id, 'cA'); assert.equal(t.cols[25].id, 'cZ');
  assert.equal(t.rows.length, 30); assert.equal(t.rows[29].id, 'r30'); assert.equal(JSON.stringify(t.rows.map((r) => r.cells)).replace(/[\[\]{},]/g, ''), '');
  assert.ok(L.fitsLimit(sh) && L.sheetBytes(sh) < 20000);
});
test('Rev 114: setCell menyimpan hanya sel berisi; nilai kosong menghapus; gaya digabung dan dibatasi', () => {
  const t = L.newTab();
  assert.equal(L.setCell(t, 'r2', 'cB', { v: 12.5 }), true); assert.deepEqual(L.getCell(t, 'r2', 'cB'), { v: 12.5 });
  assert.equal(L.setCell(t, 'r2', 'cB', { v: 12.5 }), false); // tidak berubah
  L.setCell(t, 'r2', 'cB', { s: { b: true, bg: 'yellow', ha: 'end', evil: 1 } });
  assert.deepEqual(L.getCell(t, 'r2', 'cB'), { v: 12.5, s: { b: true, bg: 'yellow', ha: 'end' } });
  L.setCell(t, 'r2', 'cB', { s: { b: null } }); assert.equal(L.getCell(t, 'r2', 'cB').s.b, undefined);
  L.setCell(t, 'r2', 'cB', { v: '' }); L.setCell(t, 'r2', 'cB', { s: { bg: null, ha: null } });
  assert.equal(L.getCell(t, 'r2', 'cB'), null); assert.equal('cB' in t.rows[1].cells, false);
  assert.equal(L.setCell(t, 'r999', 'cB', { v: 1 }), false); assert.equal(L.setCell(t, 'r1', 'cZZ', { v: 1 }), false);
  L.setCell(t, 'r1', 'cA', { v: 'x'.repeat(5000) }); assert.equal(L.getCell(t, 'r1', 'cA').v.length, L.MAX_CELL);
  L.setCell(t, 'r1', 'cA', { v: 'a', s: { bg: 'javascript:alert(1)' } }); assert.equal(L.getCell(t, 'r1', 'cA').s, undefined);
});
test('Rev 114: sisip/hapus baris dan kolom memberi ID BARU dan tidak mengubah ID lama (dasar rumus berbasis ID)', () => {
  const t = L.newTab('A', 5); L.setCell(t, 'r3', 'cC', { v: 7 });
  const rid = L.insertRow(t, 0); assert.equal(rid, 'r6'); assert.equal(t.rows[0].id, 'r6'); assert.equal(L.getCell(t, 'r3', 'cC').v, 7);
  assert.equal(L.rowIndex(t, 'r3'), 3); // bergeser satu, ID tetap
  assert.equal(L.deleteRow(t, 'r1'), true); assert.equal(L.insertRow(t, 99), 'r7'); // ID r1 tidak dipakai ulang
  const cid = L.insertCol(t, 0); assert.equal(cid, null); // sudah 26 kolom = penuh
  assert.equal(L.deleteCol(t, 'cA'), true); assert.equal(t.cols.length, 25);
  const c2 = L.insertCol(t, 0); assert.equal(c2, 'x1'); assert.equal(L.colIndex(t, 'cC'), 2);
  L.deleteCol(t, 'cC'); assert.equal(t.rows.every((r) => !('cC' in r.cells)), true);
});
test('Rev 114: batas 500 baris, minimal 1 baris/kolom/tab, maks. 5 tab, lebar kolom dijepit 40-320', () => {
  const t = L.newTab('A', 495); assert.equal(L.addRows(t, 100), 5); assert.equal(t.rows.length, 500); assert.equal(L.addRows(t, 10), 0); assert.equal(L.insertRow(t, 0), null);
  const one = L.newTab('B', 1); assert.equal(L.deleteRow(one, 'r1'), false);
  const sh = L.newSheet(); assert.equal(L.removeTab(sh, sh.tabs[0].id), false);
  for (let i = 0; i < 6; i++) L.addTab(sh); assert.equal(sh.tabs.length, 5); assert.equal(L.addTab(sh), null);
  const ids = new Set(sh.tabs.map((x) => x.id)); assert.equal(ids.size, 5);
  assert.equal(L.setColWidth(t, 'cA', 5), true); assert.equal(t.cols[0].w, 40); L.setColWidth(t, 'cA', 9999); assert.equal(t.cols[0].w, 320);
  assert.equal(L.renameTab(sh, sh.tabs[1].id, '  Anggaran   2026  '), true); assert.equal(sh.tabs[1].name, 'Anggaran 2026');
});
test('Rev 114: cleanSheet membuang sel/kolom/baris rusak, memangkas ke batas, dan membuang lembar melewati ~500 KB utuh', () => {
  const raw = { id: 'abc123', name: 'T', tabs: [{ id: 'tab111', name: 'L', cols: [{ id: 'cA', w: 10 }, { id: 'cA', w: 99 }, { id: 'cB' }], rows: [{ id: 'r1', cells: { cA: { v: 1, s: { b: true, z: 1 } }, cB: { v: {} }, cZ: { v: 2 } } }, { id: 'r1' }, null, { id: 'r2', cells: [] }] }] };
  const s = L.cleanSheet(raw); const t = s.tabs[0];
  assert.deepEqual(t.cols, [{ id: 'cA', w: 40 }, { id: 'cB', w: 96 }]); assert.equal(t.rows.length, 2);
  assert.deepEqual(t.rows[0].cells, { cA: { v: 1, s: { b: true } } }); assert.deepEqual(t.rows[1].cells, {});
  assert.equal(L.cleanSheet({ id: 'BAD ID!', tabs: [] }), null); assert.equal(L.cleanSheet(null), null);
  const big = L.newSheet({ id: 'big111' }); const bt = big.tabs[0]; L.addRows(bt, 500);
  for (const r of bt.rows) for (const c of bt.cols) r.cells[c.id] = { v: 'x'.repeat(100) };
  assert.equal(L.fitsLimit(big), false); assert.equal(L.cleanSheet(big), null);
});
test('Rev 114: tabToTsv memotong baris/kolom kosong di ekor, boolean TRUE/FALSE, tab/baris baru di dalam sel jadi spasi', () => {
  const t = L.newTab(); L.setCell(t, 'r1', 'cA', { v: 'Nama' }); L.setCell(t, 'r1', 'cB', { v: 'Nilai' }); L.setCell(t, 'r2', 'cA', { v: 'a\tb\nc' }); L.setCell(t, 'r2', 'cB', { v: true }); L.setCell(t, 'r3', 'cA', { s: { b: true } });
  assert.equal(L.tabToTsv(t), 'Nama\tNilai\na b c\tTRUE'); assert.equal(L.tabToTsv(L.newTab()), '');
});
test('Rev 114: SCHEMA 11; data lama tanpa sheets dimuat ({}), ekspor memuat version 11, tak ada lembar yatim dibuat sendiri', () => {
  assert.equal(SCHEMA, 22); assert.deepEqual(emptyData().sheets, {});
  const d = normalize({ version: 10, notes: [{ id: 'n', title: 'x' }] }); assert.deepEqual(d.sheets, {});
  assert.ok(exportJSON(d).includes('"version": 22'));
});
test('Rev 114: cadangan ekspor-impor memulihkan lembar kerja persis; kunci tak cocok id dan lembar rusak dibuang', () => {
  const sh = L.newSheet({ id: 'abc123', now: 9 }); L.setCell(sh.tabs[0], 'r4', 'cD', { v: 'halo', s: { b: true, fg: '#ff0000' } }); L.addTab(sh, 'Dua');
  const d = normalize({ sheets: { abc123: sh, zzzz99: { ...sh, id: 'lain11' }, rusak1: 'x', arr: [] } });
  assert.deepEqual(Object.keys(d.sheets), ['abc123']);
  const r = importJSON(exportJSON(d)); assert.equal(r.ok, true); assert.deepEqual(r.data.sheets, d.sheets);
  assert.equal(normalize({ sheets: [1, 2] }).sheets && Object.keys(normalize({ sheets: [1, 2] }).sheets).length, 0);
});
test('Rev 114: maks. 50 lembar kerja', () => {
  const m = {}; for (let i = 0; i < 60; i++) { const id = 'sh' + String(i).padStart(4, '0'); m[id] = L.newSheet({ id }); }
  assert.equal(Object.keys(normalize({ sheets: m }).sheets).length, 50);
});
test('Rev 114: versi 0.3.121, SCHEMA 11, native dan dependensi tidak berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121');
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(pk.scripts.test.includes('node tests/rev114.test.mjs'));
});
