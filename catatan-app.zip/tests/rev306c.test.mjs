// Rev 306c / Kelimaa AI LAMPIRAN CATATAN, bagian C: lampiran MENEMPEL untuk pertanyaan lanjutan. Tanpa DOM nyata: yang dikunci adalah bentuk kode dan perilaku mesin.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as A from '../src/js/ai/lampiran.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const ob = src('src/js/ai/obrolan.js'), ui = src('src/js/ai/lampiranui.js');

test('kirim: lampiran tidak dilepas setelah berhasil, hanya disegarkan', () => {
  const i = ob.indexOf('send.onclick'), seg = ob.slice(i, i + 7500);
  assert.match(seg, /if \(ab\) paintLamp\(\);/); assert.doesNotMatch(seg, /lamp = \[\]/);
  assert.ok(seg.indexOf('if (ab) paintLamp()') > seg.indexOf('if (res.ok) {'), 'disegarkan hanya di jalur berhasil');
});
test('lampiran dilepas saat ganti, baru, hapus satu, dan hapus semua ruang percakapan', () => {
  assert.match(ob, /const lepasLamp = \(\) => \{ if \(lamp\.length\) \{ lamp = \[\]; paintLamp\(\); \} \};/);
  assert.equal((ob.match(/lepasLamp\(\)/g) || []).length, 4 + 1, 'pindah, baru, hapus satu, hapus semua, + Rev 308c: sakelar Tetap menempel mati');
  const j = ob.indexOf('const pindah = async'), k = ob.indexOf('const baru = async');
  assert.ok(ob.slice(j, k).includes('lepasLamp()')); assert.ok(ob.slice(k, k + 700).includes('lepasLamp()'));
});
test('lepasLamp didefinisikan SEBELUM dipakai oleh pengendali (tidak ada pemanggilan sebelum definisi dijalankan)', () => {
  assert.ok(ob.indexOf('const lepasLamp') > ob.indexOf('const paintLamp'), 'sesudah paintLamp');
  // pindah/baru hanya dipanggil dari pengendali ketukan (sesudah layar terbentuk), bukan saat inisialisasi
  const sebelum = ob.slice(0, ob.indexOf('const lepasLamp'));
  assert.doesNotMatch(sebelum, /await pindah\(|await baru\(/);
});
test('keterangan di bawah balasan menyebut lampiran masih menempel + perkiraan token per pesan', () => {
  assert.match(ob, /masih menempel, \\u2248 /); assert.match(ob, /estTokens\(ab\.chars\)/); assert.match(ob, /attachable, cleanAtt, estTokens \} from '\.\/lampiran\.js'/);
});
test('teks UI menjelaskan sifat menempel (pemilih dan pratinjau)', () => {
  assert.match(ui, /di setiap pesan sampai kamu lepas lampirannya/); assert.match(ui, /dibaca ulang dari catatan tiap kali kirim/);
  assert.match(ob, /catatan dilampirkan\. Ketuk untuk mengubah/);
});
test('mesin: lampiran dibangun ulang dari data TERBARU tiap kirim, jadi suntingan catatan ikut; catatan yang dihapus gugur', () => {
  const d1 = { notes: [{ id: 'a1', title: 'Belanja', html: '<p>telur</p>' }] };
  const t1 = A.buildAttachment(d1, ['a1'], { total: 12000 });
  const d2 = { notes: [{ id: 'a1', title: 'Belanja', html: '<p>telur dan susu</p>' }] };
  const t2 = A.buildAttachment(d2, ['a1'], { total: 12000 });
  assert.ok(t1.ok && t2.ok); assert.ok(t1.text.includes('telur') && !t1.text.includes('susu')); assert.ok(t2.text.includes('susu'));
  assert.deepEqual(A.attachable({ notes: [] }).map((r) => r.id), [], 'catatan dihapus = tidak ada yang bisa dilampirkan lagi');
});
test('pesan lanjutan: riwayat tidak membawa isi catatan, lampiran ditempel ulang di pesan terbaru saja, tetap dalam batas Worker', () => {
  const hist = [{ role: 'user', content: 'ringkas', att: [{ id: 'a1', title: 'Belanja' }] }, { role: 'assistant', content: 'ok' }];
  const msgs = [...hist.map(({ role, content }) => ({ role, content })), { role: 'user', content: 'lalu apa lagi?' }];
  const d = { notes: [{ id: 'a1', title: 'Belanja', html: '<p>telur</p>' }] };
  const ab = A.buildAttachment(d, ['a1'], { total: A.budgetFor(14, 0) });
  const wa = A.withAttachment(msgs, { ctxText: '', attText: ab.text });
  assert.ok(wa.ok); assert.equal(wa.messages.length, 3);
  assert.ok(wa.messages[2].content.includes('telur') && wa.messages[2].content.endsWith('lalu apa lagi?'));
  assert.ok(!wa.messages[0].content.includes('telur'), 'pesan lama tetap polos');
  for (const m of wa.messages) assert.ok(m.content.length <= A.WORKER_MSG_MAX);
});
test('Worker tidak berubah di Rev 306c (batas pesan tetap 16000)', () => {
  const w = src('backend/cloudflare/worker.mjs'); assert.match(w, /MAX_MSG_CHARS\s*=\s*16000/); assert.match(w, /MAX_CHAT_BODY\s*=\s*90000/);
});
