// Rev 165 / Q10 tahap 2 (Cari data bagian 1): MATCH(nilai; rentang; [tipe]). INDEX = Rev 166, VLOOKUP = Rev 167, HLOOKUP + audit = Rev 168.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { argHint } from '../src/js/rumus-bantu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 9, 0, 0).getTime();
function mk(grid) { const t = L.newTab('T', 12); grid.forEach((row, ri) => row.forEach((v, ci) => { if (v === undefined || v === null) return; L.setCell(t, t.rows[ri].id, t.cols[ci].id, { v }); })); return t; }
function at(grid, f) { const t = mk(grid); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cF = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cF'); }
const COL = [['apel'], ['Jeruk'], ['pisang'], ['kiwi'], [''], [null]];
const NAIK = [[10], [20], [30], [40], [50]];
const TURUN = [[50], [40], [30], [20], [10]];

test('MATCH tipe 0: sama persis, huruf besar/kecil diabaikan, wildcard * ?, tidak ketemu = #N/A, posisi pertama', () => {
  assert.equal(at(COL, '=MATCH("jeruk";A1:A6;0)'), 2); assert.equal(at(COL, '=MATCH("JERUK";A1:A6;0)'), 2); assert.equal(at(COL, '=MATCH("pis*";A1:A6;0)'), 3); assert.equal(at(COL, '=MATCH("k?wi";A1:A6;0)'), 4);
  assert.equal(at(COL, '=MATCH("mangga";A1:A6;0)').e, '#N/A'); assert.equal(at([['a'], ['b'], ['a']], '=MATCH("a";A1:A3;0)'), 1);
  assert.equal(at(NAIK, '=MATCH(30;A1:A5;0)'), 3); assert.equal(at(NAIK, '=MATCH(35;A1:A5;0)').e, '#N/A'); assert.equal(at([[0.1 + 0.2], [5]], '=MATCH(0,3;A1:A2;0)'), 1); // banding 15 digit seperti Excel
  assert.equal(at([['10'], [10]], '=MATCH(10;A1:A2;0)'), 2); // teks "10" bukan angka 10
  assert.equal(at([[true], [false]], '=MATCH(FALSE;A1:A2;0)'), 2); assert.equal(at(NAIK, '=MATCH("30";A1:A5;0)').e, '#N/A');
  assert.equal(at([['x*y']], '=MATCH("x~*y";A1:A1;0)'), 1); // ~ meloloskan *
});
test('MATCH tipe 1 (bawaan) dan -1: terbesar <= / terkecil >=, batas, tipe lain', () => {
  assert.equal(at(NAIK, '=MATCH(35;A1:A5)'), 3); assert.equal(at(NAIK, '=MATCH(35;A1:A5;1)'), 3); assert.equal(at(NAIK, '=MATCH(30;A1:A5;1)'), 3); assert.equal(at(NAIK, '=MATCH(9;A1:A5;1)').e, '#N/A'); assert.equal(at(NAIK, '=MATCH(999;A1:A5;1)'), 5);
  assert.equal(at(TURUN, '=MATCH(35;A1:A5;-1)'), 2); assert.equal(at(TURUN, '=MATCH(40;A1:A5;-1)'), 2); assert.equal(at(TURUN, '=MATCH(51;A1:A5;-1)').e, '#N/A'); assert.equal(at(TURUN, '=MATCH(1;A1:A5;-1)'), 5);
  assert.equal(at(NAIK, '=MATCH(35;A1:A5;2)'), 3); assert.equal(at(TURUN, '=MATCH(35;A1:A5;-2)'), 2); assert.equal(at(NAIK, '=MATCH(30;A1:A5;)'), 3); // tipe kosong = 0 = sama persis
  assert.equal(at([[1], [2], [2], [3]], '=MATCH(2;A1:A4;1)'), 3); // kembar: posisi terakhir
  assert.equal(at([['a'], ['c'], ['e']], '=MATCH("d";A1:A3;1)'), 2); // teks juga bisa (urutan abjad)
  assert.equal(at([[10], ['x'], [30]], '=MATCH(35;A1:A3;1)'), 3); // sel beda jenis dilewati
});
test('MATCH: satu baris/kolom saja (2D = #N/A), nilai tunggal, sel kosong/galat dilewati, galat menjalar, jumlah argumen', () => {
  assert.equal(at([[1, 2, 3]], '=MATCH(3;A1:C1;0)'), 3); assert.equal(at([[1, 2], [3, 4]], '=MATCH(3;A1:B2;0)').e, '#N/A'); assert.equal(at([], '=MATCH(5;5;0)'), 1); assert.equal(at([], '=MATCH(5;6;0)').e, '#N/A');
  const t = mk([[1], [2], [3]]); t.rows[1].cells.cA = { fx: R.a1ToStored('=1/0', t).fx }; t.rows[0].cells.cF = { fx: R.a1ToStored('=MATCH(3;A1:A3;0)', t).fx }; t.rows[1].cells.cF = { fx: R.a1ToStored('=MATCH(2;A1:A3;0)', t).fx };
  const c = R.computeTab(t, { now: NOW }); assert.equal(c.get('r1', 'cF'), 3); assert.equal(c.get('r2', 'cF').e, '#N/A'); // sel galat tidak pernah cocok
  assert.equal(at(NAIK, '=MATCH(1/0;A1:A5;0)').e, '#DIV/0!'); assert.equal(at(NAIK, '=MATCH(A1:A2;A1:A5;0)').e, '#VALUE!'); assert.equal(at(NAIK, '=MATCH(10;A1:A5;"x")').e, '#VALUE!');
  assert.equal(at(NAIK, '=MATCH(10)').rejected !== undefined || at(NAIK, '=MATCH(10)').e === '#VALUE!', true);
  assert.equal(at(NAIK, '=IFERROR(MATCH(7;A1:A5;0);"tidak ada")'), 'tidak ada'); assert.equal(at(NAIK, '=MATCH(30;A1:A5;0)+MATCH(10;A1:A5;0)'), 4);
});
test('MATCH ikut urutan hitung (rentang berisi rumus) dan siklus', () => {
  const t = mk([[5], [null], [null]]); const put = (r, f) => { t.rows[r].cells.cA = { fx: R.a1ToStored(f, t).fx }; };
  put(1, '=A1*2'); put(2, '=A2*2'); t.rows[0].cells.cF = { fx: R.a1ToStored('=MATCH(20;A1:A3;0)', t).fx };
  assert.equal(R.computeTab(t, { now: NOW }).get('r1', 'cF'), 3); // A3 = 20 dihitung dulu
  const u = mk([[null]]); u.rows[0].cells.cA = { fx: R.a1ToStored('=MATCH(1;A1:A2;0)', u).fx }; assert.equal(R.computeTab(u, { now: NOW }).get('r1', 'cA').e, '#CIRC!');
});
test('daftar fungsi 49 termasuk MATCH (sig, ket, petunjuk argumen, saran); modul murni; tes terdaftar', () => {
  const names = R.FUNCTION_LIST.map((f) => f.name); assert.equal(names.length, 53); const f = R.FUNCTION_LIST.find((x) => x.name === 'MATCH'); assert.ok(f && f.sig.startsWith('MATCH(') && f.ket.length > 3);
  assert.equal(argHint('MATCH', 7).parts.length, 3); assert.deepEqual(R.suggestFunctions('ma').map((x) => x.name), ['MATCH', 'MAX']); assert.ok(names.includes('HLOOKUP'));
  const s = src('src/js/rumus.js'); assert.ok(!/^\s*import\s/m.test(s)); assert.ok(!/document\.|window\.|localStorage|eval\(|new Function/.test(s)); assert.ok(src('package.json').includes('tests/rev165.test.mjs'));
});
