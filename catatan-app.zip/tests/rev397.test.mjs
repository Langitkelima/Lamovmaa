// Rev 397 / PART M2: ekspor Markdown ke ZIP. Perilaku HP (Share, izin, gambar nyata) BELUM diuji.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import { planMarkdownExport, buildMarkdownZipBytes, writeMarkdownZipToCache, mdZipName } from '../src/js/ekspor-md.js';
import { blocksToMarkdown, parseNoteHtml } from '../src/js/export.js';
import { readZipIndex, readZipEntry, utf8, base64ToBytes } from '../src/js/zip.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 22);
const fig = (id, x = 'webp') => `<figure class="ki" data-kimg="${id}" data-w="10" data-h="10" data-b="100" data-x="${x}"></figure>`;
const IMG1 = 'abcdefghij1234567890';
const data = () => ({
  settings: { labels: [{ id: 'l1', name: 'rumah' }, { id: 'l2', name: 'kerja' }] },
  notes: [
    { id: 'a', title: 'Belanja', html: '<div>Satu <b>tebal</b></div><div class="todo"><input type="checkbox" checked="">&nbsp;Beras</div>', labels: ['l1'] },
    { id: 'b', title: 'Belanja', html: '<div>Kedua</div>', labels: [] },
    { id: 'c', title: '', html: '' },
    { id: 'd', title: 'Foto', html: '<div>Lihat</div>' + fig(IMG1, 'jpg'), labels: ['l2'] },
    { id: 'e', title: 'Hitung', html: '<div>x</div><div data-sheet="s1"></div>' },
  ],
  priv: [{ id: 'p', title: 'Rahasia', html: '<div>sandi</div>' + fig(IMG1, 'jpg') }],
  trash: [{ kind: 'note', item: { id: 't', title: 'Sampah', html: '<div>buang</div>' } }],
});

test('rencana: Catatan Privat dan sampah TIDAK ikut bawaan; kosong dilewati; nama unik; label ikut', () => {
  const p = planMarkdownExport(data(), {}, NOW);
  assert.equal(p.files.length, 4); assert.equal(p.counts.kosong, 1); assert.equal(p.counts.priv, 0);
  const names = p.files.map((f) => f.name);
  assert.deepEqual(names.slice(0, 2), ['belanja-20261122.md', 'belanja-20261122-2.md']);
  assert.ok(!p.files.some((f) => /rahasia|sandi|sampah|buang/.test(f.name + f.text)));
  assert.ok(p.files[0].text.includes('label: ["rumah"]') && p.files[0].text.includes('- [x] Beras') && p.files[0].text.includes('**tebal**'));
  assert.ok(!planMarkdownExport(data(), { labels: false }, NOW).files[0].text.includes('label:'));
  assert.equal(p.counts.lembar, 1);
});
test('rencana: Catatan Privat hanya bila dicentang, di folder privat/, gambar rujuk ../gambar/', () => {
  const p = planMarkdownExport(data(), { priv: true, images: true }, NOW);
  const pv = p.files.find((f) => f.name.startsWith('privat/')); assert.ok(pv && pv.text.includes('sandi')); assert.equal(p.counts.priv, 1);
  assert.ok(pv.text.includes('![gambar](../gambar/' + IMG1 + '.jpg)'));
  assert.ok(p.files.find((f) => f.name === 'foto-20261122.md').text.includes('![gambar](gambar/' + IMG1 + '.jpg)'));
  assert.equal(p.imageRefs.length, 1); // satu berkas dirujuk dua catatan = dihitung sekali
});
test('rencana: tanpa opsi gambar, tetap "[gambar]" dan tidak ada rujukan untuk disalin', () => {
  const p = planMarkdownExport(data(), {}, NOW);
  assert.equal(p.imageRefs.length, 0); assert.equal(p.counts.gambarDilewati, 1);
  assert.ok(p.files.find((f) => /foto/.test(f.name)).text.includes('[gambar]'));
});
test('blocksToMarkdown tanpa opsi tetap persis seperti dulu', () => {
  const bl = parseNoteHtml('<div>a</div>' + fig(IMG1));
  assert.ok(blocksToMarkdown('', bl).includes('[gambar]')); assert.ok(!blocksToMarkdown('', bl).includes('!['));
  assert.ok(blocksToMarkdown('', bl, { imageUrl: (id) => 'g/' + id }).includes('![gambar](g/' + IMG1 + ')'));
});
test('ZIP peramban terbaca kembali: isi .md utuh', async () => {
  const p = planMarkdownExport(data(), {}, NOW), z = buildMarkdownZipBytes(p, NOW);
  const blob = new Blob([z]), idx = await readZipIndex(blob);
  assert.equal(idx.length, p.files.length);
  const e = idx.find((x) => x.name === 'belanja-20261122.md');
  assert.equal(utf8.decode(await readZipEntry(blob, e)), p.files[0].text);
});
test('ZIP HP bertahap lewat FS palsu: .md + gambar; gambar hilang dilewati dan dicatat; galat membersihkan CACHE', async () => {
  const p = planMarkdownExport(data(), { images: true }, NOW);
  const store = {}, calls = [];
  const FS = { writeFile: async (o) => { store[o.path] = base64ToBytes(o.data); calls.push('w'); return { uri: 'file://' + o.path }; }, appendFile: async () => { calls.push('a'); },
    readFile: async (o) => { calls.push(o.directory + ':' + o.path); return { data: Buffer.from('JPEGDATA').toString('base64') }; }, deleteFile: async (o) => { calls.push('d:' + o.path); } };
  const r = await writeMarkdownZipToCache(FS, p, mdZipName(NOW), NOW);
  assert.equal(r.included, 1); assert.equal(r.missing.length, 0); assert.equal(r.written, 4); assert.ok(calls.includes('DATA:gambar/' + IMG1 + '.jpg'));
  const idx = await readZipIndex(new Blob([store[mdZipName(NOW)]]));
  assert.ok(idx.some((x) => x.name === 'gambar/' + IMG1 + '.jpg') && idx.some((x) => x.name === 'belanja-20261122.md'));
  const FS2 = { ...FS, readFile: async () => { throw new Error('hilang'); } };
  const r2 = await writeMarkdownZipToCache(FS2, p, 'x.zip', NOW); assert.deepEqual(r2.missing, [IMG1]); assert.equal(r2.included, 0);
  const calls3 = []; const FS3 = { ...FS, writeFile: async () => { throw new Error('penuh'); }, deleteFile: async (o) => { calls3.push(o.path); } };
  await assert.rejects(() => writeMarkdownZipToCache(FS3, p, 'y.zip', NOW), /penuh/); assert.deepEqual(calls3, ['y.zip']);
});
test('pemasangan: baris Setelan memuat modul MALAS, tidak ada impor statis baru di main/settings', () => {
  const st = rd('src/js/sync-ui.js'); // Rev 412: pemanggilan malas pindah ke layar Sync
  assert.ok(st.includes("import('./ekspor-md-ui.js')") && !/^import .*ekspor-md/m.test(st) && !/^import .*ekspor-md/m.test(rd('src/js/main.js')));
  const ui = rd('src/js/ekspor-md-ui.js');
  assert.ok(ui.includes('MD_ZIP_MAX_NOTES') && ui.includes('Buka kunci Catatan Privat') && ui.includes('Tidak ada catatan yang bisa diekspor'));
  assert.ok(/priv: false/.test(ui)); // Catatan Privat mati bawaan
});
