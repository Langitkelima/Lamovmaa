// Rev 132 / U8a-5: format angka sel (nf): modul murni lembar-format.js + model (cleanStyle/setCell/cleanSheet) + SCHEMA 13 + kabel UI.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { cleanNf, formatNumber, formatDate, stepDecimals, nfKey, nfLabel, NF_PRESETS, MAX_DEC } from '../src/js/lembar-format.js';
import { serialOf } from '../src/js/rumus.js';
import * as L from '../src/js/lembar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('formatNumber: Angka (otomatis dan tetap), ribuan titik, desimal koma, pembulatan 1.005', () => {
  assert.equal(formatNumber(1234567.891, { k: 'number' }), '1.234.567,891'); assert.equal(formatNumber(1234.5, { k: 'number', d: 2 }), '1.234,50');
  assert.equal(formatNumber(0, { k: 'number' }), '0'); assert.equal(formatNumber(999, { k: 'number', d: 0 }), '999'); assert.equal(formatNumber(1000, { k: 'number' }), '1.000');
  assert.equal(formatNumber(1.005, { k: 'number', d: 2 }), '1,01'); assert.equal(formatNumber(0.1 + 0.2, { k: 'number' }), '0,3');
  assert.equal(formatNumber(-1234.5, { k: 'number', d: 1 }), '-1.234,5'); assert.equal(formatNumber(-0.001, { k: 'number', d: 2 }), '0,00');
});
test('formatNumber: Persen dan Rupiah', () => {
  assert.equal(formatNumber(0.256, { k: 'percent', d: 1 }), '25,6%'); assert.equal(formatNumber(0.07, { k: 'percent' }), '7%'); assert.equal(formatNumber(1.5, { k: 'percent' }), '150%'); assert.equal(formatNumber(-0.25, { k: 'percent' }), '-25%');
  assert.equal(formatNumber(1250000, { k: 'currency' }), 'Rp 1.250.000'); assert.equal(formatNumber(-1250000.5, { k: 'currency', d: 2 }), '-Rp 1.250.000,50'); assert.equal(formatNumber(0, { k: 'currency' }), 'Rp 0');
  assert.equal(formatNumber(2500, { k: 'currency', c: '*' }), 'Rp 2.500'); // kode lain = IDR
});
test('formatNumber: Tanggal dari nomor seri (sama dengan TODAY)', () => {
  assert.equal(formatNumber(serialOf(Date.UTC(2026, 10, 9, 12)), { k: 'date', p: 'short' }), '09/11/2026');
  assert.equal(formatNumber(45292, { k: 'date' }), '01/01/2024'); assert.equal(formatNumber(45292.9, { k: 'date' }), '01/01/2024');
  assert.equal(formatDate(0), null); assert.equal(formatDate(-5), null); assert.equal(formatDate(3000000), null); assert.equal(formatDate(NaN), null);
});
test('formatNumber: bukan angka / nf rusak / terlalu besar = null (tampil apa adanya)', () => {
  for (const v of ['abc', '12', true, null, undefined, NaN, Infinity, { e: '#REF!' }]) assert.equal(formatNumber(v, { k: 'number' }), null, String(v));
  assert.equal(formatNumber(5, null), null); assert.equal(formatNumber(5, { k: 'bogus' }), null); assert.equal(formatNumber(5, 'currency'), null);
  assert.equal(formatNumber(1e15, { k: 'number' }), null); assert.equal(formatNumber(7e-7, { k: 'number' }), null);
});
test('cleanNf / stepDecimals / preset', () => {
  assert.deepEqual(cleanNf({ k: 'percent' }), { k: 'percent', d: 0 }); assert.deepEqual(cleanNf({ k: 'currency', c: 'USD', d: 9 }), { k: 'currency', c: 'IDR', d: 0 }); assert.deepEqual(cleanNf({ k: 'number', d: 3 }), { k: 'number', d: 3 });
  assert.deepEqual(cleanNf({ k: 'date', p: 'long' }), { k: 'date', p: 'short' }); for (const x of [null, 5, 'x', {}, { k: 'time' }, { k: 'checkbox' }]) assert.equal(cleanNf(x), undefined);
  assert.deepEqual(stepDecimals({ k: 'number' }, 1), { k: 'number', d: 1 }); assert.deepEqual(stepDecimals({ k: 'percent', d: 0 }, -1), { k: 'percent', d: 0 }); assert.deepEqual(stepDecimals({ k: 'currency', c: 'IDR', d: MAX_DEC }, 1), { k: 'currency', c: 'IDR', d: MAX_DEC });
  assert.equal(stepDecimals(null, 1), null); assert.equal(stepDecimals({ k: 'date' }, 1), null);
  assert.deepEqual(NF_PRESETS.map((p) => p.label), ['Umum', 'Angka', 'Persen', 'Rp', 'Tanggal']); assert.equal(nfKey(null), 'none'); assert.equal(nfKey({ k: 'currency' }), 'currency'); assert.equal(nfLabel({ k: 'date' }), 'Tanggal');
  for (const p of NF_PRESETS) assert.deepEqual(cleanNf(p.nf) || null, p.nf);
});
test('model sel: nf di gaya sel; setCell menimpa/menghapus; nilai mentah tidak berubah; nf rusak dibuang', () => {
  const tab = L.newTab('T'); const r = tab.rows[0].id;
  L.setCell(tab, r, 'cA', { v: 0.25 }); assert.equal(L.setCell(tab, r, 'cA', { s: { nf: { k: 'percent', d: 1 } } }), true);
  assert.deepEqual(L.getCell(tab, r, 'cA'), { v: 0.25, s: { nf: { k: 'percent', d: 1 } } });
  L.setCell(tab, r, 'cA', { s: { b: true } }); assert.deepEqual(L.getCell(tab, r, 'cA').s, { b: true, nf: { k: 'percent', d: 1 } }); // gaya lain tidak menghapus nf
  L.setCell(tab, r, 'cA', { s: { nf: { k: 'currency' } } }); assert.deepEqual(L.getCell(tab, r, 'cA').s.nf, { k: 'currency', c: 'IDR', d: 0 });
  L.setCell(tab, r, 'cA', { s: { nf: null } }); assert.deepEqual(L.getCell(tab, r, 'cA'), { v: 0.25, s: { b: true } });
  L.setCell(tab, r, 'cA', { s: { nf: { k: 'zzz' } } }); assert.equal(L.getCell(tab, r, 'cA').s.nf, undefined);
  assert.ok(L.STYLE_KEYS.includes('nf'));
});
test('nf ikut cleanSheet (cadangan/muat) dan bertahan bersama rumus', () => {
  const sh = L.newSheet({ id: 'sabc1' }), tab = sh.tabs[0]; L.setCell(tab, 'r1', 'cB', { fx: '=[r1.cA]*2', s: { nf: { k: 'currency', c: 'IDR', d: 0 } } });
  const back = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.deepEqual(L.getCell(back.tabs[0], 'r1', 'cB').s.nf, { k: 'currency', c: 'IDR', d: 0 }); assert.equal(L.getCell(back.tabs[0], 'r1', 'cB').fx, '=[r1.cA]*2');
  const bad = JSON.parse(JSON.stringify(sh)); bad.tabs[0].rows[0].cells.cB.s.nf = { k: 'percent', d: 99 }; assert.deepEqual(L.getCell(L.cleanSheet(bad).tabs[0], 'r1', 'cB').s.nf, { k: 'percent', d: 0 });
});
test('kabel lembar-ui: tampil lewat formatNumber (hasil rumus ikut), tombol Format + panel, bar lama tidak berubah; modul murni', () => {
  const u = src('src/js/lembar-ui.js'), m = src('src/js/lembar-format.js');
  assert.match(u, /from '\.\/lembar-format\.js'/); assert.match(u, /formatNumber\(raw, (?:st\.nf|anf)\)/); assert.match(u, /cc\.get\(srow\.id, c\.id\) : undefined\) : \(cell && cell\.v\)/); assert.match(u, /el\.textContent = f/);
  assert.match(u, /fmtBar\.insertBefore\(bN, bB\); root\.insertBefore\(nfp, fmtBar\)/); assert.match(u, /applyStyle\(\{ nf: p\.nf \}\)/); assert.match(u, /stepDecimals\(st\.nf, d\)/); assert.match(u, /paintPal\(\); paintNf\(\);/);
  assert.match(u, /fmtBar, assistEl, bar, tabs/); assert.match(u, /bU, bR, bS, bB, bI, bAL, bAC, bAR, bBg, bFg/); assert.match(u, /let nfOpen = false/);
  assert.doesNotMatch(m, /document|window|localStorage|eval\(|new Function|import /);
  assert.match(src('src/js/lembar.js'), /import \{ cleanNf \} from '\.\/lembar-format\.js'/);
});
test('Rev 132: versi 0.3.121, SCHEMA 13, native/dependensi tidak berubah, tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev132.test.mjs')); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
