// Rev 302a / v0.3.121: kolom beku = pembungkus STICKY (bukan translate JS), penolakan kolom beku terlalu lebar, alat audit, dokumen.
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');

test('kolom beku TIDAK lagi digeser JS: shiftFz, kelas fzc/fzl, dan translate sebesar scrollLeft untuk sel beku sudah hilang', () => {
  assert.ok(!ui.includes('shiftFz')); assert.ok(!/classList\.add\('fz[cl]'\)/.test(ui)); assert.ok(!/' fzc'/.test(ui)); assert.ok(!/querySelectorAll\('\.fzc'\)/.test(ui));
  assert.ok(!/\.fzc|\.fzl/.test(css), 'CSS tanpa .fzc/.fzl');
});
test('pembungkus .lz-fzw dibuat di kepala dan di tiap baris HANYA bila ada kolom beku; sel beku masuk pembungkus, sel gabungan tidak', () => {
  assert.match(ui, /const fcN = getFreeze\(tab\)\.c, fzw = fcN \? h\('div', \{ class: 'lz-fzw' \}\) : null/);
  assert.match(ui, /const fzw = fc \? h\('div', \{ class: 'lz-fzw' \}\) : null; if \(fzw\) \{ fzw\.style\.width = fzPx\(colLeft\(tab, fc\)\)/); /* Rev 304a: lebar lewat calc(--fzs) */
  assert.match(ui, /const fz = !!fzw && i < fc && !mg; el\.style\.left = fz \? fzPx\(colLeft\(tab, i\)\) : NUM_W \+ colLeft\(tab, i\)/);
  assert.match(ui, /\(fz \? fzw : rowEl\)\.append\(el\)/); assert.match(ui, /\(fz \? fzw : headRow\)\.append\(hc\)/);
  assert.ok(ui.indexOf("rowEl.append(rnEl);") < ui.indexOf("const fzw = fc ?"), 'pembungkus SESUDAH nomor baris (nomor baris tetap anak pertama)');
});
test('seret lebar kolom (relayout) menghitung kiri sel di pembungkus dan memperbarui lebar pembungkus', () => {
  assert.match(ui, /lf = \(e, i\) => lefts\[i\] - \(fzE\(e\) \? NUM_W : 0\)/);
  assert.match(ui, /hc\.style\.left = fzE\(hc\) \? fzPx\(lf\(hc, i\)\)/); assert.match(ui, /el\.style\.left = fzE\(el\) \? fzPx\(lf\(el, i\)\)/); assert.match(ui, /querySelectorAll\('\.lz-fzw'\)\.forEach\(\(e\) => \{ e\.style\.width = fcw; \}\)/);
});
test('gulir memanggil clipSel langsung (lapisan seleksi di kolom beku tidak menunggu rAF); rAF tetap untuk gambar baris', () => {
  assert.match(ui, /const onScroll = \(\) => \{ fzUpdate\(\); clipSel\(\); if \(raf\) return; raf = requestAnimationFrame\(\(\) => \{ raf = 0; drawRows\(\); clipSel\(\); \}\); \};/);
});
test('bekukan kolom ditolak bila lebar kolom beku > 70% lebar layar sesudah nomor baris (toast, tanpa perubahan data, tanpa langkah Urungkan)', () => {
  const a = ui.slice(ui.indexOf('const applyFreeze'), ui.indexOf('const openFreeze'));
  assert.match(a, /fzTooWide\(colLeft\(tab, cnt\), room \* 0\.7\)/); assert.match(a, /Kolom beku terlalu lebar bahkan setelah dipersempit/); /* Rev 304a: batas lama 70% diganti penyempitan sementara; ditolak hanya bila > 2,5 x */
  assert.ok(a.indexOf('Kolom beku terlalu lebar') < a.indexOf('const snap = ser()'), 'penolakan SEBELUM snapshot Urungkan dan setFreeze');
});
test('CSS: satu blok kecil, variabel tema, tanpa warna mentah; row+head flex; pembungkus sticky left 44px', () => {
  const i = css.indexOf('/* Rev 302a'); assert.ok(i > 0); assert.equal(css.split('Rev 302a').length - 1, 1); const j302 = css.indexOf('/* Rev', i + 5), blk = css.slice(i, j302 > 0 ? j302 : undefined); /* Rev 303c: blok 303c menyusul sesudahnya */ assert.ok(blk.length < 700, String(blk.length)); assert.ok(!/#[0-9a-fA-F]{3,6}\b/.test(blk));
  assert.match(blk, /\.lz-row,\.lembarfs \.lz-head\{display:flex\}/); assert.match(blk, /\.lz-fzw\{position:sticky;left:44px;flex:none;z-index:2;/); assert.match(blk, /var\(--ln\)/); assert.match(blk, /pointer-events:none\}\.lembarfs \.lz-fzw>\*\{pointer-events:auto\}/); // pembungkus kosong tidak menutupi sel gabungan di bawahnya
  assert.ok(Buffer.byteLength(css) < 270 * 1024, 'CSS di bawah anggaran resmi cssMaks 270 KB (Rev 383: batas tes disamakan dengan tools/audit-ukuran.mjs): ' + Buffer.byteLength(css));
});
test('alat audit: tools/audit_beku_kolom.py ada, mengukur kolom A/kepala/nomor baris sesudah scrollLeft, terang + gelap, 360x720', () => {
  assert.ok(existsSync(new URL('../tools/audit_beku_kolom.py', import.meta.url))); const t = src('tools/audit_beku_kolom.py');
  assert.match(t, /360, 'height': 720/); assert.match(t, /'light', 'dark'/); assert.match(t, /scrollLeft = x/); assert.match(t, /kolomA/);
  assert.ok(!/\.fzc/.test(src('tools/audit_beku.py')), 'audit_beku.py tidak lagi memakai .fzc');
});
test('dokumen: README ringkas (< 12000 huruf) + jujur soal status; entri Rev 302a di PROMPT dan RIWAYAT; butir uji HP AG; tes terdaftar; versi + SCHEMA tetap', () => {
  const r = src('README.md'); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */); assert.match(r, /Rev 302a/); assert.match(r, /bukan\*\* bukti APK/);
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 302a / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('**Rev 302a / v0.3.121')); // Rev 302b: startsWith -> includes
  assert.match(src('UJI_HP_RILIS.md'), /## AG\. Kolom beku menempel saat digulir \(Rev 302a\)/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev302a\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
console.log('rev302a: ' + n + ' tes');
