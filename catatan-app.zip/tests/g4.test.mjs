// Rev 60 / G4: penampil layar penuh (matematika murni + kabel), Setelan > Gambar (kualitas, pemakaian, bersihkan), SCHEMA 8.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as G from '../src/js/gambar.js';
import * as S from '../src/js/storage.js';
import { IMAGE_QUALITIES, normalizeImageQuality } from '../src/js/logic.js';
import { scanImages, clearUnusedImages } from '../src/js/gambar-app.js';
let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

await t('kualitas: kunci logic.js sama dengan PRESETS gambar.js; nilai aneh jadi seimbang', () => {
  assert.deepEqual([...IMAGE_QUALITIES], Object.keys(G.PRESETS)); assert.deepEqual([...G.QUALITY_KEYS], [...IMAGE_QUALITIES]);
  for (const k of IMAGE_QUALITIES) assert.equal(normalizeImageQuality(k), k);
  for (const bad of [undefined, null, '', 'HEMAT', 'x', 3, {}]) assert.equal(normalizeImageQuality(bad), 'seimbang');
  assert.equal(G.DEFAULT_PRESET, 'seimbang');
});
await t('SCHEMA 8: data v7 tanpa imageQuality dimigrasi (bawaan seimbang), nilai sah dipertahankan, nilai aneh dibersihkan', () => {
  assert.equal(S.SCHEMA, 22);
  assert.equal(S.emptyData().settings.imageQuality, 'seimbang');
  const old = S.normalize({ version: 7, notes: [{ id: 'a', title: 'x', html: 'y' }], settings: { theme: 'dark' } });
  assert.equal(old.settings.imageQuality, 'seimbang'); assert.equal(old.notes.length, 1); assert.equal(old.settings.theme, 'dark');
  assert.equal(S.normalize({ settings: { imageQuality: 'tajam' } }).settings.imageQuality, 'tajam');
  assert.equal(S.normalize({ settings: { imageQuality: 'ngawur' } }).settings.imageQuality, 'seimbang');
  const rt = S.importJSON(S.exportJSON({ ...S.emptyData(), settings: { ...S.emptyData().settings, imageQuality: 'hemat' } }));
  assert.equal(rt.data.settings.imageQuality, 'hemat'); // ikut cadangan
});
await t('kualitas dipakai kompres: preset hemat < seimbang < tajam dan hint dibaca dari PRESETS', () => {
  const src0 = { w: 4000, h: 3000 };
  const a = G.planCompress(src0, 'hemat'), b = G.planCompress(src0, 'seimbang'), c = G.planCompress(src0, 'tajam');
  assert.ok(a.width < b.width && b.width < c.width); assert.ok(a.maxBytes < b.maxBytes && b.maxBytes < c.maxBytes);
  assert.match(G.qualityHint('hemat'), /1024 px.*150 KB/); assert.match(G.qualityHint('tajam'), /1920 px.*500 KB/);
});
await t('formatBytes: KB, MB dengan koma Indonesia, nilai tak sah = 0 KB', () => {
  assert.equal(G.formatBytes(0), '0 KB'); assert.equal(G.formatBytes(-5), '0 KB'); assert.equal(G.formatBytes('x'), '0 KB');
  assert.equal(G.formatBytes(1), '1 KB'); assert.equal(G.formatBytes(250 * 1000), '244 KB');
  assert.equal(G.formatBytes(3.4 * 1024 * 1024), '3,4 MB'); assert.equal(G.formatBytes(25 * 1024 * 1024), '25 MB');
});
await t('penampil: fitInto menjaga rasio dan contain; clampPan menahan di tengah bila gambar lebih kecil dari layar', () => {
  assert.deepEqual(G.fitInto(1000, 500, 400, 800), { w: 400, h: 200 });
  assert.deepEqual(G.fitInto(500, 1000, 400, 400), { w: 200, h: 400 });
  assert.deepEqual(G.fitInto(0, 5, 10, 10), { w: 0, h: 0 });
  assert.deepEqual(G.clampPan(500, 500, 1, 400, 800, 400, 200), { tx: 0, ty: 0 }); // zoom 1: tidak bisa digeser
  const c = G.clampPan(9999, -9999, 2, 400, 800, 400, 200); assert.equal(c.tx, 200); assert.equal(c.ty, 0); // tinggi 400 < 800 -> tetap tengah
  assert.deepEqual(G.clampPan(NaN, undefined, 3, 400, 400, 400, 400), { tx: 0, ty: 0 });
});
await t('penampil: clampScale 1..5, pinchScale mengalikan jarak, zoomAt menjaga titik fokus', () => {
  assert.equal(G.clampScale(0.2), 1); assert.equal(G.clampScale(99), 5); assert.equal(G.clampScale('x'), 1);
  assert.equal(G.pinchScale(1, 100, 200), 2); assert.equal(G.pinchScale(2, 100, 10), 1); assert.equal(G.pinchScale(1, 0, 50), 1); assert.equal(G.pinchScale(3, 100, 400), 5);
  // gambar 400x400 di layar 400x400, fokus di (100,0) dari tengah; zoom 1 -> 2 : titik di bawah jari tetap
  const z = G.zoomAt({ scale: 1, tx: 0, ty: 0 }, 2, 100, 0, 400, 400, 400, 400);
  assert.equal(z.scale, 2); assert.equal(z.tx, -100); assert.equal(z.ty, 0);
  const back = G.zoomAt(z, 1, 100, 0, 400, 400, 400, 400); assert.deepEqual(back, { scale: 1, tx: 0, ty: 0 });
  assert.equal(G.zoomAt({ scale: 1, tx: 0, ty: 0 }, 99, 0, 0, 400, 400, 400, 400).scale, 5);
});
await t('penampil: swipeDir hanya untuk geser mendatar jauh; neighborIndex berhenti di ujung', () => {
  assert.equal(G.swipeDir(-100, 10), 1); assert.equal(G.swipeDir(100, 10), -1); assert.equal(G.swipeDir(30, 0), 0); assert.equal(G.swipeDir(-100, 90), 0); assert.equal(G.swipeDir(NaN, 0), 0);
  assert.equal(G.neighborIndex(0, 3, -1), -1); assert.equal(G.neighborIndex(0, 3, 1), 1); assert.equal(G.neighborIndex(2, 3, 1), -1); assert.equal(G.neighborIndex(1, 3, -1), 0); assert.equal(G.neighborIndex(0, 1, 1), -1); assert.equal(G.neighborIndex(5, 3, 1), -1);
});
const A = 'aaaaaaaaaa11', B = 'bbbbbbbbbb22', C = 'cccccccccc33', D = 'dddddddddd44';
const NOW = 1_800_000_000_000;
const mkData = () => ({ notes: [{ html: G.buildFigure({ id: A, w: 10, h: 10, b: 2000, x: 'webp' }) }], priv: [], trash: [{ kind: 'note', item: { html: G.buildFigure({ id: B, w: 10, h: 10, b: 3000, x: 'jpg' }) } }] });
const mkFS = (files) => {
  const calls = [];
  return { calls, files,
    async readdir() { return { files: files.map((f) => ({ name: f.name })) }; },
    async stat({ path }) { const f = files.find((x) => path.endsWith('/' + x.name)); return { size: f.size, mtime: f.mtime }; },
    async deleteFile({ path }) { calls.push(path); const i = files.findIndex((x) => path.endsWith('/' + x.name)); files.splice(i, 1); } };
};
await t('summarizeImages: dipakai vs berkas nyata vs yatim vs hilang; berkas baru (<5 mnt) dan waktu tak jelas tidak dihitung yatim', () => {
  const data = mkData();
  const files = [
    { name: A + '.webp', size: 2000, mtime: NOW - 86400000 }, { name: B + '.jpg', size: 3000, mtime: NOW - 86400000 },
    { name: C + '.webp', size: 5000, mtime: NOW - 3600000 },   // yatim lama
    { name: D + '.png', size: 7000, mtime: NOW - 60000 },      // baru 1 menit: dilewati
    { name: 'zzzzzzzzzz55.webp', size: 9, mtime: 0 },          // waktu tak jelas: aman-gagal
    { name: 'catatan.txt', size: 1, mtime: NOW - 99999999 }];  // bukan pola gambar
  const sum = G.summarizeImages(G.refsOfData(data), files, NOW);
  assert.deepEqual(sum.used, { count: 2, bytes: 5000 });
  assert.equal(sum.diskCount, 5); assert.equal(sum.diskBytes, 2000 + 3000 + 5000 + 7000 + 9);
  assert.deepEqual(sum.orphans, [C + '.webp']); assert.equal(sum.orphanBytes, 5000); assert.equal(sum.missing, 0);
  const gone = G.summarizeImages(G.refsOfData(data), files.filter((f) => !f.name.startsWith(A)), NOW);
  assert.equal(gone.missing, 1);
  assert.deepEqual(G.summarizeImages([], [], NOW).orphans, []);
});
await t('scanImages membaca saja; clearUnusedImages menghapus HANYA yatim lama dan melaporkan jumlah/ukuran', async () => {
  const data = mkData();
  const files = [{ name: A + '.webp', size: 2000, mtime: NOW - 99999999 }, { name: B + '.jpg', size: 3000, mtime: NOW - 99999999 }, { name: C + '.webp', size: 5000, mtime: NOW - 99999999 }, { name: D + '.png', size: 7000, mtime: NOW - 1000 }];
  const fs = mkFS(files);
  const sum = await scanImages(data, NOW, fs); assert.equal(sum.orphans.length, 1); assert.equal(fs.calls.length, 0);
  const r = await clearUnusedImages(data, NOW, fs);
  assert.deepEqual(r, { removed: 1, freed: 5000 }); assert.deepEqual(fs.calls, ['gambar/' + C + '.webp']);
  assert.deepEqual(files.map((f) => f.name).sort(), [A + '.webp', B + '.jpg', D + '.png'].sort());
  assert.deepEqual(await clearUnusedImages(data, NOW, fs), { removed: 0, freed: 0 });
});
await t('folder gambar belum ada / FS galat: scan kosong, bersihkan tidak melempar', async () => {
  const fs = { async readdir() { throw new Error('tidak ada'); } };
  const sum = await scanImages(mkData(), NOW, fs); assert.equal(sum.diskCount, 0);
  assert.deepEqual(await clearUnusedImages(mkData(), NOW, fs), { removed: 0, freed: 0 });
});
await t('kabel: penampil dibuka dari ketuk (Baca) dan tombol Lihat (Edit, tetap aktif saat terkunci); Kembali dan cleanup menutupnya', () => {
  const nt = src('../src/js/notes.js'), mn = src('../src/js/main.js'), css = src('../src/css/styles.css');
  assert.match(nt, /import \{ openViewer, closeViewer \} from '\.\/penampil\.js'/);
  assert.ok(nt.includes("if (editorMode !== 'edit') { e.preventDefault();") && nt.includes('viewImage(fig)'));
  assert.ok(nt.includes("tapBtn(imgView, (fig) => viewImage(fig), true)"));
  assert.ok(nt.includes("'Lihat layar penuh'") && nt.includes('imgFlow, imgView'));
  assert.match(nt, /const cleanup = \(\) => \{ alive = false; closeViewer\(\);/);
  assert.match(mn, /function handleBack\(\) \{\n  if \(closeViewer\(\)\) return 'handled';/);
  assert.ok(css.includes('.img-b.fl.vw') === false && css.includes('.img-tools.locked .img-b.fl:not(.vw){display:none}'));
  assert.ok(!/\.img-tools\.locked[^{]*\.img-row\.r3\{display:none/.test(css));
});
await t('penampil hemat memori: satu gambar sekali, URL dicabut, tanpa backdrop-filter, z-index di atas alat gambar', () => {
  const pm = src('../src/js/penampil.js'), css = src('../src/css/styles.css');
  assert.ok(pm.includes('URL.revokeObjectURL') && pm.includes('token++') && pm.includes('if (my !== token || !cur) return;'));
  assert.equal((pm.match(/createObjectURL/g) || []).length, 1);
  const blok = css.slice(css.indexOf('/* ===== Rev 60')).replace(/\/\*[\s\S]*?\*\//g, '');
  assert.ok(/\.imgviewer\{[^}]*z-index:40/.test(blok) && !/backdrop-filter/.test(blok));
  assert.ok(/touch-action:none/.test(blok));
});
await t('kualitas dari Setelan dipakai saat menambah gambar; layar Gambar terdaftar di Setelan dan tombol Kembali', () => {
  const nt = src('../src/js/notes.js'), st = src('../src/js/settings.js');
  assert.ok(nt.includes('compressImage(chosen[i], data.settings.imageQuality || G.DEFAULT_PRESET)'));
  for (const k of ["moreView === 'gambar'", "'Kualitas gambar baru'", "'Bersihkan gambar tak terpakai'", 'clearUnusedImages', 'scanImages', "go('gambar')", 'Gambar lama tidak dikompres ulang']) assert.ok(st.includes(k), k);
  assert.ok(!st.includes('ctx.render(); toast(\'Gagal membersihkan'));
});
await t('tanpa native/plugin/workflow baru; versi 0.3.2 selaras', () => {
  const pk = JSON.parse(src('../package.json'));
  assert.equal(pk.version, '0.3.121'); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121')); assert.ok(src('../RIWAYAT.md').includes('versi 0.3.2'));
  assert.ok(!/penampil|imageQuality/.test(src('../scripts/apply-native.mjs')));
});
console.log(n + ' tes g4 lulus');
