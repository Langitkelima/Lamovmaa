// Rev 277 / W2 (paket Peringatan + Pelacakan Error): penanda merah "#ERROR" di sel (isi tetap), ringkasan "N sel tidak sah", ikon peringatan di kanan chip Tambah baris. Tes AI saja (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
test('kabel UI: errB di kanan chip Tambah baris, ringkasan, lompat berbagi goTo, paintErr murah', () => {
  const ui = src('src/js/lembar-ui.js');
  for (const k of ["class: 'lz-err'", "class: 'lz-errn'", "addBar.append(errB)", "' sel tidak sah'", 'const paintErr = (iv)', 'paintErr(iv)', 'const goTo = (m)', 'errB.onclick', 'goTo(m)']) assert.ok(ui.includes(k), k);
  assert.ok(ui.indexOf("addBar.append(errB)") > ui.indexOf("String(n))));"), 'ikon SETELAH chip 10 dan 100');
  assert.match(ui, /const goBad = \(\) => \{ const m = nextInvalid\(getIV\(\), getOrder\(\), sel\);/);
  assert.match(ui, /if \(errN\.dataset\.n === String\(n\)\) return;/);
});
test('CSS: #ERROR merah di ::before (panah ::after tetap), ikon peringatan, catatan peringatan editor', () => {
  const css = src('src/css/styles.css');
  assert.match(css, /\.lz-c\.bad::before\{content:'#ERROR'/); assert.match(css, /\.lz-err\[hidden\]\{display:none\}/); assert.match(css, /\.vd-note\.warn\{/);
  assert.match(css, /\.lz-c\.dd::after\{content:'\\25BE'/);
  assert.doesNotMatch(css, /\.lz-c\.bad::after/);
});
test('isi sel tidak diubah penanda: tanda hanya kelas bad + title, tanpa menulis data', () => {
  const ui = src('src/js/lembar-ui.js'), i = ui.indexOf("el.classList.add('bad')"), around = ui.slice(i - 80, i + 260);
  assert.ok(around.includes('el.title = invalidTip(')); assert.doesNotMatch(around, /setCell|textContent\s*=\s*'#ERROR'/);
});
