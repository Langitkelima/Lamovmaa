// Rev 149 / U9b-1: FILTER BARIS SEMENTARA lembar kerja (modul murni lembar-filter.js + kabel UI). Tidak disimpan, tidak mengubah data.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as F from '../src/js/lembar-filter.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { a1ToStored } from '../src/js/rumus.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js');
const mk = (vals) => { const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; vals.forEach((v, r) => { if (v !== undefined) L.setCell(tab, tab.rows[r].id, tab.cols[0].id, { v }); }); return { sh, tab }; };

test('cleanFilter: jenis asing, kolom hilang, nilai wajib kosong, angka tidak valid ditolak; jenis tanpa nilai tidak butuh nilai', () => {
  const { tab } = mk([]); const c = tab.cols[0].id;
  assert.equal(F.cleanFilter({ c, k: 'zzz', a: 'x' }, tab.cols), null); assert.equal(F.cleanFilter({ c: 'cZZ', k: 'eq', a: 'x' }, tab.cols), null);
  assert.equal(F.cleanFilter({ c, k: 'contains', a: '  ' }, tab.cols), null); assert.equal(F.cleanFilter({ c, k: 'gt', a: 'abc' }, tab.cols), null);
  assert.deepEqual(F.cleanFilter({ c, k: 'gt', a: ' 1,5 ' }, tab.cols), { c, k: 'gt', a: '1,5' }); assert.deepEqual(F.cleanFilter({ c, k: 'empty', a: 'x' }, tab.cols), { c, k: 'empty', a: '' });
  assert.equal(F.cleanFilter(null, tab.cols), null);
});

test('filterRows: contains/eq/ne tak peka huruf, kosong/tidak kosong, gt/lt angka (koma desimal), urutan asli, filter tak sah = semua baris', () => {
  const { tab } = mk(['Kopi susu', 'kopi', 'Teh', undefined, 10, 2.5]); const c = tab.cols[0].id, d = makeDisplay(tab);
  assert.deepEqual(F.filterRows(tab, { c, k: 'contains', a: 'KOPI' }, d), [0, 1]); assert.deepEqual(F.filterRows(tab, { c, k: 'eq', a: 'kopi' }, d), [1]);
  assert.equal(F.filterRows(tab, { c, k: 'ne', a: 'kopi' }, d).includes(1), false);
  assert.deepEqual(F.filterRows(tab, { c, k: 'empty' }, d).slice(0, 1), [3]); assert.deepEqual(F.filterRows(tab, { c, k: 'nonempty' }, d), [0, 1, 2, 4, 5]);
  assert.deepEqual(F.filterRows(tab, { c, k: 'gt', a: '2,4' }, d), [4, 5]); assert.deepEqual(F.filterRows(tab, { c, k: 'lt', a: '5' }, d), [5]); // teks tidak cocok aturan angka
  assert.equal(F.filterRows(tab, { c, k: 'zzz' }, d).length, tab.rows.length); assert.equal(F.filterRows(null, null, d).length, 0);
});

test('filterRows memakai HASIL rumus dan teks tampil; tidak mengubah data tab', () => {
  const { tab } = mk([5, 'x']); L.setCell(tab, tab.rows[2].id, tab.cols[0].id, { fx: a1ToStored('=A1*3', tab).fx });
  const before = JSON.stringify(tab), c = tab.cols[0].id;
  assert.deepEqual(F.filterRows(tab, { c, k: 'gt', a: '10' }, makeDisplay(tab)), [2]); assert.deepEqual(F.filterRows(tab, { c, k: 'eq', a: '15' }, makeDisplay(tab)), [2]);
  assert.equal(JSON.stringify(tab), before);
});

test('filterText + label', () => {
  assert.equal(F.filterText({ c: 'x', k: 'contains', a: 'kopi' }, 'A'), 'Kolom A: berisi teks “kopi”'); assert.equal(F.filterText({ c: 'x', k: 'empty', a: '' }, ''), 'kosong'); assert.equal(F.filterText(null, 'A'), '');
  assert.equal(F.filterNeedsValue('empty'), false); assert.equal(F.FILTER_KINDS.length, 7);
});

test('kabel UI: filter sementara, order dihitung SEKALI per (tab, ver, filter), nomor baris asli, TIDAK menyimpan/Urungkan', () => {
  assert.match(ui, /from '\.\/lembar-filter\.js'/); assert.equal((ui.match(/filterRows\(/g) || []).length, 1, 'filterRows hanya di getOrder');
  const g = ui.slice(ui.indexOf('const getOrder'), ui.indexOf('const NO_IV')); assert.match(g, /tab\.id \+ '\|' \+ ver \+ '\|' \+ fltSig\(\)/);
  const d = ui.slice(ui.indexOf('const drawRows'), ui.indexOf('const paintBar'));
  assert.match(d, /const ord = getOrder\(\)/); assert.match(d, /visibleRangeH\(lay\.tops, scroller\.scrollTop, scroller\.clientHeight \|\| innerHeight, BUFFER\)/); assert.match(d, /fltSig\(\), lay\.tops\[total\]\]\.join/); // Rev 184b: tinggi baris bebas
  assert.match(d, /rowEl\.style\.top = lay\.tops\[k\] \+ 'px'/); assert.match(d, /String\(r \+ 1\)/); assert.match(d, /'data-r': String\(r\)/);
  const o = ui.slice(ui.indexOf('const openFilter'), ui.indexOf('const openMore'));
  assert.doesNotMatch(o, /hist\.push|onChange|touched\(|L\.set/); assert.match(o, /if \(!sel\) \{ t(?:Ok|Warn|Err|Info)\('Pilih sel dulu\.'\)/);
  const m = ui.slice(ui.indexOf('const openMore'), ui.indexOf('bM.addEventListener')); assert.ok(m.indexOf("item('validasi'") < m.indexOf("item('filter'") && m.indexOf("item('filter'") < m.indexOf("item('csv'"));
});

test('Rev 149: modul murni, ekspor/pulau/alat TIDAK memakai filter, CSS, versi 0.3.121, SCHEMA 15, tes terdaftar', () => {
  const m = src('src/js/lembar-filter.js'); assert.doesNotMatch(m, /^import /m); assert.doesNotMatch(m, /document\.|window\.|localStorage|sessionStorage|\beval\s*\(|new Function/);
  for (const f of ['src/js/lembar.js', 'src/js/lembar-alat.js', 'src/js/lembar-pulau.js', 'src/js/lembar-tampil.js', 'src/js/export.js']) assert.doesNotMatch(src(f), /lembar-filter/, f);
  const css = src('src/css/styles.css'); for (const k of ['.lembarfs .lz-flt{', '.lz-fltd .lz-rop']) assert.ok(css.includes(k), k);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(pk.scripts.test.includes('tests/rev149.test.mjs'));
});
