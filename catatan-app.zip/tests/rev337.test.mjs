// Rev 337 / PART I4: hitung cepat `12*3=` di editor catatan (tampilan; mesin = ketik-pemicu.js dari Rev 336).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
// ketik-ui.js mengimpor ui.js (butuh document) hanya untuk pasangKetik; fungsi murni diuji dengan document palsu minimal.
globalThis.document = { createElement: () => ({ setAttribute() {}, addEventListener() {}, append() {}, className: '' }), createTextNode: (t) => ({ nodeType: 3, data: t }) };
const { lineBefore, calcFor } = await import('../src/js/ketik-ui.js');

const T = (data) => ({ nodeType: 3, data });
const E = (tagName, ...kids) => { const e = { nodeType: 1, tagName, childNodes: kids, get textContent() { return kids.map((k) => (k.nodeType === 3 ? k.data : k.textContent)).join(''); } }; kids.forEach((k, i) => { k.parentNode = e; k.previousSibling = kids[i - 1] || null; }); return e; };

test('lineBefore: teks sebelum kursor dalam satu simpul, dipotong di offset', () => {
  const ed = E('DIV', T('12*3=sisa')); const t = ed.childNodes[0];
  assert.equal(lineBefore(ed, t, 5), '12*3=');
});
test('lineBefore: berhenti di <br> dan di elemen blok sebelumnya', () => {
  const ed = E('DIV', T('baris satu'), E('BR'), T('2+2=')); assert.equal(lineBefore(ed, ed.childNodes[2], 4), '2+2=');
  const ed2 = E('DIV', E('DIV', T('lama')), T('5*5=')); assert.equal(lineBefore(ed2, ed2.childNodes[1], 4), '5*5=');
});
test('lineBefore: elemen sebaris (<b>) ikut dihitung dan naik ke induk sampai blok', () => {
  const ed = E('DIV', T('Total '), E('B', T('3')), T('*4=')); assert.equal(lineBefore(ed, ed.childNodes[2], 3), 'Total 3*4=');
  const inner = E('B', T('2+')), inner2 = T('3='); const row = E('DIV', inner, inner2); const ed3 = E('DIV', row);
  assert.equal(lineBefore(ed3, inner2, 2), '2+3=');
  const ed4 = E('DIV', E('P', T('x'), E('SPAN', T('7*6=')))); const sp = ed4.childNodes[0].childNodes[1].childNodes[0];
  assert.equal(lineBefore(ed4, sp, 4), 'x7*6=', 'naik dari <span> ke <p> lalu berhenti di blok');
});
test('lineBefore: kursor bukan di simpul teks = null', () => {
  const ed = E('DIV', E('BR')); assert.equal(lineBefore(ed, ed, 0), null); assert.equal(lineBefore(ed, null, 0), null);
});

test('calcFor: hasil gaya Indonesia, tanpa eval', () => {
  assert.deepEqual({ ...calcFor('12*3=') }, { value: 36, text: '36', expr: '12*3' });
  assert.equal(calcFor('Total: 1,5jt*2=').text, '3.000.000');
  assert.equal(calcFor('Belanja 2jt+500rb=').text, '2.500.000');
  assert.equal(calcFor('(2+3)*4=').text, '20');
  assert.equal(calcFor('200*10%=').text, '20');
  assert.equal(calcFor('10/4=').text, '2,5');
  assert.equal(calcFor('2^10=').text, '1.024');
  assert.equal(calcFor('catatan 7×6=').text, '42');
});
test('calcFor: yang bukan ekspresi tidak memicu', () => {
  for (const s of ['5=', 'abc=', '12*3', '12*=', '10/0=', '1.5.3*2=', 'alert(1)=', '', '=', '2 3=', 'x == 5=']) assert.equal(calcFor(s), null, JSON.stringify(s));
  assert.equal(calcFor(null), null); assert.equal(calcFor(42), null);
});
test('calcFor: [[ terbuka tidak dihitung bila hanya diminta calc? (calc tetap sah; wiki menyusul di I2)', () => {
  assert.equal(calcFor('[[a 2+3=').text, '5', 'selama I2 belum ada, hanya calc yang diminta');
});

test('sumber notes.js: pemicu malas, hanya Catatan Biasa, tanpa impor statis', () => {
  const n = read('src/js/notes.js');
  assert.ok(!/^import .*ketik-ui/m.test(n), 'ketik-ui.js tidak boleh diimpor statis (anggaran JS buka)');
  assert.ok(!/^import .*ketik-pemicu/m.test(n), 'ketik-pemicu.js tidak boleh diimpor statis');
  const i = n.indexOf('Rev 337 / I4'); assert.ok(i > 0, 'blok pemicu ada');
  const blok = n.slice(Math.max(0, i - 40), i + 6000); // `if (!isP) {` ada tepat sebelum komentar penanda
  assert.match(blok, /if \(!isP\)/, 'tidak dipasang di Catatan Privat');
  assert.match(blok, /editorMode !== 'edit'/, 'tidak di mode Baca');
  assert.match(blok, /import\('\.\/ketik-ui\.js'\)/, 'dimuat malas');
  assert.match(blok, /=== '='|!== '='/, 'gerbang murah: hanya sesudah tanda =');
  assert.match(blok, /if \(alive\)/, 'tidak memasang bila editor sudah ditutup');
});
test('sumber ketik-ui.js: tidak menulis otomatis, tidak mencuri fokus, satu langkah Urungkan, tanpa eval', () => {
  const k = read('src/js/ketik-ui.js');
  assert.ok(!/\beval\s*\(|new Function|innerHTML/.test(k), 'tanpa eval/Function/innerHTML');
  assert.match(k, /onpointerdown: stop/); assert.match(k, /onmousedown: stop/); assert.match(k, /preventDefault/);
  const ap = k.slice(k.indexOf('const apply = () =>'), k.indexOf('// ---- Rev 339')); // Rev 339: flushHist format otomatis berada di luar fungsi apply
  assert.equal((ap.match(/flushHist\(\)/g) || []).length, 2, 'catat sebelum dan sesudah sisip = hasil jadi satu langkah');
  assert.match(k, /insertText/); assert.match(k, /BLOCKED/); assert.match(k, /isContentEditable/);
  assert.match(k, /td,th,table/, 'tidak di sel tabel (D-I1)');
  assert.ok(!/from '\.\/notes\.js'/.test(k) && !/from '\.\/storage\.js'/.test(k), 'tanpa penyimpanan, tanpa impor notes');
  assert.ok(!/localStorage|fetch\(|XMLHttp/.test(k), 'tanpa jaringan/penyimpanan');
});
test('CSS: blok I4 hanya variabel tema dan menyembunyikan baris saat hidden', () => {
  const css = read('src/css/styles.css'); const i = css.indexOf('/* Rev 337 / I4'); assert.ok(i > 0);
  const j = css.indexOf('/* Rev 340 / I6'); // Rev 343: blok I4 berakhir di awal blok I6 (blok berikutnya ditambahkan di akhir berkas dan diperiksa tesnya sendiri)
  const blok = css.slice(i, j > i ? j : undefined);
  assert.match(blok, /\.kp-row\[hidden\]\{display:none\}/);
  assert.ok(!/#[0-9a-fA-F]{3,8}\b|rgba?\(/.test(blok), 'tanpa warna tetap');
  assert.ok(blok.length < 1200, 'blok CSS kecil');
});
