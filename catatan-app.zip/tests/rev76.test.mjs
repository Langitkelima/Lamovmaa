// Rev 76: menu tabel solid + rata teks sel (data-a) + pilih sel/baris/kolom/semua; ekspor ikut rata; versi 0.3.2.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseNoteHtml, layoutDoc } from '../src/js/export.js';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const nt = src('src/js/notes.js'), css = src('src/css/styles.css');

test('Rev 76: sanitize hanya mengizinkan data-a c/r di TD/TH dan membuang data-sel', () => {
  assert.match(nt, /\(c\.tagName === 'TD' \|\| c\.tagName === 'TH'\) && k === 'data-a' && \/\^\[cr\]\$\/\.test\(v\)/);
  assert.ok(!/data-sel'\s*&&/.test(nt) && !nt.includes("k === 'data-sel'"));
});
test('Rev 76 (diganti Rev 97): menu ▦ dihapus; rata teks, pilihan bagian, dan aksi lama pindah ke chip', () => {
  assert.ok(!nt.includes('data-table-align') && !nt.includes('data-table-select') && !nt.includes('data-table-action'));
  for (const id of ['align', 'sel-cell', 'sel-row', 'sel-col', 'sel-all', 'hdr-row', 'hdr-col', 'row-del', 'col-del', 'tbl-del']) assert.ok(nt.includes("'" + id + "'") || nt.includes("id === '" + id + "'"), id);
});
test('Rev 76: rata teks menjaga atribut saat ganti baris/kolom judul dan saat tambah baris', () => {
  const bc = src('src/js/bilah-chip.js'); // Rev 97: retag menyalin SEMUA atribut (termasuk data-a); tambah baris menyalin data-a kolom acuan
  assert.match(bc, /for \(const a of \[\.\.\.cell\.attributes\]\) rep\.setAttribute\(a\.name, a\.value\)/);
  assert.ok(bc.includes("cell.setAttribute('data-a', a)"));
});
test('Rev 76: pilihan sementara dibersihkan saat pindah sel, mode Baca, dan aksi struktur', () => {
  assert.ok(nt.includes('const resetSel = ') && nt.includes('if (cell !== selCell)'));
  assert.match(nt, /activeTable = activeCell = null; resetSel\(\); \}\n    const baca/);
  assert.ok(nt.includes("if (selScope !== 'cell') { selScope = 'cell'; clearSel(); }"));
});
test('Rev 76: CSS rata teks dan sorotan pilihan (gaya menu ▦ dihapus di Rev 97)', () => {
  assert.ok(!css.includes('.tbl-menu'));
  assert.ok(css.includes('.ed2 td[data-a="c"],.ed2 th[data-a="c"]{text-align:center}') && css.includes('.ed2 td[data-a="r"],.ed2 th[data-a="r"]{text-align:right}'));
  assert.ok(css.includes('.ed2 [data-sel]{'));
});
test('Rev 76: ekspor membawa rata sel (a) ke tata letak', () => {
  const blocks = parseNoteHtml('<div class="tbl-wrap"><table><tbody><tr><td data-a="c">A</td><td data-a="r">B</td><td>C</td></tr><tr><td>1</td><td>2</td><td>3</td></tr></tbody></table></div>');
  const t = blocks.find((b) => b.kind === 'table');
  assert.deepEqual(t.rows[0].map((c) => c.a), ['c', 'r', '']);
  const lines = layoutDoc({ title: '', blocks }, { width: 1240, height: 1754, size: 28, padX: 60, padY: 60, measure: (t) => t.length * 14 });
  const row = lines.find((l) => l.kind === 'tableRow');
  assert.deepEqual(row.cells.map((c) => c.a), ['c', 'r', '']);
});
test('Rev 76: tanpa native/SCHEMA; versi 0.3.2 selaras', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('RIWAYAT.md').includes('versi 0.3.2'));
});
