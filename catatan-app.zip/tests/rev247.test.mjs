// Rev 247: pembersihan kode/CSS yang terbukti tidak dipakai (analisis rujukan seluruh src, scripts, tools, tes). Tanpa perubahan perilaku.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, readdirSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('simbol mati dibuang: scopeCellsOf (bilah-chip) dan FOLD_CLASS (lipat)', () => {
  assert.doesNotMatch(src('src/js/bilah-chip.js'), /scopeCellsOf/); assert.doesNotMatch(src('src/js/lipat.js'), /FOLD_CLASS/);
  assert.match(src('src/js/bilah-chip.js'), /komponen bilah chip \(DOM\)/); // bagian sesudahnya utuh
});
test('CSS: kelas tak dipakai (.setgrp, .cap.capb, .aiin) dibuang; kelas dinamis dan tetangganya utuh', () => {
  const c = src('src/css/styles.css');
  for (const k of ['.setgrp', '.capb', '.aiin', '.kai-ob']) assert.ok(!c.includes(k), k);
  for (const k of ['.kai-og button', '.seg3', '.tn-v', '.ha-center', '.sethero', '.daycard', '.fbar .numfmt']) assert.ok(c.includes(k), k);
  const js = readdirSync(new URL('../src/js/', import.meta.url)).map((f) => (f.endsWith('.js') ? src('src/js/' + f) : '')).join('\n');
  for (const k of ['setgrp', 'capb', 'aiin', 'kai-ob']) assert.ok(!js.includes(k), 'JS tidak memakai ' + k);
});
test('tanpa versi/SCHEMA berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev247\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
