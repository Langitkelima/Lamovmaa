// Rev 179b / U10e-2: SALIN & TEMPEL RENTANG (copyRange/pasteRange di lembar-alat.js + kabel UI). Salin satu sel (Rev 171/172) tidak berubah.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { copyCell, pasteClip, copyRange, pasteRange } from '../src/js/lembar-alat.js';
import { a1ToStored } from '../src/js/rumus.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = (n = 12) => { const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; if (tab.rows.length < n) L.addRows(tab, n - tab.rows.length); return { sh, tab }; };
const put = (tab, r, c, p) => L.setCell(tab, tab.rows[r].id, tab.cols[c].id, p);
const fx = (tab, r, c, t) => put(tab, r, c, { fx: a1ToStored(t, tab).fx });
const v = (tab, r, c) => { const x = L.cellAt(tab, r, c); return x ? x.v : undefined; };
const txt = (tab, r, c) => makeDisplay(tab).text(r, c);

test('copyRange: bentuk clip, ukuran, gaya ikut, gabungan tertutup = null, rentang tidak sah ditolak', () => {
  const { tab } = mk(); put(tab, 0, 0, { v: 'a', s: { b: true } }); put(tab, 0, 1, { v: 5 }); put(tab, 1, 0, { v: 7 });
  const c = copyRange(tab, { r1: 0, c1: 0, r2: 1, c2: 1 }); assert.equal(c.ok, true); const k = c.clip;
  assert.deepEqual([k.range, k.rows, k.cols, k.rowIds.length, k.colIds.length, k.tabId], [true, 2, 2, 2, 2, tab.id]);
  assert.equal(k.cells[0][0].v, 'a'); assert.deepEqual(k.cells[0][0].s, { b: true }); assert.equal(k.cells[0][1].v, 5); assert.equal(k.cells[1][1].v, undefined);
  for (const bad of [null, { r1: 0, c1: 0, r2: 99, c2: 0 }, { r1: 2, c1: 0, r2: 1, c2: 0 }, { r1: -1, c1: 0, r2: 0, c2: 0 }]) assert.equal(copyRange(tab, bad).ok, false);
  const m = mk(); put(m.tab, 0, 0, { v: 'J' }); L.mergeCells(m.tab, 0, 0, 1, 1, { clear: true }); const mc = copyRange(m.tab, { r1: 0, c1: 0, r2: 1, c2: 1 }).clip;
  assert.equal(mc.cells[0][0].v, 'J'); assert.equal(mc.cells[0][1], null); assert.equal(mc.cells[1][0], null); assert.equal(mc.cells[1][1], null);
});
test('pasteRange (Semua): isi + gaya sebesar sumber di kiri-atas tujuan; tidak mengubah sumber', () => {
  const { tab } = mk(); put(tab, 0, 0, { v: 'a', s: { b: true } }); put(tab, 0, 1, { v: 5 }); put(tab, 1, 0, { v: 7 }); put(tab, 1, 1, { v: 'z', s: { i: true } });
  const k = copyRange(tab, { r1: 0, c1: 0, r2: 1, c2: 1 }).clip; const res = pasteRange(tab, k, 5, 2, {});
  assert.equal(res.ok, true); assert.equal(res.pasted, 4); assert.deepEqual([res.rows, res.cols], [2, 2]);
  assert.equal(v(tab, 5, 2), 'a'); assert.equal(v(tab, 5, 3), 5); assert.equal(v(tab, 6, 2), 7); assert.equal(v(tab, 6, 3), 'z');
  assert.equal(L.cellAt(tab, 5, 2).s.b, true); assert.equal(L.cellAt(tab, 6, 3).s.i, true); assert.equal(v(tab, 0, 0), 'a'); assert.equal(v(tab, 1, 1), 'z');
});
test('pasteRange: rumus relatif bergeser sesuai posisinya, $ tetap, keluar lembar jadi #REF! dan dihitung', () => {
  const { tab } = mk(); put(tab, 0, 0, { v: 1 }); put(tab, 0, 1, { v: 2 }); fx(tab, 1, 0, '=A1*10'); fx(tab, 1, 1, '=$B$1+B1');
  const k = copyRange(tab, { r1: 1, c1: 0, r2: 1, c2: 1 }).clip; const res = pasteRange(tab, k, 4, 0, {});
  assert.equal(res.fxPasted, 2); put(tab, 3, 0, { v: 4 }); put(tab, 3, 1, { v: 6 }); assert.equal(txt(tab, 4, 0), '40'); assert.equal(txt(tab, 4, 1), '8'); // =A4*10 ; =$B$1+B4 = 2+6
  const up = copyRange(tab, { r1: 1, c1: 0, r2: 1, c2: 0 }).clip; const r2 = pasteRange(tab, up, 0, 0, {}); assert.equal(r2.refLost, 1);
});
test('pasteRange (Isi & rumus) tanpa gaya; (Gaya saja) tanpa isi; (Nilai saja) hanya hasil hitung dan boleh lintas tab', () => {
  const { sh, tab } = mk(); put(tab, 0, 0, { v: 3, s: { b: true } }); fx(tab, 0, 1, '=A1*2'); put(tab, 5, 0, { v: 'x', s: { i: true } }); put(tab, 5, 1, { v: 'y' });
  const k = copyRange(tab, { r1: 0, c1: 0, r2: 0, c2: 1 }).clip;
  pasteRange(tab, k, 5, 0, { mode: 'content' }); assert.equal(v(tab, 5, 0), 3); assert.equal(L.cellAt(tab, 5, 0).s.i, true); assert.ok(L.cellAt(tab, 5, 1).fx);
  const t2 = mk(); put(t2.tab, 2, 0, { v: 'keep' }); const pk = copyRange(tab, { r1: 0, c1: 0, r2: 0, c2: 1 }).clip;
  pasteRange(tab, pk, 8, 0, { mode: 'style' }); assert.equal(L.cellAt(tab, 8, 0).s.b, true); assert.equal(v(tab, 8, 0), undefined);
  const vr = pasteRange(t2.tab, pk, 0, 0, { mode: 'values' }); assert.equal(vr.ok, true); assert.equal(v(t2.tab, 0, 0), 3); assert.equal(v(t2.tab, 0, 1), 6); assert.equal(L.cellAt(t2.tab, 0, 1).fx, undefined); assert.equal(v(t2.tab, 2, 0), 'keep');
  const bl = pasteRange(t2.tab, pk, 0, 0, { mode: 'all' }); assert.equal(bl.blocked, 'tab'); assert.equal(bl.ok, false); assert.equal(pasteRange(t2.tab, pk, 0, 0, { mode: 'content' }).blocked, 'tab');
});
test('pasteRange: baris/kolom sumber sudah dihapus = blocked origin (tidak ada yang berubah); Nilai saja tetap boleh', () => {
  const { tab } = mk(); put(tab, 0, 0, { v: 1 }); put(tab, 1, 0, { v: 2 }); const k = copyRange(tab, { r1: 0, c1: 0, r2: 1, c2: 0 }).clip;
  L.deleteRow(tab, tab.rows[1].id); const before = JSON.stringify(tab); const r = pasteRange(tab, k, 4, 0, { mode: 'all' }); assert.equal(r.blocked, 'origin'); assert.equal(r.ok, false); assert.equal(JSON.stringify(tab), before);
  const ok = pasteRange(tab, k, 4, 0, { mode: 'values' }); assert.equal(ok.ok, true); assert.equal(v(tab, 4, 0), 1);
});
test('pasteRange: lewat tepi lembar = truncated dihitung; tujuan tertutup gabungan dilewati; sel tertutup sumber tidak mengosongkan tujuan', () => {
  const { tab } = mk(); for (let r = 0; r < 3; r++) for (let c = 0; c < 2; c++) put(tab, r, c, { v: r * 10 + c });
  const k = copyRange(tab, { r1: 0, c1: 0, r2: 2, c2: 1 }).clip, last = tab.rows.length - 1; const res = pasteRange(tab, k, last - 1, 0, {}); assert.equal(res.truncated, 2); assert.equal(res.pasted, 4); // 3 baris, hanya 2 muat
  const rc = pasteRange(tab, k, 5, tab.cols.length - 1, {}); assert.equal(rc.truncated, 3); assert.equal(rc.pasted, 3); // 2 kolom, hanya kolom terakhir muat
  const m = mk(); put(m.tab, 0, 5, { v: 'X' }); put(m.tab, 1, 5, { v: 'Y' }); L.mergeCells(m.tab, 0, 3, 1, 4, { clear: true }); const k2 = copyRange(m.tab, { r1: 0, c1: 5, r2: 1, c2: 5 }).clip;
  const r2 = pasteRange(m.tab, k2, 0, 4, {}); assert.equal(r2.skippedCovered >= 1, true); // (0,4) tertutup gabungan A:D? jangkar (0,3)
  const s = mk(); put(s.tab, 0, 0, { v: 'J' }); L.mergeCells(s.tab, 0, 0, 1, 1, { clear: true }); put(s.tab, 6, 1, { v: 'jangan hilang' }); const sk = copyRange(s.tab, { r1: 0, c1: 0, r2: 1, c2: 1 }).clip;
  pasteRange(s.tab, sk, 5, 0, {}); assert.equal(v(s.tab, 5, 0), 'J'); assert.equal(v(s.tab, 6, 1), 'jangan hilang');
});
test('pasteRange: sumber dan tujuan bertumpuk memakai potret saat Salin (hasil benar)', () => {
  const { tab } = mk(); [1, 2, 3].forEach((n, r) => put(tab, r, 0, { v: n })); const k = copyRange(tab, { r1: 0, c1: 0, r2: 2, c2: 0 }).clip; pasteRange(tab, k, 1, 0, {});
  assert.deepEqual([0, 1, 2, 3].map((r) => v(tab, r, 0)), [1, 1, 2, 3]);
});
test('pasteRange (Nilai saja): hasil galat dilewati dan dihitung, sel lain tetap ditempel', () => {
  const { tab } = mk(); put(tab, 0, 0, { v: 5 }); fx(tab, 0, 1, '=1/0'); const k = copyRange(tab, { r1: 0, c1: 0, r2: 0, c2: 1 }).clip;
  const r = pasteRange(tab, k, 3, 0, { mode: 'values' }); assert.equal(r.skippedErr, 1); assert.equal(r.pasted, 1); assert.equal(v(tab, 3, 0), 5);
});
test('rentang besar (2000 sel) tersalin dan tertempel cepat', () => {
  const { tab } = mk(500); for (let r = 0; r < 500; r++) for (let c = 0; c < 4; c++) put(tab, r, c, { v: r + c });
  const t0 = Date.now(); const k = copyRange(tab, { r1: 0, c1: 0, r2: 499, c2: 3 }).clip; const res = pasteRange(tab, k, 0, 4, {}); assert.equal(res.pasted, 2000); assert.ok(Date.now() - t0 < 4000);
});
test('Salin satu sel tidak berubah: copyCell/pasteClip tetap sama dan clip satu sel tanpa flag range', () => {
  const { tab } = mk(); put(tab, 0, 0, { v: 9, s: { b: true } }); const c = copyCell(tab, 0, 0); assert.equal(c.clip.range, undefined); const r = pasteClip(tab, c.clip, 3, 3, {}); assert.equal(r.pasted, 1); assert.equal(v(tab, 3, 3), 9);
  const ui = src('src/js/lembar-ui.js'); assert.ok(ui.includes('const res = copyCell(tab, sel.r, sel.c)') && ui.includes('pasteClip(tab, clip, at.r, at.c, { ...o, keepFx: (o.count || 1) > 1 })')); // Rev 255 / S5b: titik awal `at` = sudut kiri-atas seleksi (satu sel = jangkar)
});
test('kabel UI: doCopy menyalin rentang bila ada, runPaste memilih pasteRange, dialog menyembunyikan jumlah/arah, pesan galat, satu Urungkan', () => {
  const ui = src('src/js/lembar-ui.js'); assert.ok(ui.includes("import { copyCell, pasteClip, copyRange, pasteRange } from './lembar-alat.js'"));
  const d = ui.slice(ui.indexOf('const doCopy = () => {'), ui.indexOf('const openCopyPaste = () => {'));
  assert.ok(d.includes('copyRange(tab, rng.rect)') && d.includes('rgClear()') && d.includes('clip.range ? pasteRange(tab, clip, at.r, at.c, { mode: o.mode })'));
  assert.ok(d.includes('const snap = ser()') && d.includes('ver++, hist.push(snap)') && d.indexOf('L.fitsLimit(sheet)') < d.indexOf('hist.push(snap)'));
  const o = ui.slice(ui.indexOf('const openCopyPaste = () => {'), ui.indexOf('// --- Rev 152 / U10b-2a')); assert.ok(o.includes('rowOnly') && o.includes("'Salin rentang '") && o.includes('Disalin: rentang'));
  assert.ok(ui.includes("r.skippedErr) extra.push"));
});
test('Rev 179b: SCHEMA 17; versi 0.3.121; tes terdaftar; tanpa native/dependensi baru; alat tidak mengimpor lembar-rentang', () => {
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev180.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
  assert.deepEqual(Object.keys(JSON.parse(pk).dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  const al = src('src/js/lembar-alat.js'); assert.ok(!al.includes('lembar-rentang') && !/localStorage|eval\(|new Function|Capacitor/.test(al.slice(al.indexOf('salin / tempel RENTANG'))));
});
