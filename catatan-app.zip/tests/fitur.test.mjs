// Tes Rev 5: terakhir diedit, label, tautan + pratinjau, keluar total, pemasangan kode native.
import assert from 'node:assert/strict';
import * as L from '../src/js/logic.js';
import * as S from '../src/js/storage.js';
import { fetchPreview, openExternal } from '../src/js/links.js';
import { nativeExit, installBrowserBack, exitApp } from '../src/js/exit.js';
import { closeDialog } from '../src/js/ui.js';
import { mainActivitySource, ensureInternetPermission, ensureAdjustResize } from '../scripts/apply-native.mjs';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const at = (y, mo, d, h = 0, mi = 0) => new Date(y, mo - 1, d, h, mi).getTime();
const NOW = at(2026, 10, 25, 23, 0);

// ---- Terakhir diedit ----
await t('formatEdited: baru saja / menit lalu', () => {
  assert.equal(L.formatEdited(NOW - 20000, NOW), 'Baru saja');
  assert.equal(L.formatEdited(NOW - 5 * 60000, NOW), '5 menit lalu');
  assert.equal(L.formatEdited(NOW + 90000, NOW), 'Baru saja'); // jam HP mundur
});
await t('formatEdited: hari ini, kemarin, tanggal, tahun lain', () => {
  assert.equal(L.formatEdited(at(2026, 10, 25, 14, 30), NOW), 'Hari ini, 14.30');
  assert.equal(L.formatEdited(at(2026, 10, 24, 9, 5), NOW), 'Kemarin, 09.05');
  assert.equal(L.formatEdited(at(2026, 10, 20, 8, 0), NOW), '20 Okt, 08.00');
  assert.equal(L.formatEdited(at(2025, 12, 31, 23, 59), NOW), '31 Des 2025, 23.59');
});
await t('formatEdited: kemarin tetap benar melewati tengah malam', () => {
  assert.equal(L.formatEdited(at(2026, 10, 24, 23, 50), at(2026, 10, 25, 0, 10)), '20 menit lalu');
  assert.equal(L.formatEdited(at(2026, 10, 24, 22, 0), at(2026, 10, 25, 0, 10)), 'Kemarin, 22.00');
});
await t('formatEdited: kosong/rusak -> teks kosong', () => {
  assert.equal(L.formatEdited(undefined, NOW), ''); assert.equal(L.formatEdited(0, NOW), ''); assert.equal(L.formatEdited('x', NOW), '');
});
await t('noteSignature: berubah bila isi/warna/label berubah, tidak bergantung urutan label', () => {
  const a = L.noteSignature('J', '<b>x</b>', '#fff', ['b', 'a']);
  assert.equal(a, L.noteSignature('J', '<b>x</b>', '#fff', ['a', 'b']));
  assert.notEqual(a, L.noteSignature('J2', '<b>x</b>', '#fff', ['a', 'b']));
  assert.notEqual(a, L.noteSignature('J', '<b>y</b>', '#fff', ['a', 'b']));
  assert.notEqual(a, L.noteSignature('J', '<b>x</b>', '#000', ['a', 'b']));
  assert.notEqual(a, L.noteSignature('J', '<b>x</b>', '#fff', ['a']));
  assert.equal(L.noteSignature('', '', '', undefined), L.noteSignature(null, null, null, []));
});

// ---- Label ----
await t('validateLabel: kosong, terlalu panjang, ganda (tanpa peduli huruf besar), batas jumlah', () => {
  const ls = [{ id: '1', name: 'Kerja' }];
  assert.equal(L.validateLabel('   ', ls).ok, false);
  assert.equal(L.validateLabel('a'.repeat(21), ls).ok, false);
  assert.equal(L.validateLabel('kerja', ls).ok, false);
  assert.equal(L.validateLabel('  Pribadi   baru ', ls).value, 'Pribadi baru');
  assert.equal(L.validateLabel('Kerja', ls, '1').ok, true); // ganti nama ke dirinya sendiri boleh
  const many = Array.from({ length: 20 }, (_, i) => ({ id: 'i' + i, name: 'L' + i }));
  assert.equal(L.validateLabel('Baru', many).ok, false);
});
await t('toggleId, noteLabels, labelCounts', () => {
  assert.deepEqual(L.toggleId(undefined, 'a'), ['a']); assert.deepEqual(L.toggleId(['a', 'b'], 'a'), ['b']);
  const ls = [{ id: 'a', name: 'A' }, { id: 'b', name: 'B' }];
  assert.deepEqual(L.noteLabels({ labels: ['b', 'zzz'] }, ls).map((x) => x.id), ['b']); // id yatim diabaikan
  assert.deepEqual(L.noteLabels({}, ls), []);
  assert.deepEqual(L.labelCounts([{ labels: ['a'] }, { labels: ['a', 'b'] }, {}]), { a: 2, b: 1 });
});
await t('filterNotes: saring per label + kata kunci; tanpa label = semua', () => {
  const ns = [{ title: 'Rapat', labels: ['a'] }, { title: 'Belanja', labels: ['b'] }, { title: 'Rapat besar', labels: ['b'] }];
  assert.equal(L.filterNotes(ns, '', '').length, 3);
  assert.equal(L.filterNotes(ns, '', 'b').length, 2);
  assert.equal(L.filterNotes(ns, 'rapat', 'b').length, 1);
  assert.equal(L.filterNotes(ns, 'rapat').length, 2);
});
await t('removeLabel: dicopot dari catatan, privat, sampah; catatan tidak terhapus', () => {
  const d = { notes: [{ labels: ['a', 'b'] }], priv: [{ labels: ['a'] }], trash: [{ kind: 'note', item: { labels: ['a'] } }, { kind: 'task', item: {} }], settings: { labels: [{ id: 'a', name: 'A' }, { id: 'b', name: 'B' }] } };
  assert.equal(L.removeLabel(d, 'a'), 3);
  assert.deepEqual(d.notes[0].labels, ['b']); assert.deepEqual(d.priv[0].labels, []); assert.deepEqual(d.trash[0].item.labels, []);
  assert.deepEqual(d.settings.labels, [{ id: 'b', name: 'B' }]); assert.equal(d.notes.length, 1);
});

// ---- Penyimpanan / migrasi ----
await t('migrasi v1 -> v2: data lama tanpa label tetap terbaca, label bawaan kosong', () => {
  const v1 = { version: 1, habits: [], tasks: [], notes: [{ id: 'x', title: 'Lama', text: 't', updated: 5 }], priv: [], trash: [], settings: { days: [1], theme: 'dark', lastReset: '', recent: [] } };
  const d = S.normalize(v1);
  assert.deepEqual(d.settings.labels, []); assert.equal(d.notes[0].title, 'Lama'); assert.equal(d.settings.theme, 'dark');
  assert.equal(S.SCHEMA, 22);
});
await t('normalize: label rusak/ganda dibuang, nama dipangkas; impor cadangan v1 berhasil', () => {
  const d = S.normalize({ notes: [], settings: { labels: [{ id: 'a', name: ' Kerja ' }, { id: 'a', name: 'ganda' }, { id: 5, name: 'x' }, null, { id: 'b', name: '' }, { id: 'c', name: 'x'.repeat(50) }] } });
  assert.deepEqual(d.settings.labels.map((l) => l.id), ['a', 'c']); assert.equal(d.settings.labels[0].name, 'Kerja'); assert.equal(d.settings.labels[1].name.length, 20);
  assert.equal(S.normalize({ notes: [], settings: { labels: 'bukan array' } }).settings.labels.length, 0);
  assert.equal(S.importJSON(JSON.stringify({ version: 1, notes: [{ id: 'q' }] })).ok, true);
});

// ---- Tautan ----
await t('extractUrls: tanda baca, www, duplikat, batas 3, bukan tautan', () => {
  assert.deepEqual(L.extractUrls('lihat https://example.com/a?b=1, dan www.kompas.com. juga (https://x.id/p).'), ['https://example.com/a?b=1', 'https://www.kompas.com', 'https://x.id/p']);
  assert.deepEqual(L.extractUrls('https://a.com https://a.com'), ['https://a.com']);
  assert.equal(L.extractUrls('https://a.com https://b.com https://c.com https://d.com').length, 3);
  assert.deepEqual(L.extractUrls('ftp://x.com javascript:alert(1) file:///etc/passwd localhost:8080 http://tanpatitik https://ab'), []);
  assert.deepEqual(L.extractUrls(null), []);
});
await t('hostOf dan safeImageUrl: hanya https untuk gambar', () => {
  assert.equal(L.hostOf('https://www.kompas.com/x'), 'kompas.com');
  assert.equal(L.safeImageUrl('https://a.com/i.jpg'), 'https://a.com/i.jpg');
  for (const bad of ['http://a.com/i.jpg', 'javascript:alert(1)', 'data:image/png;base64,AAA', '', null, 'a.com/i.jpg']) assert.equal(L.safeImageUrl(bad), '');
});
const HTML = `<!doctype html><html><head><title> Judul &amp; Biasa </title>
<meta property="og:title" content="Berita &quot;Utama&quot; &#38; Lainnya">
<meta property='og:image' content='/img/a.jpg?x=1&amp;y=2'>
<meta name="twitter:image" content="https://cdn.x.com/lain.png">
<meta property="og:site_name" content="Situs Contoh"></head><body><meta property="og:title" content="JANGAN DIPAKAI"></body></html>`;
await t('parsePreview: og:title/og:image/og:site_name, entitas, alamat relatif jadi absolut, hanya <head>', () => {
  const p = L.parsePreview(HTML, 'https://contoh.com/artikel/1');
  assert.equal(p.t, 'Berita "Utama" & Lainnya'); assert.equal(p.i, 'https://contoh.com/img/a.jpg?x=1&y=2'); assert.equal(p.s, 'Situs Contoh');
});
await t('parsePreview: cadangan <title> + twitter:image, http dinaikkan ke https, gambar berbahaya dibuang', () => {
  assert.equal(L.parsePreview('<title>Hanya Judul</title>', 'https://a.com').t, 'Hanya Judul');
  assert.equal(L.parsePreview('<meta name="twitter:image" content="http://a.com/i.png">', 'https://a.com').i, 'https://a.com/i.png');
  assert.equal(L.parsePreview('<meta property="og:image" content="javascript:alert(1)">', 'https://a.com').i, '');
  assert.deepEqual(L.parsePreview('', 'https://a.com'), { t: '', i: '', s: '' });
  assert.deepEqual(L.parsePreview(null, 'https://a.com'), { t: '', i: '', s: '' });
});
await t('parsePreview: judul dipangkas 140, HTML mentah tidak ikut (hanya teks)', () => {
  const p = L.parsePreview('<meta property="og:title" content="' + 'a'.repeat(300) + '"><title>x</title>', 'https://a.com');
  assert.equal(p.t.length, 140);
  assert.equal(L.parsePreview('<meta property="og:title" content="&lt;img src=x onerror=alert(1)&gt;">', 'https://a.com').t, '<img src=x onerror=alert(1)>'); // tetap teks; UI memakai textContent
});
await t('fetchPreview: hasil + nama situs cadangan; http dicoba https dulu; gagal -> error', async () => {
  const seen = [];
  const r = await fetchPreview('http://contoh.com/a', async (u) => { seen.push(u); return u.startsWith('https') ? HTML : ''; });
  assert.deepEqual(seen, ['https://contoh.com/a']); assert.equal(r.t, 'Berita "Utama" & Lainnya'); assert.ok(r.at > 0);
  const r2 = await fetchPreview('https://contoh.com/x', async () => '<title>T</title>');
  assert.equal(r2.s, 'contoh.com');
  const seen2 = [];
  const r3 = await fetchPreview('http://lama.com/', async (u) => { seen2.push(u); if (u.startsWith('https')) throw new Error('tls'); return '<title>OK</title>'; });
  assert.deepEqual(seen2, ['https://lama.com/', 'http://lama.com/']); assert.equal(r3.t, 'OK');
  await assert.rejects(() => fetchPreview('https://mati.com/', async () => { throw new Error('offline'); }), /offline/);
});
await t('fetchPreview di aplikasi: memanggil CapacitorHttp.request lewat nativePromise (tanpa registerPlugin)', async () => {
  const calls = [];
  globalThis.Capacitor = { isNativePlatform: () => true, nativePromise: (p, m, o) => { calls.push([p, m, o]); return Promise.resolve({ status: 200, data: HTML }); } };
  const r = await fetchPreview('https://contoh.com/artikel');
  assert.equal(calls[0][0], 'CapacitorHttp'); assert.equal(calls[0][1], 'request');
  assert.equal(calls[0][2].url, 'https://contoh.com/artikel'); assert.equal(calls[0][2].responseType, 'text'); assert.ok(calls[0][2].headers['User-Agent']);
  assert.equal(r.i, 'https://contoh.com/img/a.jpg?x=1&y=2');
  globalThis.Capacitor = { isNativePlatform: () => true, nativePromise: () => Promise.resolve({ status: 403, data: 'x' }) };
  await assert.rejects(() => fetchPreview('https://contoh.com/blok'), /HTTP 403/);
  delete globalThis.Capacitor;
});
await t('openExternal: lewat KelimaaNative.openUrl, hanya http/https, cadangan window.open', () => {
  const got = [];
  assert.equal(openExternal('https://a.com', { KelimaaNative: { openUrl: (u) => got.push(u) } }), true); assert.deepEqual(got, ['https://a.com']);
  assert.equal(openExternal('javascript:alert(1)', { KelimaaNative: { openUrl: (u) => got.push(u) } }), false); assert.equal(got.length, 1);
  assert.equal(openExternal('https://b.com', { open: (u) => ({ u }) }), true);
  assert.equal(openExternal('https://b.com', {}), false);
});

// ---- Keluar total ----
await t('nativeExit: memanggil KelimaaNative.exit; false bila jembatan tidak ada atau error', () => {
  let called = 0;
  assert.equal(nativeExit({ KelimaaNative: { exit: () => { called++; } } }), true); assert.equal(called, 1);
  assert.equal(nativeExit({}), false);
  assert.equal(nativeExit({ KelimaaNative: {} }), false);
  assert.equal(nativeExit({ KelimaaNative: { exit: () => { throw new Error('x'); } } }), false);
});
await t('closeDialog: menekan Batal pada dialog paling atas; false bila tidak ada dialog', () => {
  const clicks = [];
  const mk = (id) => ({ querySelector: () => ({ click: () => clicks.push(id) }) });
  assert.equal(closeDialog({ querySelectorAll: () => [] }), false);
  assert.equal(closeDialog({ querySelectorAll: () => [mk('bawah'), mk('atas')] }), true);
  assert.deepEqual(clicks, ['atas']);
});

// ---- Kode native ----
await t('mainActivitySource: paket benar, jembatan exit + openUrl, hanya http/https, proses dimatikan', () => {
  const j = mainActivitySource('com.kelimaa.notes');
  assert.match(j, /^package com\.kelimaa\.notes;/);
  for (const k of ['extends BridgeActivity', '@JavascriptInterface', 'public void exit()', 'public void openUrl', '"KelimaaNative"', 'finishAndRemoveTask()', 'OnBackPressedCallback', '__kelimaaBack', 'closeAppTotal', 'killProcess', 'removeCallbacks(killTask)', 'System.exit(0)', '"https".equalsIgnoreCase']) assert.ok(j.includes(k), k);
  assert.equal((j.match(/\{/g) || []).length, (j.match(/\}/g) || []).length, 'kurung kurawal seimbang');
});
await t('ensureInternetPermission: menambah bila belum ada, tidak dobel bila sudah ada', () => {
  const m = '<manifest>\n    <application android:label="x">\n    </application>\n</manifest>';
  const a = ensureInternetPermission(m);
  assert.ok(a.includes('android.permission.INTERNET')); assert.ok(a.indexOf('INTERNET') < a.indexOf('<application'));
  assert.equal(ensureInternetPermission(a), a);
});

// ---- Rev 9: ruang aman dihitung native ----
await t('mainActivitySource Rev 9: inset native dikonsumsi, ime ikut, ada setBars dan cadangan', () => {
  const j = mainActivitySource('com.kelimaa.notes');
  for (const k of ['setDecorFitsSystemWindows(getWindow(), false)', 'Type.systemBars()', 'Type.displayCutout()', 'Type.ime()', 'WindowInsetsCompat.CONSUMED', 'v.setPadding(b.left, b.top, b.right, b.bottom)', 'public void setBars', 'setAppearanceLightStatusBars', 'UI_MODE_NIGHT_MASK', 'setDecorFitsSystemWindows(getWindow(), true)']) assert.ok(j.includes(k), k);
});
await t('ensureAdjustResize: menambah, mengganti, dan idempoten', () => {
  const m = '<manifest><application><activity android:name=".MainActivity" android:exported="true"></activity></application></manifest>';
  const a = ensureAdjustResize(m);
  assert.ok(a.includes('android:windowSoftInputMode="adjustResize"'));
  assert.equal(ensureAdjustResize(a), a);
  const b = ensureAdjustResize(m.replace('<activity', '<activity android:windowSoftInputMode="adjustPan"'));
  assert.ok(b.includes('adjustResize') && !b.includes('adjustPan'));
});
await t('CSS: tidak lagi memakai --safe-area-inset (hitungan ganda), config SystemBars disable', async () => {
  const { readFileSync } = await import('node:fs');
  const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
  assert.ok(!/var\(--safe-area-inset/.test(css), 'tidak boleh membaca --safe-area-inset-*');
  assert.ok(/--sat:env\(safe-area-inset-top,0px\)/.test(css));
  const cfg = JSON.parse(readFileSync(new URL('../capacitor.config.json', import.meta.url), 'utf8'));
  assert.equal(cfg.plugins.SystemBars.insetsHandling, 'disable');
});
await t('syncBars: mengirim warna latar + gelap/terang ke jembatan native; aman tanpa jembatan', async () => {
  const { syncBars } = await import('../src/js/native.js');
  syncBars(); // tanpa jembatan: tidak error
  let got = null;
  globalThis.KelimaaNative = { setBars: (c, d) => { got = [c, d]; } };
  globalThis.document = { body: {} };
  globalThis.getComputedStyle = () => ({ backgroundColor: 'rgb(11, 17, 32)' });
  syncBars(); assert.deepEqual(got, ['#0b1120', true]);
  globalThis.getComputedStyle = () => ({ backgroundColor: 'rgb(237, 242, 249)' });
  syncBars(); assert.deepEqual(got, ['#edf2f9', false]);
  delete globalThis.KelimaaNative; delete globalThis.document; delete globalThis.getComputedStyle;
});


// Rev 11: latar layar pembuka
{
  const { patchLaunchStyles, LAUNCH_COLOR_XML } = await import('../scripts/apply-native.mjs');
  const xml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.DayNight.DarkActionBar"></style>
    <style name="AppTheme.NoActionBar" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="windowActionBar">false</item>
        <item name="android:background">@null</item>
    </style>
    <style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">
        <item name="android:background">@drawable/splash</item>
    </style>
</resources>`;
  const a = patchLaunchStyles(xml), b = patchLaunchStyles(a);
  assert.ok(a.includes('@color/kelimaa_launch_bg') && !a.includes('@drawable/splash') && !a.includes('@null'), 'latar diganti');
  assert.equal((a.match(/windowSplashScreenBackground/g) || []).length, 1, 'atribut splash hanya di tema Splash');
  assert.equal(a, b, 'idempoten');
  assert.ok(a.includes('windowActionBar'), 'item lain tetap');
  assert.ok(LAUNCH_COLOR_XML.includes('#0B1120'));
  console.log('ok - patchLaunchStyles: latar pembuka navy, idempoten');
}

// ---- Rev 14: dialog keluar saat Kembali ----
await t('installBrowserBack: peramban memasang guard + popstate; aplikasi (jembatan) TIDAK memasang', () => {
  const mk = (extra = {}) => { const o = { pushed: 0, l: {}, history: { pushState() { o.pushed++; } }, addEventListener(e, f) { o.l[e] = f; }, ...extra }; return o; };
  const b = mk(); let back = 0;
  assert.equal(installBrowserBack(() => back++, b), true); assert.equal(b.pushed, 1);
  b.l.popstate(); assert.equal(back, 1); assert.equal(b.pushed, 2, 'guard dipasang ulang setelah Kembali');
  b.__kelimaaLeaving = true; b.l.popstate(); assert.equal(back, 1); assert.equal(b.pushed, 2, 'saat keluar tidak menjebak lagi');
  const a = mk({ KelimaaNative: {} });
  assert.equal(installBrowserBack(() => {}, a), false); assert.equal(a.pushed, 0);
  assert.equal(installBrowserBack(() => {}, { addEventListener() {}, history: { pushState() { throw new Error('x'); } } }), false);
});
await t('exitApp (peramban): simpan, window.close(), lalu about:blank; flag keluar menyala', async () => {
  const saved = []; let closed = 0, replaced = '';
  globalThis.document = { querySelector: () => null };
  const g = { close: () => closed++, location: { replace: (u) => { replaced = u; } } };
  exitApp({ persist: () => saved.push(1) }, g);
  assert.equal(saved.length, 1); assert.equal(closed, 1); assert.equal(g.__kelimaaLeaving, true);
  await new Promise((r) => setTimeout(r, 250)); assert.equal(replaced, 'about:blank');
  delete globalThis.document;
});
await t('main.js Rev 14: Kembali di layar utama tidak lagi membalas exit; onAndroidEvent meneruskan event lain', async () => {
  const { readFileSync } = await import('node:fs');
  const m = readFileSync(new URL('../src/js/main.js', import.meta.url), 'utf8');
  assert.ok(m.includes('askExitBack(ctx)') && !m.includes("return 'exit'"), 'dialog, bukan exit langsung');
  assert.ok(m.includes("event === 'backPressed'") && m.includes('prevAndroidEvent.apply'), 'onAndroidEvent + handler lama diteruskan');
  const e = readFileSync(new URL('../src/js/exit.js', import.meta.url), 'utf8');
  for (const k of ["role: 'dialog'", "'aria-modal': 'true'", "e.key === 'Escape'", 'bNo.focus()', "'Keluar dari aplikasi?'", 'img/logo-keluar.png']) assert.ok(e.includes(k), k);
  const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
  assert.ok(css.includes('.exitq') && /prefers-reduced-motion:reduce\)\{\.exitq/.test(css), 'animasi + reduced-motion');
});
console.log(n + ' tes fitur lulus');
