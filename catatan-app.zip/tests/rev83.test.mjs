import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { localDateISO, isValidDateISO, formatDateID } from '../src/js/tanggal.js';
import { parseNoteHtml } from '../src/js/export.js';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

test('Rev 83: tanggal lokal memakai komponen kalender perangkat dan format Indonesia', () => {
  assert.equal(localDateISO(new Date(2026, 10, 7, 23, 59)), '2026-11-07');
  assert.equal(isValidDateISO('2024-02-29'), true);
  assert.equal(isValidDateISO('2025-02-29'), false);
  assert.equal(isValidDateISO('2026-13-01'), false);
  assert.equal(formatDateID('2026-11-07'), '7 November 2026');
  assert.equal(formatDateID('2026-02-31'), '');
});

test('Rev 83: bilah Langit memiliki tombol Tanggal dan jalur handler tersambung', () => {
  const notes = read('../src/js/notes.js');
  assert.match(notes, /insertBtn\('date', 'Tanggal'\)/);
  assert.match(notes, /kind === 'date'\) insertDate\(\)/);
  assert.match(notes, /className = 'kb-date-block'/);
  assert.match(notes, /registerBlock\(\{ type: 'date', selector: '\.kb-date-block'/);
});

test('Rev 83: parser ekspor merangkum blok Tanggal sebagai teks biasa', () => {
  const blocks = parseNoteHtml('<div class="kb-date-block" contenteditable="false" data-kb-date="2026-11-07"><span class="kb-date-value">7 November 2026</span></div><p>Catatan</p>');
  assert.equal(blocks[0].kind, 'p');
  assert.equal(blocks[0].runs.map((r) => r.t).join(''), 'Tanggal: 7 November 2026');
  assert.equal(blocks[1].runs.map((r) => r.t).join(''), 'Catatan');
});

test('Rev 83: sanitizer mengizinkan hanya atribut tanggal valid dan tidak mengubah SCHEMA/native', () => {
  const notes = read('../src/js/notes.js');
  const storage = read('../src/js/storage.js');
  const pkg = JSON.parse(read('../package.json'));
  assert.match(notes, /kb-date-block/);
  assert.match(notes, /k === 'data-kb-date' && isValidDateISO\(v\)/);
  assert.match(storage, /SCHEMA\s*=\s*22/);
  assert.equal(pkg.version, '0.3.121');
  assert.doesNotMatch(notes, /registerPlugin\(|Capacitor\.Plugins/);
});
