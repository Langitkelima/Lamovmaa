// Rev 287 / T2: kelompok templat "Fitur" (Tur lengkap, Warna bersyarat, Dropdown status, Diagram, Filter dan isi seri) + anggaran JS dinaikkan atas izin.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { chartList } from '../src/js/lembar-grafik.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN);
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 14, 12, 0, 0).getTime();
const IDS = ['fitur-tur', 'fitur-warna', 'fitur-dropdown', 'fitur-diagram', 'fitur-filter'];
const mk = (id) => T.makeFromTemplate(id, { now: NOW });
test('Rev 287: lima templat Fitur ada, nama <= 30, keterangan, tab Panduan terakhir, failed 0, muat batas, tanpa galat rumus', () => {
  const ids = T.templateList().map((t) => t.id); for (const id of IDS) assert.ok(ids.includes(id), id); assert.equal(new Set(ids).size, ids.length);
  for (const id of IDS) {
    const t = T.templateList().find((x) => x.id === id); assert.ok(t.name.startsWith('Fitur · ') && t.name.length <= 30 && t.desc.length >= 20 && t.desc.length <= 100, id);
    const r = mk(id); assert.ok(r, id); assert.equal(r.failed, 0, id); assert.ok(L.fitsLimit(r.sheet)); const tabs = r.sheet.tabs;
    assert.equal(tabs[tabs.length - 1].name, 'Panduan', id); assert.ok(tabs.length <= 5);
    for (const tab of tabs) { const d = makeDisplay(tab); for (let i = 0; i < tab.rows.length; i++) for (let j = 0; j < tab.cols.length; j++) assert.doesNotMatch(String(d.text(i, j)), /^#/, id + ' ' + L.cellAddr(j, i)); }
    const c = L.cleanSheet(JSON.parse(JSON.stringify(r.sheet))); assert.equal((c.tabs[0].rules || []).length, (tabs[0].rules || []).length, id); assert.equal((c.tabs[0].checks || []).length, (tabs[0].checks || []).length, id); assert.equal(chartList(c.tabs[0]).length, chartList(tabs[0]).length, id);
  }
});
test('Rev 287: tiap fitur benar-benar terpasang (aturan, dropdown, diagram, seri, rumus)', () => {
  let tab = mk('fitur-tur').sheet.tabs[0], d = makeDisplay(tab);
  assert.equal(tab.rules.length, 3); assert.equal(tab.checks.length, 2); assert.deepEqual(chartList(tab).map((c) => c.kind), ['column', 'donut']);

  const tot = [2, 3, 4, 5].reduce((a, i) => a + d.raw(i - 1, 7), 0); assert.equal(d.raw(5, 7), tot); assert.equal(tot, 695000);
  assert.deepEqual(Array.from({ length: 10 }, (_, i) => d.raw(i + 1, 0)), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
  assert.equal(d.raw(10, 1) - d.raw(1, 1), 9); // tanggal berurutan
  tab = mk('fitur-warna').sheet.tabs[0]; assert.equal(tab.rules.length, 7); assert.ok(tab.rules.some((r) => r.op === 'scale') && tab.rules.some((r) => r.op === 'eq' && r.a === 'Lunas'));
  tab = mk('fitur-dropdown').sheet.tabs[0]; assert.equal(tab.checks.length, 5); assert.deepEqual(tab.checks.map((c) => c.k), ['list', 'list', 'date', 'email', 'num']); assert.equal(tab.checks[0].cl.Selesai.bg, '#DCFCE7');
  tab = mk('fitur-diagram').sheet.tabs[0]; d = makeDisplay(tab); assert.deepEqual(chartList(tab).map((c) => c.kind), ['column', 'bar', 'donut']); assert.equal(d.raw(5, 4), 8500000 + 4200000 + 6100000 + 3900000); assert.ok(Math.abs(d.raw(5, 7) - 1) < 1e-9);
  tab = mk('fitur-filter').sheet.tabs[0]; d = makeDisplay(tab); assert.equal(tab.rows.length, 41); assert.equal(d.raw(40, 0), 40); assert.equal(d.raw(2, 8), 40); assert.equal(d.raw(3, 8), 12); assert.equal(tab.checks.length, 2);
  assert.ok(Array.from({ length: 40 }, (_, i) => d.text(i + 1, 5)).filter((x) => x === '').length === 5); // 5 baris Status kosong untuk filter Kosong
});
test('Rev 287: modul data murni; fungsi rumus hanya yang ada; 12 templat lama tetap di depan; anggaran dinaikkan atas izin', () => {
  const s = src('src/js/templat-fitur.js'); assert.doesNotMatch(s, /import |localStorage|document\.|window\.|eval\(|new Function/);
  const used = new Set([...s.matchAll(/'(=[^']*)'|"(=[^"]*)"/g)].flatMap((m) => [...(m[1] || m[2]).matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1]))); for (const f of used) assert.ok(['SUM', 'SUMIF', 'COUNTA', 'COUNTIF'].includes(f), f);
  assert.deepEqual(T.templateList().slice(-10, -6).map((t) => t.id), ['anggaran', 'bagi', 'jadwal', 'nilai']); assert.equal(T.templateList().length, 35);
  const a = src('tools/audit-ukuran.mjs'); assert.match(a, /jsMaks: 1600 \* 1024/); assert.match(a, /totalMaks: 2100 \* 1024/);
  for (const f of ['settings', 'lembar', 'lembar-ui', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /templat-fitur/, f);
});
