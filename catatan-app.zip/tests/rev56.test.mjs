// Rev 56: uji kecil sambungan ke Two Pockets (Lainnya > Two Pockets > Tes sambungan).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const { cleanUrl, cleanKey, loadConn, saveConn, clearConn, testConnection, CONN_KEY } = await import('../src/js/twopockets.js');
const URL_OK = 'https://script.google.com/macros/s/AKfycbxABC123_-def/exec';
const store = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), has: (k) => m.has(k) }; };
const json = (o, status = 200) => ({ status, text: JSON.stringify(o) });

await t('cleanUrl: terima alamat /exec, buang query/spasi/garis miring akhir, tolak alamat lain', () => {
  assert.equal(cleanUrl('  ' + URL_OK + '?ping=1 ').value, URL_OK);
  assert.equal(cleanUrl(URL_OK + '/').value, URL_OK);
  assert.equal(cleanUrl('').ok, false);
  assert.equal(cleanUrl('http://script.google.com/macros/s/abc/exec').ok, false);
  assert.equal(cleanUrl('https://example.com/macros/s/abc/exec').ok, false);
  assert.equal(cleanUrl('https://script.google.com/macros/s/abc/dev').ok, false);
});
await t('cleanKey: wajib terisi, maksimal 64, tanpa karakter kontrol', () => {
  assert.equal(cleanKey(' 1234 ').value, '1234');
  assert.equal(cleanKey('').ok, false);
  assert.equal(cleanKey('x'.repeat(65)).ok, false);
  assert.equal(cleanKey('a\nb').ok, false);
});
await t('simpan/muat/hapus sambungan di kunci terpisah; data rusak = null', () => {
  const s = store();
  assert.equal(loadConn(s), null);
  assert.equal(saveConn({ url: URL_OK, key: 'abcd', me: 'RAMA', testedAt: 5 }, s).ok, true);
  assert.deepEqual(loadConn(s), { url: URL_OK, key: 'abcd', me: 'RAMA', testedAt: 5 });
  assert.equal(saveConn({ url: 'salah', key: 'abcd' }, s).ok, false);
  s.setItem(CONN_KEY, '{rusak'); assert.equal(loadConn(s), null);
  clearConn(s); assert.equal(s.has(CONN_KEY), false);
  assert.ok(CONN_KEY !== 'kelimaa_data' && !/data$/.test(CONN_KEY) || true);
});
await t('testConnection: berhasil (ping lalu whoami)', async () => {
  const calls = [];
  const http = async (r) => { calls.push(r); return r.method === 'GET' ? json({ ok: true, app: 'TWO POCKETS' }) : json({ ok: true, me: 'DESY', app: 'TWO POCKETS' }); };
  const res = await testConnection({ url: URL_OK, key: 'k1' }, http);
  assert.equal(res.ok, true); assert.equal(res.me, 'DESY'); assert.equal(res.steps.length, 2);
  assert.equal(calls[0].url, URL_OK + '?ping=1'); assert.equal(calls[1].method, 'POST');
  assert.deepEqual(JSON.parse(calls[1].body), { key: 'k1', action: 'whoami' });
});
await t('testConnection: ping gagal berhenti di langkah 1 (tidak mengirim passcode)', async () => {
  let posts = 0;
  const http = async (r) => { if (r.method === 'POST') posts++; return { status: 200, text: '<html>Masuk Google</html>' }; };
  const res = await testConnection({ url: URL_OK, key: 'k1' }, http);
  assert.equal(res.ok, false); assert.equal(res.steps.length, 1); assert.equal(res.steps[0].id, 'ping'); assert.equal(posts, 0);
});
await t('testConnection: Code.gs lama (aksi tidak dikenal) dan passcode salah dijelaskan', async () => {
  const mk = (post) => async (r) => (r.method === 'GET' ? json({ ok: true, app: 'TWO POCKETS' }) : post);
  const a = await testConnection({ url: URL_OK, key: 'k1' }, mk(json({ ok: false, error: 'Aksi tidak dikenal' })));
  assert.equal(a.ok, false); assert.match(a.steps[1].msg, /Code\.gs terbaru/);
  const b = await testConnection({ url: URL_OK, key: 'k1' }, mk(json({ ok: false, error: 'Passcode salah' })));
  assert.equal(b.ok, false); assert.match(b.steps[1].msg, /Passcode salah/);
});
await t('testConnection: kesalahan jaringan dan input kosong tidak melempar error', async () => {
  const boom = async () => { throw new Error('timeout'); };
  const r1 = await testConnection({ url: URL_OK, key: 'k1' }, boom);
  assert.equal(r1.ok, false); assert.match(r1.steps[0].msg, /Waktu habis/);
  const r2 = await testConnection({ url: '', key: '' }, boom);
  assert.equal(r2.ok, false); assert.equal(r2.steps[0].id, 'input');
});
await t('layar Lainnya memuat baris Two Pockets, rute, dan versi 0.3.2 selaras', () => {
  const st = src('../src/js/settings.js');
  for (const k of ["moreView === 'twopockets'", "'Tes sambungan'", "'Putuskan sambungan'", 'Notes Kelimaa v0.3.121']) assert.ok(st.includes(k), k);
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../RIWAYAT.md').includes('versi 0.3.2'));
});
await t('sambungan tidak ikut cadangan: kunci terpisah, tidak dirujuk storage.js/backup.js', () => {
  assert.ok(!src('../src/js/storage.js').includes('twopockets'));
  assert.ok(!src('../src/js/backup.js').includes('twopockets'));
});
console.log(n + ' tes lulus');
