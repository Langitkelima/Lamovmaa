// Rev 102 / U5b: SCHEMA 10 (note.cbRem / note.cdRem), modul glue cb-alarm.js, kotak masuk notifikasi cb/cd, sambungan hapus/Sampah/cadangan/salin. Tanpa UI baru.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as S from '../src/js/storage.js';
import * as I from '../src/js/ingatkan.js';
import * as C from '../src/js/cb-alarm.js';
import * as R from '../src/js/reminders.js';
import { duplicateNote } from '../src/js/logic.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const L = (y, m, d, h = 0, mi = 0) => new Date(y, m - 1, d, h, mi, 0, 0).getTime();
const NOW = L(2026, 11, 8, 10);
const row = (cid, text, done = false) => `<div class="todo"${cid ? ` data-cid="${cid}"` : ''}><input type="checkbox"${done ? ' checked=""' : ''}>${text}</div>`;
const cdBlock = (bid, date, time = '', title = 'Ulang tahun') => `<div class="kb-countdown-block" data-kb-id="${bid}" data-kb-date="${date}"${time ? ` data-kb-time="${time}"` : ''} data-kb-title="${title}" contenteditable="false"></div>`;
// jembatan native palsu: merekam semua panggilan
function fakeApi(over = {}) {
  const calls = { sched: [], cancel: [] };
  globalThis.AndroidAPI = { scheduleNotification: (id, t, m, d, r) => { calls.sched.push({ id, t, m, d, r }); return over.result || 'exact_alarm'; }, cancelScheduledNotification: (id) => { calls.cancel.push(id); }, requestNotificationPermission: () => {}, ...over.extra };
  return calls;
}
const noApi = () => { delete globalThis.AndroidAPI; delete globalThis.KelimaaNative; };

test('Rev 102: SCHEMA 10; data lama tanpa cbRem/cdRem tetap valid dan tidak diberi field baru', () => {
  assert.equal(S.SCHEMA, 22);
  const d = S.normalize({ version: 9, tasks: [], habits: [], priv: [], trash: [], notes: [{ id: 'n1', title: 'a', html: row('', 'x') }] });
  assert.ok(d); assert.equal('cbRem' in d.notes[0], false); assert.equal('cdRem' in d.notes[0], false);
  assert.equal(S.exportJSON(d).includes('"version": 22'), true);
});
test('Rev 102: normalize memangkas cbRem ke cid yang ada di HTML (maks. 30) dan membuang aturan rusak', () => {
  const html = row('ab12c', 'beli susu') + row('zz99z', 'telepon');
  const d = S.normalize({ tasks: [], habits: [], priv: [], trash: [], notes: [{ id: 'n1', html, cbRem: { ab12c: { at: 5, repeat: 'daily', sticky: true }, hilang1: { at: 5 }, zz99z: { at: 'x' }, 'BAD!': { at: 5 } } }] });
  assert.deepEqual(d.notes[0].cbRem, { ab12c: { at: 5, repeat: 'daily', sticky: false } });
  const many = {}; let h = ''; for (let i = 0; i < 40; i++) { const c = 'c' + String(1000 + i); many[c] = { at: 5 }; h += row(c, 'x' + i); }
  assert.equal(Object.keys(S.normalize({ tasks: [], habits: [], priv: [], trash: [], notes: [{ id: 'n', html: h, cbRem: many }] }).notes[0].cbRem).length, 30);
});
test('Rev 102: normalize memangkas cdRem ke bid yang ada (maks. 10 kartu x 4); cbRem/cdRem kosong dihapus; Privat tidak pernah punya', () => {
  const html = cdBlock('Bk1', '2026-12-25') + cdBlock('Bk2', '2026-12-26');
  const d = S.normalize({ tasks: [], habits: [], trash: [], notes: [{ id: 'n1', html, cdRem: { Bk1: [7, 0, 3, 3, 99], Gone: [1], Bk2: 'x' } }, { id: 'n2', html: '', cbRem: {}, cdRem: {} }], priv: [{ id: 'p1', html: row('ab12c', 'rahasia') + cdBlock('Bk1', '2026-12-25'), cbRem: { ab12c: { at: 5 } }, cdRem: { Bk1: [0] } }] });
  assert.deepEqual(d.notes[0].cdRem, { Bk1: [0, 3, 7] });
  assert.equal('cbRem' in d.notes[1] || 'cdRem' in d.notes[1], false);
  assert.equal('cbRem' in d.priv[0] || 'cdRem' in d.priv[0], false);
});
test('Rev 102: catatan di Tempat sampah ikut dipangkas (agar Pulihkan benar); cadangan JSON bolak-balik utuh', () => {
  const n = { id: 'n1', title: 't', html: row('ab12c', 'x'), cbRem: { ab12c: { at: 99, repeat: 'weekly' }, nope1: { at: 9 } } };
  const d = S.normalize({ tasks: [], habits: [], priv: [], notes: [], trash: [{ kind: 'note', item: n, at: 1 }] });
  assert.deepEqual(d.trash[0].item.cbRem, { ab12c: { at: 99, repeat: 'weekly', sticky: false } });
  const back = S.importJSON(S.exportJSON(d)); assert.ok(back.ok);
  assert.deepEqual(back.data.trash[0].item.cbRem, d.trash[0].item.cbRem);
});
test('Rev 102: helper HTML (rowsFromHtml / blocksFromHtml / bidsInHtml / cleanNoteRem)', () => {
  const h = row('ab12c', 'Beli <b>susu</b>&nbsp;&amp; roti', true) + row('ab12c', 'kembar') + row('', 'tanpa cid') + cdBlock('Xy9', '2026-12-25', '08:30', 'Natal');
  assert.deepEqual(I.rowsFromHtml(h), { ab12c: { text: 'Beli susu & roti', done: true } });
  assert.deepEqual(I.blocksFromHtml(h), { Xy9: { date: '2026-12-25', time: '08:30', title: 'Natal' } });
  assert.deepEqual(I.bidsInHtml(h), ['Xy9']);
  assert.deepEqual(I.cleanNoteRem({ html: h, cbRem: { ab12c: { at: 5 }, x1x1x: { at: 5 } }, cdRem: { Xy9: [0], Q: [0] } }), { cbRem: { ab12c: { at: 5, repeat: 'none', sticky: false } }, cdRem: { Xy9: [0] } });
});
test('Rev 102: syncNoteAlarms menjadwalkan kotak centang + hitung mundur lewat jembatan; pesan dari teks baris; Bulanan = 12 alarm', () => {
  const calls = fakeApi();
  const note = { id: 'n1', title: 'Belanja', html: row('ab12c', 'Beli susu') + row('mn345', 'Bayar listrik') + cdBlock('Bk1', '2026-11-20', '09:00', 'Ulang tahun'),
    cbRem: { ab12c: { at: L(2026, 11, 9, 9), repeat: 'none' }, mn345: { at: L(2026, 11, 10, 8), repeat: 'monthly' } }, cdRem: { Bk1: [0, 1] } };
  const res = C.syncNoteAlarms(note, NOW);
  assert.ok(res.every((r) => r.ok));
  const ids = calls.sched.map((c) => c.id);
  assert.ok(ids.includes('cb:n1:ab12c')); assert.equal(ids.filter((i) => i.startsWith('cb:n1:mn345:m')).length, 12);
  assert.ok(ids.includes('cd:n1:Bk1:0') && ids.includes('cd:n1:Bk1:1'));
  const one = calls.sched.find((c) => c.id === 'cb:n1:ab12c'); assert.equal(one.t, 'Belanja'); assert.equal(one.m, 'Beli susu'); assert.equal(one.d, L(2026, 11, 9, 9) - NOW); assert.equal(one.r, 0);
  assert.equal(calls.sched.find((c) => c.id === 'cd:n1:Bk1:1').m, 'Ulang tahun: 1 hari lagi.');
  // semua kemungkinan ID dibatalkan dulu (supaya bulan basi tidak tertinggal)
  assert.ok(calls.cancel.includes('cb:n1:mn345:m12') && calls.cancel.includes('cd:n1:Bk1:7') && calls.cancel.includes('cb:n1:ab12c'));
  noApi();
});
test('Rev 102: baris dicentang = pengingat sekali dilewati; Harian = satu alarm berulang 1 hari', () => {
  const calls = fakeApi();
  const note = { id: 'n1', title: 'T', html: row('ab12c', 'a', true) + row('dd111', 'b'), cbRem: { ab12c: { at: L(2026, 11, 9, 9), repeat: 'none' }, dd111: { at: L(2026, 11, 9, 7), repeat: 'daily' } } };
  C.syncNoteAlarms(note, NOW);
  assert.deepEqual(calls.sched.map((c) => c.id), ['cb:n1:dd111']); assert.equal(calls.sched[0].r, I.DAY_MS);
  noApi();
});
test('Rev 102: cancelNoteAlarms membatalkan semua ID (hapus catatan); tanpa jembatan native tidak error', () => {
  const calls = fakeApi();
  const note = { id: 'n1', html: '', cbRem: { ab12c: { at: 1 } }, cdRem: { Bk1: [0] } };
  C.cancelNoteAlarms(note);
  assert.equal(calls.cancel.length, 13 + 4); assert.ok(calls.cancel.includes('cb:n1:ab12c:m1') && calls.cancel.includes('cd:n1:Bk1:3'));
  noApi();
  assert.doesNotThrow(() => C.cancelNoteAlarms(note));
  const r = C.syncNoteAlarms({ id: 'n1', title: 't', html: row('ab12c', 'x'), cbRem: { ab12c: { at: L(2026, 11, 9, 9) } } }, NOW);
  assert.deepEqual(r, [{ ok: false, reason: 'unavailable' }]);
  assert.deepEqual(C.syncNoteAlarms(null), []); assert.deepEqual(C.syncNoteAlarms({ id: 'n2', html: '' }, NOW), []);
});
test('Rev 102: izin ditolak / alarm tidak tepat / error native dilaporkan', () => {
  fakeApi({ result: 'inexact_alarm' }); const n = { id: 'n1', title: 't', html: row('ab12c', 'x'), cbRem: { ab12c: { at: L(2026, 11, 9, 9) } } };
  assert.deepEqual(C.syncNoteAlarms(n, NOW), [{ ok: true, warning: 'inexact_alarm' }]);
  fakeApi({ result: 'permission_denied' }); assert.deepEqual(C.syncNoteAlarms(n, NOW), [{ ok: false, reason: 'permission' }]);
  fakeApi({ result: 'error' }); assert.deepEqual(C.syncNoteAlarms(n, NOW), [{ ok: false, reason: 'native_error' }]);
  noApi();
});
test('Rev 102: reconcileNoteAlarms: baris/kartu yang dihapus dari isi dipangkas dan alarmnya dibatalkan; sisanya dijadwalkan ulang', () => {
  const calls = fakeApi();
  const note = { id: 'n1', title: 'T', html: row('ab12c', 'tinggal ini'), cbRem: { ab12c: { at: L(2026, 11, 9, 9), repeat: 'none' }, gone1: { at: L(2026, 11, 9, 9), repeat: 'weekly' } }, cdRem: { Bk1: [0] } };
  const r = C.reconcileNoteAlarms(note, NOW);
  assert.equal(r.pruned, true); assert.deepEqual(Object.keys(note.cbRem), ['ab12c']); assert.equal('cdRem' in note, false);
  assert.ok(calls.cancel.includes('cb:n1:gone1') && calls.cancel.includes('cd:n1:Bk1:0'));
  assert.deepEqual(calls.sched.map((c) => c.id), ['cb:n1:ab12c']);
  const again = C.reconcileNoteAlarms(note, NOW); assert.equal(again.pruned, false);
  noApi();
});
test('Rev 102: syncAllNoteAlarms hanya catatan biasa berpengingat; Privat tidak disentuh', () => {
  const calls = fakeApi();
  const data = { notes: [{ id: 'a', title: 'A', html: row('ab12c', 'x'), cbRem: { ab12c: { at: L(2026, 11, 9, 9) } } }, { id: 'b', title: 'B', html: '' }], priv: [{ id: 'p', title: 'Rahasia', html: row('ab12c', 'x'), cbRem: { ab12c: { at: L(2026, 11, 9, 9) } } }] };
  C.syncAllNoteAlarms(data, NOW);
  assert.deepEqual(calls.sched.map((c) => c.id), ['cb:a:ab12c']);
  noApi();
});
test('Rev 102: kotak masuk notifikasi: cb:/cd: membuka catatan biasa; Privat/tidak dikenal tidak membuka apa pun', () => {
  const data = { tasks: [], notes: [{ id: 'n1' }] }; const opened = [];
  globalThis.AndroidAPI = { takeReminder: () => globalThis.__next || '' };
  const ctx = { data };
  globalThis.__next = ''; const pull = R.installReminderInbox(ctx, () => {}, (it) => opened.push(it.id), () => {});
  globalThis.__next = 'cb:n1:ab12c'; assert.equal(pull(), true);
  globalThis.__next = 'cb:n1:ab12c:m7'; assert.equal(pull(), true);
  globalThis.__next = 'cd:n1:Bk1:3'; assert.equal(pull(), true);
  globalThis.__next = 'cb:zzz:ab12c'; assert.equal(pull(), false); // catatan sudah tidak ada
  globalThis.__next = 'cb:n1:BAD!'; assert.equal(pull(), false);
  globalThis.__next = 'cd:n1:Bk1:5'; assert.equal(pull(), false); // beforeDays tidak sah
  assert.deepEqual(opened, ['n1', 'n1', 'n1']);
  delete globalThis.AndroidAPI; delete globalThis.__next;
});
test('Rev 102: salin catatan TIDAK menyalin cbRem/cdRem (tidak ada notifikasi ganda)', () => {
  const copy = duplicateNote({ id: 'n1', title: 'A', html: row('ab12c', 'x'), cbRem: { ab12c: { at: 5 } }, cdRem: { Bk1: [0] }, reminder: { at: 5, repeat: 'once' } }, { id: 'n2' });
  assert.equal('cbRem' in copy, false); assert.equal('cdRem' in copy, false); assert.equal('reminder' in copy, false);
  assert.equal(copy.html, row('ab12c', 'x'));
});
test('Rev 102: kabel kode: sanitize data-cid, simpan, hapus (tunggal+massal+Urungkan), Sampah, cadangan, main', () => {
  const notes = src('src/js/notes.js'), settings = src('src/js/settings.js'), main = src('src/js/main.js');
  assert.match(notes, /k === 'data-cid' && CID_RE\.test\(v\) && \(\(c\.tagName === 'DIV' && c\.classList\.contains\('todo'\)\)/); // Rev 347 / R2: li ikut
  assert.match(notes, /cid kembar[\s\S]{0,700}newCid\(/);
  assert.match(notes, /function removeNote\(ctx, n\) \{\n  cancelReminder\('note', n\.id\);\n  cancelNoteAlarms\(n\);/);
  assert.match(notes, /cancelReminder\('note', r\.n\.id\); cancelNoteAlarms\(r\.n\);/);
  assert.equal((notes.match(/syncNoteAlarms\(/g) || []).length >= 2, true); // Urungkan tunggal + massal
  assert.match(notes, /reconcileNoteAlarms\(n\)/);
  assert.match(settings, /syncNoteAlarms\(restored\)/); assert.match(settings, /syncAllReminders\(ctx\.data\); syncAllNoteAlarms\(ctx\.data\);/);
  assert.ok(settings.indexOf('cancelAllReminders(); replaceData') > 0, 'Pulihkan cadangan tetap membatalkan semua alarm dulu');
  assert.equal((main.match(/syncAllNoteAlarms\(data\)/g) || []).length, 2);
});
test('Rev 102: tanpa UI baru, native/dependensi tidak berubah; versi 0.3.121 (Rev 103), SCHEMA 10; modul glue tidak memuat DOM', () => {
  const g = src('src/js/cb-alarm.js').replace(/\/\/.*$/gm, '');
  assert.ok(!/document\.|window\.|localStorage|Intl\./.test(g));
  // Rev 103 / U5c: lembar + lonceng kini ada (dites di rev103.test.mjs); modul glue tetap tanpa DOM.
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('node tests/rev102.test.mjs'));
});
