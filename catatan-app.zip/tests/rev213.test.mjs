// Rev 213a: jalur OTOMATIS pindah ke jalur lain bila jalur utama gagal; jalur yang dipilih eksplisit TIDAK pindah. Fetch PALSU, tanpa jaringan/kunci asli.
import test from 'node:test'; import assert from 'node:assert/strict';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t;
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), SAKELAR_KEY: 'sk-FAKE-0123456789', GEMINI_KEY: 'AIza-FAKE-0123456789', RETRY_MS: [0, 0], ...x });
const NOW = Date.UTC(2026, 10, 12, 5, 0, 0);
const post = (b) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify(b) });
const req = (o = {}) => ({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', limit: 5, messages: [{ role: 'user', content: 'Halo' }], ...o });
const res = (status, o) => ({ ok: status < 400, status, json: async () => o });
const good = (t = 'Halo juga!') => res(200, { choices: [{ message: { content: t } }], usage: { prompt_tokens: 3, completion_tokens: 2 } });
async function run(env, b, seq) {
  const calls = []; const orig = globalThis.fetch;
  globalThis.fetch = async (url, init) => { const host = new URL(url).host; calls.push(host + '|' + JSON.parse(init.body).model); return seq(host, calls.length); };
  try { const r = await T.handle(post(b), env, NOW); return { status: r.status, j: await r.json(), calls, env }; } finally { globalThis.fetch = orig; }
}
const SAK = 'api.sakelar.web.id', GEM = 'generativelanguage.googleapis.com';

test('Otomatis: Sakelar gagal (402) -> otomatis ke Gemini, melapor jalur asal, jatah dihitung SEKALI', async () => {
  const r = await run(env0(), req(), (h) => (h === SAK ? res(402, { error: { message: 'saldo habis' } }) : good()));
  assert.equal(r.j.ok, true); assert.equal(r.j.provider, 'gemini'); assert.equal(r.j.fallbackProvider, 'sakelar'); assert.deepEqual(r.j.tried, ['sakelar']);
  assert.equal(r.j.model, 'gemini-3.5-flash'); assert.equal(r.j.used, 1); assert.equal(r.j.limit, 5);
  assert.equal(r.calls[0], SAK + '|deepseek/deepseek-v4-flash');
});
test('Otomatis: jalur utama berhasil -> tidak ada panggilan kedua dan tidak ada fallbackProvider', async () => {
  const r = await run(env0(), req(), () => good());
  assert.equal(r.j.ok, true); assert.equal(r.j.provider, 'sakelar'); assert.equal(r.calls.length, 1); assert.equal(r.j.fallbackProvider, undefined);
});
test('Jalur dipilih eksplisit (sakelar): gagal = galat, TIDAK pindah ke Gemini', async () => {
  const r = await run(env0(), req({ provider: 'sakelar' }), (h) => (h === SAK ? res(402, {}) : good()));
  assert.equal(r.j.ok, false); assert.equal(r.status, 502); assert.ok(r.calls.every((c) => c.startsWith(SAK)));
});
test('Model dari aplikasi hanya untuk jalur utama; jalur cadangan memakai modelnya sendiri', async () => {
  const r = await run(env0(), req({ model: 'anthropic/haiku-5.5' }), (h) => (h === SAK ? res(404, {}) : good()));
  assert.equal(r.calls[0], SAK + '|anthropic/haiku-5.5'); assert.equal(r.calls[r.calls.length - 1], GEM + '|gemini-3.5-flash'); assert.equal(r.j.ok, true);
});
test('Relay tanpa model dilewati sebagai cadangan (tidak mengarang nama model)', async () => {
  const r = await run(env0({ RELAY_KEY: 'rk-FAKE-0123456789' }), req(), (h) => (h === SAK ? res(401, {}) : good()));
  assert.ok(!r.calls.some((c) => c.includes('relayrouter'))); assert.equal(r.j.provider, 'gemini'); assert.deepEqual(r.j.tried, ['sakelar']);
});
test('Semua jalur gagal: galat jalur utama + catatan cadangan juga gagal, kode dari jalur utama, jatah tetap 1', async () => {
  const r = await run(env0(), req(), (h) => (h === SAK ? res(401, {}) : res(402, {})));
  assert.equal(r.j.ok, false); assert.equal(r.status, 502); assert.match(r.j.error, /SAKELAR_KEY/); assert.match(r.j.error, /Jalur cadangan \(Gemini Google\) juga gagal/);
  assert.equal(r.env.KV.m.get('use:rama:2026-11-12'), '1');
});
test('Jawaban kosong dari jalur utama juga memicu jalur cadangan', async () => {
  const r = await run(env0(), req(), (h) => (h === SAK ? res(200, { choices: [{ message: { content: '' }, finish_reason: 'length' }] }) : good('dari Gemini')));
  assert.equal(r.j.ok, true); assert.equal(r.j.text, 'dari Gemini'); assert.equal(r.j.fallbackProvider, 'sakelar');
});
test('Batas harian tercapai: tidak ada panggilan ke penyedia sama sekali', async () => {
  const e = env0(); e.KV.m.set('use:rama:2026-11-12', '5');
  const r = await run(e, req(), () => good());
  assert.equal(r.status, 429); assert.equal(r.calls.length, 0);
});
test('Rev 213a hanya Worker; versi mengikuti revisi terbaru dan tes terdaftar', async () => {
  const { readFileSync } = await import('node:fs'); const pk = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev213\.test\.mjs/);
});
