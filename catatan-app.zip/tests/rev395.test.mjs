// Rev 395 / CHECKPOINT Paket Markdown + Kartu Bagikan, DOKUMEN SAJA. Kode aplikasi tidak berubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('banner Rev 395 paling atas (di atas Rev 394), BELUM ADA KODE, keputusan Privat dan roda warna', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) {
    const d = rd(f); assert.ok(/^\*\*Rev (?:39\d|4[0-3]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 395 /') < d.indexOf('**Rev 394 /'), f);
    const b = d.slice(d.indexOf('**Rev 395 /'), d.indexOf('**Rev 394 /')); for (const k of ['PART M1-M4', 'K1-K4', 'BELUM ADA KODE', 'BERFUNGSI-BELUM-DIUJI', 'Catatan Privat', 'ROA WARNA']) assert.ok(b.includes(k), f + ' ' + k);
  }
});
test('bagian 39 ada dengan M1-M4, K1-K4, D-M1 sampai D-M3', () => {
  const d = rd('PROMPT_SERAH_TERIMA.md'); const s = d.slice(d.indexOf('## 39. PAKET EKSPOR/IMPOR MARKDOWN'));
  assert.ok(s.length > 500); for (const k of ['**M1:**', '**M2:**', '**M3:**', '**M4:**', '**K1:**', '**K2:**', '**K3:**', '**K4:**', 'D-M1', 'D-M2', 'D-M3']) assert.ok(s.includes(k), k);
});
test('kode TIDAK berubah: SCHEMA 22, versi 0.3.121; tes terdaftar sesudah rev394', () => {
  assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/); assert.equal(JSON.parse(rd('package.json')).version, '0.3.121');
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.indexOf('rev394.test.mjs') < t.indexOf('rev395.test.mjs'));
});
