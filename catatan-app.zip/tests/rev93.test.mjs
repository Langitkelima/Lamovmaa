import assert from 'node:assert/strict';
import { test } from 'node:test';
import fs from 'node:fs';
const src = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const css = src('src/css/styles.css'), main = src('src/js/main.js'), notes = src('src/js/notes.js');
test('Rev 93: .sw hanya milik kartu catatan; sakelar memakai .tgl', () => {
  assert.ok(notes.includes("class: 'sw'"));
  assert.ok(!main.includes("class: 'sw'"));
  assert.ok(css.includes('.tgl{width:54px') && !/\n\.sw\{[^}]*width:54px/.test(css));
  assert.ok(css.includes('.sw{border-radius:26px}'));
});
test('Rev 93: bar bawah digerakkan rAF, kurva easeInOutCubic, reduced motion dihormati', () => {
  for (const k of ['function navTo(', 'function navPaint(', 'requestAnimationFrame(step)', 'navEase', 'prefers-reduced-motion', "classList.add('navmove')"]) assert.ok(main.includes(k), k);
  assert.ok(main.includes('requestAnimationFrame(() => requestAnimationFrame(() => render()))'));
  assert.ok(css.includes('nav.navmove .navsh{filter:none') && css.includes('.navbg path{transition:none}'));
});
test('Rev 93: versi 0.3.9', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('RIWAYAT.md').includes('Rev 93 / 0.3.7'));
});
