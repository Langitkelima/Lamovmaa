// Rev 421 / PART SY3b (Paket SY): layar Sync varian G (Orbit + Jalur) di src/js/sync-ui.js. Tes Node: logika status + pemeriksaan sumber. BUKAN bukti dari HP/Chromium.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { bacaStatus, SYNC_CFG_KEY } from '../src/js/sync-jalan.js';
import { CONN_KEY } from '../src/js/ai/sambungan.js';
const rd = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const store = () => { const m = new Map(); return { m, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { m.set(k, String(v)); }, removeItem: (k) => { m.delete(k); } }; };
const conn = (st) => st.setItem(CONN_KEY, JSON.stringify({ url: 'https://k.contoh.workers.dev', key: 'rama-secret-12' }));
const data = () => ({ notes: [{ id: 'abcd1', title: 'a', html: '<p>x</p>', labels: [], updated: 1 }], priv: [], settings: { labels: [] } });

test('bacaStatus: belum > jalan > off > galat > tunggu > ok', () => {
  const st = store(), d = data();
  assert.equal(bacaStatus({ data: d, store: st }).kode, 'belum'); assert.equal(bacaStatus({ data: d, store: st, online: false }).kode, 'belum');
  conn(st);
  assert.equal(bacaStatus({ data: d, store: st, busy: true, online: false }).kode, 'jalan');
  assert.equal(bacaStatus({ data: d, store: st, online: false }).kode, 'off');
  assert.equal(bacaStatus({ data: d, store: st }).kode, 'tunggu'); // catatan belum pernah terkirim
  st.setItem(SYNC_CFG_KEY, JSON.stringify({ v: 1, lastErr: 'Passcode salah' }));
  assert.equal(bacaStatus({ data: d, store: st }).kode, 'galat');
  assert.equal(bacaStatus({ data: d, store: st, online: false }).kode, 'off');
  assert.equal(bacaStatus({ data: d, store: st }).notes, 1);
  assert.equal(bacaStatus({ data: { notes: [], priv: [], settings: { labels: [] } }, store: (() => { const s = store(); conn(s); return s; })() }).kode, 'ok');
});

test('teksStatus + lalu: teks per status, tanpa passcode', async () => {
  const src = rd('src/js/sync-ui.js');
  // Muat fungsi murni tanpa DOM: potong bagian lalu/teksStatus dari sumber.
  const code = src.slice(src.indexOf('export function lalu'), src.indexOf('function afterApply')).replace(/export /g, '');
  const { lalu, teksStatus } = new Function(code + '; return { lalu, teksStatus };')();
  const now = 10_000_000_000;
  assert.equal(lalu(now - 5000, now), 'baru saja'); assert.equal(lalu(now - 5 * 60000, now), '5 menit lalu'); assert.equal(lalu(now - 3 * 3600000, now), '3 jam lalu'); assert.equal(lalu(now - 2 * 86400000, now), '2 hari lalu');
  assert.deepEqual(teksStatus({ kode: 'belum', cfg: {} })[0], 'Belum masuk');
  assert.match(teksStatus({ kode: 'tunggu', dirty: 3, cfg: {} })[1], /^3 catatan berubah/);
  assert.match(teksStatus({ kode: 'ok', notes: 148, cfg: { lastOkAt: now - 2 * 60000 } }, now)[1], /2 menit lalu\. 148 catatan/);
  assert.equal(teksStatus({ kode: 'ok', notes: 1, cfg: {} })[0], 'Siap disinkronkan');
  assert.equal(teksStatus({ kode: 'galat', cfg: { lastErr: 'X salah' } })[1], 'X salah');
  assert.equal(teksStatus({ kode: 'jalan', cfg: {} })[0], 'Sedang menyinkronkan');
  assert.equal(teksStatus({ kode: 'off', cfg: {} })[0], 'Offline');
});

test('sumber sync-ui.js: varian G, dimuat malas, hapus massal + keluar lewat dialog, tanpa Catatan Privat/passcode', () => {
  const s = rd('src/js/sync-ui.js'), k = s.replace(/\/\/.*$/gm, '');
  assert.match(k, /import\('\.\/sync-jalan\.js'\)/); assert.doesNotMatch(k, /^import .*sync-jalan/m); assert.doesNotMatch(k, /from '\.\/sync\.js'/);
  for (const c of ['syorb', 'syrute', 'sycen', 'sybtn', 'Sinkronkan sekarang', 'Sinkron otomatis', 'Keluar dari sinkron']) assert.ok(k.includes(c), c);
  assert.match(k, /allowMassDelete/); assert.match(k, /dialogTahan/); assert.match(k, /putusSinkron/); assert.match(k, /role: 'switch'/);
  assert.doesNotMatch(k, /\.priv\b|kelimaa_ai_conn|\.key\b/);
  assert.match(k, /export function bukaPilihan/); assert.match(k, /export const SYNC_PILIHAN/);
  assert.doesNotMatch(rd('src/js/main.js') + rd('src/js/startup.js'), /sync-jalan|sync-ui/);
});

test('CSS blok Rev 421: hanya variabel tema (tanpa hex/rgba), gerak dimatikan bila diminta, dalam anggaran', () => {
  const c = rd('src/css/styles.css'), b = c.slice(c.indexOf('/* Rev 421 / SY3b'));
  assert.ok(b.length > 2000); assert.doesNotMatch(b, /#[0-9a-fA-F]{3,8}\b|rgba?\(/); assert.match(b, /prefers-reduced-motion/);
  for (const n of ['syrip', 'syrt', 'sygt', 'synf', 'symv', 'sydr', 'sypop', 'sywt']) assert.ok(b.includes('@keyframes ' + n), n);
  assert.ok(Buffer.byteLength(c) <= 270 * 1024);
});

test('dokumen dan pemasangan: banner Rev 421, tes terdaftar, versi/SCHEMA tetap', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) { const d = rd(f); assert.ok(/^\*\*Rev 4(?:2[1-9]|3\d) \/ v0\.3\.121/.test(d), f); const e = d.slice(d.indexOf('**Rev 421 /'), d.indexOf('**Rev 420 /')); assert.match(e, /SY3b/); assert.match(e, /BERFUNGSI-BELUM-DIUJI/); assert.match(e, /SCHEMA \(22\)/); }
  assert.match(rd('package.json'), /tests\/rev421\.test\.mjs/); assert.equal(JSON.parse(rd('package.json')).version, '0.3.121'); assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
});
