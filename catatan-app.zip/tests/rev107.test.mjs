// Rev 107: kursor/teks tidak boleh berada di kiri kotak centang (div.todo flex di contenteditable).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { boxOf, healTodoRow, caretLeftOfBox, caretAfterBox } from '../src/js/todo.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

// DOM mini: cukup untuk fungsi murni (childNodes, firstChild/nextSibling, insertBefore, parentNode).
class N {
  constructor(type, tag, data) { this.nodeType = type; this.tagName = tag; this.data = data; this.parentNode = null; this.childNodes = []; }
  get firstChild() { return this.childNodes[0] || null; }
  get nextSibling() { if (!this.parentNode) return null; const k = this.parentNode.childNodes; return k[k.indexOf(this) + 1] || null; }
  insertBefore(c, ref) { if (c.parentNode) c.parentNode.childNodes.splice(c.parentNode.childNodes.indexOf(c), 1); c.parentNode = this; const i = ref ? this.childNodes.indexOf(ref) : this.childNodes.length; this.childNodes.splice(i, 0, c); return c; }
}
const txt = (d) => new N(3, undefined, d);
const row = (...kids) => { const r = new N(1, 'DIV'); for (const k of kids) r.insertBefore(k, null); return r; };
const box = () => new N(1, 'INPUT');
const dump = (r) => r.childNodes.map((c) => (c.nodeType === 3 ? JSON.stringify(c.data) : '[' + c.tagName + ']')).join(' ');

test('Rev 107: baris normal (kotak lalu teks) tidak diubah', () => {
  const cb = box(); const t = txt('\u00a0isi'); const r = row(cb, t);
  assert.equal(boxOf(r), cb); assert.equal(healTodoRow(r), 0); assert.equal(dump(r), '[INPUT] "\u00a0isi"');
});
test('Rev 107: teks yang nyasar di kiri kotak dipindah ke kanan, urutan terjaga (kasus rekaman: "Dddd" di kiri)', () => {
  const r = row(txt('Dd'), txt('dd'), box(), txt('\u00a0fffyyg'));
  assert.equal(healTodoRow(r), 2);
  assert.equal(dump(r), '[INPUT] "Dd" "dd" "\u00a0fffyyg"');
  assert.equal(healTodoRow(r), 0, 'idempoten');
});
test('Rev 107: baris tanpa teks setelah kotak juga sembuh', () => {
  const r = row(txt('x'), box()); assert.equal(healTodoRow(r), 1); assert.equal(dump(r), '[INPUT] "x"');
});
test('Rev 107: caretLeftOfBox: di kiri/tepat sebelum kotak = true; sesudah kotak = false', () => {
  const a = txt('kiri'); const cb = box(); const b = txt('\u00a0kanan'); const r = row(a, cb, b);
  assert.equal(caretLeftOfBox(r, r, 0), true);
  assert.equal(caretLeftOfBox(r, r, 1), true, 'tepat sebelum kotak');
  assert.equal(caretLeftOfBox(r, r, 2), false, 'tepat sesudah kotak');
  assert.equal(caretLeftOfBox(r, a, 2), true, 'di dalam teks kiri');
  assert.equal(caretLeftOfBox(r, b, 3), false);
  const r2 = row(cb === null ? null : box(), txt('\u00a0x'));
  assert.equal(caretLeftOfBox(r2, r2, 0), true, 'offset 0 pada baris normal = sebelum kotak');
  assert.equal(caretLeftOfBox(row(txt('tanpa kotak')), r, 0), false);
});
test('Rev 107: caretAfterBox: awal teks di kanan kotak, melewati nbsp pembuka; tanpa teks = tepat setelah kotak', () => {
  const cb = box(); const t = txt('\u00a0isi'); const r = row(cb, t);
  assert.deepEqual({ ...caretAfterBox(r), node: caretAfterBox(r).node === t }, { node: true, offset: 1 });
  const t2 = txt('isi'); assert.equal(caretAfterBox(row(box(), t2)).offset, 0);
  const only = row(box()); const g = caretAfterBox(only); assert.equal(g.node, only); assert.equal(g.offset, 1);
  assert.equal(caretAfterBox(row(txt('x'))), null);
});
test('Rev 107: sumber notes.js: sanitize menyembuhkan, penjaga kursor terpasang dan dilepas, input memanggil penyembuh', () => {
  const nt = src('src/js/notes.js');
  assert.ok(/import \{[^}]*\binsertTodo\b[^}]*\bhealTodoRow\b[^}]*\bcaretLeftOfBox\b[^}]*\bcaretAfterBox\b[^}]*\} from '\.\/todo\.js';/.test(nt)); // Rev 108 menambah impor lain
  assert.ok(nt.includes("querySelectorAll('.todo').forEach((row) => healTodoStructure(row, t.content.ownerDocument))")); // Rev 108: healTodoStructure memanggil healTodoRow lebih dulu
  assert.ok(nt.includes("document.addEventListener('selectionchange', keepCaretRight)"));
  assert.ok(nt.includes("document.removeEventListener('selectionchange', keepCaretRight)"));
  assert.ok(nt.includes("ed.addEventListener('input', () => { healTodos();"));
  assert.ok(nt.includes("if (o.classList.contains('ed-baca') || composing) return;"), 'mode Baca (dan saat IME menyusun kata) tidak menyentuh kursor');
});
test('Rev 107: versi 0.3.121, SCHEMA/native tidak berubah', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
});
