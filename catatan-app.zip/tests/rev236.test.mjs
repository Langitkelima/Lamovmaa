// Rev 236 / Tahap 7c: sambungan AI ke Proyek = (1) sumber konteks `proyek` (bawaan MATI) dan (2) tautkan tugas hasil usulan AI ke proyek aktif (opsional, bisa Urungkan). Tanpa DOM; tanpa perubahan SCHEMA/Worker.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { CTX_SOURCES, normPerms, buildContext, anyOn } from '../src/js/ai/konteks.js';
import { activeProjects, linkTasksToProject, unlinkTasks, createTasks, removeTasks } from '../src/js/ai/aksi.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => {
  const data = {
    tasks: [{ id: 't1', title: 'A', done: true }, { id: 't2', title: 'B', done: false }, { id: 't3', title: 'C', done: false }],
    notes: [{ id: 'n1', title: 'Rahasia judul', text: 'isi', updated: 1 }], priv: [{ id: 'p1', title: 'PRIVAT' }], trash: [],
    projects: [
      { id: 'a', name: 'Renovasi Dapur', desc: 'DESKRIPSI RAHASIA', status: 'aktif', at: 20, due: new Date(2026, 11, 31).getTime(), tasks: ['t1', 't2'], notes: ['n1'] },
      { id: 'b', name: 'Lama', desc: '', status: 'selesai', at: 10, tasks: [], notes: [] },
      { id: 'c', name: 'Belajar', desc: '', status: 'aktif', at: 30, tasks: [], notes: [] },
    ],
  };
  let saved = 0; return { data, persist: () => { saved++; }, ui: { tab: 'x' }, render() {}, get saved() { return saved; } };
};
test('konteks: sumber proyek ada, bawaan MATI, normPerms tidak menyalakan sendiri', () => {
  assert.deepEqual(CTX_SOURCES.map((s) => s.id), ['tugas', 'proyek']);
  const p = normPerms(null); assert.deepEqual(p.proyek, []); assert.equal(anyOn(p), false);
  assert.equal(buildContext(mk().data, { v: 2, proyek: [] }).text, '');
});
test('konteks: hanya proyek AKTIF, terbaru dulu, nama + kemajuan + tenggat; tanpa deskripsi, judul tugas, judul catatan', () => {
  const t = buildContext(mk().data, { v: 2, proyek: ['a', 'b', 'c'] }).text;
  assert.match(t, /Proyek aktif:/); assert.match(t, /- Belajar, belum ada tugas tertaut/); assert.match(t, /- Renovasi Dapur, 1 dari 2 tugas selesai, tenggat 2026-12-31/);
  assert.ok(t.indexOf('Belajar') < t.indexOf('Renovasi'));
  assert.doesNotMatch(t, /Lama|DESKRIPSI|Rahasia judul|PRIVAT|\bB\b.*tugas selesai/);
});
test('konteks: tanpa proyek aktif = tidak ada blok; maks. 10 proyek; data rusak aman', () => {
  assert.equal(buildContext({ projects: [{ id: 'x', name: 'S', status: 'arsip', tasks: [], notes: [] }] }, { v: 2, proyek: ['x'] }).text, '');
  const many = { tasks: [], projects: Array.from({ length: 14 }, (_, i) => ({ id: 'p' + i, name: 'P' + i, status: 'aktif', at: i + 1, tasks: [], notes: [] })) };
  assert.equal(buildContext(many, { v: 2, proyek: many.projects.map((q) => q.id) }, 5000).parts[0].count, 10);
  assert.doesNotThrow(() => buildContext(null, { v: 2, proyek: ['p'] })); assert.doesNotThrow(() => buildContext({ projects: [null, 5, {}] }, { v: 2, proyek: ['p'] }));
});
test('activeProjects: hanya status aktif, terbaru dulu', () => { assert.deepEqual(activeProjects(mk()).map((p) => p.id), ['c', 'a']); assert.deepEqual(activeProjects(null), []); });
test('linkTasksToProject: menautkan id baru ke proyek aktif; proyek selesai/tak ada = null; id yang sudah tertaut tidak berubah', () => {
  const c = mk(); const r = linkTasksToProject(c, 'c', ['t2', 't3']); assert.deepEqual(r, { linked: 2, skipped: 0 }); assert.deepEqual(c.data.projects[2].tasks, ['t2', 't3']); assert.equal(c.saved, 1);
  assert.deepEqual(linkTasksToProject(c, 'a', ['t1']), { linked: 0, skipped: 0 }); assert.deepEqual(c.data.projects[0].tasks, ['t1', 't2']); // sudah tertaut: tetap
  assert.equal(linkTasksToProject(c, 'b', ['t1']), null); assert.equal(linkTasksToProject(c, 'zzz', ['t1']), null); assert.equal(linkTasksToProject(c, 'a', 'x'), null);
});
test('linkTasksToProject: batas 100 tautan = sisanya dilewati dan dihitung', () => {
  const c = mk(); c.data.projects[2].tasks = Array.from({ length: 99 }, (_, i) => 'k' + i);
  assert.deepEqual(linkTasksToProject(c, 'c', ['u1', 'u2', 'u3']), { linked: 1, skipped: 2 }); assert.equal(c.data.projects[2].tasks.length, 100);
});
test('alur penuh: buat tugas AI -> tautkan -> Urungkan membuang tugas DAN tautannya; proyek lain utuh', () => {
  const c = mk(); const ids = createTasks(c, ['Beli cat', 'Ukur dinding'], 'minggu'); assert.equal(ids.length, 2);
  assert.deepEqual(linkTasksToProject(c, 'c', ids), { linked: 2, skipped: 0 }); assert.equal(c.data.projects[2].tasks.length, 2);
  assert.equal(unlinkTasks(c, ids), 2); assert.equal(removeTasks(c, ids), 2);
  assert.deepEqual(c.data.projects[2].tasks, []); assert.deepEqual(c.data.projects[0].tasks, ['t1', 't2']); assert.equal(c.data.tasks.length, 3);
  assert.equal(unlinkTasks(null, ids), 0); assert.equal(unlinkTasks(c, 'x'), 0);
});
test('sumber: aksi/konteks hanya impor proyek-alat (lazy); tidak menyentuh Privat/sampah; obrolan memakai fungsi baru; versi 0.3.121; tes terdaftar', () => {
  assert.match(src('src/js/ai/aksi.js'), /from '\.\.\/proyek-alat\.js'/); assert.match(src('src/js/ai/konteks.js'), /from '\.\.\/proyek-alat\.js'/);
  for (const f of ['ai/aksi.js', 'ai/konteks.js']) assert.doesNotMatch(src('src/js/' + f), /\.priv\b|\.trash\b|innerHTML/);
  const o = src('src/js/ai/obrolan.js'); assert.match(o, /linkTasksToProject/); assert.match(o, /unlinkTasks\(ctx, ids\); removeTasks\(ctx, ids\)/); assert.match(o, /'Tautkan ke proyek'/);
  for (const f of ['main.js', 'notes.js', 'settings.js', 'todo.js', 'storage.js']) assert.doesNotMatch(src('src/js/' + f), /proyek-alat/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev236\.test\.mjs/);
});
