// Rev 127: (a) audit U7 = perbaikan lembar-ui (sel tidak disentuh tidak berubah, tutup layar menyimpan isian, peringatan hapus lembar terpakai);
// (b) U8a-2 = sel menyimpan fx (SCHEMA 12), grid menghitung dan menampilkan hasil rumus.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import * as S from '../src/js/storage.js';
import { deleteNote, fxDisplay, hasFx, tabHasFx } from '../src/js/lembar-ui.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('audit U7: commit() tidak menyimpan bila isian tidak diketik ulang; tutup layar ikut menyimpan', () => {
  const s = src('src/js/lembar-ui.js');
  assert.match(s, /if \(val\.value === shown\) return;/);
  assert.match(s, /shown = val\.value;/);
  assert.match(s, /close: \(\) => \{ try \{ commit\(\); \}/);
});
test('audit U7: alur lama yang salah (teks angka diparse tiap lepas sel) terbukti ada di parseInput; penjaga mencegahnya', () => {
  // Replika murni alur commit lama: tanpa penjaga "val.value === shown", "007" berubah jadi 7. Dengan penjaga, tidak pernah sampai ke parseInput.
  const parse = (t) => (/^[-+]?\d+([.,]\d+)?$/.test(String(t).trim()) ? Number(String(t).trim().replace(',', '.')) : String(t));
  for (const txt of ['007', '0812345678', '1.000']) { assert.notEqual(String(parse(txt)), txt); const shown = txt, value = txt; assert.equal(value === shown, true); }
});
test('audit U7: dialog hapus menyebut pemakaian oleh catatan; Setelan dan catatan mengirim usedIn', () => {
  assert.equal(deleteNote(0), ''); assert.equal(deleteNote(undefined), ''); assert.equal(deleteNote('x'), ''); assert.equal(deleteNote(-3), '');
  assert.match(deleteNote(2), /dipakai di 2 catatan/); assert.match(deleteNote(1.9), /di 1 catatan/);
  assert.match(src('src/js/lembar-ui.js'), /usedIn = 0 \} = \{\}/); assert.match(src('src/js/lembar-ui.js'), /deleteNote\(usedIn\)/);
  assert.match(src('src/js/settings.js'), /usedIn: sheetUsage\(data\)\[id\] \|\| 0/);
  assert.match(src('src/js/notes.js'), /usedIn: \(sheetUsage\(ctx\.data\)\[sh\.id\] \|\| 0\)/);
  assert.doesNotMatch(src('src/js/settings.js'), /Tab baru, lebar kolom, dan gaya menyusul/);
});

test('U8a-2: cleanCell menyimpan fx (tanpa v), membuang fx yang bukan rumus/terlalu panjang', () => {
  assert.deepEqual(L.cleanCell({ fx: '=1+1' }), { fx: '=1+1' });
  assert.deepEqual(L.cleanCell({ fx: '=1+1', v: 5, s: { b: true } }), { fx: '=1+1', s: { b: true } });
  assert.equal(L.cleanCell({ fx: 'bukan rumus' }), null); assert.equal(L.cleanCell({ fx: '=' }), null); assert.equal(L.cleanCell({ fx: 5 }), null);
  assert.deepEqual(L.cleanCell({ fx: 'x', v: 3 }), { v: 3 });
  assert.equal(L.cleanCell({ fx: '=' + '1'.repeat(L.MAX_FX_LEN) }), null); assert.ok(L.cleanCell({ fx: '=' + '1'.repeat(L.MAX_FX_LEN - 1) }));
});
test('U8a-2: setCell fx / v saling menggantikan; gaya tetap', () => {
  const t = L.newTab('T', 3); const r = t.rows[0].id, c = t.cols[0].id;
  assert.ok(L.setCell(t, r, c, { v: 4, s: { b: true } }));
  assert.ok(L.setCell(t, r, c, { fx: '=2*3' })); assert.deepEqual(t.rows[0].cells[c], { fx: '=2*3', s: { b: true } });
  assert.ok(L.setCell(t, r, c, { v: 'teks' })); assert.deepEqual(t.rows[0].cells[c], { v: 'teks', s: { b: true } });
  assert.ok(L.setCell(t, r, c, { fx: '=1' })); assert.ok(L.setCell(t, r, c, { fx: null })); assert.deepEqual(t.rows[0].cells[c], { s: { b: true } });
  assert.ok(L.setCell(t, r, c, { fx: '=1' })); assert.ok(L.setCell(t, r, c, { v: null })); assert.deepEqual(t.rows[0].cells[c], { s: { b: true } });
  assert.equal(L.setCell(t, r, c, { fx: 'salah' }), false);
});
test('U8a-2: SCHEMA 12; fx lolos normalize, ekspor/impor JSON, dan data v11 tanpa fx tetap valid', () => {
  assert.equal(S.SCHEMA, 22);
  const sh = L.newSheet({ id: 'sab123', name: 'Anggaran' }); const tab = sh.tabs[0];
  L.setCell(tab, 'r1', 'cA', { v: 10 }); L.setCell(tab, 'r2', 'cA', { v: 5 });
  const a = R.a1ToStored('=SUM(A1:A2)', tab); assert.ok(a.ok); L.setCell(tab, 'r3', 'cA', { fx: a.fx });
  const d = S.normalize({ version: 12, sheets: { sab123: sh } });
  assert.equal(d.sheets.sab123.tabs[0].rows[2].cells.cA.fx, a.fx); assert.equal(d.sheets.sab123.tabs[0].rows[2].cells.cA.v, undefined);
  const back = S.normalize(JSON.parse(S.exportJSON(d))); assert.equal(back.sheets.sab123.tabs[0].rows[2].cells.cA.fx, a.fx);
  const old = S.normalize({ version: 11, sheets: { sab123: { ...sh, tabs: [{ ...tab, rows: tab.rows.map((r) => ({ ...r, cells: Object.fromEntries(Object.entries(r.cells).filter(([, x]) => !x.fx)) })) }] } } });
  assert.equal(tabHasFx(old.sheets.sab123.tabs[0]), false);
});
test('U8a-2: hasil dihitung dari sel (tidak disimpan) dan galat ditandai; fxDisplay/hasFx/tabHasFx murni', () => {
  const tab = L.newTab('T', 6);
  L.setCell(tab, 'r1', 'cA', { v: 10 }); L.setCell(tab, 'r2', 'cA', { v: 5 });
  const put = (rid, cid, a1) => { const r = R.a1ToStored(a1, tab); assert.ok(r.ok, a1); L.setCell(tab, rid, cid, { fx: r.fx }); };
  put('r3', 'cA', '=SUM(A1:A2)'); put('r4', 'cA', '=A3/0'); put('r5', 'cA', '=A3/4');
  const res = R.computeTab(tab, { now: 0 });
  assert.equal(res.get('r3', 'cA'), 15); assert.deepEqual(fxDisplay(res.get('r3', 'cA')), { text: '15', err: false });
  assert.deepEqual(fxDisplay(res.get('r4', 'cA')), { text: '#DIV/0!', err: true }); assert.deepEqual(fxDisplay(res.get('r5', 'cA')), { text: '3,75', err: false });
  assert.deepEqual(fxDisplay(undefined), { text: '', err: false });
  assert.equal(hasFx({ fx: '=1' }), true); assert.equal(hasFx({ v: 1 }), false); assert.equal(hasFx(null), false);
  assert.equal(tabHasFx(tab), true); assert.equal(tabHasFx(L.newTab('K')), false); assert.equal(tabHasFx(null), false);
  assert.equal(JSON.stringify(tab).includes('"15"'), false); // hasil tidak ikut tersimpan
});
test('U8a-2: sisip/hapus kolom tidak merusak rumus (ID); hapus kolom yang dirujuk = #REF!', () => {
  const tab = L.newTab('T', 4); L.setCell(tab, 'r1', 'cA', { v: 7 });
  const r = R.a1ToStored('=A1+1', tab); L.setCell(tab, 'r2', 'cB', { fx: r.fx });
  assert.ok(L.deleteCol(tab, 'cZ')); assert.ok(L.insertCol(tab, 0)); // tab baru sudah 26 kolom (penuh): kosongkan satu dulu; kolom baru di depan: A1 lama kini B1, rumus tetap menunjuk sel yang sama
  const ex = R.computeTab(tab, { now: 0 }); assert.equal(ex.get('r2', 'cB'), 8); assert.equal(R.storedToA1(r.fx, tab), '=B1+1');
  L.deleteCol(tab, 'cA'); assert.deepEqual(R.computeTab(tab, { now: 0 }).get('r2', 'cB'), R.E.REF);
});
test('U8a-2: lembar-ui memakai mesin rumus dengan cache (ver), menampilkan rumus A1 di bilah, kunci aman', () => {
  const s = src('src/js/lembar-ui.js');
  assert.match(s, /import \{ computeTab, valueToText, isErr, storedToA1, a1ToStored(?:, fxAutoNf)? \} from '\.\/rumus\.js'/);
  assert.match(s, /const getCalc = \(\) =>/); assert.match(s, /tabHasFx\(tab\) \? computeTab\(tab\) : null/);
  assert.match(s, /hasFx\(pc\) \? storedToA1\(pc\.fx, tab\) : displayValue\(pc\)/);
  assert.match(s, /fxd && fxd\.err \? ' err' : ''/);
  assert.equal((s.match(/ver\+\+, hist\.push\(/g) || []).length, 28); // kotak centang diketuk (Rev 303b) + bekukan baris (Rev 300b) + ubah huruf Aa (Rev 298) + bersihkan riwayat error (Rev 279) + gabung langsung dari seleksi (Rev 260) + aksi seleksi (Rev 254) + seret tinggi baris (Rev 184b) + tempel (Rev 171) + simpan + hapus diagram (Rev 159) + gabung+pisahkan sel (Rev 152) + geser tab (Rev 150) + 8 lama + warna bersyarat (Rev 146) + urutkan (Rev 141) + ganti semua (Rev 142) + isi seri (Rev 143) assert.match(s, /ver\+\+; palMode = null;/);
  assert.doesNotMatch(s, /eval\(|new Function/);
  for (const f of ['notes.js', 'main.js', 'lembar.js', 'storage.js', 'lembar-pulau.js', 'lembar-siklus.js']) assert.doesNotMatch(src('src/js/' + f), /rumus\.js/, f); // ekspor/pratinjau memakai HASIL = U8b
});
test('Rev 127: versi (dinaikkan Rev 128), native/dependensi tidak berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('tests/rev127.test.mjs'));
});
