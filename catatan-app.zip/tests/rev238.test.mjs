// Rev 238 / Tahap 8b-1: data tren (SCHEMA 20): tugas.doneAt + data.habitLog. Hanya lapisan data; Insight belum memakainya (8b-2).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/logic.js'; import * as S from '../src/js/storage.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const N = 1763000000000;
test('toggleDone: tugas selesai dapat doneAt, batal centang menghapusnya; kebiasaan tidak pernah dapat doneAt', () => {
  const t = { id: 't', title: 'x', done: false }; L.toggleDone(t, true, N); assert.equal(t.done, true); assert.equal(t.doneAt, N);
  L.toggleDone(t, true, N + 5); assert.equal(t.done, false); assert.equal('doneAt' in t, false);
  const h = { id: 'h', title: 'y', done: false }; L.toggleDone(h, false, N); assert.equal(h.done, true); assert.equal('doneAt' in h, false);
});
test('cleanDoneAt: hanya tugas selesai dengan angka positif; sisanya dibuang; bulat', () => {
  const l = [{ done: true, doneAt: N + 0.7 }, { done: false, doneAt: N }, { done: true, doneAt: -1 }, { done: true, doneAt: 'abc' }, { done: true }, null, 5];
  assert.doesNotThrow(() => L.cleanDoneAt(l)); assert.equal(l[0].doneAt, N); assert.equal('doneAt' in l[1], false); assert.equal('doneAt' in l[2], false); assert.equal('doneAt' in l[3], false); assert.equal('doneAt' in l[4], false);
});
test('cleanHabitLog: buang rusak (tanggal, done > total, total 0), ganda diganti yang terakhir, urut naik, maks. 60', () => {
  const r = L.cleanHabitLog([{ d: '2026-11-02', done: 1, total: 3 }, { d: '2026-11-01', done: 2, total: 2 }, { d: '2026-11-02', done: 3, total: 3 }, { d: 'x', done: 1, total: 1 }, { d: '2026-11-03', done: 4, total: 3 }, { d: '2026-11-04', done: 0, total: 0 }, { d: '2026-11-05', done: 1.5, total: 2 }, null, 'a']);
  assert.deepEqual(r, [{ d: '2026-11-01', done: 2, total: 2 }, { d: '2026-11-02', done: 3, total: 3 }]);
  const many = Array.from({ length: 90 }, (_, i) => ({ d: new Date(Date.UTC(2026, 0, 1 + i)).toISOString().slice(0, 10), done: 1, total: 1 }));
  const c = L.cleanHabitLog(many); assert.equal(c.length, L.HABIT_LOG_MAX); assert.equal(c[c.length - 1].d, many[89].d); assert.deepEqual(L.cleanHabitLog('rusak'), []);
});
test('logHabitDay: mencatat done/total; tanpa kebiasaan atau tanggal salah = tidak mencatat; hari sama diperbarui', () => {
  const d = { habits: [{ done: true }, { done: false }, { done: true }], habitLog: [] };
  assert.equal(L.logHabitDay(d, '2026-11-10'), true); assert.deepEqual(d.habitLog, [{ d: '2026-11-10', done: 2, total: 3 }]);
  d.habits[1].done = true; L.logHabitDay(d, '2026-11-10'); assert.deepEqual(d.habitLog, [{ d: '2026-11-10', done: 3, total: 3 }]);
  assert.equal(L.logHabitDay({ habits: [] }, '2026-11-10'), false); assert.equal(L.logHabitDay(d, ''), false); assert.equal(L.logHabitDay(d, 'kemarin'), false);
  const x = { habits: [{ done: true }] }; L.logHabitDay(x, '2026-11-10'); assert.equal(x.habitLog.length, 1);
});
test('applyDailyReset: mencatat hari yang BARU berakhir (lastReset) sebelum dikosongkan; tidak mencatat bila tidak reset atau lastReset kosong', () => {
  const mk = (last) => ({ habits: [{ id: 'a', done: true }, { id: 'b', done: false }], habitLog: [], settings: { days: [0, 1, 2, 3, 4, 5, 6], lastReset: last } });
  const d = mk('2026-11-11'); assert.equal(L.applyDailyReset(d, '2026-11-12'), true);
  assert.deepEqual(d.habitLog, [{ d: '2026-11-11', done: 1, total: 2 }]); assert.equal(d.habits.every((h) => h.done === false), true); assert.equal(d.settings.lastReset, '2026-11-12');
  assert.equal(L.applyDailyReset(d, '2026-11-12'), false); assert.equal(d.habitLog.length, 1);
  const e = mk(''); L.applyDailyReset(e, '2026-11-12'); assert.deepEqual(e.habitLog, []);
  const f = mk('2026-11-11'); f.settings.days = []; assert.equal(L.applyDailyReset(f, '2026-11-12'), false); assert.deepEqual(f.habitLog, []);
});
test('storage: SCHEMA 20; data kosong punya habitLog []; data v19 dimigrasi; doneAt dijaga di tugas dan sampah; ekspor dan impor utuh', () => {
  assert.equal(S.SCHEMA, 22); assert.deepEqual(S.emptyData().habitLog, []);
  const old = S.normalize({ version: 19, habits: [], tasks: [], notes: [], priv: [], trash: [], projects: [] }); assert.deepEqual(old.habitLog, []); assert.equal(old.version, 22);
  const d = S.normalize({ habits: [], notes: [], priv: [], habitLog: [{ d: '2026-11-11', done: 1, total: 2 }, { d: 'rusak' }],
    tasks: [{ id: 'a', title: 'A', done: true, doneAt: N }, { id: 'b', title: 'B', done: false, doneAt: N }],
    trash: [{ kind: 'task', item: { id: 'c', title: 'C', done: true, doneAt: N } }, { kind: 'task', item: { id: 'e', title: 'E', done: false, doneAt: N } }] });
  assert.deepEqual(d.habitLog, [{ d: '2026-11-11', done: 1, total: 2 }]); assert.equal(d.tasks[0].doneAt, N); assert.equal('doneAt' in d.tasks[1], false);
  assert.equal(d.trash[0].item.doneAt, N); assert.equal('doneAt' in d.trash[1].item, false);
  const back = S.normalize(JSON.parse(S.exportJSON(d))); assert.deepEqual(back.habitLog, d.habitLog); assert.equal(back.tasks[0].doneAt, N);
});
test('main.js memakai toggleDone untuk centang utama; Worker tidak berubah; versi 0.3.121; tes terdaftar', () => {
  const m = src('src/js/main.js'); assert.match(m, /toggleDone\(item, !isH\)/); assert.doesNotMatch(m, /onclick: \(\) => \{ item\.done = !item\.done;/);
  // Rev 239 / 8b-2: Insight kini memakai habitLog/doneAt (dites di rev239.test.mjs).
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev238\.test\.mjs/);
});
