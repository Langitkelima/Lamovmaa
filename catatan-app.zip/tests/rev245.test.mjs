// Rev 245: bagian E daftar uji HP Kelimaa AI (dokumen saja; tanpa perubahan kode). Bukan uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('UJI_HP_RILIS.md punya bagian E1-E10 dengan butir bernomor 1-33 dan label jujur', () => {
  const u = src('UJI_HP_RILIS.md'); for (const k of ['E1.', 'E2.', 'E3.', 'E4.', 'E5.', 'E6.', 'E7.', 'E8.', 'E9.', 'E10.']) assert.ok(u.includes('**' + k), k);
  const e = u.slice(u.indexOf('## E. Kelimaa AI')); const nums = [...e.matchAll(/^(\d+)\. \[ \]/gm)].map((m) => Number(m[1])); assert.deepEqual(nums, Array.from({ length: 33 }, (_, i) => i + 1));
  assert.match(e, /BELUM pernah dicoba di HP/); assert.match(e, /DIMATIKAN/); assert.match(e, /HARD_DAILY_LIMIT/);
});
test('label tombol yang disebut daftar benar-benar ada di kode', () => {
  const o = src('src/js/ai/obrolan.js'), t = src('src/js/ai/tulisui.js');
  for (const k of ['Insight mingguan', 'Jadikan tugas', 'Tambah ke catatan yang ada', 'Cari di web', 'Cadangkan riwayat', 'Pulihkan riwayat']) assert.ok(o.includes(k), k);
  assert.ok(t.includes('Tulis dengan AI')); assert.match(src('src/js/notes.js'), /class: 'aichip', 'aria-label': 'Tulis AI'/ /* Rev 360: pintu Tulis AI = tahan ✦ (DISENGAJA) */); assert.match(src('UJI_HP_RILIS.md'), /tahan ✦ > "Tulis AI"/);
});
test('tanpa versi/SCHEMA berubah; tes terdaftar', () => { const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev245\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/); });
