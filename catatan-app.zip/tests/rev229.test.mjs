// Rev 229: reminder.set = tugas baru + pengingat dari balasan AI. API native DIPALSUKAN (globalThis.AndroidAPI); tanpa HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as A from '../src/js/ai/aksi.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 12, 10, 0, 0).getTime(), H = 3600000;
const mk = () => ({ data: { tasks: [{ id: 'old', title: 'LAMA', done: false, scope: 'hari' }], notes: [], habits: [], settings: {} }, ui: { tab: 'catatan' }, persists: 0, persist() { this.persists++; }, render() {} });
const fakeNative = (res = 'scheduled') => { const calls = [], cancels = []; globalThis.AndroidAPI = { scheduleNotification: (...a) => { calls.push(a); return res; }, cancelScheduledNotification: (id) => { cancels.push(id); } }; return { calls, cancels }; };
test.afterEach(() => { delete globalThis.AndroidAPI; });

test('cleanRemindAt: harus >= 1 menit lagi dan <= sekitar setahun', () => {
  assert.equal(A.cleanRemindAt(NOW + H, NOW), NOW + H); assert.equal(A.cleanRemindAt(NOW + 30000, NOW), 0); assert.equal(A.cleanRemindAt(NOW - H, NOW), 0);
  assert.equal(A.cleanRemindAt(NOW + 400 * 24 * H, NOW), 0); for (const bad of [NaN, null, undefined, 'x', Infinity]) assert.equal(A.cleanRemindAt(bad, NOW), 0);
});
test('remindPresets: semua di masa depan dan urut; sore ini hilang bila sudah lewat', () => {
  const p = A.remindPresets(NOW); assert.deepEqual(p.map((x) => x.label), ['1 jam lagi', 'Sore ini 17:00', 'Besok 08:00', 'Besok 17:00']);
  assert.ok(p.every((x, i) => x.at > NOW && (!i || x[i - 1] === undefined || x.at >= p[i - 1].at)));
  const late = new Date(2026, 10, 12, 16, 50).getTime(); assert.ok(!A.remindPresets(late).some((x) => x.label === 'Sore ini 17:00'));
});
test('createReminders: tugas KAPITAL ber-pengingat, terjadwal lewat native, tugas lama utuh', () => {
  const n = fakeNative(), ctx = mk(), r = A.createReminders(ctx, ['Telepon ibu', 'Bayar listrik'], 'minggu', NOW + 2 * H, 'daily', NOW);
  assert.equal(r.ids.length, 2); const t = ctx.data.tasks.filter((x) => r.ids.includes(x.id));
  assert.deepEqual(t.map((x) => x.title), ['TELEPON IBU', 'BAYAR LISTRIK']); assert.ok(t.every((x) => x.scope === 'minggu' && x.reminder.at === NOW + 2 * H && x.reminder.repeat === 'daily' && x.done === false));
  assert.equal(n.calls.length, 2); assert.equal(n.calls[0][0], 'task:' + t[0].id); assert.equal(n.calls[0][4], 86400000); assert.equal(ctx.data.tasks[0].id, 'old'); assert.equal(ctx.data.tasks[0].reminder, undefined);
});
test('createReminders: waktu lewat / lingkup salah / judul kosong = null, tidak ada yang berubah', () => {
  const n = fakeNative(), ctx = mk();
  assert.equal(A.createReminders(ctx, ['A'], 'hari', NOW - H, 'once', NOW), null); assert.equal(A.createReminders(ctx, ['A'], 'habit', NOW + H, 'once', NOW), null); assert.equal(A.createReminders(ctx, ['  '], 'hari', NOW + H, 'once', NOW), null);
  assert.equal(ctx.data.tasks.length, 1); assert.equal(n.calls.length, 0);
});
test('Urungkan: removeTasks menghapus tugas DAN membatalkan alarmnya', () => {
  const n = fakeNative(), ctx = mk(), r = A.createReminders(ctx, ['A', 'B'], 'hari', NOW + H, 'once', NOW);
  assert.equal(A.removeTasks(ctx, r.ids), 2); assert.deepEqual(ctx.data.tasks.map((x) => x.id), ['old']); assert.deepEqual(n.cancels.sort(), r.ids.map((i) => 'task:' + i).sort());
});
test('remindSummary: izin ditolak / bukan HP / alarm kurang tepat / sukses', () => {
  assert.match(A.remindSummary(2, [{ ok: true }, { ok: false, reason: 'permission' }]), /izin notifikasi/); assert.match(A.remindSummary(1, [{ ok: false, reason: 'unavailable' }]), /aplikasi HP/);
  assert.match(A.remindSummary(1, [{ ok: true, warning: 'inexact_alarm' }]), /terlambat/); assert.equal(A.remindSummary(3, [{ ok: true }]), '3 pengingat dibuat.');
  const ctx = mk(); fakeNative('permission_denied'); const r = A.createReminders(ctx, ['A'], 'hari', NOW + H, 'once', NOW); assert.match(A.remindSummary(1, r.results), /izin notifikasi/); assert.equal(ctx.data.tasks.length, 2);
});
test('obrolan.js: Jadikan pengingat lewat centang + waktu + konfirmasi, ada Urungkan; Batal tetap tombol .line pertama', () => {
  const o = src('src/js/ai/obrolan.js');
  assert.match(o, /'Jadikan pengingat'/); assert.match(o, /createReminders\(ctx, pick, scope, at, rep\)/); assert.match(o, /removeTasks\(ctx, r\.ids\)/); assert.match(o, /type: 'datetime-local'/);
  assert.ok(o.indexOf("batal, tambah,") > 0); assert.doesNotMatch(o, /innerHTML/);
});
