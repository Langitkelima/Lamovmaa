// Rev 133 / U8a-5b: ketikan persen (25% -> 0,25 + format Persen otomatis; angka polos >= 1 di sel berformat Persen).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { typedPercent } from '../src/js/lembar-format.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('typedPercent: tanda % eksplisit', () => {
  assert.deepEqual(typedPercent('25%', null), { v: 0.25, d: 0, explicit: true }); assert.deepEqual(typedPercent(' 25,5 % ', null), { v: 0.255, d: 1, explicit: true });
  assert.deepEqual(typedPercent('7%', null), { v: 0.07, d: 0, explicit: true }); assert.deepEqual(typedPercent('-12.5%', null), { v: -0.125, d: 1, explicit: true });
  assert.equal(typedPercent('1,23456789%', null).d, 6);
  for (const t of ['%', 'abc%', '5%5', '1e3%', '', '25', '=A1%', '1234567890123456789%']) assert.equal(typedPercent(t, null), null, t);
});
test('typedPercent: sel berformat Persen, angka polos >= 1 = persen; < 1 tetap mentah', () => {
  const pf = { k: 'percent', d: 1 };
  assert.deepEqual(typedPercent('25', pf), { v: 0.25, d: 1, explicit: false }); assert.equal(typedPercent('0,25', pf), null); assert.equal(typedPercent('0.5', pf), null);
  assert.equal(typedPercent('25', { k: 'number' }), null); assert.equal(typedPercent('25', null), null); assert.equal(typedPercent('halo', pf), null);
});
test('kabel commit: typedPercent dipakai, format Persen otomatis hanya untuk sel tanpa format; modul tetap murni', () => {
  const u = src('src/js/lembar-ui.js'), m = src('src/js/lembar-format.js');
  assert.match(u, /typedPercent\(val\.value, \(curStyle\(\) \|\| \{\}\)\.nf\)/); assert.match(u, /pct && pct\.explicit && !curStyle\(\)\.nf/); assert.match(u, /patch\.s = \{ nf: \{ k: 'percent', d: pct\.d \} \}/);
  assert.match(u, /parseInput\(val\.value\)/); assert.doesNotMatch(m, /document|window|localStorage|eval\(|new Function|import /);
});
test('Rev 133: versi 0.3.121, SCHEMA 13 tetap, tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev133.test.mjs'));
});
