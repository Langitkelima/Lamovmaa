// Tes Rev 25b: pengingat pindah ke menu ⋮, penanda di pojok kanan header + kartu, ⋮ bulat, tanpa titik warna.
// Pemeriksaan sumber (tampilan dicek terpisah di Chromium). BUKAN uji di HP.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css'), ui = src('../src/js/ui.js');

await t('pengingat tidak lagi di badan catatan; ada di panel dock dan menu ⋮ (hanya catatan biasa)', () => {
  assert.ok(!nt.includes('remBox'));
  assert.ok(nt.includes("h('div', { class: 'dock' }, lp, rp, cp, pal, bar)"));
  assert.ok(nt.includes("const rp = isP ? null :"));
  assert.ok(/isP \? null : mi\(PATH\.alarm, remAt\.value \? 'Ubah pengingat' : 'Pengingat'/.test(nt));
  const body = nt.slice(nt.indexOf("const body = h('div', { class: 'fsb' }"), nt.indexOf("const o = h('div', { class: 'fs' }"));
  assert.ok(!body.includes('rem'), 'badan catatan tidak memuat kotak pengingat');
});
await t('ikon alarm di header (ketuk = buka panel) mengikuti isi waktu pengingat; ada di Kartu', () => {
  assert.ok(nt.includes("const remMark = isP ? null : h('button'") && nt.includes('onclick: () => openRp()'));
  assert.ok(nt.includes("const remUi = () => { if (remMark) remMark.style.display = remAt.value && fromLocalInput(remAt.value) ? '' : 'none'; };"));
  assert.ok(nt.includes("remAt.addEventListener('change', () => { remUi(); auto(); })"));
  assert.ok(nt.includes("'aria-label': n.reminder.mode === 'alarm' ? 'Alarm berdering' : 'Ada pengingat'")); // Rev 382: disesuaikan SENGAJA (Rev 381 membuat label bergantung mode; mode notifikasi tetap 'Ada pengingat')
  assert.ok(!nt.includes('⏰ Ada pengingat'), 'teks lama di kartu diganti ikon');
});
await t('panel pengingat menutup panel label/warna dan sebaliknya; menutup saat mengetik', () => {
  assert.ok(nt.includes('const openRp = () =>') && nt.includes('const closeRp = () =>'));
  assert.ok(/const openLp = \(\) => \{ closeRp\(\);/.test(nt));
  assert.ok(nt.includes('closeLp(); closeRp();'));
  assert.ok(nt.includes('closeLp(); closeRp(); });'), 'fokus ke isi menutup panel pengingat');
});
await t('ikon tautan: header (catatan biasa saja) + kartu; tampil bila ada hubungan keluar atau balik', () => {
  assert.ok(nt.includes("const linkMark = isP ? null :"));
  assert.ok(nt.includes('if (linkMark) linkMark.style.display = out.length || inn.length'));
  assert.ok(nt.includes("const linked = kind !== 'priv' && (linkedNotes(n, ctx.data.notes).length > 0 || backlinks(ctx.data.notes, n.id).length > 0)"));
});
await t('panah menu bulat besar (Rev 35, sebelumnya ⋮); penanda header bulat; label di pojok kanan; titik warna dihapus', () => {
  assert.ok(nt.includes("class: 'ghost hmore'"));
  assert.ok(/\.fsh \.ghost\.hmore\{[^}]*height:48px/.test(css));
  assert.ok(/\.hb\{[^}]*border-radius:50%/.test(css));
  assert.ok(nt.includes("class: 'hmk' }, hlab, linkMark, remMark, pinMark"));
  assert.ok(!nt.includes('colMark') && !css.includes('.cdot'));
});
await t('kartu daftar: tombol pin bulat (sematan = terisi aksen), penanda info; mode petak menaruh penanda di bawah isi', () => {
  assert.ok(nt.includes("class: 'cbd pinb'") && nt.includes("'aria-pressed': String(!!n.pin)"));
  assert.ok(/\.cbd\.pinned\{[^}]*background:var\(--ac\)/.test(css));
  assert.ok(/\.ngrid \.cin\{position:static/.test(css));
  assert.ok(ui.includes("pin: 'M15.2 3.3L19.6 6.8L15.3 11.3L16 15.9L15.1 17.2L6.2 10.3L7.2 9L11.9 8.6ZM10.6 13.7L6.2 19.4'") && ui.includes('alarm:'));
});
await t('tanpa perubahan data/native: SCHEMA 8 sejak Rev 60', () => {
  assert.match(src('../src/js/storage.js'), /SCHEMA = 22/);
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
});
console.log(n + ' tes lulus (penanda)');
