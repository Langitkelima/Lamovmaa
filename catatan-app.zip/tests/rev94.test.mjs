import assert from 'node:assert/strict';
import { test } from 'node:test';
import fs from 'node:fs';
const src = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const css = src('src/css/styles.css'), main = src('src/js/main.js'), todo = src('src/js/todo.js');
test('Rev 94: ikon + label bar bawah mengikuti --p dari navPaint (serempak dengan lingkaran)', () => {
  assert.ok(main.includes("b.style.setProperty('--p'") && main.includes("classList.toggle('lit'"));
  assert.ok(css.includes('calc(var(--p) * -20px)') && css.includes('opacity:calc(1 - var(--p) * 1.6)'));
  assert.ok(!/nav button\.on svg\{[^}]*transition:transform/.test(css.slice(0, css.indexOf('Rev 95: navbar'))), 'tidak boleh ada transisi transform CSS terpisah untuk ikon aktif');
});
test('Rev 94: kotak centang editor kustom, area sentuh >= 44px, struktur data tetap', () => {
  for (const k of ['.ed2 input[type=checkbox]{-webkit-appearance:none;appearance:none', 'width:26px;height:26px', '.ed2 input[type=checkbox]::after{content:"";position:absolute;inset:-9px -7px}', '.ed2 input[type=checkbox]:checked{', '.ed2 input[type=checkbox]:active{transform:scale(.88)}']) assert.ok(css.includes(k), k);
  assert.ok(todo.includes("row.className = 'todo'") && todo.includes("setAttribute('type', 'checkbox')"));
});
test('Rev 94: versi 0.3.9', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('RIWAYAT.md').includes('Rev 94 / 0.3.8'));
});
