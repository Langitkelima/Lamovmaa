// Rev 200 / v0.3.121: Kelimaa AI Tahap 1a = Worker kerangka (ping, whoami, usage, batas). Berkas rev205 = Rev 200.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, readdirSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = () => { const m = new Map(); return { m, get: async (k) => m.has(k) ? m.get(k) : null, put: async (k, v) => { m.set(k, v); } }; };
const env0 = () => ({ PASS_RAMA: 'rama-secret-12', PASS_DESY: 'desy-secret-34', KV: kv() });
const post = (b, h = {}) => new Request('https://w.example/', { method: 'POST', body: typeof b === 'string' ? b : JSON.stringify(b), headers: h });
const NOW = Date.UTC(2026, 10, 11, 5, 0, 0);
test('hanya ekspor bawaan (aman untuk Cloudflare)', () => { assert.doesNotMatch(src('backend/cloudflare/worker.mjs'), /^export (async )?function|^export const/m); assert.equal(typeof W.fetch, 'function'); });
test('ping tanpa passcode dan tanpa menyentuh KV', async () => {
  const e = env0(); const r = await W.fetch(new Request('https://w.example/?ping=1'), e); const j = await r.json();
  assert.equal(r.status, 200); assert.deepEqual(j, { ok: true, app: 'KELIMAA AI', v: 1 }); assert.equal(e.KV.m.size, 0);
});
test('whoami: passcode benar menjawab nama; tanpa menulis KV', async () => {
  const e = env0(); const j = await (await T.handle(post({ key: 'desy-secret-34', action: 'whoami' }), e, NOW)).json();
  assert.equal(j.ok, true); assert.equal(j.me, 'desy'); assert.equal(j.limit, 100); assert.equal(j.used, 0); assert.equal(e.KV.m.size, 0);
  assert.equal((await (await T.handle(post({ key: 'rama-secret-12', action: 'whoami' }), e, NOW)).json()).me, 'rama');
});
test('passcode salah / pendek / bukan teks = 401 dan tidak membocorkan kunci', async () => {
  const e = env0();
  for (const k of ['salah-salah-1', 'x', '', 123, null, undefined, 'rama-secret-1']) {
    const r = await T.handle(post({ key: k, action: 'whoami' }), e, NOW); const t = await r.text(); assert.equal(r.status, 401); assert.doesNotMatch(t, /rama-secret|desy-secret/);
  }
});
test('Secret kosong atau kurang dari 8 huruf dianggap belum diatur (503)', async () => {
  assert.deepEqual(T.passList({ PASS_A: 'pendek', PASS_B: '', PASS_C: 5, X: 'abcdefghijkl' }), []);
  const r = await T.handle(post({ key: 'apa-saja-saja', action: 'whoami' }), { PASS_A: 'pendek' }, NOW); assert.equal(r.status, 503);
});
test('banyak percobaan gagal dari satu IP = 429; IP lain tidak terkena; setelah ganti jam pulih', async () => {
  const e = env0(), h = { 'CF-Connecting-IP': '1.2.3.4' };
  for (let i = 0; i < 10; i++) assert.equal((await T.handle(post({ key: 'salah-salah-' + i, action: 'whoami' }, h), e, NOW)).status, 401);
  assert.equal((await T.handle(post({ key: 'rama-secret-12', action: 'whoami' }, h), e, NOW)).status, 429);
  assert.equal((await T.handle(post({ key: 'rama-secret-12', action: 'whoami' }, { 'CF-Connecting-IP': '5.6.7.8' }), e, NOW)).status, 200);
  assert.equal((await T.handle(post({ key: 'rama-secret-12', action: 'whoami' }, h), e, NOW + 3700000)).status, 200);
});
test('permintaan rusak: bukan JSON, larik, terlalu besar, aksi asing, metode lain', async () => {
  const e = env0();
  assert.equal((await T.handle(post('bukan json'), e, NOW)).status, 400);
  assert.equal((await T.handle(post('[1,2]'), e, NOW)).status, 400);
  assert.equal((await T.handle(post({ key: 'rama-secret-12', pad: 'x'.repeat(5000) }), e, NOW)).status, 413);
  assert.equal((await T.handle(post({ key: 'rama-secret-12', action: 'hapus-semua' }), e, NOW)).status, 400);
  assert.equal((await T.handle(new Request('https://w.example/', { method: 'PUT' }), e, NOW)).status, 405);
  assert.equal((await T.handle(new Request('https://w.example/'), e, NOW)).status, 404);
});
test('CORS: hanya asal aplikasi yang diizinkan; OPTIONS 204', async () => {
  const e = env0();
  const a = await T.handle(new Request('https://w.example/?ping=1', { headers: { Origin: 'https://localhost' } }), e, NOW);
  assert.equal(a.headers.get('Access-Control-Allow-Origin'), 'https://localhost');
  const b = await T.handle(new Request('https://w.example/?ping=1', { headers: { Origin: 'https://jahat.example' } }), e, NOW);
  assert.equal(b.headers.get('Access-Control-Allow-Origin'), null);
  assert.equal((await T.handle(new Request('https://w.example/', { method: 'OPTIONS' }), e, NOW)).status, 204);
});
test('batas harian: consume naik sampai batas lalu menolak; tanpa KV ditolak; hari WIB berganti', async () => {
  const e = { ...env0(), DAILY_LIMIT: '3' };
  assert.equal(T.limitOf(e), 3); assert.equal(T.limitOf({}), 100); assert.equal(T.limitOf({ DAILY_LIMIT: 'abc' }), 100); assert.equal(T.limitOf({ DAILY_LIMIT: '999999' }), 10000);
  for (let i = 1; i <= 3; i++) { const r = await T.consume(e, 'rama', NOW); assert.equal(r.ok, true); assert.equal(r.used, i); }
  const x = await T.consume(e, 'rama', NOW); assert.equal(x.ok, false); assert.equal(x.reason, 'limit');
  assert.equal((await T.consume(e, 'desy', NOW)).ok, true); // per orang
  assert.equal((await T.consume({ PASS_A: 'abcdefgh' }, 'rama', NOW)).reason, 'kv');
  assert.equal(T.dayKey(Date.UTC(2026, 10, 11, 16, 59)), '2026-11-11'); assert.equal(T.dayKey(Date.UTC(2026, 10, 11, 17, 0)), '2026-11-12');
  assert.equal((await T.consume(e, 'rama', Date.UTC(2026, 10, 11, 17, 0))).ok, true);
  const j = await (await T.handle(post({ key: 'rama-secret-12', action: 'usage' }), e, NOW)).json(); assert.equal(j.used, 3); assert.equal(j.limit, 3);
});
test('KV rusak tidak menjatuhkan whoami', async () => {
  const e = { PASS_RAMA: 'rama-secret-12', KV: { get: async () => { throw new Error('x'); }, put: async () => { throw new Error('x'); } } };
  const j = await (await T.handle(post({ key: 'rama-secret-12', action: 'whoami' }), e, NOW)).json(); assert.equal(j.ok, true); assert.equal(j.used, null);
});
test('tidak ada rahasia di repo: berkas Worker dan panduan tanpa kunci; kode aplikasi tidak menyentuh AI', () => {
  const w = src('backend/cloudflare/worker.mjs') + src('backend/cloudflare/PANDUAN_WORKER.md');
  assert.doesNotMatch(w, /sk-[A-Za-z0-9]{10,}|AIza[0-9A-Za-z_-]{20,}|Bearer [A-Za-z0-9._-]{20,}/);
  // Rev 201: pelonggaran terarah. Hanya src/js/ai/ (modul AI) yang boleh menyebut workers.dev/KELIMAA AI; settings.js hanya boleh memuat label ubin 'KELIMAA AI'.
  for (const f of readdirSync(new URL('../src/js/', import.meta.url), { recursive: true }).filter((n) => n.endsWith('.js') && !n.startsWith('ai/'))) {
    assert.doesNotMatch(src('src/js/' + f), /backend\/cloudflare|workers\.dev/, f);
    if (f !== 'settings.js') assert.doesNotMatch(src('src/js/' + f), /KELIMAA AI/, f);
  }
});
test('versi sumber 0.3.121 (Rev 201 menaikkan dari 0.3.114), SCHEMA 18, tes terdaftar', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev205\.test\.mjs/);
});
