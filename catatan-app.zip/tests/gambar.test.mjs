// Tes Rev 24C (G1): mesin murni gambar (src/js/gambar.js). Tanpa DOM; modul belum dipanggil aplikasi.
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import * as G from '../src/js/gambar.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const ref = (id, extra = {}) => ({ id, w: 1280, h: 960, b: 183000, x: 'webp', ...extra });
const ID1 = 'abcde12345', ID2 = 'zyxwv98765';

await t('fitSize: sisi terpanjang <= batas, rasio dipertahankan, gambar kecil TIDAK diperbesar', () => {
  assert.deepEqual(G.fitSize(4000, 3000, 1280), { width: 1280, height: 960 });
  assert.deepEqual(G.fitSize(3000, 4000, 1280), { width: 960, height: 1280 });
  assert.deepEqual(G.fitSize(640, 480, 1280), { width: 640, height: 480 });
  assert.deepEqual(G.fitSize(1280, 1280, 1280), { width: 1280, height: 1280 });
  assert.deepEqual(G.fitSize(20000, 10, 1280), { width: 1280, height: 1 }); // sangat lonjong: sisi pendek minimal 1
  for (const bad of [[0, 5], [5, 0], [-1, 5], [NaN, 5], ['x', 5]]) assert.equal(G.fitSize(bad[0], bad[1], 1280), null);
  assert.equal(G.fitSize(5, 5, 0), null);
});
await t('qualityLadder: turun bertahap, berhenti di 0,5, tanpa nilai di bawahnya', () => {
  assert.deepEqual(G.qualityLadder(0.75), [0.75, 0.7, 0.65, 0.6, 0.55, 0.5]);
  assert.deepEqual(G.qualityLadder(0.5), [0.5]);
  assert.deepEqual(G.qualityLadder(0.3), [0.5]);
  assert.equal(Math.max(...G.qualityLadder(2)), 1); assert.ok(Math.min(...G.qualityLadder(0.85)) === 0.5);
});
await t('planCompress Seimbang (foto 108 MP): 1280 px, WebP 0,75, tangga ke 0,5, lalu 1024 px', () => {
  const p = G.planCompress({ w: 12000, h: 9000, bytes: 20e6 });
  assert.equal(p.ok, true); assert.equal(p.width, 1280); assert.equal(p.height, 960); assert.equal(p.maxBytes, 250000);
  assert.equal(p.steps[0].quality, 0.75); assert.equal(p.steps.at(-1).quality, 0.5);
  assert.deepEqual([p.steps.at(-1).width, p.steps.at(-1).height], [1024, 768]);
  assert.equal(p.resized, true); assert.equal(p.upscaled, false);
});
await t('planCompress: gambar kecil tidak diperbesar dan tidak ada langkah perkecil; tetap digambar ulang (EXIF terbuang)', () => {
  const p = G.planCompress({ w: 800, h: 600, bytes: 40000 });
  assert.equal(p.ok, true); assert.deepEqual([p.width, p.height], [800, 600]); assert.equal(p.resized, false);
  assert.ok(p.steps.length >= 1); assert.ok(p.steps.every((s) => s.width === 800 && s.height === 600));
});
await t('planCompress: preset Hemat dan Tajam sesuai spesifikasi; preset aneh jatuh ke Seimbang; ukuran tak sah ditolak', () => {
  const h = G.planCompress({ w: 4000, h: 3000 }, 'hemat'); assert.equal(h.width, 1024); assert.equal(h.steps[0].quality, 0.65); assert.equal(h.maxBytes, 150000);
  const j = G.planCompress({ w: 4000, h: 3000 }, 'tajam'); assert.equal(j.width, 1920); assert.equal(j.steps[0].quality, 0.85); assert.equal(j.maxBytes, 500000);
  assert.equal(G.planCompress({ w: 4000, h: 3000 }, 'ngawur').width, 1280);
  for (const bad of [null, {}, { w: 0, h: 10 }, { w: 'a', h: 10 }]) { const r = G.planCompress(bad); assert.equal(r.ok, false); assert.ok(r.msg); }
});
await t('fitsTarget: <= target lulus, lebih besar atau nilai aneh tidak', () => {
  assert.equal(G.fitsTarget(250000), true); assert.equal(G.fitsTarget(250001), false);
  assert.equal(G.fitsTarget(150000, 'hemat'), true); assert.equal(G.fitsTarget(150001, 'hemat'), false);
  for (const bad of [0, -1, NaN, 'x', null]) assert.equal(G.fitsTarget(bad), false);
});
await t('checkSource: tolak > 30 MB, HEIC, bukan gambar; terima JPG/PNG/WebP', () => {
  assert.equal(G.checkSource({ type: 'image/jpeg', name: 'a.jpg', size: 5e6 }).ok, true);
  assert.equal(G.checkSource({ type: 'image/webp', size: 30 * 1024 * 1024 }).ok, true);
  assert.equal(G.checkSource({ type: 'image/jpeg', size: 30 * 1024 * 1024 + 1 }).reason, 'too_big');
  assert.equal(G.checkSource({ type: 'image/heic', name: 'a.heic', size: 100 }).reason, 'unsupported');
  assert.equal(G.checkSource({ type: '', name: 'IMG.HEIF', size: 100 }).reason, 'unsupported');
  assert.equal(G.checkSource({ type: 'application/pdf', size: 100 }).reason, 'not_image');
  assert.equal(G.checkSource({ type: 'image/png', size: NaN }).ok, false);
  assert.ok(G.checkSource({ type: 'image/heic' }).msg.length > 5);
});
await t('chooseFormat: WebP bila didukung; tanpa WebP, transparan = PNG dan lainnya = JPEG', () => {
  assert.equal(G.chooseFormat({ webp: true }).ext, 'webp'); assert.equal(G.chooseFormat({ webp: true, alpha: true }).ext, 'webp');
  assert.deepEqual(G.chooseFormat({ alpha: true }), { mime: 'image/png', ext: 'png' });
  assert.deepEqual(G.chooseFormat({}), { mime: 'image/jpeg', ext: 'jpg' });
});
await t('newImageId: >= 10 huruf/angka, acak, lolos ID_RE; rng suntikan deterministik; tanpa crypto tetap jalan', () => {
  const a = G.newImageId(), b = G.newImageId();
  assert.match(a, /^[a-z0-9]{16}$/); assert.ok(G.ID_RE.test(a)); assert.notEqual(a, b);
  assert.equal(G.newImageId(() => 0.5), G.newImageId(() => 0.5));
  const set = new Set(Array.from({ length: 500 }, () => G.newImageId())); assert.equal(set.size, 500);
  const c = globalThis.crypto; Object.defineProperty(globalThis, 'crypto', { value: undefined, configurable: true });
  try { assert.match(G.newImageId(), /^[a-z0-9]{16}$/); } finally { Object.defineProperty(globalThis, 'crypto', { value: c, configurable: true }); }
});
await t('buildFigure: sesuai kontrak (figure kosong + paragraf kosong), tanpa <img> dan tanpa byte gambar', () => {
  const f = G.buildFigure(ref(ID1));
  assert.equal(f, `<figure class="ki" contenteditable="false" data-kimg="${ID1}" data-w="1280" data-h="960" data-b="183000" data-x="webp"></figure><p><br></p>`);
  assert.ok(!/<img|base64|data:/i.test(f)); assert.ok(f.length < 300);
  assert.match(G.buildFigure(ref(ID1, { x: 'jpg' })), /data-x="jpg"/);
  assert.match(G.buildFigure(ref(ID1, { x: 'bmp' })), /data-x="webp"/);
});
await t('buildFigure: ID atau ukuran tak sah ditolak (tidak boleh menyuntik atribut/HTML)', () => {
  for (const id of ['pendek', 'ab"onload="x', 'a b c d e f g h i j', '../../etc/passwd1', '<script>alert1', '', null, 5]) assert.equal(G.buildFigure(ref(id)), null);
  for (const bad of [{ w: 0 }, { h: 0 }, { w: NaN }, { h: -4 }]) assert.equal(G.buildFigure(ref(ID1, bad)), null);
  assert.equal(G.buildFigure(null), null); assert.equal(G.buildFigure('x'), null);
  assert.match(G.buildFigure(ref(ID1, { b: 'x' })), /data-b="0"/);
});
await t('parseRefs: bolak-balik dengan buildFigure, urutan terjaga, atribut urutan acak dan tanda kutip tunggal terbaca', () => {
  const html = '<p>a</p>' + G.buildFigure(ref(ID1)) + '<p>teks</p>' + G.buildFigure(ref(ID2, { w: 640, h: 480, b: 9000, x: 'png' }))
    + `<figure data-w='50' data-h='60' class='ki x' data-kimg='abcde99999'></figure>`;
  const r = G.parseRefs(html);
  assert.deepEqual(r.map((x) => x.id), [ID1, ID2, 'abcde99999']);
  assert.deepEqual(r[1], { id: ID2, w: 640, h: 480, b: 9000, x: 'png' });
  assert.deepEqual(r[2], { id: 'abcde99999', w: 50, h: 60, b: 0, x: 'webp' });
});
await t('parseRefs: HTML tanpa gambar/aneh -> kosong; rujukan rusak dilewati; tanpa class ki diabaikan', () => {
  for (const h of ['', '<p>halo</p>', null, undefined, 5, '<figure class="ki"></figure>', '<figure data-kimg="abcde12345" data-w="1" data-h="1"></figure>',
    '<figure class="ki" data-kimg="bad" data-w="1" data-h="1"></figure>', '<figure class="ki" data-kimg="abcde12345" data-w="0" data-h="5"></figure>']) assert.deepEqual(G.parseRefs(h), []);
  const rusak = '<figure class="ki" data-kimg="x"></figure>' + G.buildFigure(ref(ID1)); assert.equal(G.parseRefs(rusak).length, 1);
  assert.deepEqual(G.parseRefs('<figure class="ki" data-kimg="abcde12345" data-w="5" data-h="5" data-x="exe">').map((x) => x.x), ['webp']);
});
await t('usageOf: gambar unik dan total byte; rujukan ganda (salinan) dihitung sekali', () => {
  assert.deepEqual(G.usageOf([]), { count: 0, bytes: 0 }); assert.deepEqual(G.usageOf(null), { count: 0, bytes: 0 });
  assert.deepEqual(G.usageOf([ref(ID1, { b: 100 }), ref(ID2, { b: 50 }), ref(ID1, { b: 100 })]), { count: 2, bytes: 150 });
});
await t('refsOfData: menghitung rujukan dari catatan, privat, DAN sampah (salinan berbagi berkas dengan asli)', () => {
  const data = { notes: [{ html: G.buildFigure(ref(ID1)) }], priv: [{ html: G.buildFigure(ref(ID2)) }],
    trash: [{ kind: 'note', item: { html: G.buildFigure(ref('trash12345')) } }, { kind: 'task', item: { html: G.buildFigure(ref('task123456')) } }] };
  assert.deepEqual(G.refsOfData(data).map((r) => r.id), [ID1, ID2, 'trash12345']);
  assert.deepEqual(G.refsOfData(null), []); assert.deepEqual(G.refsOfData({}), []);
});
await t('findOrphans: hanya yang tak dirujuk DAN lebih tua dari 24 jam; hapus permanen salinan tidak membuang gambar milik asli', () => {
  const NOW = Date.UTC(2026, 10, 1), H = 3600000;
  const files = [{ name: ID1 + '.webp', mtime: NOW - 30 * H }, { name: ID2 + '.jpg', mtime: NOW - 30 * H }, { name: 'baru123456.png', mtime: NOW - 2 * H }, { name: 'tepi1234567.webp', mtime: NOW - 24 * H }];
  assert.deepEqual(G.findOrphans(files, [ref(ID1)], NOW), [ID2 + '.jpg']); // ID2 yatim lama; baru tetap aman; tepat 24 jam belum yatim
  assert.deepEqual(G.findOrphans(files, [ID1, ID2], NOW), []); // rujukan berupa id polos juga diterima
  // Asli dan salinan merujuk berkas yang sama; salinan dihapus permanen, asli masih merujuk -> berkas aman.
  const asli = { notes: [{ html: G.buildFigure(ref(ID1)) }], trash: [] };
  assert.deepEqual(G.findOrphans([files[0]], G.refsOfData(asli), NOW), []);
  // Semua rujukan hilang -> baru berkas jadi yatim.
  assert.deepEqual(G.findOrphans([files[0]], G.refsOfData({ notes: [], trash: [] }), NOW), [ID1 + '.webp']);
});
await t('findOrphans aman-gagal: nama asing, waktu tak jelas, masukan aneh tidak pernah dianggap yatim', () => {
  const NOW = 2e12, old = NOW - 1e9;
  const files = [{ name: 'catatan.txt', mtime: old }, { name: '.nomedia', mtime: old }, { name: 'abc.webp', mtime: old }, { name: ID1 + '.gif', mtime: old },
    { name: ID1 + '.webp' }, { name: ID2 + '.webp', mtime: NaN }, { name: ID2 + '.png', mtime: 0 }, null, {}, { name: 5 }];
  assert.deepEqual(G.findOrphans(files, [], NOW), []);
  assert.deepEqual(G.findOrphans(null, null, NOW), []); assert.deepEqual(G.findOrphans('x', 'y', NOW), []);
});
await t('batas: maksimal 10 per catatan (menolak, memotong, atau menerima), peringatan lembut > 200 MB', () => {
  assert.deepEqual(G.canAddImages(0, 5), { ok: true, allowed: 5, msg: '' });
  assert.deepEqual(G.canAddImages(5, 5), { ok: true, allowed: 5, msg: '' });
  assert.equal(G.canAddImages(10, 1).ok, false); assert.equal(G.canAddImages(10, 1).allowed, 0);
  const cut = G.canAddImages(8, 5); assert.equal(cut.ok, true); assert.equal(cut.allowed, 2); assert.ok(cut.msg);
  assert.equal(G.canAddImages(undefined, 'x').allowed, 0);
  assert.equal(G.totalWarning(200 * 1024 * 1024), ''); assert.ok(G.totalWarning(200 * 1024 * 1024 + 1)); assert.equal(G.totalWarning(NaN), '');
});
await t('mesin gambar tetap murni; G3 memakai melalui gambar-app.js dan editor', () => {
  const s = src('../src/js/gambar.js');
  assert.ok(!/\b(document|window|localStorage|sessionStorage|fetch|XMLHttpRequest|Capacitor|FileReader)\b/.test(s.replace(/\/\/.*$/gm, '')));
  // Rev 45 (G3): modul gambar-app.js dan editor notes.js mengimpor mesin gambar untuk import/tampil.
  for (const f of readdirSync(new URL('../src/js/', import.meta.url)).filter((n) => n.endsWith('.js'))) if (!['gambar.js', 'cadangan-gambar.js', 'gambar-app.js', 'notes.js', 'share.js', 'penampil.js', 'settings.js'].includes(f)) assert.ok(!/from '\.\/gambar\.js'/.test(src('../src/js/' + f)), f + ' tidak boleh mengimpor gambar.js langsung');
  assert.ok(!/gambar\.js/.test(src('../src/index.html')));
});
console.log(n + ' tes lulus (gambar)');
