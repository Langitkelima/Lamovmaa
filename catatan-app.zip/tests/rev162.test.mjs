// Rev 162 / Q10: fungsi rumus tahap 2 kelompok ANGKA (INT MOD POWER SQRT AVERAGEIF LARGE SMALL RANK) dan TEKS (CONCAT LEFT RIGHT MID LEN UPPER LOWER TRIM VALUE)
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import * as S from '../src/js/storage.js';
import { argHint } from '../src/js/rumus-bantu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 9, 0, 0).getTime();
function mk(grid) { const t = L.newTab('T', 12); grid.forEach((row, ri) => row.forEach((v, ci) => { if (v === undefined || v === null) return; L.setCell(t, t.rows[ri].id, t.cols[ci].id, { v }); })); return t; }
function at(grid, f) { const t = mk(grid); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cF = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cF'); }
const calc = (f) => at([], f);
const DATA = [['apel', 'A', 10], ['jeruk', 'A', 20], ['apel', 'B', 30], ['apel', 'A', 5], ['pisang', 'B', 'x']];
const NUMS = [[5], [9], [1], [9], ['teks'], [3]];

test('INT, MOD, POWER, SQRT: nilai, tanda, dan galat seperti Excel', () => {
  assert.equal(calc('=INT(8,9)'), 8); assert.equal(calc('=INT(-1,5)'), -2); assert.equal(calc('=INT(0,1+0,2)'), 0); assert.equal(calc('=INT(\"a\")').e, '#VALUE!');
  assert.equal(calc('=MOD(10;3)'), 1); assert.equal(calc('=MOD(-3;2)'), 1); assert.equal(calc('=MOD(3;-2)'), -1); assert.equal(calc('=MOD(5,5;2)'), 1.5); assert.equal(calc('=MOD(4;2)'), 0); assert.equal(calc('=MOD(5;0)').e, '#DIV/0!');
  assert.equal(calc('=POWER(2;10)'), 1024); assert.equal(calc('=POWER(9;0,5)'), 3); assert.equal(calc('=POWER(0;0)').e, '#NUM!'); assert.equal(calc('=POWER(0;-1)').e, '#DIV/0!'); assert.equal(calc('=POWER(-8;0,5)').e, '#NUM!');
  assert.equal(calc('=SQRT(144)'), 12); assert.equal(calc('=SQRT(0)'), 0); assert.equal(calc('=SQRT(-1)').e, '#NUM!'); assert.equal(calc('=SQRT(\"x\")').e, '#VALUE!');
});
test('AVERAGEIF: rata-rata yang cocok, rentang rata-rata terpisah, tanpa cocok = #DIV/0!, galat menjalar', () => {
  assert.equal(at(DATA, '=AVERAGEIF(A1:A5;\"apel\";C1:C5)'), 15); assert.equal(at(DATA, '=AVERAGEIF(C1:C4;\">5\")'), 20);
  assert.equal(at(DATA, '=AVERAGEIF(A1:A5;\"jeruk\";C1:C5)'), 20); assert.equal(at(DATA, '=AVERAGEIF(A1:A5;\"kiwi\";C1:C5)').e, '#DIV/0!');
  assert.equal(at(DATA, '=AVERAGEIF(A1:A5;\"pisang\";C1:C5)').e, '#DIV/0!'); // C5 teks = tidak dihitung
  assert.equal(at(DATA, '=AVERAGEIF(5;\"a\")').e, '#VALUE!'); assert.equal(at(DATA, '=AVERAGEIF(A1:A5;\"apel\";7)').e, '#VALUE!');
});
test('LARGE, SMALL, RANK: urutan, batas k, teks diabaikan, #NUM! dan #N/A', () => {
  assert.equal(at(NUMS, '=LARGE(A1:A6;1)'), 9); assert.equal(at(NUMS, '=LARGE(A1:A6;3)'), 5); assert.equal(at(NUMS, '=SMALL(A1:A6;1)'), 1); assert.equal(at(NUMS, '=SMALL(A1:A6;4)'), 9);
  assert.equal(at(NUMS, '=LARGE(A1:A6;6)').e, '#NUM!'); assert.equal(at(NUMS, '=SMALL(A1:A6;0)').e, '#NUM!'); assert.equal(at(NUMS, '=LARGE(A1:A6;\"x\")').e, '#VALUE!');
  assert.equal(at(NUMS, '=RANK(9;A1:A6)'), 1); assert.equal(at(NUMS, '=RANK(5;A1:A6)'), 3); assert.equal(at(NUMS, '=RANK(1;A1:A6)'), 5); assert.equal(at(NUMS, '=RANK(1;A1:A6;1)'), 1); assert.equal(at(NUMS, '=RANK(5;A1:A6;1)'), 3);
  assert.equal(at(NUMS, '=RANK(4;A1:A6)').e, '#N/A'); assert.equal(at(NUMS, '=RANK(5;7)').e, '#VALUE!');
  assert.equal(at([[1], ['a']], '=LARGE(A1:A2;1)'), 1); // teks diabaikan
  assert.equal(at([[1], [2]], '=LARGE(A1:A2;1)+LARGE(A1:A2;2)'), 3);
});
test('galat di rentang menjalar ke LARGE/RANK; di AVERAGEIF galat di rentang kriteria = tidak cocok', () => {
  const t = mk([[1], [2], [3]]); t.rows[1].cells.cA = { fx: R.a1ToStored('=1/0', t).fx };
  t.rows[0].cells.cF = { fx: R.a1ToStored('=LARGE(A1:A3;1)', t).fx }; t.rows[1].cells.cF = { fx: R.a1ToStored('=RANK(1;A1:A3)', t).fx }; t.rows[2].cells.cF = { fx: R.a1ToStored('=AVERAGEIF(A1:A3;\">0\")', t).fx };
  const c = R.computeTab(t, { now: NOW }); assert.equal(c.get('r1', 'cF').e, '#DIV/0!'); assert.equal(c.get('r2', 'cF').e, '#DIV/0!'); assert.equal(c.get('r3', 'cF'), 2); // galat di rentang KRITERIA = tidak cocok (seperti SUMIF/Excel), jadi hanya 1 dan 3 yang dirata-rata
});
test('AVERAGEIF membaca rentang_rata2 yang berbeda lewat urutan hitung (ketergantungan seperti SUMIF)', () => {
  const t = mk([['a', 1], ['a', 3], ['b', 100]]); t.rows[1].cells.cB = { fx: R.a1ToStored('=A1&\"\"', t).fx }; // sel B2 berumus tidak dipakai di rata-rata
  t.rows[2].cells.cB = { fx: R.a1ToStored('=10+20', t).fx }; // B3 berumus = 30
  t.rows[0].cells.cF = { fx: R.a1ToStored('=AVERAGEIF(A1:A3;\"b\";B1:B3)', t).fx };
  assert.equal(R.computeTab(t, { now: NOW }).get('r1', 'cF'), 30);
  const t2 = mk([['a', 1], ['b', 0]]); t2.rows[0].cells.cF = { fx: R.a1ToStored('=AVERAGEIF(A1:A2;\"a\";H1:H2)', t2).fx }; t2.rows[0].cells.cH = { fx: R.a1ToStored('=2*3', t2).fx };
  assert.equal(R.computeTab(t2, { now: NOW }).get('r1', 'cF'), 6);
});
test('CONCAT: teks, angka, rentang sel demi sel, galat menjalar, batas 2000', () => {
  assert.equal(calc('=CONCAT(\"a\";\"b\";1;2,5;TRUE)'), 'ab12.5TRUE'); assert.equal(at(DATA, '=CONCAT(A1:B2)'), 'apelAjerukA'); assert.equal(at(DATA, '=CONCAT(A1;\"-\";C1)'), 'apel-10');
  assert.equal(calc('=CONCAT(\"a\";1/0)').e, '#DIV/0!'); assert.equal(calc('=CONCAT(\"\")'), '');
  assert.equal(calc('=CONCAT(REPT)').rejected !== undefined, true);
  assert.equal(at([[ 'x'.repeat(1500) ], [ 'y'.repeat(600) ]], '=CONCAT(A1:A2)').e, '#VALUE!');
});
test('LEFT, RIGHT, MID, LEN: bawaan, batas, titik kode (emoji = 1), galat', () => {
  assert.equal(calc('=LEFT(\"Kelimaa\")'), 'K'); assert.equal(calc('=LEFT(\"Kelimaa\";4)'), 'Keli'); assert.equal(calc('=LEFT(\"ab\";10)'), 'ab'); assert.equal(calc('=LEFT(\"ab\";0)'), ''); assert.equal(calc('=LEFT(\"ab\";-1)').e, '#VALUE!');
  assert.equal(calc('=RIGHT(\"Kelimaa\")'), 'a'); assert.equal(calc('=RIGHT(\"Kelimaa\";3)'), 'maa'); assert.equal(calc('=RIGHT(\"ab\";10)'), 'ab'); assert.equal(calc('=RIGHT(\"ab\";0)'), ''); assert.equal(calc('=RIGHT(12345;2)'), '45');
  assert.equal(calc('=MID(\"Kelimaa\";3;3)'), 'lim'); assert.equal(calc('=MID(\"abc\";2;99)'), 'bc'); assert.equal(calc('=MID(\"abc\";5;2)'), ''); assert.equal(calc('=MID(\"abc\";0;2)').e, '#VALUE!'); assert.equal(calc('=MID(\"abc\";1;-1)').e, '#VALUE!');
  assert.equal(calc('=LEN(\"Kelimaa\")'), 7); assert.equal(calc('=LEN(\"\")'), 0); assert.equal(calc('=LEN(123,5)'), 5); assert.equal(calc('=LEN(\"a😀b\")'), 3); assert.equal(calc('=LEFT(\"😀ab\";1)'), '😀');
  assert.equal(at(DATA, '=LEN(A1:A2)').e, '#VALUE!'); assert.equal(calc('=LEN(1/0)').e, '#DIV/0!');
});
test('UPPER, LOWER, TRIM, VALUE', () => {
  assert.equal(calc('=UPPER(\"Kelimaa\")'), 'KELIMAA'); assert.equal(calc('=LOWER(\"KeLiMaa\")'), 'kelimaa'); assert.equal(calc('=UPPER(12)'), '12');
  assert.equal(calc('=TRIM(\"  a   b  c  \")'), 'a b c'); assert.equal(calc('=TRIM(\"\")'), '');
  assert.equal(calc('=VALUE(\"12,5\")'), 12.5); assert.equal(calc('=VALUE(\"12.5\")'), 12.5); assert.equal(calc('=VALUE(\" 7 \")'), 7); assert.equal(calc('=VALUE(\"25%\")'), 0.25); assert.equal(calc('=VALUE(\"x\")').e, '#VALUE!'); assert.equal(calc('=VALUE(\"\")').e, '#VALUE!'); assert.equal(calc('=VALUE(TRUE)').e, '#VALUE!'); assert.equal(calc('=VALUE(3)'), 3); assert.equal(calc('=VALUE(\"Rp 10\")').e, '#VALUE!');
  assert.equal(calc('=VALUE(LEFT(\"45abc\";2))+1'), 46);
});
test('daftar fungsi: 39 fungsi, semua punya sig + ket + petunjuk argumen; saran huruf awal', () => {
  const names = R.FUNCTION_LIST.map((f) => f.name); assert.equal(names.length, 53);
  for (const n of ['INT', 'MOD', 'POWER', 'SQRT', 'AVERAGEIF', 'LARGE', 'SMALL', 'RANK', 'CONCAT', 'LEFT', 'RIGHT', 'MID', 'LEN', 'UPPER', 'LOWER', 'TRIM', 'VALUE']) { assert.ok(names.includes(n), n); const a = argHint(n, 0); assert.ok(a && a.sig.startsWith(n + '(') && a.ket, n); }
  assert.equal(names.includes('TEXT'), true); /* Rev 164 menambah TEXT */ assert.deepEqual(R.suggestFunctions('co').map((f) => f.name), ['CONCAT', 'COUNT', 'COUNTA', 'COUNTIF', 'COUNTIFS']);
  assert.deepEqual(R.suggestFunctions('l').map((f) => f.name), ['LARGE', 'LEFT', 'LEN', 'LOWER']);
});
test('rumus tersimpan dan terbaca balik; nama lama tetap; fungsi tak dikenal ditolak', () => {
  const t = mk([[1]]); const r = R.a1ToStored('=CONCAT(LEFT(A1;1);MID(\"abc\";2;1))', t); assert.ok(r.ok); assert.equal(R.storedToA1(r.fx, t), '=CONCAT(LEFT(A1;1);MID("abc";2;1))');
  assert.match(R.a1ToStored('=XTEXT(1;\"0\")', t).error, /tidak dikenal/i); // Rev 164: TEXT kini dikenal, pakai nama lain
});
test('Rev 162: mesin rumus tetap murni (tanpa DOM/impor); SCHEMA 17; versi 0.3.121; tes terdaftar', () => {
  const m = src('src/js/rumus.js'); assert.doesNotMatch(m, /document|window|localStorage|eval\(|new Function|^import /m);
  assert.equal(S.SCHEMA, 22); const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev162.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
