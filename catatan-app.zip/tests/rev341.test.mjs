// Rev 341 / PART I8: `!jam 9` di baris kotak centang = saran satu ketukan yang membuka lembar Ingatkan saya terisi (tidak menjadwalkan langsung).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
globalThis.document = { createElement: () => ({ setAttribute() {}, addEventListener() {}, append() {}, className: '' }), createTextNode: (t) => ({ nodeType: 3, data: t }) };
const { remindFor } = await import('../src/js/ketik-ui.js');
const NOW = new Date(2026, 10, 18, 10, 0, 0).getTime(); // Rabu 18 Nov 2026 10.00

test('remindFor: jam, besok, hari, tanggal (spasi nbsp diterima)', () => {
  let r = remindFor('beli susu !jam 15', NOW); assert.equal(r.label, 'Hari ini 15.00'); assert.equal(r.when, new Date(2026, 10, 18, 15, 0).getTime()); assert.equal(r.hasTime, true);
  r = remindFor('!besok 9', NOW); assert.equal(r.label, 'Besok 09.00'); assert.equal(r.when, new Date(2026, 10, 19, 9, 0).getTime());
  r = remindFor('x !jumat 14.30', NOW); assert.equal(r.label, 'Jumat 14.30'); assert.equal(r.when, new Date(2026, 10, 20, 14, 30).getTime());
  r = remindFor('!15 des', NOW); assert.equal(r.hasTime, false); assert.equal(r.when, r.when);
  r = remindFor('x\u00a0!jam\u00a09', NOW); assert.ok(r, 'nbsp dianggap spasi');
});
test('remindFor: bukan pemicu = null (seru biasa, tanpa waktu, tidak ada kata kunci, bukan teks)', () => {
  for (const l of ['Halo! jam 9', '!', '!jam', '!halo 9', '!jam 99', 'selesai!', '', 'tanpa seru']) assert.equal(remindFor(l, NOW), null, JSON.stringify(l));
  assert.equal(remindFor(null, NOW), null); assert.equal(remindFor(5, NOW), null);
});
test('remindFor: waktu lampau TIDAK digeser (lembar yang memutuskan lewat checkChoice)', () => {
  const r = remindFor('!jam 8', NOW); assert.equal(r.when, new Date(2026, 10, 18, 8, 0).getTime()); assert.ok(r.when < NOW);
});
test('sumber ketik-ui.js: hanya baris .todo, membuka lembar (bukan menjadwalkan), teks pemicu tetap, hide sebelum open', () => {
  const k = read('src/js/ketik-ui.js');
  assert.match(k, /el\.closest\('\.todo,li'\)/); /* Rev 348 / R3: + li */ assert.match(k, /env\.remind\.open\(r\.row, r\.when\)/);
  assert.match(k, /if \(r\.kind === 'remind'\) \{ hide\(\); env\.remind\.open/);
  assert.ok(!/setCbRule|scheduleAlarm|cb-alarm/.test(k), 'modul tampilan tidak menjadwalkan sendiri');
  assert.match(k, /isBang/);
});
test('sumber notes.js: lembar terisi lewat presetAt, tetap checkChoice, hanya catatan biasa, gerbang pemuat untuk `!` di .todo', () => {
  const n = read('src/js/notes.js');
  assert.match(n, /const openRemindSheet = \(row, presetAt\) =>/);
  assert.match(n, /Number\.isFinite\(presetAt\) && presetAt > 0/);
  assert.match(n, /const remind = \{ open: \(row, at\) =>/);
  assert.match(n, /closest\('\.todo,li'\)\); \/\/ Rev 341/); /* Rev 348 / R3: + li */
  assert.match(n, /pasangKetik\(\{ ed, flushHist, tags, slash, remind(?:, wiki)? \}\)/ /* Rev 343: + wiki */);
  assert.match(n, /if \(!isP\) \{ \/\/ Rev 337/, 'blok ketikan hanya di catatan biasa');
  const i = n.indexOf('const doSave = () => {\n      const at = pick ? pick.at : 0;'); assert.ok(i > 0); assert.match(n.slice(i, i + 200), /checkChoice\(at, repeat, Date\.now\(\)\)/);
});
