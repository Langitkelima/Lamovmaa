// Rev 45 / G3: kontrak integrasi import, simpan berkas, lazy-load, hapus, dan Bagikan.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as G from '../src/js/gambar.js';
import { writeImage, readImageBlob, compressImage, sourceDimensions } from '../src/js/gambar-app.js';
let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const ID = 'g3image123456789';
const ref = { id: ID, w: 640, h: 480, b: 4, x: 'webp' };
await t('tulis gambar membuat folder dan menyimpan byte sebagai base64 di Directory.Data/gambar', async () => {
  const calls = [], fs = { async mkdir(a) { calls.push(['mkdir', a]); }, async writeFile(a) { calls.push(['write', a]); } };
  await writeImage(fs, ref, new Blob([new Uint8Array([1,2,3,4])], { type: 'image/webp' }));
  assert.equal(calls[0][0], 'mkdir'); assert.equal(calls[1][1].path, G.imagePath(ref));
  assert.equal(calls[1][1].directory, 'DATA'); assert.equal(atob(calls[1][1].data).length, 4);
});
await t('baca gambar menghasilkan Blob dari berkas terpisah', async () => {
  const fs = { async readFile(a) { assert.equal(a.path, G.imagePath(ref)); return { data: btoa('\x01\x02\x03\x04') }; } };
  const b = await readImageBlob(fs, ref); assert.equal(b.type, 'image/webp'); assert.deepEqual([...new Uint8Array(await b.arrayBuffer())], [1,2,3,4]);
});
await t('dimensi sumber dibaca dari header PNG, JPEG, dan WebP tanpa decode bitmap', async () => {
  const png = new Uint8Array(24); png.set([137,80,78,71,13,10,26,10]); new DataView(png.buffer).setUint32(16, 1920); new DataView(png.buffer).setUint32(20, 1080);
  assert.deepEqual(await sourceDimensions(new Blob([png])), { w: 1920, h: 1080 });
  const jpg = new Uint8Array([255,216,255,192,0,17,8,1,224,2,128,3,1,17,0,2,17,0,3,17,0]);
  assert.deepEqual(await sourceDimensions(new Blob([jpg])), { w: 640, h: 480 });
  const webp = new Uint8Array(30); webp.set([...new TextEncoder().encode('RIFF')],0); webp.set([...new TextEncoder().encode('WEBP')],8); webp.set([...new TextEncoder().encode('VP8X')],12); webp[24]=0x7F; webp[25]=0x04; webp[27]=0x37; webp[28]=0x04;
  assert.deepEqual(await sourceDimensions(new Blob([webp])), { w: 1152, h: 1080 });
});
await t('kompres menolak HEIC, non-gambar, dan sumber di atas 30 MB sebelum decode', async () => {
  await assert.rejects(compressImage({ type: 'image/heic', name: 'a.heic', size: 10 }), /HEIC/);
  await assert.rejects(compressImage({ type: 'text/plain', name: 'a.txt', size: 10 }), /bukan gambar/);
  await assert.rejects(compressImage({ type: 'image/jpeg', name: 'a.jpg', size: 31 * 1024 * 1024 }), /30 MB/);
});
await t('editor: tombol Gambar hanya untuk catatan biasa, input multi-pilih, progress, limit, Undo, hapus, dan lazy-load', () => {
  const s = src('../src/js/notes.js');
  for (const x of ["insertBtn('image'", "accept: 'image/*'", 'multiple: \'multiple\'', 'Memproses ', 'G.canAddImages', 'flushHist()', 'hydrateImages', "tOk('Gambar dihapus'"]) assert.ok(s.includes(x), x);
  assert.match(s, /isP \? \[\] : \[insertBtn\('image'/);
  assert.ok(s.includes('URL.revokeObjectURL'));
  assert.ok(s.includes("'gambar ×' + imageCount"));
  assert.ok(s.includes('n.html || n.reminder'));
  assert.ok(src('../src/js/share.js').includes('n.title || n.text || n.html'));
});
await t('sanitize mengizinkan hanya figure.ki dengan ID, dimensi, byte, dan ekstensi yang dibatasi', () => {
  const s = src('../src/js/notes.js');
  for (const x of ['FIGURE', "c.tagName === 'FIGURE' && k === 'data-kimg'", "c.tagName === 'FIGURE' && k === 'data-x'"]) assert.ok(s.includes(x));
});
await t('pembersihan yatim dipanggil saat mulai dan setelah pengosongan tempat sampah', () => {
  assert.ok(src('../src/js/main.js').includes('cleanupOrphanImages(data)'));
  assert.ok(src('../src/js/settings.js').includes('cleanupOrphanImages(data)'));
});
await t('Bagikan PDF/JPG memuat bitmap gambar, teks biasa memakai penanda [gambar]', () => {
  const s = src('../src/js/share.js');
  assert.ok(s.includes('loadShareImages(n)'));
  assert.ok(s.includes('renderPages(n, PDF, true, MAX_PDF_PAGES, alive, images)'));
  assert.ok(s.includes('renderPages(n, JPG, false, MAX_JPG_PARTS, alive, images)'));
  assert.ok(s.includes("g.fillText('[gambar]'"));
});
console.log(`${n} tes lulus (G3)`);
