// Rev 362 / PART W2: penerapan tebal `*x*` / miring `_x_` gaya WhatsApp di editor (tampilan = ketik-ui.js, mesin = format-wa.js). Perilaku DOM nyata diaudit di Chromium: tools/audit_format_wa_362.py.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const k = read('src/js/ketik-ui.js'), n = read('src/js/notes.js');

test('ketik-ui.js: waApply memakai mesin W1, hanya karakter pemicu, hanya simpul teks di luar BLOCKED, IME dilewati', () => {
  assert.match(k, /import \{ pairsClosedBefore, resolveLine, isTriggerChar \} from '\.\/format-wa\.js'/);
  const w = k.slice(k.indexOf('const waApply'), k.indexOf('const undoWa'));
  assert.match(w, /waTyped\(e\)/); assert.match(w, /busy \|\| composing/); assert.match(w, /BLOCKED/); assert.match(w, /pairsClosedBefore\(ctx, ctx\.length\)/);
  assert.match(w, /p\.open < base/, 'pasangan lintas simpul dilewati (W3)');
  assert.match(w, /createElement\('b'\)/); assert.match(w, /createElement\('i'\)/);
  assert.match(w, /flushHist\(\)[\s\S]*flushHist\(\)/, 'format = langkah Urungkan sendiri');
  const t = k.slice(k.indexOf('const waTyped'), k.indexOf('const waApply'));
  assert.match(t, /inputType === 'insertText'/); assert.match(t, /isComposing/); assert.match(t, /e\.data\.length === 1/);
});
test('ketik-ui.js: Backspace tepat sesudah format mengembalikan teks mentah (undoWa), dipasang lewat onBefore capture; wa diekspor', () => {
  const u = k.slice(k.indexOf('const undoWa'), k.indexOf('function destroy'));
  assert.match(u, /anchorOffset !== 1/); assert.match(u, /l\.nodes\.forEach\(\(n\) => n\.remove\(\)\)/); assert.match(u, /l\.seg/);
  assert.match(k, /last\.kind === 'wa' \? undoWa\(\) : undoFmt\(\)/);
  assert.match(k, /if \(!\(spaceTyped && format\(\)\)\) waApply\(e\)/);
  assert.match(k, /format, wa: waApply/);
});
test('notes.js: gerbang murah inWa memuat modul malas; sesudah dimuat memanggil kt.wa(ev); modul TIDAK diimpor statis; Privat tidak ikut', () => {
  assert.match(n, /const inWa = \/\[\*_\]\[ \\u00a0\.,;:!\?\)\]\$\/\.test\(nd\.data\.slice\(0, sl\.anchorOffset\)\)/);
  assert.match(n, /if \(inTodoBang \|\| inWiki \|\| inWa\)/);
  assert.match(n, /if \(!kt\.format\(\)\) kt\.wa\(ev\)/);
  assert.ok(!/^import .*format-wa/m.test(n)); assert.ok(!/format-wa/.test(n));
  assert.ok(!/^import .*ketik-ui/m.test(n));
  assert.match(n.slice(n.indexOf('Rev 337 / I4 + Rev 338') - 40, n.indexOf('Rev 337 / I4 + Rev 338')), /if \(!isP\)/);
});
test('format-wa.js tetap murni dan hanya ketik-ui.js yang mengimpornya; tebal/miring memakai tag yang sama dengan tombol bilah (b, i di FMT_TAGS)', () => {
  const users = ['main.js', 'startup.js', 'notes.js', 'privat.js', 'ui.js', 'export.js'].filter((f) => /format-wa/.test(read('src/js/' + f)));
  assert.deepEqual(users, []);
  assert.match(k, /const FMT_TAGS = \/\^\(DIV\|P\|SPAN\|B\|I\|U\|S\|STRONG\|EM\|STRIKE\|FONT\)\$\//);
});
test('anggaran dinaikkan ATAS IZIN PENGGUNA (19 Nov 2026): JS buka 792.000, jsMaks 1520, totalMaks 2040, cssMaks 270; tes terdaftar; versi dan SCHEMA tetap', () => {
  assert.match(read('tests/rev193.test.mjs'), /tot < 810000/); assert.match(read('tests/rev194.test.mjs'), /tot < 810000/);
  assert.match(read('tools/audit-ukuran.mjs'), /cssMaks: 270 \* 1024, jsMaks: 1600 \* 1024, totalMaks: 2100 \* 1024/);
  const pk = JSON.parse(read('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev362\.test\.mjs/);
  assert.match(read('src/js/storage.js'), /SCHEMA = 22/);
});
