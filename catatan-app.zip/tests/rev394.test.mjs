// Rev 394 / PART SM2+SM3 (digabung): mode alarm PER SUB-TUGAS, sakelar varian B di panel pengingat sub-tugas. Perilaku HP belum diuji.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import { cleanSubs, cleanSubReminder, withMode } from '../src/js/logic.js';
import { scheduleSubReminder } from '../src/js/reminders.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('model: sub-tugas campuran notifikasi dan alarm tetap utuh lewat cleanSubs', () => {
  const at = Date.now() + 3600e3;
  const subs = cleanSubs([{ id: 'a', title: 'A', reminder: { at, repeat: 'once', mode: 'alarm' } }, { id: 'b', title: 'B', reminder: { at, repeat: 'daily' } }, { id: 'c', title: 'C' }]);
  assert.equal(subs[0].reminder.mode, 'alarm'); assert.equal(subs[1].reminder.mode, undefined); assert.equal(subs[1].reminder.repeat, 'daily'); assert.equal(subs[2].reminder, undefined);
  assert.deepEqual(cleanSubReminder({ at, repeat: 'once', mode: 'xyz' }), { at, repeat: 'once' });
  assert.deepEqual(withMode({ at, repeat: 'once' }, 'alarm'), { at, repeat: 'once', mode: 'alarm' });
});
test('penjadwal: tiap sub-tugas memakai modenya sendiri (alarm lewat scheduleAlarm, notifikasi lewat scheduleNotification)', () => {
  const calls = []; const at = Date.now() + 3600e3;
  globalThis.AndroidAPI = { scheduleNotification: (...x) => { calls.push(['notif', x[0]]); return true; }, scheduleAlarm: (...x) => { calls.push(['alarm', x[0]]); return true; }, canUseFullScreenAlarm: () => true };
  try {
    const task = { id: 't1', title: 'T' };
    scheduleSubReminder(task, { id: 's1', title: 'S1', reminder: { at, repeat: 'once', mode: 'alarm' } });
    scheduleSubReminder(task, { id: 's2', title: 'S2', reminder: { at, repeat: 'once' } });
  } finally { delete globalThis.AndroidAPI; }
  assert.deepEqual(calls.map((c) => c[0]), ['alarm', 'notif']);
});
test('main.js: tidak ada lagi penimpaan mode ke semua sub-tugas; rmode hanya dari pengingat tugas sendiri; modePick + subMode per sub-tugas; pemilih tugas disembunyikan di mode per sub-tugas', () => {
  const m = rd('src/js/main.js');
  assert.ok(!m.includes('if (subsMode) draft.forEach((x) => { if (x.reminder) x.reminder = withMode('));
  assert.ok(m.includes("let rmode = item && item.reminder && item.reminder.mode === 'alarm' ? 'alarm' : 'notif';"));
  assert.ok(!/item\.subs\.some\(\(x\) => x\.reminder && x\.reminder\.mode === 'alarm'\)/.test(m));
  for (const k of ['modePick = new Map()', 'const subMode = () =>', "A.modeSwitch({ mode: subMode()", 'msw ? msw.el : null', "if (mp) mp.el.style.display = em === 'subs'", "' · alarm'"]) assert.ok(m.includes(k), k);
});
test('alarm-ui.js: modeSwitch (role=switch, aria-checked, Alarm berdering + keterangan), memanggil askFullScreen / peringatan APK lama hanya saat DINYALAKAN; modul tetap malas', () => {
  const a = rd('src/js/alarm-ui.js'); const b = a.slice(a.indexOf('export function modeSwitch'));
  for (const k of ["role: 'switch'", "'aria-checked'", "'Alarm berdering'", 'Berdering sampai dimatikan.', "if (cur === 'alarm')", 'alarmUnsupported(a)', 'askFullScreen(a)', 'onChange(cur)']) assert.ok(b.includes(k), k);
  const m = rd('src/js/main.js'); assert.ok(!/^import .* from '\.\/alarm-ui\.js'/m.test(m)); assert.equal((m.match(/import\('\.\/alarm-ui\.js'\)/g) || []).length, 1);
});
test('CSS: blok Rev 394 hanya variabel tema (tanpa warna mentah) dan anggaran CSS 270 KB utuh; SCHEMA 22; versi 0.3.121', () => {
  const css = rd('src/css/styles.css'); const blk = css.slice(css.indexOf('Rev 394 / SM3')); assert.ok(blk.includes('.am-sw') && !/#[0-9a-fA-F]{3,6}\b/.test(blk));
  assert.ok(css.length < 270 * 1024); assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/); assert.equal(JSON.parse(rd('package.json')).version, '0.3.121');
});
test('banner Rev 394 paling atas (di atas Rev 393), PART SM2, varian B, BELUM TERBUKTI, BERFUNGSI-BELUM-DIUJI; bagian BZ 12 butir; 38.19; tes terdaftar sesudah rev393', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) {
    const d = rd(f); assert.ok(/^\*\*Rev (?:39\d|4[0-3]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 394 /') < d.indexOf('**Rev 393 /'), f);
    const b = d.slice(d.indexOf('**Rev 394 /'), d.indexOf('**Rev 393 /')); for (const k of ['PART SM2', 'varian B', 'BELUM TERBUKTI', 'BERFUNGSI-BELUM-DIUJI', 'audit_sub_alarm_394.py']) assert.ok(b.includes(k), f + ' ' + k);
  }
  const u = rd('UJI_HP_RILIS.md'); const z = u.slice(u.indexOf('## BZ.')); for (let i = 1; i <= 12; i++) assert.ok(z.includes('\n' + i + '. '), 'butir ' + i); assert.ok(z.includes('terang DAN gelap'));
  assert.ok(rd('PROMPT_SERAH_TERIMA.md').includes('**38.19 STATUS PENUTUP (Rev 394)'));
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.indexOf('rev393.test.mjs') < t.indexOf('rev394.test.mjs'));
});
