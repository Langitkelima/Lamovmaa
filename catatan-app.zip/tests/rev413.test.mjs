// Rev 413: penutup Paket Sync (S4). Memastikan audit, bagian uji HP, dan banner tercatat.
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { strict as assert } from 'node:assert';
const rd = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
test('banner Rev 413 di atas Rev 412 di RIWAYAT dan PROMPT', () => {
  for (const f of ['RIWAYAT.md', 'PROMPT_SERAH_TERIMA.md']) { const d = rd(f); assert.ok(d.indexOf('**Rev 413 /') < d.indexOf('**Rev 412 /'), f); }
});
test('audit Sync ada dan bagian CE ada di UJI_HP_RILIS', () => {
  assert.ok(rd('tools/audit_sync_412.py').includes('sysheet'));
  assert.ok(rd('UJI_HP_RILIS.md').includes('## CE. Sync'));
  assert.match(JSON.parse(rd('package.json')).scripts.test, /node tests\/rev413\.test\.mjs/);
});
