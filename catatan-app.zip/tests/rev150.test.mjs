// Rev 150 / U10a: geser urutan tab lembar kerja
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
const mk = (n) => { const sh = L.newSheet({ name: 'A' }); for (let i = 1; i < n; i++) L.addTab(sh); return sh; };
test('moveTab: geser kiri/kanan menukar urutan, ID tetap', () => {
  const sh = mk(3), ids = sh.tabs.map((t) => t.id);
  assert.equal(L.moveTab(sh, ids[0], 1), true); assert.deepEqual(sh.tabs.map((t) => t.id), [ids[1], ids[0], ids[2]]);
  assert.equal(L.moveTab(sh, ids[2], -1), true); assert.deepEqual(sh.tabs.map((t) => t.id), [ids[1], ids[2], ids[0]]);
});
test('moveTab: di ujung/tidak ada/satu tab = false, tidak mengubah apa pun', () => {
  const sh = mk(3), ids = sh.tabs.map((t) => t.id), before = JSON.stringify(sh);
  assert.equal(L.moveTab(sh, ids[0], -1), false); assert.equal(L.moveTab(sh, ids[2], 1), false); assert.equal(L.moveTab(sh, 'zzz', 1), false);
  assert.equal(JSON.stringify(sh), before);
  const one = mk(1); assert.equal(L.moveTab(one, one.tabs[0].id, 1), false);
});
test('moveTab: isi tab, rumus, aturan tidak tersentuh; lolos pembersihan simpan/muat', () => {
  const sh = mk(2); const [a, b] = sh.tabs; L.setCell(a, 'r1', 'cA', { v: 5 }); L.setCell(b, 'r1', 'cA', { v: 7 });
  L.moveTab(sh, a.id, 1); assert.equal(sh.tabs[0].name, b.name);
  const clean = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.deepEqual(clean.tabs.map((t) => t.id), [b.id, a.id]);
});
test('kontrak kode: UI lewat lembar.js, satu hist.push sesudah snapshot, tanpa penyimpanan langsung', () => {
  const ui = src('js/lembar-ui.js'), i = ui.indexOf('L.moveTab(sheet, t.id, d)');
  assert.ok(i > 0); assert.ok(ui.lastIndexOf('const snap = ser()', i) > ui.lastIndexOf("class: 'lz-tabmove'"));
  assert.ok(ui.slice(i, i + 140).includes('hist.push(snap)') && ui.slice(i, i + 140).includes('paintTabs()'));
  assert.ok(ui.includes('Geser kiri') && ui.includes('Geser kanan') && ui.includes('lz-deltab'));
  assert.ok(!/localStorage|persist\(|eval\(|new Function|Capacitor/.test(ui));
  assert.match(src('css/styles.css'), /Rev 150 \/ U10a/);
});
test('Rev 150: versi 0.3.121, SCHEMA 15 tetap, tes terdaftar', () => {
  const pk = readFileSync(new URL('../package.json', import.meta.url), 'utf8');
  assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev150.test.mjs')); assert.match(src('js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
