// Rev 210a: Gemini 503 (kelebihan beban) dicoba ulang otomatis + model cadangan; pesan penyedia tidak lagi dibuang. Fetch PALSU, tanpa jaringan/kunci asli.
import test from 'node:test'; import assert from 'node:assert/strict';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t;
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), GEMINI_KEY: 'AIza-FAKE-0123456789', RETRY_MS: [0, 0], ...x });
const NOW = Date.UTC(2026, 10, 11, 5, 0, 0);
const post = (b) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify(b) });
const req = (o = {}) => ({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', provider: 'gemini', model: 'gemini-3.5-flash', limit: 0, messages: [{ role: 'user', content: 'Halo' }], ...o });
const res = (status, o) => ({ ok: status < 400, status, json: async () => o });
const good = () => res(200, { choices: [{ message: { content: 'Halo juga!' }, finish_reason: 'stop' }], usage: { prompt_tokens: 3, completion_tokens: 2 } });
const busy = () => res(503, [{ error: { code: 503, message: 'The model is overloaded. Please try again later.', status: 'UNAVAILABLE' } }]);
async function run(env, b, seq) {
  const calls = []; const orig = globalThis.fetch; globalThis.fetch = async (url, init) => { const body = JSON.parse(init.body); calls.push(body.model); return seq(calls.length, body.model); };
  try { const r = await T.handle(post(b), env, NOW); return { status: r.status, j: await r.json(), calls }; } finally { globalThis.fetch = orig; }
}

test('503 sekali lalu berhasil: dicoba ulang dengan model yang sama, tanpa beralih model', async () => {
  const r = await run(env0(), req(), (n) => (n === 1 ? busy() : good()));
  assert.equal(r.j.ok, true); assert.equal(r.j.text, 'Halo juga!'); assert.deepEqual(r.calls, ['gemini-3.5-flash', 'gemini-3.5-flash']); assert.equal(r.j.model, 'gemini-3.5-flash'); assert.equal(r.j.fallbackFrom, undefined);
});
test('503 terus pada model pilihan: pindah ke model cadangan Gemini dan melapor model yang dipakai', async () => {
  const r = await run(env0(), req(), (n, m) => (m === 'gemini-3.5-flash' ? busy() : good()));
  assert.equal(r.j.ok, true); assert.deepEqual(r.calls, ['gemini-3.5-flash', 'gemini-3.5-flash', 'gemini-3.5-flash', 'gemini-3.5-flash-lite']);
  assert.equal(r.j.model, 'gemini-3.5-flash-lite'); assert.equal(r.j.fallbackFrom, 'gemini-3.5-flash');
});
test('semua gagal 503: pesan jelas memuat pesan asli penyedia (bukan hanya "kode 503"); jatah dihitung SEKALI', async () => {
  const e = env0({ }); const r = await run(e, req({ limit: 5 }), () => busy());
  assert.equal(r.status, 503); assert.match(r.j.error, /kelebihan beban/); assert.match(r.j.error, /overloaded/); assert.equal(r.calls.length, 4);
  assert.equal(e.KV.m.get('use:rama:2026-11-11'), '1');
});
test('galat bukan sementara (401/404) tidak dicoba ulang dan tidak pindah model', async () => {
  for (const st of [401, 404, 400]) { const r = await run(env0(), req(), () => res(st, { error: { message: 'x' } })); assert.equal(r.calls.length, 1, String(st)); }
});
test('jalur selain Gemini tidak punya model cadangan: hanya coba ulang model yang sama', async () => {
  const r = await run(env0({ SAKELAR_KEY: 'sk-FAKE-0123456789-tes' }), req({ provider: 'sakelar', model: 'deepseek/deepseek-v4-flash' }), () => res(503, { error: { message: 'down' } }));
  assert.equal(r.calls.length, 3); assert.ok(r.calls.every((m) => m === 'deepseek/deepseek-v4-flash')); assert.equal(r.status, 503);
});
test('model cadangan sama dengan pilihan pengguna: tidak diulang lagi', async () => {
  const r = await run(env0(), req({ model: 'gemini-3.5-flash-lite' }), () => busy());
  assert.equal(r.calls.length, 3);
});
test('providerError membaca galat berbentuk array', () => {
  const u = T.providerError('gemini', 400, [{ error: { message: 'bad thing' } }]); assert.match(u.error, /bad thing/);
});
