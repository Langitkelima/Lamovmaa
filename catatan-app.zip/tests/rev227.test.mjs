// Rev 227: balasan AI bergaya (Markdown + tag HTML liar -> tebal/miring sungguhan) dan dialog simpan baru. Pengurai MURNI, tanpa DOM.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as M from '../src/js/ai/markdown.js';
import * as A from '../src/js/ai/aksi.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const RAW = '1. **"Day in My Life" versi realistis** (estetik)\n2. **Review jujur** biar dikira <i>shill</i>.\n\nTeks *miring* dan ***keduanya***, 2 * 3 = 6, snake_case_name.';

test('toPlain: tanda **, *, <i> hilang; butir dan angka tetap', () => {
  const t = M.toPlain(M.parse(RAW));
  assert.doesNotMatch(t, /\*\*|<i>|<\/i>/); assert.match(t, /^1\. "Day in My Life" versi realistis \(estetik\)\n2\. Review jujur biar dikira shill\./);
  assert.match(t, /2 \* 3 = 6, snake_case_name\./); assert.match(t, /miring dan keduanya/);
});
test('toHtml: tebal/miring jadi tag sungguhan, teks di-escape, tag liar tidak lolos', () => {
  const h = M.toHtml(M.parse(RAW));
  assert.match(h, /<ol><li><b>"Day in My Life" versi realistis<\/b>/); assert.match(h, /<i>shill<\/i>/); assert.match(h, /<b><i>keduanya<\/i><\/b>/);
  const x = M.toHtml(M.parse('<script>alert(1)</script> & <img src=x onerror=1> **ok**'));
  assert.doesNotMatch(x, /<script|<img/); assert.match(x, /&lt;script&gt;|alert\(1\)/); assert.match(x, /<b>ok<\/b>/);
});
test('parse: judul, kutipan, kode, garis, daftar bertingkat, tag penutup yatim dibuang', () => {
  const b = M.parse('## Judul\n> kutip\n\n```\nkode **bukan tebal**\n```\n---\n- a\n  - b\ntag </i> sisa');
  assert.deepEqual(b.map((x) => x.k), ['h', 'q', 'pre', 'hr', 'list', 'p']); assert.equal(b[2].v, 'kode **bukan tebal**'); assert.equal(b[4].items[1].d, 1);
  assert.equal(M.toPlain([b[5]]), 'tag  sisa');
});
test('noteDraft: teks bersih + html bergaya; judul tanpa tanda; createNote memakai html lewat sanitize', () => {
  const d = A.noteDraft('Siap, **TikTok**!\n\n- satu\n- <i>dua</i>');
  assert.equal(d.title, 'Siap, TikTok!'); assert.doesNotMatch(d.text, /\*|<i>/); assert.match(d.html, /<b>TikTok<\/b>/); assert.match(d.html, /<li><i>dua<\/i><\/li>/);
  assert.equal(A.noteDraft('   '), null); assert.equal(A.noteDraft(''), null);
  assert.deepEqual(A.taskDrafts('- **Cuci** mobil\n- Telepon <i>ibu</i>'), ['Cuci mobil', 'Telepon ibu']);
});
test('obrolan.js: balasan lewat node DOM (toDom), salin = teks bersih, dialog baru tetap urutan Batal dulu', () => {
  const o = src('src/js/ai/obrolan.js'), c = src('src/css/styles.css');
  assert.match(o, /toDom\(parse\(el\._raw\)\)/); assert.match(o, /toPlain\(parse\(el\._raw/); assert.doesNotMatch(o, /innerHTML/); assert.doesNotMatch(src('src/js/ai/markdown.js'), /innerHTML|insertAdjacentHTML|eval\(/);
  assert.ok(o.indexOf("batal, tambah,") > 0 && o.indexOf("batal, tambah,") < o.indexOf('baru));')); assert.match(o, /kai-save/);
  for (const k of ['.md strong', '.md em', '.kai-save .sheet.dlg', '.kai-save .dlgb .sv-main', '.kai-save .dlgb .sv-no']) assert.ok(c.includes(k), k);
  const blok = c.slice(c.indexOf('Rev 227: balasan AI bergaya')); assert.doesNotMatch(blok, /#[0-9a-fA-F]{3,8}\b/); assert.doesNotMatch(blok, /backdrop-filter|blur\(/);
});
test('worker: petunjuk sistem meminta Markdown sederhana tanpa tag HTML', () => {
  assert.match(src('backend/cloudflare/worker.mjs'), /Markdown sederhana[^']*JANGAN pakai tag HTML/);
});
