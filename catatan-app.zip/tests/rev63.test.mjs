// Rev 63: alarm jatuh tempo utang/piutang dari Two Pockets (due.debts) di mesin alarm Notes.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const tp = await import('../src/js/twopockets.js');
const al = await import('../src/js/tp-alarm.js');
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const store = () => { const m = new Map(); return { getItem: k => m.has(k) ? m.get(k) : null, setItem: (k, v) => m.set(k, String(v)), removeItem: k => m.delete(k) }; };
const NOW = new Date(2026, 10, 6, 10, 0, 0).getTime(); // 6 Nov 2026 10:00
const at = (y, m, d, h, mi = 0) => new Date(y, m - 1, d, h, mi, 0).getTime();
const UT = { id: 'dU1', kind: 'utang', person: 'Budi', left: 100000, due: '2026-11-13', daysLeft: 7, status: 'segera' };
const PI = { id: 'dP1', kind: 'piutang', person: 'Andi', left: 1500000, due: '2026-11-04', daysLeft: -2, status: 'terlambat' };
const api = () => { const calls = [], cancels = []; return { calls, cancels, scheduleNotification: (id, title, message, delay) => { calls.push({ id, title, message, delay }); return 'exact_alarm'; }, cancelScheduledNotification: id => cancels.push(id) }; };
let n = 0; const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };

await t('normalizeDebts: membuang id/tanggal/jenis tidak valid dan id terlalu panjang', () => {
  const d = tp.normalizeDebts({ debts: [UT, { ...UT, id: '../x' }, { ...UT, id: 'x'.repeat(35) }, { ...UT, id: 'a2', due: '2026-1-1' }, { ...UT, id: 'a3', kind: 'lain' }, PI] });
  assert.deepEqual(d.map(x => x.id), ['dU1', 'dP1']);
  assert.equal(tp.normalizeDebts({}).length, 0); assert.equal(tp.normalizeDebts(null).length, 0);
});
await t('fetchDue membaca debts; jawaban server lama tanpa debts tetap diterima', async () => {
  const conn = { url: 'https://script.google.com/macros/s/Abc/exec', key: 'x' };
  const ok = await tp.fetchDue(conn, async () => ({ status: 200, text: JSON.stringify({ ok: true, me: 'RAMA', due: { today: '2026-11-06', items: [], bills: [], debts: [UT] } }) }));
  assert.equal(ok.ok, true); assert.equal(ok.due.debts.length, 1);
  const old = await tp.fetchDue(conn, async () => ({ status: 200, text: JSON.stringify({ ok: true, me: 'RAMA', due: { today: '2026-11-06', items: [] } }) }));
  assert.deepEqual(old.due.debts, []);
});
await t('cache menyimpan debts; cache lama tanpa debts tetap terbaca', () => {
  const s = store(); tp.saveDueCache({ fetchedAt: NOW, today: '2026-11-06', items: [], bills: [], debts: [UT], sched: ['tpd:dU1:d'], alarm: true }, s);
  const c = tp.loadDueCache(s); assert.equal(c.debts.length, 1); assert.deepEqual(c.sched, ['tpd:dU1:d']);
  s.setItem(tp.DUE_KEY, JSON.stringify({ fetchedAt: NOW, items: [], sched: [] })); assert.deepEqual(tp.loadDueCache(s).debts, []);
});
await t('planAlarms utang: bawaan 08:00, 7 hari sebelum + hari-H', () => {
  const early = new Date(2026, 10, 5, 10, 0, 0).getTime();
  const p = al.planAlarms([], early, {}, [], [UT]);
  assert.deepEqual(p.map(x => x.id), ['tpd:dU1:w', 'tpd:dU1:d']);
  assert.equal(p[0].at, at(2026, 11, 6, 8)); assert.equal(p[1].at, at(2026, 11, 13, 8));
});
await t('alarm yang waktunya sudah lewat tidak dibuat (6 Nov 08:00 < sekarang 10:00)', () => {
  const ids = al.planAlarms([], NOW, {}, [], [UT]).map(x => x.id);
  assert.ok(!ids.includes('tpd:dU1:w')); assert.ok(ids.includes('tpd:dU1:d'));
});
await t('judul dan pesan: Utang ke / Piutang dari, ada sisa', () => {
  const p = al.planAlarms([], NOW, {}, [], [UT]);
  assert.equal(p[0].title, 'Utang ke Budi'); assert.match(p[0].message, /Jatuh tempo hari ini\./); assert.match(p[0].message, /Sisa Rp100\.000\./);
  const q = al.planAlarms([], NOW, {}, [], [PI]); assert.equal(q[0].title, 'Piutang dari Andi');
});
await t('utang terlambat: pengingat harian 08:00 besok; dihitung dari tanggal HP, bukan status cache', () => {
  const p = al.planAlarms([], NOW, {}, [], [{ ...PI, status: 'aman' }]);
  assert.deepEqual(p.map(x => x.id), ['tpd:dP1:n']); assert.equal(p[0].at, at(2026, 11, 7, 8)); assert.match(p[0].message, /Terlambat 2 hari/);
  const none = al.planAlarms([], NOW, {}, [], [{ ...UT, status: 'terlambat' }]); assert.ok(!none.some(x => x.id.endsWith(':n')));
});
await t('pengaturan per catatan lewat kunci dbt_<id>: jam, hari, mati, tanpa terlambat', () => {
  const cfg = { [al.debtKey('dU1')]: { hour: 19, min: 30, before: [3, 0], late: true } };
  const p = al.planAlarms([], NOW, cfg, [], [UT]);
  assert.deepEqual(p.map(x => x.id), ['tpd:dU1:b3', 'tpd:dU1:d']); assert.equal(p[0].at, at(2026, 11, 10, 19, 30));
  assert.deepEqual(al.planAlarms([], NOW, { dbt_dU1: { on: false } }, [], [UT]), []);
  assert.deepEqual(al.planAlarms([], NOW, { dbt_dP1: { late: false } }, [], [PI]), []);
});
await t('ID tpd tidak bertabrakan dengan tp dan tpb walau id sama', () => {
  const svc = { id: 'same', vehicle: 'V', name: 'Pajak', kind: 'pajak', dueDate: '2026-11-13', dueKm: 0, daysLeft: 7, kmLeft: null, status: 'aman' };
  const bill = { id: 'same', name: 'Listrik', amount: 1, repeat: 'once', nextDue: '2026-11-13', daysLeft: 7, status: 'aman', remind: [{ d: 0, t: '20:00' }] };
  const p = al.planAlarms([svc], NOW, {}, [bill], [{ ...UT, id: 'same' }]);
  const ids = p.map(x => x.id); assert.equal(new Set(ids).size, ids.length);
  assert.ok(ids.includes('tp:same:d') && ids.includes('tpb:same:b0') && ids.includes('tpd:same:d'));
});
await t('batas 60 alarm gabungan tetap berlaku dan yang terdekat dipertahankan', () => {
  const debts = Array.from({ length: 40 }, (_, i) => ({ ...UT, id: 'd' + i, due: '2026-12-' + String((i % 28) + 1).padStart(2, '0') }));
  const p = al.planAlarms([], NOW, { }, [], debts); assert.ok(p.length <= 60);
  const sorted = [...p].sort((a, b) => a.at - b.at); assert.deepEqual(p.map(x => x.id).sort(), sorted.map(x => x.id).sort());
});
await t('refreshDue memasang alarm utang dan menyimpan debts + sched', async () => {
  const s = store(); tp.saveConn({ url: 'https://script.google.com/macros/s/Abc/exec', key: 'k' }, s);
  const a = api(); const http = async () => ({ status: 200, text: JSON.stringify({ ok: true, me: 'RAMA', due: { today: '2026-11-06', items: [], bills: [], debts: [UT] } }) });
  const r = await al.refreshDue({ http, now: NOW, store: s, api: a, force: true });
  assert.equal(r.ok, true); assert.ok(a.calls.some(c => c.id === 'tpd:dU1:d')); assert.deepEqual(tp.loadDueCache(s).sched, ['tpd:dU1:d']);
});
await t('setItemCfg(dbt_) memasang ulang; setAlarmEnabled(false) membatalkan; reapply memulihkan', () => {
  const s = store(); tp.saveDueCache({ fetchedAt: NOW, today: '2026-11-06', items: [], bills: [], debts: [UT], sched: [], alarm: true }, s);
  const a = api(); const r = al.setItemCfg(al.debtKey('dU1'), { before: [3, 0], hour: 9, min: 0, late: true, on: true }, { now: NOW, store: s, api: a });
  assert.equal(r.ok, true); assert.ok(a.calls.some(c => c.id === 'tpd:dU1:b3'));
  const b = api(); al.setAlarmEnabled(false, { now: NOW, store: s, api: b }); assert.ok(b.cancels.includes('tpd:dU1:b3'));
  al.setAlarmEnabled(true, { now: NOW, store: s, api: api() });
  const c = api(); const re = al.reapplyAlarms({ now: NOW, store: s, api: c }); assert.equal(re.ok, true); assert.ok(c.calls.some(x => x.id === 'tpd:dU1:d'));
});
await t('reapplyAlarms tidak dilewati bila hanya ada debts (tanpa items/bills)', () => {
  const s = store(); tp.saveDueCache({ fetchedAt: NOW, today: '', items: [], bills: [], debts: [UT], sched: [], alarm: true }, s);
  assert.equal(al.reapplyAlarms({ now: NOW, store: s, api: api() }).skipped, undefined);
});
await t('describeDebt menampilkan status, sisa, tanggal, dan hitungan hari', () => {
  assert.match(al.describeDebt(UT, '2026-11-06'), /Segera.*Rp100\.000.*13 Nov 2026.*7 hari lagi/);
  assert.match(al.describeDebt(PI, '2026-11-06'), /Terlambat.*terlambat 2 hari/);
});
await t('ketukan notifikasi tpd: membuka layar Two Pockets; kunci lain tetap', () => {
  let opened = 0; const root = { AndroidAPI: { takeReminder: () => 'tpd:dU1:d' } };
  const old = globalThis.AndroidAPI; globalThis.AndroidAPI = root.AndroidAPI;
  return import('../src/js/reminders.js').then(m => { const pull = m.installReminderInbox({ data: { tasks: [], notes: [] } }, () => {}, () => {}, () => { opened++; }); globalThis.AndroidAPI = old; assert.equal(opened, 1); assert.equal(typeof pull, 'function'); });
});
await t('layar Setelan memuat utang/piutang, tanpa native/SCHEMA baru; versi 0.3.2 selaras', () => {
  const st = src('../src/js/settings.js');
  for (const k of ['describeDebt', 'debtKey', 'cfgRow', 'Servis, pajak, tagihan & utang']) assert.ok(st.includes(k), k);
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121'); assert.ok(st.includes('Notes Kelimaa v0.3.121')); assert.ok(src('../RIWAYAT.md').includes('versi 0.3.2'));
  assert.ok(src('../src/js/storage.js').includes('SCHEMA = 22'));
});
console.log(n + ' tes Rev 63 lulus');
