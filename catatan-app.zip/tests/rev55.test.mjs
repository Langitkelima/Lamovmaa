// Rev 55: bar status/navigasi ikut warna catatan berwarna.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const { syncBars, BAR_EDGES } = await import('../src/js/native.js');
t('syncBars(warna): bar atas = warna catatan, bar bawah = warna dock; ikon gelap/terang menurut warna catatan', () => {
  let bars = null, edges = null;
  globalThis.document = { body: {} };
  globalThis.getComputedStyle = () => ({ backgroundColor: 'rgb(10, 15, 36)' });
  globalThis.KelimaaNative = { setBars: (c, d) => { bars = [c, d]; }, setBarEdges: (a, b) => { edges = [a, b]; } };
  syncBars('#234232');
  assert.deepEqual(bars, ['#234232', true]);
  assert.equal(edges[0], '#234232,#234232');
  assert.match(edges[1], /^#[0-9a-f]{6},#[0-9a-f]{6}$/);
  assert.equal(edges[1].split(',')[0], edges[1].split(',')[1]);
  syncBars('#F5E6A8'); assert.equal(bars[1], false);
  syncBars(null); assert.deepEqual(edges, [BAR_EDGES.dark.top.join(','), BAR_EDGES.dark.bottom.join(',')]);
  syncBars('bukan-warna'); assert.deepEqual(edges, [BAR_EDGES.dark.top.join(','), BAR_EDGES.dark.bottom.join(',')]);
  delete globalThis.KelimaaNative; delete globalThis.document; delete globalThis.getComputedStyle;
});
t('notes.js: tint() menyinkronkan bar, cleanup() mengembalikan ke latar langit', () => {
  const s = src('../src/js/notes.js');
  assert.ok(s.includes("import { syncBars } from './native.js'"));
  assert.ok(s.includes('syncBars(t ? n.col : null)'));
  const c = s.slice(s.indexOf('const cleanup = () =>')); assert.ok(c.slice(0, c.indexOf('\n')).includes('try { syncBars(); } catch (_) {} };'));
});
t('versi 0.3.2 selaras', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
console.log(n + ' tes lulus (Rev 55)');
