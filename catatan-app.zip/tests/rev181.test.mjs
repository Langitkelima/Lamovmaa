// Rev 180 / U10d-1: mesin templat lembar kerja (lembar-templat.js) + pemilih "Buat dari templat" di Setelan > Lembar kerja. Templat contoh: Anggaran bulanan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { chartList } from '../src/js/lembar-grafik.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');

test('Rev 180: lembar-templat.js murni dan hanya dipakai settings.js (tanpa DOM, penyimpanan, native, eval)', () => {
  const s = src('src/js/lembar-templat.js');
  assert.doesNotMatch(s, /localStorage|document\.|window\.|AndroidAPI|Intl\.|eval\(|new Function/);
  assert.match(s, /from '\.\/lembar\.js'/); assert.match(s, /from '\.\/lembar-tampil\.js'/);
  for (const f of ['notes', 'main', 'lembar', 'lembar-ui', 'lembar-pulau', 'storage', 'export', 'share']) assert.doesNotMatch(src('src/js/' + f + '.js'), /lembar-templat/, f);
  assert.match(src('src/js/settings.js'), /loadTemplates/); assert.match(src('src/js/lembar-pintu.js'), /import\('\.\/lembar-templat\.js'\)/); // Rev 192 / P2a: dimuat lewat pintu, bukan impor statis
});
test('Rev 180: daftar templat = id unik, nama dan keterangan Bahasa Indonesia, templat contoh Anggaran bulanan', () => {
  const l = T.templateList(); assert.ok(l.length >= 1);
  assert.equal(new Set(l.map((t) => t.id)).size, l.length);
  for (const t of l) { assert.ok(t.name && t.desc && /^[a-z0-9_-]+$/.test(t.id)); assert.doesNotMatch(t.name + t.desc, /\b(Planned|Spent|Monthly|budget)\b/); }
  const ang = l.find((t) => t.id === 'anggaran'); assert.ok(ang); assert.equal(ang.name, 'Anggaran bulanan'); assert.equal(T.hasTemplate('anggaran'), true); assert.equal(T.hasTemplate('nope'), false);
});
test('Rev 180: makeFromTemplate membangun lembar sah (tanpa rumus ditolak, muat batas, bulat-balik cleanSheet)', () => {
  const r = T.makeFromTemplate('anggaran', { now: 7 }); assert.ok(r); assert.equal(r.failed, 0);
  const sh = r.sheet; assert.equal(sh.name, 'Anggaran bulanan'); assert.equal(sh.at, 7); assert.equal(sh.tabs.length, 1); assert.equal(sh.tabs[0].name, 'Anggaran');
  assert.ok(L.fitsLimit(sh)); assert.ok(L.isSheetId(sh.id));
  assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(sh)))), JSON.stringify(sh));
  assert.equal(T.makeFromTemplate('nope'), null); assert.equal(T.makeFromTemplate(), null);
  assert.equal(T.makeFromTemplate('anggaran', { name: 'Februari' }).sheet.name, 'Februari');
  const a = T.makeFromTemplate('anggaran').sheet, b = T.makeFromTemplate('anggaran').sheet; assert.notEqual(a.id, b.id); // tiap panggilan = lembar baru (ID unik)
});
test('Rev 180: Anggaran bulanan = rumus hidup (Sisa, Dipakai, Total) dan format Rp / Persen', () => {
  const tab = T.makeFromTemplate('anggaran').sheet.tabs[0], d = makeDisplay(tab);
  assert.deepEqual([0, 1, 2, 3, 4].map((j) => d.text(0, j)), ['Kategori', 'Rencana', 'Terpakai', 'Sisa', 'Dipakai']);
  assert.deepEqual([0, 1, 2, 3, 4].map((j) => d.text(1, j)), ['Makan', 'Rp 1.500.000', 'Rp 1.250.000', 'Rp 250.000', '83%']);
  assert.equal(d.text(4, 3), '-Rp 120.000'); assert.equal(d.text(4, 4), '120%'); // belanja melebihi rencana
  assert.deepEqual([0, 1, 2, 3, 4].map((j) => d.text(9, j)), ['Total', 'Rp 5.150.000', 'Rp 4.440.000', 'Rp 710.000', '86%']);
  assert.equal(d.raw(9, 1), 5150000); assert.equal(d.raw(9, 2), 4440000);
  const fx = tab.rows[1].cells[tab.cols[3].id]; assert.match(fx.fx, /^=/); assert.equal(fx.v, undefined); // hasil tidak pernah disimpan
  assert.equal(tab.rows[0].cells[tab.cols[0].id].s.b, true); assert.equal(tab.rows[9].cells[tab.cols[1].id].s.b, true); // judul dan Total tebal
  assert.equal(tab.rows[0].cells[tab.cols[0].id].s.fg, '#111827'); // isian terang selalu bersama teks gelap
});
test('Rev 180: rumus ikut hidup saat sel diubah, dan baris/lebar kolom sesuai templat', () => {
  const tab = T.makeFromTemplate('anggaran').sheet.tabs[0];
  L.setCell(tab, tab.rows[1].id, tab.cols[2].id, { v: 1500000 }); const d = makeDisplay(tab);
  assert.equal(d.text(1, 3), 'Rp 0'); assert.equal(d.text(1, 4), '100%'); assert.equal(d.raw(9, 2), 4690000);
  assert.equal(tab.cols[0].w, 150); assert.equal(tab.cols[4].w, 70); assert.equal(tab.rows.length, 30);
});
test('Rev 180: diagram tersimpan Terpakai per kategori (kolom, satu kolom nilai) memakai ID baris/kolom', () => {
  const tab = T.makeFromTemplate('anggaran').sheet.tabs[0], cs = chartList(tab);
  assert.equal(cs.length, 1); assert.equal(cs[0].kind, 'column'); assert.equal(cs[0].title, 'Terpakai per kategori'); assert.equal(cs[0].ref, 'A1:C9'); assert.equal(cs[0].valueCol, 2);
});
test('Rev 180: pemilih Buat dari templat terpasang di Setelan > Lembar kerja (dialog, lembar baru, batas 50, tanpa menyentuh lembar lain)', () => {
  const s = src('src/js/settings.js');
  assert.match(s, /'Buat dari templat'/); assert.match(s, /class: 'btn line lztpl', onclick: pickTemplate/);
  assert.match(s, /const fromTemplate = \(tid\) => \{[\s\S]*?LZ\.MAX_SHEETS[\s\S]*?makeFromTemplate\(tid\)[\s\S]*?data\.sheets\[sh\.id\] = sh; ctx\.persist\(\); ctx\.render\(\); open\(sh\.id\)/);
  assert.match(s, /class: 'ov dlgov'[\s\S]*?class: 'sheet dlg tpldlg'/); // dialog memakai .dlgov agar tombol Kembali HP menutupnya (closeDialog klik tombol .line)
  assert.match(s, /class: 'dlgb' \}, h\('button', \{ type: 'button', class: 'btn line'/);
  const css = src('src/css/styles.css'); assert.match(css, /Rev 180 \/ U10d-1/); const blk = css.slice(css.indexOf('Rev 180 / U10d-1')); assert.doesNotMatch(blk, /#[0-9a-fA-F]{3,8}\b/); // hanya variabel tema
});
