// Rev 156 / U10c-1: mesin diagram SVG lembar kerja (murni, tanpa UI).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import * as D from '../src/js/lembar-diagram.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
function mk(grid) { const t = L.newTab('T', Math.max(8, grid.length + 2)); grid.forEach((r, i) => r.forEach((v, j) => { if (v !== undefined) L.setCell(t, t.rows[i].id, t.cols[j].id, { v }); })); return t; }
const S = { r1: 0, c1: 0, r2: 4, c2: 1 };

test('chartData: baris judul dikenali, baris bukan angka dilewati dan dihitung, label kosong diberi nama', () => {
  const d = D.chartData(mk([['Bulan', 'Biaya'], ['Jan', 10], ['Feb', 'x'], [undefined, 5], ['Mar', 20]]), S);
  assert.equal(d.ok, true); assert.equal(d.title, 'Biaya'); assert.deepEqual(d.labels, ['Jan', 'Baris 4', 'Mar']); assert.deepEqual(d.values, [10, 5, 20]); assert.equal(d.skipped, 1);
  const n = D.chartData(mk([['a', 1], ['b', 2]]), { r1: 0, c1: 0, r2: 1, c2: 1 }); assert.equal(n.title, ''); assert.deepEqual(n.values, [1, 2]); // tanpa judul: baris 1 tetap data
});
test('chartData: memakai HASIL rumus dan teks tampil; rentang/kolom buruk ditolak tanpa melempar', () => {
  const t = mk([['Item', 'Nilai'], ['a', 2], ['b', 3]]); L.setCell(t, t.rows[3].id, t.cols[0].id, { v: 'jml' }); L.setCell(t, t.rows[3].id, t.cols[1].id, R.a1ToStored('=SUM(B2:B3)', t));
  assert.deepEqual(D.chartData(t, { r1: 0, c1: 0, r2: 3, c2: 1 }).values, [2, 3, 5]);
  for (const bad of [null, {}, { r1: 0, c1: 0, r2: 99, c2: 1 }, { r1: 2, c1: 0, r2: 1, c2: 1 }, { r1: 0, c1: 0, r2: 1, c2: 0 }, { r1: 0.5, c1: 0, r2: 1, c2: 1 }]) assert.equal(D.chartData(t, bad).ok, false);
  assert.equal(D.chartData(t, { r1: 0, c1: 0, r2: 3, c2: 1 }, { valueCol: 0 }).ok, false); assert.equal(D.chartData(mk([['a', 'b'], ['c', 'd']]), { r1: 0, c1: 0, r2: 1, c2: 1 }).reason, 'kosong');
});
test('chartData: dipotong MAX_POINTS dan dilaporkan', () => {
  const g = []; for (let i = 0; i < 40; i++) g.push(['k' + i, i + 1]); const t = L.newTab('T', 50); g.forEach((r, i) => r.forEach((v, j) => L.setCell(t, t.rows[i].id, t.cols[j].id, { v })));
  const d = D.chartData(t, { r1: 0, c1: 0, r2: 39, c2: 1 }); assert.equal(d.values.length, D.MAX_POINTS); assert.equal(d.truncated, 40 - D.MAX_POINTS);
});
test('chartSvg: tiga jenis menghasilkan SVG sah, berjudul, tanpa skrip/gambar luar/handler', () => {
  const d = D.chartData(mk([['Bulan', 'Biaya'], ['Jan', 1500000], ['Feb', 2000000], ['Mar', -500000], ['Apr', 800000]]), S);
  for (const kind of D.CHART_KINDS) {
    const r = D.chartSvg(d, { kind }); assert.equal(r.ok, true, kind); assert.ok(r.svg.startsWith('<svg ') && r.svg.endsWith('</svg>')); assert.ok(r.w > 0 && r.h > 0);
    assert.ok(r.svg.includes('role="img"') && r.svg.includes('<title>')); assert.doesNotMatch(r.svg, /<script|<image|href=|onload|onclick|javascript:|<foreignObject|<style|url\(/i);
  }
  assert.match(D.chartSvg(d, { kind: 'donut' }).svg, /4,3 jt/); assert.match(D.chartSvg(d, { kind: 'column' }).svg, /2 jt/);
});
test('teks berbahaya diloloskan (judul, label); warna tema tidak sah diganti bawaan', () => {
  const d = { ok: true, labels: ['<img src=x onerror=1>', 'a"b'], values: [1, 2], title: '', skipped: 0, truncated: 0 };
  const r = D.chartSvg(d, { kind: 'column', title: '</title><script>alert(1)</script>', theme: { ink: 'red;}</style>', mut: '#12', bg: '"><x' } });
  assert.doesNotMatch(r.svg, /<script|<img|onerror=1>/); assert.match(r.svg, /&lt;script&gt;/); assert.match(r.svg, /fill="#1F2937"/); assert.doesNotMatch(r.svg, /<x/);
});
test('donat: nilai nol/negatif tidak digambar, satu irisan penuh = cincin, semua tak positif = ditolak; legenda bisa dimatikan', () => {
  const one = D.chartSvg({ ok: true, labels: ['a', 'b'], values: [5, -3], title: '' }, { kind: 'donut' }); assert.equal(one.ok, true); assert.match(one.svg, /<circle /); assert.doesNotMatch(one.svg, /<path /);
  assert.equal(D.chartSvg({ ok: true, labels: ['a'], values: [-1], title: '' }, { kind: 'donut' }).ok, false); assert.equal(D.chartSvg(null).ok, false);
  const d = { ok: true, labels: ['a', 'b', 'c'], values: [1, 2, 3], title: '' }; assert.ok(D.chartSvg(d, { kind: 'donut', legend: true }).h > D.chartSvg(d, { kind: 'donut', legend: false }).h); assert.equal((D.chartSvg(d, { kind: 'donut' }).svg.match(/<path /g) || []).length, 3);
});
test('kolom/batang: nilai negatif punya garis nol, semua nol tetap aman, lebar dibatasi; pembantu compact/niceScale/cleanChart', () => {
  assert.equal(D.chartSvg({ ok: true, labels: ['a', 'b'], values: [0, 0], title: '' }, { kind: 'bar' }).ok, true); assert.equal(D.chartSvg({ ok: true, labels: ['a'], values: [3], title: '' }, { kind: 'column', width: 99999 }).w, 1200);
  assert.deepEqual([D.compact(1500), D.compact(15000), D.compact(2000000), D.compact(-3e9), D.compact(0.5)], ['1500', '15 rb', '2 jt', '\u22123 M', '0,5']);
  const sc = D.niceScale(-3, 97); assert.ok(sc.lo <= -3 && sc.hi >= 97 && sc.ticks.includes(0)); assert.ok(D.niceScale(0, 0).hi > 0);
  assert.deepEqual(D.cleanChart({ kind: 'pie', title: '  a   b ', legend: 0 }), { kind: 'column', title: 'a b', legend: true }); assert.equal(D.cleanChart({ title: 'x'.repeat(200) }).title.length, D.MAX_TITLE);
});
test('modul murni dan hanya dipakai lembar-ui; versi 0.3.121, SCHEMA 16', () => {
  const m = src('src/js/lembar-diagram.js'); assert.doesNotMatch(m, /document\.|localStorage|eval\(|new Function|Capacitor|window\./); assert.doesNotMatch(m, /from '\.\/rumus\.js'/); assert.match(m, /from '\.\/lembar-tampil\.js'/);
  for (const f of ['lembar', 'export', 'notes', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /lembar-diagram/, f); // Rev 157: hanya lembar-ui.js (dialog Diagram) yang boleh mengimpor
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev156.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
});
