// Rev 280 / W5 (penutup paket Peringatan + Pelacakan Error): perbaikan tata letak dialog Riwayat error yang ditemukan audit Chromium. Tes AI saja (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
test('CSS: tombol Lompat di baris riwayat tidak melebar penuh (akar: .btn{width:100%} global menjepit .eh-main jadi 0)', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 280 / W5'); assert.ok(i > 0); const blk = css.slice(i);
  assert.match(css, /\.btn\{[^}]*width:100%/); // sebab: aturan global memang ada
  assert.match(blk, /\.eh-row \.btn\{[^}]*width:auto/); assert.match(blk, /\.eh-row \.btn\{[^}]*flex:none/); assert.match(blk, /\.eh-row \.eh-main\{[^}]*min-width:0/);
  assert.doesNotMatch(blk, /#[0-9a-fA-F]{3,8}\b/); assert.doesNotMatch(blk, /rgba?\(/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('alat audit ada dan memeriksa lencana, ikon, dialog, daftar 200, Bersihkan, terang dan gelap', () => {
  const a = src('tools/audit_riwayat.py');
  for (const k of ["'light', 'dark'", '.lz-err', '.eh-row', '[data-f=clear]', 'range(200)'.replace('range(200)', 'k < 200'), 'badge', 'ratio(']) assert.ok(a.includes(k), k);
});
test('dialog Riwayat error tidak berubah di JS; versi 0.3.121, SCHEMA 22, tes terdaftar', () => {
  const ui = src('src/js/lembar-ui.js'); assert.match(ui, /const openHist = \(\) => \{/); assert.match(ui, /class: 'eh-main'/); assert.match(ui, /'data-f': 'go'/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/); assert.match(pk.scripts.test, /node tests\/rev280\.test\.mjs/);
});
