// Rev 263: panel warna: "Terakhir dipakai", "Di lembar ini" (pipet tanpa layar), pipet layar bila didukung. Tes Node; BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as W from '../src/js/lembar-warna.js'; import * as L from '../src/js/lembar.js';
const ui = readFileSync(new URL('../src/js/lembar-ui.js', import.meta.url), 'utf8');
test('pushRecent: ke depan, tanpa duplikat, maksimal 9, masukan liar diabaikan, daftar asli utuh', () => {
  const a = ['#111111', '#222222']; assert.deepEqual(W.pushRecent(a, '#222222'), ['#222222', '#111111']); assert.deepEqual(a, ['#111111', '#222222']);
  assert.deepEqual(W.pushRecent(a, 'abc'), ['#AABBCC', '#111111', '#222222']); assert.deepEqual(W.pushRecent(a, 'bukan'), a); assert.deepEqual(W.pushRecent(null, '#123456'), ['#123456']);
  let l = []; for (let i = 0; i < 20; i++) l = W.pushRecent(l, W.hslToHex(i * 17, 80, 50)); assert.equal(l.length, 9); assert.equal(new Set(l).size, 9);
  assert.deepEqual(W.pushRecent(['x', '#111111', 5], '#333333'), ['#333333', '#111111']);
});
test('usedColors: hitung per tab, paling sering dulu, kunci bg/fg terpisah, hex tak sah dilewati', () => {
  const sh = L.newSheet({ id: 'u', name: 'u' }), t = sh.tabs[0];
  const put = (r, c, s) => L.setCell(t, t.rows[r].id, t.cols[c].id, { v: 'x', s });
  put(0, 0, { bg: '#FDE68A' }); put(1, 0, { bg: '#FDE68A' }); put(2, 0, { bg: '#BFDBFE' }); put(3, 0, { bg: '#BBF7D0', fg: '#DC2626' }); put(4, 0, { fg: '#DC2626' }); put(5, 0, { fg: '#16A34A' });
  assert.deepEqual(W.usedColors(t, 'bg'), ['#FDE68A', '#BFDBFE', '#BBF7D0']); assert.deepEqual(W.usedColors(t, 'fg'), ['#DC2626', '#16A34A']);
  assert.deepEqual(W.usedColors(t, 'b'), []); assert.deepEqual(W.usedColors(null, 'bg'), []); assert.deepEqual(W.usedColors({ rows: [null, {}, { cells: { a: null, b: { s: { bg: 'zz' } } } }] }, 'bg'), []);
  assert.deepEqual(W.usedColors(t, 'bg', 2), ['#FDE68A', '#BFDBFE']);
});
test('panel: baris Terakhir dipakai / Di lembar ini muncul hanya bila ada isinya; applyStyle mencatat; tanpa penyimpanan', () => {
  const f = ui.slice(ui.indexOf('function openColorPanel(key, ext) {'), ui.indexOf('// --- Rev 132 / U8a-5: tombol Format'));
  assert.ok(f.includes("mkRow('Terakhir dipakai', lastC, 'terakhir')") && f.includes("mkRow('Di lembar ini', usedC, 'lembar')") && f.includes('WN.usedColors(tab, key)') && f.includes('lastC.length ?') && f.includes('usedC.length ?'));
  assert.ok(f.includes('.filter((c) => !lastC.includes(c))')); // tidak ganda dengan baris Terakhir
  assert.ok(ui.includes('const recentCol = { bg: [], fg: [] };') && ui.includes('recentCol[k] = WN.pushRecent(recentCol[k], patch[k])'));
  assert.ok(!/localStorage|sessionStorage|Capacitor|indexedDB/.test(f + ui.slice(ui.indexOf('const recentCol'), ui.indexOf('const recentCol') + 200)));
  assert.equal((f.match(/applyStyle\(/g) || []).length, 1); // Rev 296: Terapkan/Atur ulang kini satu jalur (done); pilih warna dari deret hanya mengisi panel; data berubah hanya lewat Terapkan/Atur ulang
});
test('pipet layar: hanya bila window.EyeDropper ada; gagal/batal tidak melempar galat', () => {
  const f = ui.slice(ui.indexOf('function openColorPanel(key, ext) {'), ui.indexOf('// --- Rev 132 / U8a-5: tombol Format'));
  assert.ok(f.includes("typeof window.EyeDropper === 'function'") && f.includes('new window.EyeDropper().open().then(') && f.includes('setHex(r.sRGBHex)') && f.includes('catch (_) {}') && f.includes('chip, hex, eye'));
});
