// Rev 61: alarm Two Pockets per item (jam, hari sebelum, terlambat, nyala/mati).
import assert from 'node:assert/strict';
let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const tp = await import('../src/js/twopockets.js');
const al = await import('../src/js/tp-alarm.js');
const store = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };
const NOW = new Date(2026, 10, 4, 10, 0, 0).getTime();
const at = (y, m, d, h, mi = 0) => new Date(y, m - 1, d, h, mi, 0).getTime();
const PAJAK = { id: 'rP', vehicle: 'Vario', name: 'Pajak', kind: 'pajak', dueDate: '2026-12-30', dueKm: 0, daysLeft: 56, kmLeft: null, status: 'aman' };
const OLI = { id: 'rO', vehicle: 'Vario', name: 'Oli', kind: 'servis', dueDate: '2026-10-30', dueKm: 1, daysLeft: -5, kmLeft: -120, status: 'terlambat' };
const mkApi = () => { const calls = [], cancels = []; return { calls, cancels, scheduleNotification: (id, ti, m, d) => { calls.push({ id, d }); return 'exact_alarm'; }, cancelScheduledNotification: (id) => cancels.push(id) }; };

await t('cleanCfg: bawaan, nilai aneh dibersihkan', () => {
  assert.deepEqual(tp.cleanCfg(null), tp.DEFAULT_CFG);
  const c = tp.cleanCfg({ on: false, hour: 99, min: -1, before: [1, '3', 3, 999, 'x', 30], late: false });
  assert.equal(c.on, false); assert.equal(c.hour, 8); assert.equal(c.min, 0); assert.equal(c.late, false);
  assert.deepEqual(c.before, [30, 3, 1]);
  assert.equal(tp.isDefaultCfg({}), true); assert.equal(tp.isDefaultCfg({ hour: 19 }), false);
});
await t('planAlarms tanpa pengaturan = perilaku lama (08:00, w + d)', () => {
  const p = al.planAlarms([PAJAK], NOW);
  assert.deepEqual(p.map((x) => x.id), ['tp:rP:w', 'tp:rP:d']);
  assert.equal(p[0].at, at(2026, 12, 23, 8));
});
await t('planAlarms: jam 19:30 dan hari 30, 3, 1, hari-H', () => {
  const p = al.planAlarms([PAJAK], NOW, { rP: { hour: 19, min: 30, before: [30, 3, 1, 0] } });
  assert.deepEqual(p.map((x) => x.id), ['tp:rP:b30', 'tp:rP:b3', 'tp:rP:b1', 'tp:rP:d']);
  assert.equal(p[0].at, at(2026, 11, 30, 19, 30)); assert.equal(p[3].at, at(2026, 12, 30, 19, 30));
  assert.match(p[0].message, /30 hari lagi \(30 Des 2026\)/);
});
await t('planAlarms: item mati tidak berbunyi; late=false menghapus alarm terlambat; jam terlambat ikut jam item', () => {
  assert.deepEqual(al.planAlarms([PAJAK, OLI], NOW, { rP: { on: false } }).map((x) => x.id), ['tp:rO:n']);
  assert.deepEqual(al.planAlarms([OLI], NOW, { rO: { late: false } }), []);
  const late = al.planAlarms([OLI], NOW, { rO: { hour: 20, min: 15 } })[0];
  assert.equal(late.at, at(2026, 11, 4, 20, 15));
});
await t('setItemCfg: simpan, pasang ulang alarm, batalkan yang tidak dipakai; bawaan menghapus entri', () => {
  const s = store(), a = mkApi();
  tp.saveDueCache({ fetchedAt: NOW, today: '2026-11-04', items: [PAJAK], sched: ['tp:rP:w', 'tp:rP:d'], alarm: true }, s);
  const r = al.setItemCfg('rP', { hour: 19, min: 0, before: [1] }, { now: NOW, store: s, api: a });
  assert.equal(r.ok, true);
  assert.deepEqual(a.calls.map((c) => c.id), ['tp:rP:b1']);
  assert.deepEqual(a.cancels.sort(), ['tp:rP:d', 'tp:rP:w']);
  assert.equal(tp.loadAlarmCfg(s).rP.hour, 19);
  assert.deepEqual(tp.loadDueCache(s).sched, ['tp:rP:b1']);
  al.setItemCfg('rP', {}, { now: NOW, store: s, api: mkApi() });
  assert.deepEqual(tp.loadAlarmCfg(s), {});
});
await t('setItemCfg: alarm global mati = hanya simpan; disconnect menghapus pengaturan', () => {
  const s = store(), a = mkApi();
  tp.saveDueCache({ fetchedAt: NOW, today: '', items: [PAJAK], sched: [], alarm: false }, s);
  const r = al.setItemCfg('rP', { hour: 9 }, { now: NOW, store: s, api: a });
  assert.equal(r.alarm, null); assert.equal(a.calls.length, 0);
  al.disconnect({ store: s, api: a });
  assert.deepEqual(tp.loadAlarmCfg(s), {});
});
await t('describeCfg: ringkasan terbaca', () => {
  assert.equal(al.describeCfg(null), 'Alarm 08:00 \u00b7 H-7, hari-H \u00b7 + tiap hari bila terlambat');
  assert.equal(al.describeCfg({ on: false }), 'Alarm mati');
  assert.match(al.describeCfg({ hour: 19, min: 5, before: [], late: false }), /19:05 · tanpa pengingat sebelum$/);
});
console.log(n + ' tes lulus (rev61)');
