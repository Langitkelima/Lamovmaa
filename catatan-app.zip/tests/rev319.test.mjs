// Rev 319 / PART U2a: pegangan seret lebar kolom tabel. Bagian DOM/gestur dicek di Chromium (tools/audit_lebar_kolom_319.py), bukan di npm test.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dragWidth, shiftWidthList } from '../src/js/tabel-lebar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('Rev 319: dragWidth dijepit 56-320 dan tidak pernah jatuh ke 0 (otomatis)', () => {
  assert.equal(dragWidth(105, 60), 165); assert.equal(dragWidth(105, -300), 56); assert.equal(dragWidth(105, 900), 320);
  assert.equal(dragWidth(100.4, 0.2), 101); assert.equal(dragWidth(NaN, 5), 56); assert.equal(dragWidth(undefined, undefined), 56);
});
test('Rev 319: shiftWidthList menjaga lebar kolom lain saat kolom ditambah/dihapus', () => {
  assert.deepEqual(shiftWidthList([140, 0, 200], 'ins', 1, 3), [140, 0, 0, 200]);
  assert.deepEqual(shiftWidthList([140, 0, 200], 'ins', 0, 3), [0, 140, 0, 200]);
  assert.deepEqual(shiftWidthList([140, 0, 200], 'ins', 3, 3), [140, 0, 200, 0]);
  assert.deepEqual(shiftWidthList([140, 90, 200], 'del', 1, 3), [140, 200]);
  assert.deepEqual(shiftWidthList([140, 90, 200], 'del', 0, 3), [90, 200]);
  assert.deepEqual(shiftWidthList([140, 90, 200], 'del', 2, 3), [140, 90]);
});
test('Rev 319: sanitize memasang ulang gaya lebar dari data-w (satu pintu), gaya lebar liar tetap dibuang', () => {
  const t = src('src/js/tabel.js');
  assert.match(t, /export function applyTableWidths\(table\)/);
  assert.match(t, /normalizeTableWidths\(table\) \{[^\n]*applyTableWidths\(table\); \}/);
  const n = src('src/js/notes.js');
  assert.match(n, /querySelectorAll\('table\[data-w\]'\)\.forEach\(\(tb\) => normalizeTableWidths\(tb\)\)/);
  assert.match(n, /\^color:#\?\[0-9a-zA-Z\(\),\.%\]\+\$/, 'daftar gaya yang diizinkan sanitize tidak boleh ditambah width');
});
test('Rev 319: modul seret dimuat MALAS (import dinamis), tidak statis dari notes.js/main.js', () => {
  const n = src('src/js/notes.js');
  assert.match(n, /import\('\.\/tabel-seret\.js'\)/); assert.doesNotMatch(n, /\btabel-lebar\b/, 'notes.js hanya lewat tabel-seret.js');
  for (const f of ['notes', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /^import .*tabel-(seret|lebar)/m, f);
});
test('Rev 319: pegangan bagian dari tabel aktif: disembunyikan di luar sel, dibersihkan saat editor ditutup, ikut gulir/ukuran/ketik', () => {
  const n = src('src/js/notes.js');
  assert.match(n, /if \(colRs\) colRs\.hide\(\);/);
  assert.match(n, /colRs\.show\(table\)/);
  assert.match(n, /colRs\.el\.remove\(\)/);
  assert.match(n, /ed\.addEventListener\('input', placeSoon\)/);
  assert.match(n, /placeImageTools\(\); if \(colRs\) colRs\.place\(\);/);
});
test('Rev 319: tambah/hapus kolom memanggil shiftTableWidths hanya bila tabel punya data-w', () => {
  const n = src('src/js/notes.js');
  assert.match(n, /if \(target && wAttr && tblW\) tblW\.shiftTableWidths\(table, 'del', colIndex, d\.cols\)/);
  assert.match(n, /if \(target && wAttr && tblW\) tblW\.shiftTableWidths\(table, 'ins', id === 'col-after' \? colIndex \+ 1 : colIndex, d\.cols\)/);
});
test('Rev 319: modul seret: area sentuh 28 px, tanpa mencuri fokus, satu Undo per seretan, ambang gerak 3 px', () => {
  const s = src('src/js/tabel-seret.js'), c = src('src/css/styles.css');
  assert.match(s, /e\.preventDefault\(\); e\.stopPropagation\(\)/); assert.match(s, /Math\.abs\(dx\) < 3/);
  assert.match(s, /onStart\(\)/); assert.match(s, /onCommit\(\)/); assert.match(s, /setPointerCapture/);
  assert.match(c, /\.col-rs-h\{position:fixed;width:28px/); assert.match(c, /touch-action:none/);
});
test('Rev 319: versi dan SCHEMA tidak berubah', () => {
  assert.ok(src('package.json').includes('"version": "0.3.121"')); assert.ok(src('src/js/storage.js').includes('export const SCHEMA = 22;'));
});
