// Rev 283 / V6c-3 (Validasi): urut baris menjaga rentang SUMBER daftar pilihan di posisinya. Tes Node (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { sortTab } from '../src/js/lembar-alat.js';
import { pinSrc, unpinSrc, srcRect, refreshSrc } from '../src/js/lembar-sumber.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = () => { const t = L.newSheet({ id: 's', name: 's' }).tabs[0], put = (i, j, v) => L.setCell(t, t.rows[i].id, t.cols[j].id, { v });
  ['Cc', 'Aa', 'Bb', 'Dd', 'Ee', 'Ff'].forEach((v, i) => put(i, 0, v)); ['1', '2', '3', '4', '5', '6'].forEach((v, i) => put(i, 1, v));
  const S = { c1: t.cols[0].id, c2: t.cols[0].id, r1: t.rows[1].id, r2: t.rows[3].id }; // sumber A2:A4
  L.setChecks(t, [{ id: 'a', c: t.cols[2].id, k: 'list', items: ['x'], src: S }]); return { t, put, text: (i, j) => { const c = t.rows[i].cells[t.cols[j].id]; return c && c.v != null ? String(c.v) : ''; } }; };
test('pinSrc/unpinSrc: ID batas dipasang ulang pada indeks yang sama setelah baris bertukar; aturan tanpa src dilewati', () => {
  const { t } = mk(); assert.deepEqual(srcRect(t, t.checks[0].src), { c1: 0, c2: 0, r1: 1, r2: 3 }); const snap = pinSrc(t); assert.deepEqual(snap[0], { c1: 0, c2: 0, r1: 1, r2: 3 });
  [t.rows[1], t.rows[5]] = [t.rows[5], t.rows[1]]; assert.notDeepEqual(srcRect(t, t.checks[0].src), { c1: 0, c2: 0, r1: 1, r2: 3 }); // tanpa pin rentang ikut ID baris
  unpinSrc(t, snap); assert.deepEqual(srcRect(t, t.checks[0].src), { c1: 0, c2: 0, r1: 1, r2: 3 });
  L.setChecks(t, [{ id: 'z', c: t.cols[2].id, k: 'list', items: ['x'] }]); assert.deepEqual(pinSrc(t), [null]); unpinSrc(t, [null]); unpinSrc(t, null);
});
test('sortTab: sumber tetap di A2:A4 setelah urut (nilai di baris tersebut berubah, rentang tidak melompat); daftar mengikuti isi baru', () => {
  const { t, text } = mk(); refreshSrc(t, text); assert.deepEqual(t.checks[0].items, ['Aa', 'Bb', 'Dd']);
  const before = t.checks[0].src; const res = sortTab(t, 0, 'desc', { header: false }); assert.ok(res.ok && res.moved > 0);
  assert.deepEqual(srcRect(t, t.checks[0].src), { c1: 0, c2: 0, r1: 1, r2: 3 }); assert.equal(t.checks[0].src.c1, before.c1);
  refreshSrc(t, text); assert.deepEqual(t.checks[0].items, ['Ee', 'Dd', 'Cc']); // desc: Ff, Ee, Dd, Cc, Bb, Aa -> baris 2-4
});
test('urut tanpa baris pindah = src tidak berubah; kabel: lembar-alat (malas) mengimpor pin/unpin, modul statis tidak; tes terdaftar', () => {
  const { t } = mk(); sortTab(t, 0, 'asc', { header: false }); const s1 = JSON.stringify(t.checks[0].src); const r = sortTab(t, 0, 'asc', { header: false }); assert.equal(r.moved, 0); assert.equal(JSON.stringify(t.checks[0].src), s1);
  const a = src('src/js/lembar-alat.js'); assert.match(a, /import \{ pinSrc, unpinSrc \} from '\.\/lembar-sumber\.js'/); assert.match(a, /ps = pinSrc\(tab\)/); assert.match(a, /if \(moved\) \{ unpinChecks\(tab, pv\); unpinSrc\(tab, ps\); \}/); assert.doesNotMatch(a, /lembar-validasi/);
  for (const f of ['lembar.js', 'lembar-validasi.js', 'main.js']) assert.doesNotMatch(src('src/js/' + f), /lembar-sumber/, f);
  const pk = JSON.parse(src('package.json')); assert.match(pk.scripts.test, /node tests\/rev283\.test\.mjs/); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
});
