// Rev 183 / U10d-4: empat templat terakhir Lampiran C (Catatan olahraga, Inventaris, Penjualan, Absensi) = 12 templat lengkap.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { chartList } from '../src/js/lembar-grafik.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 12, 0, 0).getTime();
const mk = (id, o = {}) => T.makeFromTemplate(id, { now: NOW, ...o });
const row = (d, i, n) => Array.from({ length: n }, (_, j) => d.text(i, j));
const NEW = ['olahraga', 'inventaris']; // Rev 293: Penjualan dan Absensi lama dihapus (digantikan Admin · Laporan penjualan dan Daftar hadir)
const put = (tab, i, j, patch) => L.setCell(tab, tab.rows[i].id, tab.cols[j].id, patch);
const sty = (tab, i, j) => (tab.rows[i].cells[tab.cols[j].id] || {}).s || {};

test('Rev 183: 12 templat lengkap, ID unik, nama Indonesia', () => {
  const l = T.templateList().slice(-10); assert.equal(T.templateList().length, 35); /* Rev 293: 10 templat lama paling belakang */ assert.equal(l.length, 10); assert.equal(new Set(l.map((t) => t.id)).size, 10);
  assert.deepEqual(l.slice(8).map((t) => t.id), NEW); assert.deepEqual(l.slice(8).map((t) => t.name), ['Catatan olahraga', 'Inventaris']);
  for (const t of l.slice(8)) assert.doesNotMatch(t.name + ' ' + t.desc, /\b(Workout|log|Inventory|Sales|tracker|Attendance|Stock)\b/);
});
test('Rev 183: keempat templat sah (tanpa rumus ditolak, muat batas, bulat-balik, tanpa galat rumus)', () => {
  for (const id of NEW) {
    const r = mk(id); assert.ok(r, id); assert.equal(r.failed, 0, id); assert.ok(L.fitsLimit(r.sheet));
    assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(r.sheet)))), JSON.stringify(r.sheet), id);
    const d = makeDisplay(r.sheet.tabs[0]); for (let i = 0; i < 12; i++) for (let j = 0; j < 9; j++) assert.doesNotMatch(d.text(i, j), /^#|NaN|undefined/, id);
  }
});
test('Rev 183: Catatan olahraga = Volume = set x repetisi x beban, diagram menit', () => {
  const tab = mk('olahraga').sheet.tabs[0]; let d = makeDisplay(tab);
  assert.deepEqual(row(d, 0, 8), ['Tanggal', 'Latihan', 'Set', 'Repetisi', 'Beban (kg)', 'Volume', 'Menit', 'Catatan']);
  assert.deepEqual(row(d, 2, 8), ['05/11/2026', 'Angkat beban: dada', '4', '10', '40', '1.600', '45', '']); assert.equal(d.text(7, 0), '10/11/2026');
  put(tab, 7, 2, { v: 3 }); put(tab, 7, 3, { v: 12 }); put(tab, 7, 4, { v: 20 }); d = makeDisplay(tab); assert.equal(d.text(7, 5), '720'); assert.equal(d.text(8, 5), '');
  const c = chartList(tab); assert.equal(c.length, 1); assert.equal(c[0].kind, 'column'); assert.equal(c[0].ref, 'A1:G8'); assert.equal(c[0].valueCol, 6);
});
test('Rev 183: Inventaris = nilai stok, Pesan ulang bila stok <= batas, Total', () => {
  const tab = mk('inventaris').sheet.tabs[0]; let d = makeDisplay(tab);
  assert.deepEqual(row(d, 3, 6), ['Map plastik', '15', '30', 'Rp 2.500', 'Rp 37.500', 'Pesan']); assert.equal(d.text(1, 5), '');
  assert.deepEqual(row(d, 8, 6), ['Total', '', '', '', 'Rp 3.354.500', '3']);
  put(tab, 2, 1, { v: 50 }); d = makeDisplay(tab); assert.equal(d.text(2, 5), 'Pesan'); assert.equal(d.text(8, 5), '4'); // tepat di batas = pesan
  const c = chartList(tab); assert.equal(c[0].kind, 'bar'); assert.equal(c[0].ref, 'A1:B8'); assert.equal(sty(tab, 8, 0).b, true);
});
test('Rev 183: modul tetap murni; fungsi hanya yang ada; versi 0.3.121, SCHEMA 17', () => {
  const s = src('src/js/lembar-templat.js'); assert.doesNotMatch(s, /localStorage|document\.|window\.|eval\(|new Function/);
  const used = new Set([...s.matchAll(/'(=[^']*)'/g)].flatMap((m) => [...m[1].matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1])));
  for (const f of used) assert.ok(['SUM', 'SUMIF', 'AVERAGE', 'COUNT', 'COUNTA', 'COUNTIF', 'IF', 'OR', 'MIN', 'TODAY'].includes(f), f);
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22\b/); assert.ok(JSON.parse(src('package.json')).scripts.test.includes('tests/rev186.test.mjs'));
});
