// Rev 57: kartu Servis & pajak + alarm jatuh tempo dari Two Pockets (aksi dueList, hanya baca).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const tp = await import('../src/js/twopockets.js');
const al = await import('../src/js/tp-alarm.js');
const { installReminderInbox } = await import('../src/js/reminders.js');
const URL_OK = 'https://script.google.com/macros/s/AKfycbxABC123_-def/exec';
const store = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k), has: (k) => m.has(k) }; };
const json = (o, status = 200) => ({ status, text: JSON.stringify(o) });
const NOW = new Date(2026, 10, 4, 10, 0, 0).getTime(); // 4 Nov 2026 10:00 waktu HP
const at8 = (y, m, d) => new Date(y, m - 1, d, 8, 0, 0).getTime();
const ITEMS = [
  { id: 'rPajak', vehicle: 'Vario', name: 'Pajak tahunan', kind: 'pajak', dueDate: '2026-12-30', dueKm: 0, daysLeft: 56, kmLeft: null, status: 'aman' },
  { id: 'rOli', vehicle: 'Vario', name: 'Ganti oli', kind: 'servis', dueDate: '2026-10-30', dueKm: 12000, daysLeft: -5, kmLeft: -120, status: 'terlambat' },
  { id: 'rKm', vehicle: 'Beat', name: 'Servis berkala', kind: 'servis', dueDate: '', dueKm: 8000, daysLeft: null, kmLeft: 250, status: 'segera' },
  { id: 'rBelum', vehicle: 'Beat', name: 'Aki', kind: 'servis', dueDate: '', dueKm: 0, daysLeft: null, kmLeft: null, status: 'belum' },
];
const mkApi = (over = {}) => {
  const calls = [], cancels = []; let perm = 0;
  return { calls, cancels, get perm() { return perm; },
    scheduleNotification: (id, title, message, delay, repeat) => { calls.push({ id, title, message, delay, repeat }); return over.result || 'exact_alarm'; },
    cancelScheduledNotification: (id) => cancels.push(id),
    requestNotificationPermission: () => { perm++; } };
};
const dueBody = (items) => json({ ok: true, me: 'RAMA', due: { today: '2026-11-04', items } });
const conn = () => { const s = store(); tp.saveConn({ url: URL_OK, key: 'k1', me: 'RAMA', testedAt: 1 }, s); return s; };

await t('normalizeDue: buang ID tidak valid, status asing jadi belum, teks dipotong, null tetap null', () => {
  const d = tp.normalizeDue({ today: '2026-11-04', items: [
    { id: 'ok1', vehicle: 'x'.repeat(99), name: 'y'.repeat(99), kind: 'aneh', dueDate: '2026-1-1', dueKm: -5, daysLeft: '7', kmLeft: null, status: 'rusak' },
    { id: '../hack', name: 'x' }, null, 'teks', { name: 'tanpa id' },
  ] });
  assert.equal(d.items.length, 1);
  const it = d.items[0];
  assert.equal(it.vehicle.length, 40); assert.equal(it.name.length, 60); assert.equal(it.kind, 'servis');
  assert.equal(it.dueDate, ''); assert.equal(it.dueKm, 0); assert.equal(it.daysLeft, 7); assert.equal(it.kmLeft, null); assert.equal(it.status, 'belum');
  assert.deepEqual(tp.normalizeDue(null), { today: '', items: [] });
});
await t('fetchDue: kirim aksi dueList dengan passcode, hasilnya dibersihkan', async () => {
  let sent;
  const http = async (r) => { sent = r; return dueBody(ITEMS); };
  const r = await tp.fetchDue({ url: URL_OK, key: 'k1' }, http);
  assert.equal(r.ok, true); assert.equal(r.me, 'RAMA'); assert.equal(r.due.items.length, 4);
  assert.equal(sent.method, 'POST'); assert.equal(sent.url, URL_OK);
  assert.deepEqual(JSON.parse(sent.body), { key: 'k1', action: 'dueList' });
});
await t('fetchDue: Code.gs lama, passcode salah, jawaban aneh, jaringan mati, input kosong: tidak melempar error', async () => {
  const a = await tp.fetchDue({ url: URL_OK, key: 'k1' }, async () => json({ ok: false, error: 'Aksi tidak dikenal' }));
  assert.equal(a.ok, false); assert.match(a.msg, /Code\.gs terbaru/);
  const b = await tp.fetchDue({ url: URL_OK, key: 'k1' }, async () => json({ ok: false, error: 'Passcode salah' }));
  assert.match(b.msg, /Passcode salah/);
  const c = await tp.fetchDue({ url: URL_OK, key: 'k1' }, async () => ({ status: 200, text: '<html>Masuk</html>' }));
  assert.equal(c.ok, false); assert.match(c.msg, /tidak dikenali/);
  const d = await tp.fetchDue({ url: URL_OK, key: 'k1' }, async () => { throw new Error('timeout'); });
  assert.equal(d.ok, false); assert.match(d.msg, /Waktu habis/);
  assert.equal((await tp.fetchDue({ url: '', key: '' })).ok, false);
});
await t('cache jatuh tempo: simpan/muat, data rusak = null, daftar alarm disaring', () => {
  const s = store();
  assert.equal(tp.loadDueCache(s), null);
  assert.equal(tp.saveDueCache({ fetchedAt: 5, today: '2026-11-04', items: ITEMS, sched: ['tp:a:d'], alarm: false }, s), true);
  const c = tp.loadDueCache(s);
  assert.equal(c.fetchedAt, 5); assert.equal(c.items.length, 4); assert.deepEqual(c.sched, ['tp:a:d']); assert.equal(c.alarm, false);
  s.setItem(tp.DUE_KEY, JSON.stringify({ fetchedAt: 1, items: [], sched: [1, null, '', 'tp:ok:d'] }));
  assert.deepEqual(tp.loadDueCache(s).sched, ['tp:ok:d']); assert.equal(tp.loadDueCache(s).alarm, true);
  s.setItem(tp.DUE_KEY, '{rusak'); assert.equal(tp.loadDueCache(s), null);
});
await t('nextMorning: sebelum 08:00 = hari ini, sesudahnya = besok', () => {
  assert.equal(al.nextMorning(new Date(2026, 10, 4, 6, 0).getTime()), at8(2026, 11, 4));
  assert.equal(al.nextMorning(new Date(2026, 10, 4, 10, 0).getTime()), at8(2026, 11, 5));
  assert.equal(al.nextMorning(new Date(2026, 10, 4, 7, 59, 30).getTime()), at8(2026, 11, 5), 'kurang dari 1 menit = besok');
  assert.equal(al.nextMorning(new Date(2026, 11, 31, 12, 0).getTime()), at8(2027, 1, 1), 'ganti tahun');
});
await t('planAlarms: 7 hari sebelum + hari-H; terlambat = satu alarm pagi berikutnya; km menipis; belum = tidak ada', () => {
  const plan = al.planAlarms(ITEMS, NOW);
  const byId = Object.fromEntries(plan.map((p) => [p.id, p]));
  assert.deepEqual(Object.keys(byId).sort(), ['tp:rKm:n', 'tp:rOli:n', 'tp:rPajak:d', 'tp:rPajak:w']);
  assert.equal(byId['tp:rPajak:w'].at, at8(2026, 12, 23)); assert.equal(byId['tp:rPajak:d'].at, at8(2026, 12, 30));
  assert.equal(byId['tp:rOli:n'].at, at8(2026, 11, 5)); assert.equal(byId['tp:rKm:n'].at, at8(2026, 11, 5));
  assert.equal(byId['tp:rPajak:w'].title, 'Vario: Pajak tahunan'); assert.match(byId['tp:rPajak:w'].message, /7 hari lagi \(30 Des 2026\)/);
  assert.match(byId['tp:rPajak:d'].message, /hari ini/);
  assert.match(byId['tp:rOli:n'].message, /Terlambat 5 hari/); assert.match(byId['tp:rOli:n'].message, /lewat 120 km/);
  assert.match(byId['tp:rKm:n'].message, /sisa 250 km/);
});
await t('planAlarms: jatuh tempo hari ini pukul 10:00 dan yang sudah lewat tidak membuat alarm masa lalu', () => {
  const hariIni = [{ id: 'r1', vehicle: '', name: 'STNK', kind: 'pajak', dueDate: '2026-11-04', dueKm: 0, daysLeft: 0, kmLeft: null, status: 'segera' }];
  assert.deepEqual(al.planAlarms(hariIni, NOW), []);
  const dekat = [{ ...hariIni[0], dueDate: '2026-11-08', daysLeft: 4 }]; // w sudah lewat (1 Nov), d = 8 Nov
  assert.deepEqual(al.planAlarms(dekat, NOW).map((p) => p.id), ['tp:r1:d']);
  assert.equal(al.planAlarms(dekat, NOW)[0].title, 'STNK', 'tanpa nama kendaraan: tanpa titik dua');
  for (const p of al.planAlarms(ITEMS, NOW)) assert.ok(p.at > NOW);
});
await t('describeDue: sisa hari dihitung dari tanggal hari ini, bukan angka lama server', () => {
  assert.equal(al.describeDue(ITEMS[0], '2026-11-04'), 'Aman \u00b7 jatuh tempo 30 Des 2026 (56 hari lagi)');
  assert.equal(al.describeDue(ITEMS[0], '2026-12-29'), 'Aman \u00b7 jatuh tempo 30 Des 2026 (1 hari lagi)');
  assert.equal(al.describeDue(ITEMS[0], '2026-12-30'), 'Aman \u00b7 jatuh tempo 30 Des 2026 (hari ini)');
  assert.equal(al.describeDue(ITEMS[1], '2026-11-04'), 'Terlambat \u00b7 jatuh tempo 30 Okt 2026 (terlambat 5 hari) \u00b7 lewat 120 km');
  assert.equal(al.describeDue(ITEMS[2], '2026-11-04'), 'Segera \u00b7 sisa 250 km');
  assert.equal(al.describeDue(ITEMS[3], '2026-11-04'), 'Belum terjadwal');
  assert.equal(al.fmtNum(12500), '12.500');
});
await t('applyAlarms: jeda dihitung dari sekarang, tanpa pengulangan, alarm lama yang hilang dibatalkan', () => {
  const a = mkApi();
  const plan = al.planAlarms(ITEMS, NOW);
  const r = al.applyAlarms(plan, ['tp:rPajak:d', 'tp:basi:d'], NOW, a);
  assert.equal(r.ok, true); assert.equal(r.ids.length, 4);
  const d = a.calls.find((c) => c.id === 'tp:rPajak:d');
  assert.equal(d.delay, at8(2026, 12, 30) - NOW); assert.equal(d.repeat, 0);
  assert.deepEqual(a.cancels, ['tp:basi:d'], 'hanya yang tidak ada lagi di rencana');
});
await t('applyAlarms: izin notifikasi ditolak, alarm tepat tidak ada, native error, tanpa jembatan native', () => {
  const plan = al.planAlarms(ITEMS, NOW);
  const a1 = mkApi({ result: 'permission_denied' }); const r1 = al.applyAlarms(plan, [], NOW, a1);
  assert.equal(r1.ok, false); assert.equal(r1.reason, 'permission'); assert.equal(a1.perm, 1); assert.deepEqual(r1.ids, []);
  const r2 = al.applyAlarms(plan, [], NOW, mkApi({ result: 'inexact_alarm' }));
  assert.equal(r2.ok, true); assert.equal(r2.warning, 'inexact_alarm'); assert.equal(r2.ids.length, 4);
  const r3 = al.applyAlarms(plan, [], NOW, mkApi({ result: 'error' }));
  assert.equal(r3.ok, false); assert.equal(r3.reason, 'native_error');
  const boom = { scheduleNotification: () => { throw new Error('x'); }, cancelScheduledNotification: () => {} };
  assert.equal(al.applyAlarms(plan, [], NOW, boom).ok, false);
  assert.equal(al.applyAlarms(plan, [], NOW, null).reason, 'unavailable');
});
await t('refreshDue: tanpa sambungan tidak melakukan apa pun', async () => {
  let called = 0;
  const r = await al.refreshDue({ store: store(), http: async () => { called++; return dueBody([]); }, api: mkApi(), now: NOW });
  assert.equal(r.ok, false); assert.equal(r.reason, 'noconn'); assert.equal(called, 0);
});
await t('refreshDue: muat, simpan cache, pasang alarm; panggilan dalam 3 jam dilewati kecuali dipaksa', async () => {
  const s = conn(); const a = mkApi(); let posts = 0;
  const http = async () => { posts++; return dueBody(ITEMS); };
  const r1 = await al.refreshDue({ store: s, http, api: a, now: NOW });
  assert.equal(r1.ok, true); assert.equal(posts, 1); assert.equal(a.calls.length, 4);
  const c = tp.loadDueCache(s); assert.equal(c.fetchedAt, NOW); assert.equal(c.sched.length, 4); assert.equal(c.items.length, 4);
  const r2 = await al.refreshDue({ store: s, http, api: a, now: NOW + 2 * 3600000 });
  assert.equal(r2.skipped, true); assert.equal(posts, 1);
  const r3 = await al.refreshDue({ store: s, http, api: a, now: NOW + 3 * 3600000 + 1 });
  assert.equal(r3.skipped, undefined); assert.equal(posts, 2);
  const r4 = await al.refreshDue({ store: s, http, api: a, now: NOW + 3 * 3600000 + 5, force: true });
  assert.equal(posts, 3); assert.equal(r4.ok, true);
});
await t('refreshDue: gagal/offline membiarkan cache dan alarm lama; item yang hilang dibatalkan alarmnya', async () => {
  const s = conn(); const a = mkApi();
  await al.refreshDue({ store: s, http: async () => dueBody(ITEMS), api: a, now: NOW });
  const before = JSON.stringify(tp.loadDueCache(s));
  const a2 = mkApi();
  const bad = await al.refreshDue({ store: s, http: async () => { throw new Error('timeout'); }, api: a2, now: NOW + 4 * 3600000 });
  assert.equal(bad.ok, false); assert.equal(bad.reason, 'fetch'); assert.equal(a2.calls.length, 0); assert.equal(a2.cancels.length, 0);
  assert.equal(JSON.stringify(tp.loadDueCache(s)), before, 'cache tidak berubah saat gagal');
  // pajak sudah dibayar: item hilang dari daftar -> w dan d dibatalkan
  const a3 = mkApi();
  await al.refreshDue({ store: s, http: async () => dueBody(ITEMS.filter((x) => x.id !== 'rPajak')), api: a3, now: NOW + 5 * 3600000 });
  assert.deepEqual(a3.cancels.sort(), ['tp:rPajak:d', 'tp:rPajak:w']);
  assert.ok(!tp.loadDueCache(s).sched.some((id) => id.startsWith('tp:rPajak')));
});
await t('refreshDue: dua pemanggil bersamaan berbagi satu permintaan', async () => {
  const s = conn(); let posts = 0;
  const http = async () => { posts++; await new Promise((r) => setTimeout(r, 5)); return dueBody(ITEMS); };
  const [x, y] = await Promise.all([al.refreshDue({ store: s, http, api: mkApi(), now: NOW }), al.refreshDue({ store: s, http, api: mkApi(), now: NOW })]);
  assert.equal(posts, 1); assert.equal(x, y);
});
await t('alarm dimatikan: daftar tetap dimuat tetapi tidak ada alarm; alarm lama dibatalkan; menyalakan lagi tanpa internet', async () => {
  const s = conn(); const a = mkApi();
  await al.refreshDue({ store: s, http: async () => dueBody(ITEMS), api: a, now: NOW });
  const off = mkApi(); al.setAlarmEnabled(false, { store: s, api: off, now: NOW });
  assert.equal(off.cancels.length, 4); assert.equal(tp.loadDueCache(s).alarm, false); assert.deepEqual(tp.loadDueCache(s).sched, []);
  const quiet = mkApi();
  const r = await al.refreshDue({ store: s, http: async () => dueBody(ITEMS), api: quiet, now: NOW + 4 * 3600000 });
  assert.equal(r.ok, true); assert.equal(quiet.calls.length, 0); assert.equal(tp.loadDueCache(s).items.length, 4);
  const on = mkApi(); al.setAlarmEnabled(true, { store: s, api: on, now: NOW + 4 * 3600000 });
  assert.equal(on.calls.length, 4); assert.equal(tp.loadDueCache(s).alarm, true); assert.equal(tp.loadDueCache(s).sched.length, 4);
});
await t('reapplyAlarms (setelah Pulihkan cadangan) memasang ulang dari cache; alarm mati/cache kosong dilewati', async () => {
  const s = conn();
  assert.equal(al.reapplyAlarms({ store: s, api: mkApi(), now: NOW }).skipped, true);
  await al.refreshDue({ store: s, http: async () => dueBody(ITEMS), api: mkApi(), now: NOW });
  const a = mkApi(); const r = al.reapplyAlarms({ store: s, api: a, now: NOW + 60000 });
  assert.equal(a.calls.length, 4); assert.equal(r.alarm.ids.length, 4);
  al.setAlarmEnabled(false, { store: s, api: mkApi(), now: NOW });
  const a2 = mkApi(); assert.equal(al.reapplyAlarms({ store: s, api: a2, now: NOW }).skipped, true); assert.equal(a2.calls.length, 0);
});
await t('dropDue dan disconnect: batalkan semua alarm, hapus daftar; disconnect juga hapus sambungan', async () => {
  const s = conn(); await al.refreshDue({ store: s, http: async () => dueBody(ITEMS), api: mkApi(), now: NOW });
  const a = mkApi(); al.dropDue({ store: s, api: a });
  assert.equal(a.cancels.length, 4); assert.equal(s.has(tp.DUE_KEY), false); assert.notEqual(tp.loadConn(s), null);
  await al.refreshDue({ store: s, http: async () => dueBody(ITEMS), api: mkApi(), now: NOW });
  const b = mkApi(); al.disconnect({ store: s, api: b });
  assert.equal(b.cancels.length, 4); assert.equal(s.has(tp.DUE_KEY), false); assert.equal(tp.loadConn(s), null);
  assert.doesNotThrow(() => al.disconnect({ store: store(), api: mkApi() }));
});
await t('ketukan notifikasi tp:... membuka layar Two Pockets; tanpa penangan = tidak melakukan apa pun', () => {
  let opened = 0;
  globalThis.AndroidAPI = { takeReminder: () => 'tp:rPajak:d' };
  const ctx = { data: { tasks: [], notes: [] } };
  installReminderInbox(ctx, () => assert.fail('bukan tugas'), () => assert.fail('bukan catatan'), () => { opened++; });
  assert.equal(opened, 1);
  installReminderInbox(ctx, () => {}, () => {}); // tanpa penangan: tidak error
  delete globalThis.AndroidAPI; delete globalThis.__kelimaaReminderOpened;
});
await t('kabel: layar Servis & pajak, tombol, pasang ulang setelah Pulihkan, hook buka dan kembali ke aplikasi', () => {
  const st = src('../src/js/settings.js'), mn = src('../src/js/main.js');
  for (const k of ["'Servis, pajak, tagihan & utang'", "'Muat ulang'", "'Alarm jatuh tempo'", 'reapplyAlarms()', 'disconnect()', 'dropDue()', 'describeDue(it)', "from './tp-alarm.js'"]) assert.ok(st.includes(k), k);
  assert.ok(st.indexOf('cancelAllReminders(); replaceData') < st.indexOf('reapplyAlarms()'), 'pasang ulang SESUDAH cancelAllReminders');
  for (const k of ["from './tp-alarm.js'", "ui.moreView = 'twopockets'", 'refreshDue()']) assert.ok(mn.includes(k), k);
  assert.ok((mn.match(/refreshDue\(\)/g) || []).length >= 2, 'saat buka dan saat kembali ke layar');
});
await t('aman: tidak ikut cadangan, tanpa perubahan native/skema, tidak mengirim data aplikasi', () => {
  for (const f of ['storage.js', 'backup.js', 'cadangan-gambar.js']) { const x = src('../src/js/' + f); assert.ok(!/twopockets|tp-alarm|kelimaa_twopockets/.test(x), f); }
  assert.equal(tp.DUE_KEY, 'kelimaa_twopockets_due');
  assert.ok(!/MainActivity/.test(src('../src/js/tp-alarm.js')));
  assert.ok(/SCHEMA = 22/.test(src('../src/js/storage.js')));
  const body = src('../src/js/twopockets.js'); const f = body.slice(body.indexOf('export async function fetchDue'));
  assert.ok(!/ctx\.data|tasks|notes/.test(f.slice(0, f.indexOf('// Cache:'))), 'fetchDue tidak menyentuh data catatan/tugas');
});
await t('versi 0.3.2 selaras di package.json, layar Setelan, RIWAYAT', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('../RIWAYAT.md').includes('versi 0.3.2'));
});
console.log(n + ' tes lulus');
