// Tes regresi untuk h(): anak berupa array bersarang harus jadi elemen, bukan teks "[object HTMLDivElement]".
class Node_ { constructor(t) { this.nodeType = t; this.kids = []; } append(...k) { this.kids.push(...k); } }
class El extends Node_ { constructor(tag) { super(1); this.tag = tag; this.attrs = {}; } setAttribute(k, v) { this.attrs[k] = v; } addEventListener() {} }
class Txt extends Node_ { constructor(t) { super(3); this.text = t; } }
globalThis.document = { createElement: (t) => new El(t), createTextNode: (t) => new Txt(t), querySelector: () => null };
const { h } = await import('../src/js/ui.js');
let ok = 0; const t = (name, fn) => { fn(); ok++; console.log('ok - ' + name); };
const assert = (c, m) => { if (!c) throw new Error('GAGAL: ' + m); };

t('array bersarang dua tingkat jadi elemen, tanpa teks "object"', () => {
  const list = [h('div'), h('div')];
  const el = h('main', {}, [h('h1'), list, [h('p'), [h('div')]]]);
  assert(el.kids.length === 5, 'jumlah anak 5, dapat ' + el.kids.length);
  assert(el.kids.every((k) => k.nodeType === 1), 'semua anak harus elemen');
});
t('null dan false dilewati, tidak jadi teks', () => {
  const el = h('div', {}, null, false, [null, h('b')]);
  assert(el.kids.length === 1 && el.kids[0].tag === 'b', 'hanya satu elemen b');
});
t('teks biasa tetap jadi teks', () => {
  const el = h('div', {}, 'halo', 5);
  assert(el.kids.map((k) => k.text).join() === 'halo,5', 'teks dan angka tetap tampil');
});
// ---- Rev 12: judul layar berupa gambar ----
const fs = await import('node:fs');
const { JUDUL, judul } = await import('../src/js/ui.js');
const { SCOPES } = await import('../src/js/logic.js');
t('judul(): h1 berisi dua gambar (terang + gelap), teks asli ada di alt', () => {
  for (const k of Object.keys(JUDUL)) {
    const el = judul(k);
    assert(el.tag === 'h1' && el.className === (k === 'privat' ? 'jdl mid' : 'jdl'), k + ': harus h1.jdl (privat: jdl mid)');
    assert(el.kids.length === 2 && el.kids.every((x) => x.tag === 'img'), k + ': dua img (-t dan -g)');
    assert(el.kids[0].className === 'jdl-t' && el.kids[1].className === 'jdl-g', k + ': kelas jdl-t lalu jdl-g');
    assert(el.kids[0].attrs.alt === JUDUL[k][0] && el.kids[0].attrs.alt.length > 3, k + ': alt');
  }
});
t('judul(): berkas SVG terang dan gelap benar-benar ada di src/img/judul dan tidak kosong', () => {
  for (const [k, [, berkas]] of Object.entries(JUDUL)) {
    for (const tema of ['t', 'g']) {
      const f = new URL(`../src/img/judul/${berkas}-${tema}.svg`, import.meta.url);
      assert(fs.existsSync(f) && fs.statSync(f).size > 1500, k + ': ' + berkas + '-' + tema + '.svg tidak ada');
      assert(fs.readFileSync(f, 'utf8').startsWith('<svg '), k + ': bukan SVG');
    }
  }
});
t('judul(): semua 4 bagian Tugas + Catatan + Privat punya gambar', () => {
  for (const sc of SCOPES) assert(JUDUL[sc.id], 'judul untuk ' + sc.id);
  assert(JUDUL.catatan && JUDUL.privat, 'catatan dan privat');
});
t('src/js tidak lagi membuat h1 teks untuk 6 judul utama', () => {
  const main = fs.readFileSync(new URL('../src/js/main.js', import.meta.url), 'utf8');
  const notes = fs.readFileSync(new URL('../src/js/notes.js', import.meta.url), 'utf8');
  const priv = fs.readFileSync(new URL('../src/js/privat.js', import.meta.url), 'utf8');
  assert(!/sc\.emoji \+ ' ' \+ sc\.title/.test(main), 'judul Tugas masih teks');
  assert(!/h\('h1', \{\}, isP/.test(notes), 'judul Catatan masih teks');
  assert(!/h\('h1', \{\}, 'Catatan Privat/.test(priv), 'judul Privat masih teks');
});
t('CSS: judul kartu catatan KAPITAL lewat text-transform (data tidak diubah)', () => {
  const css = fs.readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
  assert(/\.card b\{text-transform:uppercase\}/.test(css), 'aturan uppercase untuk .card b');
});
t('Rev 13/372: logo Catatan Private di tengah; judul editor KAPITAL hanya tampilan', () => {
  const css = fs.readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
  assert(/h1\.jdl\.mid img\{[^}]*margin:-7px auto/.test(css), 'logo privat dipusatkan');
  assert(/\.ttl\{text-transform:uppercase\}/.test(css), 'judul editor uppercase');
  assert(/\.ttl::placeholder\{text-transform:none\}/.test(css), 'placeholder tidak ikut kapital');
  const n = fs.readFileSync(new URL('../src/js/notes.js', import.meta.url), 'utf8');
  assert(!/toUpperCase/.test(n), 'data judul tidak diubah lewat JS');
});
console.log(`\n${ok} tes UI lulus`);
