// Rev 237 / Tahap 8a: Insight mingguan (murni, dihitung di HP). Tidak membaca Privat/sampah/isi catatan; tidak mengirim apa pun sendiri.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { buildInsight, insightPrompt, INSIGHT_MAX } from '../src/js/ai/insight.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 12, 10, 0, 0).getTime(), DAY = 86400000;
const data = () => ({
  tasks: [
    { id: 't1', title: 'Bayar listrik', done: false, due: '2026-11-10', pri: 1 }, { id: 't2', title: 'Kirim laporan', done: false, due: '2026-11-14' },
    { id: 't3', title: 'Jauh', done: false, due: '2026-12-30' }, { id: 't4', title: 'Selesai', done: true, due: '2026-11-01' }, { id: 't5', title: 'Tanpa tenggat', done: false },
  ],
  notes: [{ id: 'n1', title: 'RAHASIA JUDUL', text: 'ISI RAHASIA', updated: NOW - DAY }, { id: 'n2', title: 'Lama', updated: NOW - 30 * DAY }],
  priv: [{ id: 'p', title: 'PRIVAT' }], trash: [{ id: 'z', title: 'SAMPAH' }],
  projects: [
    { id: 'a', name: 'Renovasi', desc: 'DESK RAHASIA', status: 'aktif', at: 5, due: NOW - 2 * DAY, tasks: ['t1', 't4'], notes: [] },
    { id: 'b', name: 'Belajar', status: 'aktif', at: 9, due: NOW + 5 * DAY, tasks: [], notes: [] }, { id: 'c', name: 'Arsip', status: 'arsip', at: 1, tasks: [], notes: [] },
  ],
});
test('statistik: tugas terbuka/terlambat/7 hari/penting, catatan 7 hari, proyek lewat/dekat tenggat', () => {
  const r = buildInsight(data(), NOW);
  assert.deepEqual(r.stats, { open: 4, late: 1, soon: 1, important: 1, notesWeek: 1, projects: 2, projLate: 1, projSoon: 1 });
  assert.equal(r.empty, false); assert.match(r.lines[0], /^Tugas belum selesai: 4 \(1 terlambat, 1 jatuh tempo 7 hari ke depan, 1 penting\)$/);
  assert.match(r.text, /Bayar listrik, tenggat 2026-11-10 \(terlambat\)/); assert.match(r.text, /Renovasi, 1 dari 2 tugas selesai/); assert.match(r.text, /Belajar, belum ada tugas tertaut, tenggat 2026-11-17/);
  assert.ok(r.text.indexOf('Bayar listrik') < r.text.indexOf('Kirim laporan'));
});
test('privasi: tanpa judul/isi catatan, Privat, sampah, deskripsi proyek, proyek arsip', () => {
  const t = buildInsight(data(), NOW).text; assert.doesNotMatch(t, /RAHASIA|PRIVAT|SAMPAH|DESK|Arsip|Selesai\b|Jauh/);
  const s = readFileSync(new URL('../src/js/ai/insight.js', import.meta.url), 'utf8').replace(/^\/\/.*$/gm, ''); assert.doesNotMatch(s, /\.priv\b|\.trash\b|\.sheets\b|\.habits\b|innerHTML|document\.|fetch|localStorage/);
});
test('data kosong/rusak aman; empty bernilai true', () => {
  const r = buildInsight({}, NOW); assert.equal(r.empty, true); assert.match(r.lines[0], /^Tugas belum selesai: 0$/); assert.doesNotThrow(() => buildInsight(null, NOW)); assert.doesNotThrow(() => buildInsight({ tasks: [null, 3, {}], notes: [null], projects: [{}, 4] }, NOW));
});
test('batas: teks <= INSIGHT_MAX, maks. 5 butir per daftar; insightPrompt <= batas pesan', () => {
  const d = { tasks: Array.from({ length: 40 }, (_, i) => ({ id: 'k' + i, title: 'Tugas panjang sekali nomor ' + i + ' '.repeat(3) + 'x'.repeat(80), due: '2026-11-0' + (1 + (i % 9)) })), projects: Array.from({ length: 12 }, (_, i) => ({ id: 'p' + i, name: 'P' + i, status: 'aktif', at: i + 1, tasks: [], notes: [] })) };
  const r = buildInsight(d, NOW); assert.ok(r.text.length <= INSIGHT_MAX); assert.equal(r.lines.filter((l) => l.startsWith('- ')).length <= 10, true);
  assert.ok(insightPrompt(r.text, 4000).length <= 4000); assert.ok(insightPrompt('x'.repeat(5000), 600).length <= 600); assert.match(insightPrompt('abc'), /3 saran prioritas[\s\S]*abc$/);
});
test('obrolan.js: tombol hanya mengisi kolom pesan (tidak mengirim), nonaktif bila kosong; tetap malas; versi 0.3.121; tes terdaftar', () => {
  const o = src('src/js/ai/obrolan.js'); assert.match(o, /from '\.\/insight\.js'/); assert.match(o, /'Insight mingguan'/); assert.match(o, /ta\.value = insightPrompt\(ins\.text, CHAT_MAX_MSG\)/); assert.match(o, /disabled: ins\.empty/);
  const blok = o.slice(o.indexOf('Rev 237: ringkasan'), o.indexOf("'Minta saran AI'")); assert.doesNotMatch(blok, /send\.onclick|kirimChat|send\.click/);
  for (const f of ['main.js', 'notes.js', 'settings.js']) assert.doesNotMatch(src('src/js/' + f), /insight/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev237\.test\.mjs/);
});
