// Rev 266 / V1: model validasi diperluas (rentang, warna per pilihan, dd, mode) TANPA SCHEMA baru dan tanpa UI. Tes Node; BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as V from '../src/js/lembar-validasi.js'; import * as L from '../src/js/lembar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet({ id: 'v', name: 'v' }); return sh.tabs[0]; };
const ids = (t) => new Set(t.cols.map((c) => c.id));
test('aturan lama tidak berubah: bentuk, satu per kolom penuh, tanpa kunci baru', () => {
  const t = mk(); const c = t.cols[1].id;
  const ck = V.cleanCheck({ id: 'ab12', c, k: 'list', items: ['a', 'b'] }, ids(t));
  assert.deepEqual(ck, { id: 'ab12', c, k: 'list', items: ['a', 'b'] });
  assert.equal(V.cleanChecks([ck, { ...ck, id: 'zz99', items: ['x'] }], t.cols, t.rows).length, 2, 'Rev 276: kolom penuh kembar BOLEH');
  assert.equal(JSON.stringify(V.cleanChecks([ck], t.cols, t.rows)), JSON.stringify([ck]));
});
test('warna per pilihan: hanya pilihan yang ada, hanya #RRGGBB, huruf besar, entri kosong dibuang', () => {
  const t = mk(); const c = t.cols[0].id;
  const ck = V.cleanCheck({ id: 'ab12', c, k: 'list', items: ['Fashion', 'Audio'], cl: { Fashion: { bg: '#dc2626', fg: 'x' }, Audio: { bg: 'merah' }, Lain: { bg: '#000000' } } }, ids(t));
  assert.deepEqual(ck.cl, { Fashion: { bg: '#DC2626' } });
  assert.equal(V.cleanCheck({ id: 'ab12', c, k: 'list', items: ['a'], cl: { a: {} } }, ids(t)).cl, undefined);
  assert.deepEqual(V.colorOf(ck, ' fashion '), { bg: '#DC2626' }); assert.equal(V.colorOf(ck, 'Audio'), null); assert.equal(V.colorOf(ck, 'zzz'), null); assert.equal(V.colorOf(null, 'a'), null);
  const w = V.withColor(ck, 'Audio', '#1e3a8a', '#ffffff'); assert.deepEqual(w.cl.Audio, { bg: '#1E3A8A', fg: '#FFFFFF' }); assert.equal(ck.cl.Audio, undefined, 'asli tidak diubah');
  assert.equal(V.withColor(w, 'Audio', '', '').cl.Audio, undefined); assert.equal(V.withColor(ck, 'Tidak ada', '#000000'), ck);
});
test('rentang: kolom kiri-kanan, batas baris, null = tanpa batas, kolom penuh disingkat', () => {
  const t = mk(); const [a, b, c2] = t.cols.map((x) => x.id), r = t.rows.map((x) => x.id);
  const ck = V.cleanCheck({ id: 'ab12', c: b, k: 'list', items: ['x'], rg: { c2: c2, r1: r[1], r2: r[4] } }, ids(t), new Set(r), new Map(t.cols.map((x, i) => [x.id, i])));
  assert.deepEqual(V.checkRect({ ...t, checks: [ck] }, ck), { r1: 1, r2: 4, c1: 1, c2: 2 });
  const sw = V.cleanCheck({ id: 'ab12', c: c2, k: 'list', items: ['x'], rg: { c2: a } }, ids(t), new Set(r), new Map(t.cols.map((x, i) => [x.id, i])));
  assert.equal(sw.c, a); assert.equal(sw.rg.c2, c2, 'kolom ditukar bila terbalik');
  const full = V.cleanCheck({ id: 'ab12', c: a, k: 'list', items: ['x'], rg: { c2: a } }, ids(t)); assert.equal(full.rg, undefined);
  const open = V.cleanCheck({ id: 'ab12', c: a, k: 'list', items: ['x'], rg: { c2: a, r1: r[2] } }, ids(t), new Set(r)); assert.deepEqual(open.rg, { c2: a, r1: r[2] });
  assert.equal(V.cleanCheck({ id: 'ab12', c: a, k: 'list', items: ['x'], rg: { c2: a, r1: 'hilang' } }, ids(t), new Set(r)).rg, undefined, 'batas baris yang hilang jadi tanpa batas');
});
test('aturan di kolom yang sama dengan rentang beda boleh; rentang kembar dibuang; maks. MAX_CHECKS', () => {
  const t = mk(); const a = t.cols[0].id, r = t.rows.map((x) => x.id);
  const x1 = { c: a, k: 'list', items: ['p'], rg: { c2: a, r1: r[0], r2: r[4] } }, x2 = { c: a, k: 'list', items: ['q'], rg: { c2: a, r1: r[5], r2: r[9] } };
  assert.equal(V.cleanChecks([x1, x2, { ...x2 }], t.cols, t.rows).length, 3); // Rev 276: rentang kembar boleh
  const many = Array.from({ length: 15 }, (_, i) => ({ c: a, k: 'list', items: ['i' + i], rg: { c2: a, r1: r[i], r2: r[i] } })); assert.equal(V.cleanChecks(many, t.cols, t.rows).length, V.MAX_CHECKS);
});
test('checkAt/invalidCells mengikuti rentang; aturan pertama menang; kolom penuh seperti dulu', () => {
  const t = mk(); const [a, b] = t.cols.map((x) => x.id), r = t.rows.map((x) => x.id);
  t.checks = V.cleanChecks([{ c: a, k: 'list', items: ['ya'], rg: { c2: b, r1: r[1], r2: r[2] } }, { c: a, k: 'list', items: ['tidak'] }], t.cols, t.rows);
  assert.equal(t.checks.length, 2); assert.equal(V.checkAt(t, 1, 1), t.checks[0]); assert.equal(V.checkAt(t, 0, 0), t.checks[1]); assert.equal(V.checkAt(t, 3, 1), null);
  const txt = { '0,0': 'ya', '1,0': 'ya', '1,1': 'salah', '3,1': 'bebas', '4,0': 'ya' };
  const bad = V.invalidCells(t, (i, j) => txt[i + ',' + j] || '');
  assert.deepEqual([...bad].sort(), ['0,0', '1,0', '1,1', '4,0']); // Rev 276: SEMUA aturan pencakup diperiksa; 'ya' di A2 lolos aturan 1 tetapi gagal aturan kolom penuh ('tidak')
});
test('dd dan mode hanya tersimpan bila bukan bawaan', () => {
  const t = mk(); const c = t.cols[0].id; const base = { c, k: 'list', items: ['a'] };
  assert.deepEqual(Object.keys(V.cleanCheck({ ...base, dd: true, mode: 'tanda' }, ids(t))), ['id', 'c', 'k', 'items']);
  const x = V.cleanCheck({ ...base, dd: false, mode: 'tolak' }, ids(t)); assert.equal(x.dd, false); assert.equal(x.mode, undefined); // Rev 276: mode dibuang
});
test('lembar.js: simpan/muat membawa rentang+warna; hapus kolom ujung kanan menyusutkan; hapus baris batas menyusutkan (Rev 272); SCHEMA tetap 20', () => {
  const t = mk(); const [a, b] = t.cols.map((x) => x.id), r = t.rows.map((x) => x.id);
  assert.ok(L.setChecks(t, [{ c: a, k: 'list', items: ['Fashion'], cl: { Fashion: { bg: '#DC2626' } }, rg: { c2: b, r1: r[1], r2: r[3] } }]));
  const back = L.cleanTab ? L.cleanTab(JSON.parse(JSON.stringify(t))) : null; if (back) assert.deepEqual(back.checks, t.checks);
  L.deleteCol(t, b); assert.deepEqual(t.checks[0].rg, { c2: a, r1: r[1], r2: r[3] }); // kolom ujung hilang: menyusut ke kolom kiri, batas baris tetap
   assert.equal(t.checks[0].cl.Fashion.bg, '#DC2626');
  L.setChecks(t, [{ c: a, k: 'list', items: ['x'], rg: { c2: a, r1: r[1], r2: r[3] } }]); L.deleteRow(t, r[3]); assert.deepEqual(t.checks[0].rg, { c2: a, r1: r[1], r2: r[2] }); // Rev 272 (disengaja): baris ujung dihapus = rentang MENYUSUT, tidak lagi melebar
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
});
test('modul tetap murni: tanpa DOM/penyimpanan/eval dan tanpa impor lembar.js/rumus.js', () => {
  const m = src('src/js/lembar-validasi.js'); assert.doesNotMatch(m, /document\.|localStorage|eval\(|Capacitor|^import /m);
});
