// Rev 166 / Q10 tahap 2 (Cari data bagian 2): INDEX(rentang; baris; [kolom]). VLOOKUP = Rev 167, HLOOKUP + audit = Rev 168.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { argHint } from '../src/js/rumus-bantu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 9, 0, 0).getTime();
function mk(grid) { const t = L.newTab('T', 12); grid.forEach((row, ri) => row.forEach((v, ci) => { if (v === undefined || v === null) return; L.setCell(t, t.rows[ri].id, t.cols[ci].id, { v }); })); return t; }
function at(grid, f) { const t = mk(grid); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cH = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cH'); }
const TAB = [['apel', 10, 'A'], ['jeruk', 20, 'B'], ['pisang', 30, 'C'], ['kiwi', 40, 'D']];

test('INDEX rentang dua dimensi: baris + kolom, posisi mulai 1, nilai teks/angka/boolean', () => {
  assert.equal(at(TAB, '=INDEX(A1:C4;1;1)'), 'apel'); assert.equal(at(TAB, '=INDEX(A1:C4;3;2)'), 30); assert.equal(at(TAB, '=INDEX(A1:C4;4;3)'), 'D'); assert.equal(at(TAB, '=INDEX(B2:C3;2;2)'), 'C'); // rentang tidak harus mulai di A1
  assert.equal(at([[true, 2]], '=INDEX(A1:B1;1;1)'), true); assert.equal(at(TAB, '=INDEX(A1:C4;"2";"2")'), 20); assert.equal(at(TAB, '=INDEX(A1:C4;2,9;1)'), 'jeruk'); // pecahan dipotong, teks angka dikoersi
  assert.equal(at(TAB, '=INDEX(B1:B4;2;1)'), 20);
});
test('INDEX satu baris / satu kolom: cukup satu nomor', () => {
  assert.equal(at(TAB, '=INDEX(A1:A4;3)'), 'pisang'); assert.equal(at(TAB, '=INDEX(A1:C1;3)'), 'A'); assert.equal(at(TAB, '=INDEX(A1:C1;2)'), 10); assert.equal(at(TAB, '=INDEX(A1:A4;4;1)'), 'kiwi');
  assert.equal(at(TAB, '=INDEX(A1:C1;1;3)'), 'A'); assert.equal(at([], '=INDEX(5;1)'), 5); assert.equal(at([], '=INDEX(5;2)').e, '#REF!'); // nilai tunggal = rentang satu sel
});
test('INDEX galat: di luar rentang #REF!, 0/negatif/kurang kolom pada 2D #VALUE!, galat menjalar', () => {
  assert.equal(at(TAB, '=INDEX(A1:C4;5;1)').e, '#REF!'); assert.equal(at(TAB, '=INDEX(A1:C4;1;4)').e, '#REF!'); assert.equal(at(TAB, '=INDEX(A1:A4;5)').e, '#REF!'); assert.equal(at(TAB, '=INDEX(A1:C1;4)').e, '#REF!');
  assert.equal(at(TAB, '=INDEX(A1:C4;0;1)').e, '#VALUE!'); assert.equal(at(TAB, '=INDEX(A1:C4;1;0)').e, '#VALUE!'); assert.equal(at(TAB, '=INDEX(A1:C4;-1;1)').e, '#VALUE!'); assert.equal(at(TAB, '=INDEX(A1:A4;0)').e, '#VALUE!');
  assert.equal(at(TAB, '=INDEX(A1:C4;2)').e, '#VALUE!'); // 2D tanpa kolom = seluruh baris, belum didukung
  assert.equal(at(TAB, '=INDEX(A1:C4;"x";1)').e, '#VALUE!'); assert.equal(at(TAB, '=INDEX(A1:C4;1/0;1)').e, '#DIV/0!'); assert.equal(at(TAB, '=INDEX(A1:C4;A1:A2;1)').e, '#VALUE!'); assert.equal(at(TAB, '=INDEX(1/0;1)').e, '#DIV/0!');
  const t = mk([[1], [2], [3]]); t.rows[1].cells.cA = { fx: R.a1ToStored('=1/0', t).fx }; t.rows[0].cells.cH = { fx: R.a1ToStored('=INDEX(A1:A3;2)', t).fx }; t.rows[1].cells.cH = { fx: R.a1ToStored('=INDEX(A1:A3;3)', t).fx };
  const c = R.computeTab(t, { now: NOW }); assert.equal(c.get('r1', 'cH').e, '#DIV/0!'); assert.equal(c.get('r2', 'cH'), 3); // hanya galat di sel yang diambil menjalar
  assert.equal(at([['a'], [null], ['c']], '=INDEX(A1:A3;2)'), 0); // sel kosong = 0 seperti Excel assert.equal(at([['a'], [null], ['c']], '=IFERROR(INDEX(A1:A3;7);"habis")'), 'habis');
});
test('INDEX + MATCH = cari data; hasil ikut urutan hitung dan siklus', () => {
  assert.equal(at(TAB, '=INDEX(B1:B4;MATCH("pisang";A1:A4;0))'), 30); assert.equal(at(TAB, '=INDEX(C1:C4;MATCH(25;B1:B4))'), 'B'); assert.equal(at(TAB, '=INDEX(A1:C4;MATCH("kiwi";A1:A4;0);2)*2'), 80);
  assert.equal(at(TAB, '=IFERROR(INDEX(B1:B4;MATCH("durian";A1:A4;0));"tidak ada")'), 'tidak ada'); assert.equal(at(TAB, '="Harga: "&TEXT(INDEX(B1:B4;MATCH("jeruk";A1:A4;0));"Rp #.##0")'), 'Harga: Rp 20');
  const t = mk([[5], [null], [null]]); t.rows[1].cells.cA = { fx: R.a1ToStored('=A1*2', t).fx }; t.rows[2].cells.cA = { fx: R.a1ToStored('=A2*2', t).fx }; t.rows[0].cells.cH = { fx: R.a1ToStored('=INDEX(A1:A3;3)', t).fx };
  assert.equal(R.computeTab(t, { now: NOW }).get('r1', 'cH'), 20);
  const u = mk([[null]]); u.rows[0].cells.cA = { fx: R.a1ToStored('=INDEX(A1:A2;1)', u).fx }; assert.equal(R.computeTab(u, { now: NOW }).get('r1', 'cA').e, '#CIRC!');
});
test('daftar fungsi 50 termasuk INDEX (sig, ket, petunjuk argumen, saran); modul murni; tes terdaftar', () => {
  const names = R.FUNCTION_LIST.map((f) => f.name); assert.equal(names.length, 53); const f = R.FUNCTION_LIST.find((x) => x.name === 'INDEX'); assert.ok(f && f.sig.startsWith('INDEX(') && f.ket.length > 3);
  assert.equal(argHint('INDEX', 7).parts.length, 3); assert.deepEqual(R.suggestFunctions('ind').map((x) => x.name), ['INDEX']); assert.ok(names.includes('HLOOKUP'));
  const s = src('src/js/rumus.js'); assert.ok(!/^\s*import\s/m.test(s)); assert.ok(!/document\.|window\.|localStorage|eval\(|new Function/.test(s)); assert.ok(src('package.json').includes('tests/rev166.test.mjs'));
});
