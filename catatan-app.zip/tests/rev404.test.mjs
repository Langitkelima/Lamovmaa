// Rev 404: perbaikan glow/bayangan pil kategori (.chp) yang terpotong. Tes AI (pemeriksaan CSS); tampilan diuji di Chromium (sebelum/sesudah dilihat langsung); HP BELUM.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const css = rd('src/css/styles.css'), i = css.indexOf('/* Rev 404:'), blk = css.slice(i);

test('CSS Rev 404: kotak gulir pil kategori diberi ruang untuk glow (atas 6, bawah 22), margin negatif menjaga tata letak, baris sampai tepi layar dengan pudar ujung', () => {
  assert.ok(i > 0);
  assert.match(blk, /\.chips:has\(> \.chp\)\{margin:-4px -16px -10px;padding:6px 18px 22px;overflow-y:hidden;scroll-padding-inline:18px;/);
  assert.match(blk, /mask-image:linear-gradient\(90deg,transparent 0,black 14px,black calc\(100% - 14px\),transparent 100%\)/);
  // tata letak tidak bergeser: tinggi bersih = lama (2 + 12 = 14 ekstra -> 6 + 22 - 4 - 10 = 14) dan awal pil tetap 18 px dari tepi (16 isi + 2 lama)
  const [, pt, , pb] = /padding:(\d+)px (\d+)px (\d+)px/.exec(blk).map(Number); assert.equal(pt + pb - 4 - 10, 2 + 12); assert.equal(16 + 2, 18);
  assert.match(css, /main\{padding:6px 16px 120px\}/); // margin -16 mengandalkan padding samping isi 16
});

test('CSS Rev 404: glow pil aktif lebih rapat dan muat di ruang tambahan; hanya variabel tema; aturan lama tetap (tes lama mengunci)', () => {
  assert.match(blk, /\.chp\.on\{box-shadow:0 6px 14px -6px var\(--ac\)\}/);
  const kum = 6 + 14 / 2; assert.ok(kum < 22 && 14 / 2 - 6 < 6); // jangkauan glow ke bawah < padding bawah, ke atas/samping < padding
  assert.ok(!/#[0-9a-fA-F]{3,8}\b/.test(blk) && !/rgba?\(/.test(blk));
  assert.ok(css.includes('.chips{display:flex;gap:8px;overflow-x:auto;padding:2px 2px 12px;scrollbar-width:none}') && css.includes('.seg button.on,.chp.on{background:var(--onbg)'));
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});

test('pemasangan: tes terdaftar, versi/SCHEMA tetap, banner Rev 404 di dokumen, tanpa perubahan kode JS/native', () => {
  const pk = JSON.parse(rd('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev404\.test\.mjs/);
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
  for (const f of ['RIWAYAT.md', 'PROMPT_SERAH_TERIMA.md']) { const d = rd(f); assert.ok(/^\*\*Rev 4(?:0[4-9]|[123]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 404 /') < d.indexOf('**Rev 403 /'), f); }
});
