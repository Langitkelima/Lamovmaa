// Rev 71: menu bawah dengan lekukan melengkung + lingkaran aktif menonjol.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { navShape, NAV_PAD } from '../src/js/logic.js';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const main = src('src/js/main.js'), css = src('src/css/styles.css'), settings = src('src/js/settings.js');
const cmds = (d) => d.replace(/[-\d.]+/g, '').replace(/\s+/g, '');

test('Rev 71: navShape punya struktur perintah SAMA untuk semua tab (bisa dianimasikan) dan tertutup', () => {
  const base = cmds(navShape(332, 66, 0));
  for (const i of [1, 2, 3]) assert.equal(cmds(navShape(332, 66, i)), base);
  for (const W of [292, 332, 372]) { const d = navShape(W, 66, 2); assert.ok(d.startsWith('M ') && d.endsWith(' Z')); assert.ok(!/NaN|Infinity/.test(d)); }
});
test('Rev 71: lekukan berpusat di tab aktif dan tidak keluar dari bar', () => {
  const W = 332, tab = (W - 2 * NAV_PAD) / 4;
  for (const i of [0, 1, 2, 3]) {
    const d = navShape(W, 66, i), nums = d.split(' ').map(Number);
    const xs = nums.filter((n) => !Number.isNaN(n));
    assert.ok(Math.min(...xs) >= 0 && Math.max(...xs) <= W + 0.01);
    const cx = NAV_PAD + tab * (i + 0.5), px = Math.sqrt(41 * 41 - 16) * 33 / 41, m = d.match(/A 33 33 0 0 0 ([\d.]+) ([\d.]+)/);
    assert.ok(m && Math.abs(Number(m[1]) - (cx + px)) < 0.2, 'tepi kanan lekukan di tab ' + i);
  }
});
test('Rev 71: layar sempit (320px): sudut dibatasi agar lekukan tab pertama/terakhir tidak bertabrakan', () => {
  for (const i of [0, 3]) { const d = navShape(292, 66, i); assert.ok(!/NaN/.test(d)); assert.ok(/^M [\d.]+ 0 L [\d.]+ 0/.test(d)); }
});
test('Rev 71: main.js menggambar bentuk bar tiap render dan saat resize; CSS lingkaran + animasi bentuk', () => {
  assert.ok(main.includes('function drawNav(navEl)') && main.includes('drawNav(navEl);') && main.includes("addEventListener('resize'"));
  assert.ok(main.includes('navShape(W, H, x, { tabs: 5 })') && main.includes('function navBg()'));
  for (const k of ['.navbg path{transition:none}', '.navind::before{', 'top:-24px;width:56px;height:56px', 'nav button span{opacity:calc(1 - var(--p) * 1.6)', 'calc(var(--p) * -20px)']) assert.ok(css.includes(k), k);
  assert.ok(css.includes('prefers-reduced-motion:reduce){.navbg path'));
});
test('Rev 71: tanpa native/SCHEMA; versi 0.3.2', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(settings.includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('RIWAYAT.md').includes('versi 0.3.2'));
});
