// Rev 100 / U4e: ekspor TXT/MD/PDF/JPG memuat baris Total; judul TH tabel editor ikut terbaca; audit jalur simpan. Tes Node murni.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as E from '../src/js/export.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const html = '<div class="tbl-wrap"><table><tbody><tr><th>Item</th><th>Harga</th></tr><tr><td>a</td><td data-a="r">1.000</td></tr><tr><td>b</td><td data-a="r">2.500</td></tr><tr class="tt"><td contenteditable="false"></td><td contenteditable="false" data-f="sum" data-a="r">Jumlah: 3.500</td></tr></tbody></table></div><p>x</p>';
const O = { width: 600, padX: 40, size: 30, titleSize: 44, measure: (t) => String(t).length * 14 };

test('Rev 100: parser menandai baris Total (row.total) dan judul dari TH; baris Total tidak menentukan judul', () => {
  const tb = E.parseNoteHtml(html).find((b) => b.kind === 'table');
  assert.equal(tb.rows.length, 4);
  assert.deepEqual(tb.rows.map((r) => !!r.total), [false, false, false, true]);
  assert.equal(tb.headerRow, true); assert.equal(tb.headerCol, false);
  assert.ok(tb.rows[3].every((c) => c.runs.every((r) => r.b)), 'teks baris Total tebal');
});
test('Rev 100: TXT dan Markdown memuat baris Total; Markdown mencetak tebal', () => {
  const bl = E.parseNoteHtml(html);
  assert.match(E.blocksToText('T', bl), /^ \| Jumlah: 3\.500$/m);
  assert.match(E.blocksToMarkdown('T', bl), /^\|\s+\| \*\*Jumlah: 3\.500\*\* \|$/m);
});
test('Rev 100: PDF/JPG (layoutDoc): baris Total ada, diarsir seperti judul, tebal, rata kanan dipertahankan; baris data biasa tidak', () => {
  const rows = E.layoutDoc({ title: '', blocks: E.parseNoteHtml(html) }, O).filter((x) => x.kind === 'tableRow');
  assert.equal(rows.length, 4);
  assert.equal(rows[0].headerRow, true);
  assert.ok(rows[0].cells.every((c) => c.header));
  assert.ok(rows[1].cells.every((c) => !c.header) && rows[2].cells.every((c) => !c.header));
  const last = rows[3].cells;
  assert.ok(last.every((c) => c.header));
  assert.equal(last[1].a, 'r');
  assert.equal(last[1].lines.flat().map((s) => s.t).join('').replace(/\s+/g, ' ').trim(), 'Jumlah: 3.500');
  assert.ok(last[1].lines.flat().every((s) => s.b));
});
test('Rev 100: tabel lama (data-hr/data-hc, tanpa tr.tt) dan tabel tanpa judul tetap seperti sebelumnya', () => {
  const old = E.parseNoteHtml('<table data-hr="1" data-hc="1"><tr><td>a</td><td>b</td></tr><tr><td>c</td><td>d</td></tr></table>').find((b) => b.kind === 'table');
  assert.equal(old.headerRow, true); assert.equal(old.headerCol, true); assert.ok(old.rows.every((r) => !r.total));
  const plain = E.parseNoteHtml('<table><tbody><tr><td>a</td><td>b</td></tr><tr><td>c</td><td>d</td></tr></tbody></table>').find((b) => b.kind === 'table');
  assert.equal(plain.headerRow, false); assert.equal(plain.headerCol, false);
  const colHead = E.parseNoteHtml('<table><tbody><tr><th>a</th><td>b</td></tr><tr><th>c</th><td>d</td></tr></tbody></table>').find((b) => b.kind === 'table');
  assert.equal(colHead.headerRow, false); assert.equal(colHead.headerCol, true);
});
test('Rev 100: audit jalur simpan: Undo memulihkan lewat sanitize (total dihitung ulang), salin catatan membawa html apa adanya', () => {
  const n = src('src/js/notes.js');
  assert.match(n, /ed\.innerHTML = sanitize\(st\.html\)/);
  // listener input yang menghitung ulang total HARUS terpasang sebelum markHist (riwayat Undo menangkap total yang sudah segar)
  assert.ok(n.indexOf("if (tb && tb.querySelector('tr.tt')) refreshTotals(tb)") < n.indexOf("markHist(); auto(); });"));
  assert.match(src('src/js/logic.js'), /html: String\(src\.html \?\? ''\)/);
});
test('Rev 100: versi 0.3.121, SCHEMA 9, native dan dependensi tidak berubah', () => {
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('node tests/rev100.test.mjs'));
});
