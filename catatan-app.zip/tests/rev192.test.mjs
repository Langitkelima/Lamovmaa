// Rev 192 / P2a: lazy loading layar lembar kerja + daftar templat lewat pintu lembar-pintu.js. Berkas rev192 = Rev 192.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, statSync } from 'node:fs';
import { staticGraph } from '../scripts/preload.mjs';
import { openSheet, closeSheet, isSheetOpen, loadSheetUI, loadTemplates, sheetUILoaded } from '../src/js/lembar-pintu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const g = staticGraph('js/main.js'); const has = (m) => g.includes('js/' + m + '.js');

test('anggaran: graf impor STATIS dari main.js tidak lagi memuat layar lembar kerja, alat, templat, pembantu rumus, filter, rentang, tinggi baris', () => {
  for (const m of ['lembar-ui', 'lembar-alat', 'lembar-templat', 'rumus-bantu', 'lembar-filter', 'lembar-rentang', 'lembar-baris']) assert.ok(!has(m), m + ' tidak boleh impor statis dari main.js');
  assert.ok(has('lembar-pintu'), 'pintu kecil ikut dimuat saat buka');
});
test('anggaran: JS saat buka turun dari 919.481 byte (Rev 191, 58 modul) dan tidak melewati batas baru', () => {
  const tot = g.reduce((a, f) => a + statSync(new URL('../src/' + f, import.meta.url)).size, 0);
  assert.ok(tot < 810000 /* Rev 416: 800000 -> 810000 ATAS IZIN PENGGUNA (gagang geser + tempel centang di notes.js) */, 'JS statis saat buka ' + tot + ' byte'); assert.ok(g.length <= 53, 'modul statis ' + g.length);
});
test('anggaran: modul yang sengaja BELUM dilazy (P2b-2): lembar, lembar-pulau, lembar-tampil tetap statis; rumus sudah lazy sejak Rev 192b', () => {
  for (const m of ['lembar', 'lembar-pulau', 'lembar-tampil']) assert.ok(has(m), m + ' masih statis sampai P2b-2');
});
test('pintu: tanpa impor statis, kecil, tanpa DOM/penyimpanan/native', () => {
  const s = src('src/js/lembar-pintu.js'); assert.ok(!/^import\s/m.test(s), 'tanpa impor statis'); assert.ok(s.length < 3500);
  assert.doesNotMatch(s, /localStorage|document\.|window\.|AndroidAPI|Capacitor|eval\(|new Function/);
  assert.match(s, /import\('\.\/lembar-ui\.js'\)/); assert.match(s, /import\('\.\/lembar-templat\.js'\)/);
});
test('main/notes/settings hanya lewat pintu; handleBack tetap SINKRON (tanpa await/then di closeSheet())', () => {
  for (const f of ['main', 'notes', 'settings']) assert.doesNotMatch(src('src/js/' + f + '.js'), /from '\.\/lembar-ui\.js'|from '\.\/lembar-templat\.js'/, f);
  assert.match(src('src/js/main.js'), /import \{ closeSheet \} from '\.\/lembar-pintu\.js'/);
  assert.match(src('src/js/main.js'), /if \(closeSheet\(\)\) return 'handled'/);
  assert.match(src('src/js/notes.js'), /\.catch\(\(\) => t(?:Ok|Warn|Err|Info)\('Lembar kerja gagal dibuka\.'\)\)/); assert.match(src('src/js/settings.js'), /\.catch\(\(\) => t(?:Ok|Warn|Err|Info)\('Lembar kerja gagal dibuka\.'\)\)/);
  assert.match(src('src/js/settings.js'), /\.catch\(\(\) => t(?:Ok|Warn|Err|Info)\('Templat gagal dimuat\.'\)\)/);
});
test('pintu: sebelum apa pun dibuka, Kembali tidak menangani apa-apa (false) dan tidak ada layar terbuka', () => {
  assert.equal(closeSheet(), false); assert.equal(isSheetOpen(), false); assert.equal(sheetUILoaded(), false);
});
test('pintu: Kembali saat modul masih dimuat MEMBATALKAN bukaan (true), lalu bukaan itu selesai false dan layar tak pernah dibuka', async () => {
  const p = openSheet({ sheet: null }); assert.equal(isSheetOpen(), true, 'ada permintaan menunggu'); assert.equal(closeSheet(), true);
  assert.equal(isSheetOpen(), false); assert.equal(await p, false); assert.equal(closeSheet(), false);
});
test('pintu: dua ketukan beruntun = hanya yang terakhir yang jalan (yang lama false)', async () => {
  const a = openSheet({ sheet: null }), b = openSheet({ sheet: null }); assert.equal(await a, false); await b; assert.equal(isSheetOpen(), false);
});
test('pintu: modul ber-cache (objek sama), lembar tak sah ditolak lembut tanpa melempar', async () => {
  const m1 = await loadSheetUI(), m2 = await loadSheetUI(); assert.equal(m1, m2); assert.equal(sheetUILoaded(), true);
  assert.equal(typeof m1.openSheet, 'function'); assert.equal(await openSheet({ sheet: { tabs: [] } }), false);
  const t1 = await loadTemplates(), t2 = await loadTemplates(); assert.equal(t1, t2); assert.ok(t1.templateList().length >= 12);
});
test('pintu: kegagalan memuat tidak menyangkut selamanya (cache dikosongkan, ketukan berikut mencoba lagi) dan Promise ditolak', async () => {
  const s = src('src/js/lembar-pintu.js'); assert.match(s, /loading = null; throw e/); assert.match(s, /tplLoading = null; throw e/);
  assert.match(s, /if \(pendingTok === tok\) pendingTok = 0; throw e/);
});
test('versi 0.3.121 di package.json dan settings.js; SCHEMA tidak berubah (18)', () => {
  assert.match(src('package.json'), /"version": "0\.3\.121"/); assert.match(src('src/js/settings.js'), /v0\.3\.121/);
  assert.match(src('src/js/storage.js') + src('src/js/logic.js'), /SCHEMA\s*=\s*22/);
});
