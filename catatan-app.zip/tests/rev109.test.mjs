// Rev 109 / U6a: bagian lipat (struktur, sanitize, tampilan, sisip, buka/tutup, Enter di judul).
// Perilaku DOM nyata (sanitize, ketuk panah, Enter) dicek di Chromium 360x800 (terang/gelap) saat revisi dibuat; tes Node ini mengunci kode dan kontrak.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const notes = src('src/js/notes.js'), lipat = src('src/js/lipat.js'), css = src('src/css/styles.css');

test('Rev 109: lipat.js mengekspor fungsi struktur dan tidak menyentuh penyimpanan/native/Intl/eval', async () => {
  const m = await import('../src/js/lipat.js');
  for (const k of ['makeFold', 'toggleFold', 'setFoldOpen', 'isFold', 'isFoldOpen', 'healFold', 'healAllFolds', 'flattenFold', 'foldTitle', 'foldOf', 'arrowHit', 'headOf', 'openToBody']) assert.equal(typeof m[k], 'function', k);
  assert.doesNotMatch(lipat, /localStorage|AndroidAPI|Intl\.|eval\(|new Function|innerHTML\s*=/);
});
test('Rev 109: sanitize menerima hanya kelas fold/fh/fb pada DIV dan data-o="1" pada .fold', () => {
  assert.match(notes, /\(c\.tagName === 'DIV' && \['fold', 'fh', 'fb'\]\.includes\(v\)\)/);
  assert.match(notes, /k === 'data-o' && v === '1' && c\.classList\.contains\('fold'\)/);
});
test('Rev 109: sanitize memulihkan struktur SEBELUM healTodoStructure; .fh/.fb yatim kehilangan kelas', () => {
  const a = notes.indexOf('healAllFolds(t.content, t.content.ownerDocument)');
  const b = notes.indexOf("t.content.querySelectorAll('.todo').forEach((row) => healTodoStructure");
  assert.ok(a > 0 && b > a, 'urutan sanitize');
  assert.match(notes, /div\.fh,div\.fb'\)\.forEach\(\(el\) => \{ if \(!el\.parentElement \|\| !el\.parentElement\.classList\.contains\('fold'\)\) el\.removeAttribute\('class'\)/);
});
test('Rev 109: aturan struktur di lipat.js (diratakan di sel/kutipan/daftar/bersarang; blok terlarang pindah keluar; data-o hanya 1)', () => {
  assert.match(lipat, /closest\('\.fold,td,th,blockquote,li,ul,ol,\.todo,table'\)/);
  assert.match(lipat, /OUT_OF_BODY = '\.mood-block,\.kb-date-block,\.kb-time-block,\.kb-countdown-block,table,\.tbl-wrap,figure,\.fold,\.lk-card'/);
  assert.match(lipat, /o !== '1'/);
  assert.match(lipat, /export function flattenFold/);
});
test('Rev 109: tombol Sisipkan "Bagian lipat" di menu Langit, ikon sendiri, runInsert memanggil insertFold', () => {
  assert.match(notes, /insertBtn\('fold', 'Bagian lipat'\)/);
  assert.match(notes, /\bfold: 'M/);
  assert.match(notes, /else if \(kind === 'fold'\) insertFold\(\);/);
  assert.match(notes, /const insertFold = \(\) => \{\s*flushHist\(\); restore\(\);/);
  assert.match(notes, /makeFold\(document, '', true\)/);
});
test('Rev 109: sisip di dalam bagian lipat ditaruh SESUDAH bagian lipat (tanpa bersarang); baris insideBlock tetap utuh', () => {
  assert.match(notes, /const insideFold = !!\(top && top !== ed && isFold\(top\)\)/);
  assert.match(notes, /\(flowTop \|\| insideFold \|\| \(anchorEl && anchorEl\.closest\('li,blockquote,ul,ol'\)\)\) && top && top !== ed\) top\.after\(block, tail\)/);
});
test('Rev 109: ketuk panah = buka/tutup lewat pointerdown (preventDefault) + click, juga di mode Baca, 1 langkah Undo', () => {
  assert.match(notes, /ed\.addEventListener\('pointerdown', \(e\) => \{ const f = arrowHit\(e, ed\); if \(f\) \{ e\.preventDefault\(\)/);
  assert.match(notes, /ed\.addEventListener\('click', \(e\) => \{ const f = arrowHit\(e, ed\); if \(f\) \{ e\.preventDefault\(\); foldToggle\(f\); \} \}\);/);
  const ft = notes.slice(notes.indexOf('const foldToggle = (fold) => {'), notes.indexOf('const foldToggle = (fold) => {') + 900);
  assert.match(ft, /flushHist\(\);\s*const opened = toggleFold\(fold\)/);
  assert.match(ft, /flushHist\(\); auto\(\);/);
  assert.match(ft, /!opened && sel && sel\.rangeCount && fb && fb\.contains\(sel\.anchorNode\)/, 'kursor di isi yang disembunyikan pindah ke judul');
  // pengendali panah ada di luar blok `if (!isP)` (juga untuk Catatan Privat)
  assert.ok(notes.indexOf("const f = arrowHit(e, ed); if (f) { e.preventDefault(); f.classList.add('pr')") < notes.indexOf('if (!isP) {\n    ed.addEventListener(\'pointerdown\', (e) => { if (bellHit(e))'));
});
test('Rev 109: Enter di judul = buka dan pindah ke isi pertama; Enter di isi/Backspace/Delete belum ditangani (U6c)', () => {
  assert.match(notes, /const fh = headOf\(sl\.anchorNode, ed\); if \(!fh\) return;\s*e\.preventDefault\(\); flushHist\(\);\s*const first = openToBody\(fh\.parentElement, document\);/);
  assert.match(notes, /e\.inputType !== 'insertParagraph' && e\.inputType !== 'insertLineBreak'\) return;\s*const sl = getSelection\(\)/);
});
test('Rev 109: CSS panah (putar saat terbuka), isi disembunyikan saat tertutup, placeholder, isi menjorok', () => {
  for (const k of ['.ed2 .fold>.fh::before', '.ed2 .fold[data-o="1"]>.fh::before{transform:rotate(45deg)}', '.ed2 .fold:not([data-o="1"])>.fb{display:none}', '.ed2 .fold>.fh:empty::after', '.ed2 .fold>.fb{margin:2px 0 6px 18px']) assert.ok(css.includes(k), k);
  assert.match(css, /\.fh:has\(>br:only-child\)::after\{content:"Bagian lipat"/);
});
test('Rev 109: versi 0.3.121, SCHEMA 10, native dan dependensi tidak berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('node tests/rev109.test.mjs'));
});
