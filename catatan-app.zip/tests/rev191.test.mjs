// Rev 191 / P1: waktu buka. startup.js (mark, afterFirstPaint), main.js menggeser pekerjaan tidak kritis, preload.mjs + build.mjs. Berkas rev191 = Rev 191.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, existsSync } from 'node:fs';
import { mark, afterFirstPaint } from '../src/js/startup.js';
import { staticGraph, injectPreload } from '../scripts/preload.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('mark: berawalan kelimaa:, gagal-aman bila performance tidak ada atau melempar', () => {
  const got = []; mark('x', { mark: (n) => got.push(n) });
  assert.deepEqual(got, ['kelimaa:x']);
  assert.doesNotThrow(() => mark('x', null)); assert.doesNotThrow(() => mark('x', {})); assert.doesNotThrow(() => mark('x', { mark() { throw new Error('x'); } }));
});
const fakeEnv = (withRaf = true) => {
  const q = []; let raf = null;
  const env = { setTimeout: (f, ms) => { q.push({ f, ms }); return q.length; } };
  if (withRaf) env.requestAnimationFrame = (f) => { raf = f; };
  return { env, q, fireRaf: () => { const f = raf; raf = null; if (f) f(); }, runTimers: (maxMs) => { for (const t of q.filter((x) => x.ms <= maxMs).splice(0)) t.f(); }, hasRaf: () => !!raf };
};
test('afterFirstPaint: tidak jalan sebelum gambar pertama; jalan setelah rAF + setTimeout 0; hanya SEKALI', () => {
  const { env, q, fireRaf } = fakeEnv(); let n = 0;
  afterFirstPaint(() => { n++; }, env, 1200);
  assert.equal(n, 0); fireRaf(); assert.equal(n, 0, 'rAF saja belum cukup: tunggu setTimeout 0');
  for (const t of q.filter((x) => x.ms === 0)) t.f(); assert.equal(n, 1);
  for (const t of q) t.f(); assert.equal(n, 1, 'cadangan 1,2 dtk tidak menjalankan dua kali');
});
test('afterFirstPaint: rAF tak pernah dipanggil (WebView tersembunyi) = cadangan maxWait tetap menjalankan', () => {
  const { env, q } = fakeEnv(); let n = 0; afterFirstPaint(() => { n++; }, env, 1200);
  const cad = q.find((x) => x.ms === 1200); assert.ok(cad); cad.f(); assert.equal(n, 1);
});
test('afterFirstPaint: tanpa requestAnimationFrame jatuh ke setTimeout; kesalahan fn tidak melempar', () => {
  const { env, q } = fakeEnv(false); let n = 0; const err = console.error; console.error = () => {};
  try { afterFirstPaint(() => { n++; throw new Error('uji'); }, env); assert.doesNotThrow(() => q.find((x) => x.ms === 0).f()); assert.equal(n, 1); } finally { console.error = err; }
});
test('main.js: pekerjaan tidak kritis ada DI DALAM afterFirstPaint; yang harus cepat tetap di luar', () => {
  const m = src('src/js/main.js'); const a = m.indexOf('afterFirstPaint(() => {'); const b = m.indexOf('\n});\n', a);
  assert.ok(a > 0 && b > a); const blok = m.slice(a, b);
  for (const k of ['syncAllReminders(data)', 'syncAllNoteAlarms(data)', 'cleanupOrphanImages(data)', 'installShootingStars();', "mark('tertunda-selesai')"]) assert.ok(blok.includes(k), k + ' harus di dalam blok tertunda');
  const luar = m.slice(0, a) + m.slice(b);
  for (const k of ['installReminderInbox(ctx', 'installShareInbox(ctx); pullShared(ctx);', 'installSkyLock();', 'applyDailyReset(data)', 'purgeTrash(data)']) assert.ok(luar.includes(k), k + ' tetap sinkron');
  assert.ok(m.indexOf('\nrender();') < m.indexOf("mark('render-awal')") && m.indexOf("mark('render-awal')") < a, 'urutan: render, tanda, baru tugas tertunda');
  assert.ok(m.indexOf("mark('data-siap')") > m.indexOf('const data = load();'));
  assert.ok(m.includes("import { mark, afterFirstPaint } from './startup.js'"));
});
test('main.js: sinkron alarm tetap berlaku di visibilitychange (buka lagi) dan tidak ikut ditunda', () => {
  const m = src('src/js/main.js'); const v = m.slice(m.indexOf("document.addEventListener('visibilitychange'"));
  assert.ok(v.includes('syncAllReminders(data)') && v.includes('syncAllNoteAlarms(data)') && !v.includes('afterFirstPaint'));
});
test('staticGraph: mengikuti import/export-from statis, mengabaikan import() dinamis, tanpa duplikat', () => {
  const fs = { 'js/main.js': "import { a } from './a.js';\nimport './c.js';\nconst l = () => import('./lazy.js');", 'js/a.js': "export { b } from './b.js';\nimport { c } from './c.js';", 'js/b.js': 'export const b = 1;', 'js/c.js': "import { a } from './a.js'; export const c = 1;", 'js/lazy.js': 'export const z = 1;' };
  assert.deepEqual(staticGraph('js/main.js', (p) => fs[p]), ['js/main.js', 'js/a.js', 'js/b.js', 'js/c.js']);
});
test('staticGraph pada src asli: semua berkas ada, termasuk startup.js; ANGGARAN JS saat buka (naikkan HANYA dengan alasan; P2 akan menurunkannya)', () => {
  const g = staticGraph('js/main.js'); assert.equal(new Set(g).size, g.length);
  for (const f of g) assert.ok(existsSync(new URL('../src/' + f, import.meta.url)), f);
  assert.ok(g.includes('js/startup.js') && g[0] === 'js/main.js');
  const kb = g.reduce((s, f) => s + readFileSync(new URL('../src/' + f, import.meta.url)).length, 0) / 1024;
  assert.ok(g.length <= 60, 'jumlah modul saat buka ' + g.length); assert.ok(kb <= 920, 'JS saat buka ' + kb.toFixed(0) + ' KB');
});
test('injectPreload: sisip sebelum </head>, idempoten, src/index.html tidak disentuh', () => {
  const h = '<html><head><title>x</title></head><body></body></html>'; const o = injectPreload(h, ['js/main.js', 'js/a.js']);
  assert.ok(o.includes('<link rel="modulepreload" href="js/main.js" data-kelimaa-preload>') && o.indexOf('modulepreload') < o.indexOf('</head>'));
  assert.equal(injectPreload(o, ['js/main.js', 'js/a.js']), o); assert.equal(injectPreload('tanpa head', ['js/a.js']), 'tanpa head');
  assert.ok(!src('src/index.html').includes('modulepreload'));
});
test('build.mjs: memakai preload.mjs dan gagal-aman (try/catch); tetap menyalin src ke www', () => {
  const b = src('scripts/build.mjs'); assert.match(b, /staticGraph\('js\/main\.js'\)/); assert.match(b, /try \{[\s\S]*injectPreload[\s\S]*\} catch/); assert.match(b, /cpSync\('src', 'www'/);
});
test('versi 0.3.121 selaras di package.json dan layar Setelan', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
