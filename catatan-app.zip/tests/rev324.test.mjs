// Rev 324 / PART L3: gambar kecil kartu tautan (D3 = dari internet saja, gagal = ikon) + bilah kartu. DOM nyata dicek di Chromium (tools/audit_linkcard_324.py); tes Node ini mengunci kode dan kontrak.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { staticGraph } from '../scripts/preload.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const notes = src('src/js/notes.js'), ui = src('src/js/linkcard-ui.js'), css = src('src/css/styles.css');

test('Rev 324: renderCard memuat gambar kecil hanya dari https, tidak di Catatan Privat, gagal muat = ikon', () => {
  assert.match(ui, /import \{ hostOf, safeImageUrl \} from '\.\/logic\.js'/);
  assert.match(ui, /el\.closest\('\[data-priv\]'\) \? '' : safeImageUrl\(el\.getAttribute\('data-i'\)/);
  assert.match(ui, /class: 'lk-th', src: img/);
  assert.match(ui, /referrerpolicy: 'no-referrer'/);
  assert.match(ui, /onerror: \(e\) => e\.target\.replaceWith\(icon\(\)\)/);
});
test('Rev 324: fill() menyimpan alamat gambar (data-i) tetapi bukan gambarnya; privat tetap tanpa pengambilan', () => {
  assert.match(ui, /normalizeLinkCard\(\{ u: url, t: p\.t, s: p\.s, i: p\.i \}\)/);
  assert.match(ui, /if \(c\.i\) el\.setAttribute\('data-i', c\.i\)/);
  assert.match(ui, /if \(linkCardFetchAllowed\(kind\)\) fill\(el, r\.url, ed, save\)/);
  assert.match(notes, /\.\.\.\(isP \? \{ 'data-priv': '' \} : \{\}\)/); // penanda editor privat dibaca renderCard
});
test('Rev 324: bilah kartu = alat blok standar (mood-tools kb-tools data-kb-tool) dengan 6 tombol', () => {
  assert.match(ui, /export function toggleCardTools\(card, \{ ed, flush, save, close \}\)/);
  assert.match(ui, /class: 'mood-tools kb-tools lk-tools'/);
  assert.match(ui, /setAttribute\('data-kb-tool', ''\)/);
  assert.match(ui, /\[\['l', 'Kiri'\], \['c', 'Tengah'\], \['r', 'Kanan'\]\]/);
  for (const t of ['Buka', 'Lepas tautan', 'Hapus']) assert.ok(ui.includes("'" + t + "'"), t);
  assert.match(ui, /if \(v === 'l'\) card\.removeAttribute\('data-a'\)/); // Kiri = bawaan, atribut dihilangkan (kontrak L1)
  assert.match(ui, /p\.textContent = url; card\.replaceWith\(p\)/);
  assert.equal((ui.match(/flush\(\)/g) || []).length >= 6, true); // tiap aksi dibungkus flush (satu langkah Undo)
});
test('Rev 324: notes.js memanggil bilah lewat impor malas, hanya mode Edit dan bukan panah', () => {
  assert.match(notes, /const lkc = e\.target\.closest\('\.lk-card'\)/);
  assert.match(notes, /!o\.classList\.contains\('ed-baca'\) && !e\.target\.closest\('\.lk-go'\)/);
  assert.match(notes, /import\('\.\/linkcard-ui\.js'\)\.then\(\(m\) => m\.toggleCardTools\(lkc, \{ ed, flush: flushHist, save: auto, close: closeMoodTools \}\)/);
  assert.match(notes, /\.kb-countdown-block,\.lk-card'/); // moodTarget
  assert.match(notes, /\.kb-tools,\.lk-card'\)\) closeMoodTools/); // pointerdown tidak menutup bilah sebelum klik
});
test('Rev 324: CSS gambar kecil + bilah, tanpa atribut baru di kartu (sorotan lewat :has)', () => {
  assert.match(css, /\.lk-th\{flex:none;width:48px;height:48px;border-radius:12px;object-fit:cover/);
  assert.match(css, /\.lk-card:has\(\+ \.lk-tools\)/);
  assert.match(css, /\.lk-tools\{max-width:none/);
});
test('Rev 324: jalur buka tidak bertambah (linkcard-ui.js tetap di luar graf statis, impor hanya dinamis)', () => {
  const g = staticGraph();
  assert.ok(![...g].some((f) => /linkcard/.test(f)), 'linkcard*.js tidak boleh masuk graf statis');
  assert.doesNotMatch(notes, /^import .*linkcard-ui/m);
});
