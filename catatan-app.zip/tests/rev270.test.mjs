// Rev 270 / V5a (paket Validasi, bagian 29): kriteria BARU (teks berisi/tidak berisi/sama persis, email, URL, angka, tanggal) = MESIN MURNI, belum ada UI. Tes AI saja (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as V from '../src/js/lembar-validasi.js';
import { formatDate } from '../src/js/lembar-format.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');

function sample(extra) {
  const sh = L.newSheet({ id: 'sabc123', name: 'Uji' }); const t = sh.tabs[0];
  const ck = { id: '', c: t.cols[0].id, ...extra }; L.setChecks(t, [ck]); return t;
}
const ok = (ck, txt, raw) => V.validate(ck, txt, raw).ok;

test('cleanCheck: kriteria non-daftar bersih, items [] dan dd:false, tanpa warna', () => {
  const t = sample({ k: 'has', v: '  Rp  ', cl: { x: { bg: '#FFFFFF' } }, items: ['a'] }); const c = t.checks[0];
  assert.equal(c.k, 'has'); assert.equal(c.v, 'Rp'); assert.deepEqual(c.items, []); assert.equal(c.dd, false); assert.equal(c.cl, undefined);
  assert.equal(sample({ k: 'email' }).checks[0].k, 'email');
  assert.equal(sample({ k: 'has', v: '   ' }).checks, undefined); // v kosong dibuang
  assert.equal(sample({ k: 'aneh' }).checks, undefined);
  assert.equal(sample({ k: 'num', op: 'gt' }).checks, undefined); // operan hilang
  assert.equal(sample({ k: 'num', op: 'xx', a: 1 }).checks, undefined);
  assert.equal(sample({ k: 'date', op: 'bf', a: 0 }).checks, undefined); // serial di luar 1..2958465
  assert.equal(sample({ k: 'date', op: 'bf', a: 46000.5 }).checks, undefined); // harus bulat
});

test('cleanCheck: bt/nb menukar a>b, ok tanpa operan, daftar lama tidak berubah', () => {
  const c = sample({ k: 'num', op: 'bt', a: 10, b: 2 }).checks[0]; assert.equal(c.a, 2); assert.equal(c.b, 10);
  const d = sample({ k: 'date', op: 'ok', a: 5 }).checks[0]; assert.equal(d.a, undefined); assert.equal(d.op, 'ok');
  const l = sample({ k: 'list', items: ['A', 'B'] }).checks[0]; assert.deepEqual(l.items, ['A', 'B']); assert.equal(l.dd, undefined);
});

test('teks: berisi, tidak berisi (tak peka huruf), sama persis (peka huruf), kosong selalu sah', () => {
  const has = sample({ k: 'has', v: 'abc' }).checks[0]; assert.ok(ok(has, 'xxABCxx')); assert.ok(!ok(has, 'xyz')); assert.ok(ok(has, ''));
  const no = sample({ k: 'hasnot', v: 'abc' }).checks[0]; assert.ok(ok(no, 'xyz')); assert.ok(!ok(no, 'aBc'));
  const same = sample({ k: 'same', v: 'Ya' }).checks[0]; assert.ok(ok(same, ' Ya ')); assert.ok(!ok(same, 'ya')); assert.ok(ok(same, '   '));
});

test('email dan URL', () => {
  const e = sample({ k: 'email' }).checks[0];
  for (const g of ['a@b.co', 'nama.baru+x@mail.example.com']) assert.ok(ok(e, g), g);
  for (const b of ['a@b', 'a b@c.com', '@b.com', 'a@b..com', 'a@.com', 'a@b.c', 'a,b@c.com', 'a@b.com;']) assert.ok(!ok(e, b), b);
  const u = sample({ k: 'url' }).checks[0];
  for (const g of ['https://a.com', 'www.a.co.id/x?y=1#z', 'http://sub.a.com:8080/p', 'a.com']) assert.ok(ok(u, g), g);
  for (const b of ['a', 'http://', 'https://a', 'a b.com', 'ftp:/a.com', 'javascript:alert(1)']) assert.ok(!ok(u, b), b);
});

test('parseNumText: gaya Indonesia, desimal titik, persen, Rp', () => {
  const P = V.parseNumText;
  assert.equal(P('12'), 12); assert.equal(P('-12,5'), -12.5); assert.equal(P('12.5'), 12.5); assert.equal(P('1.234.567'), 1234567); assert.equal(P('1.234,5'), 1234.5);
  assert.equal(P('1.234'), 1.234); assert.equal(P('25%'), 0.25); assert.equal(P('Rp 1.500'), 1500); assert.equal(P('Rp1.500.000'), 1500000);
  assert.equal(P('abc'), null); assert.equal(P(''), null); assert.equal(P('1,2,3'), null); assert.equal(P('12abc'), null);
});

test('angka: semua operator, nilai mentah menang atas tampilan, bukan angka = tidak sah', () => {
  const g = (op, a, b) => sample({ k: 'num', op, a, b }).checks[0];
  assert.ok(ok(g('gt', 5), '6')); assert.ok(!ok(g('gt', 5), '5')); assert.ok(ok(g('ge', 5), '5')); assert.ok(ok(g('lt', 5), '4,9')); assert.ok(!ok(g('lt', 5), '5')); assert.ok(ok(g('le', 5), '5'));
  assert.ok(ok(g('eq', 5), '5')); assert.ok(!ok(g('eq', 5), '6')); assert.ok(ok(g('ne', 5), '6')); assert.ok(!ok(g('ne', 5), '5'));
  assert.ok(ok(g('bt', 1, 10), '1')); assert.ok(ok(g('bt', 1, 10), '10')); assert.ok(!ok(g('bt', 1, 10), '11'));
  assert.ok(ok(g('nb', 1, 10), '0')); assert.ok(!ok(g('nb', 1, 10), '5'));
  assert.ok(!ok(g('gt', 5), 'banyak')); assert.ok(ok(g('gt', 5), ''));
  assert.ok(ok(g('gt', 1000), 'Rp 5', 5000)); // tampilan ambigu, nilai mentah dipakai
  assert.ok(!ok(g('gt', 1000), '5.000', 500));
});

test('tanggal: parse, kalender sah, operator, nomor seri', () => {
  const S = V.serialFromYmd; assert.equal(S(1899, 12, 30), null); assert.equal(S(1900, 1, 1), 2); assert.equal(S(2026, 11, 13), 46339);
  assert.equal(V.parseDateText('13/11/2026'), 46339); assert.equal(V.parseDateText('2026-11-13'), 46339); assert.equal(V.parseDateText('13-11-2026'), 46339); assert.equal(V.parseDateText('1/2/2026'), S(2026, 2, 1));
  assert.equal(V.parseDateText('31/02/2026'), null); assert.equal(V.parseDateText('2026-13-01'), null); assert.equal(V.parseDateText('besok'), null); assert.equal(V.parseDateText('46339'), 46339); assert.equal(V.parseDateText('0'), null);
  assert.equal(V.serialText(46339), '13/11/2026'); assert.equal(formatDate(46339), V.serialText(46339)); assert.equal(formatDate(S(1900, 1, 1)), '01/01/1900'); // sejalan dengan formatDate aplikasi
   assert.equal(V.serialText(0), null);
  const g = (op, a, b) => sample({ k: 'date', op, a, b }).checks[0], d = (x) => V.parseDateText(x), A = d('15/06/2026'), B = d('30/06/2026');
  assert.ok(ok(g('ok'), '01/01/2026')); assert.ok(!ok(g('ok'), '32/01/2026'));
  assert.ok(ok(g('eq', A), '15/06/2026')); assert.ok(!ok(g('eq', A), '16/06/2026'));
  assert.ok(ok(g('bf', A), '14/06/2026')); assert.ok(!ok(g('bf', A), '15/06/2026')); assert.ok(ok(g('af', A), '16/06/2026')); assert.ok(!ok(g('af', A), '15/06/2026'));
  assert.ok(ok(g('obf', A), '15/06/2026')); assert.ok(ok(g('oaf', A), '15/06/2026')); assert.ok(!ok(g('oaf', A), '14/06/2026'));
  assert.ok(ok(g('bt', A, B), '20/06/2026')); assert.ok(ok(g('bt', A, B), '30/06/2026')); assert.ok(!ok(g('bt', A, B), '01/07/2026')); assert.ok(ok(g('nb', A, B), '01/07/2026'));
  assert.ok(ok(g('bf', A), 'x', A - 1)); assert.ok(!ok(g('bf', A), 'x', A + 0.5)); assert.ok(!ok(g('bf', A), 'x', 0));
});

test('rejectText + invalidCells + checkText memakai kriteria baru (mode tolak, tanda merah, daftar)', () => {
  const t = sample({ k: 'num', op: 'bt', a: 1, b: 10, mode: 'tolak' }); L.setCell(t, 'r1', t.cols[0].id, { v: 5 });
  assert.equal(V.rejectText, undefined); assert.equal(t.checks[0].mode, undefined); // Rev 276: mode tolak dihapus, data lama dibersihkan
  const bad = V.invalidCells(t, (i, j) => (i === 0 && j === 0 ? '50' : '')); assert.ok(bad.has('0,0')); assert.equal(bad.size, 1);
  assert.equal(V.checkText(t.checks[0], 'A'), 'Kolom A: angka antara 1 dan 10');
  assert.equal(V.criteriaText(sample({ k: 'date', op: 'af', a: 46339 }).checks[0]), 'tanggal setelah 13/11/2026');
  assert.equal(V.criteriaText(sample({ k: 'num', op: 'gt', a: 2.5 }).checks[0]), 'angka lebih dari 2,5');
  assert.equal(V.criteriaText(sample({ k: 'list', items: ['A'] }).checks[0]), null);
  assert.equal(V.kindLabel('num', 'bt'), 'Angka antara'); assert.equal(V.kindLabel('has'), 'Teks berisi'); assert.equal(V.operands('ok'), 0); assert.equal(V.operands('nb'), 2);
});

test('pembaca lama aman: non-daftar tanpa panah/warna/langkah pilihan; rentang + beberapa aturan tetap jalan', () => {
  const t = sample({ k: 'url' }); const c = t.checks[0];
  assert.equal(c.dd, false); assert.equal(V.colorOf(c, 'a.com'), null); assert.equal(V.stepItem(c, 'x', 1), null); assert.equal(V.checkAt(t, 0, 0), c);
  const sh = L.newSheet({ id: 'sxyz123', name: 'K' }), u = sh.tabs[0];
  L.setChecks(u, [{ id: '', c: u.cols[0].id, k: 'num', op: 'gt', a: 0 }, { id: '', c: u.cols[1].id, k: 'list', items: ['Ya', 'Tidak'] }, { id: '', c: u.cols[0].id, k: 'num', op: 'gt', a: 0 }]);
  assert.equal(u.checks.length, 3); // Rev 276: rentang kembar boleh
  const back = JSON.parse(JSON.stringify(u.checks)); assert.deepEqual(V.cleanChecks(back, u.cols, u.rows), u.checks); // bolak-balik simpan/muat identik
});

test('berkas: kriteria baru tidak bocor ke pulau/ekspor/lembar.js; versi tetap', () => {
  for (const f of ['src/js/lembar-pulau.js', 'src/js/export.js', 'src/js/share.js', 'src/js/lembar.js']) for (const w of ['criteriaText', 'parseNumText', 'parseDateText', 'kindLabel', 'serialFromYmd']) assert.ok(!src(f).includes(w), w + ' tidak dipakai di ' + f); // Rev 271: editor (lembar-ui.js) kini memakainya; pulau/ekspor/lembar.js tidak
  const pkg = JSON.parse(src('package.json')); assert.equal(pkg.version, '0.3.121'); assert.ok(pkg.scripts.test.includes('rev270.test.mjs'));
  assert.ok(!/^\s*import\s/m.test(src('src/js/lembar-validasi.js')), 'tetap murni, tanpa impor');
});
