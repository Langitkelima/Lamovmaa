// Rev 30d: perlindungan seleksi teks dan fokus editor di WebView Android.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const nt = read('../src/js/notes.js');
const css = read('../src/css/styles.css');
assert.ok(nt.includes("inputmode: 'text'"), 'editor menyatakan mode input teks');
assert.ok(nt.includes("autocapitalize: 'sentences'"), 'keyboard dapat memakai kapitalisasi kalimat');
assert.ok(nt.includes('const focusEditorAtEnd = () =>'), 'ada satu jalur fokus editor');
assert.ok(nt.includes("ed.focus({ preventScroll: true })"), 'fokus tidak menggeser halaman secara tak perlu');
assert.ok(nt.includes('requestAnimationFrame(place)'), 'kursor dipastikan lagi setelah layout WebView');
assert.ok(nt.includes('if (!sl || sl.isCollapsed || !ed.contains(sl.anchorNode)) rng = null'), 'Range aktif tidak dibuang saat gagang seleksi disentuh');
assert.ok(css.includes('.fs .ed2,') && css.includes('-webkit-user-select: text !important;'), 'seleksi native berlaku di mode Baca dan Edit');
assert.match(css, /\.fs \.ed2\s*\{[^}]*touch-action:\s*auto/s, 'gesture seleksi diserahkan ke WebView');
console.log('8 tes lulus (Rev 30d editor UX)');
