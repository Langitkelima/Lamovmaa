// Rev 256 / S6: gulir mulus = baris yang masih terlihat dipakai ulang saat jendela baris bergeser. Tes Node; BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8'); const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
const dr = ui.slice(ui.indexOf('const drawRows = '), ui.indexOf('const paintBar = '));
test('drawRows: kunci dipecah jadi base (selain jendela baris) + jendela; hanya jendela berubah = inkremental', () => {
  assert.ok(dr.includes("const base = [tab.id, ver, sel ? sel.r + ':' + sel.c : '-', SX.sig(selx), fltSig(), lay.tops[total]].join('|'), key = base + '|' + from + '|' + to;"));
  assert.ok(dr.includes("const inc = lastKey !== '' && base === lastBase; lastKey = key; lastBase = base;"), "lastKey kosong (dipaksa) = gambar penuh");
  assert.ok(ui.includes("lastKey = '', lastBase = '',"), 'lastBase dideklarasikan bersama lastKey');
});
test('drawRows: baris di luar jendela dibuang, baris yang ada dilewati, selain itu dibuat; gambar penuh tetap mengosongkan body', () => {
  assert.ok(dr.includes('if (kk >= from && kk < to) have.add(kk); else el.remove();'));
  assert.ok(dr.includes("} else body.textContent = '';"));
  assert.ok(dr.includes('if (have && have.has(k)) continue;'));
  assert.ok(dr.indexOf('have.has(k)') < dr.indexOf("h('div', { class: 'lz-row'"), 'baris yang sudah ada dilewati sebelum dibuat ulang');
});
test('perhitungan jendela: gabungan sel yang mulai di atas layar tetap masuk jendela sebelum kunci dihitung', () => {
  assert.ok(dr.indexOf('m.pos < from') < dr.indexOf('const base = '));
});
test('CSS: .lz-scroll memakai overscroll-behavior dan contain; baris TIDAK diberi contain (sel gabungan membentang antarbaris)', () => {
  const line = css.split('\n').find((l) => l.startsWith('.lembarfs .lz-scroll{'));
  assert.ok(line.includes('overscroll-behavior:contain') && line.includes('contain:layout paint'));
  const row = css.split('\n').find((l) => l.startsWith('.lembarfs .lz-row{')); assert.ok(!/contain:/.test(row));
  assert.ok(!/touch-action:\s*none/.test(line), 'gulir bawaan tetap jalan');
});
test('jalur gulir: satu rAF per gulir, pendengar pasif, tanpa baca tata letak di onScroll', () => {
  const on = ui.slice(ui.indexOf('const onScroll = '), ui.indexOf('const pick = '));
  assert.ok(on.includes('if (raf) return; raf = requestAnimationFrame(') && on.includes('drawRows(); clipSel();'));
  assert.ok(!/getBoundingClientRect|offsetWidth|offsetHeight/.test(on) && !/getBoundingClientRect/.test(dr));
  assert.ok(ui.includes("scroller.addEventListener('scroll', onScroll, { passive: true });"));
});
