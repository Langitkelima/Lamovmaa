// Tes nativePlugin(): tiga jalur akses plugin tanpa bundler, dan pesan error jelas bila semuanya tidak ada.
const { nativePlugin, isNative } = await import('../src/js/native.js');
let ok = 0; const t = async (name, fn) => { await fn(); ok++; console.log('ok - ' + name); };
const assert = (c, m) => { if (!c) throw new Error('GAGAL: ' + m); };
const reset = (c) => { globalThis.Capacitor = c; };

await t('jalur 1: registerPlugin dipakai bila ada', () => {
  reset({ registerPlugin: (n) => ({ via: 'register', n }) });
  assert(nativePlugin('Filesystem').via === 'register', 'harus lewat registerPlugin');
});
await t('jalur 2: Capacitor.Plugins dipakai bila registerPlugin tidak ada', () => {
  reset({ Plugins: { Share: { via: 'plugins' } } });
  assert(nativePlugin('Share').via === 'plugins', 'harus lewat Plugins');
});
await t('jalur 3: nativePromise membungkus pemanggilan metode', async () => {
  const calls = [];
  reset({ nativePromise: (p, m, o) => { calls.push([p, m, o]); return Promise.resolve({ uri: 'file://x' }); } });
  const FS = nativePlugin('Filesystem');
  const r = await FS.writeFile({ path: 'a.json' });
  assert(r.uri === 'file://x', 'hasil diteruskan');
  assert(calls[0][0] === 'Filesystem' && calls[0][1] === 'writeFile' && calls[0][2].path === 'a.json', 'argumen benar');
  assert(FS.then === undefined, 'proxy tidak boleh dianggap thenable');
});
await t('semua jalur tidak ada: error jelas', () => {
  reset({ isNativePlatform: () => true });
  let msg = ''; try { nativePlugin('Share'); } catch (e) { msg = e.message; }
  assert(msg.includes('Share') && msg.includes('isNativePlatform'), 'pesan memuat nama plugin dan isi Capacitor');
});
await t('isNative: true hanya bila isNativePlatform() true', () => {
  reset({ isNativePlatform: () => true }); assert(isNative() === true, 'true');
  reset({}); assert(isNative() === false, 'false tanpa fungsi');
  reset(undefined); assert(isNative() === false, 'false tanpa Capacitor');
});
console.log(`\n${ok} tes native lulus`);
