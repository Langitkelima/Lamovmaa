// Rev 161 / U10c-3b: diagram tersimpan ikut ekspor PDF/JPG (TXT/MD tidak); SCHEMA 18
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as P from '../src/js/lembar-pulau.js';
import * as E from '../src/js/export.js';
import * as S from '../src/js/storage.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mkSheet = () => { const sh = L.newSheet({ name: 'Jual' }); const t = sh.tabs[0]; const put = (i, j, v) => L.setCell(t, t.rows[i].id, t.cols[j].id, { v });
  put(0, 0, 'Bulan'); put(0, 1, 'Jual'); [['Jan', 10], ['Feb', 30], ['Mar', 20]].forEach(([a, b], k) => { put(k + 1, 0, a); put(k + 1, 1, b); }); return sh; };
const withCharts = (n = 1) => { const sh = mkSheet(); for (let i = 0; i < n; i++) L.saveChart(sh.tabs[0], { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, { kind: i % 2 ? 'bar' : 'column', title: 'Penjualan ' + i }); return sh; };
const html = (id) => '<p>Awal</p><div class="ksheet" contenteditable="false" data-sheet="' + id + '"></div><p>Akhir</p>';
const O = { width: 1240, pageH: 1754, padX: 110, padTop: 120, padBottom: 130, size: 30, titleSize: 46, measure: (t, st) => String(t).length * (st.size || 30) * 0.5 };

test('exportCharts: kosong tanpa diagram; SVG putih berdiri sendiri dengan w/h; maks. EXPORT_CHARTS; null aman', () => {
  assert.deepEqual(P.exportCharts(mkSheet()), []); assert.deepEqual(P.exportCharts(null), []);
  const c = P.exportCharts(withCharts(1)); assert.equal(c.length, 1); assert.match(c[0].svg, /^<svg /); assert.ok(c[0].w > 0 && c[0].h > 0); assert.equal(c[0].title, 'Penjualan 0');
  assert.doesNotMatch(c[0].svg, /<script|href=|<image/i);
  const banyak = withCharts(6); assert.equal(P.exportCharts(banyak).length, Math.min(6, P.EXPORT_CHARTS));
});
test('exportModel: diagram HANYA bila opts.charts === true; tanpa itu sama persis dengan sebelumnya', () => {
  const a = mkSheet(), b = withCharts(2); assert.deepEqual(P.exportModel(a), P.exportModel(b)); assert.equal(P.exportModel(b).charts, undefined);
  assert.equal(P.exportModel(b, P.EXPORT_ALL, { charts: false }).charts, undefined);
  const m = P.exportModel(b, { rows: 20, cols: 6 }, { charts: true }); assert.equal(m.charts.length, 2);
});
test('parseNoteHtml: blok chart muncul sesudah tabel hanya dengan opts.charts; TXT dan Markdown tidak memuatnya', () => {
  const sh = withCharts(2); P.setSheetsSource(() => ({ [sh.id]: sh }));
  try {
    const plain = E.parseNoteHtml(html(sh.id), new Date(), (id) => P.exportModel(P.sheetById(id), P.EXPORT_ALL));
    assert.equal(plain.filter((b) => b.kind === 'chart').length, 0);
    const full = E.parseNoteHtml(html(sh.id), new Date(), (id) => P.exportModel(P.sheetById(id), { rows: 20, cols: 6 }, { charts: true }));
    const ch = full.filter((b) => b.kind === 'chart'); assert.equal(ch.length, 2); assert.ok(full.findIndex((b) => b.kind === 'table') < full.findIndex((b) => b.kind === 'chart'));
    assert.equal(full[full.length - 1].runs[0].t, 'Akhir');
    const t1 = E.blocksToText('J', plain), t2 = E.blocksToText('J', full); assert.equal(t1, t2); assert.doesNotMatch(t2, /<svg|diagram/i);
    const m1 = E.blocksToMarkdown('J', plain), m2 = E.blocksToMarkdown('J', full); assert.equal(m1, m2);
  } finally { P.setSheetsSource(null); }
});
test('sheetBlocks: blok chart hanya dari svg sah; model lama tanpa charts tidak berubah', () => {
  const m = P.exportModel(mkSheet()); const b0 = E.sheetBlocks(m); assert.ok(!b0.some((b) => b.kind === 'chart'));
  const b1 = E.sheetBlocks({ ...m, charts: [{ svg: '<svg xmlns="x"/>', w: 10, h: 5, title: 'T' }, { svg: 'bukan svg', w: 10, h: 5 }, { svg: '<svg/>', w: 0, h: 5 }, null] });
  assert.equal(b1.filter((b) => b.kind === 'chart').length, 1);
});
test('layoutDoc: chart = satu baris tinggi tetap, rata tengah, 90% lebar isi, tidak melebihi tinggi halaman; diikuti gap', () => {
  const blocks = [{ kind: 'chart', svg: '<svg/>', w: 520, h: 300, title: 'A' }, { kind: 'chart', svg: '<svg/>', w: 100, h: 90000, title: 'tinggi' }];
  const lines = E.layoutDoc({ title: '', blocks }, O); const cs = lines.filter((l) => l.kind === 'chart'); assert.equal(cs.length, 2);
  const inner = O.width - O.padX * 2; assert.ok(Math.abs(cs[0].w - inner * 0.9) < 1); assert.equal(cs[0].lh, cs[0].h); assert.ok(Math.abs(cs[0].x - (O.padX + (inner - cs[0].w) / 2)) < 0.01);
  assert.ok(Math.abs(cs[0].h / cs[0].w - 300 / 520) < 0.01); assert.ok(cs[1].h <= O.pageH - O.padTop - O.padBottom);
  assert.equal(lines[lines.indexOf(cs[0]) + 1].kind, 'gap');
  const pages = E.paginate(lines, O); assert.ok(pages.every((p) => p.used <= O.pageH - O.padTop - O.padBottom + 1));
});
test('Rev 161: share.js hanya meminta diagram untuk PDF/JPG, menggambar lewat Image + data URL dengan cadangan kotak; modul lain tidak mengimpor mesin diagram', () => {
  const s = src('src/js/share.js'); assert.match(s, /blocksOf\(n, o\.sheet, true\)/); assert.match(s, /exportModel\(sheetById\(id\), lim, charts \? \{ charts: true \} : \{\}\)/);
  assert.match(s, /export const noteText = \(n\) => blocksToText\(n\.title, blocksOf\(n\)\)/); assert.match(s, /image\/svg\+xml/); assert.match(s, /\[diagram\]/); assert.match(s, /l\.kind === 'chart'/);
  assert.doesNotMatch(s, /innerHTML|lembar-diagram|lembar-grafik/);
  for (const f of ['lembar', 'export', 'notes', 'main', 'storage', 'share']) assert.doesNotMatch(src('src/js/' + f + '.js'), /lembar-diagram/, f);
});
test('Rev 161: SCHEMA 18; versi 0.3.121; tes terdaftar', () => {
  assert.equal(S.SCHEMA, 22); const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev161.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
