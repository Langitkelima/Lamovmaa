// Rev 257 / S7: audit interaksi. Tes Node; audit Chromium ada di tools/audit_interaksi.py (BUKAN HP).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, existsSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8'); const ui = src('src/js/lembar-ui.js');
test('alat audit Chromium tersedia dan membandingkan gulir bertahap dengan lompat', () => {
  assert.ok(existsSync(new URL('../tools/audit_interaksi.py', import.meta.url)) && existsSync(new URL('../tools/ukur_gulir.py', import.meta.url)));
  const a = src('tools/audit_interaksi.py'); assert.ok(a.includes('gulir bertahap vs lompat') && a.includes('addMerge(tab, 40, 1, 44, 2') && a.includes('urungkan'));
});
test('daur ulang baris tidak merusak ketuk-sisip-rujukan, validasi, dan penanda baris dilewati', () => {
  assert.ok(ui.includes("scroller.addEventListener('click', (e) => {\n    if (!tapRef) return;"), 'Rev 131 utuh');
  assert.ok(ui.includes("if (vck && vck.dd !== false) el.classList.add('dd');"), 'Rev 148 utuh (Rev 267: panah menurut aturan yang mencakup sel)');
  const dr = ui.slice(ui.indexOf('const drawRows = '), ui.indexOf('const paintBar = '));
  assert.ok(dr.includes("rowEl.dataset.k = String(k)"), 'baris dikenali lewat data-k saat didaur ulang');
  assert.ok(dr.indexOf('paintSelBox();') > dr.indexOf('body.append(rowEl)'), 'kotak seleksi digambar sesudah baris');
});
