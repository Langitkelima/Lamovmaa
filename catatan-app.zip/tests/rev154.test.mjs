// Rev 154 / U10b-3: gabungan sel MELEBAR digambar menyatu di pulau pratinjau dan ekspor PDF/JPG; TXT/MD/kartu/cari tetap jujur (sel tertutup kosong).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { exportModel, islandModel, sheetCardText, sheetSearchText } from '../src/js/lembar-pulau.js';
import { sheetBlocks, layoutDoc, blocksToText } from '../src/js/export.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const measure = (t, st) => String(t).length * (st.size || 30) * 0.5;
const o = { width: 1240, pageH: 1754, padX: 110, padTop: 120, padBottom: 130, size: 30, titleSize: 46, measure };
function mk() { const sh = L.newSheet({ id: 'sabc123', name: 'Laporan' }), t = sh.tabs[0]; L.setCell(t, t.rows[0].id, t.cols[0].id, { v: 'Judul besar' }); L.setCell(t, t.rows[1].id, t.cols[0].id, { v: 'a' }); L.setCell(t, t.rows[1].id, t.cols[1].id, { v: 'b' }); L.setCell(t, t.rows[1].id, t.cols[2].id, { v: 'c' }); return sh; }

test('model pulau dan ekspor: jangkar membawa cs, sel tertutup sebaris bertanda cv; tanpa gabungan bentuknya TIDAK berubah', () => {
  const sh = mk(), t = sh.tabs[0];
  assert.equal('cs' in islandModel(sh).rows[0][0], false); assert.equal('cs' in exportModel(sh).rows[0][0], false);
  assert.equal(L.mergeCells(t, 0, 0, 0, 2).ok, true);
  for (const m of [islandModel(sh), exportModel(sh)]) { assert.equal(m.rows[0][0].cs, 3); assert.equal(m.rows[0][1].cv, true); assert.equal(m.rows[0][2].cv, true); assert.equal('cs' in m.rows[1][0], false); assert.equal('cv' in m.rows[1][1], false); }
});
test('gabungan dipotong ke jendela kolom; gabungan tegak tidak dimodelkan (sel bawah tetap sel kosong biasa)', () => {
  const sh = mk(), t = sh.tabs[0]; L.mergeCells(t, 0, 0, 0, 2);
  assert.equal(exportModel(sh, { rows: 5, cols: 2 }).rows[0][0].cs, 2);
  const v = mk(), u = v.tabs[0]; assert.equal(L.mergeCells(u, 2, 0, 3, 0).ok, true);
  const m = exportModel(v); assert.equal(m.rows.length >= 2, true); assert.equal('cs' in m.rows[2 < m.rows.length ? 2 : 0][0], false);
});
test('sheetBlocks meneruskan cs/cv; tata letak PDF/JPG: jangkar selebar kolom yang digabung, sel tertutup tidak punya sel sendiri', () => {
  const sh = mk(), t = sh.tabs[0]; L.mergeCells(t, 0, 0, 0, 2);
  const blocks = sheetBlocks(exportModel(sh)); const tb = blocks.find((b) => b.kind === 'table'); assert.equal(tb.rows[0][0].cs, 3); assert.equal(tb.rows[0][1].cv, true);
  const rows = layoutDoc({ title: 'T', blocks }, o).filter((l) => l.kind === 'tableRow');
  assert.equal(rows[0].cells.length, 1); assert.equal(rows[1].cells.length, 3);
  const full = rows[1].cells.reduce((a, c) => a + c.w, 0); assert.ok(Math.abs(rows[0].cells[0].w - full) < 0.01); assert.equal(rows[0].cells[0].x, 0);
});
test('tanpa gabungan tata letak sama seperti sebelumnya (jumlah sel per baris = jumlah kolom)', () => {
  const rows = layoutDoc({ title: 'T', blocks: sheetBlocks(exportModel(mk())) }, o).filter((l) => l.kind === 'tableRow'); assert.equal(rows[0].cells.length, 3);
});
test('TXT, kartu daftar, dan pencarian: sel tertutup kosong jadi teks jangkar tampil sekali (tanpa teks ganda)', () => {
  const sh = mk(), t = sh.tabs[0]; L.mergeCells(t, 0, 0, 0, 2);
  assert.equal(sheetCardText(sh).startsWith('Judul besar; a b c'), true); assert.equal(sheetSearchText(sh).split('Judul besar').length, 2);
  assert.match(blocksToText('', sheetBlocks(exportModel(sh))), /Judul besar/);
});
test('UI pulau: sel tertutup dilewati dan jangkar memakai grid-column span; modul gabung tetap tanpa impor; versi 0.3.121, SCHEMA 16', () => {
  const p = src('src/js/lembar-pulau.js'); assert.ok(p.includes('if (c.cv) return;') && p.includes("gridColumn = 'span '")); assert.match(p, /from '\.\/lembar-gabung\.js'/);
  assert.ok(!/^\s*import\s/m.test(src('src/js/lembar-gabung.js'))); assert.doesNotMatch(src('src/js/export.js'), /lembar-gabung/);
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev154.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
});
