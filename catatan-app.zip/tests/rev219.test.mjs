// Rev 217 / v0.3.121: mesin Writing Studio (3a): logika murni.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { WRITE_ACTIONS, SEL_MAX, cleanSelection, buildPrompt, cleanResult, tulisDenganAI } from '../src/js/ai/tulis.js';
import { TASK_CHOICES, CHAT_MAX_MSG } from '../src/js/ai/sambungan.js';
const conn = { url: 'https://kelimaa-ai.dhani5081.workers.dev', key: 'abcdefgh1', me: 'rama' };
test('tabel aksi: id unik, jenis pekerjaan sah, instruksi terisi', () => {
  assert.equal(new Set(WRITE_ACTIONS.map((a) => a.id)).size, WRITE_ACTIONS.length);
  for (const a of WRITE_ACTIONS) { assert.ok(TASK_CHOICES.some((t) => t[0] === a.task), a.id); assert.ok(a.ins.length > 20 && a.label); }
});
test('seleksi: kosong ditolak, terlalu panjang ditolak, kontrol dibuang', () => {
  assert.equal(cleanSelection('   ').ok, false); assert.equal(cleanSelection('a'.repeat(SEL_MAX + 1)).ok, false);
  assert.equal(cleanSelection('a\u0000b\r\nc ').text, 'ab\nc');
});
test('buildPrompt: satu pesan di bawah batas Worker, memuat teks terpilih, aksi tak dikenal ditolak', () => {
  const p = buildPrompt('ringkas', 'Halo dunia'); assert.ok(p.ok); assert.ok(p.content.endsWith('Halo dunia')); assert.ok(p.content.length <= CHAT_MAX_MSG);
  assert.ok(buildPrompt('ringkas', 'a'.repeat(SEL_MAX)).content.length <= CHAT_MAX_MSG);
  assert.equal(buildPrompt('hapus', 'x').ok, false);
});
test('cleanResult: buang pagar kode dan kutip pembungkus saja', () => {
  assert.equal(cleanResult('```\nIsi\n```'), 'Isi'); assert.equal(cleanResult('"Halo"'), 'Halo'); assert.equal(cleanResult('Dia bilang "ya" tadi'), 'Dia bilang "ya" tadi');
});
test('tulisDenganAI: kirim SATU pesan dengan task sesuai aksi, tanpa riwayat; galat tidak melempar', async () => {
  let sent; const http = async (q) => { sent = JSON.parse(q.body); return { status: 200, text: JSON.stringify({ ok: true, text: '"Hasil"', provider: 'gemini', model: 'm' }) }; };
  const r = await tulisDenganAI(conn, { on: true }, 'kembangkan', 'Kopi enak', http);
  assert.equal(r.ok, true); assert.equal(r.text, 'Hasil'); assert.equal(sent.task, 'creative.general'); assert.equal(sent.messages.length, 1); assert.equal(sent.messages[0].role, 'user');
  const bad = await tulisDenganAI(conn, {}, 'rapikan', '', http); assert.equal(bad.ok, false);
  const boom = await tulisDenganAI(conn, {}, 'rapikan', 'x', async () => { throw new Error('timeout'); }); assert.equal(boom.ok, false);
});
test('tulis.js murni: tanpa DOM/penyimpanan/data aplikasi; hanya impor sambungan.js', () => {
  const s = readFileSync(new URL('../src/js/ai/tulis.js', import.meta.url), 'utf8');
  assert.doesNotMatch(s, /document\.|window\.|localStorage|\.priv|\.notes|\.tasks|innerHTML/);
  assert.deepEqual([...s.matchAll(/^import .*$/gm)].map((m) => m[0]), ["import { kirimChat, chatOpts, CHAT_MAX_MSG } from './sambungan.js';"]);
});
