// Rev 53: desain baru "Aurora Kaca" (hanya CSS; fitur, tata letak, data, native tidak berubah).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const css = src('../src/css/styles.css');
const i = css.indexOf('===== Rev 53');
assert.ok(i > 0, 'blok Rev 53 harus ada di akhir styles.css');
const blk = css.slice(i);

t('token terang dan gelap ditimpa (media gelap + data-theme=dark), latar memakai gradasi valid', () => {
  assert.ok(blk.includes('@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){'), 'gelap otomatis');
  assert.ok(blk.includes(':root[data-theme="dark"]{'), 'gelap manual');
  for (const k of ['--sky:', '--gbg:', '--gbd:', '--onbg:', '--onfg:']) assert.ok(blk.split(k).length >= 3, k + ' ada di terang dan gelap');
  // --sky adalah daftar gambar: lapisan terakhir harus gradasi, BUKAN warna polos (warna polos membuat seluruh gradasi diabaikan)
  for (const m of blk.matchAll(/--sky:([^;]+);/g)) assert.ok(/linear-gradient\([^()]*\)\s*$/.test(m[1]) || /linear-gradient\(#[0-9A-Fa-f]{6},#[0-9A-Fa-f]{6}\)$/.test(m[1]), 'lapisan akhir --sky valid: ' + m[1].slice(-40));
});
t('kaca buram (backdrop-filter) hanya di bilah format editor (menu bawah sejak Rev 71 memakai path SVG tanpa blur), bukan di kartu daftar', () => {
  const rules = [...blk.matchAll(/([^{}]+)\{([^{}]*backdrop-filter[^{}]*)\}/g)].map((m) => m[1].trim());
  assert.ok(rules.length >= 1, 'ada aturan blur');
  for (const sel of rules) assert.ok(/^\.fs \.dock$/.test(sel), 'blur hanya untuk .fs .dock, ditemukan: ' + sel);
});
t('kartu catatan di dalam .sw solid (lapisan Hapus tidak tembus) dan sudut .sw ikut membulat', () => {
  assert.ok(blk.includes('.sw .card{background:var(--cardo)}'));
  assert.ok(/--cardo:#[0-9A-Fa-f]{6}/.test(blk) && !/--cardo:rgba/.test(blk), 'warna solid, bukan rgba');
  assert.ok(blk.includes('.sw{border-radius:26px}'));
});
t('komponen utama memakai token baru (segmen aktif, centang, tombol +, progres, menu bawah)', () => {
  for (const k of ['.seg button.on', '.ck.on', '.fab{', '.prog i{', 'nav{', '.navind{']) assert.ok(blk.includes(k), k);
});
t('hanya tampilan: SCHEMA 8 sejak Rev 60, tanpa plugin/native baru, JS aplikasi tidak memuat gaya Rev 53', () => {
  assert.match(src('../src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.ok(!src('../package.json').includes('"@capacitor/camera"'));
  assert.ok(!src('../src/js/main.js').includes('Rev 53'));
});
t('versi 0.3.2 selaras di package.json dan layar Setelan', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
console.log(n + ' tes lulus (Rev 53)');
