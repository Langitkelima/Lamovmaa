import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { FONT_LEVELS, FONT_LEVEL_NAMES, nearestFontLevel, clampFontScale } from '../src/js/ukuran.js';
const read = (f) => readFileSync(new URL(f, import.meta.url), 'utf8');
let n = 0; const ok = (m, f) => { f(); n++; console.log('ok - ' + m); };
ok('Rev 30c: 4 titik ukuran wajar (80, 100, 130, 160) dan semuanya lolos clamp apa adanya', () => {
  assert.deepEqual(FONT_LEVELS, [80, 100, 130, 160]);
  assert.equal(FONT_LEVEL_NAMES.length, 4);
  for (const l of FONT_LEVELS) assert.equal(clampFontScale(l), l);
});
ok('Rev 30c: nilai lama dipetakan ke titik terdekat; masukan aneh jadi Normal', () => {
  assert.equal(nearestFontLevel(100), 1); assert.equal(nearestFontLevel(120), 2); assert.equal(nearestFontLevel(250), 3);
  assert.equal(nearestFontLevel(70), 0); assert.equal(nearestFontLevel('x'), 1);
});
ok('Rev 30c: span ukuran tidak pernah bersarang (dibelah di luar span lama) dan catatan lama dirapikan saat dibuka', () => {
  const u = read('../src/js/ukuran.js'), nt = read('../src/js/notes.js');
  assert.match(u, /outermostScale\(range\.startContainer, root\)/);
  assert.match(u, /host\.after\(span\)/);
  assert.match(u, /querySelectorAll\('\[data-fs\] \[data-fs\]'\)/);
  assert.match(nt, /flattenFontScale\(t\.content\)/);
});
ok('Rev 30c: slider 4 titik, hanya menerapkan saat titik berpindah', () => {
  const nt = read('../src/js/notes.js');
  assert.match(nt, /FONT_LEVELS\.forEach\(\(_, i\) => track\.append\(h\('i', \{ class: 'fss-dot'/);
  assert.match(nt, /if \(k === liveIdx\) return/);
});
console.log(n + ' tes lulus (ukuran-titik)');
