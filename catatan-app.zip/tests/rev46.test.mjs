// Rev 46: ketuk gambar = pilih + atur ukuran (data-s), tidak lagi menghapus; panah menu header tidak berkedip di tema gelap.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as G from '../src/js/gambar.js';
import * as E from '../src/js/export.js';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css');

t('scaleOf: hanya kelipatan 5 antara 20 dan 100 yang sah; selain itu = 100 (penuh)', () => {
  for (const v of ['20', '25', '55', '95', '100']) assert.equal(G.scaleOf(v), Number(v));
  for (const v of ['', null, undefined, 'abc', '15', '0', '101', '21', '-50', '1e2', '100.0']) assert.equal(G.scaleOf(v), 100, String(v));
});
t('normalizeScale: dibulatkan ke kelipatan 5 dan dijepit 20..100', () => {
  assert.equal(G.normalizeScale(52), 50); assert.equal(G.normalizeScale(53), 55);
  assert.equal(G.normalizeScale(3), 20); assert.equal(G.normalizeScale(-10), 20);
  assert.equal(G.normalizeScale(400), 100); assert.equal(G.normalizeScale(NaN), 100); assert.equal(G.normalizeScale('x'), 100);
});
t('stepScale: tombol - dan + bergeser 10 dan berhenti di batas', () => {
  assert.equal(G.stepScale('100', -1), 90); assert.equal(G.stepScale('50', 1), 60);
  assert.equal(G.stepScale('25', -1), 20); assert.equal(G.stepScale('20', -1), 20);
  assert.equal(G.stepScale('95', 1), 100); assert.equal(G.stepScale(null, -1), 90); // tanpa atribut = penuh
});
t('scaleFromDrag: seret pegangan menghitung persen terhadap lebar kolom', () => {
  assert.equal(G.scaleFromDrag(300, 0, 300), 100);
  assert.equal(G.scaleFromDrag(300, -150, 300), 50);
  assert.equal(G.scaleFromDrag(300, 500, 300), 100);
  assert.equal(G.scaleFromDrag(300, -290, 300), 20);
  assert.equal(G.scaleFromDrag(300, -100, 0), 100); // lebar kolom 0 tidak membagi nol
});
t('ekspor (PDF/JPG): data-s dibaca dan lebar gambar mengikuti persen; tanpa data-s tetap penuh', () => {
  const fig = (s) => `<figure class="ki" data-kimg="abcde12345" data-w="1000" data-h="500"${s}></figure>`;
  assert.equal(E.parseNoteHtml(fig(' data-s="50"'))[0].scale, 50);
  assert.equal(E.parseNoteHtml(fig(''))[0].scale, 100);
  assert.equal(E.parseNoteHtml(fig(' data-s="7"'))[0].scale, 100);
  const O = { width: 800, padX: 40, padTop: 40, padBottom: 40, size: 24, pageH: 4000 };
  const wOf = (s) => E.layoutDoc({ title: '', blocks: E.parseNoteHtml(fig(s)) }, O).find((x) => x.kind === 'image');
  const full = wOf(''), half = wOf(' data-s="50"');
  assert.ok(Math.abs(half.w / full.w - 0.5) < 0.01); assert.ok(Math.abs(half.w / half.h - 2) < 0.01); // rasio tetap
  assert.ok(Math.abs(half.x + half.w / 2 - (full.x + full.w / 2)) < 1); // tetap rata tengah
});
t('sanitize mengizinkan data-s hanya 20..100 kelipatan 5 (tanpa style)', () => {
  assert.ok(nt.includes("k === 'data-s' && /^(?:[2-9][05]|100)$/.test(v)"));
  assert.ok(!/FIGURE'\s*&&\s*k === 'style'/.test(nt));
});
t('CSS: satu aturan lebar per langkah 20..95 (bertahan setelah undo/sanitize, tanpa style inline)', () => {
  for (let v = 20; v <= 95; v += 5) assert.ok(css.includes(`.ed2 figure.ki[data-s="${v}"]{width:${v}%}`), String(v));
  assert.ok(!css.includes('figure.ki[data-s="100"]')); // 100 = bawaan
});
t('ketuk gambar memilih, TIDAK menghapus; hapus hanya lewat tombol Hapus + Urungkan', () => {
  const a = nt.indexOf("ed.addEventListener('click', (e) => {\n    const fig = e.target.closest && e.target.closest('figure.ki');");
  assert.ok(a > 0, 'handler klik gambar ada');
  const handler = nt.slice(a, nt.indexOf('});', a));
  assert.ok(handler.includes('selectImage(fig)')); assert.ok(!handler.includes('.remove()')); assert.ok(!handler.includes('toast('));
  assert.ok(nt.includes("tapBtn(imgDel,")); assert.ok(nt.includes("tOk('Gambar dihapus'"));
  for (const k of ['imgMinus', 'imgPlus', 'imgFull', 'imgGrip', 'G.scaleFromDrag', 'G.stepScale', 'setPointerCapture']) assert.ok(nt.includes(k), k);
});
t('alat gambar tinggal di luar isi catatan (overlay), dibersihkan saat Baca dan saat editor ditutup', () => {
  assert.ok(nt.includes("o.append(imgTools)")); assert.ok(nt.includes('imgTools.remove()')); // Rev 97: menu ▦ dihapus
  assert.ok(nt.includes("if (next === 'baca') { clearImgSel();"));
  assert.ok(nt.includes('placeRaf = 0; placeImageTools();'));
});
t('panah menu: denyut skala dihapus, bintang dijeda selama animasi, item tidak terlihat saat masih menumpuk di tombol', () => {
  assert.ok(!nt.includes('moreBtn.animate('));
  assert.ok(nt.includes('const skyHold')); assert.ok(nt.includes('skyHold(true)')); assert.ok(nt.includes('skyHold(false)'));
  assert.ok(nt.includes('{ transform: t, opacity: 0, offset: .3 }')); // buka: tersembunyi dulu sampai keluar dari tombol
  assert.ok(nt.includes('{ opacity: 0, offset: .65 }')); // tutup: memudar sebelum sampai ke tombol
  assert.ok(css.includes('.fs.anim-hold::before,.fs.anim-hold::after,html.anim-hold body::before,html.anim-hold body::after{animation-play-state:paused}'));
  assert.ok(css.includes('.fsh .ghost.hmore{position:relative;z-index:6;transition:box-shadow .18s ease,background-color .18s ease}'));
});
t('optimasi: bintang halaman dijeda selama editor terbuka dan dipulihkan saat editor ditutup', () => {
  assert.ok(nt.includes("classList.add('ed-open')")); assert.ok(nt.includes("classList.remove('ed-open')"));
  assert.ok(css.includes('@media (max-width:480px){html.ed-open body::before,html.ed-open body::after{animation-play-state:paused}}'));
});
console.log(`${n} tes lulus (Rev 46)`);
