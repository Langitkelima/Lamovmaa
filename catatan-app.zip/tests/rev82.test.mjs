import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const notes = read('../src/js/notes.js');
const blocks = read('../src/js/blok.js');
const css = read('../src/css/styles.css');
const pkg = JSON.parse(read('../package.json'));
const settings = read('../src/js/settings.js');

test('Rev 82: Suasana hati dapat disisipkan di Catatan Privat; Gambar tetap dibatasi', () => {
  const start = notes.indexOf('const insertMood = () => {');
  const end = notes.indexOf('  // Rev D: Kutipan', start);
  assert.ok(start >= 0 && end > start);
  assert.doesNotMatch(notes.slice(start, end), /if \(isP\) return/);
  assert.match(notes, /\.\.\.\(isP \? \[\] : \[insertBtn\('image'/);
});

test('Rev 82: mode Baca menutup alat Suasana hati; menu/fitur Blok sudah dihapus', () => {
  assert.match(notes, /if \(baca\) \{ closeMoodTools\(\); \}/);
  assert.doesNotMatch(notes, /block-actions|block-panel|block-float|Tindakan blok/);
  assert.doesNotMatch(css, /\.block-(panel|float|trigger)/);
});

test('Rev 82: Undo/Redo memulihkan renderer blok dan membuang referensi seleksi lama', () => {
  assert.match(notes, /ed\.innerHTML = sanitize\(st\.html\);\s*hydrateBlocks\(ed\);/);
});

test('Rev 82: alat sementara blok dibersihkan sebelum sanitize, simpan, cadangan, dan ekspor', () => {
  assert.match(notes, /import \{ registerBlock, hydrateBlocks, stripBlockTools/);
  assert.match(notes, /stripBlockTools\(t\.content\)/);
  assert.match(notes, /strip: \(el\) => el\.querySelectorAll\('\.mood-tools'\)/);
  assert.match(blocks, /root\.matches\(def\.selector\)/);
  assert.match(blocks, /\[data-kb-tool\],\.kb-tool,\.kb-actions/);
});

test('Rev 82: versi Rev 82 konsisten dan tidak mengubah SCHEMA/native', () => {
  assert.equal(pkg.version, '0.3.121');
  assert.match(settings, /Notes Kelimaa v0\.3\.121/);
  assert.match(read('../src/js/storage.js'), /SCHEMA\s*=\s*22/);
  assert.doesNotMatch(notes, /registerPlugin\(|Capacitor\.Plugins/);
});
