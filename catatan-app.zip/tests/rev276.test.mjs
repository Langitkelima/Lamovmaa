// Rev 276 / W1 (paket Peringatan + Pelacakan Error): penolakan -> peringatan. Mode Tolak dihapus; aturan boleh kembar/beririsan (hanya diberi tahu); semua aturan diperiksa. Tes AI saja (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as V from '../src/js/lembar-validasi.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
function sample(list) {
  const t = L.newSheet({ id: 'sabc123', name: 'K' }).tabs[0], a = t.cols[0].id, r = t.rows.map((x) => x.id);
  L.setChecks(t, list(a, r)); return { t, a, r };
}
test('mode tolak dihapus: data lama dibersihkan, tidak ada rejectText', () => {
  const { t } = sample((a) => [{ id: '', c: a, k: 'list', items: ['Ya', 'Tidak'], mode: 'tolak' }]);
  assert.equal(t.checks.length, 1); assert.equal(t.checks[0].mode, undefined); assert.equal(V.rejectText, undefined);
});
test('rentang kembar dan beririsan BOLEH; aturan lain tetap utuh', () => {
  const { t, a, r } = sample((a, r) => [{ id: '', c: a, k: 'list', items: ['Ya'] }, { id: '', c: a, k: 'list', items: ['Tidak'] }, { id: '', c: a, rg: { c2: a, r1: r[1], r2: r[3] }, k: 'num', op: 'gt', a: 0 }]);
  assert.equal(t.checks.length, 3); assert.equal(new Set(t.checks.map((x) => x.id)).size, 3);
  const rc = V.checkRect(t, t.checks[2]), o = V.overlapChecks(t, rc, t.checks[2].id); assert.equal(o.length, 2);
  assert.equal(V.overlapChecks(t, rc, null).length, 3); assert.equal(V.overlapChecks(t, { r1: 8, r2: 9, c1: 1, c2: 1 }, null).length, 0); // kolom lain = tidak beririsan
});
test('invalidCells memeriksa SEMUA aturan pencakup; by = aturan pertama yang dilanggar; kosong selalu sah', () => {
  const { t } = sample((a, r) => [{ id: 'va01', c: a, rg: { c2: a, r1: r[0], r2: r[3] }, k: 'has', v: 'x' }, { id: 'vb02', c: a, rg: { c2: a, r1: r[2], r2: r[5] }, k: 'num', op: 'gt', a: 5 }]);
  const txt = { '0,0': 'ax', '1,0': 'zz', '2,0': 'x9', '3,0': 'x3', '4,0': '9', '5,0': '2', '6,0': 'bebas' };
  const bad = V.invalidCells(t, (i, j) => txt[i + ',' + j] || '');
  assert.deepEqual([...bad].sort(), ['1,0', '2,0', '3,0', '5,0']); // 2,0 'x9' lolos has tetapi gagal num; 3,0 gagal num
  assert.equal(bad.by.get('1,0').id, 'va01'); assert.equal(bad.by.get('2,0').id, 'vb02'); assert.equal(bad.by.get('5,0').id, 'vb02');
  assert.equal(V.invalidCells(t, () => '').size, 0);
});
test('kabel UI: tanpa Tolak; catatan rentang memberi tahu aturan terpasang; tip memakai aturan yang dilanggar', () => {
  const ui = src('src/js/lembar-ui.js'), o = ui.slice(ui.indexOf('const openChecks'), ui.indexOf('const openFilter'));
  assert.doesNotMatch(ui, /rejectText|'Tolak'|vd-seg/); assert.doesNotMatch(src('src/css/styles.css'), /\.vd-seg|\.vd-sg/);
  for (const k of ['overlapChecks(', 'paintOvl', "rg.addEventListener('input', paintOvl)", 'sudah punya aturan', 'sel diperiksa terhadap semua aturan']) assert.ok(o.includes(k), k);
  assert.doesNotMatch(o, /Ubah aturan itu saja/); assert.match(ui, /iv\.by && iv\.by\.get\(/);
  assert.equal((o.match(/hist\.push\(/g) || []).length, 1);
});
test('berkas: SCHEMA tetap 20; tes terdaftar; rev269 diganti oleh rev276', () => {
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/); const pk = src('package.json'); assert.ok(pk.includes('tests/rev276.test.mjs') && !pk.includes('rev269.test.mjs'));
});
