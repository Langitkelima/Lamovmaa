// Tes Rev 19 (bagian 1): tempat sampah otomatis kosong (settings.trashDays, SCHEMA 5).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/logic.js';
import * as S from '../src/js/storage.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const DAY = 86400000, NOW = Date.UTC(2026, 9, 30, 12, 0, 0);
const note = (id, extra = {}) => ({ id, title: 'J' + id, text: 't', html: '', col: '', pin: false, updated: 1, ...extra });
const tr = (id, daysAgo, extra = {}) => ({ kind: 'note', item: note(id, extra), at: NOW - daysAgo * DAY });
const withDays = (days, trash, notes = []) => { const d = S.emptyData(); d.settings.trashDays = days; d.trash = trash; d.notes = notes; return d; };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

await t('SCHEMA 5: data v4 tanpa trashDays dimigrasi, bawaan Mati; nilai aneh jadi Mati; nilai sah dipertahankan', () => {
  assert.equal(S.SCHEMA, 22);
  const v4 = { version: 4, habits: [], tasks: [], notes: [note('a')], priv: [], trash: [tr('x', 3)], settings: { days: [1], theme: 'dark' } };
  const d = S.normalize(v4);
  assert.equal(d.settings.trashDays, 0); assert.equal(d.settings.theme, 'dark'); assert.equal(d.notes.length, 1); assert.equal(d.trash.length, 1);
  for (const bad of [45, '30', null, -7, 7.5, NaN, true, {}]) assert.equal(S.normalize({ ...v4, settings: { trashDays: bad } }).settings.trashDays, 0, String(bad));
  for (const ok of [0, 7, 30, 90]) assert.equal(S.normalize({ ...v4, settings: { trashDays: ok } }).settings.trashDays, ok);
  assert.equal(S.emptyData().settings.trashDays, 0);
});
await t('isTrashExpired: batas tepat, item tanpa waktu valid, waktu di masa depan, entri rusak TIDAK dihapus', () => {
  assert.equal(L.isTrashExpired(tr('a', 30), 30, NOW), true, 'tepat 30 hari = lewat');
  assert.equal(L.isTrashExpired({ ...tr('a', 30), at: NOW - 30 * DAY + 1 }, 30, NOW), false, 'kurang 1 ms');
  assert.equal(L.isTrashExpired(tr('a', 999), 0, NOW), false, 'Mati');
  for (const bad of [{ kind: 'note', item: note('b') }, { kind: 'note', item: note('b'), at: 'kemarin' }, { kind: 'note', item: note('b'), at: NaN }, null, undefined, 5, 'x']) assert.equal(L.isTrashExpired(bad, 7, NOW), false);
  assert.equal(L.isTrashExpired({ kind: 'note', item: note('f'), at: NOW + 5 * DAY }, 7, NOW), false, 'jam HP diubah mundur');
});
await t('purgeTrash: Mati tidak menghapus apa pun; 7/30/90 hanya membuang yang lewat batas; hasil = jumlah dibuang', () => {
  const mk = (days) => withDays(days, [tr('a', 1), tr('b', 8), tr('c', 31), tr('d', 91), tr('e', 400)]);
  let d = mk(0); assert.equal(L.purgeTrash(d, NOW), 0); assert.equal(d.trash.length, 5);
  d = mk(7); assert.equal(L.purgeTrash(d, NOW), 4); assert.deepEqual(d.trash.map((x) => x.item.id), ['a']);
  d = mk(30); assert.equal(L.purgeTrash(d, NOW), 3); assert.deepEqual(d.trash.map((x) => x.item.id), ['a', 'b']);
  d = mk(90); assert.equal(L.purgeTrash(d, NOW), 2); assert.deepEqual(d.trash.map((x) => x.item.id), ['a', 'b', 'c']);
  assert.equal(L.purgeTrash(d, NOW), 0, 'dipanggil lagi tidak membuang tambahan');
});
await t('purgeTrash: tugas/kebiasaan ikut, entri rusak dan tanpa waktu dipertahankan, tidak melempar', () => {
  const d = withDays(7, [{ kind: 'task', item: { id: 't', title: 'x' }, at: NOW - 20 * DAY }, { kind: 'habit', item: { id: 'h', title: 'y' }, at: NOW - 1 * DAY }, null, { kind: 'note', item: note('z') }, 'aneh']);
  assert.equal(L.purgeTrash(d, NOW), 1); assert.equal(d.trash.length, 4);
  const noSettings = { trash: [tr('a', 99)] }; assert.equal(L.purgeTrash(noSettings, NOW), 0);
});
await t('purgeTrash: hubungan ke catatan yang ikut terbuang dibersihkan seketika, hubungan ke catatan di sampah yang masih hidup tetap', () => {
  const d = withDays(30, [tr('lama', 40), tr('baru', 2)], [note('a', { links: ['lama', 'baru', 'b'] }), note('b')]);
  assert.equal(L.purgeTrash(d, NOW), 1);
  assert.deepEqual(d.notes[0].links, ['baru', 'b']);
});
await t('countExpiredTrash dan trashDaysLeft', () => {
  const d = withDays(0, [tr('a', 1), tr('b', 8), tr('c', 31)]);
  assert.equal(L.countExpiredTrash(d, 0, NOW), 0); assert.equal(L.countExpiredTrash(d, 7, NOW), 2); assert.equal(L.countExpiredTrash(d, 30, NOW), 1); assert.equal(L.countExpiredTrash(d, 90, NOW), 0);
  assert.equal(L.trashDaysLeft(tr('a', 1), 30, NOW), 29);
  assert.equal(L.trashDaysLeft({ ...tr('a', 0), at: NOW - 29.5 * DAY }, 30, NOW), 1, 'dibulatkan ke atas');
  assert.equal(L.trashDaysLeft(tr('a', 40), 30, NOW), 1, 'minimal 1');
  assert.equal(L.trashDaysLeft(tr('a', 1), 0, NOW), null); assert.equal(L.trashDaysLeft({ kind: 'note' }, 30, NOW), null);
  assert.deepEqual(L.TRASH_DAYS_OPTIONS, [0, 7, 30, 90]); assert.equal(L.trashDaysText(0), 'Mati'); assert.equal(L.trashDaysText(30), '30 hari');
});
await t('simpan, muat, ekspor, impor: trashDays bertahan; pulihkan dari cadangan tidak menghapus sampah yang belum lewat batas', () => {
  const d = withDays(30, [tr('a', 3)]);
  const store = { v: null, getItem() { return this.v; }, setItem(k, x) { this.v = x; } };
  assert.equal(S.save(d, store).ok, true); assert.equal(S.load(store).settings.trashDays, 30);
  const imp = S.importJSON(S.exportJSON(d)); assert.equal(imp.ok, true); assert.equal(imp.data.settings.trashDays, 30); assert.equal(imp.data.trash.length, 1);
});
await t('sumber: dipanggil saat dibuka dan saat kembali ke layar; Lainnya punya pilihan + peringatan sebelum menghapus langsung', () => {
  const m = src('../src/js/main.js');
  assert.ok(m.includes('purgeTrash(data)') && (m.match(/purgeTrash\(data\)/g) || []).length >= 2, 'main: saat dibuka + visibilitychange');
  assert.ok(m.indexOf('purgeTrash(data)') < m.indexOf('\nrender();'), 'dibersihkan sebelum tampilan pertama');
  const st = src('../src/js/settings.js');
  for (const k of ['Kosongkan otomatis', 'TRASH_DAYS_OPTIONS.map(autoBtn)', 'countExpiredTrash(data, d)', 'Ada yang langsung terhapus', 'trashDaysLeft(x, s.trashDays)', "'Mati: item tetap di sini"]) assert.ok(st.includes(k), k);
});
console.log(n + ' tes sampah lulus');
