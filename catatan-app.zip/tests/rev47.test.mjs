// Rev 47: gambar bisa rata kiri/tengah/kanan (data-a) dan dikunci (data-l). Tahap 1 dari rencana "mirip Word"; teks mengalir di samping gambar BELUM (Rev 48).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as G from '../src/js/gambar.js';
import * as E from '../src/js/export.js';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css');

t('alignOf: hanya l/c/r yang sah; selain itu = c (tengah)', () => {
  for (const v of ['l', 'c', 'r']) assert.equal(G.alignOf(v), v);
  for (const v of ['', null, undefined, 'x', 'L', 'left', 'lr', '1']) assert.equal(G.alignOf(v), 'c', String(v));
});
t('isLocked: hanya "1" yang berarti terkunci', () => {
  assert.equal(G.isLocked('1'), true);
  for (const v of ['', null, undefined, '0', 'true', '11']) assert.equal(G.isLocked(v), false, String(v));
});
t('alignedX: kiri, tengah, kanan di dalam kolom', () => {
  assert.equal(G.alignedX('l', 40, 720, 360), 40);
  assert.equal(G.alignedX('c', 40, 720, 360), 220);
  assert.equal(G.alignedX('r', 40, 720, 360), 400);
  assert.equal(G.alignedX('?', 40, 720, 360), 220);
});
t('ekspor (PDF/JPG): data-a dibaca dan posisi x gambar mengikuti rata; ukuran tetap', () => {
  const fig = (a) => `<figure class="ki" data-kimg="abcde12345" data-w="1000" data-h="500" data-s="50"${a}></figure>`;
  assert.equal(E.parseNoteHtml(fig(' data-a="l"'))[0].align, 'l');
  assert.equal(E.parseNoteHtml(fig(' data-a="r"'))[0].align, 'r');
  assert.equal(E.parseNoteHtml(fig(''))[0].align, 'c');
  assert.equal(E.parseNoteHtml(fig(' data-a="zz"'))[0].align, 'c');
  const O = { width: 800, padX: 40, padTop: 40, padBottom: 40, size: 24, pageH: 4000 };
  const at = (a) => E.layoutDoc({ title: '', blocks: E.parseNoteHtml(fig(a)) }, O).find((x) => x.kind === 'image');
  const l = at(' data-a="l"'), c = at(''), r = at(' data-a="r"');
  assert.equal(l.x, 40); assert.ok(Math.abs(c.x - (40 + (720 - c.w) / 2)) < 0.01); assert.ok(Math.abs(r.x + r.w - 760) < 0.01);
  assert.equal(l.w, c.w); assert.equal(c.w, r.w);
});
t('sanitize mengizinkan data-a (l/c/r) dan data-l="1" saja, tanpa style', () => {
  assert.ok(nt.includes("k === 'data-a' && /^[lcr]$/.test(v)"));
  assert.ok(nt.includes("k === 'data-l' && v === '1'"));
});
t('CSS: rata kiri/kanan/tengah lewat atribut (tanpa style inline); bar dua baris; terkunci menyembunyikan kontrol selain kunci', () => {
  assert.ok(css.includes('.ed2 figure.ki[data-a="l"]{margin-left:0;margin-right:auto}'));
  assert.ok(css.includes('.ed2 figure.ki[data-a="r"]{margin-left:auto;margin-right:0}'));
  assert.ok(css.includes('.img-tools.locked .img-grip'));
  assert.ok(css.includes('.img-tools.locked .img-row.r1'));
  assert.ok(!/style\.(?:textAlign|cssFloat|float)\b/.test(nt));
});
t('alat gambar: ukuran, rata, dan hapus menolak bekerja saat terkunci; hanya tombol kunci yang lolos', () => {
  assert.ok(nt.includes('(allowLocked || !figLocked(imgSel))') || nt.includes('(allowLocked || !figLocked(imgSel)))') || /allowLocked \|\| !figLocked\(imgSel\)/.test(nt));
  assert.ok(nt.includes("if (!imgSel || figLocked(imgSel)) return;")); // pegangan seret
  assert.ok(/tapBtn\(imgLock,[\s\S]*?\}, true\);/.test(nt));
});
t('penjaga: gambar terkunci yang hilang lewat keyboard dipulihkan dari keadaan sah terakhir', () => {
  assert.ok(nt.includes("infoKey('gbrKunci', 'dihapus')"));
  assert.ok(nt.includes('let okHtml = ed.innerHTML'));
  assert.ok(/flushHist = \(\) => \{ okHtml = ed\.innerHTML;/.test(nt));
});
t('tanpa perubahan SCHEMA/native/plugin dan tanpa tipe data baru', () => {
  assert.ok(src('../src/js/storage.js').includes('SCHEMA = 22'));
  assert.ok(!src('../scripts/apply-native.mjs').includes('data-a'));
});
t('versi 0.3.2 selaras di package.json dan layar Setelan', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
console.log(n + ' tes lulus (Rev 47)');
