// Rev 409: kartu TWO POCKETS di atas Setelan, kolom jam model B, tombol Atur jadwal gradasi, panel jadwal dirombak.
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { strict as assert } from 'node:assert';
const rd = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const st = rd('src/js/settings.js'), css = rd('src/css/styles.css');
test('Setelan: kartu TWO POCKETS tepat setelah judul, ubin lama dihapus', () => {
  assert.ok(st.indexOf("tpSetCard(ctx, conn),\n    h('div', { class: 'mzg' }") > 0); // Rev 410: kini di bawah kartu Notes Kelimaa (bukan di atas)
  assert.ok(!st.includes("tile('wide pocket'"));
});
test('panel jadwal: kolom jam ikon + kapsul panah, Atur jadwal berikon jam, opsi dikelompokkan, tombol Batal', () => {
  for (const k of ["class: 'tpfld'", "class: 'tpfc'", 'ico(PATH.clock), h(\'span\', {}, \'Atur jadwal\')', "class: 'tpopts'", "'Batal'", 'closeEd']) assert.ok(st.includes(k), k);
});
test('CSS: model B memakai variabel/gradasi aplikasi dan menang atas aturan .in Rev 172', () => {
  for (const k of ['.tpfc{', 'main .tpcfg .tpfld input.in{', '.tp2{', '.tpopts{']) assert.ok(css.includes(k), k);
});
test('pemasangan: tes terdaftar, SCHEMA tetap, catatan Rev 409', () => {
  assert.match(JSON.parse(rd('package.json')).scripts.test, /node tests\/rev409\.test\.mjs/);
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
  assert.ok(rd('RIWAYAT.md').includes('**Rev 409 /'));
});
