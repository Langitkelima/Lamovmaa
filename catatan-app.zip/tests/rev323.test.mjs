// Rev 323 / PART L2: dialog Sisipkan > Tautan + kartu inline tanpa thumbnail. DOM nyata dicek di Chromium; tes Node ini mengunci kode dan kontrak.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { staticGraph } from '../scripts/preload.mjs';
import { linkCardAttrOk, linkCardUrl, LK_ERR } from '../src/js/linkcard.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const notes = src('src/js/notes.js'), ui = src('src/js/linkcard-ui.js'), lipat = src('src/js/lipat.js'), css = src('src/css/styles.css');

test('Rev 323: kait sanitize di notes.js (kartu hanya DIV.lk-card, isi dikosongkan, tanpa alamat sah dibuang)', () => {
  assert.match(notes, /const lk = c\.tagName === 'DIV' && c\.getAttribute\('class'\) === 'lk-card'/);
  assert.match(notes, /\|\| \(lk && lkOk\(k, v\)\)/);
  assert.match(notes, /querySelectorAll\('\.lk-card'\)\.forEach\(\(el\) => \{ if \(!lkU\(el\.getAttribute\('data-u'\) \|\| ''\)\) el\.remove\(\); else \{ el\.replaceChildren\(\); el\.removeAttribute\('style'\); el\.setAttribute\('contenteditable', 'false'\); \} \}\)/);
  assert.match(notes, /const BLOCK_SEL = '[^']*\.lk-card'/);
});
test('Rev 323: lkOk/lkU di notes.js memberi hasil sama dengan linkCardAttrOk (linkcard.js)', () => {
  const a = notes.indexOf('const LK_CT ='), b = notes.indexOf("registerBlock({ type: 'lk'");
  assert.ok(a > 0 && b > a);
  const safeImageUrl = (await_u) => (/^https:\/\//i.test(await_u) ? await_u : '');
  // eslint-disable-next-line no-new-func
  const lkOk = new Function('safeImageUrl', notes.slice(a, b) + '\nreturn lkOk;')(safeImageUrl);
  const cases = [
    ['class', 'lk-card'], ['class', 'lk-card x'], ['contenteditable', 'false'], ['contenteditable', 'true'],
    ['data-u', 'https://contoh.com/a?b=1'], ['data-u', 'http://contoh.com'], ['data-u', 'javascript:alert(1)'], ['data-u', 'data:text/html,x'], ['data-u', 'https://a.com@b.com/x'],
    ['data-u', 'https://localhost/x'], ['data-u', 'https://192.168.0.1/x'], ['data-u', 'https://contoh.com/a b'], ['data-u', 'https://contoh.com/' + 'a'.repeat(2100)], ['data-u', 'contoh.com'], ['data-u', ''],
    ['data-t', 'Judul biasa'], ['data-t', 'x'.repeat(141)], ['data-t', 'a\u0001b'], ['data-s', 'Situs'], ['data-s', 'x'.repeat(61)],
    ['data-i', 'https://cdn.contoh.com/g.jpg'], ['data-i', 'http://cdn.contoh.com/g.jpg'], ['data-i', 'javascript:x'],
    ['data-a', 'l'], ['data-a', 'c'], ['data-a', 'r'], ['data-a', 'x'], ['onclick', 'alert(1)'], ['style', 'color:red'], ['data-x', '1'],
  ];
  for (const [k, v] of cases) assert.equal(lkOk(k, v), linkCardAttrOk(k, v), k + '=' + v.slice(0, 40));
});
test('Rev 323: registri blok lk, OUT_OF_BODY, tombol Tautan di bilah (juga di Catatan Privat), ikon, pembuka dialog malas', () => {
  assert.match(notes, /registerBlock\(\{ type: 'lk', selector: '\.lk-card'/);
  assert.match(notes, /strip: \(el\) => el\.replaceChildren\(\)/);
  assert.match(lipat, /OUT_OF_BODY = '[^']*,\.lk-card';/);
  assert.match(notes, /insertBtn\('link', 'Tautan'\), \.\.\.\(isP \? \[\] : \[insertBtn\('image', 'Gambar'\)\]\)/);
  assert.match(notes, /\n    link: 'M/);
  assert.match(notes, /else if \(kind === 'link'\) openLinkDialog\(\);/);
  const i = notes.indexOf('const openLinkDialog = () =>'); const body = notes.slice(i, i + 700);
  assert.match(body, /editorMode !== 'edit'/); assert.match(body, /import\('\.\/linkcard-ui\.js'\)/); assert.match(body, /kind: isP \? 'priv' : 'note'/); assert.match(body, /placeBlock\(el, savedRange, 'Tautan'\)/);
});
test('Rev 323: anggaran: linkcard-ui.js dan linkcard.js TIDAK di graf statis main.js; notes.js tidak mengimpor statis', () => {
  const g = staticGraph('js/main.js');
  assert.ok(!g.includes('js/linkcard-ui.js') && !g.includes('js/linkcard.js'));
  assert.ok(!/^import .*linkcard/m.test(notes));
  assert.ok(g.length <= 53, 'modul statis ' + g.length);
});
test('Rev 323: linkcard-ui.js: alasan tertulis untuk SEMUA kode penolakan, Sisipkan nonaktif selama tidak sah', async () => {
  for (const [bad, why] of [['', 'kosong'], ['javascript:alert(1)', 'skema'], ['https://a b.com', 'spasi'], ['https://a.com@b.com', 'akun'], ['https://localhost', 'host'], ['https://' + 'a'.repeat(2100) + '.com', 'panjang']]) {
    assert.equal(linkCardUrl(bad).why, why, bad.slice(0, 30)); assert.equal(linkCardUrl(bad).error || LK_ERR, LK_ERR);
  }
  const m = await import('../src/js/linkcard-ui.js').catch(() => null); // butuh DOM untuk ui.js; di Node cukup cek teks bila gagal
  const whyKeys = ['kosong', 'panjang', 'spasi', 'skema', 'format', 'akun', 'host'];
  if (m) for (const k of whyKeys) assert.ok(m.LK_WHY[k] && m.LK_WHY[k].length > 20, k);
  else for (const k of whyKeys) assert.match(ui, new RegExp('\\b' + k + ": '"));
  assert.match(ui, /const ok = h\('button', \{ type: 'button', class: 'btn', disabled: true \}, 'Sisipkan'\)/);
  assert.match(ui, /ok\.disabled = !r\.ok/);
  assert.match(ui, /msg\.textContent = empty \? LK_WHY\.kosong : LK_ERR \+ '\. ' \+ LK_WHY\[r\.why\]/);
});
test('Rev 323: privasi (D6): di Catatan Privat tidak ada pengambilan internet; hanya satu pendengar global dan tidak ada innerHTML', () => {
  assert.match(ui, /if \(linkCardFetchAllowed\(kind\)\) fill\(el, r\.url, ed, save\);/);
  assert.equal((ui.match(/fetchPreview\(/g) || []).length, 1, 'fetchPreview hanya dipanggil di fill()');
  assert.equal((ui.match(/document\.addEventListener\(/g) || []).length, 1, 'hanya satu pendengar global');
  assert.match(ui, /let wired = false;/);
  assert.doesNotMatch(ui.replace(/\/\/.*$/gm, ''), /innerHTML|outerHTML|insertAdjacentHTML|eval\(|new Function|localStorage/);
  assert.match(ui, /if \(!ed\.isConnected \|\| !ed\.contains\(el\)\) return;/, 'hasil lambat tidak menyentuh catatan yang sudah ditutup/kartu dihapus');
});
test('Rev 323: mode Edit hanya panah yang membuka tautan; mode Baca seluruh kartu; hanya http/https lewat openExternal', () => {
  assert.match(ui, /if \(!card\.closest\('\.ed-baca'\) && !e\.target\.closest\('\.lk-go'\)\) return;/);
  assert.match(ui, /bukaTautan\(card\.getAttribute\('data-u'\) \|\| ''\)/); // Rev 325: lewat bukaTautan (openExternal + toast peringatan bila gagal)
});
test('Rev 323: CSS kartu + dialog ada, memakai token tema (terang/gelap), area sentuh panah 44px, tanpa animasi baru (A2)', () => {
  for (const c of ['.lk-card{', '.lk-ic{', '.lk-tx{', '.lk-t{', '.lk-h{', '.lk-go{', '.lk-msg{', '.lk-row{']) assert.ok(css.includes(c), c);
  const blk = css.slice(css.indexOf('/* Rev 323 / L2'), css.indexOf('/* Rev 326 / A2') > 0 ? css.indexOf('/* Rev 326 / A2') : undefined); // Rev 326: blok A2 (animasi) sengaja di luar bagian L2
  assert.match(blk, /\.lk-go\{[^}]*width:44px;height:44px/);
  assert.match(blk, /var\(--ln\)/); assert.match(blk, /var\(--acs\)/);
  assert.doesNotMatch(blk, /@keyframes|animation:|transition:/);
});
