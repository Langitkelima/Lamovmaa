// Rev 75: tinggi latar dikunci supaya tidak melar saat keyboard muncul/turun; versi 0.3.2.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { skyHeight, installSkyLock } from '../src/js/langit.js';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 75: skyHeight menyimpan tinggi terbesar (keyboard tidak mengecilkan)', () => {
  let st = skyHeight(0, 0, 800, 360);
  assert.deepEqual(st, { h: 800, w: 360 });
  st = skyHeight(st.h, st.w, 480, 360); // keyboard muncul
  assert.equal(st.h, 800);
  st = skyHeight(st.h, st.w, 800, 360); // keyboard turun
  assert.equal(st.h, 800);
});
test('Rev 75: skyHeight reset saat lebar berubah (diputar) dan abaikan nilai 0', () => {
  assert.deepEqual(skyHeight(800, 360, 360, 800), { h: 360, w: 800 });
  assert.equal(skyHeight(800, 360, 0, 360).h, 800);
});
test('Rev 75: installSkyLock mengisi --skyh dan menjaga nilai saat resize', () => {
  const props = {}; const lis = {};
  const doc = { documentElement: { style: { setProperty: (k, v) => { props[k] = v; } } } };
  const win = { innerHeight: 800, innerWidth: 360, addEventListener: (e, f) => { lis[e] = f; } };
  installSkyLock(doc, win);
  assert.equal(props['--skyh'], '800px');
  win.innerHeight = 470; lis.resize();
  assert.equal(props['--skyh'], '800px');
});
test('Rev 75: CSS memakai tinggi tetap untuk body dan .fs.skybg; main.js memasang', () => {
  const css = src('src/css/styles.css');
  assert.match(css, /body\{isolation:isolate;background-image:var\(--glow\),var\(--sky\);background-size:100% var\(--skyh,100%\)/);
  assert.match(css, /\.fs\.skybg\{[^}]*background-size:100% var\(--skyh,100%\)/);
  assert.match(src('src/js/main.js'), /installSkyLock\(\)/);
});
test('Rev 75: tanpa native/SCHEMA; versi 0.3.2 selaras', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('RIWAYAT.md').includes('versi 0.3.2'));
});
