// Rev 152 / U10b-2a: UI gabung sel (menu Lainnya, sel jangkar membentang, penjaga)
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as G from '../src/js/lembar-gabung.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
const ui = src('js/lembar-ui.js');
const fn = (name, next) => { const a = ui.indexOf(name); assert.ok(a > 0, name); const b = ui.indexOf(next, a + name.length); return ui.slice(a, b > 0 ? b : undefined); };
test('menu Lainnya: item gabung berganti Gabung sel / Pisahkan sel, ada sebelum warna bersyarat', () => {
  const m = fn('const openMore = () => {', 'bM.addEventListener');
  // Rev 264: Gabung/Pisahkan sel hanya di Menu sel (tekan lama), tidak diulang di Lainnya
  assert.ok(!m.includes("item('gabung'") && ui.includes("'Pisahkan sel' : 'Gabungkan sel', openMerge"));
});
test('openMerge: snapshot SEBELUM perubahan, lewat lembar.js, satu hist.push per aksi, batas ukuran dicek', () => {
  const o = fn('const openMerge = () => {', '// --- Rev 157 / U10c-2a: Diagram');
  assert.equal((o.match(/ver\+\+, hist\.push\(snap\)/g) || []).length, 3); // pisahkan + gabungkan lewat dialog + gabungkan langsung dari seleksi (Rev 260)
  assert.ok(o.indexOf('const snap = ser()') < o.indexOf('L.unmergeCell('));
  const g = o.slice(o.indexOf('goB.onclick')); assert.ok(g.indexOf('const snap = ser()') < g.indexOf('L.mergeCells(') && g.indexOf('L.fitsLimit(sheet)') < g.indexOf('hist.push(snap)'));
  assert.ok(g.includes('{ clear: true }') && o.includes('planMerge(') && o.includes('Gabungkan dan kosongkan'));
});
test('grid: sel tertutup tidak digambar, jangkar membentang lebar dan tinggi, jangkar di atas layar ikut digambar (Rev 178: juga saat filter aktif)', () => {
  const d = fn('const drawRows = () => {', 'const paintBar = () => {');
  assert.ok(d.includes('mergeView(tab, ord)') && d.includes('m.pos < from && m.pos + m.count > from'));
  assert.ok(d.includes('return; // Rev 152') && d.includes("classList.add('mg')") && d.includes('lay.tops[mg.pos + mg.count] - lay.tops[mg.pos]') && d.includes('colLeft(tab, mg.c2)'));
  assert.match(src('css/styles.css'), /Rev 152 \/ U10b-2a/); assert.match(src('css/styles.css'), /\.lz-c\.mg\{z-index:1/);
});
test('penjaga sementara Rev 152 dicabut di Rev 153 (U10b-2b): alat memperhatikan gabungan sendiri; Cari-ganti tidak dijaga', () => {
  assert.ok(!ui.includes('blockMerged')); assert.ok(!ui.includes("blockMerged('Cari"));
  assert.match(src('js/lembar-alat.js'), /Rev 153 \/ U10b-2b/);
});
test('perilaku inti yang dipakai UI: gabung dari sel terpilih, pisahkan dari sel jangkar, bentuk tersimpan bertahan', () => {
  const sh = L.newSheet({ name: 'A' }), t = sh.tabs[0]; L.setCell(t, t.rows[0].id, t.cols[0].id, { v: 'Judul' }); L.setCell(t, t.rows[0].id, t.cols[2].id, { v: 'x' });
  const p = G.planMerge(t, 0, 0, 1, 2); assert.equal(p.filled, 1);
  assert.deepEqual(L.mergeCells(t, 0, 0, 1, 2, { clear: true }), { ok: true, cleared: 1 });
  assert.equal(G.mergeAt(t, 1, 1).ref, 'A1:C2'); assert.equal(G.isCovered(t, 1, 1), true);
  const back = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.equal(G.mergeList(back.tabs[0])[0].ref, 'A1:C2'); assert.equal(back.tabs[0].rows[0].cells[back.tabs[0].cols[0].id].v, 'Judul');
  assert.equal(L.unmergeCell(t, 0, 0), true); assert.equal('merges' in t, false); assert.equal(t.rows[0].cells[t.cols[0].id].v, 'Judul');
});
test('tanpa penyimpanan langsung di UI; Rev 152: versi 0.3.121, SCHEMA 16 tetap, tes terdaftar', () => {
  assert.ok(!/localStorage|persist\(|eval\(|new Function|Capacitor/.test(ui)); assert.ok(ui.includes("from './lembar-gabung.js'"));
  const pk = readFileSync(new URL('../package.json', import.meta.url), 'utf8'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev152.test.mjs')); assert.match(src('js/settings.js'), /Notes Kelimaa v0\.3\.121/);
  assert.match(src('js/storage.js'), /SCHEMA = 22;/);
});
