// Rev 258: menu Lainnya > Pilih rentang DIHAPUS (keputusan pengguna D-S2, 13 Nov 2026). Tes Node; BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8'); const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
test('menu Lainnya tanpa Pilih rentang; Salin & Tempel dan Urutkan tetap ada (Ubah seleksi pindah ke Menu sel, Rev 264)', () => {
  const m = ui.slice(ui.indexOf("item('salin'"), ui.indexOf("item('cari'"));
  assert.ok(!m.includes('rentang') && !m.includes("item('aksi'") && m.includes("item('asc'") && m.includes("item('desc'"));
});
test('mode, spanduk, dan CSS Pilih rentang hilang; rentang tetap bisa dibuat lewat titik seret dan kepala', () => {
  for (const k of ['rngMode', 'startRange', 'rgEl', 'lz-rgb', 'rg-off', 'RANGE_MSG', 'makeRange']) assert.ok(!ui.includes(k) && !css.includes(k), k);
  assert.ok(ui.includes('SX.selectRange(') && ui.includes('SX.selectCol(') && ui.includes('SX.selectRow(') && ui.includes('hdDown'));
  assert.ok(ui.includes('const paintRg = () => { normSel(); };') && ui.includes('rng = k &&'));
});
test('Rev 131 (ketuk-sisip-rujukan) dan Rev 148 (validasi) tidak berubah', () => {
  assert.match(ui, /e\.stopImmediatePropagation\(\); e\.preventDefault\(\);\s*const r = insertRef\(/);
  assert.ok(ui.includes('if (again && (() => { const pk = checkAt(tab, sel.r, sel.c); return !!pk && pk.dd !== false; })()) openPick();'));
});
