// Rev 32b / Tahap 6: pagar regresi CSS untuk scroll dan transisi ringan Android WebView.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const settings = readFileSync(new URL('../src/js/settings.js', import.meta.url), 'utf8');
assert.equal(pkg.version, '0.3.121');
assert.ok(settings.includes('Notes Kelimaa v0.3.121'), 'versi di layar Lainnya harus selaras');
assert.match(css, /main\s*\{[^}]*overscroll-behavior-y:\s*contain/s, 'scroll utama tidak merembet ke halaman induk');
assert.match(css, /\.fsb,\s*\.menu\s*\{\s*overscroll-behavior-y:\s*contain;/, 'panel editor dan menu punya batas scroll');
assert.match(css, /\.row,\s*\.card,\s*\.set\s*\{\s*transition:\s*border-color[^}]*transform/s, 'transisi kartu tidak menginterpolasi box-shadow yang lebih mahal');
assert.doesNotMatch(css.match(/\.fab\s*\{[^}]*transition:[^}]*\}/s)?.[0] || '', /filter\s*\./, 'FAB tidak menganimasikan filter');
assert.match(css, /prefers-reduced-motion:\s*reduce/, 'dukungan gerakan dikurangi tetap tersedia');
console.log('7 tes lulus (Android performance CSS)');
