// Rev 303b / v0.3.121: KOTAK CENTANG di sel lembar kerja, bagian 2 = UI (Validasi data > Kotak centang, gambar sel, ketuk = centang/lepas). Tanpa CSS baru, SCHEMA 22 tetap.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
test("editor Validasi data: opsi 'Kotak centang' (box), kartu kriteria dan pilihan disembunyikan, catatan, label chip", () => {
  assert.match(ui, /\['date', 'Tanggal'\], \['box', 'Kotak centang'\]\]/); assert.match(ui, /kind === 'url' \|\| kind === 'box';/);
  assert.match(ui, /kind === 'box' \? 'Sel di rentang jadi kotak centang/); assert.match(ui, /date: 'Tanggal', box: 'Kotak' \}\)\[ck\.k\]/);
});
test('gambar sel: ☑/☐ hanya untuk sel tanpa rumus yang kosong/boolean/TRUE-FALSE; teks lain tetap teks (ditandai tidak sah); sel berumus tidak diubah', () => {
  const i = ui.indexOf("if (vck && vck.k === 'box' && !fxd)"); assert.ok(i > 0); const seg = ui.slice(i, i + 700);
  assert.match(seg, /rv === undefined \|\| rv === null \|\| rv === '' \|\| typeof rv === 'boolean' \|\| \/\^\(true\|false\)\$\/i/); /* Rev 303c: glyph \u2611/\u2610 diganti kotak CSS (lihat rev303c.test.mjs) */
  assert.match(seg, /ha-center/); assert.match(seg, /dataset\.box/); assert.match(seg, /role', 'checkbox'/); assert.match(seg, /aria-checked/);
});
test('ketuk = centang/lepas lewat toggleBox: L.setCell boolean, fitsLimit, SATU langkah Urungkan (snapshot sebelum), sel berumus ditolak', () => {
  const i = ui.indexOf('const toggleBox = '); assert.ok(i > 0); const seg = ui.slice(i, i + 900);
  assert.match(seg, /isBox\(checkAt\(tab, r, ci\)\)/); assert.match(seg, /hasFx\(pc\)/); assert.match(seg, /nextBoxValue\(pc && pc\.v\)/); assert.match(seg, /L\.fitsLimit\(sheet\)\) \{ restore\(snap\)/);
  assert.equal((seg.match(/hist\.push\(snap\)/g) || []).length, 1); assert.ok(seg.indexOf('const snap = ser()') < seg.indexOf('L.setCell'));
  assert.match(ui, /if \(c\.classList\.contains\('lz-c'\) && c\.dataset\.box !== undefined\) \{ toggleBox\(sel\.r, sel\.c\); return; \}/);
});
test('impor: mesin murni lembar-kotak.js hanya diimpor lembar-ui.js (modul malas); main.js dan modul awal tidak mengimpornya', () => {
  assert.match(ui, /import \{ isBox, boxState, nextBoxValue(?:, [A-Za-z, ]+)? \} from '\.\/lembar-kotak\.js'/);
  for (const f of ['main', 'startup', 'notes', 'settings', 'storage', 'lembar-pintu', 'lembar']) assert.ok(!src('src/js/' + f + '.js').includes('lembar-kotak'), f + ' tidak mengimpor lembar-kotak');
});
test('anggaran: CSS di bawah anggaran resmi cssMaks 270 KB (Rev 383), SCHEMA 22 dan versi 0.3.121 tetap', () => {
  assert.ok(Buffer.byteLength(css) <= 270 * 1024); /* Rev 383: batas disamakan dengan cssMaks resmi 270 KB */
  assert.match(src('src/js/storage.js'), /SCHEMA = 22/); assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
});
test('alat audit Chromium tools/audit_kotak.py ada dan memeriksa buat, gambar, ketuk, Urungkan, tahan lama', () => {
  const a = src('tools/audit_kotak.py'); for (const k of ['dropdown', 'select_option', "'box'", 'aria-checked', 'Urungkan', 'tahan lama']) assert.ok(a.includes(k), k);
});
test('dokumen: README < 12000 huruf; entri Rev 303b di PROMPT dan RIWAYAT (paling atas); UJI_HP bagian AI; tes terdaftar', () => {
  const r = src('README.md'); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */); assert.match(r, /Rev 303b/); assert.match(r, /bukan\*\* bukti APK/);
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 303b / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('**Rev 303b / v0.3.121')); assert.match(src('UJI_HP_RILIS.md'), /## AI\. Kotak centang di sel \(Rev 303b\)/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev303b\.test\.mjs/);
});
console.log('rev303b: ' + n + ' tes');
