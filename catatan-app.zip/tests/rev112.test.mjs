// Rev 112 / U6d: Pindahkan ke dalam / keluar dari bagian lipat (bilah chip "Alat bagian lipat").
// Perilaku nyata (ketuk chip, kursor, Urungkan/Ulangi, simpan dan buka ulang, mode Baca) dicek di Chromium 360x800 saat revisi dibuat
// (22 pemeriksaan + Urungkan/Ulangi/buka ulang); tes Node ini mengunci fungsi murni (DOM mini) dan kontrak kode.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { canMoveIntoFold, topBlockOf, blockBelowFold, foldMoveContext, moveBlockIntoFold, moveBlockOutOfFold } from '../src/js/lipat.js';
import { FOLD_IN_CHIPS, FOLD_OUT_CHIPS } from '../src/js/bilah-chip.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const notes = src('src/js/notes.js'), lipat = src('src/js/lipat.js');

// DOM mini yang cukup untuk fungsi U6d (selector sederhana: .kelas, tag, [atribut], dipisah koma)
class N {
  constructor(type, tag, data) { this.nodeType = type; this.tagName = tag; this.data = data; this.childNodes = []; this.parentNode = null; this.attrs = {}; }
  get className() { return this.attrs.class || ''; }
  set className(v) { this.attrs.class = v; }
  get classList() { const c = () => this.className.split(/\s+/).filter(Boolean); return { contains: (x) => c().includes(x) }; }
  get parentElement() { return this.parentNode && this.parentNode.nodeType === 1 ? this.parentNode : null; }
  get firstChild() { return this.childNodes[0] || null; }
  get lastChild() { return this.childNodes[this.childNodes.length - 1] || null; }
  get children() { return this.childNodes.filter((c) => c.nodeType === 1); }
  get firstElementChild() { return this.children[0] || null; }
  get lastElementChild() { return this.children[this.children.length - 1] || null; }
  get previousElementSibling() { const s = this.parentNode ? this.parentNode.children : []; return s[s.indexOf(this) - 1] || null; }
  get nextElementSibling() { const s = this.parentNode ? this.parentNode.children : []; return s[s.indexOf(this) + 1] || null; }
  get textContent() { return this.nodeType === 3 ? this.data : this.childNodes.map((c) => c.textContent).join(''); }
  getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; }
  setAttribute(k, v) { this.attrs[k] = String(v); }
  removeAttribute(k) { delete this.attrs[k]; }
  append(...k) { for (const c of k) { if (c.parentNode) c.remove(); c.parentNode = this; this.childNodes.push(c); } }
  remove() { if (this.parentNode) { this.parentNode.childNodes.splice(this.parentNode.childNodes.indexOf(this), 1); this.parentNode = null; } }
  after(...k) { const p = this.parentNode; let i = p.childNodes.indexOf(this) + 1; for (const c of k) { if (c.parentNode) c.remove(); i = p.childNodes.indexOf(this) + 1 + (k.indexOf(c)); c.parentNode = p; p.childNodes.splice(i, 0, c); } }
  contains(n) { for (let x = n; x; x = x.parentNode) if (x === this) return true; return false; }
  matches(sel) { return sel.split(',').some((s) => { s = s.trim(); if (s[0] === '.') return this.classList.contains(s.slice(1)); if (s[0] === '[') return (s.slice(1, -1)) in this.attrs; return this.tagName === s.toUpperCase(); }); }
  closest(sel) { for (let x = this; x && x.nodeType === 1; x = x.parentNode) if (x.matches(sel)) return x; return null; }
}
const doc = { createElement: (t) => new N(1, t.toUpperCase()) };
const el = (t, cls, ...k) => { const e = new N(1, t.toUpperCase()); if (cls) e.className = cls; e.append(...k); return e; };
const tx = (d) => { const n = new N(3, undefined, d); return n; };
const para = (t) => el('p', '', tx(t));
const blank = () => el('p', '', el('br'));
const mkFold = (open, rows, title = 'J') => { const f = el('div', 'fold', el('div', 'fh', tx(title)), el('div', 'fb', ...rows)); if (open) f.setAttribute('data-o', '1'); return f; };
const mkEd = (...k) => { const ed = el('div', 'ed2', ...k); return ed; };
const texts = (parent) => parent.children.map((c) => c.textContent).join('|');

test('Rev 112: lipat.js mengekspor fungsi U6d dan tetap bebas penyimpanan/native/Intl/eval', () => {
  for (const f of [canMoveIntoFold, topBlockOf, blockBelowFold, foldMoveContext, moveBlockIntoFold, moveBlockOutOfFold]) assert.equal(typeof f, 'function');
  assert.doesNotMatch(lipat, /localStorage|AndroidAPI|Intl\.|eval\(|new Function/);
});
test('Rev 112: canMoveIntoFold = teks, kotak centang, daftar, kutipan; BUKAN tabel, gambar, blok pulau, bagian lipat, baris alat sementara', () => {
  assert.equal(canMoveIntoFold(el('p')), true);
  assert.equal(canMoveIntoFold(el('div', 'todo')), true);
  assert.equal(canMoveIntoFold(el('ul')), true);
  assert.equal(canMoveIntoFold(el('blockquote')), true);
  for (const c of ['tbl-wrap', 'mood-block', 'kb-date-block', 'kb-time-block', 'kb-countdown-block', 'fold']) assert.equal(canMoveIntoFold(el('div', c)), false, c);
  assert.equal(canMoveIntoFold(el('table')), false); assert.equal(canMoveIntoFold(el('figure')), false);
  const tool = el('div', 'x'); tool.setAttribute('data-kb-tool', ''); assert.equal(canMoveIntoFold(tool), false);
  assert.equal(canMoveIntoFold(null), false); assert.equal(canMoveIntoFold(tx('x')), false);
});
test('Rev 112: foldMoveContext: "in" untuk blok tepat di bawah bagian lipat, "out" untuk baris isi, null untuk judul/jauh/tabel/di luar editor', () => {
  const t1 = tx('isi'), t2 = tx('bawah'), t3 = tx('jauh'), th = tx('judul');
  const row = el('p', '', t1), below = el('p', '', t2), far = el('p', '', t3);
  const f = mkFold(true, [row]); f.children[0].childNodes[0] = th; th.parentNode = f.children[0];
  const ed = mkEd(f, below, far);
  assert.deepEqual([foldMoveContext(t1, ed).kind, foldMoveContext(t1, ed).row === row, foldMoveContext(t1, ed).fold === f], ['out', true, true]);
  const c = foldMoveContext(t2, ed); assert.deepEqual([c.kind, c.block === below, c.fold === f], ['in', true, true]);
  assert.equal(foldMoveContext(t3, ed), null, 'blok yang tidak tepat di bawah bagian lipat');
  assert.equal(foldMoveContext(th, ed), null, 'kursor di judul');
  assert.equal(foldMoveContext(tx('luar'), ed), null, 'simpul di luar editor');
  assert.equal(foldMoveContext(ed, ed), null); assert.equal(foldMoveContext(null, ed), null);
  const tt = tx('sel'); const tbl = el('div', 'tbl-wrap', el('table', '', el('tr', '', el('td', '', tt))));
  const ed2 = mkEd(mkFold(true, [blank()]), tbl);
  assert.equal(foldMoveContext(tt, ed2), null, 'tabel tepat di bawah bagian lipat tidak boleh masuk');
  const ta = tx('lipat2'); const ed3 = mkEd(mkFold(true, [blank()]), el('div', 'fold', el('div', 'fh', ta), el('div', 'fb', blank())));
  assert.equal(foldMoveContext(ta, ed3), null, 'bagian lipat tepat di bawah bagian lipat tidak bersarang');
});
test('Rev 112: moveBlockIntoFold memindahkan SIMPUL ASLI ke akhir isi, membuka bagian lipat, atribut (data-cid) utuh', () => {
  const todo = el('div', 'todo', el('input'), tx(' tugas')); todo.setAttribute('data-cid', 'abc');
  const f = mkFold(false, [para('isi1')]); const next = para('sesudah');
  const ed = mkEd(f, todo, next);
  assert.equal(moveBlockIntoFold(f, todo, doc), true);
  const fb = f.children[1];
  assert.equal(fb.lastElementChild, todo, 'simpul yang sama, bukan salinan');
  assert.equal(todo.getAttribute('data-cid'), 'abc');
  assert.equal(f.getAttribute('data-o'), '1', 'terbuka agar blok yang dipindah tetap terlihat');
  assert.equal(ed.children.length, 2); assert.equal(ed.children[1], next);
});
test('Rev 112: moveBlockIntoFold membuang baris kosong pengganti bila blok yang masuk berisi; mempertahankannya bila blok kosong', () => {
  const f = mkFold(true, [blank()]); const b = para('teks'); const ed = mkEd(f, b);
  assert.equal(moveBlockIntoFold(f, b, doc), true);
  assert.equal(texts(f.children[1]), 'teks'); assert.equal(f.children[1].children.length, 1);
  const f2 = mkFold(true, [blank()]); const e = blank(); mkEd(f2, e);
  assert.equal(moveBlockIntoFold(f2, e, doc), true);
  assert.equal(f2.children[1].children.length, 2, 'blok kosong ikut masuk, baris kosong lama tidak disentuh');
  const f3 = mkFold(true, [para('a'), blank()]); const c = para('c'); mkEd(f3, c);
  moveBlockIntoFold(f3, c, doc); assert.equal(texts(f3.children[1]), 'a||c', 'baris kosong di antara isi berteks tidak dibuang');
});
test('Rev 112: moveBlockIntoFold menolak blok yang tidak tepat di bawah bagian lipat, tabel/blok pulau, dan target yang bukan bagian lipat', () => {
  const f = mkFold(true, [para('a')]); const mid = para('mid'); const far = para('far'); mkEd(f, mid, far);
  assert.equal(moveBlockIntoFold(f, far, doc), false);
  const f2 = mkFold(true, [para('a')]); const tbl = el('div', 'tbl-wrap'); mkEd(f2, tbl);
  assert.equal(moveBlockIntoFold(f2, tbl, doc), false);
  assert.equal(moveBlockIntoFold(el('div', 'x'), para('z'), doc), false);
  assert.equal(texts(f.children[1]), 'a'); assert.equal(texts(f2.children[1]), 'a');
});
test('Rev 112: moveBlockOutOfFold: hanya baris itu yang keluar, tepat di bawah bagian lipat; baris lain tetap; isi tak pernah kosong total', () => {
  const r1 = para('r1'), r2 = para('r2'), r3 = para('r3'), sesudah = para('sesudah');
  const f = mkFold(true, [r1, r2, r3]); const ed = mkEd(f, sesudah);
  assert.equal(moveBlockOutOfFold(f, r2, doc), true);
  assert.equal(texts(f.children[1]), 'r1|r3');
  assert.equal(ed.children[1], r2, 'tepat di bawah bagian lipat, sebelum blok berikutnya'); assert.equal(ed.children[2], sesudah);
  const g = mkFold(true, [para('satu')]); const only = g.children[1].children[0]; const ed2 = mkEd(g);
  assert.equal(moveBlockOutOfFold(g, only, doc), true);
  assert.equal(g.children[1].children.length, 1, 'satu paragraf kosong tersisa'); assert.equal(g.children[1].textContent, '');
  assert.equal(ed2.children[1], only);
  assert.equal(moveBlockOutOfFold(g, para('luar'), doc), false, 'bukan anak langsung isi');
  assert.equal(moveBlockOutOfFold(el('div', 'x'), para('q'), doc), false);
});
test('Rev 112: pergi-balik masuk lalu keluar mengembalikan susunan awal (blok terakhir)', () => {
  const f = mkFold(true, [para('isi')]); const b = para('b'); const n = para('n'); const ed = mkEd(f, b, n);
  moveBlockIntoFold(f, b, doc); moveBlockOutOfFold(f, b, doc);
  assert.equal(texts(f.children[1]), 'isi');
  assert.equal(ed.children.length, 3); assert.equal(ed.children[0], f); assert.equal(ed.children[1], b); assert.equal(ed.children[2], n);
});
test('Rev 112: bilah-chip.js: dua definisi chip satu-tombol dengan teks polos (tanpa simbol)', () => {
  assert.deepEqual(FOLD_IN_CHIPS, { main: [{ id: 'fold-in', label: 'Pindahkan ke dalam bagian lipat' }] });
  assert.deepEqual(FOLD_OUT_CHIPS, { main: [{ id: 'fold-out', label: 'Pindahkan keluar dari bagian lipat' }] });
});
test('Rev 112: notes.js: import, bilah dipasang di dock sebelum bilah bawah, dan bilah tabel tidak mencabut kelas .chips saat bilah lipat tampil', () => {
  const imp = notes.split('\n').find((l) => l.startsWith('import { healAllFolds'));
  for (const k of ['foldMoveContext', 'moveBlockIntoFold', 'moveBlockOutOfFold']) assert.ok(imp.includes(k), k);
  assert.ok(notes.split('\n').find((l) => l.startsWith('import { createChipBar')).includes('FOLD_IN_CHIPS, FOLD_OUT_CHIPS'));
  assert.match(notes, /const foldBar = createChipBar\(h, \{ label: 'Alat bagian lipat', onAction: \(id\) => foldChip\(id\) \}\);/);
  assert.match(notes, /o\.querySelector\('\.dock'\)\.insertBefore\(foldBar\.el, bar\);/);
  assert.match(notes, /chipBar\.hide\(\); if \(!foldBar\.isShown\(\)\) o\.classList\.remove\('chips'\);/);
});
test('Rev 112: foldChip = satu langkah Undo, konteks dihitung ulang dari kursor, kursor dipulihkan di simpul asli; mode Baca menyembunyikan bilah', () => {
  const fn = notes.slice(notes.indexOf('const foldChip = (id) =>'), notes.indexOf('const selChanged ='));
  assert.match(fn, /if \(editorMode !== 'edit'\) return;/);
  assert.match(fn, /foldMoveContext\(node, ed\)/);
  assert.match(fn, /flushHist\(\);\s*const ok = cur\.kind === 'in' \? moveBlockIntoFold\(cur\.fold, cur\.block, document\) : moveBlockOutOfFold\(cur\.fold, cur\.row, document\);/);
  assert.match(fn, /setCaretAt\(node, off\)/);
  assert.match(fn, /flushHist\(\); auto\(\); foldUi\(\);/);
  assert.match(notes, /const selChanged = \(\) => \{ upd\(\); snap\(\); tableUi\(\); foldUi\(\); \};/);
  assert.match(notes, /if \(baca\) \{ chipBar\.hide\(\); foldBar\.hide\(\); foldCtx = null; o\.classList\.remove\('chips'\); \}/);
  const ui = notes.slice(notes.indexOf('const foldUi = () =>'), notes.indexOf('const foldChip = (id) =>'));
  assert.match(ui, /editorMode === 'edit' && node \? foldMoveContext\(node, ed\) : null/);
});
test('Rev 112: versi 0.3.121, SCHEMA 10, native dan dependensi tidak berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('node tests/rev111.test.mjs && node tests/rev112.test.mjs'));
});
