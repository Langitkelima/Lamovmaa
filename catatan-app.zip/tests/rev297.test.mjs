// Rev 297: Setelan = variasi G (profil terpusat) pilihan pengguna. Hanya tampilan; fungsi tombol tidak berubah.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const st = src('src/js/settings.js'), css = src('src/css/styles.css');
const vs = st.slice(st.indexOf('export function viewSettings'));
test('Rev 297: urutan = hero+angka, kartu Tema+Cadangan, hari kerja, daftar, TWO POCKETS+Tutup, kaki', () => {
  let at = 0;
  for (const k of ["'sethero mzhero'", "class: 'mzstat'", "class: 'mzg'", "class: 'seg3 mzs'", "'mzcard mzcad'", "class: 'mzwrap'", "class: 'mzlist'", "class: 'mz'", "class: 'foot'"]) { const i = vs.indexOf(k, at); assert.ok(i >= at && i >= 0, k); at = i; }
});
test('Rev 297: ringkasan angka (label, lembar, proyek, sampah) dan 8 baris daftar membuka layar yang sama seperti ubin lama', () => {
  assert.equal((vs.match(/stat\(/g) || []).length, 4); // 4 pemakaian
  assert.equal((vs.match(/\brow\(/g) || []).length, 7); // Rev 412: 7 baris (4 baris cadangan/Markdown diganti satu baris Sync); dulu 10 baris (Rev 344: + Panduan ketikan cepat; Rev 397: + Ekspor Markdown; Rev 398: + Impor Markdown)
  for (const k of ["go('labels')", "go('trash')", "go('lembar')", "go('proyek', 1)", "go('gambar')", "go('backup')", "go('sync')", 'askExit(ctx)']) assert.ok(vs.includes(k), k);
  assert.ok(vs.includes('tpSetCard(ctx, conn)')); // Rev 409/410: TWO POCKETS jadi kartu Setelan
});
test('Rev 297: tombol tema punya label pembaca layar (teks disembunyikan di kartu sempit); hari kerja tetap', () => {
  assert.ok(vs.includes("'aria-label': label") && vs.includes('applyTheme(v)') && vs.includes('toggleDay(s.days, d)'));
  assert.ok(css.includes('.mzthema .seg3 button span{display:none}'));
});
test('Rev 297: CSS memakai variabel tema (tanpa warna tetap), ada kartu, pil status, daftar baris', () => {
  const c = css.slice(css.indexOf('Rev 297'));
  for (const k of ['.mzg{display:grid;grid-template-columns:1fr 1fr', '.mzcard{', '.mzpill{', '.mzpill.on{', '.mzlist{', '.mzr{', 'var(--gbd)', 'var(--sg)', 'var(--rd)']) assert.ok(c.includes(k), k);
  assert.ok(!/#[0-9a-fA-F]{3,6}\b/.test(c), 'tanpa warna heksa tetap');
});
test('Rev 297: versi 0.3.121, SCHEMA 22 tetap, kaki halaman utuh', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/);
  assert.ok(st.includes('Notes Kelimaa v0.3.121')); assert.ok(pk.scripts.test.includes('rev297.test.mjs'));
});
console.log(n + ' tes lulus (Rev 297)');
