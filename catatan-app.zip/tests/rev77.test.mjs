// Rev D (0.3.2): Sisipkan pindah ke menu Langit (ikon peniti), Kutipan bisa dimatikan, desain ulang Suasana hati.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import test from 'node:test';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const nt = src('src/js/notes.js'), css = src('src/css/styles.css'), ui = src('src/js/ui.js');

test('Rev D (Rev 88): menu Sisipkan dihapus; tombolnya langsung di bilah Langit dan tidak di bilah tertutup', () => {
  assert.ok(!/insert-trigger|insert-panel|icoPeniti/.test(nt));
  assert.ok(!/export function icoPeniti/.test(ui));
  const bar = nt.slice(nt.indexOf("const bar = h('div', { class: 'fbar' }"), nt.indexOf('const starBtn'));
  assert.ok(bar.indexOf("insertBtn('date'") > bar.indexOf("'data-cmd': 'redo'"), 'tombol sisip setelah Undo/Star/Redo = hanya tampil di bilah terbuka');
});
test('Rev D: Kutipan bisa dimatikan (toggle), Backspace di awal kutipan dan Enter di kutipan kosong melepasnya', () => {
  assert.match(nt, /const toggleQuote = /);
  assert.match(nt, /kind === 'quote'\) toggleQuote\(\)/);
  assert.match(nt, /const unwrapQuote = /);
  assert.match(nt, /e\.key === 'Backspace'/);
  assert.match(nt, /if \(!block \|\| !quote\.contains\(block\)\) block = quote;/);
});
test('Rev D: unwrapQuote bekerja di DOM nyata (toggle, kutipan kosong, kutipan berisi div)', async () => {
  let JSDOM; try { ({ JSDOM } = await import('jsdom')); } catch (_) { return; }
  const dom = new JSDOM('<div id="ed"><blockquote>abc</blockquote><blockquote><div>x</div><div>y</div></blockquote><blockquote></blockquote></div>');
  const { document } = dom.window;
  const fn = new Function('document', 'ed', 'getSelection', nt.match(/const unwrapQuote = [\s\S]*?\n  \};\n/)[0].replace('const unwrapQuote =', 'return') );
  const ed = document.getElementById('ed');
  const un = fn(document, ed, () => ({ rangeCount: 0, removeAllRanges() {}, addRange() {} }));
  const qs = [...ed.querySelectorAll('blockquote')];
  qs.forEach((q) => un(q));
  assert.equal(ed.querySelectorAll('blockquote').length, 0);
  assert.equal(ed.textContent, 'abcxy');
});
test('Rev D: wajah Suasana hati digambar CSS per data-mood-value, tanpa emoji; syncMood membersihkan emoji lama', () => {
  for (let i = 0; i < 5; i++) assert.ok(css.includes(`.mood-face[data-mood-value="${i}"]{background-image:url("data:image/svg+xml`), 'wajah ' + i);
  assert.match(css, /\.mood-block\[data-mood-value="4"\]\{--mc:/);
  assert.match(css, /\.mood-face\.selected\{[^}]*scale\(1\.2\)/);
  assert.match(nt, /if \(f\.textContent\) f\.textContent = ''/);
  assert.match(css, /\.mood-face\{[^}]*height:44px/);
});
test('Rev D: versi 0.3.2 selaras', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('RIWAYAT.md').includes('versi 0.3.2'));
});
test('Rev E: PDF/JPG menggambar kartu Suasana hati (blok mood), TXT/MD tetap teks', () => {
  const ex = src('src/js/export.js'), sh = src('src/js/share.js');
  assert.match(ex, /export function moodGeom\(/);
  assert.match(ex, /kind: 'mood'/);
  assert.match(sh, /function drawMoodCard\(/);
  assert.match(sh, /l\.kind === 'mood'\) \{ drawMoodCard/);
  assert.match(ex, /runs: \[\{ t: 'Suasana hati: ' \+ label/); // teks untuk TXT/MD tidak hilang
});
