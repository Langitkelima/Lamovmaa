// Rev 406: impor Markdown membaca ZIP sekali ke memori (bukan dua pembacaan per isi).
import { readFileSync } from 'node:fs';
import { strict as assert } from 'node:assert';
import { buildZip, readZipIndex, readZipEntry } from '../src/js/zip.js';
const src = readFileSync(new URL('../src/js/impor-md-ui.js', import.meta.url), 'utf8');
const t = (n, f) => { f(); console.log('ok', n); };
t('rev406: readPicked memakai zipDiMemori dan tidak membaca isi dari berkas pilihan', () => {
  assert.match(src, /zipDiMemori\(f\)/);
  assert.doesNotMatch(src, /readZipEntry\(f,/);
  assert.doesNotMatch(src, /readZipIndex\(f\)/);
});
let reads = 0;
const files = Array.from({ length: 60 }, (_, i) => ({ name: 'c' + i + '.md', data: new TextEncoder().encode('# J' + i + '\nisi ' + i) }));
const zip = buildZip(files, new Date());
const asli = { size: zip.length, slice: (a, b) => ({ arrayBuffer: async () => { reads++; return zip.buffer.slice(zip.byteOffset + a, zip.byteOffset + b); } }) };
const all = zip.buffer.slice(zip.byteOffset, zip.byteOffset + zip.length);
const mem = { size: all.byteLength, slice: (a, b) => ({ arrayBuffer: async () => all.slice(a, b) }) };
const idx = await readZipIndex(mem);
t('rev406: irisan memori terbaca benar (60 isi, CRC cocok)', () => assert.equal(idx.length, 60));
for (const e of idx) assert.ok((await readZipEntry(mem, e)).length > 0);
await readZipIndex(asli);
t('rev406: cara lama butuh banyak pembacaan (' + reads + ') vs satu', () => assert.ok(reads > 60));
