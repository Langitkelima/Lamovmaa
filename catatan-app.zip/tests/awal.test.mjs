// Rev 32c: saat aplikasi dibuka, layar awal harus Tugas > Kebiasaan Harian (bukan Fokus Hari Ini).
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const main = src('../src/js/main.js');
assert.match(main, /const ui = \{ tab: 'tugas', seg: 'habit',/, 'layar awal = Kebiasaan Harian');
assert.ok(!/const ui = \{[^}]*seg: 'hari'/.test(main), 'tidak lagi mulai dari Fokus Hari Ini');
assert.ok(main.includes("ui.seg = item.scope || 'hari'"), 'ketukan notifikasi tugas tetap membuka ruang tugasnya');
for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'])
  for (const f of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png', 'ic_launcher_bglayer.png'])
    assert.ok(existsSync(new URL(`../resources/android/res/mipmap-${d}/${f}`, import.meta.url)), `ikon peluncur ${d}/${f} harus ada di ZIP`);
assert.ok(existsSync(new URL('../resources/android/res/values/ic_launcher_background.xml', import.meta.url)));
assert.ok(existsSync(new URL('../resources/android/res/mipmap-anydpi-v26/ic_launcher.xml', import.meta.url)));
console.log('4 tes lulus (layar awal + kelengkapan ikon peluncur)');
