// Rev 230: sheet.append_row = baris dari balasan AI ke lembar kerja. Tanpa HP, tanpa DOM.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as B from '../src/js/ai/baris.js';
import * as L from '../src/js/lembar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => { const s = L.newSheet({ id: 's1', name: 'Pengeluaran', now: 1 }); const ctx = { data: { sheets: { s1: s }, notes: [{ id: 'n' }], tasks: [], habits: [], priv: [{ id: 'p' }], trash: [] }, persists: 0, persist() { this.persists++; } }; return { ctx, s, tab: s.tabs[0] }; };
const val = (tab, r, c) => { const x = L.cellAt(tab, r, c); return x ? x.v : undefined; };

test('rowDrafts: tabel Markdown (judul ditandai), tanpa pemisah; tanda **/` dibuang', () => {
  const d = B.rowDrafts('Ini rinciannya:\n| Item | Harga |\n|---|---:|\n| **Kopi** | 15000 |\n| Roti | 12,5 |');
  assert.equal(d.length, 3); assert.equal(d[0].head, true); assert.deepEqual(d[1].cells, ['Kopi', '15000']); assert.equal(d[1].head, false); assert.deepEqual(d[2].cells, ['Roti', '12,5']);
});
test('rowDrafts: tanpa tabel -> butir daftar = baris satu sel; maks. 10; kosong = []', () => {
  const d = B.rowDrafts('- Susu\n- Telur\n1. Beras\n2) [ ] Gula'); assert.deepEqual(d.map((x) => x.cells[0]), ['Susu', 'Telur', 'Beras', 'Gula']);
  assert.equal(B.rowDrafts(Array.from({ length: 15 }, (_, i) => '- a' + i).join('\n')).length, B.ROW_MAX);
  assert.deepEqual(B.rowDrafts('Halo apa kabar'), []); assert.deepEqual(B.rowDrafts(null), []);
});
test('toCellValue: angka polos jadi angka, 15.000 tetap teks, "=" diberi apostrof', () => {
  assert.equal(B.toCellValue('15000'), 15000); assert.equal(B.toCellValue('12,5'), 12.5); assert.equal(B.toCellValue('-3'), -3); assert.equal(B.toCellValue('15.000'), '15.000');
  assert.equal(B.toCellValue('=SUM(A1)'), "'=SUM(A1)"); assert.equal(B.toCellValue('  '), undefined); assert.equal(B.toCellValue('Kopi'), 'Kopi');
});
test('appendRows: mulai di bawah baris terisi terakhir, kolom A dst., lembar lain utuh', () => {
  const { ctx, tab } = mk(); L.setCell(tab, tab.rows[0].id, tab.cols[0].id, { v: 'Judul' }); L.setCell(tab, tab.rows[2].id, tab.cols[1].id, { v: 5 });
  const r = B.appendRows(ctx, 's1', tab.id, [['Kopi', '15000'], ['Roti', '8000']], 99);
  assert.equal(r.error, undefined); assert.equal(r.start, 4); assert.equal(val(tab, 3, 0), 'Kopi'); assert.equal(val(tab, 3, 1), 15000); assert.equal(val(tab, 4, 0), 'Roti');
  assert.equal(val(tab, 0, 0), 'Judul'); assert.equal(val(tab, 2, 1), 5); assert.equal(ctx.data.sheets.s1.at, 99); assert.equal(ctx.persists, 1); assert.equal(tab.rows.length, 30);
});
test('appendRows: baris bergaya-kosong tidak dihitung terisi; tab kosong mulai baris 1', () => {
  const { ctx, tab } = mk(); L.setCell(tab, tab.rows[5].id, tab.cols[0].id, { s: { b: true } });
  const r = B.appendRows(ctx, 's1', tab.id, [['A']]); assert.equal(r.start, 1); assert.equal(val(tab, 0, 0), 'A');
});
test('appendRows: menambah baris bila kurang; penuh = galat tanpa perubahan', () => {
  const { ctx, tab } = mk(); L.addRows(tab, 470); L.setCell(tab, tab.rows[28].id, tab.cols[0].id, { v: 'x' });
  tab.rows.length = 29; const r = B.appendRows(ctx, 's1', tab.id, Array.from({ length: 3 }, (_, i) => ['b' + i])); assert.equal(r.start, 30); assert.equal(tab.rows.length, 32); assert.equal(r.addedIds.length, 3);
  const full = mk(); full.tab.rows.length = 0; for (let i = 0; i < L.MAX_ROWS; i++) full.tab.rows.push({ id: 'r' + (i + 1), cells: { cA: { v: i } } });
  const before = JSON.stringify(full.ctx.data.sheets); const e = B.appendRows(full.ctx, 's1', full.tab.id, [['z']]); assert.equal(e.error, 'full'); assert.equal(JSON.stringify(full.ctx.data.sheets), before); assert.equal(full.ctx.persists, 0);
});
test('appendRows: sheet/tab tak ada, data kosong = invalid; tidak ada yang berubah', () => {
  const { ctx, tab } = mk(); const before = JSON.stringify(ctx.data);
  for (const a of [['zz', tab.id, [['a']]], ['s1', 'zz', [['a']]], ['s1', tab.id, []], ['s1', tab.id, [['  ']]], ['s1', tab.id, 'x']]) assert.equal(B.appendRows(ctx, ...a).error, 'invalid');
  assert.equal(JSON.stringify(ctx.data), before); assert.equal(ctx.persists, 0);
});
test('appendRows: lembar kelewat besar ditolak dan dikembalikan utuh', () => {
  const { ctx, s, tab } = mk(); const big = 'x'.repeat(1900); let k = 0;
  while (L.sheetBytes(s) < L.MAX_BYTES - 4000) { const r = tab.rows[Math.floor(k / 20) % 30]; r.cells['c' + L.colLabel(k % 20)] = { v: big + k }; k++; if (k > 400) break; }
  assert.ok(L.fitsLimit(s)); const before = JSON.stringify(s); const e = B.appendRows(ctx, 's1', tab.id, [[big, big, big]]);
  assert.equal(e.error, 'big'); assert.equal(JSON.stringify(s), before); assert.equal(ctx.persists, 0);
});
test('Urungkan: sel dipulihkan dan baris tambahan dibuang', () => {
  const { ctx, tab } = mk(); tab.rows.length = 2; L.setCell(tab, tab.rows[0].id, tab.cols[0].id, { v: 'a' });
  const before = JSON.stringify(ctx.data.sheets.s1.tabs[0].rows); const r = B.appendRows(ctx, 's1', tab.id, [['p'], ['q'], ['r']]); assert.equal(tab.rows.length, 4);
  assert.equal(B.restoreRows(ctx, r), true); assert.equal(JSON.stringify(ctx.data.sheets.s1.tabs[0].rows), before);
  const gone = B.restoreRows({ data: { sheets: {} }, persist() {} }, r); assert.equal(gone, false);
});
test('lebih dari 26 kolom / kolom terbatas: sel kelebihan dilewati dan dilaporkan', () => {
  const { ctx, tab } = mk(); tab.cols.length = 2; const r = B.appendRows(ctx, 's1', tab.id, [['a', 'b', 'c', 'd']]);
  assert.equal(r.dropped, 2); assert.equal(val(tab, 0, 1), 'b'); assert.match(B.appendSummary(r, 'Pengeluaran'), /mulai baris 1.*2 sel/);
});
test('sheetChoices: terbaru dulu, bentuk rusak diabaikan; catatan/tugas/Privat tidak tersentuh', () => {
  const { ctx } = mk(); ctx.data.sheets.s2 = { ...L.newSheet({ id: 's2', name: 'Baru', now: 5 }) }; ctx.data.sheets.bad = { id: 'bad' };
  assert.deepEqual(B.sheetChoices(ctx).map((x) => x.id), ['s2', 's1']); assert.deepEqual(B.sheetChoices({ data: {} }), []); assert.deepEqual(B.sheetChoices(null), []);
  const b = JSON.stringify([ctx.data.notes, ctx.data.priv, ctx.data.tasks, ctx.data.habits, ctx.data.trash]); B.appendRows(ctx, 's2', ctx.data.sheets.s2.tabs[0].id, [['x']]); assert.equal(JSON.stringify([ctx.data.notes, ctx.data.priv, ctx.data.tasks, ctx.data.habits, ctx.data.trash]), b);
});
test('obrolan.js + baris.js: dialog lewat centang + konfirmasi + Urungkan; Batal tetap tombol .line pertama; tanpa HTML mentah/Privat', () => {
  const o = src('src/js/ai/obrolan.js'), b = src('src/js/ai/baris.js');
  assert.match(o, /'Tambah ke lembar kerja'/); assert.match(o, /appendRows\(ctx, x\.id/); assert.match(o, /restoreRows\(ctx, res\)/); assert.ok(o.indexOf('batal, tambah,') > 0); assert.doesNotMatch(o, /innerHTML/);
  assert.doesNotMatch(b, /innerHTML|\.priv\b|\.trash\b|\.notes\b|\.tasks\b|\.habits|localStorage|document\.|fetch\(/);
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\//); assert.doesNotMatch(src('src/js/notes.js'), /from '\.\/ai\//);
});
