// Rev 303c / v0.3.121: DESAIN kotak centang di sel lembar kerja (kotak bersudut bulat digambar CSS, centang dari --onac; terang + gelap ikut variabel tema). SCHEMA 22 dan JS awal tidak berubah.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
const i303 = css.indexOf('/* Rev 303c'), blok = css.slice(i303);
test('gambar sel: sel kotak tanpa glyph teks, tetap role/aria-checked/data-box/ha-center', () => {
  const i = ui.indexOf("if (vck && vck.k === 'box' && !fxd)"); assert.ok(i > 0); const seg = ui.slice(i, i + 700);
  assert.match(seg, /el\.textContent = ''/); assert.doesNotMatch(seg, /u2611|u2610|fontSize/); assert.match(seg, /dataset\.box = on \? '1' : '0'/); assert.match(seg, /role', 'checkbox'/); assert.match(seg, /aria-checked/);
});
test('CSS: kotak 22px radius 8, centang dari pseudo-elemen, hanya variabel tema (tanpa warna heks, tanpa blur)', () => {
  assert.ok(i303 > 0); assert.match(blok, /\.lz-c\[data-box\]::before\{[^}]*width:22px;height:22px;border-radius:8px/); assert.match(blok, /\[data-box="1"\]::after\{[^}]*background:var\(--onac\);-webkit-mask:url\("data:image\/svg\+xml/); assert.doesNotMatch(blok, /rotate\(/);
  assert.match(blok, /\[data-box="1"\]::before\{[^}]*var\(--ac\)/); assert.doesNotMatch(blok, /#[0-9a-fA-F]{3,8}\b|backdrop-filter|blur\(/);
});
test('CSS: animasi ketuk hanya lewat kelas bxp dan mati bila prefers-reduced-motion; kurung seimbang', () => {
  assert.match(blok, /\.lz-c\.bxp::before\{animation:bxp/); assert.match(blok, /@keyframes bxp/); assert.match(blok, /prefers-reduced-motion:reduce\)\{[^@]*bxp/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('ketuk: toggleBox menambah kelas bxp sebentar pada sel yang diketuk dan tetap SATU langkah Urungkan', () => {
  const i = ui.indexOf('const toggleBox = '); const seg = ui.slice(i, i + 1500);
  assert.match(seg, /classList\.add\('bxp'\)/); assert.match(seg, /classList\.remove\('bxp'\)/); assert.equal((seg.match(/hist\.push\(snap\)/g) || []).length, 1);
});
test('anggaran: batas CSS resmi 270 KB (audit-ukuran; Rev 383), CSS di bawahnya; SCHEMA 22 dan versi 0.3.121 tetap; JS awal tidak mengimpor lembar-kotak', () => {
  assert.match(src('tools/audit-ukuran.mjs'), /cssMaks: 270 \* 1024/); assert.ok(Buffer.byteLength(css) < 270 * 1024, String(Buffer.byteLength(css)));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22/); assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  for (const f of ['main', 'startup', 'storage', 'lembar-pintu', 'lembar']) assert.ok(!src('src/js/' + f + '.js').includes('lembar-kotak'), f);
});
test('alat audit tools/audit_kotak.py memeriksa ukuran kotak, kontras centang >= 3:1 dan kotak kosong tanpa centang', () => {
  const a = src('tools/audit_kotak.py'); for (const k of ['22px', 'kontras', '>= 3', '::after', 'data-box'.slice(0, 4)]) assert.ok(a.includes(k), k);
});
test('dokumen: entri Rev 303c paling atas di PROMPT dan RIWAYAT, UJI_HP bagian AJ, README menyebut 303c, tes terdaftar', () => {
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 303c / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('**Rev 303c / v0.3.121'));
  assert.match(src('UJI_HP_RILIS.md'), /## AJ\. Desain kotak centang sel \(Rev 303c\)/); const r = src('README.md'); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */); assert.match(r, /Rev 303c/); assert.match(r, /bukan\*\* bukti APK/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev303c\.test\.mjs/);
});
console.log('rev303c: ' + n + ' tes');
