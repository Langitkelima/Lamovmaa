// Rev 211 / v0.3.121: (1) model Gemini 3.8 DIHAPUS, diganti gemini-3.5-flash (bawaan Worker + pilihan di aplikasi); model lama yang masih tersimpan di HP kembali ke bawaan.
// (2) Langkah 2 rencana desain: Setelan > KELIMAA AI bergaya STIKER TEBAL (logo bintang + judul KELIMAA AI kapital, sakelar MATI|MENYALA, jalur 4 tombol, stiker biru pastel). Tanpa perubahan alur data.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
import * as S from '../src/js/ai/sambungan.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mem = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };

test('model: tidak ada lagi gemini-3.8 di kode, tes, dan panduan; bawaan = gemini-3.5-flash; cadangan tetap 3.5-flash-lite', () => {
  for (const f of ['backend/cloudflare/worker.mjs', 'backend/cloudflare/PANDUAN_WORKER.md', 'src/js/ai/layar.js']) assert.doesNotMatch(src(f), /3\.8-flash/, f);
  assert.match(src('backend/cloudflare/worker.mjs'), /model: 'gemini-3\.5-flash' \}/); assert.match(src('backend/cloudflare/worker.mjs'), /FALLBACK = \{ gemini: 'gemini-3\.5-flash-lite' \}/);
  assert.deepEqual(S.MODEL_PRESETS.gemini, ['gemini-3.5-flash', 'gemini-3.5-flash-lite']);
});
test('model lama gemini-3.8-flash yang tersimpan di HP kembali ke bawaan Worker; model lain tidak disentuh', () => {
  const st = mem();
  st.setItem(S.CFG_KEY, JSON.stringify({ on: true, provider: 'gemini', model: 'gemini-3.8-flash', limit: 150 }));
  assert.deepEqual(S.loadCfg(st), { on: true, provider: 'gemini', model: '', limit: 150 });
  assert.deepEqual(S.chatOpts(S.loadCfg(st)), { provider: 'gemini', model: '', limit: 150 });
  st.setItem(S.CFG_KEY, JSON.stringify({ on: true, provider: 'gemini', model: 'gemini-3.5-flash', limit: 0 }));
  assert.equal(S.loadCfg(st).model, 'gemini-3.5-flash');
  st.setItem(S.CFG_KEY, JSON.stringify({ on: true, provider: 'sakelar', model: 'deepseek/deepseek-v4-flash', limit: 100 }));
  assert.equal(S.loadCfg(st).model, 'deepseek/deepseek-v4-flash');
});
test('Worker: tanpa model dari aplikasi, Gemini memakai gemini-3.5-flash', async () => {
  const calls = []; const real = globalThis.fetch;
  globalThis.fetch = async (u, o) => { calls.push(JSON.parse(o.body).model); return { ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'Baik!' } }], usage: {} }) }; };
  try {
    const env = { PASS_RAMA: 'rama-secret-12', GEMINI_KEY: 'AIza-FAKE-0123456789' };
    const r = await W._t.handle(new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', provider: 'gemini', limit: 0, messages: [{ role: 'user', content: 'Halo' }] }) }), env, Date.UTC(2026, 10, 12, 5));
    const j = await r.json(); assert.equal(j.ok, true); assert.equal(j.model, 'gemini-3.5-flash'); assert.deepEqual(calls, ['gemini-3.5-flash']);
  } finally { globalThis.fetch = real; }
});
test('layar Stiker Tebal: logo bintang + judul KELIMAA AI, sakelar role=switch MATI|MENYALA, jalur 4 tombol, stiker, tanpa innerHTML; fungsi lama tetap', () => {
  const ly = src('src/js/ai/layar.js');
  for (const k of ["class: 'kai-logo'", "ico(PATH.star)", "'KELIMAA '", "class: 'kai-sw'", "role: 'switch'", "'MATI'", "'MENYALA'", "class: 'kai-og'", "['sakelar', 'relay', 'gemini', '']", "stk('JALUR')", "stk('MODEL')", "stk('BATAS')", "stk('SAMBUNGAN')", "'Buka chat'", "'Tes sambungan'", "'Simpan sambungan'", "'Putuskan sambungan'", 'saveCfg({ ...loadCfg(), on })', "ui.moreView = 'aichat'"]) assert.ok(ly.includes(k), k);
  assert.doesNotMatch(ly, /innerHTML|insertAdjacentHTML|console\./); assert.doesNotMatch(ly, /provSel|tpalarm/);
});
test('CSS Stiker Tebal: terang + gelap (media dan data-theme), warna teks/isian dari variabel tema (terbaca di gelap), tanpa blur baru', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 211'); assert.ok(i > 0); const r = css.slice(i);
  assert.match(r, /prefers-color-scheme: dark\)\{:root:not\(\[data-theme="light"\]\) \.kai\{/); assert.match(r, /:root\[data-theme="dark"\] \.kai\{/);
  assert.match(r, /\.kai \.in\{[^}]*color:var\(--ink\)/); assert.match(r, /\.kai-stk\{[^}]*rotate\(-2deg\)/); assert.match(r, /\.kai-sw\[aria-checked="true"\] span:last-child/);
  assert.doesNotMatch(r, /backdrop-filter|blur\(/);
});
test('versi 0.3.121, SCHEMA 18 tetap, tes terdaftar', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev211\.test\.mjs/);
});
