// Rev 174: tampilan baru Setelan > Lembar kerja dan Setelan > Label catatan (hanya tampilan; fungsi tidak berubah).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const set = readFileSync(new URL('../src/js/settings.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const rev = css.slice(css.indexOf('Rev 174:'));

test('Rev 174: kartu lembar kerja = tombol .lzc dengan ikon, nama satu baris, chip tab dan status pakai', () => {
  assert.match(set, /class: 'lzc tn-'/);
  assert.match(set, /'dipakai di ' \+ use\[id\] \+ ' catatan' : 'tidak dipakai'/);
  assert.match(set, /class: 'lzhero'/); assert.match(set, /class: 'lzbar'/);
  assert.match(set, /'Hapus ' \+ unused\.length \+ ' lembar tidak terpakai'/);
});
test('Rev 174: fungsi lembar kerja tidak berubah (buka, buat, hapus tidak terpakai, Kembali)', () => {
  assert.match(set, /onclick: \(\) => open\(id\)/); assert.match(set, /onclick: create/); assert.match(set, /onclick: clean/);
  assert.match(set, /LZ\.MAX_SHEETS/);
});
test('Rev 174: baris label tetap punya pegangan geser, input nama, hitung, hapus', () => {
  assert.match(set, /class: 'row lbrow tn-'/); assert.match(set, /class: 'ghost lbh'/); assert.match(set, /class: 'ghost lbx'/);
  assert.match(set, /startDrag\(ev, l, rowEl, hb\)/); assert.match(set, /class: 'cpr lbadd'/);
});
test('Rev 174: CSS memakai variabel tema (tanpa warna heks tetap) dan dibatasi ke sub-layar lembar/labels', () => {
  assert.ok(rev.length > 500);
  assert.doesNotMatch(rev, /#[0-9a-fA-F]{3,8}\b/);
  assert.match(rev, /\[data-sub="lembar"\] \.lzc/); assert.match(rev, /\[data-sub="labels"\] \.row\.lbrow/);
  assert.match(rev, /prefers-reduced-motion/);
});
test('Rev 174: versi 0.3.121, SCHEMA 18', () => {
  assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /"version": "0\.3\.121"/);
  assert.match(set, /v0\.3\.121/);
});
