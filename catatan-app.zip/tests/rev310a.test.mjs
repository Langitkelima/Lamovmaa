// Rev 310a / v0.3.121: ikon rumah A1 (Ke aplikasi) di bawah roda gigi chat, ikon tiga garis B1 di header catatan, satu tombol chat di Setelan.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('chat: Ke aplikasi jadi ikon rumah di bawah roda gigi; tombol teks di laci dihapus', () => {
  const ob = src('src/js/ai/obrolan.js'), css = src('src/css/styles.css');
  assert.match(ob, /class: 'kc-rt'/); assert.match(ob, /class: 'kc-ib kc-home', 'aria-label': 'Ke aplikasi', onclick: keluar \}, icoBeranda\(\)/);
  assert.ok(ob.indexOf("'Pengaturan AI'") < ob.indexOf("'Ke aplikasi'"), 'roda gigi dulu, rumah di bawahnya');
  assert.doesNotMatch(ob, /\}, 'Ke aplikasi'\)/); assert.match(ob, /class: 'f'/);
  assert.ok(css.includes('.kc-home{position:absolute;top:50px;right:0}') && css.includes('.kc-ib .f{fill:var(--ac);stroke:var(--ac)'));
  assert.doesNotMatch(src('src/js/ui.js'), /icoBeranda/, 'ikon rumah di modul malas, bukan di graf buka');
});
test('catatan: tombol menu memakai tiga garis yang jadi silang saat terbuka (bukan panah bawah)', () => {
  const nt = src('src/js/notes.js'), ui = src('src/js/ui.js'), css = src('src/css/styles.css');
  assert.match(nt, /class: 'ghost hmore'[^\n]*icoMenu\(\)/); assert.doesNotMatch(nt, /class: 'ghost hmore'[^\n]*chevDown/);
  assert.match(ui, /export function icoMenu\(\)/); assert.ok(ui.includes("'mh' + (i + 1)"));
  for (const k of ['[aria-expanded=true] .mh1{transform:translateY(5px) rotate(45deg)}', '[aria-expanded=true] .mh3{transform:translateY(-5px) rotate(-45deg)}', '[aria-expanded=true] .mh2{opacity:0;transform:scaleX(0)}', '.fsh .ghost.hmore svg line{']) assert.ok(css.includes(k), k);
  assert.ok(css.includes('.fsh .ghost.hmore svg line{transition:none}'), 'reduced motion');
});
test('Setelan AI: Buka chat dan Kembali ke chat disatukan jadi satu tombol; Kembali ke layar utama tetap', () => {
  const ly = src('src/js/ai/layar.js');
  assert.equal((ly.match(/'Buka chat'/g) || []).length, 1); assert.equal((ly.match(/'Kembali ke chat'/g) || []).length, 1);
  assert.match(ly, /ui\.tab === 'ai' && ui\.aiFrom === 'chat' \? 'Kembali ke chat' : 'Buka chat'/);
  assert.match(ly, /ui\.tab === 'ai' \? null : h\('button', \{ type: 'button', class: 'btn line', onclick: toMain \}, 'Kembali'\)/);
  assert.match(ly, /t(?:Ok|Warn|Err|Info)\('Nyalakan Kelimaa AI dulu\.'\); return; \} ui\.aiFrom = ''; ui\.moreView = 'aichat'/);
});
