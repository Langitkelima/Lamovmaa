// Rev 242 / Tahap 9c: token masuk/keluar per bulan di Worker (hanya bila batas bulanan aktif) + tampilan di aplikasi. Fetch PALSU; KV tiruan. Bukan bukti dari Cloudflare/penyedia nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
import * as K from '../src/js/ai/sambungan.js';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = (o = {}) => { const m = new Map(), puts = []; return { m, puts, get: async (k) => { if (o.getFail) throw new Error('kv'); return m.has(k) ? m.get(k) : null; }, put: async (k, v) => { puts.push(k); if (o.putFail && k.startsWith(o.putFail)) throw new Error('kv'); m.set(k, v); } }; };
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), GEMINI_KEY: 'gm-FAKE-0123456789-tes', ...x });
const NOW = Date.UTC(2026, 10, 12, 5, 0, 0), MK = 'mon:rama:2026-11';
const mkReq = (o = {}) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'research', messages: [{ role: 'user', content: 'Tes?' }], ...o }) });
const GEM = (p, c) => ({ candidates: [{ content: { role: 'model', parts: [{ text: 'Jawab.' }] }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: p, candidatesTokenCount: c } });
const OAI = (p, c) => ({ choices: [{ message: { content: 'Halo' }, finish_reason: 'stop' }], usage: { prompt_tokens: p, completion_tokens: c } });
async function run(env, o, body, now = NOW) { const orig = globalThis.fetch; globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => body }); try { const r = await T.handle(mkReq(o), env, now); return { status: r.status, j: await r.json() }; } finally { globalThis.fetch = orig; } }
test('parseMon: format lama (hitungan) dan baru (hitungan|masuk|keluar); rusak = nol', () => {
  assert.deepEqual(T.parseMon('5'), { n: 5, tin: 0, tout: 0 }); assert.deepEqual(T.parseMon('5|10|20'), { n: 5, tin: 10, tout: 20 });
  for (const v of [null, '', 'abc', '-1|x|-2']) assert.deepEqual(T.parseMon(v), { n: 0, tin: 0, tout: 0 }, String(v));
});
test('riset dengan batas bulanan: token dijumlah di KV (kunci sama), jawaban membawa monthTokens, hitungan tidak rusak', async () => {
  const e = env0(), a = await run(e, { monthLimit: 100 }, GEM(30, 12)); assert.equal(a.status, 200);
  assert.deepEqual(a.j.monthTokens, { in: 30, out: 12 }); assert.equal(a.j.monthUsed, 1); assert.equal(e.KV.m.get(MK), '1|30|12');
  const b = await run(e, { monthLimit: 100 }, GEM(5, 8)); assert.deepEqual(b.j.monthTokens, { in: 35, out: 20 }); assert.equal(b.j.monthUsed, 2); assert.equal(e.KV.m.get(MK), '2|35|20');
});
test('chat (jalur OpenAI) dengan batas bulanan: token dari usage penyedia ikut dijumlah; hitungan permintaan berikutnya mempertahankan token', async () => {
  const e = env0(), a = await run(e, { action: 'chat', task: 'chat.general', monthLimit: 100 }, OAI(7, 9)); assert.equal(a.status, 200); assert.deepEqual(a.j.monthTokens, { in: 7, out: 9 });
  const b = await run(e, { action: 'chat', task: 'chat.general', monthLimit: 100 }, OAI(1, 1)); assert.equal(b.j.monthUsed, 2); assert.deepEqual(b.j.monthTokens, { in: 8, out: 10 }); assert.equal(e.KV.m.get(MK), '2|8|10');
});
test('TANPA batas bulanan: tidak ada baca/tulis KV bulanan dan tidak ada monthTokens (bawaan tidak berubah)', async () => {
  const e = env0(), r = await run(e, {}, GEM(30, 12)); assert.equal(r.status, 200); assert.equal('monthTokens' in r.j, false);
  assert.equal(e.KV.puts.some((k) => k.startsWith('mon:')), false); assert.equal(e.KV.m.has(MK), false);
});
test('usage nol atau hilang: tidak menulis token (hemat KV) dan jawaban tetap sukses', async () => {
  const e = env0(), r = await run(e, { monthLimit: 100 }, GEM(0, 0)); assert.equal(r.status, 200); assert.equal('monthTokens' in r.j, false); assert.equal(e.KV.m.get(MK), '1');
  assert.equal(await T.noteMonthTokens(e, 'rama', NOW, undefined), null); assert.equal(await T.noteMonthTokens(e, 'rama', NOW, { in: -5, out: 'x' }), null);
});
test('gagal TULIS token = diabaikan: jawaban sukses, hitungan bulan sebelumnya utuh; tanpa KV = null', async () => {
  const e = env0({ KV: kv() }); const orig = e.KV.put; let n = 0; e.KV.put = async (k, v) => { if (k.startsWith('mon:') && ++n === 2) throw new Error('kv'); return orig(k, v); };
  const r = await run(e, { monthLimit: 100 }, GEM(3, 4)); assert.equal(r.status, 200); assert.equal('monthTokens' in r.j, false); assert.equal(e.KV.m.get(MK), '1');
  assert.equal(await T.noteMonthTokens({}, 'rama', NOW, { in: 1, out: 1 }), null);
});
test('batas bulanan tercapai tetap menolak SEBELUM penyedia dipanggil dan tidak menyentuh token; nilai format baru terbaca sebagai hitungan', async () => {
  const e = env0(); e.KV.m.set(MK, '3|100|200'); const r = await run(e, { monthLimit: 3 }, GEM(1, 1)); assert.equal(r.status, 429); assert.match(r.j.error, /Batas bulanan tercapai \(3\/3\)/); assert.equal(e.KV.m.get(MK), '3|100|200');
  assert.equal(await T.monthOf(e, 'rama', NOW), 3); assert.deepEqual(await T.monthTokensOf(e, 'rama', NOW), { in: 100, out: 200 });
});
test('whoami/usage mengembalikan monthTokens (null bila belum ada); angka lama tetap sama', async () => {
  const e = env0(); e.KV.m.set(MK, '7'); const a = await T.handle(mkReq({ action: 'usage' }), e, NOW), aj = await a.json(); assert.equal(aj.monthUsed, 7); assert.equal(aj.monthTokens, null);
  e.KV.m.set(MK, '7|40|60'); const b = await (await T.handle(mkReq({ action: 'whoami' }), e, NOW)).json(); assert.equal(b.monthUsed, 7); assert.deepEqual(b.monthTokens, { in: 40, out: 60 });
});
test('aplikasi: cleanTokens/tokensText defensif; hasil chat/riset dan Tes sambungan membawa token; Worker lama tanpa token tetap rapi', async () => {
  assert.equal(K.cleanTokens(null), null); assert.equal(K.cleanTokens({ in: 'a', out: 1 }), null); assert.equal(K.cleanTokens({ in: 0, out: 0 }), null); assert.deepEqual(K.cleanTokens({ in: 5.9, out: 2 }), { in: 5, out: 2 });
  assert.equal(K.tokensText(undefined), ''); assert.match(K.tokensText({ in: 1200, out: 30 }), /^token bulan ini: masuk .*200, keluar 30$/);
  const conn = { url: 'https://kelimaa-ai.akun.workers.dev', key: 'rama-secret-12' };
  const ok = (o) => async () => ({ status: 200, text: JSON.stringify({ ok: true, text: 'J', model: 'm', provider: 'gemini', used: 1, limit: 100, monthUsed: 1, monthLimit: 10, ...o }) });
  const a = await K.kirimChat(conn, [{ role: 'user', content: 'a' }], ok({ monthTokens: { in: 4, out: 6 } }), {}); assert.deepEqual(a.monthTokens, { in: 4, out: 6 });
  const b = await K.kirimRiset(conn, [{ role: 'user', content: 'a' }], ok({ sources: [], monthTokens: { in: 9, out: 1 } }), {}); assert.deepEqual(b.monthTokens, { in: 9, out: 1 });
  const c = await K.kirimChat(conn, [{ role: 'user', content: 'a' }], ok({}), {}); assert.equal('monthTokens' in c, false);
  const mk = (o) => async (r) => (r.method === 'GET' ? { status: 200, text: '{"ok":true,"app":"KELIMAA AI","v":1}' } : { status: 200, text: JSON.stringify({ ok: true, me: 'rama', limit: 100, used: 4, kv: true, ...o }) });
  const t = await K.testConnection(conn, mk({ monthUsed: 12, monthTokens: { in: 50, out: 70 } })); assert.deepEqual(t.info.monthTokens, { in: 50, out: 70 }); assert.match(t.steps[2].msg, /bulan ini: 12; token bulan ini: masuk 50, keluar 70/);
  const u = await K.testConnection(conn, mk({ monthUsed: 12 })); assert.equal(u.info.monthTokens, null); assert.doesNotMatch(u.steps[2].msg, /token/);
});
test('obrolan memakai tokensText; versi 0.3.121; tes terdaftar; panduan Worker menyebut token', () => {
  assert.match(src('src/js/ai/obrolan.js'), /tokensText\(res\.monthTokens\)/); assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev242\.test\.mjs/);
  assert.match(src('backend/cloudflare/PANDUAN_WORKER.md'), /monthTokens/);
});
