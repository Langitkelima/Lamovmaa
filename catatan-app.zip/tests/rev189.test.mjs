// Rev 184c-1 / U10e-3: tinggi baris bebas di pulau pratinjau catatan + model ekspor. Berkas rev189 = Rev 184c-1.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as P from '../src/js/lembar-pulau.js';
import * as L from '../src/js/lembar.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet({ name: 'T' }); const t = sh.tabs[0]; L.setCell(t, 'r1', 'cA', { v: 'a' }); L.setCell(t, 'r2', 'cA', { v: 'b' }); L.setCell(t, 'r3', 'cA', { v: 'c' }); return { sh, t }; };

test('islandRowPx: skala 0.8, batas 20..120, tak sah = 0', () => {
  assert.equal(P.islandRowPx(100), 80); assert.equal(P.islandRowPx(16), 20); assert.equal(P.islandRowPx(3000), 120); assert.equal(P.islandRowPx(0), 0); assert.equal(P.islandRowPx(NaN), 0); assert.equal(P.islandRowPx(undefined), 0);
});
test('rowHeightsOf: hanya bila ada baris ber-h; baris bawaan = 0', () => {
  const { t } = mk(); assert.equal(P.rowHeightsOf(t, 3), undefined);
  L.setRowHeight(t, t.rows[1].id, 120); assert.deepEqual(P.rowHeightsOf(t, 3), [0, 120, 0]); assert.deepEqual(P.rowHeightsOf(t, 1), undefined);
});
test('islandModel dan exportModel: rowH ikut hanya bila dipakai (data lama persis sama)', () => {
  const { sh, t } = mk(); assert.equal('rowH' in P.islandModel(sh), false); assert.equal('rowH' in P.exportModel(sh), false);
  L.setRowHeight(t, t.rows[0].id, 90); assert.deepEqual(P.islandModel(sh).rowH, [90, 0, 0]); assert.deepEqual(P.exportModel(sh).rowH, [90, 0, 0]);
  assert.equal(P.exportModel(sh, { rows: 2, cols: 3 }).rowH.length, 2);
});
test('kabel render + CSS: kelas kh/kt dan variabel --ksh', () => {
  const s = src('src/js/lembar-pulau.js'); assert.match(s, /classList\.add\('kh'\)/); assert.match(s, /m\.rowH\[i\] > L\.ROW_H_DEF/); assert.match(s, /setProperty\('--ksh'/);
  const c = src('src/css/styles.css'); assert.match(c, /\.ks-row\.kh \.ks-c\{min-height:var\(--ksh\)/); assert.match(c, /\.ks-row\.kh\.kt \.ks-c\{white-space:normal/);
});
