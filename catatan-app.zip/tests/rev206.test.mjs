// Rev 201 / v0.3.121: Kelimaa AI Tahap 1b = layar Setelan > Kelimaa AI (alamat Worker + passcode + Tes sambungan + sakelar). Berkas rev206 = Rev 201.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
import * as S from '../src/js/ai/sambungan.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const store = () => { const m = new Map(); return { m, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { m.set(k, String(v)); }, removeItem: (k) => { m.delete(k); } }; };
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const URL1 = 'https://kelimaa-ai.dhani5081.workers.dev';
const PASS = 'rama-secret-12';

test('cleanUrl: hanya alamat workers.dev (nama.akun.workers.dev); query, garis miring, huruf besar dirapikan', () => {
  assert.deepEqual(S.cleanUrl(URL1), { ok: true, value: URL1 });
  assert.equal(S.cleanUrl('  HTTPS://Kelimaa-AI.Dhani5081.workers.dev/?ping=1#x  ').value, URL1);
  assert.equal(S.cleanUrl(URL1 + '///').value, URL1);
  for (const bad of ['', '   ', 'http://kelimaa-ai.dhani5081.workers.dev', 'https://example.com', 'https://workers.dev', 'https://kelimaa-ai.workers.dev.evil.com',
    'https://kelimaa-ai.dhani5081.workers.dev@evil.com', 'https://evil.com/kelimaa-ai.dhani5081.workers.dev', 'https://kelimaa-ai.dhani5081.workers.dev/path', 'https://a.b.c.workers.dev', 'javascript:alert(1)', null, undefined]) {
    assert.equal(S.cleanUrl(bad).ok, false, String(bad));
  }
});
test('cleanPass: 8 sampai 200 karakter, tanpa karakter kontrol; kosong/pendek ditolak dengan pesan jelas', () => {
  assert.equal(S.cleanPass(' abcdefgh ').value, 'abcdefgh');
  assert.equal(S.cleanPass('').ok, false); assert.equal(S.cleanPass('abcdefg').ok, false); assert.match(S.cleanPass('abcdefg').msg, /8 karakter/);
  assert.equal(S.cleanPass('a'.repeat(201)).ok, false); assert.equal(S.cleanPass('abcdefg\u0007hij').ok, false); assert.equal(S.cleanPass('a'.repeat(200)).ok, true);
});
test('simpan/muat sambungan: bolak-balik, data rusak = null, hapus; kunci terpisah dari data aplikasi', () => {
  const st = store(); assert.equal(S.loadConn(st), null);
  assert.equal(S.saveConn({ url: URL1, key: PASS, me: 'rama', testedAt: 5 }, st).ok, true);
  assert.deepEqual(S.loadConn(st), { url: URL1, key: PASS, me: 'rama', testedAt: 5 });
  assert.equal(S.saveConn({ url: 'https://x.com', key: PASS }, st).ok, false); assert.equal(S.saveConn({ url: URL1, key: 'pendek' }, st).ok, false);
  st.setItem(S.CONN_KEY, '{rusak'); assert.equal(S.loadConn(st), null);
  st.setItem(S.CONN_KEY, JSON.stringify({ url: 'https://evil.com', key: PASS })); assert.equal(S.loadConn(st), null);
  S.saveConn({ url: URL1, key: PASS }, st); S.clearConn(st); assert.equal(st.m.size, 0);
  assert.equal(S.CONN_KEY, 'kelimaa_ai_conn'); assert.notEqual(S.CONN_KEY, 'catatan_app_data');
});
test('sakelar BAWAAN MATI; hanya true persis yang menyalakan; data rusak = mati', () => {
  const st = store(); assert.equal(S.loadCfg(st).on, false);
  S.saveCfg({ on: true }, st); assert.equal(S.loadCfg(st).on, true);
  S.saveCfg({ on: 'ya' }, st); assert.equal(S.loadCfg(st).on, true); // !!'ya' disimpan sebagai true oleh saveCfg
  st.setItem(S.CFG_KEY, JSON.stringify({ on: 'ya' })); assert.equal(S.loadCfg(st).on, false);
  st.setItem(S.CFG_KEY, 'bukan json'); assert.equal(S.loadCfg(st).on, false);
  S.clearCfg(st); assert.equal(st.m.size, 0);
});

// Penghubung ke Worker ASLI (kode Rev 200) tanpa jaringan: permintaan diteruskan ke W.fetch.
const lewatWorker = (env, log = []) => async ({ method, url, body }) => {
  log.push({ method, url, body });
  const r = await W.fetch(new Request(url, { method, body }), env);
  return { status: r.status, text: await r.text() };
};
test('tes sambungan ke Worker asli: passcode benar -> ping, whoami, info; passcode TIDAK ada di alamat GET', async () => {
  const log = []; const env = { PASS_RAMA: PASS, PASS_DESY: 'desy-secret-34', KV: kv() };
  const r = await S.testConnection({ url: URL1, key: PASS }, lewatWorker(env, log));
  assert.equal(r.ok, true); assert.equal(r.me, 'rama'); assert.deepEqual(r.steps.map((x) => x.id), ['ping', 'whoami', 'info']); assert.ok(r.steps.every((x) => x.ok));
  assert.deepEqual(r.info, { limit: 100, used: 0, kv: true, monthUsed: 0, monthTokens: null }); assert.match(r.steps[1].msg, /rama/); assert.match(r.steps[2].msg, /Terpakai hari ini: 0; bulan ini: 0.*bawaan Worker 100/);
  assert.equal(log[0].method, 'GET'); assert.ok(log[0].url.endsWith('/?ping=1') && !log[0].url.includes(PASS)); assert.equal(log[0].body, undefined);
  assert.equal(log[1].method, 'POST'); assert.deepEqual(JSON.parse(log[1].body), { key: PASS, action: 'whoami' });
  assert.equal((await S.testConnection({ url: URL1, key: 'desy-secret-34' }, lewatWorker(env))).me, 'desy');
});
test('tanpa KV: tetap berhasil tetapi ada catatan jujur (belum ada pembatas, permintaan AI ditolak)', async () => {
  const r = await S.testConnection({ url: URL1, key: PASS }, lewatWorker({ PASS_RAMA: PASS }));
  assert.equal(r.ok, true); assert.equal(r.info.kv, false); const n = r.steps.find((x) => x.id === 'info'); assert.equal(n.note, true); assert.match(n.msg, /KV belum terpasang/);
});
test('passcode salah = 401 dengan pesan awam; tidak menyebut passcode asli; langkah info tidak muncul', async () => {
  const r = await S.testConnection({ url: URL1, key: 'passcode-salah-99' }, lewatWorker({ PASS_RAMA: PASS, KV: kv() }));
  assert.equal(r.ok, false); assert.equal(r.me, ''); assert.deepEqual(r.steps.map((x) => x.id), ['ping', 'whoami']); assert.equal(r.steps[1].ok, false);
  assert.match(r.steps[1].msg, /Passcode salah/); assert.ok(!JSON.stringify(r).includes(PASS));
});
test('Worker tanpa Secret = 503 (Tahap 3 belum jalan); pembatas 429 dijelaskan', async () => {
  const r = await S.testConnection({ url: URL1, key: PASS }, lewatWorker({ KV: kv() }));
  assert.equal(r.ok, false); assert.match(r.steps[1].msg, /belum punya passcode/); assert.match(r.steps[1].msg, /Deploy/);
  assert.match(S.explainWorkerError(429, 'x'), /satu jam/); assert.match(S.explainWorkerError(401, ''), /Passcode salah/); assert.match(S.explainWorkerError(400, 'Aksi tidak dikenal'), /tempel ulang/);
  assert.match(S.explainWorkerError(500, ''), /kode 500/);
  const e = { PASS_RAMA: PASS, KV: kv() }; const http = lewatWorker(e);
  for (let i = 0; i < 10; i++) await S.testConnection({ url: URL1, key: 'salah-salah-' + i }, http);
  assert.match((await S.testConnection({ url: URL1, key: PASS }, http)).steps[1].msg, /Terlalu banyak percobaan/);
});
test('kegagalan ping: Hello World (bukan JSON), kode bukan 2xx, jaringan mati, waktu habis; passcode TIDAK dikirim', async () => {
  let posts = 0; const mk = (fn) => async (q) => { if (q.method === 'POST') posts++; return fn(q); };
  let r = await S.testConnection({ url: URL1, key: PASS }, mk(async () => ({ status: 200, text: 'Hello World' })));
  assert.equal(r.ok, false); assert.equal(r.steps.length, 1); assert.match(r.steps[0].msg, /Hello World/);
  r = await S.testConnection({ url: URL1, key: PASS }, mk(async () => ({ status: 404, text: '' }))); assert.match(r.steps[0].msg, /kode 404/);
  r = await S.testConnection({ url: URL1, key: PASS }, mk(async () => { throw new Error('Failed to fetch'); })); assert.match(r.steps[0].msg, /Tidak tersambung/);
  r = await S.testConnection({ url: URL1, key: PASS }, mk(async () => { throw new Error('The request timed out'); })); assert.match(r.steps[0].msg, /Waktu habis/);
  r = await S.testConnection({ url: URL1, key: PASS }, mk(async () => ({ status: 200, text: JSON.stringify({ ok: true, app: 'TWO POCKETS' }) }))); assert.equal(r.ok, false);
  assert.equal(posts, 0);
});
test('isian tidak sah ditolak sebelum ada permintaan jaringan', async () => {
  let n = 0; const http = async () => { n++; return { status: 200, text: '{}' }; };
  assert.equal((await S.testConnection({ url: 'https://evil.com', key: PASS }, http)).steps[0].id, 'input');
  assert.equal((await S.testConnection({ url: URL1, key: '' }, http)).steps[0].id, 'input');
  assert.equal((await S.testConnection(null, http)).ok, false); assert.equal(n, 0);
});
test('POST gagal setelah ping berhasil: pesan jelas, tidak melempar', async () => {
  const http = async (q) => (q.method === 'GET' ? { status: 200, text: JSON.stringify({ ok: true, app: 'KELIMAA AI', v: 1 }) } : { status: 502, text: '<html>' });
  const r = await S.testConnection({ url: URL1, key: PASS }, http); assert.equal(r.ok, false); assert.match(r.steps[1].msg, /kode 502/);
  const http2 = async (q) => { if (q.method === 'GET') return { status: 200, text: JSON.stringify({ ok: true, app: 'KELIMAA AI', v: 1 }) }; throw new Error('timeout'); };
  assert.match((await S.testConnection({ url: URL1, key: PASS }, http2)).steps[1].msg, /Waktu habis/);
});
test('AI dimuat MALAS dan terpisah: settings.js tanpa impor statis ai/, modul logika tanpa DOM, tidak ikut cadangan, Catatan Privat/sampah tak tersentuh', () => {
  const st = src('src/js/settings.js');
  assert.doesNotMatch(st, /^import .*['"]\.\/ai\//m); assert.match(st, /import\('\.\/ai\/layar\.js'\)/); assert.match(st, /export function viewKelimaaAI\(ctx\)/); // Rev 215: ubin dan rute Setelan dicabut; layar dibuka dari tab AI di bilah bawah
  assert.doesNotMatch(st, /tile\('wide', PATH\.star, 'v', 'KELIMAA AI'/); assert.match(src('src/js/main.js'), /ui\.tab === 'ai' \? viewKelimaaAI\(ctx\)/);
  const lg = src('src/js/ai/sambungan.js'); assert.doesNotMatch(lg, /document\.|window\.|from '\.\.\/ui\.js'/); assert.deepEqual([...lg.matchAll(/^import .*$/gm)].map((m) => m[0]), ["import { isNative, nativePlugin } from '../native.js';"]);
  assert.doesNotMatch(lg, /\.priv|\.trash|catatan_app_data|\.notes|\.tasks/);
  for (const f of ['storage.js', 'backup.js', 'export.js', 'cadangan-gambar.js']) assert.doesNotMatch(src('src/js/' + f), /kelimaa_ai/, f);
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\/|kelimaa_ai/); assert.doesNotMatch(src('src/js/startup.js'), /\/ai\/|kelimaa_ai/);
});
test('layar: sakelar role=switch, tombol Tes/Simpan/Putuskan/Kembali, kolom passcode bertipe password, alamat awal, tanpa rahasia', () => {
  const ly = src('src/js/ai/layar.js');
  for (const k of ["role: 'switch'", "type: 'password'", "'Tes sambungan'", "'Simpan sambungan'", "'Putuskan sambungan'", "'Kembali'", "'Putuskan Kelimaa AI?'", 'Simpan sambungan dulu, baru nyalakan.', 'testConnection({ url: url.value, key: key.value })']) assert.ok(ly.includes(k), k);
  assert.doesNotMatch(ly, /console\./); assert.doesNotMatch(ly, /innerHTML/);
  assert.match(ly, /ALAMAT_AWAL = 'https:\/\/kelimaa-ai\.dhani5081\.workers\.dev'/); assert.doesNotMatch(ly, /PASS_RAMA|PASS_DESY|sk-|AIza/);
});
test('versi 0.3.121 di tiga tempat, SCHEMA 18 tetap, tanpa perubahan native/dependensi, tes terdaftar', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev206\.test\.mjs/);
  assert.deepEqual(Object.keys(JSON.parse(src('package.json')).dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
