// Tes insertTodo() dengan DOM tiruan mini: kotak centang baru harus jadi baris sendiri, bukan bersarang.
class N { constructor(tag, text = '') { this.tagName = tag; this.className = ''; this.kids = []; this.parentNode = null; this._t = text; this.nodeType = tag === '#text' ? 3 : 1; }
  get textContent() { return this._t + this.kids.map((k) => k.textContent).join(''); }
  get nextSibling() { if (!this.parentNode) return null; const k = this.parentNode.kids; return k[k.indexOf(this) + 1] || null; }
  setAttribute() {}
  append(...a) { for (const x of a) { const n = typeof x === 'string' ? new N('#text', x) : x; n.parentNode = this; this.kids.push(n); } }
  insertBefore(n, ref) { n.parentNode = this; const i = ref ? this.kids.indexOf(ref) : this.kids.length; this.kids.splice(i, 0, n); }
  removeChild(n) { this.kids.splice(this.kids.indexOf(n), 1); n.parentNode = null; } }
const doc = { createElement: (t) => new N(t.toUpperCase()) };
const { insertTodo } = await import('../src/js/todo.js');
let ok = 0; const t = (name, fn) => { fn(); ok++; console.log('ok - ' + name); };
const assert = (c, m) => { if (!c) throw new Error('GAGAL: ' + m); };
const todo = (txt) => { const d = new N('DIV'); d.className = 'todo'; d.append(new N('INPUT'), '\u00a0' + txt); return d; };
const nested = (ed) => ed.kids.some((k) => k.kids.some((x) => x.tagName === 'DIV'));

t('kursor di akhir baris centang: baris baru di bawahnya, tidak bersarang', () => {
  const ed = new N('DIV'); const a = todo('gh'), b = todo('ggnhhdhd'); ed.append(a, b);
  const row = insertTodo(ed, b.kids[1], doc);
  assert(ed.kids.length === 3 && ed.kids[2] === row, 'baris baru jadi anak ketiga editor');
  assert(!nested(ed), 'tidak ada div di dalam div');
});
t('kursor di baris teks biasa: kotak centang dipasang setelahnya', () => {
  const ed = new N('DIV'); const line = new N('DIV', 'Hshshs'); ed.append(line);
  const row = insertTodo(ed, line, doc);
  assert(ed.kids[0] === line && ed.kids[1] === row, 'urutan benar');
});
t('teks langsung di akar editor (tanpa pembungkus)', () => {
  const ed = new N('DIV'); ed.append('Hshshs'); const txt = ed.kids[0];
  const row = insertTodo(ed, txt, doc);
  assert(ed.kids[0] === txt && ed.kids[1] === row, 'baris baru setelah teks');
});
t('baris kosong biasa diganti, bukan ditambah', () => {
  const ed = new N('DIV'); const empty = new N('DIV'); ed.append(empty);
  const row = insertTodo(ed, empty, doc);
  assert(ed.kids.length === 1 && ed.kids[0] === row, 'hanya satu baris tersisa');
});
t('editor kosong atau kursor di luar: ditambahkan di akhir', () => {
  const ed = new N('DIV'); const row = insertTodo(ed, ed, doc);
  assert(ed.kids.length === 1 && ed.kids[0] === row, 'satu baris di akhir');
});
console.log(`\n${ok} tes kotak centang lulus`);
