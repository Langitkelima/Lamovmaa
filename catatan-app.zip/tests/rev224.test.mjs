// Rev 222 / v0.3.121: task.create = jadikan butir daftar balasan AI jadi tugas (konfirmasi, lingkup, Urungkan).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
globalThis.document = { createElement: () => ({ innerHTML: '', content: { childNodes: [], querySelectorAll: () => [], querySelector: () => null } }), querySelector: () => null };
const A = await import('../src/js/ai/aksi.js');
const mk = () => { const ctx = { data: { tasks: [{ id: 'old', title: 'LAMA', done: false, pri: 0, due: '', scope: 'hari' }], habits: [{ id: 'h', title: 'MINUM' }], notes: [], priv: [{ id: 'p', title: 'X' }] }, ui: { tab: 'ai' }, calls: 0, renders: 0 }; ctx.persist = () => { ctx.calls++; }; ctx.render = () => { ctx.renders++; }; return ctx; };
test('taskDrafts: butir daftar dipakai (bullet, nomor, kotak centang), markdown dibuang, duplikat dan kosong dilewati, maks. 10', () => {
  assert.deepEqual(A.taskDrafts('Rencana:\n- Beli susu\n* **Cuci** mobil\n1. Bayar listrik\n2) [ ] Telepon ibu\n- beli SUSU\n-\ncatatan biasa'), ['Beli susu', 'Cuci mobil', 'Bayar listrik', 'Telepon ibu']);
  assert.equal(A.taskDrafts(Array.from({ length: 15 }, (_, i) => '- tugas ' + i).join('\n')).length, A.TASK_MAX);
  assert.equal(A.taskDrafts('- ' + 'x'.repeat(300))[0].length, A.TASK_TITLE_MAX);
});
test('taskDrafts: tanpa butir -> satu baris pendek dipakai; paragraf panjang atau kosong -> tidak ada', () => {
  assert.deepEqual(A.taskDrafts('Servis motor Sabtu'), ['Servis motor Sabtu']); assert.deepEqual(A.taskDrafts('Baris satu\nBaris dua tanpa butir'), []);
  assert.deepEqual(A.taskDrafts('y'.repeat(200)), []); assert.deepEqual(A.taskDrafts(''), []); assert.deepEqual(A.taskDrafts(null), []);
});
test('createTasks: judul KAPITAL, bentuk sama dengan tugas biasa, lingkup sah, Kebiasaan/priv tak tersentuh', () => {
  const ctx = mk(), ids = A.createTasks(ctx, ['Beli susu', 'beli SUSU', '  ', 'Cuci mobil'], 'minggu');
  assert.equal(ids.length, 2); const t = ctx.data.tasks.filter((x) => ids.includes(x.id));
  assert.deepEqual(t.map((x) => x.title), ['BELI SUSU', 'CUCI MOBIL']); for (const x of t) { assert.equal(x.scope, 'minggu'); assert.equal(x.done, false); assert.equal(x.pri, 0); assert.equal(x.due, ''); assert.ok(x.id); assert.equal(x.reminder, undefined); assert.equal(x.subs, undefined); }
  assert.equal(ctx.data.tasks.length, 3); assert.equal(ctx.calls, 1); assert.equal(ctx.data.habits.length, 1); assert.equal(ctx.data.priv.length, 1);
});
test('createTasks: lingkup salah (termasuk habit), daftar kosong, data aneh ditolak tanpa mengubah apa pun; render hanya di tab tugas', () => {
  const ctx = mk();
  for (const sc of ['habit', 'x', '', undefined]) assert.equal(A.createTasks(ctx, ['A'], sc), null);
  assert.equal(A.createTasks(ctx, [], 'hari'), null); assert.equal(A.createTasks(ctx, 'A', 'hari'), null); assert.equal(A.createTasks(null, ['A'], 'hari'), null); assert.equal(A.createTasks({ data: {} }, ['A'], 'hari'), null);
  assert.equal(ctx.data.tasks.length, 1); assert.equal(ctx.calls, 0);
  A.createTasks(ctx, ['A'], 'hari'); assert.equal(ctx.renders, 0); ctx.ui.tab = 'tugas'; A.createTasks(ctx, ['B'], 'hari'); assert.equal(ctx.renders, 1);
  assert.equal(A.createTasks(ctx, Array.from({ length: 25 }, (_, i) => 't' + i), 'bulan').length, A.TASK_MAX);
});
test('removeTasks (Urungkan): hanya id yang dibuat hilang, tugas lama utuh', () => {
  const ctx = mk(), ids = A.createTasks(ctx, ['A', 'B'], 'hari'); assert.equal(A.removeTasks(ctx, ids), 2);
  assert.deepEqual(ctx.data.tasks.map((x) => x.id), ['old']); assert.equal(A.removeTasks(ctx, ids), 0); assert.equal(A.removeTasks(ctx, 'x'), 0);
});
test('obrolan.js: Jadikan tugas lewat dialog centang + lingkup + konfirmasi; aksi.js tetap bersih; tetap malas', () => {
  const o = src('src/js/ai/obrolan.js'), a = src('src/js/ai/aksi.js');
  assert.match(o, /Jadikan tugas/); assert.match(o, /createTasks\(ctx, pick, scope\)/); assert.match(o, /removeTasks\(ctx, ids\)/); assert.match(o, /type: 'checkbox'/); assert.match(o, /Pilih minimal satu tugas/);
  assert.ok(o.indexOf("class: 'btn', onclick: () => {\n      const pick") > 0 || /const pick = rows\.filter/.test(o));
  assert.doesNotMatch(a, /innerHTML|\.priv\b|\.trash\b|\.habits|openEditor|localStorage|syncTaskAlarms/);
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\//); assert.deepEqual(A.TASK_SCOPES.map((x) => x[0]), ['hari', 'minggu', 'bulan']);
});
