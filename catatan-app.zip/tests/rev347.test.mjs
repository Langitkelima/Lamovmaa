// Rev 347 / PART R2: penyembuhan cid item daftar (bullet/bernomor) + sanitize mengizinkan data-cid pada li.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { healListCids } from '../src/js/todo.js';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

class N {
  constructor(type, tag, data) { this.nodeType = type; this.tagName = tag; this.data = data; this.childNodes = []; this.attrs = {}; }
  get firstChild() { return this.childNodes[0] || null; }
  get nextSibling() { return this._p ? (this._p.childNodes[this._p.childNodes.indexOf(this) + 1] || null) : null; }
  get textContent() { return this.nodeType === 3 ? this.data : this.childNodes.map((c) => c.textContent).join(''); }
  add(c) { c._p = this; this.childNodes.push(c); return this; }
  getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; }
  removeAttribute(k) { delete this.attrs[k]; }
}
const t = (d) => new N(3, undefined, d);
const li = (cid, ...kids) => { const e = new N(1, 'LI'); if (cid) e.attrs['data-cid'] = cid; kids.forEach((k) => e.add(k)); return e; };
const ul = (...kids) => { const e = new N(1, 'UL'); kids.forEach((k) => e.add(k)); return e; };

test('R2: cid ganda di li (Enter membelah item): yang PERTAMA tetap, yang kedua dibersihkan', () => {
  const a = li('bul01', t('Telepon ibu')), b = li('bul01', t('sambungan'));
  assert.equal(healListCids([a, b]), 1);
  assert.equal(a.getAttribute('data-cid'), 'bul01'); assert.equal(b.getAttribute('data-cid'), null);
  assert.equal(healListCids([a, b]), 0, 'idempoten');
});
test('R2: li tanpa teks (kosong/spasi/nbsp/br) tidak boleh memegang cid', () => {
  const k1 = li('kos01'), k2 = li('kos02', t(' \u00a0 ')), k3 = li('kos03', new N(1, 'BR')), ok = li('ada01', t('x'));
  assert.equal(healListCids([k1, k2, k3, ok]), 3);
  assert.equal(k1.getAttribute('data-cid'), null); assert.equal(k2.getAttribute('data-cid'), null); assert.equal(k3.getAttribute('data-cid'), null);
  assert.equal(ok.getAttribute('data-cid'), 'ada01');
});
test('R2: li induk dengan sub-daftar tapi tanpa teks sendiri kehilangan cid; teks anak tidak dihitung milik induk', () => {
  const anak = li('anak1', t('Anak')); const induk = li('induk', ul(anak));
  assert.equal(healListCids([induk, anak]), 1);
  assert.equal(induk.getAttribute('data-cid'), null); assert.equal(anak.getAttribute('data-cid'), 'anak1');
});
test('R2: cid kembar lintas jenis: div.todo lebih dulu menang; div.todo kembar tidak disentuh (urusan sanitize)', () => {
  const todo = new N(1, 'DIV'); todo.attrs['data-cid'] = 'samaa'; const l = li('samaa', t('bullet'));
  assert.equal(healListCids([todo, l]), 1); assert.equal(todo.getAttribute('data-cid'), 'samaa'); assert.equal(l.getAttribute('data-cid'), null);
  const t2 = new N(1, 'DIV'); t2.attrs['data-cid'] = 'samaa';
  assert.equal(healListCids([todo, t2]), 0); assert.equal(t2.getAttribute('data-cid'), 'samaa');
});
test('R2: elemen tanpa cid dilewati', () => { assert.equal(healListCids([li(null, t('x'))]), 0); assert.equal(healListCids([]), 0); });
test('R2: sumber notes.js: sanitize mengizinkan data-cid hanya pada li di dalam ul/ol dan div.todo; healTodos memanggil healListCids', () => {
  const s = read('src/js/notes.js');
  assert.match(s, /k === 'data-cid' && CID_RE\.test\(v\) && \(\(c\.tagName === 'DIV' && c\.classList\.contains\('todo'\)\) \|\| \(c\.tagName === 'LI' && !!c\.parentElement && \/\^\(UL\|OL\)\$\/\.test\(c\.parentElement\.tagName\)\)\)/);
  assert.match(s, /healListCids\(\[\.\.\.ed\.querySelectorAll\('li\[data-cid\],\.todo\[data-cid\]'\)\]\)/);
  assert.match(s, /if \(isLi\) \{ el\.removeAttribute\('data-cid'\); return; \}/);
  assert.match(s, /import \{[^}]*healListCids[^}]*\} from '\.\/todo\.js'/);
});
