import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const ui = readFileSync(new URL('../src/js/ui.js', import.meta.url), 'utf8');
let n = 0; const ok = (m, f) => { f(); n++; console.log('ok - ' + m); };
ok('Rev 204: lapisan .swbg tidak pernah menangkap sentuhan', () => {
  assert.match(css, /\.swbg\{pointer-events:none\}/);
});
ok('Rev 204: baris Tugas/Kebiasaan kembali polos (tanpa geser-hapus); tombol tempat sampah tetap ada', () => {
  const m = readFileSync(new URL('../src/js/main.js', import.meta.url), 'utf8');
  assert.doesNotMatch(m, /pasangGeserHapus|swbgEl|class: 'swt'/); assert.doesNotMatch(ui, /pasangGeserHapus/); assert.doesNotMatch(css, /\.swt\b/);
  assert.match(m, /aria-label': 'Hapus', onclick: \(\) => remove\(item, kind\)/);
});
const { minifyCss } = await import('../scripts/minify.mjs');
ok('Rev 204: minifyCss membuang komentar dan spasi tak bermakna, menjaga spasi bermakna dan isi string', () => {
  assert.equal(minifyCss('/* x */\n.a  b ,\n .c > d {\n  color : red ;\n  margin: calc(1px + 2px) 0\n}\n'), '.a b,.c > d{color : red;margin: calc(1px + 2px) 0}');
  assert.equal(minifyCss('.a::before{content:"a;  /* b */ {"}'), '.a::before{content:"a;  /* b */ {"}');
  assert.equal(minifyCss(".a{font:12px/1 'A  B',serif}"), ".a{font:12px/1 'A  B',serif}");
  assert.equal(minifyCss('.a/**/.b{x:1}'), '.a .b{x:1}');
  assert.throws(() => minifyCss('.a{/* buka'));
});
ok('Rev 204: build menyalin src ke www dan CSS hasilnya lebih kecil dengan kurung seimbang', async () => {
  const { execFileSync } = await import('node:child_process');
  execFileSync(process.execPath, ['scripts/build.mjs'], { cwd: new URL('..', import.meta.url), stdio: 'pipe' });
  const min = readFileSync(new URL('../www/css/styles.css', import.meta.url), 'utf8');
  assert.ok(min.length < css.length * 0.95);
  assert.equal(min.split('{').length, min.split('}').length); assert.doesNotMatch(min, /\/\*/);
});
console.log(n + ' tes lulus (rev204)');
