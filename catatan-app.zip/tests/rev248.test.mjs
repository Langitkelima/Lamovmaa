// Rev 248: perombakan UI Proyek + dialog Data aplikasi untuk AI. Tanpa peramban; memeriksa kode dan CSS.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('Proyek: judul KAPITAL, keterangan di kartu permukaan solid, teks isian berwarna tema', () => {
  const ui = src('src/js/proyek-ui.js'), css = src('src/css/styles.css');
  assert.equal((ui.match(/h\('h1', \{\}, 'PROYEK'\)/g) || []).length, 2); assert.doesNotMatch(ui, /h\('h1', \{\}, 'Proyek'\)/);
  assert.match(ui, /class: 'pjintro'/); assert.match(ui, /class: 'pjring'/);
  for (const c of ['.pjintro{', '.pjring{', 'text-transform:uppercase', '-webkit-text-fill-color:var(--ink)']) assert.ok(css.includes(c), c);
  const blok = css.slice(css.indexOf('Rev 248: Proyek')); assert.doesNotMatch(blok, /#[0-9a-fA-F]{3,8}\b/, 'tanpa warna heks');
  assert.match(blok, /\.pjintro\{[^}]*background:var\(--sfo\)/);
});
test('Data aplikasi untuk AI: baris sakelar (role=switch), kartu aksi, judul kapital lewat CSS, tanpa pengiriman otomatis', () => {
  const o = src('src/js/ai/obrolan.js'), css = src('src/css/styles.css');
  assert.match(o, /class: 'kd-row'/); assert.match(o, /bukaPemilihData/); assert.match(o, /class: 'kd-act'/); assert.match(o, /'Lihat data yang dikirim'/); assert.match(o, /'Minta saran AI'/);
  assert.match(css, /\.kd-sheet h3\{[^}]*text-transform:uppercase/); assert.match(css, /\.kd-row\.on\{/);
  const blok = o.slice(o.indexOf('const bukaData'), o.indexOf('const kc = h')); assert.doesNotMatch(blok, /kirimChat|send\.click/);
});
