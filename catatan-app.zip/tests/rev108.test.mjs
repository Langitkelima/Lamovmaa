// Rev 108: sistem kotak centang dirapikan. Akar masalah (terbukti di Chromium): Enter di dalam div.todo membuat div.todo BARU TANPA kotak
// (lonceng bertumpuk, teks nempel kiri). Invarian: tiap div.todo punya TEPAT SATU kotak sebagai anak pertamanya.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { boxOf, isTodoBlank, newTodoRow, healTodoStructure, todoToPlain, mergeNextTodo } from '../src/js/todo.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

// DOM mini
class N {
  constructor(type, tag, data) { this.nodeType = type; this.tagName = tag; this.data = data; this.parentNode = null; this.childNodes = []; this.attrs = {}; this.className = ''; }
  get firstChild() { return this.childNodes[0] || null; }
  get nextSibling() { if (!this.parentNode) return null; const k = this.parentNode.childNodes; return k[k.indexOf(this) + 1] || null; }
  insertBefore(c, ref) { if (c.parentNode) c.parentNode.removeChild(c); c.parentNode = this; const i = ref ? this.childNodes.indexOf(ref) : this.childNodes.length; this.childNodes.splice(i, 0, c); return c; }
  removeChild(c) { this.childNodes.splice(this.childNodes.indexOf(c), 1); c.parentNode = null; return c; }
  setAttribute(k, v) { this.attrs[k] = v; }
  removeAttribute(k) { delete this.attrs[k]; if (k === 'class') this.className = ''; }
}
const doc = { createElement: (t) => new N(1, t.toUpperCase()), createTextNode: (d) => new N(3, undefined, d) };
const txt = (d) => doc.createTextNode(d);
const el = (t, ...kids) => { const e = doc.createElement(t); for (const k of kids) e.insertBefore(k, null); return e; };
const row = (...kids) => { const r = el('div', ...kids); r.className = 'todo'; return r; };
const box = () => el('input');
const dump = (r) => r.childNodes.map((c) => (c.nodeType === 3 ? JSON.stringify(c.data) : '[' + c.tagName + ']')).join(' ');

test('Rev 108: baris yatim kosong (<br>) = hasil Enter bawaan Chrome diberi kotak baru + nbsp', () => {
  const r = row(el('br'));
  assert.equal(healTodoStructure(r, doc), 1);
  assert.equal(dump(r), '[INPUT] " "');
  assert.equal(healTodoStructure(r, doc), 0, 'idempoten');
});
test('Rev 108: baris yatim berisi teks (catatan lama) diberi kotak di depan, teks utuh dan sejajar', () => {
  const r = row(txt('tanpa kotak'));
  assert.equal(healTodoStructure(r, doc), 1);
  assert.equal(dump(r), '[INPUT] " " "tanpa kotak"');
  const r2 = row(txt(' sudah ada nbsp'));
  healTodoStructure(r2, doc); assert.equal(dump(r2), '[INPUT] " sudah ada nbsp"');
});
test('Rev 108: kotak ganda dalam satu baris dibuang, teks tetap; baris normal tidak berubah', () => {
  const r = row(box(), txt(' a'), box(), txt('b'));
  assert.equal(healTodoStructure(r, doc), 1);
  assert.equal(dump(r), '[INPUT] " a" "b"');
  const ok = row(box(), txt(' isi')); assert.equal(healTodoStructure(ok, doc), 0);
});
test('Rev 108: teks di kiri kotak (Rev 107) tetap disembuhkan oleh healTodoStructure', () => {
  const r = row(txt('Dd'), box(), txt(' x'));
  assert.ok(healTodoStructure(r, doc) >= 1); assert.equal(dump(r), '[INPUT] "Dd" " x"');
});
test('Rev 108: isTodoBlank: kosong/nbsp/<br> = true; ada huruf atau gambar = false', () => {
  assert.equal(isTodoBlank(row(box(), txt(' '))), true);
  assert.equal(isTodoBlank(row(box(), txt(' '), el('br'))), true);
  assert.equal(isTodoBlank(row(box(), txt(' a'))), false);
  assert.equal(isTodoBlank(row(box(), txt(' '), el('img'))), false);
  assert.equal(isTodoBlank(row(box(), txt(' '), el('span', txt('x')))), false);
});
test('Rev 108: newTodoRow = kotak + nbsp, belum dicentang, tanpa data-cid (tanpa pengingat)', () => {
  const r = newTodoRow(doc); assert.equal(r.className, 'todo'); assert.equal(dump(r), '[INPUT] " "');
  assert.equal(r.attrs['data-cid'], undefined); assert.equal(boxOf(r).attrs.checked, undefined);
});
test('Rev 108: todoToPlain (Backspace di awal / Enter di baris kosong): kotak, kelas, cid, nbsp pembuka dibuang; teks utuh', () => {
  const r = row(box(), txt(' halo')); r.setAttribute('class', 'todo'); r.setAttribute('data-cid', 'abc'); r.setAttribute('data-rem', '1');
  todoToPlain(r, doc);
  assert.equal(dump(r), '"halo"'); assert.deepEqual(r.attrs, {});
  const e = row(box(), txt(' ')); todoToPlain(e, doc); assert.equal(dump(e), '[BR]', 'baris kosong diberi <br> agar tetap terlihat');
});
test('Rev 108: mergeNextTodo (Delete di akhir baris): isi baris berikutnya masuk, kotak dan <br> tidak ikut, baris berikutnya hilang', () => {
  const ed = el('div'); const a = row(box(), txt(' ab')); const b = row(box(), txt(' cd')); ed.insertBefore(a, null); ed.insertBefore(b, null);
  mergeNextTodo(a, b);
  assert.equal(dump(a), '[INPUT] " ab" " cd"'); assert.equal(ed.childNodes.length, 1);
  assert.equal(a.childNodes.filter((c) => c.tagName === 'INPUT').length, 1);
});
test('Rev 108: kode notes.js memasang beforeinput (Enter/Backspace/Delete), melewati IME, dan sanitize memakai healTodoStructure', () => {
  const nt = src('src/js/notes.js');
  assert.ok(nt.includes("ed.addEventListener('beforeinput'"));
  assert.ok(nt.includes("t === 'insertParagraph'") && nt.includes("t === 'deleteContentBackward'") && nt.includes("t === 'deleteContentForward'"));
  assert.ok(nt.includes('e.isComposing || composing'), 'saat IME menyusun kata, DOM tidak disentuh');
  assert.ok(nt.includes('if (composing) return 0;'), 'healTodos tidak jalan saat IME menyusun');
  assert.ok(nt.includes('healTodoStructure(row, t.content.ownerDocument)'), 'catatan lama yang rusak ikut sembuh lewat sanitize');
  assert.ok(nt.includes("rowFixed.removeAttribute") || nt.includes("row.removeAttribute('data-cid')"), 'baris salinan Chrome tidak mewarisi cid pengingat');
});
test('Rev 108: versi 0.3.121', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
