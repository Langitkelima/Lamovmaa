// Rev 175: gaya kartu kaca untuk Setelan > Gambar, Tempat sampah, keadaan kosong (hanya tampilan).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const rev = css.slice(css.indexOf('Rev 175:'));
test('Rev 175: CSS dibatasi sub-layar dan memakai variabel tema saja', () => {
  assert.ok(rev.length > 500); assert.doesNotMatch(rev, /#[0-9a-fA-F]{3,8}\b/);
  assert.match(rev, /\[data-sub="gambar"\] \.stat/); assert.match(rev, /\[data-sub="trash"\] \.row/); assert.match(rev, /\.empty::before/);
});
test('Rev 175: versi 0.3.121, SCHEMA 18', () => {
  assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /"version": "0\.3\.121"/);
  assert.match(readFileSync(new URL('../src/js/settings.js', import.meta.url), 'utf8'), /v0\.3\.121/);
});
