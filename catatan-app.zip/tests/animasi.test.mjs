// Tes Rev 27B: animasi sedot-muntah bilah bawah + Garis bawah manual. Pemeriksaan sumber; animasi dicek terpisah di Chromium. BUKAN uji di HP.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0; const t = (name, fn) => { fn(); n++; console.log('ok - ' + name); };
const nt = readFileSync(new URL('../src/js/notes.js', import.meta.url), 'utf8');
t('animasi hanya transform + opacity (tanpa width/left/height), lewat Web Animations API', () => {
  const blk = nt.slice(nt.indexOf('Rev 27B: animasi'), nt.indexOf('const capply'));
  assert.ok(blk.includes('.animate(') && blk.includes('transform') && blk.includes('opacity'));
  for (const bad of [/width\s*:/, /left\s*:/, /height\s*:/, /margin/]) assert.ok(!bad.test(blk), String(bad));
});
t('ketukan saat animasi diabaikan (fmtBusy), animasi dibatalkan setelah selesai, jalur mundur bila animate tidak ada', () => {
  for (const k of ['let fmtBusy = false', 'if (fmtBusy ||', 'fmtBusy = false', 'x.cancel()', "typeof starBtn.animate === 'function'", 'if (!canAnim()) { fmtState(open); return; }']) assert.ok(nt.includes(k), k);
});
t('prefers-reduced-motion: ganti dengan pudar 100 ms tanpa gerak', () => {
  assert.ok(nt.includes("prefers-reduced-motion: reduce") && nt.includes('duration: 100'));
});
t('urutan buka: sedot (170 ms) -> geser bintang (220 ms) -> muntah berurutan (jeda 25 ms); tutup: sedot jeda 15 ms', () => {
  for (const k of ['duration: 170', 'duration: 220', 'delay: 40 + i * 25', 'delay: (fmts.length - 1 - i) * 15', 'scale(.35)']) assert.ok(nt.includes(k), k);
});
t('Garis bawah dibungkus sendiri dengan <u>, jatuh ke execCommand bila tidak bisa, hanya simpul teks', () => {
  for (const k of ['const underlineSel = () =>', "document.createElement('u')", "c === 'underline' && underlineSel()", 'SHOW_TEXT']) assert.ok(nt.includes(k), k);
});
t('tanpa perubahan data/native: SCHEMA 8 sejak Rev 60', () => assert.ok(/SCHEMA = 22/.test(readFileSync(new URL('../src/js/storage.js', import.meta.url), 'utf8'))));
console.log(`\n${n} tes lulus (animasi)`);
