// Rev 192b / P2b-1: mesin rumus (rumus.js) dimuat belakangan lewat jembatan lembar-mesin.js. Berkas rev193 = Rev 192b.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, statSync } from 'node:fs';
import { staticGraph } from '../scripts/preload.mjs';
import { getEngine, setEngine, loadEngine, onEngine, sheetsHaveFx } from '../src/js/lembar-mesin.js';
import { makeDisplay, fxFromA1, shiftFormula } from '../src/js/lembar-tampil.js';
import * as L from '../src/js/lembar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const g = staticGraph('js/main.js'); const has = (m) => g.includes('js/' + m + '.js');
const mk = () => { const sh = L.newSheet({ name: 'T' }); const t = sh.tabs[0]; return { sh, t }; };

test('anggaran: rumus.js TIDAK ada di graf statis main.js; jembatan kecil ada; JS buka lebih kecil dari Rev 192a (755.464 byte)', () => {
  assert.ok(!has('rumus'), 'rumus.js tidak boleh impor statis dari main.js'); assert.ok(has('lembar-mesin'));
  const tot = g.reduce((a, f) => a + statSync(new URL('../src/' + f, import.meta.url)).size, 0);
  assert.ok(tot < 810000 /* Rev 416: 800000 -> 810000 ATAS IZIN PENGGUNA. Rev 410: naik 792000 -> 800000 ATAS IZIN PENGGUNA (23 Nov 2026, "Klo misal perlu penaikan boleh"; kartu TWO POCKETS baru menambah sekitar 1,4 KB JS buka, 792.698 byte saat dinaikkan). Naikkan lagi HANYA dengan izin. Sebelumnya: Rev 346: naik dari 764000 ATAS IZIN PENGGUNA (19 Nov 2026, "naikkan dulu sampai OCR"; Paket R pengingat bullet/bernomor + Paket OCR; JS buka 763.928 byte saat dinaikkan). Naikkan lagi HANYA dengan izin. Sebelumnya: Rev 331 / TC: naik dari 758000 ATAS IZIN PENGGUNA (D-T1, 18 Nov 2026; toast tumpuk + garis waktu + geser di ui.js menambah sekitar 2 KB di jalur buka; JS buka 758.556 byte). Sebelumnya: Rev 323 / L2: naik dari 752000 ATAS IZIN PENGGUNA (D1, 18 Nov 2026 'boleh naikkan agak banyak'; JS buka 754.185 byte): kait sanitize kartu tautan + registri blok lk + tombol/ikon Tautan + pembuka dialog malas di notes.js (+~2,5 KB); dialog dan tampilan kartu ada di linkcard-ui.js (MALAS, di luar jalur buka). Sisa ~3,8 KB untuk L3. Rev 319: naik dari 750000 ATAS IZIN PENGGUNA (D1, 18 Nov 2026 'boleh naikkan agak banyak'); sambungan pegangan seret lebar kolom (muat malas tabel-seret.js, inti applyTableWidths di tabel.js) +~0,6 KB di jalur buka. Rev 318: naik dari 748000 ATAS IZIN PENGGUNA (18 Nov 2026, D1 'boleh naikkan agak banyak'); mesin lebar kolom tabel (inti sanitize di tabel.js, +~1,6 KB) harus ikut jalur buka; sisanya lazy di tabel-lebar.js. Rev 311d: naik dari 745000 (izin pengguna 16 Nov 2026, usul 748000; JS buka 746.885 byte pada Rev 311c); Rev 310a: naik dari 744000 (izin pengguna soal anggaran JS) karena icoMenu (tiga garis jadi silang, header catatan) + svgEl di ui.js harus ikut graf buka (+~0,5 KB); ikon rumah A1 sengaja di modul malas obrolan.js; Rev 303d: naik dari 743000 karena boxView (kotak centang di pulau/ekspor/kartu, sekitar 0,7 KB) harus sinkron dan lembar-pulau.js ada di graf buka; Rev 300a / Bekukan: naik dari 741500 karena inti beku (tab.fz, cleanFreeze, fzShift di lembar.js, +1,8 KB); alat beku = modul MALAS, tanpa modul statis baru; tersisa ~0,5 KB, jadi 300b/300c yang menambah kode HARUS di modul malas; Rev 295 / Paket Data: naik dari 740000 karena penjaga gagal-muat (4-1) + log aman (7-1) + habitLog di replaceData (4-2), +0,8 KB, tanpa modul baru; tersisa ~0,8 KB; Rev 270 / V5a: naik dari 730000 karena mesin kriteria baru (teks/email/URL/angka/tanggal: cleanCriteria, okCriteria, parseNumText, parseDateText, criteriaText di lembar-validasi.js, +8,8 KB; modul sudah statis lewat lembar.js, tanpa modul baru; tersisa ~2 KB, jadi V5b/V6 yang menambah kode harus memindahkan kriteria ke modul lazy); Rev 267: naik dari 724000 karena pembantu murni editor Validasi (rangeText/parseRange/partsFromRect/itemsFromRows/ITEM_COLORS di lembar-validasi.js, +4,7 KB; modul sudah statis lewat lembar.js, tanpa modul baru); Rev 266: naik dari 717000 karena model validasi diperluas (rentang, warna per pilihan, checkRect/checkAt/colorOf/withColor di lembar-validasi.js, +5 KB; modul sudah statis lewat lembar.js, tanpa modul baru); Rev 235: naik lagi dari 714000 karena pintu Proyek di Setelan (ubin + pemuat malas, +1 KB; layarnya sendiri proyek-ui.js TIDAK statis); Rev 234: naik dari 710000 karena model Proyek (proyek.js, dipakai normalize() saat startup, +3,5 KB) */, 'JS statis saat buka ' + tot + ' byte'); assert.ok(g.length <= 53 /* Rev 234: +proyek.js */, 'modul statis ' + g.length);
});
test('jembatan: tanpa impor statis, kecil, tanpa DOM/penyimpanan/native; rumus.js tetap murni (tanpa impor)', () => {
  const s = src('src/js/lembar-mesin.js'); assert.ok(!/^import\s/m.test(s)); assert.ok(s.length < 3500);
  assert.doesNotMatch(s, /localStorage|document\.|window\.|AndroidAPI|Capacitor|eval\(|new Function/); assert.match(s, /import\('\.\/rumus\.js'\)/);
  assert.ok(!/^\s*import\s/m.test(src('src/js/rumus.js')));
});
test('tanpa mesin: tab tanpa rumus tetap benar dan TIDAK memicu pemuatan; tab berumus tampil kosong + pending', () => {
  assert.equal(getEngine(), null);
  const { t } = mk(); L.setCell(t, t.rows[0].id, t.cols[0].id, { v: 5 });
  const d0 = makeDisplay(t); assert.equal(d0.pending, false); assert.equal(d0.text(0, 0), '5');
  assert.equal(getEngine(), null, 'tab tanpa rumus tidak memuat mesin');
  assert.equal(fxFromA1('=SUM(A1:A2)', t), null); assert.equal(shiftFormula('x', t, 0, 1), null);
});
test('onEngine dipanggil SEKALI saat mesin tiba; sesudahnya sel berumus menghitung; onEngine setelah siap langsung jalan', async () => {
  const { t } = mk(); L.setCell(t, t.rows[0].id, t.cols[0].id, { v: 2 }); L.setCell(t, t.rows[1].id, t.cols[0].id, { v: 3 });
  const fx = (await loadEngine(), fxFromA1('=SUM(A1:A2)', t)); assert.ok(fx, 'rumus A1 diterima mesin');
  assert.ok(getEngine()); L.setCell(t, t.rows[2].id, t.cols[0].id, { fx });
  const d = makeDisplay(t); assert.equal(d.pending, false); assert.equal(d.text(2, 0), '5');
  let n = 0; onEngine(() => { n++; }); assert.equal(n, 1); setEngine({}); assert.equal(n, 1);
});
test('sheetsHaveFx: hanya true bila ada sel berumus; aman untuk data rusak', async () => {
  await loadEngine(); const { sh, t } = mk(); assert.equal(sheetsHaveFx({ a: sh }), false);
  L.setCell(t, t.rows[0].id, t.cols[0].id, { fx: fxFromA1('=1+1', t) }); assert.equal(sheetsHaveFx({ a: sh }), true);
  assert.equal(sheetsHaveFx(null), false); assert.equal(sheetsHaveFx({ a: null, b: { tabs: 5 } }), false);
});
test('kabel: lembar-ui memasang mesin; main memuatnya hanya bila ada lembar berumus (sesudah gambar pertama); ekspor menunggu mesin; to-sheet menunggu mesin', () => {
  assert.match(src('src/js/lembar-ui.js'), /setEngine\(MESIN\)/);
  const m = src('src/js/main.js'); assert.match(m, /if \(sheetsHaveFx\(data\.sheets\)\)/); assert.ok(m.indexOf('sheetsHaveFx(data.sheets)') > m.indexOf('afterFirstPaint(() =>'));
  const s = src('src/js/share.js'); assert.match(s, /if \(sheetsHaveFx\(ctx\.data\.sheets\)\) await loadEngine\(\)/); assert.equal((s.match(/data-sheet\/\.test\(n\.html/g) || []).length, 2);
  assert.match(src('src/js/notes.js'), /if \(!getEngine\(\)\) \{ loadEngine\(\)\.then\(\(\) => tableChip\(id\)/);
  assert.match(src('src/js/notes.js'), /onEngine\(\(\) => \{ if \(ed\.isConnected\) refreshIslands\(ed\)/);
  for (const f of ['lembar', 'lembar-pulau']) assert.doesNotMatch(src('src/js/' + f + '.js'), /rumus\.js/);
});
test('Rev 192b: versi 0.3.121, SCHEMA 18 tetap, tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev193.test.mjs'));
});
