// Tes Rev 17: cadangan otomatis (jadwal, lokasi, riwayat, migrasi skema, mesin tulis dengan Filesystem tiruan).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/logic.js';
import * as S from '../src/js/storage.js';
import { runBackup, maybeAutoBackup } from '../src/js/backup.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const at = (y, mo, d, h = 0, mi = 0) => new Date(y, mo - 1, d, h, mi).getTime();
const DAY = 86400000;
const mkCtx = (patch = {}) => {
  const data = S.emptyData(); Object.assign(data.settings.backup, patch);
  const c = { data, ui: { tab: 'tugas' }, saved: 0, rendered: 0, persist() { c.saved++; }, render() { c.rendered++; } };
  return c;
};
const mkFS = (o = {}) => {
  const f = { writes: [], perm: 0, writeFile: async (a) => { if (o.fail) throw new Error(o.fail); f.writes.push(a); return { uri: 'file:///x/' + a.path }; } };
  if (o.perm) { f.checkPermissions = async () => ({ publicStorage: o.perm }); f.requestPermissions = async () => { f.perm++; return {}; }; }
  return f;
};

// ---- Nama folder ----
await t('cleanFolder: terima nama wajar, bersihkan spasi dan garis miring', () => {
  assert.deepEqual(L.cleanFolder('  Cadangan Kerja '), { ok: true, value: 'Cadangan Kerja' });
  assert.equal(L.cleanFolder('/Kerja//Kelimaa/').value, 'Kerja/Kelimaa');
  assert.equal(L.cleanFolder('Kerja\\Kelimaa').value, 'Kerja/Kelimaa');
});
await t('cleanFolder: tolak kosong, "..", huruf terlarang, terlalu panjang, terlalu dalam', () => {
  for (const bad of ['', '   ', null, '..', 'a/../b', '.', 'a/./b', 'a:b', 'a?b', 'x"y', 'a|b', 'a<b', 'a/b/c/d', 'x'.repeat(61)]) assert.equal(L.cleanFolder(bad).ok, false, String(bad));
});

// ---- Normalisasi + migrasi ----
await t('normalizeBackup: nilai rusak jadi aman, batas minggu/bulan dihormati', () => {
  assert.deepEqual(L.normalizeBackup(undefined), L.emptyBackup());
  assert.deepEqual(L.normalizeBackup('x'), L.emptyBackup());
  const b = L.normalizeBackup({ on: 'ya', every: 999, unit: 'month', base: 'sd-card', folder: '../../etc', lastAt: -5, lastTry: 'x', history: 'bukan' });
  assert.equal(b.on, false); assert.equal(b.every, 12); assert.equal(b.unit, 'month'); assert.equal(b.base, 'documents');
  assert.equal(b.folder, L.BACKUP_FOLDER_DEFAULT); assert.equal(b.lastAt, 0); assert.equal(b.lastTry, 0); assert.deepEqual(b.history, []);
  assert.equal(L.normalizeBackup({ every: 0.2 }).every, 1);
  assert.equal(L.normalizeBackup({ unit: 'week', every: 100 }).every, 52);
});
await t('normalizeBackup: riwayat rusak dibuang, dibatasi 20, teks dipangkas', () => {
  const hist = [{ at: 5, kind: 'auto', ok: true, where: 'D/N', msg: 'a' }, { at: 0, kind: 'auto' }, { at: 6, kind: 'aneh' }, null, { at: 7, kind: 'manual', ok: 1, where: 'x'.repeat(500) }];
  const b = L.normalizeBackup({ history: hist });
  assert.equal(b.history.length, 2); assert.equal(b.history[1].ok, false); assert.equal(b.history[1].where.length, 120);
  const many = Array.from({ length: 50 }, (_, i) => ({ at: i + 1, kind: 'auto', ok: true }));
  assert.equal(L.normalizeBackup({ history: many }).history.length, 20);
});
await t('data v2 tanpa pengaturan cadangan dimigrasi (mati, nilai bawaan), data lain utuh', () => {
  assert.equal(S.SCHEMA, 22);
  const v2 = { version: 2, habits: [], tasks: [{ id: 't', title: 'Tetap' }], notes: [{ id: 'n', title: 'Lama' }], priv: [], trash: [], settings: { days: [1], theme: 'dark', lastReset: '', recent: [], labels: [{ id: 'a', name: 'Kerja' }] } };
  const d = S.normalize(v2);
  assert.equal(d.settings.backup.on, false); assert.equal(d.settings.backup.folder, 'NotesKelimaa');
  assert.equal(d.tasks[0].title, 'Tetap'); assert.equal(d.notes[0].title, 'Lama'); assert.equal(d.settings.labels[0].name, 'Kerja'); assert.equal(d.settings.theme, 'dark');
  assert.equal(S.importJSON(JSON.stringify(v2)).ok, true);
});
await t('simpan lalu muat: pengaturan dan riwayat cadangan bertahan; cadangan ekspor memuatnya', () => {
  const m = new Map(); const st = { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, v) };
  const d = S.emptyData(); Object.assign(d.settings.backup, { on: true, every: 3, unit: 'month', folder: 'Kerja/Kelimaa', lastAt: 123 });
  L.pushBackupHistory(d.settings.backup, { at: 123, kind: 'auto', ok: true, where: 'Dokumen/Kerja/Kelimaa', msg: 'f.json' });
  S.save(d, st); const back = S.load(st).settings.backup;
  assert.equal(back.every, 3); assert.equal(back.unit, 'month'); assert.equal(back.folder, 'Kerja/Kelimaa'); assert.equal(back.history.length, 1);
  assert.equal(S.importJSON(S.exportJSON(d)).data.settings.backup.lastAt, 123);
});

// ---- Jadwal ----
await t('addInterval: minggu, bulan, tanggal 31 dipangkas, kabisat, pergantian tahun', () => {
  assert.equal(L.addInterval(at(2026, 10, 30, 9, 15), 2, 'week'), at(2026, 11, 13, 9, 15));
  assert.equal(L.addInterval(at(2026, 1, 31, 8), 1, 'month'), at(2026, 2, 28, 8));
  assert.equal(L.addInterval(at(2028, 1, 31, 8), 1, 'month'), at(2028, 2, 29, 8));
  assert.equal(L.addInterval(at(2026, 11, 15, 8), 3, 'month'), at(2027, 2, 15, 8));
  assert.equal(L.addInterval(at(2026, 12, 31), 12, 'month'), at(2027, 12, 31));
});
await t('isBackupDue: mati tidak pernah jatuh tempo; belum pernah = langsung; sebelum/sesudah jadwal', () => {
  const now = at(2026, 10, 30, 12);
  assert.equal(L.isBackupDue({ ...L.emptyBackup(), on: false }, now), false);
  assert.equal(L.isBackupDue({ ...L.emptyBackup(), on: true }, now), true);
  const b = { ...L.emptyBackup(), on: true, every: 1, unit: 'week', lastAt: now - 6 * DAY };
  assert.equal(L.isBackupDue(b, now), false);
  assert.equal(L.isBackupDue({ ...b, lastAt: now - 7 * DAY }, now), true);
  assert.equal(L.isBackupDue({ ...b, lastAt: now + DAY }, now), false); // jam HP pernah dimajukan
});
await t('isBackupDue: setelah gagal tidak diulang dalam 1 jam, lalu boleh lagi', () => {
  const now = at(2026, 10, 30, 12);
  const b = { ...L.emptyBackup(), on: true, lastAt: 0, lastTry: now - 10 * 60000 };
  assert.equal(L.isBackupDue(b, now), false);
  assert.equal(L.isBackupDue({ ...b, lastTry: now - 61 * 60000 }, now), true);
});
await t('teks: nama berkas, lokasi, "tiap ...", format tanggal, riwayat dibatasi', () => {
  assert.equal(L.backupAutoName(new Date(2026, 9, 30, 7, 5)), 'notes-kelimaa-2026-10-30-0705.json');
  assert.equal(L.backupWhere({ base: 'documents', folder: 'A/B' }), 'Dokumen/A/B');
  assert.equal(L.backupWhere({ base: 'app', folder: 'X' }), 'Folder aplikasi/X');
  assert.equal(L.backupEveryText({ every: 1, unit: 'week' }), 'Tiap minggu');
  assert.equal(L.backupEveryText({ every: 3, unit: 'month' }), 'Tiap 3 bulan');
  assert.equal(L.formatBackupDate(at(2026, 10, 5, 14, 30)), '5 Okt 2026, 14.30');
  const b = L.emptyBackup(); for (let i = 0; i < 30; i++) L.pushBackupHistory(b, { at: i + 1, kind: 'auto', ok: true });
  assert.equal(b.history.length, 20); assert.equal(b.history[0].at, 30);
});

// ---- Mesin cadangan ----
await t('runBackup: menulis ke Dokumen/<folder>/<nama>.json, recursive, isi sama dengan ekspor; waktu dan riwayat tercatat', async () => {
  const NOW = at(2026, 10, 30, 14, 30), c = mkCtx({ folder: 'Kerja/Kelimaa' }), fs = mkFS();
  c.data.notes.push({ id: 'n1', title: 'Halo' });
  const r = await runBackup(c, 'manual', { FS: fs, native: true, now: () => NOW });
  assert.equal(r.ok, true); assert.equal(fs.writes.length, 1);
  const w = fs.writes[0];
  assert.equal(w.path, 'Kerja/Kelimaa/notes-kelimaa-2026-10-30-1430.json'); assert.equal(w.directory, 'DOCUMENTS'); assert.equal(w.recursive, true); assert.equal(w.encoding, 'utf8');
  assert.equal(JSON.parse(w.data).notes[0].title, 'Halo');
  const b = c.data.settings.backup;
  assert.equal(b.lastAt, NOW); assert.equal(b.lastTry, NOW); assert.equal(b.history[0].ok, true); assert.equal(b.history[0].kind, 'manual'); assert.equal(b.history[0].where, 'Dokumen/Kerja/Kelimaa');
  assert.ok(c.saved >= 1);
});
await t('runBackup: folder aplikasi memakai EXTERNAL', async () => {
  const fs = mkFS(), c = mkCtx({ base: 'app' });
  await runBackup(c, 'auto', { FS: fs, native: true }); assert.equal(fs.writes[0].directory, 'EXTERNAL');
});
await t('runBackup: gagal tulis -> ok:false, waktu sukses TIDAK berubah, gagal tercatat dengan pesan', async () => {
  const c = mkCtx({ lastAt: 111 }), fs = mkFS({ fail: 'Permission denied' });
  const r = await runBackup(c, 'auto', { FS: fs, native: true, now: () => 999 });
  assert.equal(r.ok, false); assert.match(r.msg, /Permission denied/);
  const b = c.data.settings.backup; assert.equal(b.lastAt, 111); assert.equal(b.lastTry, 999);
  assert.equal(b.history[0].ok, false); assert.match(b.history[0].msg, /Permission denied/);
});
await t('runBackup: di peramban (bukan aplikasi) gagal rapi tanpa melempar', async () => {
  const c = mkCtx(); const r = await runBackup(c, 'manual', { native: false });
  assert.equal(r.ok, false); assert.match(r.msg, /aplikasi HP/); assert.equal(c.data.settings.backup.lastAt, 0);
});
await t('runBackup: izin belum diberikan -> diminta sekali; gagal minta izin tidak menghentikan penulisan', async () => {
  const fs = mkFS({ perm: 'prompt' }), c = mkCtx();
  assert.equal((await runBackup(c, 'manual', { FS: fs, native: true })).ok, true); assert.equal(fs.perm, 1);
  const fs2 = mkFS({ perm: 'granted' }); await runBackup(mkCtx(), 'manual', { FS: fs2, native: true }); assert.equal(fs2.perm, 0);
  const fs3 = mkFS(); fs3.checkPermissions = async () => { throw new Error('tidak ada'); };
  assert.equal((await runBackup(mkCtx(), 'manual', { FS: fs3, native: true })).ok, true);
});
await t('runBackup: dua panggilan bersamaan -> yang kedua ditolak, tidak menulis ganda', async () => {
  const fs = mkFS(), c = mkCtx();
  const [a, b2] = await Promise.all([runBackup(c, 'manual', { FS: fs, native: true }), runBackup(c, 'manual', { FS: fs, native: true })]);
  assert.equal([a, b2].filter((x) => x.ok).length, 1); assert.equal(fs.writes.length, 1);
});
await t('maybeAutoBackup: belum waktunya / mati / peramban -> diam, tidak menulis', async () => {
  const NOW = at(2026, 10, 30, 12), fs = mkFS(), msgs = [];
  const d = { FS: fs, native: true, now: () => NOW, toast: (m) => msgs.push(m) };
  assert.equal(await maybeAutoBackup(mkCtx({ on: false }), d), null);
  assert.equal(await maybeAutoBackup(mkCtx({ on: true, every: 2, unit: 'week', lastAt: NOW - 3 * DAY }), d), null);
  assert.equal(await maybeAutoBackup(mkCtx({ on: true }), { ...d, native: false }), null);
  assert.equal(fs.writes.length, 0); assert.equal(msgs.length, 0);
});
await t('maybeAutoBackup: jatuh tempo -> menulis, memberi tahu, jadwal bergeser; render ulang bila sedang di Lainnya', async () => {
  const NOW = at(2026, 10, 30, 12), fs = mkFS(), msgs = [];
  const c = mkCtx({ on: true, every: 2, unit: 'week', lastAt: NOW - 15 * DAY }); c.ui.tab = 'lainnya';
  const r = await maybeAutoBackup(c, { FS: fs, native: true, now: () => NOW, toast: (m) => msgs.push(m) });
  assert.equal(r.ok, true); assert.equal(fs.writes.length, 1); assert.match(msgs[0], /tersimpan di Dokumen\/NotesKelimaa/);
  assert.equal(c.data.settings.backup.history[0].kind, 'auto'); assert.equal(c.rendered, 1);
  assert.equal(L.isBackupDue(c.data.settings.backup, NOW + DAY), false);
  assert.equal(L.isBackupDue(c.data.settings.backup, NOW + 14 * DAY), true);
});
await t('maybeAutoBackup: gagal -> pemberitahuan gagal, dan tidak mengulang saat dibuka lagi dalam 1 jam', async () => {
  const NOW = at(2026, 10, 30, 12), fs = mkFS({ fail: 'Disk penuh' }), msgs = [];
  const c = mkCtx({ on: true });
  const d = { FS: fs, native: true, toast: (m) => msgs.push(m) };
  await maybeAutoBackup(c, { ...d, now: () => NOW }); assert.match(msgs[0], /gagal: Disk penuh/);
  assert.equal(await maybeAutoBackup(c, { ...d, now: () => NOW + 30 * 60000 }), null); assert.equal(msgs.length, 1);
  assert.notEqual(await maybeAutoBackup(c, { ...d, now: () => NOW + 61 * 60000 }), null); assert.equal(msgs.length, 2);
});

// ---- Sambungan ke tampilan ----
await t('sumber: main.js memicu cadangan saat dibuka dan saat kembali; settings.js punya layar Cadangan otomatis, riwayat, folder, minggu/bulan', () => {
  const m = readFileSync(new URL('../src/js/main.js', import.meta.url), 'utf8');
  assert.ok(m.includes("import { maybeAutoBackup } from './backup.js'") && (m.match(/maybeAutoBackup\(ctx\)/g) || []).length === 2);
  const s = readFileSync(new URL('../src/js/settings.js', import.meta.url), 'utf8');
  for (const k of ["moreView === 'backup'", "'Cadangan otomatis'", "'Cadangkan sekarang'", "'Minggu'", "'Bulan'", "'Lokasi penyimpanan'", "'Riwayat'", 'Terakhir dicadangkan', 'cleanFolder(folder.value)', 'sumWhere', "kind: 'share'", 'Notes Kelimaa v0.3.121']) assert.ok(s.includes(k), k);
  assert.equal(JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version, '0.3.121');
});
console.log(n + ' tes cadangan lulus');
