// Rev 178: gabungan sel (dan diagram) tetap bekerja saat FILTER BARIS aktif. Gabungan membentang sebanyak baris yang tampil; isi dari sel jangkar.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as G from '../src/js/lembar-gabung.js';
import * as F from '../src/js/lembar-filter.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { chartData } from '../src/js/lembar-diagram.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = (n = 8) => { const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; while (tab.rows.length < n) L.addRow(tab); return { sh, tab }; };
const put = (tab, r, c, v) => L.setCell(tab, tab.rows[r].id, tab.cols[c].id, { v });

test('mergeView tanpa filter (ord null) = perilaku lama: first=r1, pos=r1, count=tinggi gabungan', () => {
  const { tab } = mk(); put(tab, 1, 0, 'Judul'); assert.equal(L.mergeCells(tab, 1, 0, 3, 1, { clear: true }).ok, true);
  const v = G.mergeView(tab, null); assert.equal(v.list.length, 1); const e = v.list[0];
  assert.deepEqual([e.first, e.pos, e.count, e.r1, e.r2, e.c1, e.c2], [1, 1, 3, 1, 3, 0, 1]); assert.equal(v.map.size, 6); assert.equal(v.map.get('2,1'), e);
});
test('mergeView tanpa gabungan = kosong tanpa biaya', () => {
  const { tab } = mk(); const v = G.mergeView(tab, [0, 2]); assert.equal(v.list.length, 0); assert.equal(v.map.size, 0);
});
test('mergeView dengan filter: membentang sebanyak baris TAMPIL, mulai dari baris tampil pertama; posisi = urutan tampil', () => {
  const { tab } = mk(); L.mergeCells(tab, 2, 0, 5, 0, { clear: true }); // baris 2..5
  const e = G.mergeView(tab, [0, 3, 4, 7]).list[0]; assert.deepEqual([e.first, e.pos, e.count], [3, 1, 2]); // baris 3 dan 4 tampil
  const f = G.mergeView(tab, [0, 2, 5, 6]).list[0]; assert.deepEqual([f.first, f.pos, f.count], [2, 1, 2]); // baris 2 dan 5 tampil (berurutan di tampilan)
});
test('mergeView: baris jangkar tersembunyi tetap menggambar gabungan dari baris tampil pertama; semua tersembunyi = gabungan tidak ada', () => {
  const { tab } = mk(); L.mergeCells(tab, 1, 0, 3, 1, { clear: true });
  const e = G.mergeView(tab, [0, 3, 4]).list[0]; assert.equal(e.first, 3); assert.equal(e.r1, 1); assert.equal(e.count, 1); const w = G.mergeView(tab, [3]); assert.equal(w.map.get('3,1'), w.list[0]); assert.equal(w.map.has('1,0'), true);
  const none = G.mergeView(tab, [0, 4, 5]); assert.equal(none.list.length, 0); assert.equal(none.map.size, 0);
});
test('mergeView: beberapa gabungan, tiap gabungan dihitung sendiri; tidak mengubah tab', () => {
  const { tab } = mk(); L.mergeCells(tab, 0, 0, 1, 0, { clear: true }); L.mergeCells(tab, 4, 1, 6, 2, { clear: true });
  const before = JSON.stringify(tab); const v = G.mergeView(tab, [1, 5, 6, 7]);
  assert.deepEqual(v.list.map((m) => [m.ref, m.first, m.pos, m.count]), [['A1:A2', 1, 0, 1], ['B5:C7', 5, 1, 2]]); assert.equal(JSON.stringify(tab), before);
});
test('filter nyata + mergeView: sel jangkar berisi teks, sel tertutup kosong; filter "Tidak kosong" menyisakan baris jangkar, "Kosong" menyisakan baris tertutup', () => {
  const { tab } = mk(); put(tab, 1, 0, 'Grup A'); L.mergeCells(tab, 1, 0, 3, 0, { clear: true }); const c = tab.cols[0].id, d = makeDisplay(tab);
  const ne = F.filterRows(tab, { c, k: 'nonempty' }, d); assert.deepEqual(ne, [1]); const v1 = G.mergeView(tab, ne).list[0]; assert.deepEqual([v1.first, v1.count], [1, 1]);
  const em = F.filterRows(tab, { c, k: 'empty' }, d); assert.equal(em.includes(1), false); const v2 = G.mergeView(tab, em).list[0]; assert.deepEqual([v2.first, v2.count], [2, 2]); // jangkar tersembunyi, isi tetap dari jangkar
});
test('diagram tidak terpengaruh filter: chartData memakai SEMUA baris dalam rentang; mesin diagram tidak mengenal filter', () => {
  const { tab } = mk(6); for (let r = 0; r < 6; r++) { put(tab, r, 0, 'k' + r); put(tab, r, 1, r + 1); }
  const d = chartData(tab, { r1: 0, c1: 0, r2: 5, c2: 1 }, { valueCol: 1 }); assert.equal(d.ok, true); assert.equal(d.values.length, 6);
  assert.doesNotMatch(src('src/js/lembar-diagram.js'), /getOrder|lembar-filter/);
});
test('kabel UI: gambar grid memakai mergeView(tab, ord) di bawah filter; jangkar dipilih lewat data-ar; spanduk tidak lagi menyebut gabungan disembunyikan; catatan di dialog diagram', () => {
  const ui = src('src/js/lembar-ui.js'); const d = ui.slice(ui.indexOf('const drawRows = () => {'), ui.indexOf('const paintBar = () => {'));
  assert.ok(d.includes('mergeView(tab, ord)') && d.includes('mg.first === r') && d.includes('const sr = mg ? mg.r1 : r, srow = mg ? tab.rows[mg.r1] : row') && d.includes('lay.tops[mg.pos + mg.count] - lay.tops[mg.pos]') && d.includes('el.dataset.ar'));
  assert.ok(!d.includes('!ord &&') && !ui.includes('gabungan sel disembunyikan sementara') && !ui.includes('mergeMap'));
  assert.ok(ui.includes("c.dataset.ar !== undefined ? Number(c.dataset.ar) : Number(rowEl.dataset.r)"));
  assert.ok(ui.includes('Filter baris tidak memengaruhi diagram'));
  const o = ui.slice(ui.indexOf('const openChart = () => {'), ui.indexOf('const tabMenu'));
  assert.ok(!o.includes('getOrder') && !o.includes('filterRows'));
});
test('Rev 178: modul gabung tetap murni; SCHEMA 17; versi 0.3.121; tes terdaftar; tanpa perubahan native/dependensi', () => {
  const g = src('src/js/lembar-gabung.js'); assert.ok(!/^import /m.test(g) && !/localStorage|document|eval\(|new Function|Capacitor/.test(g)); assert.match(g, /Rev 178/);
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev178.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
  assert.deepEqual(Object.keys(JSON.parse(pk).dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
