// Rev 302c / v0.3.121: penutup Paket 302 (petunjuk cara cepat di Lainnya > Bekukan, audit akhir, dokumen).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
test('Lainnya > Bekukan tetap ada dan memberi petunjuk cara cepat lewat Menu sel; status beku tetap ditampilkan', () => {
  assert.match(ui, /item\('beku', 'Bekukan baris & kolom'/); assert.match(ui, /cara cepat: pilih baris\/kolom, tahan/); assert.match(ui, /'beku: ' \+ freezeLabel\(tab\)/);
});
test('CSS tidak berubah dan di bawah anggaran resmi cssMaks 270 KB (Rev 383)', () => { assert.ok(!css.includes('Rev 302c')); assert.ok(Buffer.byteLength(css) < 270 * 1024); });
test('dokumen: README < 12000 huruf; entri Rev 302c di PROMPT dan RIWAYAT; tes terdaftar; versi + SCHEMA tetap', () => {
  const r = src('README.md'); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */); assert.match(r, /Rev 302c/); assert.match(r, /bukan\*\* bukti APK/);
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 302c / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('**Rev 302c / v0.3.121')); // Rev 303a: startsWith -> includes
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev302c\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
console.log('rev302c: ' + n + ' tes');
