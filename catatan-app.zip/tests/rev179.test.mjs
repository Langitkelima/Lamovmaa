// Rev 179a / U10e-1: PILIH RENTANG SEL (modul murni lembar-rentang.js + kabel UI). Hanya di layar; Salin/Tempel rentang = 179b.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as R from '../src/js/lembar-rentang.js';
import * as L from '../src/js/lembar.js';
import { mergeList } from '../src/js/lembar-gabung.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const D = { rows: 20, cols: 6 };

test('makeRange: urut kecil->besar dari dua ujung mana pun, hitung baris/kolom/sel', () => {
  const m = R.makeRange(D, { r: 5, c: 3 }, { r: 2, c: 1 }); assert.equal(m.ok, true); assert.deepEqual(m.rect, { r1: 2, c1: 1, r2: 5, c2: 3 }); assert.deepEqual([m.rows, m.cols, m.cells, m.expanded], [4, 3, 12, false]);
  const one = R.makeRange(D, { r: 1, c: 1 }, { r: 1, c: 1 }); assert.equal(one.ok, true); assert.equal(one.cells, 1);
});
test('makeRange: di luar lembar / ujung tidak sah / terlalu besar ditolak', () => {
  assert.equal(R.makeRange(D, { r: 0, c: 0 }, { r: 20, c: 0 }).reason, 'luar'); assert.equal(R.makeRange(D, { r: 0, c: 0 }, { r: 0, c: 6 }).reason, 'luar');
  assert.equal(R.makeRange(D, null, { r: 0, c: 0 }).reason, 'luar'); assert.equal(R.makeRange(D, { r: -1, c: 0 }, { r: 0, c: 0 }).reason, 'luar'); assert.equal(R.makeRange(D, { r: 0.5, c: 0 }, { r: 0, c: 0 }).reason, 'luar'); assert.equal(R.makeRange(null, { r: 0, c: 0 }, { r: 0, c: 0 }).reason, 'luar');
  const big = R.makeRange({ rows: 500, cols: 26 }, { r: 0, c: 0 }, { r: 499, c: 25 }); assert.equal(big.ok, false); assert.equal(big.reason, 'besar'); assert.equal(big.cells, 13000);
  assert.equal(R.makeRange({ rows: 500, cols: 4 }, { r: 0, c: 0 }, { r: 499, c: 3 }).ok, true); // tepat 2000
});
test('makeRange: gabungan yang tersentuh ikut masuk UTUH (diperluas sampai stabil, termasuk berantai)', () => {
  const merges = [{ r1: 2, c1: 1, r2: 4, c2: 2 }, { r1: 4, c1: 3, r2: 6, c2: 3 }];
  const a = R.makeRange(D, { r: 3, c: 0 }, { r: 3, c: 1 }, merges); assert.deepEqual(a.rect, { r1: 2, c1: 0, r2: 4, c2: 2 }); assert.equal(a.expanded, true);
  const b = R.makeRange(D, { r: 3, c: 2 }, { r: 3, c: 3 }, merges); assert.deepEqual(b.rect, { r1: 2, c1: 1, r2: 6, c2: 3 }); // berantai: gabungan kedua ikut
  const c = R.makeRange(D, { r: 0, c: 0 }, { r: 1, c: 5 }, merges); assert.equal(c.expanded, false); assert.deepEqual(c.rect, { r1: 0, c1: 0, r2: 1, c2: 5 });
});
test('inRect / rectRef / rectSig', () => {
  const r = { r1: 2, c1: 1, r2: 4, c2: 2 }; assert.equal(R.inRect(r, 2, 1), true); assert.equal(R.inRect(r, 4, 2), true); assert.equal(R.inRect(r, 5, 2), false); assert.equal(R.inRect(r, 3, 0), false); assert.equal(R.inRect(null, 0, 0), false);
  assert.equal(R.rectRef(r, L.cellAddr), 'B3:C5'); assert.equal(R.rectRef({ r1: 0, c1: 0, r2: 0, c2: 0 }, L.cellAddr), 'A1'); assert.equal(R.rectRef(null, L.cellAddr), ''); assert.equal(R.rectSig(r), '2:1:4:2'); assert.equal(R.rectSig(null), '-');
});
test('terpasang dengan mergeList sungguhan dan tidak mengubah tab', () => {
  const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; while (tab.rows.length < 8) L.addRow(tab); L.mergeCells(tab, 2, 0, 4, 0, { clear: true });
  const before = JSON.stringify(tab); const m = R.makeRange({ rows: tab.rows.length, cols: tab.cols.length }, { r: 3, c: 0 }, { r: 3, c: 1 }, mergeList(tab));
  assert.deepEqual(m.rect, { r1: 2, c1: 0, r2: 4, c2: 1 }); assert.equal(JSON.stringify(tab), before);
});
test('kabel UI (Rev 258: menu Pilih rentang DIHAPUS): impor rentang, tidak disimpan, tanpa kelas rg per sel', () => {
  const ui = src('src/js/lembar-ui.js'); assert.ok(ui.includes("from './lembar-rentang.js'") && !ui.includes("item('rentang'") && !ui.includes('startRange'));
  const d = ui.slice(ui.indexOf('const pick = (e) => {'), ui.indexOf('// --- Rev 131 / U8a-4c'));
  assert.ok(!d.includes('rngMode') && d.includes('mergeList(tab)'));
  const w = ui.slice(ui.indexOf('const drawRows = () => {'), ui.indexOf('const paintBar = () => {')); assert.ok(!w.includes("' rg'") && w.includes('SX.sig(selx)') && w.includes('paintSelBox()')); // Rev 251 / S2: kelas rg per sel DIGANTI satu lapisan .lz-sel
  assert.ok(!ui.includes('lz-rgb') && !ui.includes("data-f': 'rg-off'") && !ui.includes('rgEl'));
  assert.doesNotMatch(ui.slice(ui.indexOf('const rgClear'), ui.indexOf('const drawRows = () => {')), /hist\.push|touched\(|persist|localStorage/);
  assert.match(src('src/css/styles.css'), /\.lz-sel::before/); assert.doesNotMatch(src('src/css/styles.css'), /\.lz-c\.rg/);
});
test('Rev 179a: modul murni; Salin satu sel (copyCell/pasteClip) tidak diubah; SCHEMA 17; versi 0.3.121; tes terdaftar', () => {
  const g = src('src/js/lembar-rentang.js'); assert.ok(!/^import /m.test(g) && !/localStorage|document|eval\(|new Function|Capacitor/.test(g));
  const al = src('src/js/lembar-alat.js'); assert.ok(al.includes('export function copyCell(tab, r, c, opts = {})') && al.includes('export function pasteClip(tab, clip, r, c, opts = {})') && !al.includes('lembar-rentang'));
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev179.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
  assert.deepEqual(Object.keys(JSON.parse(pk).dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
