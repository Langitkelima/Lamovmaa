// Rev 193a / P3a: ketikan yang menunggu simpan otomatis (400 ms) disimpan saat aplikasi ke latar belakang / pagehide. Berkas rev195 = Rev 193a.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const N = src('src/js/notes.js'), M = src('src/js/main.js');

test('notes.js: penanda dirty diset di auto(), dihapus di save(); flush hanya bila dirty dan editor hidup; flushEditor aman', () => {
  assert.match(N, /let dirty = false;/); assert.match(N, /const save = \(\) => \{\n    dirty = false;/); assert.match(N, /const auto = \(\) => \{ dirty = true; setSv\(false\);/);
  assert.match(N, /current\.flush = \(\) => \{ if \(dirty && alive\) \{ clearTimeout\(tm\); save\(\); \} \};/);
  assert.match(N, /export function flushEditor\(\) \{ try \{ if \(current && current\.flush\) current\.flush\(\); \} catch/);
});
test('main.js: hidden memanggil flushEditor SEBELUM kunci Privat; pagehide juga; impor di baris terpisah', () => {
  assert.match(M, /if \(document\.hidden\) \{ flushEditor\(\); if \(ui\.unlocked\) lockPrivat\(ctx\); \}/);
  assert.match(M, /window\.addEventListener\('pagehide', \(\) => flushEditor\(\)\)/);
  assert.match(M, /import \{ flushEditor \} from '\.\/notes\.js';/);
  assert.match(M, /import \{ viewNotes, openEditor, closeEditor, backEditor, closeEditorMenu, closeSelectMenu, exitSelect \} from '\.\/notes\.js';/);
});
test('Kembali/Tutup tetap menyimpan (prepareExit -> closeEditor); format simpanan tidak berubah (SCHEMA 18)', () => {
  assert.match(src('src/js/exit.js'), /closeEditor\(\);\s+\/\/ menyimpan catatan yang sedang terbuka/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
test('tanpa native/dependensi baru; versi 0.3.121 dan tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(pk.scripts.test, /node tests\/rev195\.test\.mjs/); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
