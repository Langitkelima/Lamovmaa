// Rev 410: kartu TWO POCKETS di bawah kartu Notes Kelimaa, logo + tulisan dari web app Two Pockets, titik status, pilihan hari bulatan centang.
import { readFileSync, existsSync, statSync } from 'node:fs';
import { test } from 'node:test';
import { strict as assert } from 'node:assert';
const rd = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const st = rd('src/js/settings.js'), css = rd('src/css/styles.css');
test('urutan Setelan: judul, kartu Notes Kelimaa, kartu TWO POCKETS, lalu Tema/Cadangan', () => {
  const vs = st.indexOf('export function viewSettings');
  const a = st.indexOf("'Setelan'", vs), b = st.indexOf('sethero mzhero', vs), c = st.indexOf('tpSetCard(ctx, conn),', vs), d = st.indexOf("class: 'mzg'", vs);
  assert.ok(a > 0 && a < b && b < c && c < d, [a, b, c, d].join());
});
test('kartu: logo + tulisan gambar (bukan ikon dompet), titik status, kelas off bila belum tersambung', () => {
  const f = st.slice(st.indexOf('function tpSetCard'), st.indexOf('export function viewSettings'));
  for (const k of ["'img/tp-logo.png'", "'img/tp-teks.png'", "class: 'tp2-dot'", "'tp2' + (conn ? '' : ' off')", "'Tersambung'", "'Belum tersambung'", "class: 'tp2-stats'"]) assert.ok(f.includes(k), k);
  assert.ok(!f.includes('PATH.wallet'));
});
test('gambar ada dan ringan', () => {
  for (const [f, mx] of [['src/img/tp-logo.png', 40000], ['src/img/tp-teks.png', 60000]]) { const u = new URL('../' + f, import.meta.url); assert.ok(existsSync(u), f); assert.ok(statSync(u).size < mx, f); }
});
test('CSS: denyut hijau, kedip merah, gerak dikurangi, tulisan terang/gelap, bulatan centang pilihan hari', () => {
  const b = css.slice(css.indexOf('/* Rev 410'));
  for (const k of ['.tp2{', '@keyframes tp2ping', '@keyframes tp2blink', 'prefers-reduced-motion', '.tp2-word{filter', '[data-theme="dark"] .tp2-word', '.tpday::before{', '.tpday.on::before{', '@keyframes tpPop']) assert.ok(b.includes(k), k);
  assert.ok(!css.includes('.tpday.on::before{content:"\\2713'), 'teks ✓ lama dihapus');
  let n = 0; for (const ch of css) { if (ch === '{') n++; if (ch === '}') n--; } assert.equal(n, 0);
  assert.ok(!css.includes('.tpset'));
});
test('pemasangan: tes terdaftar, SCHEMA tetap, catatan Rev 410', () => {
  assert.match(JSON.parse(rd('package.json')).scripts.test, /node tests\/rev410\.test\.mjs/);
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
  assert.ok(rd('RIWAYAT.md').includes('**Rev 410 /'));
});
