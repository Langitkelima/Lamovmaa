// Rev 40: render() harus meratakan array bersarang dari viewTugas (active.map, finished.map).
// Tanpa flat(), replaceChildren(array) mengubah array jadi teks "[object HTMLDivElement]".
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const main = readFileSync(new URL('../src/js/main.js', import.meta.url), 'utf8');
assert.match(main, /mainEl\.replaceChildren\(\.\.\.body\.flat\(Infinity\)\.filter\(/, 'render meratakan body sebelum replaceChildren');
assert.ok(!/replaceChildren\(\.\.\.body\.filter\(/.test(main), 'tidak ada lagi replaceChildren tanpa flat');
// Bukti perilaku: replaceChildren dengan array bersarang menghasilkan teks, bukan elemen.
class Node_ { constructor(n) { this.n = n; this.nodeType = 1; } toString() { return '[object HTMLDivElement]'; } }
const body = [new Node_('p'), [new Node_('r1'), new Node_('r2')], null, [new Node_('s'), [new Node_('r3')]]];
const lama = body.filter((x) => x != null).map((x) => (x.nodeType ? x : String(x)));
assert.ok(lama.some((x) => typeof x === 'string'), 'cara lama: array jadi teks');
const baru = body.flat(Infinity).filter((x) => x != null && x !== false);
assert.equal(baru.length, 5);
assert.ok(baru.every((x) => x.nodeType === 1), 'cara baru: semua tetap elemen');
console.log('3 tes lulus (render daftar tugas: array bersarang diratakan)');
