// Rev 155 / U10b-4: gabungan TEGAK (dan persegi) digambar menyatu di pulau pratinjau dan ekspor PDF/JPG.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { exportModel, islandModel } from '../src/js/lembar-pulau.js';
import { sheetBlocks, layoutDoc } from '../src/js/export.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const measure = (t, st) => String(t).length * (st.size || 30) * 0.5;
const o = { width: 1240, pageH: 1754, padX: 110, padTop: 120, padBottom: 130, size: 30, titleSize: 46, measure };
function mk() { const sh = L.newSheet({ id: 'sabc123', name: 'Laporan' }), t = sh.tabs[0]; for (let i = 0; i < 4; i++) for (let j = 0; j < 3; j++) L.setCell(t, t.rows[i].id, t.cols[j].id, { v: 'x' + i + j }); return sh; }

test('gabungan tegak A2:A3: jangkar vd, sel lanjutan vu, tidak ada cs; sel kolom lain tidak berubah', () => {
  const sh = mk(), t = sh.tabs[0]; assert.equal(L.mergeCells(t, 1, 0, 2, 0, { clear: true }).ok, true);
  for (const m of [islandModel(sh, 6, 4), exportModel(sh)]) {
    assert.equal(m.rows[1][0].vd, true); assert.equal('vu' in m.rows[1][0], false); assert.equal(m.rows[2][0].vu, true); assert.equal('vd' in m.rows[2][0], false); assert.equal('cs' in m.rows[1][0], false);
    assert.equal('vd' in m.rows[1][1], false); assert.equal('cv' in m.rows[2][0], false); assert.equal(m.rows[2][0].t, '');
  }
});
test('gabungan persegi A2:B4: baris lanjutan membawa cs=2 pada kolom pertama, kolom kedua cv; vd hanya sebelum baris terakhir', () => {
  const sh = mk(), t = sh.tabs[0]; L.mergeCells(t, 1, 0, 3, 1, { clear: true }); const m = exportModel(sh);
  assert.equal(m.rows[1][0].cs, 2); assert.equal(m.rows[1][0].vd, true); assert.equal(m.rows[1][1].cv, true);
  assert.deepEqual([m.rows[2][0].cs, m.rows[2][0].vu, m.rows[2][0].vd, m.rows[2][1].cv], [2, true, true, true]);
  assert.deepEqual([m.rows[3][0].cs, m.rows[3][0].vu, 'vd' in m.rows[3][0]], [2, true, false]);
});
test('gabungan dipotong oleh jendela baris: bagian yang terpotong tidak meninggalkan vd', () => {
  const sh = mk(), t = sh.tabs[0]; L.mergeCells(t, 1, 0, 3, 0, { clear: true }); const m = exportModel(sh, { rows: 3, cols: 3 });
  assert.equal(m.rows.length, 3); assert.equal(m.rows[2][0].vu, true); assert.equal('vd' in m.rows[2][0], false);
});
test('tata letak PDF/JPG: flag vu/vd diteruskan ke sel baris; tanpa gabungan tegak tidak ada flag', () => {
  const sh = mk(), t = sh.tabs[0]; const plain = layoutDoc({ title: 'T', blocks: sheetBlocks(exportModel(sh)) }, o).filter((l) => l.kind === 'tableRow');
  assert.ok(plain.every((r) => r.cells.every((c) => !('vu' in c) && !('vd' in c))));
  L.mergeCells(t, 1, 0, 2, 0, { clear: true });
  const rows = layoutDoc({ title: 'T', blocks: sheetBlocks(exportModel(sh)) }, o).filter((l) => l.kind === 'tableRow');
  assert.equal(rows[1].cells[0].vd, true); assert.equal(rows[2].cells[0].vu, true); assert.equal(rows[2].cells.length, 3); assert.equal('vu' in rows[1].cells[1], false);
});
test('penggambar: garis atas/bawah per sel hanya bila ada gabungan tegak; CSS pulau; modul tanpa penyimpanan; versi 0.3.121, SCHEMA 16', () => {
  const sh = src('src/js/share.js'); assert.ok(sh.includes('c.vu || c.vd') && sh.includes('if (!c.vu) seg(') && sh.includes('if (!c.vd) seg(') && sh.includes('} else g.strokeRect(l.x, y, l.w, l.lh);'));
  assert.match(src('src/css/styles.css'), /\.ksheet \.ks-c\.vd\{border-bottom-color:transparent\}/); assert.ok(src('src/js/lembar-pulau.js').includes("classList.add('vd')"));
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev155.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
});
