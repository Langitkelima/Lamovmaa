import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { islandModel, islandText, setSheetsSource, sheetById, PREVIEW_ROWS, PREVIEW_COLS } from '../src/js/lembar-pulau.js';
import { parseNoteHtml } from '../src/js/export.js';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

function sample() {
  const sh = L.newSheet({ id: 'sabc123', name: 'Anggaran' });
  const t = sh.tabs[0];
  L.setCell(t, 'r1', 'cA', { v: 'Item', s: { b: true } });
  L.setCell(t, 'r1', 'cB', { v: 12.5, s: { bg: '#FDE68A', ha: 'end' } });
  L.setCell(t, 'r2', 'cA', { v: true });
  return sh;
}

test('Rev 122: isSheetId menerima ID lembar kerja yang sah dan menolak yang berbahaya', () => {
  assert.equal(L.isSheetId('sabc123'), true);
  for (const bad of ['', 'ab', 'A_B', 'x"onload="1', '<s>', null, undefined, 42, 'a'.repeat(30)]) assert.equal(L.isSheetId(bad), false);
});

test('Rev 122: model pratinjau memakai tab pertama, batas 6x4, minimal 3x3, koma desimal', () => {
  const m = islandModel(sample());
  assert.equal(m.name, 'Anggaran'); assert.equal(m.tab, 'Lembar 1'); assert.equal(m.tabs, 1);
  assert.equal(m.nr, 3); assert.equal(m.nc, 3); assert.equal(m.empty, false);
  assert.deepEqual(m.cols, ['A', 'B', 'C']);
  assert.equal(m.rows[0][0].t, 'Item'); assert.equal(m.rows[0][0].b, true);
  assert.equal(m.rows[0][1].t, '12,5'); assert.equal(m.rows[0][1].bg, '#FDE68A'); assert.equal(m.rows[0][1].ha, 'end');
  assert.equal(m.rows[1][0].t, 'TRUE');
  const big = L.newSheet({ id: 'sbig999' }); const t = big.tabs[0];
  L.setCell(t, 'r20', 'cH', { v: 'jauh' });
  const mb = islandModel(big);
  assert.equal(mb.nr, PREVIEW_ROWS); assert.equal(mb.nc, PREVIEW_COLS); assert.equal(mb.moreRows, true); assert.equal(mb.moreCols, true);
  const empty = islandModel(L.newSheet({ id: 'sempty1' }));
  assert.equal(empty.empty, true); assert.equal(empty.nr, 3); assert.equal(empty.nc, 3);
});

test('Rev 122: warna selain #RRGGBB tidak diteruskan ke pratinjau; lembar tak ada = null', () => {
  const sh = sample(); sh.tabs[0].rows[0].cells.cA.s = { bg: 'red', fg: 'url(x)' };
  const m = islandModel(sh); assert.equal(m.rows[0][0].bg, ''); assert.equal(m.rows[0][0].fg, '');
  assert.equal(islandModel(null), null); assert.equal(islandModel({ tabs: [] }), null);
  assert.equal(islandText(null), 'Lembar kerja'); assert.equal(islandText(sample()), 'Lembar kerja: Anggaran');
});

test('Rev 122: sheetById hanya membaca kunci sendiri dari sumber data', () => {
  setSheetsSource(() => ({ sabc123: sample() }));
  assert.equal(sheetById('sabc123').name, 'Anggaran');
  assert.equal(sheetById('constructor'), null); assert.equal(sheetById('__proto__'), null); assert.equal(sheetById('sxxxxxx'), null);
  setSheetsSource(() => { throw new Error('rusak'); }); assert.equal(sheetById('sabc123'), null);
});

test('Rev 122: notes.js memasang registri, sanitize, tombol Sisipkan (bukan Privat), buka layar penuh', () => {
  const notes = read('../src/js/notes.js');
  assert.match(notes, /registerBlock\(\{ type: 'sheet', selector: '\.ksheet'/);
  assert.match(notes, /k === 'data-sheet' && LZ\.isSheetId\(v\) && c\.classList\.contains\('ksheet'\)/);
  assert.match(notes, /isP \? \[\] : \[insertBtn\('sheet', 'Lembar kerja'\)\]/);
  assert.match(notes, /else if \(kind === 'sheet' && !isP\) insertSheet\(\)/);
  assert.match(notes, /setSheetsSource\(\(\) => ctx\.data\.sheets\);[^\n]*\n\s*if \(n\.html\) ed\.innerHTML = sanitize\(n\.html\)/);
  assert.match(notes, /openLembar\(\{ sheet: sh, onChange: \(\) => ctx\.persist\(\), onClose: \(\) => refreshIslands\(ed\)/);
  assert.match(notes, /const BLOCK_SEL = '\.kb-date-block,\.kb-time-block,\.kb-countdown-block,\.mood-block,\.lk-card'/); // tidak diubah
});

test('Rev 122: pulau tidak memakai table/td/th/input (alat tabel catatan tidak boleh tertipu)', () => {
  const src = read('../src/js/lembar-pulau.js');
  assert.doesNotMatch(src, /createElement\('(table|td|th|tr|input)'\)|mk\('(table|td|th|tr|input)'/);
  assert.match(src, /el\.replaceChildren\(\)/); // strip: tak ada isi sel di HTML tersimpan
});

test('Rev 122: pulau kosong yang tersimpan tidak merusak ekspor lama (belum diekspor = U7b-4)', () => {
  const blocks = parseNoteHtml('<p>Halo</p><div class="ksheet" contenteditable="false" data-sheet="sabc123"></div><p>Dunia</p>');
  const text = blocks.map((b) => (b.runs || []).map((r) => r.t).join('')).join('|');
  assert.match(text, /Halo/); assert.match(text, /Dunia/);
});
