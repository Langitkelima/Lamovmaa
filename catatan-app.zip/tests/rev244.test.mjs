// Rev 244: plafon server HARD_DAILY_LIMIT + allowBackup=false. Node saja: manifest Android TIDAK dikompilasi/diuji di sini.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
import * as K from '../src/js/ai/sambungan.js';
import { ensureNoBackup, ensureAdjustResize, ensureInternetPermission } from '../scripts/apply-native.mjs';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('hardCap/limitFor: tanpa variabel = perilaku lama; plafon membatasi angka besar dan Tanpa batas (0)', () => {
  for (const v of [undefined, '', 'abc', '0', -4, NaN]) assert.equal(T.hardCap({ HARD_DAILY_LIMIT: v }), 0, String(v));
  assert.equal(T.limitFor({}, { limit: 0 }), 0); assert.equal(T.limitFor({}, { limit: 500 }), 500); assert.equal(T.limitFor({}, {}), 100);
  const e = { HARD_DAILY_LIMIT: '150' };
  assert.equal(T.limitFor(e, { limit: 0 }), 150); assert.equal(T.limitFor(e, { limit: 500 }), 150); assert.equal(T.limitFor(e, { limit: 80 }), 80); assert.equal(T.limitFor(e, {}), 100); assert.equal(T.limitFor({ HARD_DAILY_LIMIT: '50' }, {}), 50);
  assert.equal(T.hardCap({ HARD_DAILY_LIMIT: '99999' }), 10000);
});
test('ujung ke ujung: dengan plafon 2, Tanpa batas dari aplikasi tetap ditolak di permintaan ke-3 (429) tanpa memanggil penyedia', async () => {
  const m = new Map(), KV = { get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } };
  const env = { PASS_RAMA: 'rama-secret-12', KV, GEMINI_KEY: 'gm-FAKE-0123456789-tes', HARD_DAILY_LIMIT: '2' };
  let calls = 0; const orig = globalThis.fetch; globalThis.fetch = async () => { calls++; return { ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'ok' } }], usage: {} }) }; };
  const go = async () => { const r = await T.handle(new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', limit: 0, messages: [{ role: 'user', content: 'Hai' }] }) }), env, Date.UTC(2026, 10, 12, 5)); return { s: r.status, j: await r.json() }; };
  try { const a = await go(), b = await go(), c = await go(); assert.equal(a.s, 200); assert.equal(a.j.limit, 2); assert.equal(b.s, 200); assert.equal(c.s, 429); assert.match(c.j.error, /Batas harian tercapai \(2\/2\)/); assert.equal(calls, 2); } finally { globalThis.fetch = orig; }
});
test('whoami membawa hardLimit hanya bila plafon diatur; aplikasi menampilkannya di Tes sambungan', async () => {
  const run = async (env) => (await T.handle(new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'whoami' }) }), { PASS_RAMA: 'rama-secret-12', ...env }, Date.UTC(2026, 10, 12, 5))).json();
  assert.equal('hardLimit' in await run({}), false); assert.equal((await run({ HARD_DAILY_LIMIT: '150' })).hardLimit, 150);
  const conn = { url: 'https://kelimaa-ai.akun.workers.dev', key: 'rama-secret-12' };
  const mk = (o) => async (r) => (r.method === 'GET' ? { status: 200, text: '{"ok":true,"app":"KELIMAA AI","v":1}' } : { status: 200, text: JSON.stringify({ ok: true, me: 'rama', limit: 100, used: 1, kv: true, ...o }) });
  const a = await K.testConnection(conn, mk({ hardLimit: 150 })); assert.equal(a.info.hardLimit, 150); assert.match(a.steps[2].msg, /Plafon server: 150\/hari/);
  const b = await K.testConnection(conn, mk({})); assert.equal('hardLimit' in b.info, false); assert.doesNotMatch(b.steps[2].msg, /Plafon/);
});
test('ensureNoBackup: menambah, mengganti true jadi false, idempoten, tidak merusak atribut/ubahan lain', () => {
  const m = '<manifest>\n    <application android:label="x" android:icon="@mipmap/ic" android:theme="@style/T">\n        <activity android:name=".Main" />\n    </application>\n</manifest>';
  const a = ensureNoBackup(m); assert.match(a, /<application android:allowBackup="false" android:label="x"/); assert.equal((a.match(/allowBackup/g) || []).length, 1); assert.equal(ensureNoBackup(a), a);
  const t = ensureNoBackup('<application android:allowBackup="true" android:label="x">'); assert.equal(t, '<application android:allowBackup="false" android:label="x">');
  assert.equal(ensureNoBackup('<manifest/>'), '<manifest/>');
  const c = ensureNoBackup(ensureAdjustResize(ensureInternetPermission(m))); assert.match(c, /INTERNET/); assert.match(c, /adjustResize/); assert.match(c, /allowBackup="false"/); assert.match(c, /<uses-permission[^>]*INTERNET[^>]*\/>\s*<application android:allowBackup="false"/);
});
test('apply-native memakai ensureNoBackup; tes terdaftar; versi 0.3.121', () => {
  const a = src('scripts/apply-native.mjs'); assert.match(a, /ensureNoBackup\(ensureShareIntentFilter/); assert.match(a, /Pencadangan otomatis Android/);
  const pk = JSON.parse(src('package.json')); assert.match(pk.scripts.test, /node tests\/rev244\.test\.mjs/); assert.equal(pk.version, '0.3.121');
});
