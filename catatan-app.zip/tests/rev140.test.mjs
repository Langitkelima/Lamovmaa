// Rev 140: singkatan nominal saat mengetik di sel: 6e5, 1,5e3, 5rb, 1,5jt (murni di lembar-format.js, dipakai parseInput).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { typedShorthand } from '../src/js/lembar-format.js';
import { parseInput } from '../src/js/lembar-ui.js';
import * as A from '../src/js/lembar-alat.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('notasi e: pangkat = jumlah nol; desimal titik/koma; tepat tanpa galat floating', () => {
  assert.equal(typedShorthand('6e5'), 600000); assert.equal(typedShorthand('3e3'), 3000); assert.equal(typedShorthand('3e2'), 300); assert.equal(typedShorthand('6E5'), 600000);
  assert.equal(typedShorthand('1,5e3'), 1500); assert.equal(typedShorthand('1.5e3'), 1500); assert.equal(typedShorthand('2e-2'), 0.02); assert.equal(typedShorthand('-4e3'), -4000); assert.equal(typedShorthand('+2e1'), 20);
  assert.equal(typedShorthand('1.1e1'), 11); assert.equal(typedShorthand('0e5'), 0); assert.equal(Object.is(typedShorthand('-0e5'), 0), true);
});
test('rb/ribu/jt/juta: ribuan dan jutaan, spasi opsional, huruf besar/kecil, desimal tepat', () => {
  assert.equal(typedShorthand('5rb'), 5000); assert.equal(typedShorthand('600rb'), 600000); assert.equal(typedShorthand('5 ribu'), 5000); assert.equal(typedShorthand('2jt'), 2000000);
  assert.equal(typedShorthand('1,5jt'), 1500000); assert.equal(typedShorthand('2,25 Juta'), 2250000); assert.equal(typedShorthand('0,5rb'), 500); assert.equal(typedShorthand('1.1jt'), 1100000); assert.equal(typedShorthand('-3JT'), -3000000);
});
test('bukan singkatan = null (tetap teks): kata lain, tanpa angka, pangkat di luar batas, terlalu besar, k/m tidak dikenal', () => {
  for (const x of ['e5', '6e', '6e+', '5rbt', 'rb', '5 rb x', '5k', '2m', '5miliar', 'abc3e3', '3e3x', '6e16', '6e-7', '1e15', '9999999999jt', '12', '', '   ', '1e1e1', '1,2,3e3', '5 r b']) assert.equal(typedShorthand(x), null, JSON.stringify(x));
  assert.equal(typedShorthand(null), null); assert.equal(typedShorthand(undefined), null); assert.equal(typedShorthand('9'.repeat(30) + 'e3'), null);
});
test('parseInput: singkatan jadi angka; angka biasa, teks, kode bernol, rumus tidak berubah', () => {
  assert.equal(parseInput('6e5'), 600000); assert.equal(parseInput(' 1,5jt '), 1500000); assert.equal(parseInput('5rb'), 5000);
  assert.equal(parseInput('12'), 12); assert.equal(parseInput('3,5'), 3.5); assert.equal(parseInput('Halo'), 'Halo'); assert.equal(parseInput('007a'), '007a'); assert.equal(parseInput('=A1+1'), '=A1+1');
  assert.equal(parseInput('5k'), '5k'); assert.equal(parseInput('e5'), 'e5'); assert.equal(typeof parseInput('1234567890123456789'), 'string'); assert.equal(parseInput(''), null);
});
test('impor CSV TIDAK memakai singkatan (berkas dibaca apa adanya)', () => {
  assert.equal(A.cellFromText('6e5'), '6e5'); assert.equal(A.cellFromText('5rb'), '5rb'); assert.doesNotMatch(src('src/js/lembar-alat.js'), /typedShorthand/);
});
test('keamanan: modul format tetap murni; hanya parseInput yang memakai singkatan', () => {
  const f = src('src/js/lembar-format.js'); assert.doesNotMatch(f, /\beval\s*\(|new Function|document\.|localStorage|window\./);
  assert.match(src('src/js/lembar-ui.js'), /const sh = typedShorthand\(t\); if \(sh !== null\) return sh;/);
});
