// Rev 232 / Tahap 6b: sisi aplikasi Research (mode Cari di web, kartu sumber, label belum terverifikasi). Tanpa jaringan, tanpa DOM.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as S from '../src/js/ai/sambungan.js';
import * as Q from '../src/js/ai/riset.js';
import { noteDraft, taskDrafts } from '../src/js/ai/aksi.js';
import { rowDrafts } from '../src/js/ai/baris.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const conn = { url: 'https://w.example.workers.dev', key: 'rama-secret-12' };
const GOOD = { ok: true, text: 'Spanyol juara.', sources: [{ title: 'uefa.com', uri: 'https://v.example/a' }, { title: 'aljazeera.com', uri: 'https://v.example/b' }], queries: ['euro 2024 winner'], grounded: true, model: 'gemini-3.5-flash', provider: 'gemini', used: 3, limit: 100 };

test('cleanSources: hanya https, unik, maks. 10, judul dibersihkan; tautan berbahaya dibuang', () => {
  const raw = [{ title: 'A|*b', uri: 'https://x.example/1' }, { title: 'dobel', uri: 'https://x.example/1' }, { title: 'j', uri: 'javascript:alert(1)' }, { title: 'h', uri: 'http://x.example/2' }, { title: '', uri: 'https://x.example/3' }, null, 5, { uri: 7 }];
  const c = Q.cleanSources(raw); assert.deepEqual(c.map((x) => x.uri), ['https://x.example/1', 'https://x.example/3']); assert.equal(c[0].title, 'A b'); assert.equal(c[1].title, 'Sumber');
  assert.equal(Q.cleanSources(Array.from({ length: 15 }, (_, i) => ({ title: 't', uri: 'https://x.example/' + i }))).length, Q.SRC_MAX); assert.deepEqual(Q.cleanSources(null), []);
});
test('researchText: ada sumber = baris Sumber (nama unik); tanpa sumber = label belum terverifikasi', () => {
  assert.equal(Q.researchText(GOOD), 'Spanyol juara.\n\n**Sumber:** uefa.com, aljazeera.com');
  assert.equal(Q.researchText({ text: 'Mungkin.', sources: [] }), 'Mungkin.\n\n' + Q.UNVERIFIED); assert.match(Q.UNVERIFIED, /Belum terverifikasi/);
  assert.equal(Q.researchText({ text: 'x', sources: [{ title: 'UEFA.com', uri: 'https://a/1' }, { title: 'uefa.com', uri: 'https://a/2' }] }), 'x\n\n**Sumber:** UEFA.com'); assert.equal(Q.researchText({ text: '  ' }), ''); assert.equal(Q.researchText(null), '');
});
test('grounded dihitung ULANG dari sumber sah, bukan dipercaya dari Worker', () => {
  assert.equal(Q.isGrounded({ grounded: true, sources: [{ title: 'j', uri: 'javascript:x' }] }), false); assert.equal(Q.isGrounded(GOOD), true); assert.equal(Q.isGrounded({}), false);
  assert.match(Q.researchText({ text: 'x', grounded: true, sources: [{ title: 'j', uri: 'http://a' }] }), /Belum terverifikasi/);
});
test('baris Sumber/label tidak menjadi tugas, baris lembar, atau judul catatan; catatan menyimpan teks bersih', () => {
  const t = Q.researchText({ text: '- Beli kopi\n- Beli roti', sources: GOOD.sources });
  assert.deepEqual(taskDrafts(t), ['Beli kopi', 'Beli roti']); assert.deepEqual(rowDrafts(t).map((x) => x.cells[0]), ['Beli kopi', 'Beli roti']);
  const d = noteDraft(Q.researchText(GOOD)); assert.match(d.text, /Sumber: uefa\.com, aljazeera\.com/); assert.doesNotMatch(d.text, /\*\*/);
  const u = noteDraft(Q.researchText({ text: 'Jawaban pendek.', sources: [] })); assert.match(u.text, /Belum terverifikasi/);
});
test('queriesLine: maks. 5 kueri, dibersihkan; kosong = ""', () => {
  assert.equal(Q.queriesLine(GOOD), 'pencarian: euro 2024 winner'); assert.equal(Q.queriesLine({ queries: ['a', 'b', 'c', 'd', 'e', 'f'] }), 'pencarian: a / b / c / d / e'); assert.equal(Q.queriesLine({}), '');
});
test('kirimRiset: kirim {action:research, messages, limit} TANPA provider/model/task; jawaban diurai', async () => {
  let sent = null; const http = async (r) => { sent = r; return { status: 200, text: JSON.stringify(GOOD) }; };
  const r = await S.kirimRiset(conn, [{ role: 'user', content: 'Halo' }], http, { limit: 0, provider: 'sakelar', model: 'x/y-model', task: 'analysis.general' });
  const b = JSON.parse(sent.body); assert.equal(b.action, 'research'); assert.equal(b.limit, 0); assert.equal(b.provider, undefined); assert.equal(b.model, undefined); assert.equal(b.task, undefined); assert.equal(sent.url, 'https://w.example.workers.dev/');
  assert.equal(r.ok, true); assert.equal(r.text, 'Spanyol juara.'); assert.equal(r.sources.length, 2); assert.equal(r.grounded, true); assert.equal(r.model, 'gemini-3.5-flash'); assert.equal(r.used, 3);
});
test('kirimRiset: galat Worker, jawaban asing, Worker lama, jaringan putus, input salah = {ok:false,msg}, tidak melempar', async () => {
  const mk = (st, o) => async () => ({ status: st, text: typeof o === 'string' ? o : JSON.stringify(o) });
  assert.match((await S.kirimRiset(conn, [{ role: 'user', content: 'a' }], mk(503, { ok: false, error: 'Riset butuh kunci Gemini Google di Worker (Secret GEMINI_KEY).' }))).msg, /GEMINI_KEY/);
  assert.match((await S.kirimRiset(conn, [{ role: 'user', content: 'a' }], mk(400, { ok: false, error: 'Aksi tidak dikenal' }))).msg, /Aksi tidak dikenal/);
  assert.match((await S.kirimRiset(conn, [{ role: 'user', content: 'a' }], mk(200, '<html>')) ).msg, /Rev 231/);
  assert.match((await S.kirimRiset(conn, [{ role: 'user', content: 'a' }], mk(401, { ok: false, error: 'Passcode salah' }))).msg, /Passcode salah/);
  assert.match((await S.kirimRiset(conn, [{ role: 'user', content: 'a' }], async () => { throw new Error('timeout'); })).msg, /60 detik/);
  assert.equal((await S.kirimRiset({ url: 'x', key: 'y' }, [{ role: 'user', content: 'a' }], async () => ({}))).ok, false); assert.equal((await S.kirimRiset(conn, [], async () => ({}))).ok, false);
});
test('obrolan.js: tombol Cari di web (mati bawaan), riset TIDAK memakai konteks data, chip sumber lewat openExternal, tanpa HTML mentah', () => {
  const o = src('src/js/ai/obrolan.js');
  assert.match(o, /let web = false/); assert.match(o, /'aria-label': 'Cari di web'/); assert.match(o, /kirimRiset\(conn, buildMessages\(riwayat, c\.value\)/); assert.match(o, /openExternal\(x\.uri\)/); assert.match(o, /ev\.stopPropagation\(\)/);
  const i = o.indexOf('if (cari) { res = await kirimRiset'), j = o.indexOf('else if (ab) {'); assert.ok(i > 0 && j > i && o.indexOf('else { const cx = buildContext') > j); // Rev 306b: cabang riset berakhir di sini; cabang lampiran (konteks + lampiran) menyusul assert.doesNotMatch(o.slice(i, j), /buildContext|attachContext|loadPerms/);
  assert.match(o, /h\('div', \{ class: 'kc-dock' \}, kc, kw, ta, send\)/); assert.doesNotMatch(o, /innerHTML|insertAdjacentHTML|outerHTML/);
  const q = src('src/js/ai/riset.js'); assert.doesNotMatch(q, /document\.|window\.|localStorage|fetch\(|innerHTML/);
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\//); assert.doesNotMatch(src('src/js/notes.js'), /from '\.\/ai\//);
});
test('CSS Rev 232 seimbang, tanpa warna heks/blur; tes terdaftar', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 232'); assert.ok(i > 0); const r = css.slice(i); assert.doesNotMatch(r, /#[0-9a-fA-F]{6}|backdrop-filter|blur\(/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0); assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev232\.test\.mjs/);
});
