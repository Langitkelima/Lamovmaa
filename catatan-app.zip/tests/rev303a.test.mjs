// Rev 303a / v0.3.121: KOTAK CENTANG di sel lembar kerja, bagian 1 = model + mesin (tanpa UI, tanpa CSS, SCHEMA 22 tetap).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as V from '../src/js/lembar-validasi.js';
import * as K from '../src/js/lembar-kotak.js';
import * as L from '../src/js/lembar.js';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet({ id: 'k', name: 'K' }), tab = sh.tabs[0]; return { sh, tab, cid: tab.cols[0].id }; };
test("kriteria 'box' sah: dibersihkan jadi { id, c, k, items: [], dd: false }; rentang rg ikut; kriteria lain tetap", () => {
  const { tab, cid } = mk(); tab.checks = [{ id: 'v1abc', c: cid, k: 'box' }, { id: 'v2abc', c: tab.cols[1].id, k: 'email' }]; const out = V.cleanChecks(tab.checks, tab.cols, tab.rows);
  assert.deepEqual(out[0], { id: 'v1abc', c: cid, k: 'box', items: [], dd: false }); assert.equal(out[1].k, 'email'); assert.ok(V.KINDS.includes('box'));
  assert.equal(V.cleanChecks([{ k: 'box', c: 'tidak-ada' }], tab.cols, tab.rows).length, 0);
});
test('validate: kosong sah; boolean dan teks TRUE/FALSE sah; teks lain tidak sah', () => {
  const ck = { k: 'box', c: 'a', items: [], dd: false };
  assert.equal(V.validate(ck, '').ok, true); assert.equal(V.validate(ck, 'TRUE', true).ok, true); assert.equal(V.validate(ck, 'false', false).ok, true); assert.equal(V.validate(ck, 'True').ok, true);
  assert.equal(V.validate(ck, 'abc', 'abc').ok, false); assert.equal(V.validate(ck, '1', 1).ok, false);
  assert.equal(V.kindLabel('box'), 'Kotak centang'); assert.match(V.checkText(ck, 'A'), /kotak centang/);
});
test('boxState / nextBoxValue: kosong -> true, true -> false, false -> true; teks TRUE terbaca; selalu boolean sungguhan', () => {
  assert.equal(K.boxState(true), true); assert.equal(K.boxState('TRUE'), true); assert.equal(K.boxState(' true '), true); assert.equal(K.boxState(false), false); assert.equal(K.boxState(undefined), false); assert.equal(K.boxState('x'), false); assert.equal(K.boxState(1), false);
  assert.equal(K.nextBoxValue(undefined), true); assert.equal(K.nextBoxValue(true), false); assert.equal(K.nextBoxValue(false), true); assert.equal(K.nextBoxValue('TRUE'), false); assert.equal(typeof K.nextBoxValue('x'), 'boolean');
  assert.equal(K.isBox({ k: 'box' }), true); assert.equal(K.isBox({ k: 'list' }), false); assert.equal(K.isBox(null), false);
});
test('boxTally menghitung tercentang dari daftar sel', () => {
  const raw = { '0,0': true, '1,0': false, '2,0': 'TRUE', '3,0': undefined };
  assert.deepEqual(K.boxTally([[0, 0], [1, 0], [2, 0], [3, 0]], (i, j) => raw[i + ',' + j]), { done: 2, total: 4 }); assert.deepEqual(K.boxTally(null, () => 0), { done: 0, total: 0 });
});
test('nilai boolean tersimpan di sel dan lolos pembersih; mengetuk dua kali kembali ke awal', () => {
  const { tab, cid } = mk(), rid = tab.rows[0].id; L.setCell(tab, rid, cid, { v: K.nextBoxValue(tab.rows[0].cells[cid] && tab.rows[0].cells[cid].v) });
  assert.equal(tab.rows[0].cells[cid].v, true); L.setCell(tab, rid, cid, { v: K.nextBoxValue(true) }); assert.equal(tab.rows[0].cells[cid].v, false);
  assert.equal(JSON.parse(JSON.stringify(tab)).rows[0].cells[cid].v, false);
});
test('invalidCells menandai sel berisi teks lain di rentang kotak centang, bukan boolean/kosong', () => {
  const { tab, cid } = mk(); tab.checks = V.cleanChecks([{ id: 'v1abc', c: cid, k: 'box' }], tab.cols, tab.rows);
  const raw = { '0': true, '1': false, '2': 'abc' }; const bad = V.invalidCells(tab, (i, j) => (j === 0 && raw[i] !== undefined ? String(raw[i]).toUpperCase() === 'ABC' ? 'abc' : String(raw[i]).toUpperCase() : ''), (i, j) => (j === 0 ? raw[i] : undefined));
  assert.ok(bad.has('2,0')); assert.ok(!bad.has('0,0')); assert.ok(!bad.has('1,0'));
});
test('anggaran: pembantu ada di modul MALAS lembar-kotak.js (tanpa impor), bukan di lembar-validasi.js; CSS dan SCHEMA tidak berubah', () => {
  assert.ok(!/^import /m.test(src('src/js/lembar-kotak.js'))); assert.ok(!src('src/js/lembar-validasi.js').includes('boxTally'));
  assert.ok(!src('src/css/styles.css').includes('Rev 303a')); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  const imp = [...src('src/js/main.js').matchAll(/from '\.\/([^']+)'/g)].map((m) => m[1]); assert.ok(!imp.includes('lembar-kotak.js'), 'tidak diimpor statis dari main.js');
});
test('dokumen: README < 12000 huruf; entri Rev 303a di PROMPT dan RIWAYAT; tes terdaftar; versi tetap', () => {
  const r = src('README.md'); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */); assert.match(r, /Rev 303a/); assert.match(r, /bukan\*\* bukti APK/);
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 303a / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('**Rev 303a / v0.3.121'));
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev303a\.test\.mjs/);
});
console.log('rev303a: ' + n + ' tes');
