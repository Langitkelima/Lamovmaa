import assert from 'node:assert/strict';
import { test } from 'node:test';
import fs from 'node:fs';
const src = (f) => fs.readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const css = src('src/css/styles.css'), main = src('src/js/main.js');
test('Rev 95: CSS navbar Bingkai Neon ada di paling bawah styles.css', () => {
  const i = css.indexOf('Rev 95: navbar'); assert.ok(i > 0);
  const tail = css.slice(i);
  for (const k of ['border:2px solid transparent', 'var(--onbg) border-box', '.navbg{display:none}', '.navind::before{display:none}', 'nav button span{display:none}', 'nav button.lit svg,nav button.on svg{stroke:var(--onfg);transform:scale(1.12)}']) assert.ok(tail.includes(k), k);
});
test('Rev 95: navPaint melewati gambar lekukan bila .navbg disembunyikan', () => {
  assert.ok(main.includes("getComputedStyle(svg).display !== 'none'"));
});
test('Rev 95: ikon aplikasi Putih Fajar lengkap (termasuk monokrom) dan XML adaptif', () => {
  for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
    for (const f of ['ic_launcher', 'ic_launcher_round', 'ic_launcher_bglayer', 'ic_launcher_foreground', 'ic_launcher_monochrome']) assert.ok(fs.existsSync(new URL(`../resources/android/res/mipmap-${d}/${f}.png`, import.meta.url)), d + f);
    assert.ok(fs.existsSync(new URL(`../resources/android/res/drawable-${d}/ic_stat_kelimaa.png`, import.meta.url)));
  }
  assert.ok(src('resources/android/res/mipmap-anydpi-v26/ic_launcher.xml').includes('ic_launcher_monochrome'));
  assert.ok(src('resources/android/res/values/ic_launcher_background.xml').includes('#F6F9FD'));
  assert.ok(fs.existsSync(new URL('../assets/logo-512.png', import.meta.url)));
});
test('Rev 95: versi 0.3.9', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('RIWAYAT.md').includes('Rev 95 / 0.3.9'));
});
