// Rev 101 / U5a: mesin "Ingatkan saya" murni (src/js/ingatkan.js). Belum ada UI, SCHEMA belum berubah. Semua waktu LOKAL (new Date(y,m,d,h,mi)).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as I from '../src/js/ingatkan.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const L = (y, m, d, h = 0, mi = 0) => new Date(y, m - 1, d, h, mi, 0, 0).getTime(); // bulan 1-12
const iso = (ts) => { const d = new Date(ts); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0') + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };

test('Rev 101: normalizeCbRule dan cleanCbRem: aturan valid, sticky selalu false, cid asing dibuang, maks. 30', () => {
  assert.deepEqual(I.normalizeCbRule({ at: 123, repeat: 'weekly', sticky: true }), { at: 123, repeat: 'weekly', sticky: false });
  assert.equal(I.normalizeCbRule({ at: 'x' }), null); assert.equal(I.normalizeCbRule({ at: -5 }), null); assert.equal(I.normalizeCbRule(null), null);
  assert.equal(I.normalizeCbRule({ at: 5, repeat: 'yearly' }).repeat, 'none');
  const raw = { abc12: { at: 10, repeat: 'daily' }, 'BAD!': { at: 10 }, gone1: { at: 10 }, xyz99: { at: 0 } };
  assert.deepEqual(Object.keys(I.cleanCbRem(raw, ['abc12', 'xyz99'])), ['abc12']);
  assert.deepEqual(Object.keys(I.cleanCbRem(raw)).sort(), ['abc12', 'gone1']); // tanpa validCids: hanya bentuk yang dicek
  const many = {}; for (let i = 0; i < 40; i++) many['c' + String(1000 + i)] = { at: 10 };
  assert.equal(Object.keys(I.cleanCbRem(many)).length, I.MAX_CB_PER_NOTE);
  assert.deepEqual(I.cleanCbRem([1, 2]), {}); assert.deepEqual(I.cleanCbRem('x'), {});
});
test('Rev 101: cidsInHtml dan newCid', () => {
  assert.deepEqual(I.cidsInHtml('<div class="todo" data-cid="ab12c"><input type="checkbox">a</div><div class="todo" data-cid="ab12c">b</div><div data-cid="Zz">x</div><div class="todo" data-cid="q9w8e7r">c</div>'), ['ab12c', 'q9w8e7r']);
  let i = 0; const seq = [0, 0, 0, 0, 0, 0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5];
  const c = I.newCid(['aaaaa'], () => seq[i++ % seq.length]); assert.match(c, I.CID_RE); assert.notEqual(c, 'aaaaa');
  assert.match(I.newCid([]), I.CID_RE);
});
test('Rev 101: nextOccurrences: sekali, harian, mingguan', () => {
  const now = L(2026, 11, 8, 10);
  assert.deepEqual(I.nextOccurrences({ at: L(2026, 11, 9, 9), repeat: 'none' }, now), [L(2026, 11, 9, 9)]);
  assert.deepEqual(I.nextOccurrences({ at: L(2026, 11, 7, 9), repeat: 'none' }, now), []);
  assert.deepEqual(I.nextOccurrences({ at: L(2026, 11, 1, 8, 30), repeat: 'daily' }, now, 3).map(iso), ['2026-11-09 08:30', '2026-11-10 08:30', '2026-11-11 08:30']);
  assert.deepEqual(I.nextOccurrences({ at: L(2026, 11, 8, 9), repeat: 'daily' }, now, 1).map(iso), ['2026-11-09 09:00']); // jam hari ini sudah lewat
  assert.deepEqual(I.nextOccurrences({ at: L(2026, 11, 8, 11), repeat: 'daily' }, now, 1).map(iso), ['2026-11-08 11:00']); // masih di depan
  assert.deepEqual(I.nextOccurrences({ at: L(2026, 10, 7, 9), repeat: 'weekly' }, now, 2).map(iso), ['2026-11-11 09:00', '2026-11-18 09:00']);
  assert.deepEqual(I.nextOccurrences({ at: L(2027, 1, 5, 9), repeat: 'weekly' }, now, 1).map(iso), ['2027-01-05 09:00']); // belum mulai
  assert.deepEqual(I.nextOccurrences({ at: L(2020, 1, 1, 9), repeat: 'daily' }, now, 2).map(iso), ['2026-11-09 09:00', '2026-11-10 09:00']); // jauh di belakang
});
test('Rev 101: nextOccurrences bulanan: 31 Jan -> akhir bulan terpendek tanpa drift, lintas tahun, tahun kabisat', () => {
  const r = { at: L(2026, 12, 31, 9), repeat: 'monthly' };
  assert.deepEqual(I.nextOccurrences(r, L(2026, 12, 31, 10), 6).map(iso), ['2027-01-31 09:00', '2027-02-28 09:00', '2027-03-31 09:00', '2027-04-30 09:00', '2027-05-31 09:00', '2027-06-30 09:00']);
  assert.deepEqual(I.nextOccurrences({ at: L(2027, 1, 31, 9), repeat: 'monthly' }, L(2028, 1, 31, 10), 2).map(iso), ['2028-02-29 09:00', '2028-03-31 09:00']);
  assert.deepEqual(I.nextOccurrences({ at: L(2026, 11, 15, 7, 5), repeat: 'monthly' }, L(2026, 11, 8), 3).map(iso), ['2026-11-15 07:05', '2026-12-15 07:05', '2027-01-15 07:05']);
  assert.equal(I.nextOccurrences({ at: L(2026, 1, 31, 9), repeat: 'monthly' }, L(2026, 1, 1), 12).length, 12);
});
test('Rev 101: presetsFor: preset hari ini bergantung jam; akhir pekan ini/depan', () => {
  const mon10 = I.presetsFor(L(2026, 11, 9, 10)); // Senin 10.00
  assert.deepEqual(mon10.map((p) => p.label), ['Nanti hari ini 14.00', 'Besok pagi 09.00', 'Akhir pekan ini Sab 09.00']);
  assert.equal(iso(mon10[1].at), '2026-11-10 09:00'); assert.equal(iso(mon10[2].at), '2026-11-14 09:00');
  assert.equal(I.presetsFor(L(2026, 11, 9, 15))[0].label, 'Nanti malam 20.00');
  assert.equal(I.presetsFor(L(2026, 11, 9, 21))[0].label, 'Besok pagi 09.00'); // keduanya sudah lewat
  assert.equal(I.presetsFor(L(2026, 11, 9, 13, 58))[0].label, 'Nanti hari ini 14.00'); assert.equal(I.presetsFor(L(2026, 11, 9, 13, 59))[0].label, 'Nanti malam 20.00'); // kurang dari 1 menit = dianggap lewat
  const sat = I.presetsFor(L(2026, 11, 14, 8)); assert.equal(sat[sat.length - 1].label, 'Akhir pekan depan Sab 09.00'); assert.equal(iso(sat[sat.length - 1].at), '2026-11-21 09:00');
  const sun = I.presetsFor(L(2026, 11, 8, 8)); assert.equal(iso(sun[sun.length - 1].at), '2026-11-14 09:00'); assert.match(sun[sun.length - 1].label, /depan/);
  assert.equal(iso(I.presetsFor(L(2026, 12, 31, 8))[1].at), '2027-01-01 09:00'); // lintas tahun
  for (const p of mon10) assert.ok(p.at > L(2026, 11, 9, 10));
});
test('Rev 101: ID alarm dan parseAlarmId', () => {
  assert.equal(I.cbId('n1', 'ab12c'), 'cb:n1:ab12c'); assert.equal(I.cbId('n1', 'ab12c', 3), 'cb:n1:ab12c:m3'); assert.equal(I.cdId('n1', 'B7x', 3), 'cd:n1:B7x:3');
  assert.equal(I.allCbIds('n1', 'ab12c').length, 13);
  assert.deepEqual(I.allCdIds('n1', 'B7x'), ['cd:n1:B7x:0', 'cd:n1:B7x:1', 'cd:n1:B7x:3', 'cd:n1:B7x:7']);
  assert.deepEqual(I.parseAlarmId('cb:n1:ab12c'), { kind: 'cb', noteId: 'n1', cid: 'ab12c' });
  assert.deepEqual(I.parseAlarmId('cb:n1:ab12c:m12'), { kind: 'cb', noteId: 'n1', cid: 'ab12c' });
  assert.equal(I.parseAlarmId('cb:n1:ab12c:m13'), null); assert.equal(I.parseAlarmId('cb:n1:XX'), null);
  assert.deepEqual(I.parseAlarmId('cd:n1:B7x:7'), { kind: 'cd', noteId: 'n1', bid: 'B7x', beforeDays: 7 });
  assert.equal(I.parseAlarmId('cd:n1:B7x:2'), null); assert.equal(I.parseAlarmId('note:n1'), null); assert.equal(I.parseAlarmId(''), null); assert.equal(I.parseAlarmId(null), null);
});
test('Rev 101: planCbAlarms: sekali/harian/mingguan 1 alarm, bulanan 12 alarm, centang, baris hilang, lewat, batas', () => {
  const now = L(2026, 11, 8, 10);
  const note = { id: 'n1', title: 'Belanja', cbRem: {
    aaaa1: { at: L(2026, 11, 9, 9), repeat: 'none' }, bbbb2: { at: L(2026, 11, 1, 8), repeat: 'daily' }, cccc3: { at: L(2026, 10, 7, 9), repeat: 'weekly' },
    dddd4: { at: L(2026, 12, 31, 9), repeat: 'monthly' }, eeee5: { at: L(2026, 11, 9, 9), repeat: 'none' }, ffff6: { at: L(2026, 11, 7, 9), repeat: 'none' }, gone7: { at: L(2026, 11, 9, 9), repeat: 'none' } } };
  const rows = { aaaa1: { text: '  Beli   susu  ', done: false }, bbbb2: { text: 'Minum obat', done: true }, cccc3: { text: '', done: false }, dddd4: { text: 'Bayar listrik', done: false }, eeee5: { text: 'Sudah selesai', done: true }, ffff6: { text: 'lewat', done: false } };
  const plan = I.planCbAlarms(note, rows, now), by = (id) => plan.find((p) => p.id === id);
  assert.equal(by('cb:n1:aaaa1').message, 'Beli susu'); assert.equal(by('cb:n1:aaaa1').repeatMs, 0); assert.equal(by('cb:n1:aaaa1').title, 'Belanja');
  assert.equal(iso(by('cb:n1:bbbb2').at), '2026-11-09 08:00'); assert.equal(by('cb:n1:bbbb2').repeatMs, I.DAY_MS); // harian tetap jalan walau dicentang
  assert.equal(iso(by('cb:n1:cccc3').at), '2026-11-11 09:00'); assert.equal(by('cb:n1:cccc3').repeatMs, 7 * I.DAY_MS); assert.equal(by('cb:n1:cccc3').message, 'Ada baris yang ingin kamu ingat.');
  const mon = plan.filter((p) => p.id.startsWith('cb:n1:dddd4:')); assert.equal(mon.length, 12); assert.equal(mon[0].id, 'cb:n1:dddd4:m1'); assert.equal(iso(mon[0].at), '2026-12-31 09:00'); assert.equal(iso(mon[2].at), '2027-02-28 09:00'); assert.ok(mon.every((p) => p.repeatMs === 0));
  assert.equal(by('cb:n1:eeee5'), undefined, 'sekali + dicentang = dilewati'); assert.equal(by('cb:n1:ffff6'), undefined, 'sudah lewat'); assert.equal(by('cb:n1:gone7'), undefined, 'barisnya sudah tidak ada');
  assert.equal(plan.length, 3 + 12);
  assert.deepEqual(I.planCbAlarms(null, rows, now), []); assert.deepEqual(I.planCbAlarms({ id: 'x' }, {}, now), []);
  // batas 60 alarm per catatan, yang terdekat dipertahankan
  const big = { id: 'n2', title: 't', cbRem: {} }, brows = {};
  for (let i = 0; i < 30; i++) { const c = 'm' + String(1000 + i); big.cbRem[c] = { at: L(2026, 12, 1 + (i % 28), 9), repeat: 'monthly' }; brows[c] = { text: 'x', done: false }; }
  const bp = I.planCbAlarms(big, brows, now); assert.equal(bp.length, I.MAX_PLAN_PER_NOTE);
  assert.ok(bp.every((p, i) => i === 0 || p.at >= bp[i - 1].at));
});
test('Rev 101: cleanCdRem dan dateTimeMs', () => {
  assert.deepEqual(I.cleanCdRem({ B7x: [7, 0, 3, 3, 9, '1'], bad: 'x', 'x!': [0], Gone: [0] }, ['B7x', 'bad', 'x!']), { B7x: [0, 1, 3, 7] });
  assert.deepEqual(I.cleanCdRem({ B7x: [] }), {}); assert.deepEqual(I.cleanCdRem(null), {}); assert.deepEqual(I.cleanCdRem([1]), {});
  const many = {}; for (let i = 0; i < 15; i++) many['blk' + i] = [0];
  assert.equal(Object.keys(I.cleanCdRem(many)).length, I.CD_MAX_BLOCKS);
  assert.equal(iso(I.dateTimeMs('2026-11-17', '12:00')), '2026-11-17 12:00'); assert.equal(iso(I.dateTimeMs('2026-11-17', '')), '2026-11-17 09:00'); assert.equal(iso(I.dateTimeMs('2026-11-17', '25:99')), '2026-11-17 09:00');
  assert.equal(I.dateTimeMs('2027-02-30', '09:00'), 0); assert.equal(I.dateTimeMs('17-11-2026', '09:00'), 0); assert.equal(I.dateTimeMs('', ''), 0); assert.equal(iso(I.dateTimeMs('2028-02-29', '23:59')), '2028-02-29 23:59');
});
test('Rev 101: planCdAlarms: n hari sebelum dari tanggal+jam kartu; lewat dilewati; tanggal berubah = rencana ikut berubah', () => {
  const now = L(2026, 11, 8, 10);
  const note = { id: 'n1', title: 'Rencana', cdRem: { B7x: [0, 1, 3, 7], Old: [0], Gone: [0] } };
  const blocks = { B7x: { date: '2026-11-17', time: '12:00', title: ' Ulang  tahun ' }, Old: { date: '2026-11-01', time: '', title: '' } };
  const plan = I.planCdAlarms(note, blocks, now), by = (n) => plan.find((p) => p.id === 'cd:n1:B7x:' + n);
  assert.equal(plan.length, 4); assert.equal(iso(by(0).at), '2026-11-17 12:00'); assert.equal(iso(by(1).at), '2026-11-16 12:00'); assert.equal(iso(by(3).at), '2026-11-14 12:00'); assert.equal(iso(by(7).at), '2026-11-10 12:00');
  assert.equal(by(0).message, 'Ulang tahun: hari ini.'); assert.equal(by(7).message, 'Ulang tahun: 7 hari lagi.'); assert.equal(by(0).title, 'Rencana'); assert.equal(by(0).repeatMs, 0);
  const moved = I.planCdAlarms(note, { B7x: { date: '2026-11-12', time: '', title: 'x' } }, now); // jam kosong = 09.00; 7 hari sebelum = 5 Nov (sudah lewat)
  assert.deepEqual(moved.map((p) => p.id).sort(), ['cd:n1:B7x:0', 'cd:n1:B7x:1', 'cd:n1:B7x:3'].sort()); assert.equal(iso(moved.find((p) => p.id.endsWith(':0')).at), '2026-11-12 09:00');
  assert.deepEqual(I.planCdAlarms(note, { B7x: { date: 'salah', time: '' } }, now), []); assert.deepEqual(I.planCdAlarms(null, blocks, now), []);
});
test('Rev 101: modul murni (tanpa DOM/AndroidAPI/Intl); belum dipanggil UI; SCHEMA dan native tidak berubah', () => {
  const s = src('src/js/ingatkan.js');
  assert.ok(!/document\.|window\.|AndroidAPI|KelimaaNative|Intl\.|localStorage|toLocale/.test(s.replace(/\/\/.*$/gm, '')));
  // Rev 102 (U5b) sengaja menyambungkan mesin ke notes.js/reminders.js/storage.js lewat cb-alarm.js; UI (lonceng, lembar) baru di U5c. main.js/logic.js/tp-alarm.js tetap tidak memakainya langsung.
  for (const f of ['main.js', 'logic.js', 'tp-alarm.js']) assert.ok(!src('src/js/' + f).includes('ingatkan.js'), f + ' tidak boleh memakai ingatkan.js langsung');
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('node tests/rev101.test.mjs'));
});
