// Rev 303d / v0.3.121: sel kotak centang tampil ☑/☐ di pratinjau pulau, kartu daftar, dan ekspor (model); salin TSV (plain) dan validasi tetap TRUE/FALSE. SCHEMA 22, CSS tidak berubah.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as D from '../src/js/lembar-tampil.js';
import * as P from '../src/js/lembar-pulau.js';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => {
  const sh = L.newSheet({ id: 'k', name: 'Tugas' }), tab = sh.tabs[0], put = (r, c, v) => L.setCell(tab, tab.rows[r].id, tab.cols[c].id, v);
  put(0, 0, { v: 'Cuci' }); put(1, 0, { v: 'Bayar' }); put(2, 0, { v: 'Belanja' }); put(3, 0, { v: 'Lain' });
  put(0, 1, { v: true }); put(1, 1, { v: false }); put(3, 1, { v: 'abc' }); put(0, 2, { v: true });
  tab.checks = [{ id: 'v1abc', c: tab.cols[1].id, k: 'box', items: [], dd: false, rg: { c2: tab.cols[1].id, r1: tab.rows[0].id, r2: tab.rows[3].id } }];
  return { sh, tab };
};
test('ekspor: tercentang ☑, FALSE/kosong ☐; teks lain tetap teks; di luar rentang tetap TRUE; plain (salin TSV) tetap TRUE/FALSE', () => {
  const { sh, tab } = mk(), r = P.exportModel(sh).rows, d = D.makeDisplay(tab);
  assert.equal(r[0][1].t, '\u2611'); assert.equal(r[1][1].t, '\u2610'); assert.equal(r[2][1].t, '\u2610'); assert.equal(r[3][1].t, 'abc'); assert.equal(r[0][2].t, 'TRUE');
  assert.equal(d.plain(0, 1), 'TRUE'); assert.equal(d.plain(1, 1), 'FALSE');
});
test('makeDisplay biasa (grid, validasi, salin) tidak berubah: TRUE/FALSE; lembar-tampil.js tidak mengimpor validasi', () => {
  const { tab } = mk(), d = D.makeDisplay(tab); assert.equal(d.text(0, 1), 'TRUE'); assert.equal(d.text(1, 1), 'FALSE'); assert.equal(d.text(2, 1), ''); assert.doesNotMatch(src('src/js/lembar-tampil.js'), /lembar-validasi/);
});
test('sel berumus di rentang kotak tidak diubah menjadi ☑/☐', () => {
  const { sh, tab } = mk(); tab.rows[2].cells[tab.cols[1].id] = { fx: '=1>0' }; assert.ok(!/[\u2610\u2611]/.test(P.exportModel(sh).rows[2][1].t));
});
test('pulau, ekspor, dan teks kartu memakai ☑/☐', () => {
  const { sh } = mk(), im = P.islandModel(sh), em = P.exportModel(sh), ct = P.sheetCardText(sh);
  assert.equal(im.rows[0][1].t, '\u2611'); assert.equal(im.rows[1][1].t, '\u2610'); assert.equal(em.rows[0][1].t, '\u2611'); assert.equal(em.rows[2][1].t, '\u2610'); assert.match(ct, /Cuci \u2611/);
});
test('lembar tanpa aturan kotak: pulau/ekspor tidak berubah (TRUE tetap TRUE)', () => {
  const { sh, tab } = mk(); tab.checks = []; assert.equal(P.exportModel(sh).rows[0][1].t, 'TRUE'); assert.equal(P.islandModel(sh).rows[0][1].t, 'TRUE');
});
test('pencarian lembar tetap TRUE/FALSE (tidak memakai opsi box); lembar-kotak tetap tidak diimpor tampil; CSS dan SCHEMA tidak berubah', () => {
  const { sh } = mk(); assert.match(P.sheetSearchText(sh), /TRUE/);
  assert.ok(!src('src/js/lembar-tampil.js').includes('lembar-kotak')); assert.match(src('src/js/storage.js'), /SCHEMA = 22/); assert.ok(!src('src/css/styles.css').includes('Rev 303d'));
});
test('dokumen: entri Rev 303d paling atas di PROMPT dan RIWAYAT, UJI_HP bagian AK, README menyebut 303d, tes terdaftar', () => {
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 303d / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('**Rev 303d / v0.3.121'));
  assert.match(src('UJI_HP_RILIS.md'), /## AK\. Kotak centang di ekspor dan pratinjau \(Rev 303d\)/); const r = src('README.md'); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */); assert.match(r, /Rev 303d/); assert.match(r, /bukan\*\* bukti APK/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev303d\.test\.mjs/);
});
console.log('rev303d: ' + n + ' tes');
