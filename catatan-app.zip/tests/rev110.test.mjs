// Rev 110 / U6b: ekspor (TXT/MD/PDF/JPG), pratinjau, dan pencarian sadar bagian lipat.
// Perilaku murni (parser, TXT, Markdown, tata letak) diuji sungguhan; kode DOM (notePlain) dan kanvas (share.js) dikunci lewat teks.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseNoteHtml, blocksToText, blocksToMarkdown, layoutDoc } from '../src/js/export.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const notes = src('src/js/notes.js'), share = src('src/js/share.js'), exp = src('src/js/export.js');

const FOLD = '<p>Awal</p><div class="fold" data-o="1"><div class="fh">Judul <b>tebal</b></div><div class="fb"><p>isi satu</p><div class="todo"><input type="checkbox" checked> beli</div><ul><li>poin</li></ul></div></div><p>Akhir</p>';
const measure = (t) => t.length * 14;
const lay = (blocks) => layoutDoc({ title: 'T', blocks }, { width: 1000, padX: 40, size: 30, measure, lhRatio: 1.4, titleSize: 40 });

test('Rev 110: parser menandai judul (fold.head, open) dan isi (fi=1), tanpa blok kosong sisa dari DIV pembungkus', () => {
  const b = parseNoteHtml(FOLD);
  assert.deepEqual(b.map((x) => [x.kind, x.fold ? 'H' : '', x.fi || 0, (x.runs || []).map((r) => r.t).join('')]), [
    ['p', '', 0, 'Awal'], ['p', 'H', 0, 'Judul tebal'], ['p', '', 1, 'isi satu'], ['todo', '', 1, 'beli'], ['ul', '', 1, 'poin'], ['p', '', 0, 'Akhir']]);
  assert.equal(b[1].fold.open, true);
  assert.equal(b[3].checked, true);
});
test('Rev 110: bagian lipat TERTUTUP juga diekspor penuh (status buka/tutup hanya dicatat)', () => {
  const b = parseNoteHtml(FOLD.replace(' data-o="1"', ''));
  assert.equal(b[1].fold.open, false);
  assert.match(blocksToText('', b), /isi satu/);
});
test('Rev 110: TXT = "▸ Judul" + isi menjorok dua spasi, tanpa baris kosong ekstra', () => {
  const t = blocksToText('T', parseNoteHtml(FOLD));
  assert.equal(t, 'T\n\nAwal\n▸ Judul tebal\n  isi satu\n  ☑ beli\n  • poin\nAkhir');
});
test('Rev 110: Markdown = butir berjudul tebal + isi bertingkat (indentasi 2 spasi), teks sesudahnya kembali ke akar', () => {
  const md = blocksToMarkdown('T', parseNoteHtml(FOLD));
  assert.match(md, /\n- \*\*Judul tebal\*\*\n/);
  assert.match(md, /\n {2}isi satu\n/);
  assert.match(md, /\n {2}- \[x\] beli\n/);
  assert.match(md, /\n {2}- poin\n/);
  assert.match(md, /\nAkhir\n/);
  assert.ok(!md.includes('**Judul** **tebal**'), 'judul tidak boleh jadi dua blok tebal bersebelahan');
});
test('Rev 110: judul bertanda miring/coret tetap utuh di dalam satu pasang **', () => {
  const md = blocksToMarkdown('', parseNoteHtml('<div class="fold"><div class="fh">A <i>b</i></div><div class="fb"><p>x</p></div></div>'));
  assert.match(md, /^- \*\*A \*b\*\*\*/);
});
test('Rev 110: bagian lipat kosong (judul dan isi kosong) tetap ada, termasuk di ujung catatan', () => {
  const h = '<p>Hai</p><div class="fold"><div class="fh"><br></div><div class="fb"><p><br></p></div></div>';
  const b = parseNoteHtml(h);
  assert.equal(b.length, 2);
  assert.equal(b[1].fold.head, true);
  assert.equal(blocksToText('', b), 'Hai\n▸ Bagian lipat');
  assert.match(blocksToMarkdown('', b), /- \*\*Bagian lipat\*\*/);
});
test('Rev 110: catatan tanpa bagian lipat tidak berubah (TXT/MD/DIV todo/wrapper tabel)', () => {
  const h = '<p>a</p><div class="todo"><input type="checkbox"> b</div><div class="kt-scroll"><table><tr><td>1</td><td>2</td></tr></table></div><p>c</p>';
  const b = parseNoteHtml(h);
  assert.equal(b.some((x) => x.fi || x.fold), false);
  assert.equal(blocksToText('', b), 'a\n☐ b\n1 | 2\nc');
});
test('Rev 110: DIV bukan bagian lipat di dalam isi (todo) tidak merusak penutup bagian lipat', () => {
  const h = '<div class="fold" data-o="1"><div class="fh">J</div><div class="fb"><div class="todo"><input type="checkbox"> t1</div><div class="todo"><input type="checkbox" checked> t2</div></div></div><p>luar</p>';
  const b = parseNoteHtml(h);
  assert.deepEqual(b.map((x) => x.fi || 0), [0, 1, 1, 0]);
  assert.equal(b[3].fi, undefined);
});
test('Rev 110: PDF/JPG = judul tebal berpanah (mark fold) selalu terbuka; isi menjorok satu langkah; isi tertutup tetap ikut', () => {
  const t = lay(parseNoteHtml(FOLD.replace(' data-o="1"', ''))).filter((l) => l.kind === 'text');
  const head = t.find((l) => l.mark && l.mark.type === 'fold');
  assert.ok(head, 'ada mark fold');
  assert.ok(head.segs.every((s) => !s.t.trim() || s.b), 'judul tebal');
  const body = t.find((l) => l.segs.map((s) => s.t).join('') === 'isi satu');
  assert.ok(body && body.x > 40, 'isi menjorok dari tepi');
  const awal = t.find((l) => l.segs.map((s) => s.t).join('') === 'Awal');
  assert.equal(awal.x, 40);
  const marks = t.filter((l) => l.mark).map((l) => l.mark.type);
  assert.deepEqual(marks, ['fold', 'todo', 'bullet']);
  assert.ok(t.find((l) => l.mark && l.mark.type === 'todo').mark.x > head.mark.x, 'kotak centang di isi lebih menjorok dari panah');
});
test('Rev 110: judul kosong di PDF/JPG memakai teks cadangan "Bagian lipat"', () => {
  const t = lay(parseNoteHtml('<div class="fold"><div class="fh"><br></div><div class="fb"><p>x</p></div></div>')).filter((l) => l.kind === 'text');
  const h = t.find((l) => l.mark && l.mark.type === 'fold');
  assert.ok(h, 'ada baris berpanah');
  assert.equal(h.segs.map((s) => s.t).join(''), 'Bagian lipat');
});
test('Rev 110: parser memakai tumpukan jenis DIV, bukan wrapperDepth, untuk bagian lipat', () => {
  assert.match(exp, /divKinds\.push\(k\)/);
  assert.doesNotMatch(exp, /wrapperDepth\s*[+-]=?\s*[^;]*fold/);
});
test('Rev 110: share.js menggambar panah lipat sebagai chevron di kanvas (bukan glyph font)', () => {
  assert.match(share, /m\.type === 'fold'/);
  assert.doesNotMatch(share.slice(share.indexOf("m.type === 'fold'"), share.indexOf("m.type === 'fold'") + 600), /fillText\(['"][▸▾⌄›]/);
});
test('Rev 110: notePlain membuka sebentar bagian lipat tertutup lalu mengembalikan data-o (try/finally)', () => {
  const a = notes.indexOf('export function notePlain(ed) {');
  const f = notes.slice(a, a + 900);
  assert.match(f, /querySelectorAll\('div\.fold:not\(\[data-o="1"\]\)'\)/);
  assert.match(f, /try \{ txt = ed\.innerText \|\| ''; \} finally \{ shut\.forEach\(\(f\) => f\.removeAttribute\('data-o'\)\); \}/);
});
test('Rev 110: versi 0.3.121, SCHEMA 10, native dan dependensi tidak berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121');
  assert.match(pk.scripts.test, /node tests\/rev110\.test\.mjs/);
  assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
  assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
