// Rev 99 / U4d: chip Total ⌄ + baris Total (tr.tt). Tes Node: kontrak sumber dan mesin angka. Perilaku DOM (ketuk chip, edit sel, tambah/hapus baris,
// sanitize anti-palsu, Undo) dicek di Chromium 360x800 (bukan bagian npm test).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { TABLE_CHIPS } from '../src/js/bilah-chip.js';
import { columnTotal, TOTAL_FUNCS } from '../src/js/tabel-hitung.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 99: chip Total ⌄ membuka sub-bilah (Tanpa total + 5 fungsi) dan berada sesudah Perataan', () => {
  const ids = TABLE_CHIPS.main.map((c) => c.id);
  assert.equal(ids[ids.indexOf('align') + 1], 'total');
  assert.equal(TABLE_CHIPS.main.find((c) => c.id === 'total').page, 'total');
  assert.deepEqual(TABLE_CHIPS.total.map((c) => c.id), ['tot-none', 'tot-sum', 'tot-avg', 'tot-cnt', 'tot-min', 'tot-max']);
  assert.deepEqual(TABLE_CHIPS.total.map((c) => c.label), ['Tanpa total', ...TOTAL_FUNCS.map((f) => f.label)]);
});
test('Rev 99: mesin angka dipakai apa adanya (U4c tidak berubah)', () => {
  assert.equal(columnTotal(['1.000', 'Rp 2.500,5', 'x', ''], 'sum').text, '3.500,5');
  assert.equal(columnTotal([], 'avg').text, '—');
  assert.equal(columnTotal(['a'], 'cnt').text, '0');
});
test('Rev 99: tabel-total.js: hanya data-f dipercaya, nilai dihitung ulang, baris Total satu dan terakhir', () => {
  const s = src('src/js/tabel-total.js');
  assert.match(s, /export function refreshTotals\(table\)/); assert.match(s, /export function setColumnTotal\(table, c, fn\)/);
  assert.match(s, /all\.slice\(1\)\.forEach\(\(r\) => r\.remove\(\)\)/);
  assert.match(s, /tt\.remove\(\); return false;/);
  assert.match(s, /td\.setAttribute\('contenteditable', 'false'\)/);
  assert.match(s, /cell\.tagName === 'TD'/, 'sel TH (kolom header) tidak dihitung');
});
test('Rev 99: sanitize mengizinkan tr.tt dan data-f TD valid, lalu menghitung ulang; tidak ada penangan inline', () => {
  const n = src('src/js/notes.js');
  assert.match(n, /\(c\.tagName === 'TR' && v === 'tt'\)/);
  assert.match(n, /c\.tagName === 'TD' && k === 'data-f' && \/\^\(\?:sum\|avg\|cnt\|min\|max\)\$\/\.test\(v\)/);
  assert.match(n, /c\.parentElement\.classList\.contains\('tt'\)/);
  assert.match(n, /querySelectorAll\('table'\)\.forEach\(\(tb\) => refreshTotals\(tb\)\)/);
  assert.ok(n.indexOf("refreshTotals(tb)); // Rev 99") < n.indexOf('flattenFontScale(t.content);\n  return t.innerHTML'));
});
test('Rev 99: bilah-chip.js tidak menghitung baris Total sebagai baris data (dims, header, hapus baris) dan menyegarkan total tiap operasi', () => {
  const s = src('src/js/bilah-chip.js');
  assert.match(s, /const rows = dataRowsOf\(table\); \/\/ baris Total/);
  assert.match(s, /export function headerFlags\(table\) \{\s*const rows = dataRowsOf\(table\);/);
  assert.match(s, /if \(isTotalRow\(row\)\) return;/);
  assert.equal((s.match(/refreshTotals\(table\)/g) || []).length >= 5, true);
  assert.match(s, /const near = dr\[Math\.min\(at, dr\.length - 1\)\]/);
});
test('Rev 99: notes.js: chip tot-* = 1 langkah Undo, input sel menghitung ulang, sel Total dialihkan ke baris data terakhir', () => {
  const n = src('src/js/notes.js');
  const fn = n.slice(n.indexOf("if (id.startsWith('tot-'))"), n.indexOf("if (id === 'hdr-row'"));
  assert.match(fn, /flushHist\(\);\s*const tc = setColumnTotal\(table, colIndex, id\.slice\(4\)\);\s*flushHist\(\); auto\(\);/);
  assert.match(n, /if \(tb && tb\.querySelector\('tr\.tt'\)\) refreshTotals\(tb\)/);
  assert.match(n, /isTotalRow\(cell\.closest\('tr'\)\)/);
  assert.match(n, /'total': \{ label: tf \? 'Total: ' \+ totalLabel\(tf\) \+ ' ⌄' : 'Total ⌄', active: !!tf \}/);
});
test('Rev 99: CSS baris Total; versi 0.3.121, SCHEMA 9, native dan dependensi tidak berubah', () => {
  assert.ok(src('src/css/styles.css').includes('.ed2 tr.tt td{'));
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('node tests/rev99.test.mjs'));
});
