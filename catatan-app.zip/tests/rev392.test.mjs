// Rev 392: CHECKPOINT PART SM (mode alarm per sub-tugas), DOKUMEN SAJA. Kode aplikasi tidak berubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('banner Rev 392 paling atas (di atas Rev 391), CHECKPOINT PART SM, BELUM ADA KODE, BERFUNGSI-BELUM-DIUJI', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) {
    const d = rd(f); assert.ok(/^\*\*Rev (?:39\d|4[0-3]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 392 /') < d.indexOf('**Rev 391 /'), f);
    const b = d.slice(d.indexOf('**Rev 392 /'), d.indexOf('**Rev 391 /')); for (const k of ['PART SM', 'BELUM ADA KODE', 'BERFUNGSI-BELUM-DIUJI', 'D-SM1']) assert.ok(b.includes(k), f + ' ' + k);
  }
});
test('bagian 38.17 ada, di bawah 38.16, memuat D-SM1..D-SM4, SM1..SM4, dan risiko', () => {
  const d = rd('PROMPT_SERAH_TERIMA.md'); const i = d.indexOf('**38.17 CHECKPOINT PART SM'); assert.ok(i > d.indexOf('**38.16 CHECKPOINT'));
  const b = d.slice(i, d.indexOf('\n', i)); for (const k of ['D-SM1', 'D-SM2', 'D-SM3', 'D-SM4', 'SM1', 'SM2', 'SM3', 'SM4', 'RISIKO', 'PRATINJAU', 'rmode']) assert.ok(b.includes(k), k);
});
test('kode TIDAK berubah: SCHEMA 22, versi 0.3.121, main.js masih memakai satu rmode, tidak ada penanda Rev 392 di src/', () => {
  assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/); assert.equal(JSON.parse(rd('package.json')).version, '0.3.121');
  assert.ok(rd('src/js/main.js').includes('let rmode ='));
  for (const f of fs.readdirSync(new URL('../src/js/', import.meta.url))) if (f.endsWith('.js')) assert.ok(!rd('src/js/' + f).includes('Rev 392'), f);
});
test('tes terdaftar sesudah rev391; README tetap < 12000', () => {
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.indexOf('rev391.test.mjs') < t.indexOf('rev392.test.mjs')); assert.ok(rd('README.md').length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */);
});
