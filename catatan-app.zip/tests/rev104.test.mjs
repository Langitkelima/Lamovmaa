// Rev 104 / U5d: pengingat kartu Hitung mundur. Tes Node: fungsi murni + alur data lewat jembatan palsu + kontrak sumber.
// Perilaku DOM (chip 🔔, lembar, simpan/hapus) dicek terpisah di Chromium/HP (bukan bagian npm test).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as I from '../src/js/ingatkan.js';
import * as C from '../src/js/cb-alarm.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const L = (y, m, d, h = 0, mi = 0) => new Date(y, m - 1, d, h, mi, 0, 0).getTime();
const NOW = L(2026, 11, 8, 10);
const card = (bid, date, time, title) => `<div class="kb-countdown-block"${bid ? ` data-kb-id="${bid}"` : ''} data-kb-date="${date}"${time ? ` data-kb-time="${time}"` : ''} data-kb-title="${title}" contenteditable="false"></div>`;
function fakeApi() {
  const calls = { sched: [], cancel: [] };
  globalThis.AndroidAPI = { scheduleNotification: (id, t, m, d, r) => { calls.sched.push({ id, t, m, d, r }); return 'exact_alarm'; }, cancelScheduledNotification: (id) => { calls.cancel.push(id); } };
  return calls;
}
const noApi = () => { delete globalThis.AndroidAPI; delete globalThis.KelimaaNative; };

test('Rev 104: newBid memakai pola BID, tidak bentrok dengan yang dipakai', () => {
  const b = I.newBid([]); assert.match(b, /^[a-z0-9]{6,8}$/); assert.ok(I.BID_PATTERN.test(b));
  let i = 0; const seq = [0, 0, 0, 0, 0, 0, 0, 0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5];
  const rnd = () => seq[i++ % seq.length];
  const first = I.newBid([], rnd); i = 0;
  assert.notEqual(I.newBid([first], rnd), first, 'bid yang sudah dipakai tidak diulang');
});
test('Rev 104: cdOptions: waktu tiap preset dari tanggal+jam kartu, jam kosong = 09.00, yang lewat ok=false', () => {
  const o = I.cdOptions({ date: '2026-11-17', time: '' }, NOW);
  assert.deepEqual(o.map((x) => x.beforeDays), [0, 1, 3, 7]);
  assert.equal(o[0].at, L(2026, 11, 17, 9)); assert.equal(o[1].at, L(2026, 11, 16, 9)); assert.equal(o[3].at, L(2026, 11, 10, 9));
  assert.ok(o.every((x) => x.ok));
  assert.equal(o[0].when, 'Sel, 17 Nov 09.00');
  const near = I.cdOptions({ date: '2026-11-10', time: '08:00' }, NOW); // hari-H 10 Nov 08.00 masih depan; 3 dan 7 hari sebelum sudah lewat
  assert.deepEqual(near.map((x) => x.ok), [true, true, false, false]);
  assert.deepEqual(I.cdOptions({ date: '2026-02-30', time: '' }, NOW), [], 'tanggal tidak sah = tidak ada pilihan');
  assert.deepEqual(I.cdOptions(null, NOW), []);
});
test('Rev 104: setCdRule/clearCdRule menulis note.cdRem; daftar dibersihkan; batas 10 kartu; kosong menghapus', () => {
  const n = { id: 'n1' };
  assert.equal(I.setCdRule(n, 'abc123', [7, 0, 0, 99, 'x']), true);
  assert.deepEqual(n.cdRem, { abc123: [0, 7] });
  assert.equal(I.setCdRule(n, 'bad!', [0]), false);
  assert.equal(I.setCdRule(n, 'abc123', []), true); assert.equal('cdRem' in n, false, 'daftar kosong = aturan dihapus');
  const big = { id: 'n2' };
  for (let i = 0; i < I.CD_MAX_BLOCKS; i++) assert.equal(I.setCdRule(big, 'blk' + i, [0]), true);
  assert.equal(I.setCdRule(big, 'extra9', [0]), false, 'kartu ke-11 ditolak');
  assert.equal(I.setCdRule(big, 'blk0', [1, 3]), true, 'mengubah yang sudah ada tetap boleh');
  assert.equal(I.clearCdRule(big, 'tidakada'), false); assert.equal(I.clearCdRule(big, 'blk0'), true);
});
test('Rev 104: cdLiveCount hanya menghitung pengingat yang masih akan berbunyi', () => {
  const blk = { date: '2026-11-10', time: '08:00' };
  assert.equal(I.cdLiveCount([0, 1, 3, 7], blk, NOW), 2);
  assert.equal(I.cdLiveCount(undefined, blk, NOW), 0); assert.equal(I.cdLiveCount([], blk, NOW), 0);
});
test('Rev 104: blocksFromHtml/bidsInHtml membaca data-kb-id; bid kembar: yang PERTAMA; cleanNoteRem memangkas cdRem yatim', () => {
  const html = card('abc123', '2026-11-17', '12:00', 'Ulang tahun') + card('abc123', '2026-12-01', '', 'Salinan') + card('', '2026-12-25', '', 'Tanpa id');
  assert.deepEqual(I.bidsInHtml(html), ['abc123']);
  assert.equal(I.blocksFromHtml(html).abc123.title, 'Ulang tahun');
  const c = I.cleanNoteRem({ html, cdRem: { abc123: [0, 3], hilang1: [0] } });
  assert.deepEqual(c.cdRem, { abc123: [0, 3] });
});
test('Rev 104: alur kartu: pasang -> alarm cd:<note>:<bid>:<n> dengan pesan benar; ubah tanggal -> jadwal ulang; hapus kartu -> dibatalkan', () => {
  const calls = fakeApi();
  const n = { id: 'n1', title: 'Pesta', html: card('abc123', '2026-11-17', '12:00', 'Ulang tahun') };
  I.setCdRule(n, 'abc123', [0, 3]);
  C.syncNoteAlarms(n, NOW);
  assert.deepEqual(calls.sched.map((c) => c.id).sort(), ['cd:n1:abc123:0', 'cd:n1:abc123:3']);
  const h0 = calls.sched.find((c) => c.id === 'cd:n1:abc123:0'), h3 = calls.sched.find((c) => c.id === 'cd:n1:abc123:3');
  assert.equal(h0.m, 'Ulang tahun: hari ini.'); assert.equal(h3.m, 'Ulang tahun: 3 hari lagi.');
  assert.equal(h0.d, L(2026, 11, 17, 12) - NOW); assert.equal(h0.r, 0);
  // tanggal kartu diubah ke 20 Nov (jam sama): reconcile menjadwalkan ulang dengan waktu baru
  calls.sched.length = 0; calls.cancel.length = 0;
  n.html = card('abc123', '2026-11-20', '12:00', 'Ulang tahun');
  C.reconcileNoteAlarms(n, NOW);
  assert.equal(calls.sched.find((c) => c.id === 'cd:n1:abc123:0').d, L(2026, 11, 20, 12) - NOW);
  // kartu dihapus dari catatan: cdRem dipangkas, alarm dibatalkan, tak ada yang dijadwalkan
  calls.sched.length = 0; calls.cancel.length = 0;
  n.html = '<p>kosong</p>';
  const rr = C.reconcileNoteAlarms(n, NOW);
  assert.equal(rr.pruned, true); assert.equal('cdRem' in n, false);
  assert.ok(calls.cancel.includes('cd:n1:abc123:0') && calls.cancel.includes('cd:n1:abc123:3'));
  assert.equal(calls.sched.length, 0);
  noApi();
});
test('Rev 104: cancelCdAlarms membatalkan SEMUA ID hari-sebelum satu kartu dan tidak menyentuh kartu lain', () => {
  const calls = fakeApi();
  C.cancelCdAlarms({ id: 'n1' }, 'abc123');
  assert.deepEqual(calls.cancel.sort(), ['cd:n1:abc123:0', 'cd:n1:abc123:1', 'cd:n1:abc123:3', 'cd:n1:abc123:7']);
  C.cancelCdAlarms(null, 'x'); C.cancelCdAlarms({ id: 'n1' }, '');
  assert.equal(calls.cancel.length, 4);
  noApi();
});
test('Rev 104: ketukan notifikasi cd: dikenali (membuka catatan)', () => {
  assert.deepEqual(I.parseAlarmId('cd:n1:abc123:3'), { kind: 'cd', noteId: 'n1', bid: 'abc123', beforeDays: 3 });
  assert.equal(I.parseAlarmId('cd:n1:abc123:5'), null);
});
test('Rev 104: kontrak sumber notes.js: data-kb-id disaring, bid kembar diberi bid baru, chip 🔔 di baris alat, lembar, simpan/hapus, Privat tanpa chip', () => {
  const s = src('src/js/notes.js');
  assert.match(s, /k === 'data-kb-id' && BID_PATTERN\.test\(v\) && c\.classList\.contains\('kb-countdown-block'\)/);
  assert.match(s, /\.kb-countdown-block\[data-kb-id\]/); assert.match(s, /newBid\(\[\.\.\.seenBid/);
  assert.match(s, /const openCdRemindSheet = \(blk\) =>/);
  assert.match(s, /\['remind', cdChipText\(blk\)\]/); assert.match(s, /\(isP \? \[\['edit', 'Ubah'\], \['delete', 'Hapus'\]\]/, 'Privat: tanpa chip pengingat');
  assert.match(s, /if \(v === 'remind'\) \{ openCdRemindSheet\(blk\); return; \}/);
  assert.match(s, /role: 'checkbox'/, 'boleh memilih beberapa');
  assert.match(s, /setCdRule\(n, bid, list\)/); assert.match(s, /blk\.setAttribute\('data-kb-id', bid\)/);
  assert.match(s, /newBid\(\[\.\.\.bidsInHtml\(ed\.innerHTML\), \.\.\.Object\.keys\(n\.cdRem \|\| \{\}\)\]\)/);
  const i0 = s.indexOf('const openCdRemindSheet'); const del = s.slice(s.indexOf('const doDelete = () =>', i0), s.indexOf('const bDel =', i0));
  assert.ok(del.indexOf('cancelCdAlarms(n, bid)') >= 0 && del.indexOf('cancelCdAlarms(n, bid)') < del.indexOf('clearCdRule(n, bid)'), 'batalkan alarm SEBELUM aturan dihapus');
  assert.ok(!/\.scheduleNotification\(/.test(s), 'UI tidak memanggil scheduleNotification langsung');
  assert.match(s, /document\.querySelectorAll\('\.ov\.rm-ov'\)\.forEach/);
});
test('Rev 104: versi 0.3.121 di package.json dan Setelan', () => {
  assert.match(src('package.json'), /"version": "0\.3\.121"/);
  assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
