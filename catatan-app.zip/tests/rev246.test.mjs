// Rev 246: tabel Markdown di balasan AI. Pengurai MURNI + DOM tiruan kecil (tanpa peramban); tampilan nyata di HP BELUM diuji.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as M from '../src/js/ai/markdown.js';
import * as A from '../src/js/ai/aksi.js';
import * as B from '../src/js/ai/baris.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const RAW = 'Perbandingan:\n\n| Nama | Harga | Catatan |\n|:-----|------:|:-------:|\n| **Kopi** | 15.000 | enak<br>pahit |\n| Teh \\| manis | 8.000 | |\n| Susu | 12.000 | dingin | lebih\n\nSesudah tabel *miring*.';

// DOM tiruan minimal: cukup untuk toDom
const mk = (tag) => ({ tag, kids: [], attrs: {}, className: '', textContent: '', append(...n) { n.forEach((x) => this.kids.push(x)); }, setAttribute(k, v) { this.attrs[k] = v; } });
const fakeDoc = { createElement: mk, createTextNode: (v) => ({ text: v }), createDocumentFragment: () => { const f = mk('#frag'); return f; } };
const flat = (n) => (n.text !== undefined ? n.text : (n.kids || []).map(flat).join(''));
const find = (n, tag, out = []) => { if (n.tag === tag) out.push(n); (n.kids || []).forEach((k) => find(k, tag, out)); return out; };

test('parse: tabel jadi blok table (rata, judul, isi; baris pendek dilengkapi, kelebihan dibuang, \\| dan <br> dalam sel aman)', () => {
  const b = M.parse(RAW);
  assert.deepEqual(b.map((x) => x.k), ['p', 'table', 'p']);
  const t = b[1]; assert.deepEqual(t.align, ['', 'r', 'c']); assert.equal(t.head.length, 3); assert.equal(t.rows.length, 3);
  assert.ok(t.rows.every((r) => r.length === 3));
  assert.equal(M.toPlain([{ k: 'p', c: t.rows[1][0] }]), 'Teh | manis'); // \| = tanda | biasa
  assert.ok(t.rows[0][2].some((n) => n.t === 'br')); // <br> di sel = baris baru di sel, tidak memecah tabel
  assert.equal(M.toPlain([{ k: 'p', c: t.rows[2][2] }]), 'dingin'); // sel ke-4 dibuang
});
test('parse: bukan tabel bila pemisah tidak cocok / tanpa pipa; teks berpipa biasa tetap paragraf', () => {
  assert.deepEqual(M.parse('a | b\nteks biasa').map((x) => x.k), ['p']);
  assert.deepEqual(M.parse('a | b | c\n--|--').map((x) => x.k), ['p']); // jumlah kolom beda
  assert.deepEqual(M.parse('Judul |\n---').map((x) => x.k), ['p', 'hr']); // setext/garis tanpa pipa bukan pemisah tabel
  assert.deepEqual(M.parse('a | b\n--|--\n1 | 2').map((x) => x.k), ['table']); // tabel tanpa pipa tepi
  assert.deepEqual(M.parse('- a\n\n| x | y |\n|---|---|\n| 1 | 2 |\n\n- b').map((x) => x.k), ['list', 'table', 'list']);
});
test('parse: batas aman (20 kolom, 200 baris)', () => {
  const cols = Array.from({ length: 30 }, (_, i) => 'k' + i);
  const big = '| ' + cols.join(' | ') + ' |\n|' + cols.map(() => '---').join('|') + '|\n' + Array.from({ length: 300 }, () => '| ' + cols.join(' | ') + ' |').join('\n');
  const t = M.parse(big)[0]; assert.equal(t.k, 'table'); assert.equal(t.head.length, 20); assert.equal(t.rows.length, 200);
});
test('toPlain: tabel jadi baris berpipa tanpa tanda Markdown', () => {
  const p = M.toPlain(M.parse(RAW)); assert.match(p, /Nama \| Harga \| Catatan\nKopi \| 15\.000 \| enak pahit\n/); assert.doesNotMatch(p, /\*\*|:---|<br>/);
});
test('toHtml: tabel catatan biasa (div.tbl-wrap > table, th judul, data-a rata, sel kosong <br>, tag liar lolos escape); ada baris kosong sesudah tabel di akhir', () => {
  const h = M.toHtml(M.parse(RAW));
  assert.match(h, /<div class="tbl-wrap"><table><tbody><tr><th>Nama<\/th><th data-a="r">Harga<\/th><th data-a="c">Catatan<\/th><\/tr>/);
  assert.match(h, /<td><b>Kopi<\/b><\/td>/); assert.match(h, /<td data-a="c">enak<br>pahit<\/td>/); assert.match(h, /<td data-a="c"><br><\/td>/);
  const x = M.toHtml(M.parse('| a |\n|---|\n| <script>alert(1)</script><img src=x onerror=1> |'));
  assert.doesNotMatch(x, /<script|<img/); assert.ok(x.endsWith('<div><br></div>')); assert.ok(!x.endsWith('<div><br></div><div><br></div>'));
});
test('toDom: tabel dalam pembungkus .md-tbl (thead/th + tbody/td), rata lewat data-a, tanpa style dan tanpa HTML mentah', () => {
  const root = M.toDom(M.parse(RAW), fakeDoc); const wrap = find(root, 'div').find((d) => d.className === 'md-tbl');
  assert.ok(wrap); assert.equal(wrap.attrs.role, 'region'); assert.equal(find(wrap, 'th').length, 3); assert.equal(find(wrap, 'tr').length, 4); assert.equal(find(wrap, 'td').length, 9);
  assert.equal(find(wrap, 'th')[1].attrs['data-a'], 'r'); assert.equal(flat(find(wrap, 'td')[0]), 'Kopi'); assert.equal(find(wrap, 'strong').length, 1);
  assert.ok(![...find(wrap, 'td'), ...find(wrap, 'th')].some((c) => 'style' in c.attrs));
});
test('noteDraft: balasan bertabel menyimpan html tabel + teks bersih; sheet.append_row tetap membaca tabel dari balasan mentah', () => {
  const d = A.noteDraft(RAW); assert.match(d.html, /<table>/); assert.match(d.text, /Nama \| Harga \| Catatan/);
  const r = B.rowDrafts(RAW); assert.ok(r.length >= 3); assert.ok(r.some((x) => x.head)); assert.deepEqual(r[0].cells.slice(0, 3), ['Nama', 'Harga', 'Catatan']);
});
test('css + sanitize: gaya .md-tbl memakai token tema; sanitize catatan mengenali tbl-wrap, th/td dan data-a', () => {
  const c = src('src/css/styles.css'); assert.match(c, /\.md \.md-tbl\{[^}]*overflow-x:auto/); assert.match(c, /\.md \.md-tbl th\{[^}]*var\(--acs\)/); assert.doesNotMatch(c.slice(c.indexOf('Rev 246')), /#[0-9a-fA-F]{3,6}\b[^}]*\.md-tbl/);
  const n = src('src/js/notes.js'); assert.match(n, /'tbl-wrap'/); assert.match(n, /k === 'data-a' && \/\^\[cr\]\$\//);
});
test('Worker: petunjuk chat mengizinkan tabel (bersyarat), tetap melarang tag HTML; hanya teks petunjuk yang berubah', () => {
  const w = src('backend/cloudflare/worker.mjs'), l = w.split('\n').find((x) => x.startsWith('const SYSTEM_CHAT'));
  assert.match(l, /Tabel Markdown/); assert.match(l, /maksimal 6 kolom/); assert.match(l, /JANGAN pakai tag HTML/); assert.doesNotMatch(l, /jangan pakai tabel/); assert.match(w, /Rev 246: SYSTEM_CHAT/);
});
test('dokumen: UJI_HP_RILIS bagian F (F1-F7), README ringkas dan jujur, entri Rev 246 di PROMPT dan RIWAYAT', () => {
  const u = src('UJI_HP_RILIS.md'), f = u.slice(u.indexOf('## F. Tabel')); const nums = [...f.matchAll(/^F(\d+)\. \[ \]/gm)].map((m) => Number(m[1])); assert.deepEqual(nums, [1, 2, 3, 4, 5, 6, 7]);
  const e = u.slice(u.indexOf('## E. Kelimaa AI'), u.indexOf('## F. Tabel')); assert.equal([...e.matchAll(/^(\d+)\. \[ \]/gm)].length, 33);
  const r = src('README.md'); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA (baris checkpoint Paket SY) */); assert.match(r, /Rev 246/); assert.match(r, /BERFUNGSI-BELUM-DIUJI/); assert.match(r, /bukan\*\* bukti APK/); assert.doesNotMatch(r, /belum disegarkan/);
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 246 / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('- **Rev 246 / v0.3.121'));
});
test('tanpa versi/SCHEMA berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev246\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
