// Rev 300a: Bekukan baris dan kolom lembar kerja, MODEL + PENYIMPANAN (tanpa UI): alat beku di lembar-beku.js (malas), cleanTab, sisip/hapus, urut, SCHEMA 22.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as B from '../src/js/lembar-beku.js'; // alat beku (modul malas); model dasar (fz, cleanFreeze, geser sisip/hapus) di lembar.js
import * as A from '../src/js/lembar-alat.js';
import * as S from '../src/js/storage.js';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => L.newTab('Uji', 12);

test('Rev 300a: alat beku = modul MALAS murni (hanya impor lembar.js); lembar.js statis tidak mengimpornya; tanpa DOM/penyimpanan', () => {
  const m = src('src/js/lembar-beku.js'); assert.deepEqual(m.match(/^import .*$/gm).map((x) => x.replace(/ .*from /, ' ')), ["import './lembar.js';"]); assert.ok(!/document\.|window\.|localStorage|eval\(|fetch\(/.test(m));
  assert.ok(!/lembar-beku/.test(src('src/js/lembar.js'))); assert.ok(!/lembar-beku/.test(src('src/js/main.js'))); assert.match(src('src/js/lembar-alat.js'), /from '\.\/lembar-beku\.js'/);
});
test('Rev 300a: tab baru TIDAK punya fz; getFreeze = nol; isFrozen salah', () => {
  const t = mk(); assert.equal('fz' in t, false); assert.deepEqual(B.getFreeze(t), { r: 0, c: 0 }); assert.equal(B.isFrozen(t), false); assert.equal(B.freezeLabel(t), 'tidak ada');
});
test('Rev 300a: setFreeze memotong ke batas (5 baris, 3 kolom) dan menyisakan 1 baris/kolom bebas', () => {
  const t = mk(); assert.equal(B.setFreeze(t, { r: 99, c: 99 }), true); assert.deepEqual(t.fz, { r: 5, c: 3 });
  const kecil = L.cleanTab({ id: 'tkecil', name: 'k', cols: [{ id: 'cA' }, { id: 'cB' }], rows: [{ id: 'r1', cells: {} }, { id: 'r2', cells: {} }] });
  B.setFreeze(kecil, { r: 9, c: 9 }); assert.deepEqual(kecil.fz, { r: 1, c: 1 });
});
test('Rev 300a: setFreeze mengembalikan false bila tak berubah; patch parsial menjaga sisi lain; nol-nol menghapus fz', () => {
  const t = mk(); assert.equal(B.setFreeze(t, {}), false); assert.equal(B.setFreeze(t, { r: 2 }), true); assert.equal(B.setFreeze(t, { r: 2 }), false);
  assert.equal(B.setFreeze(t, { c: 1 }), true); assert.deepEqual(t.fz, { r: 2, c: 1 }); assert.equal(B.freezeLabel(t), '2 baris + 1 kolom');
  assert.equal(B.setFreeze(t, { r: 0, c: 0 }), true); assert.equal('fz' in t, false);
});
test('Rev 300a: nilai aneh (teks, negatif, pecahan, NaN) dibersihkan', () => {
  const t = mk(); B.setFreeze(t, { r: '2', c: -3 }); assert.deepEqual(t.fz, { r: 2, c: 0 });
  B.setFreeze(t, { r: 1.9, c: 'x' }); assert.deepEqual(t.fz, { r: 1, c: 0 }); B.setFreeze(t, { r: NaN, c: null }); assert.equal('fz' in t, false);
});
test('Rev 300a: freezeBy semua mode (none/row1/row2/col1/rows/cols/both) dan mode tak sah = tidak berubah', () => {
  const t = mk();
  assert.deepEqual(B.freezeBy(t, 'row1'), { changed: true, r: 1, c: 0 }); assert.deepEqual(B.freezeBy(t, 'row2'), { changed: true, r: 2, c: 0 }); assert.deepEqual(B.freezeBy(t, 'col1'), { changed: true, r: 2, c: 1 });
  assert.deepEqual(B.freezeBy(t, 'rows', 3, 0), { changed: true, r: 4, c: 1 }); assert.deepEqual(B.freezeBy(t, 'cols', 0, 2), { changed: true, r: 4, c: 3 });
  assert.deepEqual(B.freezeBy(t, 'both', 0, 0), { changed: true, r: 1, c: 1 }); assert.deepEqual(B.freezeBy(t, 'none'), { changed: true, r: 0, c: 0 });
  assert.deepEqual(B.freezeBy(t, 'rows'), { changed: false, r: 0, c: 0 }); assert.deepEqual(B.freezeBy(t, 'ngawur', 1, 1), { changed: false, r: 0, c: 0 });
  assert.deepEqual(B.freezeBy(t, 'rows', 40, 0), { changed: true, r: 5, c: 0 }); // baris terpilih jauh di bawah = dipotong ke batas
});
test('Rev 300a: cleanTab menjaga fz sah, membuang fz rusak, dan data lama tetap persis tanpa fz', () => {
  const t = mk(); B.setFreeze(t, { r: 2, c: 1 }); const c = L.cleanTab(JSON.parse(JSON.stringify(t))); assert.deepEqual(c.fz, { r: 2, c: 1 });
  const rusak = JSON.parse(JSON.stringify(mk())); rusak.fz = 'ngawur'; assert.equal('fz' in L.cleanTab(rusak), false);
  const lama = JSON.parse(JSON.stringify(mk())); assert.equal('fz' in L.cleanTab(lama), false);
  const besar = JSON.parse(JSON.stringify(mk())); besar.fz = { r: 500, c: 500 }; assert.deepEqual(L.cleanTab(besar).fz, { r: 5, c: 3 });
});
test('Rev 300a: sisip baris DI DALAM area beku melebarkannya; di luar tidak', () => {
  const t = mk(); B.setFreeze(t, { r: 2 }); L.insertRow(t, 5); assert.equal(t.fz.r, 2); L.insertRow(t, 1); assert.equal(t.fz.r, 3); L.insertRow(t, 0); assert.equal(t.fz.r, 4);
});
test('Rev 300a: hapus baris di dalam area beku memperkecilnya; hapus di luar tidak; hapus baris terakhir beku menghapus fz', () => {
  const t = mk(); B.setFreeze(t, { r: 2 }); L.deleteRow(t, t.rows[8].id); assert.equal(t.fz.r, 2); L.deleteRow(t, t.rows[0].id); assert.equal(t.fz.r, 1); L.deleteRow(t, t.rows[0].id); assert.equal('fz' in t, false);
});
test('Rev 300a: sisip dan hapus KOLOM menggeser area beku kolom dengan aturan yang sama', () => {
  const t = mk(); B.setFreeze(t, { c: 2 }); for (let i = 0; i < 4; i++) L.deleteCol(t, t.cols[t.cols.length - 1].id); assert.equal(t.fz.c, 2); L.insertCol(t, 0); assert.equal(t.fz.c, 3); L.insertCol(t, 10); assert.equal(t.fz.c, 3);
  L.deleteCol(t, t.cols[1].id); assert.equal(t.fz.c, 2); L.deleteCol(t, t.cols[15].id); assert.equal(t.fz.c, 2); L.deleteCol(t, t.cols[0].id); assert.equal(t.fz.c, 1); L.deleteCol(t, t.cols[0].id); assert.equal('fz' in t, false);
});
test('Rev 300a: tab yang menyusut (hapus baris sampai tersisa sedikit) tetap menyisakan 1 baris bebas', () => {
  const t = L.cleanTab({ id: 'tmini', name: 'm', cols: [{ id: 'cA' }, { id: 'cB' }], rows: [1, 2, 3].map((i) => ({ id: 'r' + i, cells: {} })) }); B.setFreeze(t, { r: 2 }); L.deleteRow(t, 'r3'); assert.deepEqual(t.fz, { r: 1, c: 0 });
});
test('Rev 300a: Urut A-Z TIDAK memindahkan baris beku (judul tetap di atas) walau baris itu terlihat seperti data', () => {
  const t = mk(); const set = (r, v) => L.setCell(t, t.rows[r].id, 'cA', { v });
  set(0, 'Zebra'); set(1, 'Judul kedua'); set(2, 'c'); set(3, 'a'); set(4, 'b'); B.setFreeze(t, { r: 2 });
  const r = A.sortTab(t, 0, 'asc', { header: false }); assert.equal(r.ok, true);
  assert.equal(t.rows[0].cells.cA.v, 'Zebra'); assert.equal(t.rows[1].cells.cA.v, 'Judul kedua'); assert.deepEqual([2, 3, 4].map((i) => t.rows[i].cells.cA.v), ['a', 'b', 'c']); assert.equal(r.skipped, 2);
});
test('Rev 300a: Urut tanpa beku tidak berubah perilakunya', () => {
  const t = mk(); const set = (r, v) => L.setCell(t, t.rows[r].id, 'cA', { v }); set(0, 'c'); set(1, 'a'); set(2, 'b'); A.sortTab(t, 0, 'asc', { header: false });
  assert.deepEqual([0, 1, 2].map((i) => t.rows[i].cells.cA.v), ['a', 'b', 'c']);
});
test('Rev 300a: lewat normalize penyimpanan + kembali (satu putaran) fz utuh; data v21 tanpa fz tetap valid', () => {
  assert.equal(S.SCHEMA, 22); const sh = L.newSheet({ id: 'sbeku1' }); B.setFreeze(sh.tabs[0], { r: 1, c: 1 });
  const d = S.normalize({ version: 21, habits: [], tasks: [], notes: [], priv: [], trash: [], sheets: { sbeku1: JSON.parse(JSON.stringify(sh)) } });
  assert.deepEqual(d.sheets.sbeku1.tabs[0].fz, { r: 1, c: 1 }); assert.equal(d.version, 22);
  const lama = S.normalize({ version: 21, habits: [], tasks: [], notes: [], priv: [], trash: [], sheets: { sbeku2: JSON.parse(JSON.stringify(L.newSheet({ id: 'sbeku2' }))) } });
  assert.equal('fz' in lama.sheets.sbeku2.tabs[0], false);
});
test('Rev 300a: versi 0.3.121, SCHEMA 22, tes terdaftar (jaga "tanpa UI/CSS" DICABUT DISENGAJA di Rev 300b: UI + CSS beku baris kini ada, dites di rev300b)', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('node tests/rev300.test.mjs'));
});
console.log(n + ' tes lulus (Rev 300a)');
