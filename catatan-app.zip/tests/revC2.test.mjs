// Rev C-2 (0.3.2): perbaikan blok Suasana hati + panel Sisipkan. Perilaku nyata (simpan-buka ulang, ketukan) diuji di Chromium; berkas ini mengunci kontraknya.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { parseNoteHtml, blocksToText, blocksToMarkdown } from '../src/js/export.js';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const nt = src('src/js/notes.js'), css = src('src/css/styles.css'), pkg = JSON.parse(src('package.json'));

test('Rev C-2: versi 0.3.2 selaras di package.json dan Setelan', () => {
  assert.equal(pkg.version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('v0.3.121'));
});
test('Rev C-2: BUTTON tidak lagi lolos sanitizer; menu ukuran (.mood-tools) tidak pernah tersimpan', () => {
  assert.ok(!/const OK = new Set\([^)]*'BUTTON'/.test(nt));
  assert.match(nt, /querySelectorAll\('\.mood-tools'\)\.forEach\(\(x\) => x\.remove\(\)\)/);
  assert.ok(!/'mood-menu','mood-tools'|'mood-tools','mood-menu'/.test(nt));
});
test('Rev C-2: judul dan sorotan wajah diturunkan dari data-mood-value (syncMood) dan kelas selected boleh tersimpan', () => {
  assert.match(nt, /export function syncMood\(block\)/);
  assert.match(nt, /querySelectorAll\('\.mood-block'\)\.forEach\(\(el\) => syncMood\(el\)\)/);
  assert.match(nt, /v === 'mood-face selected'/);
});
test('Rev C-2: teks polos catatan (pratinjau/pencarian) meringkas blok Suasana hati', () => {
  assert.match(nt, /export function notePlain\(ed\)/);
  assert.match(nt, /n\.text = notePlain\(ed\)/);
  assert.ok(!/n\.text = ed\.innerText\.trim\(\)/.test(nt));
});
test('Rev C-2: Kutipan/Tabel/Gambar hanya lewat tombol insertBtn; tombol kembar di bilah dihapus (bukan disembunyikan)', () => {
  assert.ok(!nt.includes("'data-cmd': 'insert-table'") && !nt.includes("'data-cmd': 'insert-image'"));
  assert.ok(!/class: 'fmt legacy-insert'/.test(nt) && !css.includes('legacy-insert'));
  for (const k of ['mood', 'quote', 'table', 'image']) assert.ok(nt.includes(`insertBtn('${k}'`), k);
});
test('Rev C-2 (Rev 88): panel lain menutup saat tombol sisip diketuk; Kembali/label tidak lagi mengurus panel Sisipkan', () => {
  assert.match(nt, /const closePanels = /);
  assert.match(nt, /menu: \(\) => closeMenu\(\) \|\| closeLp\(\)/);
  assert.match(nt, /const runInsert = \(kind\) => \{\s*closePanels\(\);/);
  assert.match(nt, /const openLp = \(\) => \{ closeRp\(\);/);
});
test('Rev C-2: ketukan kontrol blok tidak menelan fokus, area sentuh >= 44px, mode Baca mengunci blok', () => {
  assert.match(nt, /addEventListener\('pointerdown', \(e\) => \{ if \(moodTarget\(e\)\) e\.preventDefault\(\); \}\)/);
  assert.match(nt, /classList\.contains\('ed-baca'\)\) return/);
  assert.match(css, /\.mood-menu\{[^}]*width:44px;height:44px/);
  assert.match(css, /\.mood-face\{[^}]*height:44px/);
  assert.match(css, /\.ed-baca \.mood-menu\{display:none\}/);
});
test('Rev C-2: Undo mencatat ganti wajah, ukuran, dan hapus; sisip tidak masuk sel tabel dan kursor ke paragraf baru', () => {
  assert.match(nt, /infoKey\('dlmTabel', label\)/);
  assert.match(nt, /placeBlock\(block, caretRange\(\), 'Suasana hati'\)/);
  assert.match(nt, /caret\.setStart\(tail, 0\)/);
  assert.ok((nt.match(/flushHist\(\)/g) || []).length > 20);
});
test('Rev C-2: menu ukuran/hapus adalah baris dalam alur di bawah judul (tidak melayang menutupi wajah)', () => {
  assert.match(nt, /querySelector\('\.mood-head'\)\.after\(tools\)/);
  assert.ok(!/\.mood-tools\{[^}]*position:absolute/.test(css));
});
test('Rev C-2: ekspor melewati isi blok dan menulis satu baris "Suasana hati: ..." (PDF/JPG, TXT, MD)', () => {
  const html = '<p>Halo</p><div class="mood-block" contenteditable="false" data-mood-size="normal" data-mood-value="1"><div class="mood-head"><strong class="mood-title">Kurang baik</strong><span class="mood-menu" data-mood-action="menu">⋮</span></div><div class="mood-faces"><span class="mood-face" data-mood-value="0">☹</span><span class="mood-face selected" data-mood-value="1">🙁</span></div></div><p>Sesudah</p>';
  const b = parseNoteHtml(html);
  assert.deepEqual(b.map((x) => x.runs.map((r) => r.t).join('')), ['Halo', 'Suasana hati: Kurang baik', 'Sesudah']);
  assert.ok(!/[☹🙁⋮]/.test(blocksToText('T', b)));
  assert.ok(blocksToMarkdown('T', b).includes('**Suasana hati: Kurang baik**'));
  const bad = parseNoteHtml('<div class="mood-block" data-mood-value="9"><div class="mood-head"></div></div><p>x</p>');
  assert.equal(bad[0].runs[0].t, 'Suasana hati: Sangat baik'); // nilai rusak jatuh ke bawaan
});
