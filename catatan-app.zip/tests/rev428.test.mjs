// Rev 428 / PART SY5a: aksi `img` di Worker (gambar catatan di R2). R2 TIRUAN; tanpa jaringan. BUKAN bukti dari Cloudflare nyata dan BELUM ada pemanggil di aplikasi (SY5b).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, rd = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = Date.UTC(2026, 10, 24, 5, 0, 0);
const r2 = () => { const m = new Map(), o = { m, calls: [], head: async (k) => (m.has(k) ? { size: m.get(k).u.length } : null), get: async (k) => (m.has(k) ? { arrayBuffer: async () => m.get(k).u.slice().buffer } : null), put: async (k, u, opt) => { o.calls.push(['put', k]); m.set(k, { u: new Uint8Array(u), opt }); }, delete: async (k) => { m.delete(k); }, list: async ({ prefix, cursor, limit }) => { const all = [...m.keys()].filter((k) => k.startsWith(prefix)).sort(); const st = cursor ? Number(cursor) : 0; const sl = all.slice(st, st + limit); return { objects: sl.map((k) => ({ key: k, size: m.get(k).u.length })), truncated: st + limit < all.length, cursor: String(st + limit) }; } }; return o; };
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); }, delete: async (k) => { m.delete(k); } }; };
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', PASS_DESY: 'desy-secret-34', KV: kv(), IMG: r2(), ...x });
const mk = (ext, n = 300, fill = 7) => { const u = new Uint8Array(n).fill(fill); const h = { png: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0], jpg: [0xff, 0xd8, 0xff, 0xe0], webp: [0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x45, 0x42, 0x50, 0x56] }[ext]; h.forEach((b, i) => { u[i] = b; }); return u; };
const b64 = (u) => { let s = ''; for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); return btoa(s); };
const req = (o, key = 'rama-secret-12') => new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key, action: 'img', ...o }) });
async function im(env, o, key) { const r = await T.handle(req(o, key), env, NOW); return { status: r.status, j: await r.json() }; }
const ID = 'abcdefghij1234', ID2 = 'zyxwvutsrq9876';

test('passcode salah = 401; tanpa binding IMG = 503 dengan petunjuk R2; aksi img tidak menyentuh jatah AI di KV', async () => {
  assert.equal((await im(env0(), { op: 'stat' }, 'salah-salah-1')).status, 401);
  const r = await im({ PASS_RAMA: 'rama-secret-12', KV: kv() }, { op: 'stat' }); assert.equal(r.status, 503); assert.match(r.j.error, /R2/);
  const e = env0(); await im(e, { op: 'put', id: ID, x: 'webp', b64: b64(mk('webp')) });
  for (const k of e.KV.m.keys()) assert.ok(!/^(use|mon|tok|day)/.test(k) || /fail/.test(k), 'kunci KV tak terduga: ' + k);
});

test('put lalu get: isi sama persis untuk webp, jpg, png; put kedua dengan id sama dilewati (existed)', async () => {
  const e = env0();
  for (const x of ['webp', 'jpg', 'png']) {
    const id = x + 'Gambar0001', u = mk(x, 1000, 9);
    const a = await im(e, { op: 'put', id, x, b64: b64(u) }); assert.deepEqual(a.j, { ok: true, existed: false });
    const g = await im(e, { op: 'get', id, x }); assert.equal(g.status, 200); assert.equal(g.j.bytes, 1000); assert.equal(g.j.mime, { webp: 'image/webp', jpg: 'image/jpeg', png: 'image/png' }[x]); assert.equal(g.j.b64, b64(u));
    const b = await im(e, { op: 'put', id, x, b64: b64(mk(x, 500)) }); assert.deepEqual(b.j, { ok: true, existed: true });
    assert.equal(e.IMG.m.get('img/rama/' + id + '.' + x).u.length, 1000, 'isi lama tidak ditimpa');
  }
  assert.equal(e.IMG.calls.length, 3, 'tepat tiga tulis');
});

test('validasi put: id/jenis/base64/ukuran/byte awal', async () => {
  const e = env0(), ok = b64(mk('png'));
  assert.equal((await im(e, { op: 'put', id: 'pendek', x: 'png', b64: ok })).status, 400);
  assert.equal((await im(e, { op: 'put', id: '../../x/yyyyyyy', x: 'png', b64: ok })).status, 400);
  assert.equal((await im(e, { op: 'put', id: ID, x: 'gif', b64: ok })).status, 400);
  assert.equal((await im(e, { op: 'put', id: ID, x: 'png', b64: 'bukan base64!!' })).status, 400);
  assert.equal((await im(e, { op: 'put', id: ID, x: 'png', b64: '' })).status, 400);
  assert.equal((await im(e, { op: 'put', id: ID, x: 'webp', b64: ok })).status, 400, 'byte awal png tidak boleh disimpan sebagai webp');
  assert.equal((await im(e, { op: 'put', id: ID, x: 'png', b64: b64(mk('png', 10)) })).status, 400, 'terlalu kecil');
  const big = await im(e, { op: 'put', id: ID, x: 'png', b64: b64(mk('png', T.MAX_IMG_BYTES + 1)) }); assert.equal(big.status, 413);
  assert.equal(e.IMG.m.size, 0, 'tidak ada yang tersimpan');
});

test('batas tepat: gambar 600000 byte lolos lewat handle (badan > 600000 huruf), 600001 ditolak', async () => {
  const e = env0(); const a = await im(e, { op: 'put', id: ID, x: 'jpg', b64: b64(mk('jpg', T.MAX_IMG_BYTES)) });
  assert.equal(a.status, 200, JSON.stringify(a.j)); assert.equal(e.IMG.m.get('img/rama/' + ID + '.jpg').u.length, T.MAX_IMG_BYTES);
  const g = await im(e, { op: 'get', id: ID, x: 'jpg' }); assert.equal(g.j.bytes, T.MAX_IMG_BYTES);
  assert.equal((await im(e, { op: 'put', id: ID2, x: 'jpg', b64: b64(mk('jpg', T.MAX_IMG_BYTES + 1)) })).status, 413);
});

test('batas badan: aksi lain (sync, chat) tetap dibatasi seperti semula; badan img di atas 820000 huruf ditolak', async () => {
  const e = env0(); const huge = 'x'.repeat(650000);
  const r1 = await T.handle(new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'sync', push: [], pad: huge }) }), e, NOW); assert.equal(r1.status, 413);
  const r2_ = await T.handle(new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'chat', messages: [], pad: huge }) }), e, NOW); assert.equal(r2_.status, 413);
  const r3 = await T.handle(new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'img', op: 'stat', pad: 'x'.repeat(830000) }) }), e, NOW); assert.equal(r3.status, 413);
});

test('terpisah per orang: milik Rama tidak terbaca, tidak terhapus, dan tidak terhitung oleh Desy', async () => {
  const e = env0(); await im(e, { op: 'put', id: ID, x: 'png', b64: b64(mk('png')) });
  assert.equal((await im(e, { op: 'get', id: ID, x: 'png' }, 'desy-secret-34')).status, 404);
  await im(e, { op: 'del', id: ID, x: 'png' }, 'desy-secret-34'); assert.ok(e.IMG.m.has('img/rama/' + ID + '.png'));
  assert.deepEqual((await im(e, { op: 'has', ids: [{ id: ID, x: 'png' }] }, 'desy-secret-34')).j, { ok: true, have: [], missing: [ID] });
  assert.equal((await im(e, { op: 'stat' }, 'desy-secret-34')).j.count, 0);
  assert.equal((await im(e, { op: 'stat' })).j.count, 1);
  await im(e, { op: 'put', id: ID, x: 'png', b64: b64(mk('png', 400)) }, 'desy-secret-34'); assert.ok(e.IMG.m.has('img/desy/' + ID + '.png'), 'Desy punya salinan sendiri');
});

test('has: dua daftar (ada/tidak ada), daftar kosong/terlalu panjang/tak sah ditolak', async () => {
  const e = env0(); await im(e, { op: 'put', id: ID, x: 'webp', b64: b64(mk('webp')) });
  assert.deepEqual((await im(e, { op: 'has', ids: [{ id: ID, x: 'webp' }, { id: ID2, x: 'webp' }] })).j, { ok: true, have: [ID], missing: [ID2] });
  assert.equal((await im(e, { op: 'has', ids: [] })).status, 400);
  assert.equal((await im(e, { op: 'has', ids: Array.from({ length: T.IMG_HAS_MAX + 1 }, () => ({ id: ID, x: 'webp' })) })).status, 400);
  assert.equal((await im(e, { op: 'has', ids: [{ id: 'x', x: 'webp' }] })).status, 400);
  assert.equal((await im(e, { op: 'has', ids: Array.from({ length: T.IMG_HAS_MAX }, () => ({ id: ID, x: 'webp' })) })).status, 200);
});

test('del lalu get = 404 missing; del gambar yang tidak ada tetap ok; operasi tak dikenal 400', async () => {
  const e = env0(); await im(e, { op: 'put', id: ID, x: 'png', b64: b64(mk('png')) });
  assert.equal((await im(e, { op: 'del', id: ID, x: 'png' })).j.ok, true);
  const g = await im(e, { op: 'get', id: ID, x: 'png' }); assert.equal(g.status, 404); assert.equal(g.j.missing, true);
  assert.equal((await im(e, { op: 'del', id: ID, x: 'png' })).status, 200);
  assert.equal((await im(e, { op: 'salto' })).status, 400); assert.equal((await im(e, {})).status, 400);
});

test('stat: jumlah dan byte; terpotong (partial) bila lebih dari halaman yang diizinkan', async () => {
  const e = env0(); for (let i = 0; i < 3; i++) await im(e, { op: 'put', id: 'gambarSatu' + i, x: 'png', b64: b64(mk('png', 100 + i)) });
  const s = await im(e, { op: 'stat' }); assert.deepEqual(s.j, { ok: true, count: 3, bytes: 303 });
  const e2 = env0(); const big = r2(); const orig = big.list; big.list = async (o) => { const l = await orig(o); return { ...l, truncated: true, cursor: 'x' }; }; e2.IMG = big;
  await im(e2, { op: 'put', id: ID, x: 'png', b64: b64(mk('png')) }); const p = await im(e2, { op: 'stat' }); assert.equal(p.j.partial, true);
});

test('kemurnian: base64 gambar tidak dicatat ke log; Worker memakai binding bernama IMG; dokumen mencatat Rev 428', () => {
  const src = rd('backend/cloudflare/worker.mjs'); const seg = src.slice(src.indexOf('async function img('), src.indexOf('async function handle('));
  assert.ok(!/console\./.test(seg)); assert.match(seg, /env\.IMG/);
  assert.match(rd('RIWAYAT.md'), /\*\*Rev 428 \/ v0\.3\.121/); assert.match(rd('PROMPT_SERAH_TERIMA.md'), /\*\*Rev 428 \/ v0\.3\.121/);
});
