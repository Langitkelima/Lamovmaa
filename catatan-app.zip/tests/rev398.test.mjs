// Rev 398 / PART M3: impor Markdown. Perilaku HP (pemilih berkas Android, sanitize di peramban nyata) BELUM diuji.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import { planMarkdownImport, commitMarkdownImport, importSummary, IMPOR_MAX_FILES, IMPOR_MAX_FILE_CHARS, IMPOR_MAX_TOTAL_CHARS } from '../src/js/impor-md.js';
import { planMarkdownExport, buildMarkdownZipBytes } from '../src/js/ekspor-md.js';
import { readZipIndex, readZipEntry, utf8 } from '../src/js/zip.js';
import { parseNoteHtml } from '../src/js/export.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
let seq = 0; const deps = { sanitize: (h) => h, newId: () => 'id' + (++seq), now: 1000 };
const D = () => ({ settings: { labels: [{ id: 'L1', name: 'Rumah' }] }, notes: [{ id: 'n0', title: 'Lama', html: '<div>lama</div>' }], priv: [{ id: 'p0', title: 'Rahasia', html: '<div>x</div>' }] });

test('rencana: judul dari front matter / # / nama berkas; label lama dipakai (tanpa beda huruf), label baru dibuat', () => {
  const p = planMarkdownImport([
    { name: 'a.md', text: '---\njudul: "Belanja"\nlabel: ["rumah", "baru"]\n---\n- [x] beras\n' },
    { name: 'rapat-mingguan.md', text: 'isi saja' },
    { name: 'b.txt', text: '# Judul B\n\nteks' },
  ], [{ id: 'L1', name: 'Rumah' }]);
  assert.deepEqual(p.items.map((i) => i.title), ['Belanja', 'rapat mingguan', 'Judul B']);
  assert.deepEqual(p.items[0].labelNames, ['Rumah', 'baru']); assert.deepEqual(p.newLabels, ['baru']);
});
test('rencana: dilewati dengan alasan (bukan md, kosong, privat/, terlalu besar, batas jumlah/total); tersembunyi dan gambar/ diam', () => {
  const p = planMarkdownImport([
    { name: 'x.pdf', text: '' }, { name: 'k.md', text: '   ' }, { name: 'privat/s.md', text: 'rahasia' }, { name: '.DS_Store', text: '' }, { name: 'gambar/a.jpg', text: '' },
    { name: 'besar.md', text: 'a'.repeat(IMPOR_MAX_FILE_CHARS + 1) }, { name: 'ok.md', text: 'ok' },
  ]);
  assert.equal(p.items.length, 1); const why = Object.fromEntries(p.skipped.map((s) => [s.name, s.reason]));
  assert.match(why['x.pdf'], /bukan/); assert.equal(why['k.md'], 'kosong'); assert.match(why['s.md'], /privat/); assert.match(why['besar.md'], /terlalu besar/);
  assert.ok(!('.DS_Store' in why) && !('a.jpg' in why));
  const many = planMarkdownImport(Array.from({ length: IMPOR_MAX_FILES + 3 }, (_, i) => ({ name: 'n' + i + '.md', text: 't' + i })));
  assert.equal(many.items.length, IMPOR_MAX_FILES); assert.equal(many.skipped.length, 3); assert.match(many.skipped[0].reason, /batas/);
  const big = 'a'.repeat(900000); const tot = planMarkdownImport([1, 2, 3].map((i) => ({ name: 't' + i + '.md', text: big })));
  assert.equal(tot.items.length, 2); assert.match(tot.skipped[0].reason, /total impor/); assert.ok(IMPOR_MAX_TOTAL_CHARS >= 1800000);
});
test('rencana: batas jumlah label (20) dan peringatan gambar/terpotong dihitung', () => {
  const labs = Array.from({ length: 19 }, (_, i) => ({ id: 'q' + i, name: 'l' + i }));
  const p = planMarkdownImport([{ name: 'a.md', text: '---\nlabel: [x1, x2, x3]\n---\n![f](a.png) ![g](b.png)' }], labs);
  assert.deepEqual(p.newLabels, ['x1']); assert.equal(p.labelsDropped, 2); assert.equal(p.warnings.gambar, 2);
  assert.match(importSummary(p), /gambar tidak ikut/);
});
test('commit: catatan BIASA saja (priv tidak berubah), id baru, label dibuat, teks cari terisi, sanitize dipanggil, catatan lama utuh', () => {
  const d = D(), calls = [];
  const p = planMarkdownImport([{ name: 'a.md', text: '---\njudul: A\nlabel: [Rumah, Baru]\n---\n- [x] satu\n\nparagraf' }], d.settings.labels);
  const r = commitMarkdownImport(d, p, { ...deps, sanitize: (h) => { calls.push(h); return h; } });
  assert.equal(r.added, 1); assert.equal(r.labelsAdded, 1); assert.equal(calls.length, 1);
  assert.equal(d.notes.length, 2); assert.equal(d.notes[0].id, 'n0'); assert.equal(d.priv.length, 1);
  const n = d.notes[1]; assert.equal(n.title, 'A'); assert.ok(n.text.includes('satu') && n.text.includes('paragraf')); assert.equal(n.pin, false); assert.equal(n.col, '');
  assert.equal(d.settings.labels.length, 2); assert.deepEqual(n.labels, ['L1', d.settings.labels[1].id]);
  assert.deepEqual(parseNoteHtml(n.html).map((b) => b.kind), ['todo', 'p']);
});
test('bolak-balik: ekspor (ZIP) lalu impor menjaga judul, label, ceklis; folder privat tidak diimpor', async () => {
  const src = { settings: { labels: [{ id: 'a', name: 'kerja' }] }, notes: [{ id: '1', title: 'Rapat', html: '<div class="todo"><input type="checkbox" checked="">&nbsp;Siap</div>', labels: ['a'] }], priv: [{ id: 'p', title: 'Rahasia', html: '<div>sandi</div>' }] };
  const z = buildMarkdownZipBytes(planMarkdownExport(src, { priv: true }, new Date(2026, 10, 22)));
  const blob = new Blob([z]), idx = await readZipIndex(blob), files = [];
  for (const e of idx) files.push({ name: e.name, text: utf8.decode(await readZipEntry(blob, e)) });
  const p = planMarkdownImport(files, []);
  assert.equal(p.items.length, 1); assert.equal(p.items[0].title, 'Rapat'); assert.deepEqual(p.items[0].labelNames, ['kerja']);
  assert.equal(p.skipped.length, 1); assert.match(p.skipped[0].reason, /privat/);
  const d = { settings: { labels: [] }, notes: [], priv: [] }; commitMarkdownImport(d, p, deps);
  assert.equal(parseNoteHtml(d.notes[0].html)[0].checked, true); assert.equal(d.priv.length, 0);
});
test('pemasangan: baris Setelan memuat modul MALAS; UI memakai sanitize, menjelaskan alasan, dan konfirmasi dulu; mesin tanpa DOM', () => {
  const st = rd('src/js/sync-ui.js'); assert.ok(st.includes("import('./impor-md-ui.js')") && !/^import .*impor-md/m.test(st) && !/^import .*impor-md/m.test(rd('src/js/main.js')));
  const ui = rd('src/js/impor-md-ui.js'); assert.ok(ui.includes('sanitize') && ui.includes('dlg(') && ui.includes('bukan Catatan Privat') && ui.includes('Tidak ada catatan yang bisa diimpor'));
  assert.ok(!/\b(document|window|localStorage|fetch)\b/.test(rd('src/js/impor-md.js')));
  assert.ok(!/data\.priv\.push|\.priv\b/.test(rd('src/js/impor-md.js').replace(/\/\/.*$/gm, '')));
});
