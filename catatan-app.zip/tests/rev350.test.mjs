// Rev 350 / PART R5: ekspor, cadangan/pulihkan, dan teks tidak merusak li berpengingat dan tidak membocorkan data-cid. Mesin murni; Chromium di tools/audit_ekspor_li_350.py.
import test from 'node:test';
import assert from 'node:assert/strict';
import { parseNoteHtml, blocksToText, blocksToMarkdown } from '../src/js/export.js';
import { normalize, exportJSON, importJSON, emptyData } from '../src/js/storage.js';

const dengan = '<ul><li data-cid="bul01">Telepon <b>ibu</b></li><li>tanpa</li></ul><ol><li data-cid="num02">Kirim laporan<ul><li data-cid="anak3">Anak</li></ul></li><li data-cid="num04">Lagi</li></ol><div class="todo" data-cid="cek05"><input type="checkbox" checked> Centang</div>';
const tanpa = dengan.replace(/ data-cid="[a-z0-9]+"/g, '');

test('R5: parseNoteHtml: blok identik dengan/tanpa data-cid pada li (tidak ada teks/atribut bocor, struktur sama)', () => {
  const a = parseNoteHtml(dengan), b = parseNoteHtml(tanpa);
  assert.deepEqual(a, b);
  assert.ok(a.length >= 5);
  assert.doesNotMatch(JSON.stringify(a), /data-cid|bul01|num02|anak3|num04|cek05/);
});
test('R5: TXT dan Markdown tidak memuat cid dan sama persis dengan versi tanpa cid', () => {
  const ta = blocksToText('Belanja', parseNoteHtml(dengan)), tb = blocksToText('Belanja', parseNoteHtml(tanpa));
  const ma = blocksToMarkdown('Belanja', parseNoteHtml(dengan)), mb = blocksToMarkdown('Belanja', parseNoteHtml(tanpa));
  assert.equal(ta, tb); assert.equal(ma, mb);
  assert.doesNotMatch(ta + ma, /data-cid|bul01|num02|anak3|num04|cek05/);
  assert.match(ta, /Telepon ibu/); assert.match(ma, /Kirim laporan/);
});
test('R5: cadangan/pulihkan: pengingat li ikut pulang utuh; cbRem yatim (cid tak ada di HTML) dipangkas; rapih di Privat', () => {
  const rule = { at: 4102444800000, repeat: 'none', sticky: false };
  const d = emptyData();
  d.notes = [{ id: 'n1', title: 'Belanja', html: '<ul><li data-cid="bul01">Telepon ibu</li></ul><ol><li data-cid="num02">Kirim</li></ol>', text: 'Telepon ibu Kirim', created: 1, updated: 1, cbRem: { bul01: rule, num02: rule, hilang: rule } }];
  const kembali = importJSON(exportJSON(normalize(d)));
  const n = (kembali.data || kembali).notes[0];
  assert.deepEqual(Object.keys(n.cbRem).sort(), ['bul01', 'num02']);
  assert.match(n.html, /<li data-cid="bul01">Telepon ibu<\/li>/);
  const p = emptyData(); p.priv = [{ id: 'p1', title: 'P', html: '<ul><li data-cid="bul01">x</li></ul>', text: 'x', created: 1, updated: 1, cbRem: { bul01: rule } }];
  assert.equal('cbRem' in normalize(p).priv[0], false, 'Catatan Privat tidak pernah menyimpan pengingat');
});
