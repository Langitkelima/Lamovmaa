// Rev 151 / U10b-1: model + mesin GABUNG SEL (tanpa UI)
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as G from '../src/js/lembar-gabung.js';
import * as S from '../src/js/storage.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
const mk = () => L.newSheet({ name: 'A' }).tabs[0];
test('addMerge: gabung sel kosong, jangkar kiri-atas, tersimpan sebagai ID', () => {
  const t = mk(); const r = G.addMerge(t, 0, 0, 0, 2); assert.deepEqual(r, { ok: true, cleared: 0 });
  assert.deepEqual(t.merges, [{ r1: t.rows[0].id, c1: t.cols[0].id, r2: t.rows[0].id, c2: t.cols[2].id }]);
  const m = G.mergeAt(t, 0, 1); assert.equal(m.ref, 'A1:C1'); assert.equal(G.isCovered(t, 0, 1), true); assert.equal(G.isCovered(t, 0, 0), false); assert.equal(G.mergeAt(t, 1, 0), null);
  assert.equal(G.mergeMap(t).size, 3);
});
test('addMerge: urutan sudut bebas; satu sel, di luar rentang, tumpang tindih, batas ditolak', () => {
  const t = mk(); assert.ok(G.addMerge(t, 2, 2, 1, 1).ok); assert.equal(G.mergeList(t)[0].ref, 'B2:C3');
  assert.equal(G.addMerge(t, 5, 5, 5, 5).reason, 'kecil'); assert.equal(G.addMerge(t, 0, 0, 999, 0).reason, 'rentang'); assert.equal(G.addMerge(t, 1.5, 0, 2, 0).reason, 'rentang');
  assert.equal(G.addMerge(t, 0, 0, 1, 1).reason, 'tumpang'); assert.equal(G.addMerge(t, 2, 2, 4, 4).reason, 'tumpang');
  const u = mk(); for (let i = 0; i < G.MAX_MERGES; i++) assert.ok(G.addMerge(u, i, 0, i, 1).ok); assert.equal(G.addMerge(u, 25, 0, 25, 1).reason, 'batas');
});
test('addMerge: sel terisi selain jangkar butuh clear=true; jangkar dipertahankan; sel lain dikosongkan', () => {
  const t = mk(); L.setCell(t, t.rows[0].id, t.cols[0].id, { v: 5 }); L.setCell(t, t.rows[0].id, t.cols[1].id, { v: 'x' }); L.setCell(t, t.rows[1].id, t.cols[0].id, { s: { b: true } });
  const p = G.planMerge(t, 0, 0, 1, 1); assert.equal(p.ok, true); assert.equal(p.filled, 1);
  const before = JSON.stringify(t); assert.deepEqual(G.addMerge(t, 0, 0, 1, 1), { ok: false, reason: 'isi', filled: 1, cleared: 0 }); assert.equal(JSON.stringify(t), before);
  assert.deepEqual(G.addMerge(t, 0, 0, 1, 1, { clear: true }), { ok: true, cleared: 1 });
  assert.equal(t.rows[0].cells[t.cols[0].id].v, 5); assert.equal(t.rows[0].cells[t.cols[1].id], undefined); assert.equal(t.rows[1].cells[t.cols[0].id], undefined);
  const u = mk(); L.setCell(u, u.rows[0].id, u.cols[0].id, { v: 1 }); assert.deepEqual(G.addMerge(u, 0, 0, 0, 1), { ok: true, cleared: 0 }); // hanya jangkar terisi
});
test('removeMerge: pisahkan dari sel mana pun di dalamnya; kunci merges hilang bila kosong', () => {
  const t = mk(); G.addMerge(t, 0, 0, 1, 1); G.addMerge(t, 3, 0, 3, 1);
  assert.equal(G.removeMerge(t, 1, 1), true); assert.equal(t.merges.length, 1); assert.equal(G.removeMerge(t, 1, 1), false);
  assert.equal(G.removeMerge(t, 3, 1), true); assert.equal('merges' in t, false);
});
test('hapus/sisip baris-kolom: interior menyusut/membesar, sudut terhapus melepas, satu sel dibuang', () => {
  const t = mk(); G.addMerge(t, 0, 0, 2, 0); // A1:A3
  L.insertRow(t, 1); assert.equal(G.mergeList(t)[0].ref, 'A1:A4');
  L.deleteRow(t, t.rows[1].id); assert.equal(G.mergeList(t)[0].ref, 'A1:A3');
  L.deleteRow(t, t.rows[1].id); assert.equal(G.mergeList(t)[0].ref, 'A1:A2');
  L.deleteRow(t, t.rows[1].id); assert.equal('merges' in t, false); // menyusut jadi satu sel
  const u = mk(); G.addMerge(u, 0, 0, 1, 2); L.deleteCol(u, u.cols[1].id); assert.equal(G.mergeList(u)[0].ref, 'A1:B2');
  L.deleteRow(u, u.rows[0].id); assert.equal('merges' in u, false);
  const v = mk(); G.addMerge(v, 0, 0, 1, 1); L.deleteCol(v, v.cols[0].id); assert.equal('merges' in v, false); // sudut jangkar terhapus
});
test('simpan/muat: cleanTab membuang gabungan rusak, tumpang tindih, dan melebihi batas; data lama tetap sama persis', () => {
  const t = mk(); G.addMerge(t, 0, 0, 0, 1);
  const raw = JSON.parse(JSON.stringify(t)); raw.merges.push({ r1: 'rX', c1: 'cA', r2: 'r2', c2: 'cB' }, { r1: 'r1', c1: 'cA', r2: 'r3', c2: 'cC' }, null, 'x', { r1: 'r5', c1: 'cA', r2: 'r5', c2: 'cA' });
  const c = L.cleanTab(raw); assert.equal(c.merges.length, 1); assert.deepEqual(c.merges[0], t.merges[0]);
  const old = mk(); const oc = L.cleanTab(JSON.parse(JSON.stringify(old))); assert.equal('merges' in oc, false); assert.equal(JSON.stringify(oc), JSON.stringify(old));
  const sh = L.newSheet({ name: 'A' }); G.addMerge(sh.tabs[0], 0, 0, 1, 1); const back = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.deepEqual(back.tabs[0].merges, sh.tabs[0].merges);
});
test('moveTab dan salin tab membawa gabungan tanpa mengubahnya', () => {
  const sh = L.newSheet({ name: 'A' }); L.addTab(sh); G.addMerge(sh.tabs[0], 0, 0, 0, 1); const m = JSON.stringify(sh.tabs[0].merges); L.moveTab(sh, sh.tabs[0].id, 1);
  assert.equal(JSON.stringify(sh.tabs[1].merges), m);
});
test('Rev 151: modul murni TANPA impor, belum ada UI, SCHEMA 16, versi 0.3.121, tes terdaftar', () => {
  const g = src('js/lembar-gabung.js'); assert.ok(!/^\s*import\s/m.test(g)); assert.ok(!/document\.|localStorage|eval\(|new Function|Capacitor/.test(g));
  assert.ok(!src('js/lembar-ui.js').includes('lembar-validasi-gabung')); // UI gabung baru ada sejak Rev 152
  assert.equal(S.SCHEMA, 22);
  const pk = readFileSync(new URL('../package.json', import.meta.url), 'utf8'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev151.test.mjs')); assert.match(src('js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
