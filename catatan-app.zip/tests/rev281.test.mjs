// Rev 281 / V6c-1 (Validasi: daftar pilihan dari rentang sel): model + mesin, TANPA layar baru (editor = V6c-2). Tes AI saja (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { cleanChecks, validate, invalidCells } from '../src/js/lembar-validasi.js';
import { srcRect, itemsFromRange, refreshSrc } from '../src/js/lembar-sumber.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet({ id: 'w', name: 'T' }), tab = sh.tabs[0]; const put = (i, j, v) => L.setCell(tab, tab.rows[i].id, tab.cols[j].id, { v });
  ['Belum', 'proses', 'Selesai', 'BELUM', '', '  Tunda  '].forEach((v, i) => put(i, 0, v)); const S = { c1: tab.cols[0].id, c2: tab.cols[0].id, r1: tab.rows[0].id, r2: tab.rows[5].id };
  return { sh, tab, put, S, text: (i, j) => { const c = tab.rows[i].cells[tab.cols[j].id]; return c && c.v != null ? String(c.v) : ''; } }; };
test('itemsFromRange: urut baris, trim, kosong dan kembar (tak peka huruf) dibuang, batas 20 dan 40 huruf', () => {
  const { tab, S, text, put } = mk(); assert.deepEqual(itemsFromRange(tab, S, text), ['Belum', 'proses', 'Selesai', 'Tunda']);
  put(6, 0, 'x'.repeat(80)); const S2 = { ...S, r2: tab.rows[6].id }; assert.equal(itemsFromRange(tab, S2, text)[4].length, 40);
  for (let i = 0; i < 25; i++) put(i, 1, 'p' + i); assert.equal(itemsFromRange(tab, { ...S, c1: tab.cols[1].id, c2: tab.cols[1].id, r2: tab.rows[24].id }, text).length, 20);
});
test('srcRect: indeks, urutan terbalik dibetulkan, ID hilang = null', () => {
  const { tab, S } = mk(); assert.deepEqual(srcRect(tab, S), { c1: 0, c2: 0, r1: 0, r2: 5 }); assert.deepEqual(srcRect(tab, { ...S, r1: S.r2, r2: S.r1 }), { c1: 0, c2: 0, r1: 0, r2: 5 });
  assert.equal(srcRect(tab, { ...S, r2: 'tidak-ada' }), null); assert.equal(srcRect(tab, null), null);
});
test('cleanChecks: aturan list dengan src boleh tanpa items; src dengan ID hilang dibuang; non-list tidak membawa src', () => {
  const { tab, S } = mk(), raw = [{ id: 'a1', c: tab.cols[1].id, k: 'list', items: [], src: S }];
  const ok = cleanChecks(raw, tab.cols, tab.rows); assert.equal(ok.length, 1); assert.deepEqual(ok[0].src, S); assert.deepEqual(ok[0].items, []);
  assert.equal(cleanChecks([{ ...raw[0], src: { ...S, r2: 'x' } }], tab.cols, tab.rows).length, 0); // tanpa items dan tanpa src sah = dibuang
  assert.equal(cleanChecks([{ ...raw[0], items: ['A'], src: { ...S, c1: 'x' } }], tab.cols, tab.rows)[0].src, undefined);
  assert.equal(cleanChecks([{ id: 'b', c: tab.cols[1].id, k: 'email', src: S }], tab.cols, tab.rows)[0].src, undefined);
  assert.equal(cleanChecks(raw, tab.cols, null).length, 0);
});
test('refreshSrc: isi items dari rentang, idempoten, ikut berubah saat sel sumber diedit, sumber hilang = jadi daftar biasa', () => {
  const { tab, S, text, put } = mk(); tab.checks = cleanChecks([{ id: 'a1', c: tab.cols[1].id, k: 'list', items: [], src: S }], tab.cols, tab.rows);
  assert.equal(refreshSrc(tab, text), true); assert.deepEqual(tab.checks[0].items, ['Belum', 'proses', 'Selesai', 'Tunda']); assert.equal(refreshSrc(tab, text), false);
  put(4, 0, 'Baru'); assert.equal(refreshSrc(tab, text), true); assert.ok(tab.checks[0].items.includes('Baru'));
  assert.equal(L.deleteRow(tab, tab.rows[5].id), true); assert.equal(tab.checks[0].src, undefined); assert.ok(tab.checks[0].items.length > 0); // baris sumber di ujung dihapus: cleanChecks membuang src, daftar terakhir jadi daftar biasa
  const t2 = mk(); t2.tab.checks = [{ id: 'z', c: t2.tab.cols[1].id, k: 'list', items: ['A'], src: { ...t2.S, r2: 'hilang' } }]; assert.equal(refreshSrc(t2.tab, t2.text), true); assert.equal(t2.tab.checks[0].src, undefined);
});
test('validate: pilihan dari rentang dinilai tak peka huruf besar-kecil; rentang kosong = tidak membatasi; invalidCells memakai items segar', () => {
  const { tab, S, text, put } = mk(); tab.checks = cleanChecks([{ id: 'a1', c: tab.cols[1].id, k: 'list', items: [], src: S, rg: { c2: tab.cols[1].id } }], tab.cols, tab.rows);
  put(0, 1, 'SELESAI'); put(1, 1, 'Lain'); refreshSrc(tab, text); assert.equal(validate(tab.checks[0], 'selesai').ok, true); assert.equal(validate(tab.checks[0], 'Lain').ok, false);
  const iv = invalidCells(tab, text); assert.equal(iv.has('1,1'), true); assert.equal(iv.has('0,1'), false);
  for (let i = 0; i < 6; i++) put(i, 0, ''); refreshSrc(tab, text); assert.deepEqual(tab.checks[0].items, []); assert.equal(validate(tab.checks[0], 'Lain').ok, true);
});
test('kabel + anggaran: modul malas murni; hanya lembar-ui.js yang memuatnya; tes terdaftar; SCHEMA tetap', () => {
  const m = src('src/js/lembar-sumber.js'); assert.doesNotMatch(m, /document\.|localStorage|window\.|eval\(|Function\(/); assert.match(m, /from '\.\/lembar-validasi\.js'/);
  assert.match(src('src/js/lembar-ui.js'), /import \{ refreshSrc, itemsFromRange \} from '\.\/lembar-sumber\.js'/);
  for (const f of ['lembar.js', 'lembar-validasi.js', 'lembar-pulau.js', 'main.js']) // Rev 283: lembar-alat.js (malas) kini boleh mengimpor pinSrc/unpinSrc
    assert.doesNotMatch(src('src/js/' + f), /lembar-sumber/, f);
  const pk = JSON.parse(src('package.json')); assert.match(pk.scripts.test, /node tests\/rev281\.test\.mjs/); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
});
