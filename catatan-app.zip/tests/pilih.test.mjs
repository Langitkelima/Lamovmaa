// Tes Rev 26: logika murni mode pilih (pilih.js) + pemeriksaan sumber (tekan lama, bilah, Kembali), header rapi, ikon notifikasi.
import { readFileSync, existsSync } from 'node:fs';
import assert from 'node:assert/strict';
import * as PL from '../src/js/pilih.js';
import { reminderReceiverSource } from '../scripts/apply-native.mjs';
let ok = 0; const t = (name, fn) => { fn(); ok++; console.log('ok - ' + name); };
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const notes = () => [{ id: 'a', pin: true, labels: ['x'] }, { id: 'b', pin: false }, { id: 'c', pin: true, labels: ['x', 'y'] }];

t('toggle: tambah/lepas tanpa duplikat, masukan aneh aman', () => {
  assert.deepEqual(PL.toggle([], 'a'), ['a']); assert.deepEqual(PL.toggle(['a', 'b'], 'a'), ['b']);
  assert.deepEqual(PL.toggle(null, 'a'), ['a']); assert.equal(PL.count(['a', 'b']), 2); assert.equal(PL.count(undefined), 0);
});
t('sematan: semua tersemat -> lepas; selain itu sematkan semua', () => {
  const n = notes();
  assert.equal(PL.allPinned(n, ['a', 'c']), true); assert.equal(PL.nextPinState(n, ['a', 'c']), false);
  assert.equal(PL.allPinned(n, ['a', 'b']), false); assert.equal(PL.nextPinState(n, ['a', 'b']), true);
  assert.equal(PL.allPinned(n, []), false);
});
t('Bagikan hanya bila tepat 1 terpilih dan bukan Privat', () => {
  assert.equal(PL.canShare(['a'], 'note'), true); assert.equal(PL.canShare(['a', 'b'], 'note'), false);
  assert.equal(PL.canShare(['a'], 'priv'), false); assert.equal(PL.canShare([], 'note'), false);
});
t('label: status all/some/none dan ketukan menambah ke semua / melepas dari semua', () => {
  const n = notes();
  assert.equal(PL.labelState(n, ['a', 'c'], 'x'), 'all'); assert.equal(PL.labelState(n, ['a', 'b'], 'x'), 'some'); assert.equal(PL.labelState(n, ['b'], 'x'), 'none');
  assert.equal(PL.applyLabel(n, ['a', 'b'], 'x'), true); assert.deepEqual(n[1].labels, ['x']); assert.deepEqual(n[0].labels, ['x']);
  assert.equal(PL.applyLabel(n, ['a', 'b', 'c'], 'x'), false); assert.equal(n[0].labels, undefined); assert.equal(n[1].labels, undefined); assert.deepEqual(n[2].labels, ['y']);
});
t('warna: berlaku ke terpilih saja; kosong = hapus warna', () => {
  const n = notes(); PL.applyColor(n, ['a', 'b'], '#DCE6F7');
  assert.equal(n[0].col, '#DCE6F7'); assert.equal(n[1].col, '#DCE6F7'); assert.equal(n[2].col, undefined);
  PL.applyColor(n, ['a'], ''); assert.equal(n[0].col, '');
});
t('urutan salinan: diproses dari bawah agar salinan paling atas tetap paling atas', () => {
  const sorted = [{ id: 'a' }, { id: 'b' }, { id: 'c' }];
  assert.deepEqual(PL.copyOrder(sorted, ['c', 'a']).map((x) => x.id), ['c', 'a']);
});

const nj = src('src/js/notes.js'), mj = src('src/js/main.js'), css = src('src/css/styles.css');
t('sumber: tekan lama 450 ms, gerak 8 px membatalkan, click penyusul ditelan, contextmenu dicegah', () => {
  for (const k of ['}, 450)', 'Math.abs(e.clientX - x0) > 8', "addEventListener('contextmenu'", 'if (lpDone) { lpDone = false; return; }', 'sel.press(n.id)', 'sel.tap(n.id)']) assert.ok(nj.includes(k), k);
  assert.ok(css.includes('-webkit-touch-callout:none'));
});
t('sumber: bilah pilih (✕, jumlah, Sematkan, Warna, Label, ⋮) dan menu Buat salinan / Bagikan / Hapus', () => {
  for (const k of ["class: 'selbar'", "class: 'selcnt'", 'PL.nextPinState', 'openColorSheet', 'openLabelSheet', 'bulkCopy', 'bulkDelete', 'PL.canShare', "'Buat salinan'", "'Hapus'"]) assert.ok(nj.includes(k), k);
  assert.ok(/isP \? null : sbtn\(PATH\.pin/.test(nj), 'Privat tanpa tombol sematkan');
});
t('sumber: Privat tanpa sampah (dua konfirmasi), catatan biasa ke sampah dengan Urungkan', () => {
  assert.ok(nj.includes('Langkah 1 dari 2') && nj.includes('Langkah 2 dari 2'));
  assert.ok(nj.includes("data.trash.push({ kind: 'note', item: r.n, at })") && nj.includes('dipindah ke tempat sampah'));
});
t('sumber: Kembali menutup menu pilih lalu keluar mode; pindah tab dan + keluar dari mode', () => {
  assert.ok(mj.includes('closeSelectMenu()') && mj.includes('exitSelect()'));
  assert.ok(mj.indexOf('closeSelectMenu()') < mj.indexOf('backEditor()') && mj.indexOf('backEditor()') < mj.indexOf('if (exitSelect()) return'));
  assert.ok(mj.includes('data-tab') && mj.includes('exitSelect()') && mj.includes("ui.tab === 'privat'"), 'navigasi persisten tetap keluar dari mode pilih dan mengunci Privat saat pindah tab');
});
t('sumber: header rapi, titik kecil di kiri + "Diedit ..." satu baris dalam kapsul', () => {
  assert.ok(nj.includes("class: 'stp' }, svt, edt"));
  assert.ok(nj.includes("'Diedit ' + formatEdited(n.updated)") && !nj.includes("'Diedit\\n'"));
  assert.ok(/\.stp\{[^}]*inline-flex/.test(css) && /\.fsh \.stp \.edt\{[^}]*white-space:nowrap/.test(css));
  assert.ok(/\.stp \.sdot\{width:8px;height:8px/.test(css));
});
t('ikon notifikasi: siluet putih di 5 kepadatan + native memakainya dengan jalur mundur', () => {
  for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) assert.ok(existsSync(new URL(`../resources/android/res/drawable-${d}/ic_stat_kelimaa.png`, import.meta.url)), d);
  const r = reminderReceiverSource('com.kelimaa.notes');
  assert.ok(r.includes('getIdentifier("ic_stat_kelimaa","drawable"') && r.includes('icon!=0?icon:android.R.drawable.ic_popup_reminder'));
  assert.ok(/try \{ icon=/.test(r) && r.includes('setColor(0xFF6B8EEB)'));
  assert.equal((r.match(/\{/g) || []).length, (r.match(/\}/g) || []).length, 'kurung kurawal seimbang');
});
t('tanpa perubahan data: SCHEMA 8 sejak Rev 60, workflow tidak disentuh', () => {
  assert.ok(/SCHEMA = 22/.test(src('src/js/storage.js')));
});
console.log(`\n${ok} tes lulus (pilih)`);
