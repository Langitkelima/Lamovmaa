// Rev 308c / v0.3.121: dialog "Data aplikasi untuk AI" jadi dua tab (Data, Riwayat token), sakelar Tetap menempel, dua tautan kecil, tab Riwayat = tempat kosong. Tes statis; tampilan nyata diaudit di Chromium (tools/audit_dialog_dua_tab.py).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ob = src('src/js/ai/obrolan.js'), css = src('src/css/styles.css');
test('dua tab: tablist, role=tab + aria-selected, panel Data dan Riwayat token, Data aktif saat dibuka', () => {
  for (const k of ["role: 'tablist'", "role: 'tab'", "'aria-selected'", "role: 'tabpanel'", "'Data'", "'Riwayat token'", "pilihTab('data')"]) assert.ok(ob.includes(k), k);
  assert.match(css, /\.kd-tab\.on\{/); assert.match(css, /\.kd-pn\[hidden\]\{display:none\}/);
});
test('tab Data: kartu Tugas dan Proyek, Catatan (Lampirkan + sakelar), dua tautan kecil; tanpa baris Judul catatan', () => {
  assert.match(ob, /h\('div', \{ class: 'kd-list' \}, lampir, tempel\)/); assert.match(ob, /h\('div', \{ class: 'kd-lnks' \}, lihat, insight\)/);
  assert.match(ob, /const lihat = h\('button', \{ type: 'button', class: 'kd-lnk'/); assert.match(ob, /const insight = h\('button', \{ type: 'button', class: 'kd-lnk'/);
  assert.ok(ob.includes("'Lihat data yang dikirim'") && ob.includes("'Insight mingguan'") && ob.includes("'Minta saran AI'")); assert.doesNotMatch(ob, /Judul catatan/);
});
test('sakelar Tetap menempel: kunci terpisah, bawaan HIDUP, mati = lampiran dilepas setelah balasan berhasil', () => {
  const kt = src('src/js/ai/konteks.js'); assert.match(kt, /TEMPEL_KEY = 'kelimaa_ai_tempel'/); assert.match(kt, /getItem\(TEMPEL_KEY\) !== '0'/); assert.match(ob, /tempelOn, setTempel \} from '\.\/konteks\.js'/); assert.match(ob, /role: 'switch'/);
  const i = ob.indexOf('if (ab && !tempelOn()) lepasLamp();'), j = ob.indexOf('if (ab) paintLamp();'); assert.ok(i > 0 && j > i, 'lepas sebelum disegarkan'); assert.match(ob, /dilepas setelah balasan ini/);
  assert.ok(ob.indexOf('if (ab && !tempelOn())') > ob.indexOf('if (res.ok) {'), 'hanya di jalur berhasil');
});
test('CSS tab, tautan, dan keadaan kosong memakai variabel tema (terang + gelap), tanpa warna mentah', () => {
  const seg = css.slice(css.indexOf('.kd-tabs{'), css.indexOf('.kd-row:active,.kd-act:active')); assert.ok(seg.length > 400); assert.doesNotMatch(seg, /#[0-9a-f]{3,8}\b/i); assert.match(seg, /var\(--ac\)/);
});
import { tempelOn, setTempel, TEMPEL_KEY } from '../src/js/ai/konteks.js';
test('tempelOn/setTempel: bawaan hidup, simpan 0/1, penyimpanan rusak = hidup', () => {
  const m = new Map(), st = { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)) };
  assert.equal(tempelOn(st), true); setTempel(false, st); assert.equal(m.get(TEMPEL_KEY), '0'); assert.equal(tempelOn(st), false); setTempel(true, st); assert.equal(tempelOn(st), true);
  assert.equal(tempelOn({ getItem() { throw new Error('x'); } }), true); assert.doesNotThrow(() => setTempel(false, { setItem() { throw new Error('x'); } }));
});
