// Rev 311e: tombol Simpan diagram yang nonaktif (batas diagram tercapai) kini punya alasan terlihat.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const ui = readFileSync(new URL('../src/js/lembar-ui.js', import.meta.url), 'utf8');
test('Rev 311e: alasan Simpan diagram nonaktif ditulis di pratinjau', () => {
  assert.ok(/if \(sv\.disabled\) pv\.textContent \+=/.test(ui));
  assert.ok(/batas ' \+ L\.MAX_CHARTS \+ ' diagram per lembar sudah tercapai/.test(ui));
});
test('Rev 311e: alasan hanya dipasang setelah status sv.disabled dihitung', () => {
  assert.ok(ui.indexOf('sv.disabled = L.listCharts(tab).length >= L.MAX_CHARTS') < ui.indexOf('Rev 311e'));
});
