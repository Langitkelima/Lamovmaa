// Tes Rev 27A: bilah bawah Undo | ✦ | Redo, panel format lewat bintang, tombol Garis bawah. Pemeriksaan sumber; BUKAN uji di HP.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0; const t = (name, fn) => { fn(); n++; console.log('ok - ' + name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css'), ui = src('../src/js/ui.js');
t('urutan tombol: Undo, bintang, Redo, lalu item format (Tebal, Miring, Garis bawah, Coret, Poin, Nomor, Centang, Warna)', () => {
  const order = ['undo', 'star', 'redo', 'bold', 'italic', 'underline', 'strikeThrough', 'insertUnorderedList', 'insertOrderedList', 'todo'];
  let at = nt.indexOf("const bar = h('div', { class: 'fbar' }");
  for (const c of order) { const i = nt.indexOf(`'data-cmd': '${c}'`, at); assert.ok(i > at, c); at = i; }
  assert.ok(nt.indexOf("'data-pal': 'txt'", at) > at);
});
t('bintang: ikon SVG sendiri (bukan emoji), aria-expanded, setFmt menutup palet dan roda warna', () => {
  assert.ok(/star: 'M12 2\.5c/.test(ui)); assert.ok(!nt.includes('✨'));
  for (const k of ["'aria-expanded': 'false'", 'const setFmt = (open)', "if (c === 'star') { setFmt(!bar.classList.contains('open')); return; }", "pal.replaceChildren(); if (cp.style.display === 'block') closeCp()"]) assert.ok(nt.includes(k), k);
});
t('CSS: tertutup hanya 3 tombol, terbuka menyembunyikan Undo/Redo dan bintang jadi tombol tutup', () => {
  for (const k of ['.fbar .fmt{display:none}', '.fbar.open .fmt{display:flex}', '.fbar.open button.uh{display:none}', '.fbar button.star{flex:0 0 56px']) assert.ok(css.includes(k), k);
});
t('Garis bawah: execCommand underline lewat handler lama, status "on" ikut, sanitize mengizinkan U', () => {
  assert.ok(nt.includes("'underline', 'strikeThrough', 'insertUnorderedList', 'insertOrderedList']"));
  assert.ok(/const OK = new Set\(\[[^\]]*'U'/.test(nt));
});
t('tanpa perubahan data/native: SCHEMA 8 sejak Rev 60', () => assert.ok(/SCHEMA = 22/.test(src('../src/js/storage.js'))));
console.log(`\n${n} tes lulus (bilah)`);
