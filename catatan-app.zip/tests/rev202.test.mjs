// Rev 197e / v0.3.121: toast solid lagi, kotak persegi bilah pilih hilang, geser hapus KIRI dan KANAN (Catatan, Tugas, Kebiasaan). Berkas rev202 = Rev 197e.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
class Node_ { constructor(t) { this.nodeType = t; this.kids = []; } append(...k) { this.kids.push(...k); } }
class El extends Node_ { constructor(tag) { super(1); this.tag = tag; this.attrs = {}; } setAttribute(k, v) { this.attrs[k] = v; } addEventListener() {} }
class Txt extends Node_ { constructor(t) { super(3); this.text = t; } }
globalThis.document = { createElement: (t) => new El(t), createTextNode: (t) => new Txt(t), querySelector: () => null };
const { arahGeser, arahTampil, GESER_HAPUS_PX, GESER_GERAK_PX } = await import('../src/js/ui.js');
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const css = src('src/css/styles.css');

test('arahGeser: kiri dan kanan sama jauhnya; persis di batas belum; masukan rusak = tidak ada arah', () => {
  assert.equal(GESER_HAPUS_PX, 100);
  assert.equal(arahGeser(-101), 'kiri'); assert.equal(arahGeser(101), 'kanan');
  assert.equal(arahGeser(-100), ''); assert.equal(arahGeser(100), ''); assert.equal(arahGeser(0), '');
  assert.equal(arahGeser(NaN), ''); assert.equal(arahGeser(undefined), ''); assert.equal(arahGeser(Infinity), '');
});
test('arahTampil: lapisan Hapus baru muncul sesudah lewat ambang ketukan (8 px), di sisi yang benar', () => {
  assert.equal(GESER_GERAK_PX, 8);
  assert.equal(arahTampil(-8), ''); assert.equal(arahTampil(8), ''); assert.equal(arahTampil(-9), 'kiri'); assert.equal(arahTampil(9), 'kanan'); assert.equal(arahTampil(NaN), '');
});

test('CSS toast: SOLID (--sfo) dan aturan terakhir yang menang; tidak kembali ke kaca --gbg (Rev 172 menimpa Rev 54)', () => {
  const all = [...css.matchAll(/(^|\n)\.toast\{([^}]*)\}/g)].map((m) => m[2]); const last = all[all.length - 1];
  assert.match(last, /background:var\(--sfo\)/); assert.doesNotMatch(last, /--gbg/); assert.match(css, /\.toast\{[^}]*z-index:8/);
});
test('CSS bilah pilih: latar pembungkus transparan (tidak ada kotak persegi datar), bilahnya solid dan bulat', () => {
  assert.match(css, /\.selhost\.on\{[^}]*background:transparent/); assert.doesNotMatch(css, /\.selhost\.on\{[^}]*background:var\(--bg\)/);
  assert.match(css, /\.selbar\{[^}]*border-radius:18px;background:var\(--sfo\)/);
});
test('CSS geser (Catatan): dua label (.swl kanan, .swr kiri) mengikuti data-dir; lapisan .swbg tidak menangkap sentuhan', () => {
  assert.match(css, /\.sw\[data-dir="kanan"\] \.swbg \.swl/); assert.match(css, /\.sw\[data-dir="kiri"\] \.swbg \.swr/);
  assert.doesNotMatch(css, /\.swt\b/); assert.match(css, /\.swbg\{pointer-events:none\}/);
  assert.match(css, /\.sw\{position:relative;border-radius:20px;overflow:hidden/);
});
test('kode: Catatan memakai arahGeser dua arah (Privat tetap lewat konfirmasi 2 langkah); Tugas DAN Kebiasaan (Rev 204: tanpa geser-hapus)', () => {
  const n = src('src/js/notes.js'), m = src('src/js/main.js');
  assert.match(n, /const arah = arahGeser\(dx\)/); assert.match(n, /arah && kind === 'priv'[^\n]*confirmDeletePriv/); assert.doesNotMatch(n, /Math\.min\(0, e\.clientX - x0\)/);
  assert.match(n, /class: 'sw' \+ \(sel\.ids\.includes\(n\.id\) \? ' sel' : ''\) \}, swbgEl\(\), el\)/); assert.match(n, /if \(sel\.ids\.length\) return; \/\/ saat mode pilih tidak ada geser-hapus/);
  // Rev 204: geser-hapus Tugas/Kebiasaan dicabut; baris dikembalikan polos
  assert.doesNotMatch(m, /pasangGeserHapus|swbgEl|class: 'swt'/);
  assert.match(m, /if \(!opened\) return mainRow;/); assert.match(m, /h\('div', \{ class: 'trow' \}, mainRow, subPanel\(kind, item, pr\)\)/);
  const viewT = m.slice(m.indexOf('function viewTugas')); assert.equal((viewT.match(/row\(x, kind\)/g) || []).length, 2); // kebiasaan memakai row() yang sama
});
test('tanpa modul baru (jumlah modul buka tetap), tanpa native/SCHEMA/dependensi berubah; versi 0.3.121 dan tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(pk.scripts.test, /node tests\/rev202\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
