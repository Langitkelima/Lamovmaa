// Rev 379 / PART AL3b-1: layar alarm native rancangan 3G (ikut tema aplikasi, cincin sisa waktu, judul HURUF KAPITAL) + jembatan setAlarmTheme + sinkron tema. Tes Node (teks sumber Java + jembatan palsu).
import test from 'node:test'; import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import * as N from '../scripts/apply-native.mjs';
import { syncAlarmTheme } from '../src/js/logic.js';
const PKG = 'com.kelimaa.notes';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('AlarmActivity 3G: judul HURUF KAPITAL, cincin sisa waktu, tombol Matikan + Tunda, tetap di atas layar kunci', () => {
  const v = N.alarmActivitySource(PKG);
  assert.ok(v.includes('toUpperCase(new Locale("id","ID"))'), 'judul kapital');
  assert.ok(v.includes('class RingView extends View') && v.includes('drawArc') && v.includes('RING_MS'), 'cincin');
  assert.ok(v.includes('"Matikan"') && v.includes('"Tunda "+AlarmRinger.snoozeMin(this)+" menit"'));
  assert.ok(v.includes('AlarmRinger.snooze(self,id,title,message)') && v.includes('AlarmRinger.stop(self,id)'));
  assert.ok(v.includes('setShowWhenLocked(true)') && v.includes('setTurnScreenOn(true)') && v.includes('FLAG_KEEP_SCREEN_ON'));
  assert.ok(v.includes('"Alarm berdering"') && v.includes('" lagi"') && v.includes('"bunyi berhenti"'));
  assert.ok(!v.includes('`') && !v.includes('${'), 'tanpa sisa interpolasi');
});
test('AlarmActivity 3G: warna terang dan gelap sama dengan palet aplikasi; tema dibaca dari SharedPreferences, otomatis = mode malam sistem', () => {
  const v = N.alarmActivitySource(PKG);
  for (const c of ['0xFF0B1120', '0xFFEDF2F9', '0xFFE4EAF6', '0xFF1E2A3D', '0xFF7C9CF0', '0xFF6B8EEB']) assert.ok(v.includes(c), c);
  assert.ok(v.includes('"kelimaa_alarm_ui"') && v.includes('UI_MODE_NIGHT_MASK') && v.includes('"dark".equals(t)') && v.includes('"light".equals(t)'));
});
test('AlarmActivity 3G: Kurangi Gerakan mematikan titik berkedip; cincin berhenti di 0 dan layar tidak menutup sendiri', () => {
  const v = N.alarmActivitySource(PKG);
  assert.ok(v.includes('ANIMATOR_DURATION_SCALE') && v.includes('if(!reduce)'));
  assert.ok(v.includes('if(rem<=0L)') && v.includes('handler.removeCallbacks(tick)'));
  assert.ok(!/rem<=0L\)\s*\{[^}]*finish\(\)/.test(v), 'tidak finish() saat bunyi berhenti');
});
test('AlarmRinger: waktu mulai bunyi (t0) dibawa ke layar alarm; jembatan setAlarmTheme ada dan hanya menerima light/dark/auto', () => {
  assert.ok(N.alarmRingerSource(PKG).includes('i.putExtra("t0",System.currentTimeMillis())'));
  const m = N.mainActivitySource(PKG);
  assert.ok(m.includes('public void setAlarmTheme(String theme)') && m.includes('"kelimaa_alarm_ui"') && m.includes('"dark".equals(theme) || "light".equals(theme) ? theme : "auto"'));
  assert.ok(m.includes('public void scheduleAlarm(') === false || m.includes('public String scheduleAlarm('), 'scheduleAlarm utuh');
  assert.ok(m.includes('public String scheduleAlarm(String id, String title, String message, long delayMs, long repeatMs)'));
});
test('syncAlarmTheme: meneruskan hanya light/dark/auto; APK lama atau jembatan rusak tidak melempar', () => {
  const got = []; const a = { setAlarmTheme: (t) => got.push(t) };
  assert.equal(syncAlarmTheme(a, 'light'), true); syncAlarmTheme(a, 'dark'); syncAlarmTheme(a, 'auto'); syncAlarmTheme(a, 'x'); syncAlarmTheme(a, undefined);
  assert.deepEqual(got, ['light', 'dark', 'auto', 'auto', 'auto']);
  assert.equal(syncAlarmTheme({}, 'dark'), false); assert.equal(syncAlarmTheme(null, 'dark'), false);
  assert.equal(syncAlarmTheme({ setAlarmTheme() { throw new Error('x'); } }, 'dark'), false);
});
test('settings.js: applyTheme memanggil syncAlarmTheme; logic.js tidak membaca globalThis untuk ini', () => {
  const s = src('src/js/settings.js'); assert.ok(/syncAlarmTheme\(globalThis\.AndroidAPI \|\| null, theme\)/.test(s) && /syncAlarmTheme, BACKUP_MAX/.test(s));
  const l = src('src/js/logic.js'); const i = l.indexOf('export function syncAlarmTheme'); assert.ok(i > 0 && !l.slice(i, i + 500).includes('globalThis'));
});
test('pemeriksa Java: semua sumber native (termasuk AlarmActivity 3G) dikompilasi terhadap stub (dilewati bila JDK tidak ada)', (t) => {
  const j = spawnSync('java', ['-version'], { encoding: 'utf8' }); if (j.error || j.status !== 0) { t.skip('JDK tidak ada'); return; }
  const r = spawnSync('node', ['tools/cek_java_native.mjs'], { encoding: 'utf8', cwd: new URL('..', import.meta.url).pathname });
  assert.equal(r.status, 0, r.stdout + r.stderr);
});
