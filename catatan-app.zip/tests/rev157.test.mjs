// Rev 157 / U10c-2a: dialog Diagram di lembar Lainnya (pratinjau SVG + Unduh SVG). Tanpa SCHEMA/native; tidak mengubah lembar kerja.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as D from '../src/js/lembar-diagram.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
function mk(grid) { const t = L.newTab('T', Math.max(8, grid.length + 2)); grid.forEach((r, i) => r.forEach((v, j) => { if (v !== undefined) L.setCell(t, t.rows[i].id, t.cols[j].id, { v }); })); return t; }
const ui = src('src/js/lembar-ui.js');
const chartBody = () => { const a = ui.indexOf('const CHART_MSG = '), b = ui.indexOf('const tabMenu = (t) => namePrompt('); assert.ok(a > 0 && b > a && ui.indexOf('const openChart = () => {') > a, 'CHART_MSG + openChart harus ada sebelum tabMenu'); return ui.slice(a, b); };

test('lembar-ui mengimpor mesin diagram; item Diagram ada di menu Lainnya antara Filter baris dan Unduh CSV', () => {
  assert.match(ui, /import \{ chartData, chartSvg, CHART_KINDS, KIND_LABELS, MAX_POINTS \} from '\.\/lembar-diagram\.js'/);
  // Rev 264: Diagram hanya di Menu sel (tekan lama: 'Diagram dari sel ini'), tidak diulang di Lainnya
  assert.ok(!ui.includes("item('diagram'") && ui.includes("'Diagram dari sel ini', openChart"));
});
test('openChart diletakkan SESUDAH openMerge (tes lama memotong kode antar penanda) dan tidak mengubah lembar kerja', () => {
  assert.ok(ui.indexOf('const openChart = () => {') > ui.indexOf('const openMerge = () => {'));
  const b = chartBody(); assert.doesNotMatch(b, /changed\(|L\.setCell|L\.mergeCells|restore\(/); // Rev 159: hist.push/ver++/touched kini sah (Simpan/Hapus diagram)
  assert.doesNotMatch(b, /localStorage|innerHTML|eval\(|new Function|insertAdjacentHTML/); assert.match(b, /DOMParser/); assert.match(b, /saveFiles/); assert.match(b, /image\/svg\+xml/);
  assert.match(b, /commit\(\); if \(!sel\)/); assert.match(b, /maxC < 2/);
});
test('openChart: kolom nilai = kolom ke-n dari sel terpilih (valueCol = c2), judul dan legenda diteruskan, latar putih berdiri sendiri', () => {
  const b = chartBody(); assert.match(b, /chartData\(tab, src, \{ valueCol: src\.c2 \}\)/); assert.match(b, /legend: lg\.checked/); assert.match(b, /title: ttl\.value/); assert.match(b, /CHART_THEME = \{ bg: '#FFFFFF' \}/);
  const t = mk([['Bulan', 'Biaya', 'Untung'], ['Jan', 10, 1], ['Feb', 20, 2], ['Mar', 30, 3]]);
  const d2 = D.chartData(t, { r1: 0, c1: 0, r2: 3, c2: 1 }, { valueCol: 1 }), d3 = D.chartData(t, { r1: 0, c1: 0, r2: 3, c2: 2 }, { valueCol: 2 });
  assert.deepEqual(d2.values, [10, 20, 30]); assert.deepEqual(d3.values, [1, 2, 3]); assert.equal(d3.title, 'Untung');
  const r = D.chartSvg(d3, { kind: 'donut', title: 'Laba', legend: false, width: 640, theme: { bg: '#FFFFFF' } }); assert.equal(r.ok, true); assert.match(r.svg, /<rect width="640" height="\d+" fill="#FFFFFF"\/>/); assert.match(r.svg, /Laba/);
});
test('tiga jenis dirangkai dari tombol (aria-pressed) dan Unduh SVG baru aktif bila ada angka', () => {
  const b = chartBody(); assert.match(b, /CHART_KINDS\.map\(kbtn\)/); assert.match(b, /KIND_LABELS\[id\]/); assert.match(b, /'aria-pressed': id === kind/); assert.match(b, /lgRow\.hidden = kind !== 'donut'/);
  assert.match(b, /dl\.disabled = true/); assert.match(b, /dl\.disabled = false/); assert.match(b, /build\(640\)/); assert.match(b, /build\(360\)/);
  for (const k of ['rentang', 'kolom', 'kosong', 'tak-positif']) assert.match(b, new RegExp("'?" + k + "'?:"));
  const kosong = D.chartData(mk([['a', 'b'], ['c', 'd']]), { r1: 0, c1: 0, r2: 1, c2: 1 }, { valueCol: 1 }); assert.equal(kosong.ok, false); assert.equal(kosong.reason, 'kosong');
});
test('CSS dialog ada; data tidak berubah (SCHEMA 16, tanpa kunci charts); modul lain tidak mengimpor mesin diagram; versi 0.3.121', () => {
  const css = src('src/css/styles.css'); assert.match(css, /Rev 157 \/ U10c-2a/); assert.match(css, /\.lz-chart \.lz-chartpv/); assert.match(css, /\.lz-chart \[hidden\]/);
  assert.match(css, /\.lz-chart \.lz-chartpv svg\{width:100%;max-width:360px;height:auto;[^}]*stroke:none;stroke-width:1/); // membatalkan aturan global svg{} ikon (24px + stroke)
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.doesNotMatch(src('src/js/lembar.js'), /lembar-diagram/); // Rev 158: kunci `charts` kini sah di lembar.js (lembar-grafik.js), tetapi lembar.js tetap tidak mengimpor mesin diagram
  for (const f of ['lembar', 'export', 'notes', 'main', 'storage']) assert.doesNotMatch(src('src/js/' + f + '.js'), /lembar-diagram/, f);
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev157.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
