// Rev 117 / U7a-2b-2: tab baru, ubah nama tab/lembar, hapus tab
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
test('renameSheet: bersih, batas 30 huruf, kosong = nama lama', () => {
  const sh = L.newSheet({ name: 'A' }); assert.ok(L.renameSheet(sh, '  Anggaran   2026  ')); assert.equal(sh.name, 'Anggaran 2026');
  assert.equal(L.renameSheet(sh, '   '), false); assert.equal(sh.name, 'Anggaran 2026');
  L.renameSheet(sh, 'x'.repeat(80)); assert.equal(sh.name.length, L.MAX_NAME);
});
test('tab: tambah sampai 5, ubah nama, hapus (minimal 1), ID unik', () => {
  const sh = L.newSheet({ name: 'A' }); const ids = [sh.tabs[0].id];
  for (let i = 0; i < 4; i++) ids.push(L.addTab(sh)); assert.equal(sh.tabs.length, 5); assert.equal(new Set(ids).size, 5); assert.equal(L.addTab(sh), null);
  assert.ok(L.renameTab(sh, ids[1], 'Gaji')); assert.equal(sh.tabs[1].name, 'Gaji');
  assert.ok(L.removeTab(sh, ids[1])); assert.equal(sh.tabs.length, 4);
  while (sh.tabs.length > 1) L.removeTab(sh, sh.tabs[0].id); assert.equal(L.removeTab(sh, sh.tabs[0].id), false);
});
test('kontrak kode: tab lewat lembar.js, fitsLimit, konfirmasi hapus tab, tanpa penyimpanan', () => {
  const ui = src('js/lembar-ui.js');
  for (const k of ['L.addTab(sheet)', 'L.removeTab(sheet, t.id)', 'L.renameTab(sheet, t.id, name)', 'L.renameSheet(sheet, name)', 'namePrompt(', "title: 'Hapus tab"]) assert.ok(ui.includes(k), k);
  assert.ok(ui.includes('L.fitsLimit(sheet)')); assert.ok(!/localStorage|persist\(|eval\(|new Function|Capacitor/.test(ui));
  assert.match(src('css/styles.css'), /Rev 117 \/ U7a-2b-2/);
});
test('versi 0.3.121', () => {
  assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /"version": "0\.3\.121"/); assert.match(src('js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
