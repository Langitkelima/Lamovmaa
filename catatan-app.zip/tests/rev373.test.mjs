// Rev 373: warna seleksi teks kustom (roda warna, tekan lama logo di Setelan). Tes Node: normalisasi, kabel sumber, batas CSS. BUKAN bukti dari HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import { normalize, emptyData } from '../src/js/storage.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('settings.selColor: bawaan kosong; hanya #rrggbb sah (huruf kecil); sisanya dibuang', () => {
  assert.equal(emptyData().settings.selColor, '');
  const mk = (v) => { const d = emptyData(); d.settings.selColor = v; return normalize(d).settings.selColor; };
  assert.equal(mk('#AABBCC'), '#aabbcc'); assert.equal(mk('#217d9c'), '#217d9c');
  for (const v of ['', 'x', '#abc', '#12345', '#gggggg', 'red', 5, null, undefined, '#aabbccdd']) assert.equal(mk(v), '');
});
test('CSS: seleksi memakai --sel hanya bila data-sel diset; aturan lama tetap utuh; bawaan gelap #217d9c', () => {
  const c = rd('src/css/styles.css');
  assert.ok(c.includes(':root[data-sel] ::selection{background:var(--sel);color:var(--selfg)}'));
  assert.ok(c.includes('.ed2::selection, .ed2 ::selection, .ttl::selection { background: var(--ac2); color: var(--ink); }'));
  assert.ok(c.includes(':root[data-theme="dark"]{--ac2:#217d9c}') && !c.includes('#7ee6ff'));
});
test('kabel: tekan lama logo -> roda warna dimuat MALAS; main.js hanya memanggil applySelColor dari settings.js; cadangan/pulihkan menerapkan ulang', () => {
  const s = rd('src/js/settings.js'), m = rd('src/js/main.js');
  assert.match(s, /onLongPress\(im, \(\) => import\('\.\/warna-seleksi\.js'\)/); assert.doesNotMatch(s, /^import .*warna-seleksi/m);
  assert.match(m, /applyTheme\(data\.settings\.theme\); applySelColor\(data\.settings\.selColor\);/); assert.doesNotMatch(m, /warna-seleksi/);
  assert.match(s, /applyTheme\(ctx\.data\.settings\.theme\); applySelColor\(ctx\.data\.settings\.selColor\);/);
});
test('roda warna: pratinjau langsung, Batal mengembalikan, Bawaan menghapus; CSS-nya disuntik dari modul (CSS utama penuh), tanpa penyimpanan sendiri', () => {
  const w = rd('src/js/warna-seleksi.js');
  assert.match(w, /const cancel = \(\) => \{ applySelColor\(prev\); close\(\); \};/);
  assert.match(w, /applySelColor\(''\); close\(\); onSave\(''\)/); assert.match(w, /injectCss\(\);/);
  assert.doesNotMatch(w, /localStorage|sessionStorage|innerHTML/);
  assert.ok(Buffer.byteLength(rd('src/css/styles.css')) < 270 * 1024); /* Rev 383: disamakan dengan cssMaks resmi 270 KB (tools/audit-ukuran.mjs) */
});
