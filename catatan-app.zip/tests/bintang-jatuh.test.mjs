// Tes Rev 39: bintang jatuh ringan (hanya tema gelap, transform+opacity, jarang, mati bila reduced-motion).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { shootParams, SHOOT_MIN_MS, SHOOT_SPAN_MS } from '../src/js/langit.js';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const css = src('../src/css/styles.css'), main = src('../src/js/main.js'), lg = src('../src/js/langit.js');

t('Rev 39: parameter acak selalu di dalam layar bagian atas, sudut dan panjang wajar, jeda 14-40 detik', () => {
  let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  for (let i = 0; i < 500; i++) {
    const p = shootParams(360, 800, rnd);
    assert.ok(p.left >= 0 && p.left <= 360 && p.top >= 0 && p.top <= 0.38 * 800 + 1, JSON.stringify(p));
    assert.ok((p.ang >= 18 && p.ang <= 36) || (p.ang >= 144 && p.ang <= 162), 'sudut ' + p.ang);
    assert.ok(p.len >= 150 && p.len <= 260, 'panjang ' + p.len);
    assert.ok(p.wait >= SHOOT_MIN_MS && p.wait <= SHOOT_MIN_MS + SHOOT_SPAN_MS);
  }
});
t('Rev 39: CSS hanya menganimasikan transform dan opacity, ada di atas konten tetapi tidak menangkap sentuhan', () => {
  const k = /@keyframes shoot\{([^@]*?)\}\s*@media/.exec(css)[1];
  assert.ok(!/(top|left|width|height|box-shadow|filter)\s*:/.test(k), 'keyframes hanya transform/opacity');
  assert.ok(css.includes('.shoot{display:var(--shootd,none);position:fixed') && css.includes('z-index:2;pointer-events:none;opacity:0'));
  assert.ok(css.includes('.shoot.go{will-change:transform,opacity;animation:shoot'), 'will-change hanya selama animasi');
});
t('Rev 39: hanya tema gelap (token --shootd) dan mati bila reduced-motion', () => {
  assert.equal((css.match(/--shootd:block;/g) || []).length, 2);
  assert.ok(css.includes('--shootd:none;'));
  assert.ok(css.includes('@media (prefers-reduced-motion:reduce){.shoot{display:none}}'));
  assert.ok(lg.includes('prefers-reduced-motion: reduce') && lg.includes('doc.hidden'));
});
t('Rev 39: terpasang di main.js dan gagal-aman (try/catch), satu elemen, jadwal pakai satu timer', () => {
  assert.ok(main.includes("import { installShootingStars, installSkyLock } from './langit.js'") && main.includes('installShootingStars();'));
  assert.ok((lg.match(/setTimeout/g) || []).length === 1 && !lg.includes('setInterval') && !lg.includes('requestAnimationFrame'));
  assert.ok(lg.includes("doc.getElementById('shoot')"));
});
console.log(n + ' tes lulus (Rev 39 bintang jatuh)');
