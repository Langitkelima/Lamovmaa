// Rev 279 / W4 (paket Peringatan + Pelacakan Error): dialog Riwayat error. Tes AI saja (BUKAN HP; tampilan belum dilihat di Chromium/HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
test('kabel: ikon peringatan membuka dialog; tombol di dialog Validasi; lompat tombol lama tetap', () => {
  const ui = src('src/js/lembar-ui.js');
  assert.match(ui, /const openHist = \(\) => \{/); assert.match(ui, /errB\.onclick = openHist;/);
  assert.match(ui, /'data-f': 'hist', onclick: \(\) => \{ ov\.remove\(\); openHist\(\); \}/); assert.match(ui, /'data-f': 'goBad', onclick: goBad/);
  assert.match(ui, /const goBad = \(\) => \{ const m = nextInvalid\(getIV\(\), getOrder\(\), sel\);/);
});
test('dialog: ringkasan aktif/selesai, terbaru dulu, Lompat nonaktif bila baris/kolom hilang, selesai = pesan "sudah beres"', () => {
  const ui = src('src/js/lembar-ui.js'), d = ui.slice(ui.indexOf('const openHist'), ui.indexOf('errB.onclick = openHist'));
  for (const k of ["'Riwayat error'", ".slice().reverse()", "' aktif, '", "' selesai (maks. '", "disabled: !ok", "'(sel dihapus)'", "'Aktif' : 'Selesai'", "' sudah beres.'", "'Belum ada catatan."]) assert.ok(d.includes(k), k);
  assert.match(d, /goTo\(\{ r: i, c: j \}\)/);
});
test('Bersihkan riwayat: ketuk dua kali (3 dtk), satu langkah Urungkan, tab tanpa riwayat = properti dihapus', () => {
  const ui = src('src/js/lembar-ui.js'), d = ui.slice(ui.indexOf('clr.onclick'), ui.indexOf('paint(); ov.append'));
  assert.ok(d.includes("'Ketuk lagi untuk menghapus'") && d.includes('3000')); assert.match(d, /const snap = ser\(\); delete tab\.errlog; ver\+\+, hist\.push\(snap\); paintUndo\(\); touched\(\);/);
});
test('CSS: hanya variabel tema (tanpa warna tetap), dan tetap seimbang', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 279 / W4'); assert.ok(i > 0); const blk = css.slice(i);
  for (const k of ['.eh-row{', '.eh-tag.on{', '.eh-tag.ok{', '.eh-list{']) assert.ok(blk.includes(k), k);
  assert.doesNotMatch(blk, /#[0-9a-fA-F]{3,8}\b/); assert.doesNotMatch(blk, /rgba?\(/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('versi 0.3.121, SCHEMA 22 tetap, tes terdaftar; modul statis tidak bertambah', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/); assert.match(pk.scripts.test, /node tests\/rev279\.test\.mjs/);
});
