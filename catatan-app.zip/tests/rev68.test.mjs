// Rev 68: pengingat per sub-tugas (task.remMode = 'subs', sub.reminder) + panel sub-tugas baru.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as L from '../src/js/logic.js';
import * as S from '../src/js/storage.js';
import * as R from '../src/js/reminders.js';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const main = src('src/js/main.js'), css = src('src/css/styles.css');

function fakeApi() {
  const calls = [], cancels = [];
  globalThis.AndroidAPI = { scheduleNotification: (id, t, m, delay, rep) => { calls.push({ id, t, m, delay, rep }); return 'exact'; }, cancelScheduledNotification: (id) => { cancels.push(id); } };
  return { calls, cancels };
}
const NOW = new Date(2026, 10, 7, 12, 0, 0).getTime();
const H = 3600 * 1000;

test('Rev 68: cleanSubs menyimpan pengingat sub-tugas yang valid dan membuang yang rusak', () => {
  const c = L.cleanSubs([{ id: 'a', title: 'x', reminder: { at: 5, repeat: 'daily' } }, { id: 'b', title: 'y', reminder: { at: 'bukan' } }, { id: 'c', title: 'z', reminder: { at: 9, repeat: 'aneh' } }]);
  assert.deepEqual(c[0].reminder, { at: 5, repeat: 'daily' });
  assert.equal(c[1].reminder, undefined);
  assert.deepEqual(c[2].reminder, { at: 9, repeat: 'once' });
});
test('Rev 68: normalize: remMode subs sah hanya bila ada sub-tugas; alarm tugas dibuang di mode subs; pengingat sub dibuang di mode biasa', () => {
  const d = S.normalize({ tasks: [
    { id: 'a', title: 'A', scope: 'hari', remMode: 'subs', reminder: { at: 10, repeat: 'once' }, subs: [{ id: 's', title: 'x', reminder: { at: 7 } }] },
    { id: 'b', title: 'B', scope: 'hari', remMode: 'subs' },
    { id: 'c', title: 'C', scope: 'hari', reminder: { at: 10 }, subs: [{ id: 's', title: 'x', reminder: { at: 7 } }] },
    { id: 'd', title: 'D', scope: 'habit', remMode: 'subs' },
  ] });
  assert.equal(d.tasks[0].remMode, 'subs'); assert.equal(d.tasks[0].reminder, undefined); assert.equal(d.tasks[0].subs[0].reminder.at, 7);
  assert.equal(d.tasks[1].remMode, undefined);
  assert.equal(d.tasks[2].reminder.at, 10); assert.equal(d.tasks[2].subs[0].reminder, undefined);
  assert.equal(d.tasks[3].remMode, undefined);
  assert.equal(S.SCHEMA, 22); // hanya bidang opsional baru, data lama tetap valid
});
test('Rev 68: roundtrip cadangan menjaga remMode dan pengingat sub-tugas', () => {
  const d = S.emptyData();
  d.tasks.push({ id: 't1', title: 'I', scope: 'hari', done: false, remMode: 'subs', subs: [{ id: 's1', title: 'a', done: false, reminder: { at: 123456, repeat: 'daily' } }] });
  const back = S.importJSON(S.exportJSON(d));
  assert.equal(back.ok, true);
  const t = back.data.tasks[0];
  assert.equal(t.remMode, 'subs'); assert.deepEqual(t.subs[0].reminder, { at: 123456, repeat: 'daily' });
});
test('Rev 68: subReminderCount dan isSubsMode', () => {
  const t = { remMode: 'subs', subs: [{ reminder: { at: 1 } }, { reminder: { at: 2 }, done: true }, {}] };
  assert.equal(L.subReminderCount(t), 1); assert.equal(L.isSubsMode(t), true);
  assert.equal(L.subReminderCount({ subs: t.subs }), 0); assert.equal(L.isSubsMode({ remMode: 'subs', subs: [] }), false);
});
test('Rev 68: mode subs menjadwalkan alarm per sub-tugas (ID sub:<tugas>:<sub>), membatalkan alarm tugas, melewati sub selesai', () => {
  const { calls, cancels } = fakeApi();
  const t = { id: 'T1', title: 'Induk', done: false, remMode: 'subs', subs: [
    { id: 'A', title: 'Satu', done: false, reminder: { at: NOW + 2 * H, repeat: 'once' } },
    { id: 'B', title: 'Dua', done: true, reminder: { at: NOW + 3 * H, repeat: 'once' } },
    { id: 'C', title: 'Tiga', done: false, reminder: { at: NOW + 4 * H, repeat: 'daily' } },
    { id: 'D', title: 'Empat', done: false }] };
  R.syncTaskAlarms(t, NOW);
  assert.deepEqual(calls.map((c) => c.id), ['sub:T1:A', 'sub:T1:C']);
  assert.equal(calls[0].t, 'Satu'); assert.match(calls[0].m, /Induk/); assert.equal(calls[0].delay, 2 * H); assert.equal(calls[0].rep, 0); assert.equal(calls[1].rep, R.DAY_MS);
  assert.ok(cancels.includes('task:T1')); assert.ok(cancels.includes('sub:T1:B')); assert.ok(cancels.includes('sub:T1:D'));
});
test('Rev 68: mode biasa menjadwalkan alarm tugas dan membatalkan semua alarm sub-tugas; tugas selesai membatalkan semuanya', () => {
  let { calls, cancels } = fakeApi();
  const t = { id: 'T2', title: 'Induk', done: false, reminder: { at: NOW + H, repeat: 'once' }, subs: [{ id: 'A', title: 'x', reminder: { at: NOW + H } }] };
  R.syncTaskAlarms(t, NOW);
  assert.deepEqual(calls.map((c) => c.id), ['task:T2']); assert.ok(cancels.includes('sub:T2:A'));
  ({ calls, cancels } = fakeApi());
  t.done = true; R.syncTaskAlarms(t, NOW);
  assert.equal(calls.length, 0); assert.ok(cancels.includes('task:T2') && cancels.includes('sub:T2:A'));
});
test('Rev 68: pengingat sub-tugas "sekali" yang sudah lewat dibuang saat sinkron', () => {
  fakeApi();
  const d = { tasks: [{ id: 'T3', title: 'I', done: false, remMode: 'subs', subs: [{ id: 'A', title: 'x', reminder: { at: NOW - H, repeat: 'once' } }] }], notes: [] };
  const rs = R.syncAllReminders(d, NOW);
  assert.equal(d.tasks[0].subs[0].reminder, undefined); assert.ok(rs.some((x) => x.expired));
});
test('Rev 68: ketukan notifikasi sub:<tugas>:<sub> membuka tugas (bukan tugas selesai) dengan id sub', () => {
  let got = null;
  globalThis.AndroidAPI = { takeReminder: () => 'sub:T4:S9' };
  const ctx = { data: { tasks: [{ id: 'T4', title: 'I', done: false }, { id: 'T5', title: 'J', done: true }], notes: [] } };
  const pull = R.installReminderInbox(ctx, (item, subId) => { got = [item.id, subId]; }, () => {}, () => {});
  assert.deepEqual(got, ['T4', 'S9']);
  globalThis.AndroidAPI = { takeReminder: () => 'sub:T5:S1' };
  got = null; assert.equal(pull(), false); assert.equal(got, null);
});
test('Rev 68: describeReminder: hari ini, besok, tanggal, tiap hari, terlewat', () => {
  const at = (day, h, m = 0) => new Date(2026, 10, day, h, m).getTime();
  assert.equal(R.describeReminder({ at: at(7, 16, 5) }, NOW), 'Hari ini 16:05');
  assert.equal(R.describeReminder({ at: at(8, 8) }, NOW), 'Besok 08:00');
  assert.equal(R.describeReminder({ at: at(20, 9) }, NOW), '20 Nov 09:00');
  assert.equal(R.describeReminder({ at: at(7, 9), repeat: 'daily' }, NOW), 'Tiap hari 09:00');
  assert.equal(R.describeReminder({ at: at(7, 9) }, NOW), 'Terlewat');
  assert.equal(R.describeReminder(null, NOW), '');
});
test('Rev 68: kabel UI (pilihan mode, tombol pengingat per sub, panel pohon, ID notifikasi) dan CSS', () => {
  for (const k of ['Langsung di tugas', 'Di tiap sub-tugas', 'Atur pengingat', "remMode = 'subs'", 'subPanel', 'syncTaskAlarms', 'cancelTaskAlarms', 'describeReminder', 'subprog']) assert.ok(main.includes(k), k);
  for (const k of ['.subprog', '.slist', '.sbellbtn', '.sremp', '.sbell']) assert.ok(css.includes(k), k);
  const blok = css.slice(css.indexOf('Rev 68'), css.indexOf('Rev 71: menu bawah'));
  assert.ok(!/backdrop-filter|blur\(|infinite|@keyframes/.test(blok), 'tanpa blur dan animasi berulang');
  assert.ok(main.includes('panel.animate') && main.includes('prefers-reduced-motion'), 'animasi muncul sekali lewat JS, hormati gerak dikurangi');
  assert.ok(/textContent|h\('span', \{ class: 'stt' \}, sb\.title\)/.test(main)); // judul sub lewat node teks, bukan innerHTML
  assert.ok(!/innerHTML/.test(main.slice(main.indexOf('function subPanel'), main.indexOf('function openSheet'))));
});
