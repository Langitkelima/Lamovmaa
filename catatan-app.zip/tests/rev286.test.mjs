// Rev 286 / T1: mesin templat v2 (banyak tab, aturan warna bersyarat, dropdown, diagram, tab Panduan) + data lama dipindah ke templat-lama.js.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { chartList } from '../src/js/lembar-grafik.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN);
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 14, 12, 0, 0).getTime();
const DEF = {
  id: 'uji', name: 'Uji mesin', desc: 'x',
  tabs: [
    { tab: 'Data', w: [120, 90, 90], head: true, nfc: ['', 'num', ''], rows: [['Nama', 'Nilai', 'Status'], ['Ani', 80, 'Hadir'], ['Budi', 55, 'Izin'], ['Cici', '=B2+B3', '']],
      rules: [{ c: 'B', op: 'lt', a: 60, bg: '#FEE2E2', fg: '#991B1B' }, { c: 'B', op: 'scale', lo: '#FFFFFF', hi: '#86EFAC' }],
      checks: [{ k: 'list', rg: 'C2:C10', items: ['Hadir', 'Izin', 'Sakit'], cl: { Hadir: { bg: '#DCFCE7', fg: '#111827' } } }],
      charts: [{ kind: 'donut', title: 'Nilai', r1: 0, c1: 0, r2: 2, c2: 1, vc: 1 }] },
    { tab: 'Kedua', rows: [['a', 'b']] },
  ],
  guide: [['Warna bersyarat', 'Kolom Nilai di tab Data berwarna merah bila kurang dari 60, dan hijau makin tua bila makin besar. Ubah lewat menu Lainnya.']],
};
test('Rev 286: banyak tab + aturan + dropdown + diagram + Panduan terbentuk, failed 0, lolos cleanSheet', () => {
  const r = T.buildFromDef(DEF, { now: NOW }); assert.ok(r); assert.equal(r.failed, 0);
  const sh = r.sheet; assert.deepEqual(sh.tabs.map((t) => t.name), ['Data', 'Kedua', 'Panduan']);
  const tab = sh.tabs[0]; assert.equal(tab.rules.length, 2); assert.equal(tab.rules[0].c, tab.cols[1].id);
  assert.equal(tab.checks.length, 1); const ck = tab.checks[0]; assert.equal(ck.c, tab.cols[2].id); assert.equal(ck.rg.c2, tab.cols[2].id); assert.equal(ck.rg.r1, tab.rows[1].id); assert.equal(ck.rg.r2, tab.rows[9].id);
  assert.deepEqual(ck.items, ['Hadir', 'Izin', 'Sakit']); assert.equal(ck.cl.Hadir.bg, '#DCFCE7');
  assert.equal(chartList(tab).length, 1); assert.equal(tab.cols[0].w, 120);
  const g = sh.tabs[2]; assert.equal(g.cols[0].w, 320); assert.equal(g.rows[0].cells[g.cols[0].id].v, 'Warna bersyarat'); assert.equal(g.rows[0].cells[g.cols[0].id].s.b, true);
  const lines = g.rows.map((x) => (x.cells[g.cols[0].id] || {}).v).filter(Boolean); assert.ok(lines.length >= 3); for (const t of lines.slice(1)) assert.ok(t.length <= 60, t);
  const c = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.equal(c.tabs[0].rules.length, 2); assert.equal(c.tabs[0].checks.length, 1); assert.equal(chartList(c.tabs[0]).length, 1); assert.equal(c.tabs.length, 3);
});
test('Rev 286: aturan/validasi yang ditolak, tab ke-6, dan rumus salah dihitung di failed', () => {
  const mkd = (x) => ({ id: 'u', name: 'U', desc: '', rows: [['a']], ...x });
  assert.equal(T.buildFromDef(mkd({ rules: [{ c: '?', op: 'gt', a: 1, bg: '#FFFFFF' }] })).failed, 1);
  assert.equal(T.buildFromDef(mkd({ checks: [{ k: 'list', rg: 'A1:A5', items: [] }] })).failed, 1);
  assert.equal(T.buildFromDef(mkd({ rows: [['=NOPE(1)']] })).failed, 1);
  const six = { id: 'u', name: 'U', desc: '', tabs: Array.from({ length: 5 }, (_, i) => ({ tab: 'T' + i, rows: [['a']] })), guide: [['x', 'y']] };
  assert.equal(T.buildFromDef(six).failed, 1); // Panduan tidak muat (maks. 5 tab)
});
test('Rev 286: 10 templat lama tetap utuh (urutan, failed 0) dan data berada di templat-lama.js', () => {
  const l = T.templateList().slice(-10); // Rev 293: 10 templat lama paling belakang assert.deepEqual(l.slice(0, 4).map((t) => t.id), ['anggaran', 'bagi', 'jadwal', 'nilai']);
  for (const t of l) { const r = T.makeFromTemplate(t.id, { now: NOW }); assert.ok(r, t.id); assert.equal(r.failed, 0, t.id); assert.equal(r.sheet.tabs.length, 1); }
  assert.equal(T.makeFromTemplate('tidak-ada'), null); assert.ok(T.hasTemplate('inventaris'));
});
test('Rev 286: modul murni; hanya lembar.js, lembar-tampil.js, templat-lama.js; fungsi rumus hanya yang ada; settings.js tidak berubah arah', () => {
  for (const f of ['lembar-templat', 'templat-lama']) { const s = src('src/js/' + f + '.js'); assert.doesNotMatch(s, /localStorage|document\.|window\.|AndroidAPI|Intl\.|eval\(|new Function/, f); assert.doesNotMatch(s, /from '\.\/(rumus|lembar-ui|lembar-pulau|storage|settings)\.js'/, f); }
  assert.doesNotMatch(src('src/js/templat-lama.js'), /import /);
  const used = new Set([...src('src/js/templat-lama.js').matchAll(/'(=[^']*)'/g)].flatMap((m) => [...m[1].matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1])));
  for (const f of used) assert.ok(['SUM', 'SUMIF', 'AVERAGE', 'COUNT', 'COUNTA', 'COUNTIF', 'IF', 'OR', 'MIN', 'TODAY'].includes(f), f);
  for (const f of ['notes', 'main', 'lembar', 'lembar-ui', 'lembar-pulau', 'storage', 'export', 'share', 'settings']) assert.doesNotMatch(src('src/js/' + f + '.js'), /templat-lama/, f);
});
