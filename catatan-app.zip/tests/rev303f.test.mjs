// Rev 303f / v0.3.121: penutup Paket 303 (kotak centang di sel). Hanya audit + dokumen; kode aplikasi, SCHEMA 22, CSS, Worker, native tidak berubah.
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('alat audit pratinjau pulau ada dan memeriksa ☑/☐, kartu, dan lebar', () => {
  assert.ok(existsSync(new URL('../tools/audit_kotak_pulau.py', import.meta.url))); const a = src('tools/audit_kotak_pulau.py');
  assert.match(a, /renderIsland/); assert.match(a, /sheetCardText/); assert.match(a, /dark/);
});
test('salin/tempel aturan kotak centang SENGAJA tidak dibuat: pasteRange tidak menyentuh tab.checks', () => {
  const al = src('src/js/lembar-alat.js'); assert.ok(!/checks/.test(al.slice(al.indexOf('export function pasteRange'))));
});
test('versi 0.3.121, SCHEMA 22, tes 303e terdaftar', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA = 22/); assert.ok(src('package.json').includes('rev303e.test.mjs'));
});
console.log(n + ' tes rev303f ok');
