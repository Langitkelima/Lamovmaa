// Rev 254 / S5a: aksi mengikuti seleksi (hapus isi, sisip/hapus baris-kolom). Tes Node (modul murni + kabel UI); BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js'; import * as S from '../src/js/lembar-seleksi.js'; import * as A from '../src/js/lembar-aksi-seleksi.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
const mk = () => { const sh = L.newSheet('t'); const t = sh.tabs[0]; L.addRows(t, 9); return t; }; // 10+ baris
const dimsOf = (t) => S.dimsOfTab(t);
const put = (t, r, c, v, s) => { L.setCell(t, t.rows[r].id, t.cols[c].id, { v, ...(s ? { s } : {}) }); };
test('hapus isi: nilai dan rumus hilang, GAYA tetap, hanya sel di seleksi, filter lewat rowOk', () => {
  const t = mk(); put(t, 1, 1, 'a', { b: true }); put(t, 2, 2, 5); put(t, 5, 5, 'x'); L.setCell(t, t.rows[3].id, t.cols[1].id, { fx: '=1+1' });
  const sx = S.selectRange(dimsOf(t), { r: 1, c: 1 }, { r: 3, c: 2 }); const r = A.clearContents(t, sx);
  assert.equal(r.n, 3); assert.equal(t.rows[1].cells[t.cols[1].id].v, undefined); assert.equal(t.rows[1].cells[t.cols[1].id].s.b, true, 'gaya tetap');
  assert.equal(t.rows[5].cells[t.cols[5].id].v, 'x', 'di luar seleksi tidak tersentuh'); assert.equal(t.rows[3].cells[t.cols[1].id], undefined);
  assert.equal(A.clearContents(t, sx).changed, false, 'kedua kali tidak ada yang berubah');
  const t2 = mk(); put(t2, 0, 0, 'p'); put(t2, 1, 0, 'q'); const col = S.selectCol(dimsOf(t2), 0);
  assert.equal(A.clearContents(t2, col, (r) => r === 1).n, 1); assert.equal(t2.rows[0].cells[t2.cols[0].id].v, 'p', 'baris tersaring tidak dihapus');
  assert.deepEqual(A.clearContents(null, sx), { ok: false, changed: false, n: 0 });
});
test('sisip baris: sebanyak baris terpilih, di atas/bawah, ID lama tetap, dibatasi MAX_ROWS', () => {
  const t = mk(); const ids = t.rows.map((x) => x.id), n0 = t.rows.length; const sx = S.selectRange(dimsOf(t), { r: 2, c: 0 }, { r: 4, c: 1 });
  const up = A.insertRows(t, sx, 'above'); assert.equal(up.n, 3); assert.equal(t.rows.length, n0 + 3); assert.equal(t.rows[5].id, ids[2], 'baris lama bergeser turun');
  const dn = A.insertRows(t, S.selectRow(dimsOf(t), 0), 'below'); assert.equal(dn.at, 1); assert.equal(t.rows[0].id, ids[0]);
  while (t.rows.length < L.MAX_ROWS - 1) L.insertRow(t, 0); const r = A.insertRows(t, S.extend(dimsOf(t), S.selectRow(dimsOf(t), 0), { r: 5, c: 0 }), 'above');
  assert.equal(r.n, 1); assert.ok(r.want > r.n); assert.equal(t.rows.length, L.MAX_ROWS); assert.equal(A.insertRows(t, S.selectRow(dimsOf(t), 0), 'above').full, true);
});
test('sisip kolom: kiri/kanan, dibatasi MAX_COLS', () => {
  const t = mk(); assert.equal(A.insertCols(t, S.selectCol(dimsOf(t), 0), 'left').full, true, 'lembar baru sudah 26 kolom = batas'); A.deleteCols(t, S.extend(dimsOf(t), S.selectCol(dimsOf(t), 20), { r: 0, c: 25 })); // sisakan ruang
  const ids = t.cols.map((x) => x.id), n0 = t.cols.length; const sx = S.extend(dimsOf(t), S.selectCol(dimsOf(t), 1), { r: 0, c: 2 });
  const r = A.insertCols(t, sx, 'right'); assert.equal(r.n, 2); assert.equal(r.at, 3); assert.equal(t.cols.length, n0 + 2); assert.equal(t.cols[1].id, ids[1]);
  const l = A.insertCols(t, S.selectCol(dimsOf(t), 0), 'left'); assert.equal(l.at, 0); assert.equal(t.cols[1].id, ids[0]);
  while (t.cols.length < L.MAX_COLS) L.insertCol(t, 0); assert.equal(A.insertCols(t, S.selectCol(dimsOf(t), 0), 'left').full, true);
});
test('hapus baris/kolom: isi ikut hilang, rujukan yang dihapus = #REF!, sisakan satu, gabungan dibersihkan', () => {
  const t = mk(); put(t, 6, 0, 'z'); const keep = t.rows[6].id; const sx = S.extend(dimsOf(t), S.selectRow(dimsOf(t), 1), { r: 3, c: 0 });
  const r = A.deleteRows(t, sx); assert.equal(r.n, 3); assert.equal(t.rows.findIndex((x) => x.id === keep), 3);
  assert.equal(A.deleteRows(t, S.selectAll(dimsOf(t))).all, true, 'tidak boleh habis'); assert.equal(A.deleteCols(t, S.selectAll(dimsOf(t))).all, true);
  const c = A.deleteCols(t, S.selectCol(dimsOf(t), 2)); assert.equal(c.n, 1); assert.equal(t.cols.length, L.newSheet('x').tabs[0].cols.length - 1);
  assert.equal(A.deleteRows(t, null).ok, false);
});
test('label tombol memakai jumlah seleksi', () => {
  const sx = S.extend({ rows: 30, cols: 8 }, S.selectRow({ rows: 30, cols: 8 }, 1), { r: 3, c: 0 });
  assert.equal(A.labelOf('rowUp', sx), 'Sisip 3 baris di atas'); assert.equal(A.labelOf('delRows', S.selectRow({ rows: 30, cols: 8 }, 1)), 'Hapus 1 baris'); assert.equal(A.labelOf('x', sx), '');
});
test('kabel UI: menu Lainnya > Ubah seleksi, satu Urungkan, filter menolak sisip/hapus, tanpa heks mentah', () => {
  const d = ui.slice(ui.indexOf('const applyAct = '), ui.indexOf('const applyAct = ') + 5200);
  for (const k of ['AS.clearContents', 'AS.insertRows', 'AS.insertCols', 'AS.deleteRows', 'AS.deleteCols', 'hist.push(snap)', "'Matikan filter dulu.'", 'L.fitsLimit(sheet)']) assert.ok(d.includes(k), k);
  assert.equal((d.match(/hist\.push/g) || []).length, 1); assert.ok(!ui.includes("item('aksi'") && !ui.includes('openSelAct') && ui.includes("dlg({ title: AS.labelOf(kind, sx)") && ui.includes("from './lembar-aksi-seleksi.js'")); // Rev 264: aksi baris/kolom hanya di Menu sel
  assert.doesNotMatch(css.slice(css.indexOf('.lz-selact')), /#[0-9a-fA-F]{3,6}\b/, 'warna dari variabel tema');
  const m = src('src/js/lembar-aksi-seleksi.js'); assert.doesNotMatch(m, /document\.|localStorage|eval\(|Capacitor/); assert.deepEqual([...m.matchAll(/^import .* from '(.*)'/gm)].map((x) => x[1]).sort(), ['./lembar-seleksi.js', './lembar.js']);
});
