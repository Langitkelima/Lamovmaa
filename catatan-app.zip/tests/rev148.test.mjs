// Rev 148 / U9b-3b: UI validasi data pilihan lembar kerja (item Validasi data di Lainnya, pilihan di sel, tanda sel tidak sah). Model/mesin = Rev 147.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as V from '../src/js/lembar-validasi.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import * as S from '../src/js/storage.js';
import { a1ToStored } from '../src/js/rumus.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js');
const mk = (vals) => { const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; vals.forEach((v, r) => { if (v !== undefined) L.setCell(tab, tab.rows[r].id, tab.cols[0].id, { v }); }); return { sh, tab }; };

test('kabel UI: impor mesin validasi + makeDisplay, item validasi di openMore sesudah warna, tanda dihitung SEKALI per (tab, ver)', () => {
  assert.match(ui, /import \{ checkAt, checkRect, colorOf, validate, invalidCells, invalidTip, nextInvalid, overlapChecks, itemsFromText, rangeText, parseRange, partsFromRect, kindLabel, operands, parseNumText, parseDateText, serialText, itemRowsOf, itemsFromRows, ITEM_COLORS, MAX_CHECKS, MAX_ITEMS, MAX_ITEM_LEN \} from '\.\/lembar-validasi\.js'/); // Rev 267: impor diperluas; Rev 269: + rejectText (mode Tolak)
  assert.match(ui, /import \{ makeDisplay \} from '\.\/lembar-tampil\.js'/);
  const m = ui.slice(ui.indexOf('const openMore'), ui.indexOf('bM.addEventListener'));
  assert.ok(!m.includes("item('validasi'") && m.indexOf("item('warna'") < m.indexOf("item('csv'") && ui.includes("bt('cm-r', 'dropdown'") && ui.includes('openChecks'), 'Rev 264: Validasi data hanya lewat Dropdown di Menu sel (tekan lama)');
  assert.equal((ui.match(/invalidCells\(/g) || []).length, 1, 'invalidCells dipanggil di satu tempat (getIV)');
  const g = ui.slice(ui.indexOf('const getIV'), ui.indexOf('const drawRows'));
  assert.match(g, /tab\.id \+ '\|' \+ ver/); assert.match(g, /NO_IV/); assert.match(g, /tab\.checks\.length\) return NO_IV/);
  const d = ui.slice(ui.indexOf('const drawRows'), ui.indexOf('const paintBar'));
  assert.match(d, /iv = getIV\(\)/); assert.match(d, /classList\.add\('dd'\)/); assert.match(d, /classList\.add\('bad'\)/);
  assert.ok(d.indexOf("iv.has(") > d.indexOf('el.style.left'), 'tanda dipasang sesudah gaya sel');
});

test('kabel UI: satu langkah Urungkan per perubahan (simpan/hapus lewat apply; pilih lewat write), snapshot SEBELUM berubah, batas ukuran memulihkan', () => {
  const o = ui.slice(ui.indexOf('const openChecks'), ui.indexOf('const openMore'));
  const a = o.slice(o.indexOf('const apply = '), o.indexOf('const strip = '));
  assert.ok(a.indexOf('const snap = ser()') < a.indexOf('L.setChecks(') && a.indexOf('L.setChecks(') < a.indexOf('hist.push(snap)'));
  assert.match(a, /if \(!L\.setChecks\(tab, next\)\) return false/); assert.match(a, /fitsLimit\(sheet\)\) \{ restore\(snap\)/);
  assert.equal((o.match(/hist\.push\(/g) || []).length, 1, 'semua perubahan validasi lewat apply()');
  assert.match(o, /MAX_CHECKS/); assert.match(o, /if \(!sel\) \{ t(?:Ok|Warn|Err|Info)\('Pilih sel dulu\.'\)/); assert.match(o, /Isi minimal satu pilihan/);
  const p = ui.slice(ui.indexOf('const openPick'), ui.indexOf('const openChecks'));
  const w = p.slice(p.indexOf('const write = '), p.indexOf('const btns'));
  assert.ok(w.indexOf('const snap = ser()') < w.indexOf('L.setCell(') && w.indexOf('L.fitsLimit') < w.indexOf('hist.push(snap)'));
  assert.equal((p.match(/hist\.push\(/g) || []).length, 1);
  assert.match(p, /hasFx\(pc\)\) \{ batas\('Sel ini berumus'/); // rumus tidak ditimpa diam-diam
  assert.match(p, /onclick: \(\) => write\(it\)/); // nilai ditulis APA ADANYA (bukan lewat parseInput/singkatan nominal) agar cocok dengan daftar
  assert.doesNotMatch(p, /parseInput/);
});

test('kabel UI: ketuk sel terpilih di kolom bervalidasi + tombol Pilih membuka daftar; tombol hanya tampil di kolom bervalidasi', () => {
  const pk = ui.slice(ui.indexOf('const pick = '), ui.indexOf('// --- Rev 131'));
  assert.match(pk, /again = !!sel && sel\.r === nr && sel\.c === nc/); assert.match(pk, /if \(again && \(\(\) => \{ const pk = checkAt\(tab, sel\.r, sel\.c\); return !!pk && pk\.dd !== false; \}\)\(\)\) openPick\(\)/); // Rev 267: aturan menurut RENTANG, panah dimatikan = tidak membuka
  assert.ok(pk.indexOf('commit();') < pk.indexOf('again = '), 'isian lama disimpan dulu');
  const pf = ui.slice(ui.indexOf('function paintFmt'), ui.indexOf('function paintPal'));
  assert.match(pf, /bP\.hidden = !pkOn; bP\.disabled = !pkOn/);
  assert.match(ui, /bP\.onclick = openPick/); assert.match(ui, /bP\.addEventListener\('pointerdown', \(e\) => e\.preventDefault\(\)\)/);
});

test('perilaku: pilihan dari dialog (bentuk check) menandai sel di luar daftar memakai teks TAMPIL; sel kosong sah; Urungkan memulihkan', () => {
  const { sh, tab } = mk(['Belum', 'selesai', 'Proses', undefined, 'x']);
  const snap = JSON.stringify({ name: sh.name, tabs: sh.tabs });
  assert.equal(L.setChecks(tab, [{ id: '', c: tab.cols[0].id, k: 'list', items: V.itemsFromText('Belum\nSelesai\n belum \nSelesai') }]), true);
  assert.deepEqual(tab.checks[0].items, ['Belum', 'Selesai']); // kembar (tak peka huruf) dibuang
  assert.deepEqual([...V.invalidCells(tab, makeDisplay(tab).text)].sort(), ['2,0', '4,0']);
  // memilih dari daftar menulis ejaan resmi lalu sel itu sah
  const row = tab.rows[2]; assert.equal(L.setCell(tab, row.id, tab.cols[0].id, { v: V.stepItem(tab.checks[0], 'Proses') }), true);
  assert.deepEqual([...V.invalidCells(tab, makeDisplay(tab).text)], ['4,0']);
  assert.ok(L.fitsLimit(sh));
  const back = JSON.parse(snap); assert.equal(back.tabs[0].checks, undefined); // snapshot SEBELUM = tanpa validasi
});

test('perilaku: hasil rumus ikut diperiksa; hapus validasi = tanda hilang; kolom lain bebas; batas MAX_CHECKS', () => {
  const { sh, tab } = mk([5, 'Selesai']);
  L.setCell(tab, tab.rows[2].id, tab.cols[0].id, { fx: a1ToStored('=A1*2', tab).fx }); // hasil 10 (angka), tidak ada di daftar
  L.setChecks(tab, [{ id: '', c: tab.cols[0].id, k: 'list', items: ['10', 'Selesai'] }]);
  assert.deepEqual([...V.invalidCells(tab, makeDisplay(tab).text)], ['0,0']); // 5 tidak sah; hasil rumus 10 = "10" sah; Selesai sah
  const id = tab.checks[0].id; assert.ok(id);
  assert.equal(L.setChecks(tab, tab.checks.filter((x) => x.id !== id)), true); assert.equal(tab.checks, undefined);
  assert.equal(V.invalidCells(tab, makeDisplay(tab).text).size, 0);
  const many = tab.cols.map((c) => ({ id: '', c: c.id, k: 'list', items: ['a'] })); L.setChecks(tab, many);
  assert.ok(tab.checks.length <= V.MAX_CHECKS); assert.ok(L.fitsLimit(sh));
});

test('simpan/muat: validasi bertahan lewat salinan JSON (cadangan); SCHEMA tetap 15', () => {
  const { sh, tab } = mk(['a']); L.setChecks(tab, [{ id: '', c: tab.cols[0].id, k: 'list', items: ['a', 'b'] }]);
  const clean = L.cleanSheet(JSON.parse(JSON.stringify(sh)));
  assert.deepEqual(clean.tabs[0].checks.map((x) => [x.k, x.items]), [['list', ['a', 'b']]]); assert.equal(S.SCHEMA, 22);
});

test('Rev 148: CSS ada, ekspor/pulau/alat TIDAK memakai validasi, versi 0.3.121, tes terdaftar, dependensi tetap', () => {
  const css = src('src/css/styles.css'); for (const k of ['.lembarfs .lz-c.dd::after', '.lembarfs .lz-c.bad{', '.lembarfs .lz-fb.fb-p[hidden]{display:none}', '.lz-checks .lz-ta', '.lz-pick .lz-mi.on']) assert.ok(css.includes(k), k);
  for (const f of ['src/js/lembar-alat.js', 'src/js/lembar-tampil.js', 'src/js/export.js']) assert.doesNotMatch(src(f), /lembar-validasi/, f); // Rev 268: lembar-pulau.js kini BOLEH mengimpor validasi (warna pilihan di pulau/ekspor)
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(pk.scripts.test.includes('tests/rev148.test.mjs')); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
