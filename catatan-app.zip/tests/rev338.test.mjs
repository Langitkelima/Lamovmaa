// Rev 338 / PART I3: label cepat `#kerja ` di editor catatan (tampilan; mesin = ketik-pemicu.js).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
globalThis.document = { createElement: () => ({ setAttribute() {}, addEventListener() {}, append() {}, className: '' }), createTextNode: (t) => ({ nodeType: 3, data: t }) };
const { tagFor } = await import('../src/js/ketik-ui.js');

test('tagFor: #tag + satu spasi memicu (spasi biasa dan nbsp)', () => {
  assert.deepEqual({ ...tagFor('rapat #kerja ') }, { tag: 'kerja' });
  assert.equal(tagFor('#ide-baru ').tag, 'ide-baru');
  assert.equal(tagFor('catatan #Kerja_2\u00a0').tag, 'Kerja_2', 'nbsp dari papan ketik dianggap spasi');
  assert.equal(tagFor('#Proyék ').tag, 'Proyék', 'huruf Unicode sah');
});
test('tagFor: belum selesai, bukan tag sah, atau bukan di akhir = null', () => {
  for (const s of ['#kerja', 'rapat #kerja', '#123 ', '#1 ', '# kerja ', 'a#kerja ', '#kerja  ', '#' + 'a'.repeat(21) + ' ', '', 'tanpa tag ']) assert.equal(tagFor(s), null, JSON.stringify(s));
  assert.equal(tagFor(null), null); assert.equal(tagFor(5), null);
});
test('sumber notes.js: API label memakai sistem yang ada (validateLabel, removeLabel, toggleId), tanpa impor statis baru', () => {
  const n = read('src/js/notes.js'); const i = n.indexOf('Rev 337 / I4 + Rev 338'); assert.ok(i > 0);
  const blok = n.slice(i, i + 4600); // Rev 343: jendela 3800 -> 4600 (env.wiki + gerbang `[[` menambah sekitar 0,3 KB di blok yang sama)
  for (const k of ['validateLabel(t, labelsAll)', 'removeLabel(data, l.id)', 'toggleId(n.labels', 'ctx.persist()', 'labUi()']) assert.ok(blok.includes(k), k);
  assert.match(blok, /if \(alive\)/); assert.ok(!/^import .*ketik-ui/m.test(n));
  assert.match(blok, /indexOf\('#'\)/, 'gerbang murah sebelum memuat modul');
});
test('sumber ketik-ui.js: teks #tag tidak dihapus, toast Urungkan, tidak ada label tanpa ketukan', () => {
  const k = read('src/js/ketik-ui.js');
  assert.match(k, /tOk\(o\.msg, o\.undo\)/); assert.match(k, /tWarn\(o\.msg\)/);
  assert.match(k, /r\.st === 'on'/, 'label yang sudah terpasang tidak ditawarkan lagi');
  assert.match(k, /env\.tags/);
  const ap = k.slice(k.indexOf('const apply = () =>'), k.indexOf('const onSel'));
  assert.ok(!/removeChild|\.remove\(|deleteContents|innerHTML/.test(ap), 'teks #tag dibiarkan di catatan');
});
test('tes terdaftar; versi dan SCHEMA tidak berubah', () => {
  const pk = JSON.parse(read('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(read('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(pk.scripts.test, /node tests\/rev338\.test\.mjs/);
});
