// Rev 181b (hotfix): format sel (Tebal, Miring, warna, rata) berlaku ke SEMUA sel rentang terpilih, bukan hanya sel pertama.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
const ui = readFileSync(new URL('../src/js/lembar-ui.js', import.meta.url), 'utf8');
const i0 = ui.indexOf('function applyStyle(patch)'), fn = ui.slice(i0, ui.indexOf('bB.onclick', i0));
test('Rev 181b: applyStyle menelusuri seluruh rentang (rng) dan membatalkan semua bila lembar kebesaran', () => {
  assert.match(ui, /const styleRect = \(\) => \(rng && rng\.tabId === tab\.id \? rng\.rect/);
  assert.match(fn, /for \(let r = q\.r1; r <= q\.r2; r\+\+\) for \(let c = q\.c1; c <= q\.c2; c\+\+\)/);
  assert.match(fn, /fitsLimit/); assert.match(fn, /undo\)/); assert.match(fn, /hist\.push\(snap\)/);
});
test('Rev 181b: Tebal/Miring memakai allHave (nyala bila SEMUA sel sudah bergaya itu)', () => {
  assert.match(ui, /bB\.onclick = \(\) => applyStyle\(\{ b: allHave\('b'\) \? null : true \}\)/);
  assert.match(ui, /bI\.onclick = \(\) => applyStyle\(\{ i: allHave\('i'\) \? null : true \}\)/);
});
test('Rev 181b: setCell berulang di satu rentang memberi gaya ke semua sel (termasuk sel kosong) dan bisa dilepas', () => {
  const tab = L.newTab('T', 6);
  const run = (patch) => { for (let r = 1; r <= 3; r++) for (let c = 0; c <= 2; c++) L.setCell(tab, tab.rows[r].id, tab.cols[c].id, { s: patch }); };
  run({ b: true, bg: '#FECACA' });
  for (let r = 1; r <= 3; r++) for (let c = 0; c <= 2; c++) { const s = L.cellAt(tab, r, c).s; assert.equal(s.b, true); assert.equal(s.bg, '#FECACA'); }
  assert.equal(L.cellAt(tab, 0, 0), null); assert.equal(L.cellAt(tab, 4, 1), null); // di luar rentang tidak tersentuh
  run({ b: null, bg: null });
  for (let r = 1; r <= 3; r++) for (let c = 0; c <= 2; c++) assert.equal(L.cellAt(tab, r, c), null);
});
