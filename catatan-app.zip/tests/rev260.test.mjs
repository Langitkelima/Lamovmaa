// Rev 260: ketuk sel = hanya memilih (keyboard baru di ketuk kedua), Gabungkan sel langsung dari seleksi. Tes Node; BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8'); const ui = src('src/js/lembar-ui.js');
const pick = ui.slice(ui.indexOf('const pick = (e) => {'), ui.indexOf('// --- Rev 131 / U8a-4c'));
test('ketuk sel pertama hanya memilih; keyboard hanya pada ketuk kedua di sel yang sama', () => {
  assert.ok(pick.includes('else if (again && nsx && nsx.kind === \'cell\' && c.classList.contains(\'lz-c\') && !val.disabled)'));
  assert.ok(!pick.includes('else if (nsx && nsx.kind === \'cell\' && c.classList.contains(\'lz-c\') && !val.disabled && !(tab.cols'));
  assert.equal((pick.match(/val\.focus\(\)/g) || []).length, 1);
  assert.ok(pick.indexOf('openPick();') < pick.indexOf('val.focus()')); // sel bervalidasi tetap membuka daftar lebih dulu
});
test('Gabungkan sel: seleksi lebih dari satu sel digabung langsung, tanpa dialog jumlah kolom/baris', () => {
  const o = ui.slice(ui.indexOf('const openMerge = () => {'), ui.indexOf('// --- Rev 157 / U10c-2a: Diagram'));
  const direct = o.slice(o.indexOf('if (rc && !(ex && same))'), o.indexOf('    if (ex) {'));
  assert.ok(direct.includes('planMerge(tab, rc.r1, rc.c1, rc.r2, rc.c2)') && direct.includes('{ clear: true }') && direct.includes('L.fitsLimit(sheet)'));
  assert.ok(direct.indexOf('const snap = ser()') < direct.indexOf('L.mergeCells(') && direct.indexOf('L.fitsLimit(sheet)') < direct.indexOf('hist.push(snap)'));
  assert.ok(!direct.includes('h(\'input\''));
  assert.ok(o.indexOf('if (rc && !(ex && same))') < o.indexOf('const mkn = ')); // dialog lama tetap ada sebagai cadangan satu sel
});
test('seleksi baris/kolom/semua yang berisi data diminta konfirmasi dulu; seleksi persis satu gabungan = Pisahkan sel', () => {
  const o = ui.slice(ui.indexOf('const openMerge = () => {'), ui.indexOf('// --- Rev 157 / U10c-2a: Diagram'));
  assert.ok(o.includes("selx.kind === 'row' || selx.kind === 'col' || selx.kind === 'all'") && o.includes('dlg({ title:'));
  assert.ok(o.includes('same = !!(ex && rc && ex.r1 === rc.r1') && o.includes('if (ex) {'));
  assert.ok(ui.includes('const mergeRange = () => {') && ui.includes("'Pisahkan sel' : 'Gabungkan sel'"));
});
test('Rev 261: sel gabungan (selx kind range dengan jangkar = ujung setelah normSel) tetap bisa membuka keyboard pada ketuk kedua', () => {
  assert.ok(pick.includes("selx.kind === 'range' && selx.a.r === selx.f.r && selx.a.c === selx.f.c"));
});
