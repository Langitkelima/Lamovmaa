// Rev 181c: chip tabel = dok ikon atas + label bawah; centang dua lapis (bilah isian lembar kerja + pojok editor). Hanya tampilan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { CHIP_ICONS, chipText, TABLE_CHIPS, TABLE_SHEET_CHIP, CHIP_BACK_ID } from '../src/js/bilah-chip.js';
const rd = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const css = rd('src/css/styles.css'), chipSrc = rd('src/js/bilah-chip.js'), notes = rd('src/js/notes.js'), lz = rd('src/js/lembar-ui.js');
const rev = css.slice(css.indexOf('Rev 181c:'));
test('Rev 181c: setiap chip tabel, sub-bilah, Ubah jadi lembar kerja, dan Kembali punya ikon', () => {
  const ids = [...TABLE_CHIPS.main, ...TABLE_CHIPS.total, ...TABLE_CHIPS.pick, TABLE_SHEET_CHIP, { id: CHIP_BACK_ID }].map((c) => c.id);
  for (const id of ids) assert.ok(typeof CHIP_ICONS[id] === 'string' && CHIP_ICONS[id].length > 8, 'ikon ' + id);
});
test('Rev 181c: chipText membuang awalan ＋ dan akhiran ⌄ saja', () => {
  assert.equal(chipText('＋ Baris di bawah'), 'Baris di bawah'); assert.equal(chipText('Total ⌄'), 'Total'); assert.equal(chipText('Pilih: Baris ⌄'), 'Pilih: Baris');
  assert.equal(chipText('Hapus tabel'), 'Hapus tabel'); assert.equal(chipText(null), '');
});
test('Rev 181c: bilah chip hanya berikon bila `ico` diberikan; label state tetap lewat paint; tabel memberi ico', () => {
  assert.match(chipSrc, /ico = null/); assert.match(chipSrc, /scroller\.classList\.toggle\('dock', tiles\)/); assert.match(chipSrc, /b\.querySelector\('\.cl'\) \|\| b/);
  assert.match(notes, /createChipBar\(h, \{ label: 'Alat tabel', onAction: \(id\) => tableChip\(id\), ico \}\)/);
  assert.match(notes, /createChipBar\(h, \{ label: 'Alat bagian lipat', onAction: \(id\) => foldChip\(id\) \}\);/); // bagian lipat tetap pil teks
});
test('Rev 181c: CSS memakai variabel tema saja (tanpa warna heks)', () => {
  assert.ok(rev.length > 800); assert.doesNotMatch(rev, /#[0-9a-fA-F]{3,8}\b/);
  for (const k of ['.chip.tile{', '.chip.tile.on{', '.chip.tile.danger', '.chipbar .chips.dock{', '.lembarfs .lz-ok{', '.fsh .hmode[aria-pressed=true]{']) assert.ok(rev.includes(k), k);
  assert.match(rev, /background-clip:content-box/);
});
test('Rev 181c: centang bilah isian berupa ikon SVG (bukan teks), nama aksesibel tetap', () => {
  assert.match(lz, /class: 'lz-ok', 'aria-label': 'Simpan isi sel', disabled: true \}, ico\(PATH\.tugas\)\)/);
});
test('Rev 181c: versi 0.3.121, SCHEMA 18', () => {
  assert.match(rd('package.json'), /"version": "0\.3\.121"/); assert.match(rd('src/js/settings.js'), /v0\.3\.121/);
});
