// Rev 164 / Q10 tahap 2: TEXT(nilai; format) + FORMAT TANGGAL OTOMATIS untuk hasil DATE/TODAY (format manual tetap menang)
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { argHint } from '../src/js/rumus-bantu.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 9, 0, 0).getTime(); // Selasa 10 Nov 2026 09:00
function at(f) { const t = L.newTab('T', 12); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cF = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cF'); }
const T = (v, f) => at(`=TEXT(${v};"${f}")`);
const D = '10/11/2026', DD = 'DATE(2026;11;10)';

test('TEXT tanggal: dd/mm/yyyy, dd mmmm yyyy, nama hari/bulan Indonesia, jam, mm = bulan atau menit sesuai konteks', () => {
  assert.equal(T(DD, 'dd/mm/yyyy'), D); assert.equal(T(DD, 'dd mmmm yyyy'), '10 November 2026'); assert.equal(T(DD, 'dddd, d mmm yy'), 'Selasa, 10 Nov 26'); assert.equal(T(DD, 'ddd'), 'Sel');
  assert.equal(T('DATE(2026;3;5)', 'd/m/yyyy'), '5/3/2026'); assert.equal(T('DATE(2026;3;5)', 'dd-mm-yy'), '05-03-26'); assert.equal(T('DATE(2026;5;5)', 'mmmm'), 'Mei'); assert.equal(T(DD, 'mm/yyyy'), '11/2026');
  assert.equal(T('NOW()', 'hh:mm'), '09:00'); assert.equal(T('NOW()', 'dd/mm/yyyy hh:mm:ss'), '10/11/2026 09:00:00'); assert.equal(T('0,75', 'h:mm'), '18:00'); assert.equal(T('0,76', 'hh:mm'), '18:14'); assert.equal(T('0,999999999', 'hh:mm'), '00:00');
  assert.equal(T('46336,5', 'hh:mm:ss'), '12:00:00'); assert.equal(T('"46336"', 'dd/mm/yyyy'), D); // teks angka dikoersi
  assert.equal(T(DD, 'DD/MM/YYYY'), D); // huruf besar/kecil tidak berpengaruh
  assert.equal(T('0', 'dd/mm/yyyy').e, '#VALUE!'); assert.equal(T('-1', 'hh:mm').e, '#VALUE!'); assert.equal(T('"abc"', 'dd/mm/yyyy').e, '#VALUE!'); assert.equal(T('TRUE', 'dd/mm/yyyy').e, '#VALUE!');
});
test('TEXT angka: 0, 0,00, #.##0, 0%, awalan/akhiran, pembulatan, tanda, nol di depan', () => {
  assert.equal(T('1234,5', '0'), '1235'); assert.equal(T('2,5', '0'), '3'); assert.equal(T('-2,5', '0'), '-3'); assert.equal(T('1234,5', '0,00'), '1234,50'); assert.equal(T('1234,5', '#.##0'), '1.235');
  assert.equal(T('1234567,891', '#.##0,00'), '1.234.567,89'); assert.equal(T('0,256', '0%'), '26%'); assert.equal(T('0,256', '0,0%'), '25,6%'); assert.equal(T('5', '000'), '005'); assert.equal(T('1234567', '0'), '1234567');
  assert.equal(T('-1234', 'Rp #.##0'), '-Rp 1.234'); assert.equal(T('1500', '#.##0 kg'), '1.500 kg'); assert.equal(T('0', '0,00'), '0,00'); assert.equal(T('-0,001', '0,00'), '0,00');
  assert.equal(T('1,5', '0,0#'), '1,5'); assert.equal(T('1,25', '0,0#'), '1,25'); assert.equal(T('0,5', '#,##'), ',5'); // # di depan koma = tanpa nol di depan (seperti Excel)
  assert.equal(T('999,999', '0,00'), '1000,00'); assert.equal(T('1,005', '0,00'), '1,01'); // 1,005 -> 1,01 (bukan 1,00)
});
test('TEXT: teks biasa lewat apa adanya, sel kosong = 0, galat menjalar, format salah/kosong, batas', () => {
  assert.equal(T('"abc"', '0,00'), 'abc'); assert.equal(at('=TEXT(A1;"0,00")'), '0,00'); assert.equal(at('=TEXT(1/0;"0")').e, '#DIV/0!'); assert.equal(T('5', ''), ''); assert.equal(T('5', 'abc'), 'abc');
  assert.equal(T('TRUE', '0').e, '#VALUE!'); assert.equal(T('5', '0,0,0').e, '#VALUE!'); assert.equal(T('1E+15', '0').e, '#NUM!'); assert.equal(at('=TEXT(5)').rejected !== undefined || at('=TEXT(5)').e === '#VALUE!', true);
  assert.equal(at('=TEXT(A1:A2;"0")').e, '#VALUE!'); assert.equal(at('=TEXT(1/0;"0")&"x"').e, '#DIV/0!'); assert.equal(at('="Total: "&TEXT(1234,5;"#.##0,00")'), 'Total: 1.234,50');
});
test('daftar fungsi 48 termasuk TEXT (sig, ket, petunjuk argumen, saran huruf awal)', () => {
  const f = R.FUNCTION_LIST.find((x) => x.name === 'TEXT'); assert.ok(f && f.sig.startsWith('TEXT(') && f.ket.length > 3); assert.equal(R.FUNCTION_LIST.length, 53);
  assert.equal(argHint('TEXT', 6).parts.length, 2); assert.ok(R.suggestFunctions('te').some((x) => x.name === 'TEXT'));
});
test('fxAutoNf: DATE/TODAY dan tanggal +/- angka = Tanggal; selisih tanggal, NOW, fungsi lain = bukan', () => {
  const A = R.fxAutoNf; const t = L.newTab('T', 12); const f = (x) => A(R.a1ToStored(x, t).fx);
  for (const x of ['=TODAY()', '=DATE(2026;11;10)', '=TODAY()+7', '=7+TODAY()', '=TODAY()-30', '=DATE(2026;1;1)+B1']) assert.deepEqual(f(x), { k: 'date', p: 'short' }, x);
  for (const x of ['=NOW()', '=TODAY()-DATE(2026;1;1)', '=30-TODAY()', '=YEAR(TODAY())', '=SUM(A1:A3)', '=1+2', '=TODAY()+TODAY()']) assert.equal(f(x), null, x);
  assert.equal(A(undefined), null); assert.equal(A('bukan rumus'), null); assert.equal(A('=((('), null);
});
test('tampilan (makeDisplay): DATE/TODAY otomatis dd/mm/yyyy; format manual menang; angka lain tidak terpengaruh', () => {
  const t = L.newTab('T', 12), put = (r, f, s) => { t.rows[r].cells.cF = { fx: R.a1ToStored(f, t).fx }; if (s) t.rows[r].cells.cF.s = s; };
  put(0, '=DATE(2026;11;10)'); put(1, '=TODAY()+30'); put(2, '=TODAY()-DATE(2026;1;1)'); put(3, '=NOW()'); put(4, '=DATE(2026;11;10)', { nf: { k: 'number' } }); put(5, '=YEAR(TODAY())'); put(6, '=DATE(2026;11;10)', { nf: { k: 'currency', c: 'IDR', d: 0 } });
  const d = makeDisplay(t, { now: NOW });
  assert.equal(d.text(0, 5), D); assert.equal(d.text(1, 5), '10/12/2026'); assert.equal(d.text(2, 5), '313'); assert.ok(/^46\d{3},375$/.test(d.text(3, 5)), d.text(3, 5));
  assert.equal(d.text(4, 5), '46.336'); assert.equal(d.text(5, 5), '2026'); assert.equal(d.text(6, 5), 'Rp 46.336'); assert.equal(d.plain(0, 5), D); // ekspor/TSV ikut tanggal
});
test('kabel: grid dan tampilan memakai fxAutoNf; rumus.js tetap murni; TEXT tidak dipakai modul lain', () => {
  assert.match(src('src/js/lembar-ui.js'), /fxAutoNf/); assert.match(src('src/js/lembar-tampil.js'), /fxAutoNf/);
  const s = src('src/js/rumus.js'); assert.ok(!/^\s*import\s/m.test(s)); assert.ok(!/document\.|window\.|localStorage|eval\(|new Function/.test(s));
  assert.equal(src('package.json').includes('tests/rev164.test.mjs'), true);
});
