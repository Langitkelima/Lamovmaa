// Rev 214 / v0.3.121 (Kelimaa AI Tahap 2): RUANG (workspace) percakapan + riwayat per ruang di berkas. FS PALSU (Map), tanpa HP. SCHEMA tetap 18.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as R from '../src/js/ai/ruang.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const fakeFS = (opt = {}) => { const m = new Map(), log = [];
  return { m, log,
    readFile: async ({ path, directory, encoding }) => { log.push(['read', path, directory]); if (opt.readErr) throw new Error(opt.readErr); if (!m.has(path)) throw new Error('File does not exist'); return { data: m.get(path) }; },
    writeFile: async ({ path, data, directory, encoding, recursive }) => { log.push(['write', path, directory]); if (opt.writeErr) throw new Error(opt.writeErr); if (opt.slow) await new Promise((r) => setTimeout(r, opt.slow--)); m.set(path, data); return { uri: path }; },
    deleteFile: async ({ path }) => { if (!m.has(path)) throw new Error('File does not exist'); m.delete(path); },
    rmdir: async ({ path }) => { let n = 0; for (const k of [...m.keys()]) if (k.startsWith(path + '/')) { m.delete(k); n++; } if (!n) throw new Error('Folder does not exist'); },
  }; };
const NOW = 1_700_000_000_000, rnd0 = () => 0.5;

test('indeks bawaan: satu ruang "Umum" bertugas chat.general, id lolos ID_RE', () => {
  const i = R.defaultIndex(NOW, rnd0); assert.equal(i.list.length, 1); assert.equal(i.list[0].name, 'Umum'); assert.equal(i.list[0].task, 'chat.general'); assert.ok(R.ID_RE.test(i.active)); assert.equal(i.active, i.list[0].id);
});
test('normIndex: id berbahaya/duplikat/nama kosong dibuang; task asing jadi bawaan; active tak valid pindah ke ruang pertama; kosong = bawaan', () => {
  const i = R.normIndex({ active: 'zzz', list: [{ id: '../etc', name: 'X' }, { id: 'wabcde1', name: 'Kerja', task: 'research.search' }, { id: 'wabcde1', name: 'Dobel' }, { id: 'wfghij2', name: '   ' }, { id: 'wklmno3', name: 'Ide', task: 'creative.general' }] }, NOW, rnd0);
  assert.deepEqual(i.list.map((w) => [w.id, w.name, w.task]), [['wabcde1', 'Kerja', 'chat.general'], ['wklmno3', 'Ide', 'creative.general']]); assert.equal(i.active, 'wabcde1');
  for (const bad of [null, 5, 'x', {}, { list: 'a' }, { list: [] }]) assert.equal(R.normIndex(bad, NOW, rnd0).list.length, 1);
  const many = { list: Array.from({ length: 40 }, (_, k) => ({ id: 'w' + String(k).padStart(5, 'a'), name: 'R' + k })) }; assert.equal(R.normIndex(many).list.length, R.MAX_WS);
});
test('cleanName: rapikan spasi/kontrol, tolak kosong dan > 30 huruf', () => {
  assert.deepEqual(R.cleanName('  Ide \n  baru\t'), { ok: true, value: 'Ide baru' }); assert.equal(R.cleanName('   ').ok, false); assert.equal(R.cleanName('a'.repeat(31)).ok, false); assert.equal(R.cleanName('a'.repeat(30)).ok, true); assert.equal(R.cleanName(null).ok, false);
});
test('addWs/renameWs/setTask/setActive/removeWs: aturan nama unik (tanpa beda huruf besar), batas jumlah, hapus terakhir = ruang bawaan baru', () => {
  let i = R.defaultIndex(NOW, rnd0); const a = R.addWs(i, 'Kerja', NOW + 1, () => 0.1); assert.ok(a.ok); i = a.idx; assert.equal(i.active, a.id);
  assert.equal(R.addWs(i, 'kerja').ok, false); assert.equal(R.addWs(i, 'umum').ok, false);
  assert.equal(R.renameWs(i, a.id, 'Umum').ok, false); const rn = R.renameWs(i, a.id, 'Proyek'); assert.ok(rn.ok); i = rn.idx; assert.equal(R.activeWs(i).name, 'Proyek');
  i = R.setTask(i, a.id, 'analysis.general'); assert.equal(R.activeWs(i).task, 'analysis.general'); assert.equal(R.setTask(i, a.id, 'bogus'), i);
  const first = i.list[0].id; i = R.setActive(i, first); assert.equal(i.active, first); assert.equal(R.setActive(i, 'nope'), i);
  i = R.removeWs(i, first, NOW, rnd0); assert.equal(i.list.length, 1); assert.equal(i.active, a.id);
  const solo = R.removeWs(i, a.id, NOW, rnd0); assert.equal(solo.list.length, 1); assert.equal(solo.list[0].name, 'Umum');
  let full = R.defaultIndex(NOW, rnd0); for (let k = 1; k < R.MAX_WS; k++) full = R.addWs(full, 'R' + k, NOW + k, () => k / 100).idx; assert.equal(full.list.length, R.MAX_WS); assert.equal(R.addWs(full, 'lagi').ok, false);
});
test('normMsgs: hanya user/assistant, teks 1..4000, jam HH:MM, mulai dari pengguna, maks. 100 terakhir', () => {
  const m = R.normMsgs([{ role: 'assistant', content: 'yatim' }, { role: 'system', content: 'x' }, { role: 'user', content: ' a ', t: '10:05' }, { role: 'assistant', content: 'b', t: 'bad' }, { role: 'user', content: '' }, { role: 'user', content: 'x'.repeat(4001) }, 7, null]);
  assert.deepEqual(m, [{ role: 'user', content: 'a', t: '10:05' }, { role: 'assistant', content: 'b' }]);
  const big = Array.from({ length: 300 }, (_, k) => ({ role: k % 2 ? 'assistant' : 'user', content: 'p' + k })); const t = R.normMsgs(big); assert.ok(t.length <= R.MAX_KEEP); assert.equal(t[0].role, 'user'); assert.equal(t[t.length - 1].content, 'p299'); assert.deepEqual(R.normMsgs('bukan array'), []);
});
test('store: indeks dan pesan bolak-balik lewat berkas di folder DATA/kelimaa_ai; berkas belum ada = bawaan/kosong', async () => {
  const fs = fakeFS(), st = R.makeStore(fs);
  const li = await st.loadIndex(NOW); assert.equal(li.ok, true); assert.equal(li.idx.list[0].name, 'Umum'); assert.equal(fs.m.size, 0); // memuat TIDAK menulis
  const i = R.addWs(li.idx, 'Kerja', NOW, rnd0).idx; assert.equal((await st.saveIndex(i)).ok, true);
  assert.deepEqual((await st.loadIndex()).idx.list.map((w) => w.name), ['Umum', 'Kerja']);
  const id = i.active; assert.deepEqual(await st.loadMsgs(id), { ok: true, msgs: [] });
  assert.equal((await st.saveMsgs(id, [{ role: 'user', content: 'Halo', t: '09:00' }, { role: 'assistant', content: 'Hai', t: '09:01' }])).ok, true);
  assert.equal((await st.loadMsgs(id)).msgs.length, 2);
  for (const [, path, dir] of fs.log) { assert.ok(path.startsWith('kelimaa_ai/')); assert.equal(dir, 'DATA'); }
  assert.deepEqual([...fs.m.keys()].sort(), ['kelimaa_ai/' + id + '.json', 'kelimaa_ai/ruang.json'].sort());
});
test('store: berkas rusak (bukan JSON) = kosong/bawaan tanpa error; galat baca NYATA = {ok:false} (tidak menimpa data)', async () => {
  const fs = fakeFS(); fs.m.set('kelimaa_ai/ruang.json', '{rusak'); fs.m.set('kelimaa_ai/wabcde1.json', 'bukan json');
  const st = R.makeStore(fs); assert.equal((await st.loadIndex(NOW)).idx.list.length, 1); assert.deepEqual(await st.loadMsgs('wabcde1'), { ok: true, msgs: [] });
  const bad = R.makeStore(fakeFS({ readErr: 'Permission denied' })); const r = await bad.loadIndex(); assert.equal(r.ok, false); assert.match(r.msg, /Permission/); assert.equal((await bad.loadMsgs('wabcde1')).ok, false);
});
test('store: id tidak sah ditolak SEBELUM menyentuh berkas (anti path traversal); galat tulis dilaporkan, tidak melempar', async () => {
  const fs = fakeFS(), st = R.makeStore(fs);
  for (const bad of ['../x', 'w/../a', '', 'W1234', null, 'wabc']) { assert.equal((await st.loadMsgs(bad)).ok, false); assert.equal((await st.saveMsgs(bad, [])).ok, false); assert.equal((await st.removeMsgs(bad)).ok, false); }
  assert.equal(fs.log.length, 0);
  const w = R.makeStore(fakeFS({ writeErr: 'Disk penuh' })); const r = await w.saveMsgs('wabcde1', [{ role: 'user', content: 'a' }]); assert.equal(r.ok, false); assert.match(r.msg, /Disk penuh/);
});
test('store: penulisan beruntun DISERIALKAN (tidak saling menimpa); removeMsgs dan clearAll tidak error bila berkas tak ada', async () => {
  const fs = fakeFS({ slow: 30 }), st = R.makeStore(fs), id = 'wabcde1';
  const ps = [1, 2, 3].map((n) => st.saveMsgs(id, [{ role: 'user', content: 'v' + n }])); await Promise.all(ps);
  assert.equal(JSON.parse(fs.m.get('kelimaa_ai/' + id + '.json'))[0].content, 'v3');
  assert.equal((await st.removeMsgs(id)).ok, true); assert.equal((await st.removeMsgs(id)).ok, true);
  await st.saveMsgs(id, [{ role: 'user', content: 'a' }]); await st.saveIndex(R.defaultIndex()); assert.equal((await st.clearAll()).ok, true); assert.equal(fs.m.size, 0); assert.equal((await st.clearAll()).ok, true);
});
test('saveMsgs memangkas ke 100 pesan terakhir dan membuang bentuk tak sah sebelum menulis', async () => {
  const fs = fakeFS(), st = R.makeStore(fs), id = 'wabcde1', big = Array.from({ length: 250 }, (_, k) => ({ role: k % 2 ? 'assistant' : 'user', content: 'p' + k })); big.push({ role: 'system', content: 'jahat' });
  await st.saveMsgs(id, big); const saved = JSON.parse(fs.m.get('kelimaa_ai/' + id + '.json')); assert.ok(saved.length <= 100); assert.ok(saved.every((m) => m.role === 'user' || m.role === 'assistant'));
});
test('kabel obrolan.js: ruang lewat ai/ruang.js (tanpa menyebut plugin atau data aplikasi), jenis pekerjaan per ruang, hapus pakai dialog, teks lewat node teks', () => {
  const ob = src('src/js/ai/obrolan.js');
  for (const k of ["import * as R from './ruang.js'", "R.openStore()", "'aria-label': 'Riwayat percakapan'", "'Hapus riwayat?'", "'Hapus semua riwayat?'", "R.byRecent(idx)", "R.touchWs(", "R.uniqueName(", "isiBot(w, isi)"]) assert.ok(ob.includes(k), k);
  assert.doesNotMatch(ob, /innerHTML|insertAdjacentHTML|outerHTML|localStorage|sessionStorage|Filesystem|catatan_app_data|\.priv|\.trash|\.notes|\.tasks|data\./);
  const rg = src('src/js/ai/ruang.js'); assert.deepEqual([...rg.matchAll(/^import .*$/gm)].map((x) => x[0]), ["import { TASK_CHOICES } from './sambungan.js';", "import { nativePlugin } from '../native.js';", "import { cleanSources, cleanSuggest } from './riset.js'; // Rev 233", "import { cleanAtt } from './lampiran-ref.js'; // Rev 306a: rujukan lampiran catatan (id + judul, TANPA isi) ikut tersimpan di pesan pengguna"]); /* Rev 306a: satu impor murni tanpa impor lain ditambahkan DISENGAJA */ assert.doesNotMatch(rg, /document\.|window\.|localStorage|innerHTML|console\./);
});
test('startup tidak memuat modul AI; versi 0.3.121, SCHEMA 18 tetap, CSS Rev 214 seimbang tanpa heks/blur, tes terdaftar', () => {
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\/ruang|ruang\.js/); assert.doesNotMatch(src('src/js/startup.js'), /\/ai\//);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/); assert.match(pk.scripts.test, /node tests\/rev216\.test\.mjs/);
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 214'); assert.ok(i > 0); assert.doesNotMatch(css.slice(i), /#[0-9a-fA-F]{6}|blur\(/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
