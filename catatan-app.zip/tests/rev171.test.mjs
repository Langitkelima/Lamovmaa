// Rev 171: Salin / Tempel / Tempel sederet / Tempel nilai saja di menu Lainnya + ikon Lainnya = bintang Langit.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { copyCell, pasteClip } from '../src/js/lembar-alat.js';
import { pasteMessage, pasteRangeText } from '../src/js/lembar-ui.js';

const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet('t'), tab = sh.tabs[0]; return { sh, tab }; };
const put = (tab, a, v, s) => { const c = a.charCodeAt(0) - 65, r = Number(a.slice(1)) - 1; L.setCell(tab, tab.rows[r].id, tab.cols[c].id, { ...(typeof v === 'string' && v[0] === '=' ? { fx: R.a1ToStored(v, tab).fx } : { v }), ...(s ? { s } : {}) }); };
const cellAt = (tab, a) => { const c = a.charCodeAt(0) - 65, r = Number(a.slice(1)) - 1; return tab.rows[r].cells[tab.cols[c].id]; };
const fxA1 = (tab, a) => { const cell = cellAt(tab, a); return cell && cell.fx ? R.storedToA1(cell.fx, tab) : cell && cell.v; };
const idx = (a) => [Number(a.slice(1)) - 1, a.charCodeAt(0) - 65];

test('Salin lalu Tempel sederet ke kanan: =SUM(B6:B17) di B18 jadi C18, D18 (kasus rekaman layar)', () => {
  const { tab } = mk(); for (let r = 6; r <= 17; r++) { put(tab, 'B' + r, r); put(tab, 'C' + r, 1); put(tab, 'D' + r, 2); }
  put(tab, 'B18', '=SUM(B6:B17)'); const [r0, c0] = idx('B18'); const cp = copyCell(tab, r0, c0); assert.equal(cp.ok, true);
  const [r1, c1] = idx('C18'); const res = pasteClip(tab, cp.clip, r1, c1, { count: 2, dir: 'right', keepFx: true });
  assert.equal(res.ok, true); assert.equal(res.pasted, 2); assert.equal(res.fxPasted, 2);
  assert.equal(fxA1(tab, 'C18'), '=SUM(C6:C17)'); assert.equal(fxA1(tab, 'D18'), '=SUM(D6:D17)');
  const calc = R.computeTab(tab); assert.equal(calc.get(tab.rows[17].id, 'cC'), 12); assert.equal(calc.get(tab.rows[17].id, 'cD'), 24);
});
test('Tempel satu sel ke bawah: rujukan relatif bergeser, $ tetap, gaya ikut', () => {
  const { tab } = mk(); put(tab, 'A1', 2); put(tab, 'A2', 3); put(tab, 'C1', 10); put(tab, 'B1', '=A1*$C$1', { b: true, bg: '#ffeeaa' });
  const cp = copyCell(tab, 0, 1).clip; const res = pasteClip(tab, cp, 1, 1, {});
  assert.equal(res.pasted, 1); assert.equal(fxA1(tab, 'B2'), '=A2*$C$1'); assert.equal(cellAt(tab, 'B2').s.b, true); assert.equal(cellAt(tab, 'B2').s.bg, '#ffeeaa');
});
test('Tempel penuh MENGGANTI isi dan gaya sel tujuan (satu sel boleh menimpa rumus)', () => {
  const { tab } = mk(); put(tab, 'A1', 5, { b: true }); put(tab, 'B1', '=1+1', { i: true, fg: '#112233' });
  const res = pasteClip(tab, copyCell(tab, 0, 0).clip, 0, 1, {});
  assert.equal(res.pasted, 1); const c = cellAt(tab, 'B1'); assert.equal(c.v, 5); assert.equal(c.fx, undefined); assert.equal(c.s.b, true); assert.equal(c.s.i, undefined); assert.equal(c.s.fg, undefined);
});
test('Tempel sederet (keepFx): sel tujuan berumus tidak ditimpa dan dilaporkan', () => {
  const { tab } = mk(); put(tab, 'A1', 7); put(tab, 'B2', '=1+1');
  const res = pasteClip(tab, copyCell(tab, 0, 0).clip, 0, 1, { count: 3, dir: 'right', keepFx: true });
  assert.equal(res.pasted, 3); const t2 = mk().tab; put(t2, 'A1', 7); put(t2, 'A2', '=1+1');
  const r2 = pasteClip(t2, copyCell(t2, 0, 0).clip, 1, 0, { count: 2, dir: 'down', keepFx: true });
  assert.equal(r2.skippedTarget, 1); assert.equal(r2.pasted, 1); assert.equal(fxA1(t2, 'A2'), '=1+1'); assert.equal(cellAt(t2, 'A3').v, 7);
});
test('Tempel nilai saja: hasil hitung tanpa rumus, gaya tujuan tidak disentuh, boleh lintas tab', () => {
  const { sh, tab } = mk(); put(tab, 'A1', 4); put(tab, 'A2', 6); put(tab, 'A3', '=SUM(A1:A2)', { b: true }); put(tab, 'C1', 'x', { bg: '#aabbcc' });
  const cp = copyCell(tab, 2, 0).clip; assert.equal(cp.val, 10);
  const res = pasteClip(tab, cp, 0, 2, { valuesOnly: true }); assert.equal(res.pasted, 1);
  const c = cellAt(tab, 'C1'); assert.equal(c.v, 10); assert.equal(c.fx, undefined); assert.equal(c.s.bg, '#aabbcc'); assert.equal(c.s.b, undefined);
  const other = { ...L.newSheet('u').tabs[0], id: 'tLain' }; const r2 = pasteClip(other, cp, 0, 0, { valuesOnly: true }); assert.equal(r2.pasted, 1); assert.equal(other.rows[0].cells[other.cols[0].id].v, 10);
});
test('Rumus tidak bisa ditempel di tab lain (blocked tab); asal yang sudah dihapus (blocked origin); hasil galat tidak bisa jadi nilai', () => {
  const { tab } = mk(); put(tab, 'A1', 1); put(tab, 'B1', '=A1+1'); const cp = copyCell(tab, 0, 1).clip;
  const other = { ...L.newSheet('u').tabs[0], id: 'tLain' }; assert.equal(pasteClip(other, cp, 0, 0, {}).blocked, 'tab');
  const cp2 = { ...cp, rowId: 'r-hilang' }; assert.equal(pasteClip(tab, cp2, 3, 1, {}).blocked, 'origin');
  put(tab, 'C1', '=1/0'); const ce = copyCell(tab, 0, 2).clip; assert.equal(ce.valErr, true); assert.equal(pasteClip(tab, ce, 1, 2, { valuesOnly: true }).blocked, 'err');
  assert.equal(pasteClip(tab, ce, 1, 2, {}).pasted, 1); // Tempel penuh rumus galat tetap boleh (rumusnya yang disalin)
});
test('Baris disisipkan sesudah Salin: asal dilacak lewat ID, jadi rujukan tetap bergeser benar', () => {
  const { tab } = mk(); put(tab, 'A1', 1); put(tab, 'A2', 2); put(tab, 'B1', '=A1');
  const cp = copyCell(tab, 0, 1).clip; const spare = tab.rows.pop(); tab.rows.unshift({ id: 'rBaru', cells: {} }); tab.rows.push(spare); // satu baris kosong di atas
  assert.equal(fxA1(tab, 'B2'), '=A2'); // sel asal kini di B2 dan rujukannya ikut pindah ke A2
  const res = pasteClip(tab, cp, 2, 1, {}); assert.equal(res.fxPasted, 1); assert.equal(fxA1(tab, 'B3'), '=A3'); // satu baris di bawah asal => bergeser +1 (tanpa pelacakan ID jadi =A4)
});
test('Rujukan keluar lembar saat ditempel = #REF! dan dilaporkan; tujuan di luar lembar dilewati; sel gabungan tertutup dilewati', () => {
  const { tab } = mk(); put(tab, 'A1', 1); put(tab, 'B2', '=A1+1');
  const res = pasteClip(tab, copyCell(tab, 1, 1).clip, 0, 1, {}); assert.equal(res.refLost, 1); assert.match(tab.rows[0].cells[tab.cols[1].id].fx, /#REF!/);
  const t3 = mk().tab; put(t3, 'A1', 3); const nr = t3.cols.length; const r3 = pasteClip(t3, copyCell(t3, 0, 0).clip, 0, nr - 2, { count: 5, dir: 'right' }); assert.equal(r3.pasted, 2); assert.equal(r3.truncated, 3);
});
test('Sel kosong disalin = Tempel mengosongkan sel tujuan; pesan hasil', () => {
  const { tab } = mk(); put(tab, 'B1', 9, { b: true }); const res = pasteClip(tab, copyCell(tab, 0, 0).clip, 0, 1, {}); assert.equal(res.pasted, 1); assert.equal(cellAt(tab, 'B1'), undefined);
  assert.equal(pasteClip(tab, copyCell(tab, 0, 0).clip, 0, 1, {}).pasted, 0); assert.match(pasteMessage({ pasted: 0 }), /Tidak ada yang berubah/);
  assert.match(pasteMessage({ pasted: 3, fxPasted: 3 }), /3 sel ditempel\. 3 rumus ditempel/); assert.match(pasteMessage({ blocked: 'tab' }), /tab asalnya/); assert.match(pasteMessage({ blocked: 'err' }), /galat/);
  assert.equal(pasteRangeText({ r: 17, c: 2 }, 3, 'right'), 'C18:E18'); assert.equal(pasteRangeText({ r: 17, c: 2 }, 1, 'down'), 'C18'); assert.equal(pasteRangeText({ r: 0, c: 0 }, 4, 'down'), 'A1:A4');
});
test('UI: menu Lainnya memuat Salin/Tempel/Tempel sederet/Tempel nilai; ikon Lainnya = bintang Langit', () => {
  const u = src('src/js/lembar-ui.js'), ui = src('src/js/ui.js'), css = src('src/css/styles.css');
  assert.ok(u.includes("item('salin', 'Salin & Tempel'")); // Rev 172: empat item digabung jadi satu dialog Salin & Tempel
  assert.match(u, /more: PATH\.star/); assert.ok(!u.includes("more: 'M5 12h.01M12 12h.01M19 12h.01'"));
  assert.match(ui, /star: 'M12 2\.5c\.7 5\.4/); assert.match(u, /fb\('fb-m', FB\.more, 'Lainnya'\)/);
  assert.match(css, /Rev 171[\s\S]*\.lz-fb\.fb-m svg\{[^}]*fill:var\(--ac\)/);
  assert.ok(!/from '\.\/rumus\.js'.*copyCell/.test(src('src/js/lembar-alat.js')), 'lembar-alat tidak boleh mengimpor mesin rumus langsung');
});
test('Rev 171: versi 0.3.121, SCHEMA 18, native/dependensi tidak berubah', () => {
  const pk = JSON.parse(src('package.json')); assert.ok(/^0\.3\.\d+$/.test(pk.version)); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v' + pk.version));
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/); assert.ok(pk.scripts.test.includes('tests/rev171.test.mjs'));
});
