// Rev 305 / T6: kelompok templat "Centang" (kotak centang dicampur rumus): nilai kunci dihitung mesin rumus sungguhan; mengetuk kotak mengubah hasil rumus.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { nextBoxValue } from '../src/js/lembar-kotak.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN);
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 15, 12, 0, 0).getTime();
Date.now = () => NOW; // Rev 312: jam dibekukan agar TODAY() di rumus templat sama dengan tanggal contoh (dulu memakai jam asli, jadi hasil Telat/Denda bergeser tiap hari)
const IDS = ['centang-tugas', 'centang-belanja', 'centang-hadir', 'centang-tagihan', 'centang-acara'];
const mk = (id) => T.makeFromTemplate(id, { now: NOW });
const first = (id) => { const tab = mk(id).sheet.tabs[0]; return { tab, d: makeDisplay(tab) }; };
const tap = (tab, i, j) => { const raw = (tab.rows[i].cells[tab.cols[j].id] || {}).v; L.setCell(tab, tab.rows[i].id, tab.cols[j].id, { v: nextBoxValue(raw) }); return makeDisplay(tab); };
test('Rev 305: lima templat Centang ada, nama <= 30, keterangan, Panduan terakhir, punya aturan kotak centang, failed 0, muat batas, tanpa galat rumus, bulat-balik', () => {
  const ids = T.templateList().map((t) => t.id); for (const id of IDS) assert.ok(ids.includes(id), id); assert.equal(new Set(ids).size, ids.length);
  for (const id of IDS) {
    const t = T.templateList().find((x) => x.id === id); assert.ok(t.name.startsWith('Centang · ') && t.name.length <= 30 && t.desc.length >= 20 && t.desc.length <= 100, id);
    const r = mk(id); assert.ok(r, id); assert.equal(r.failed, 0, id); assert.ok(L.fitsLimit(r.sheet)); const tabs = r.sheet.tabs;
    assert.equal(tabs[tabs.length - 1].name, 'Panduan', id); assert.ok(tabs.length <= 5); assert.ok(tabs[0].checks.some((c) => c.k === 'box'), id);
    for (const tab of tabs) { const d = makeDisplay(tab); for (let i = 0; i < tab.rows.length; i++) for (let j = 0; j < tab.cols.length; j++) assert.doesNotMatch(String(d.text(i, j)), /^#/, id + ' ' + L.cellAddr(j, i)); }
    assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(r.sheet)))), JSON.stringify(r.sheet), id);
  }
});
test('Rev 305: Daftar tugas = hasil kunci benar; mengetuk kotak mengubah Status, Kemajuan, dan Biaya', () => {
  const { tab, d } = first('centang-tugas');
  assert.deepEqual(Array.from({ length: 7 }, (_, i) => d.raw(i + 1, 4)), ['Selesai', 'Selesai', 'Terlambat', 'Berjalan', 'Selesai', 'Berjalan', 'Berjalan']);
  assert.deepEqual(Array.from({ length: 7 }, (_, i) => d.raw(i + 1, 7)), [7, 3, 4, 3 / 7, 650000, 225000, 1]);
  const d2 = tap(tab, 3, 0); assert.equal(d2.raw(3, 4), 'Selesai'); assert.equal(d2.raw(2, 7), 4); assert.equal(d2.raw(5, 7), 800000); assert.equal(d2.raw(7, 7), 0);
  const d3 = tap(tab, 3, 0); assert.equal(d3.raw(3, 4), 'Terlambat'); assert.equal(d3.raw(2, 7), 3);
});
test('Rev 305: Daftar belanja = hasil kunci benar; ketuk kotak menggeser Sudah dibeli; melebihi anggaran berubah status', () => {
  const { tab, d } = first('centang-belanja');
  assert.deepEqual(Array.from({ length: 7 }, (_, i) => d.raw(i + 1, 7)), [300000, 251000, 128000, 123000, 49000, '3 dari 7', 'Aman']);
  const d2 = tap(tab, 3, 0); assert.equal(d2.raw(3, 7), 184000); assert.equal(d2.raw(6, 7), '4 dari 7');
  L.setCell(tab, tab.rows[1].id, tab.cols[7].id, { v: 200000 }); assert.equal(makeDisplay(tab).raw(7, 7), 'Melebihi');
});
test('Rev 305: Hadir dan upah = hasil kunci benar; baris kosong tidak galat; centang hari baru menaikkan total', () => {
  const { tab, d } = first('centang-hadir');
  assert.deepEqual(Array.from({ length: 6 }, (_, i) => d.raw(i + 1, 6)), [5, 4, 3, 4, 4, 2]); assert.deepEqual(Array.from({ length: 6 }, (_, i) => d.raw(i + 1, 9)), ['Baik', 'Baik', 'Cukup', 'Baik', 'Baik', 'Kurang']);
  assert.deepEqual([1, 2, 3, 4, 5, 6, 8].map((j) => d.raw(12, j)), [5, 5, 4, 4, 4, 22, 2640000]); assert.equal(d.raw(7, 6), ''); assert.equal(d.raw(12, 7), 22 / 30);
  const d2 = tap(tab, 6, 3); assert.equal(d2.raw(6, 6), 3); assert.equal(d2.raw(12, 3), 5); assert.equal(d2.raw(12, 8), 2760000);
});
test('Rev 305: Tagihan dan denda = hasil kunci benar (tanggal contoh relatif ke NOW); melunasi mengosongkan kewajiban', () => {
  const { tab, d } = first('centang-tagihan');
  assert.deepEqual(Array.from({ length: 7 }, (_, i) => d.raw(i + 1, 9)), [0.02, 6, 2, 4, 800000, 4122400, 52400]);
  assert.deepEqual([3, 4].map((i) => d.raw(i, 4)), [7, 2]); assert.deepEqual([3, 4].map((i) => d.raw(i, 5)), [2400, 50000]);
  const d2 = tap(tab, 4, 0); assert.equal(d2.raw(4, 6), 0); assert.equal(d2.raw(6, 9), 1572400); assert.equal(d2.raw(7, 9), 2400);
});
test('Rev 305: Persiapan acara = kemajuan berbobot benar; COUNTIFS dua syarat; status berganti', () => {
  const { tab, d } = first('centang-acara');
  assert.deepEqual(Array.from({ length: 7 }, (_, i) => d.raw(i + 1, 7)), [100, 35, 0.35, '3 dari 7', 'Baru mulai', 1, 1]);
  const d2 = tap(tab, 5, 0); assert.equal(d2.raw(3, 7), 0.55); assert.equal(d2.raw(5, 7), 'Separuh jalan');
  for (const i of [4, 6, 7]) tap(tab, i, 0); const d3 = makeDisplay(tab); assert.equal(d3.raw(3, 7), 1); assert.equal(d3.raw(5, 7), 'SIAP');
});
test('Rev 305: modul data murni; hanya fungsi yang ada; urutan templat (Centang sebelum templat lama); mesin dan settings tidak menyebut berkas data', () => {
  const s = src('src/js/templat-centang.js'); assert.doesNotMatch(s, /import |localStorage|document\.|window\.|eval\(|new Function/);
  const ada = new Set([...src('src/js/rumus.js').matchAll(/^\s{2}([A-Z][A-Z0-9]+): \{ min:/gm)].map((m) => m[1]));
  const used = new Set([...s.matchAll(/'(=[^']*)'/g)].flatMap((m) => [...m[1].matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1]))); assert.ok(used.size >= 5); for (const f of used) assert.ok(ada.has(f), f);
  const ids = T.templateList().map((t) => t.id); assert.equal(ids.length, 35); assert.deepEqual(ids.slice(20, 25), IDS); assert.equal(ids[25], 'anggaran');
  for (const f of ['settings', 'lembar', 'lembar-ui', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /templat-centang/, f);
});
