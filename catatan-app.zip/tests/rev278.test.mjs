// Rev 278 / W3 (paket Peringatan + Pelacakan Error): riwayat error per tab (tab.errlog), SCHEMA 22. Tes AI saja (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as S from '../src/js/storage.js';
import { invalidCells, cleanErrLog, MAX_ERRLOG } from '../src/js/lembar-validasi.js';
import { syncErrLog } from '../src/js/lembar-riwayat.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { staticGraph } from '../scripts/preload.mjs';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet({ name: 'T' }), t = sh.tabs[0]; L.addRows(t, 10); L.setChecks(t, [{ k: 'list', c: t.cols[0].id, items: ['Ya', 'Tidak'] }]); return { sh, t }; };
const set = (t, i, j, v) => L.setCell(t, t.rows[i].id, t.cols[j].id, { v });
const run = (t, now) => { const dp = makeDisplay(t), iv = invalidCells(t, dp.text, dp.raw); return syncErrLog(t, iv, dp.text, now); };

test('sel salah dicatat sebagai entri open (ID baris/kolom, isi, aturan, waktu); idempoten; sel sah tidak dicatat', () => {
  const { t } = mk(); set(t, 2, 0, 'Eeer'); set(t, 3, 0, 'Ya');
  assert.equal(run(t, 1000), true); assert.equal(t.errlog.length, 1);
  const e = t.errlog[0]; assert.equal(e.r, t.rows[2].id); assert.equal(e.c, t.cols[0].id); assert.equal(e.v, 'Eeer'); assert.equal(e.at, 1000); assert.equal(e.st, 'open'); assert.equal(e.rule.id, t.checks[0].id); assert.match(e.rule.t, /Ya/); assert.equal('fixedAt' in e, false);
  assert.equal(run(t, 2000), false, 'panggilan kedua tanpa perubahan = false'); assert.equal(t.errlog.length, 1); assert.equal(t.errlog[0].at, 1000);
});
test('isi masih salah tetapi berubah = entri open diperbarui di tempat (bukan entri baru)', () => {
  const { t } = mk(); set(t, 0, 0, 'x'); run(t, 10); set(t, 0, 0, 'xyz'); assert.equal(run(t, 20), true);
  assert.equal(t.errlog.length, 1); assert.equal(t.errlog[0].v, 'xyz'); assert.equal(t.errlog[0].at, 10); assert.equal(t.errlog[0].st, 'open');
});
test('dibetulkan = fixed + fixedAt (tetap di riwayat); salah lagi = entri open BARU; satu sel maks. satu open', () => {
  const { t } = mk(); set(t, 0, 0, 'x'); run(t, 10); set(t, 0, 0, 'Ya'); assert.equal(run(t, 20), true);
  assert.equal(t.errlog.length, 1); assert.equal(t.errlog[0].st, 'fixed'); assert.equal(t.errlog[0].fixedAt, 20);
  assert.equal(run(t, 30), false); set(t, 0, 0, 'q'); assert.equal(run(t, 40), true);
  assert.equal(t.errlog.length, 2); assert.deepEqual(t.errlog.map((e) => e.st), ['fixed', 'open']); assert.equal(t.errlog[1].at, 40);
  assert.equal(new Set(t.errlog.map((e) => e.id)).size, 2);
});
test('aturan dihapus atau baris dihapus = entri open jadi fixed; tanpa entri sama sekali = tidak ada properti errlog', () => {
  const a = mk().t; assert.equal(run(a, 1), false); assert.equal('errlog' in a, false);
  const { t } = mk(); set(t, 1, 0, 'x'); set(t, 2, 0, 'y'); run(t, 10); assert.equal(t.errlog.length, 2);
  L.deleteRow(t, t.rows[2].id); assert.equal(run(t, 20), true); assert.deepEqual(t.errlog.map((e) => e.st), ['open', 'fixed']);
  L.setChecks(t, []); assert.equal(run(t, 30), true); assert.deepEqual(t.errlog.map((e) => e.st), ['fixed', 'fixed']); assert.equal(t.errlog[0].fixedAt, 30);
});
test('batas 200: yang fixed tertua dibuang dulu; semua open penuh = entri baru dilewati dan stabil (tidak berubah-ubah)', () => {
  const sh = L.newSheet({ name: 'B' }), t = sh.tabs[0]; L.addRows(t, 300); L.setChecks(t, [{ k: 'list', c: t.cols[0].id, items: ['Ya'] }]);
  for (let i = 0; i < 260; i++) set(t, i, 0, 'x');
  assert.equal(run(t, 5), true); assert.equal(t.errlog.length, MAX_ERRLOG); assert.equal(run(t, 6), false, 'penuh dan stabil'); assert.equal(t.errlog.length, MAX_ERRLOG);
  set(t, 0, 0, 'Ya'); assert.equal(run(t, 7), true); assert.equal(t.errlog.length, MAX_ERRLOG, 'yang baru beres (fixed) langsung digantikan sel salah yang belum tercatat');
  assert.equal(t.errlog.filter((e) => e.st === 'fixed').length, 0); assert.ok(!t.errlog.some((e) => e.r === t.rows[0].id), 'entri baris 0 sudah dibuang'); assert.ok(t.errlog.some((e) => e.r === t.rows[200].id && e.st === 'open'));
  assert.equal(run(t, 8), false, 'tetap stabil');
  set(t, 1, 0, 'Ya'); run(t, 9); assert.ok(t.errlog.every((e) => e.st === 'open') && t.errlog.length === MAX_ERRLOG);
});
test('cleanErrLog: entri rusak dibuang, teks dipotong, ID ganda diperbaiki, fixed butuh fixedAt, maks. 200 terbaru', () => {
  const { t } = mk(); const ok = { id: 'e1abcd', r: t.rows[0].id, c: t.cols[0].id, v: 'z'.repeat(99), rule: { id: 'vabcd1', t: 'q'.repeat(99) }, at: 5, st: 'fixed', fixedAt: 9 };
  const out = cleanErrLog([ok, { ...ok }, { ...ok, id: 'e2abcd', st: 'fixed', fixedAt: 'x' }, { ...ok, r: 'rNOPE' }, { ...ok, c: 'cNOPE' }, { ...ok, at: 'a' }, { ...ok, rule: null }, { ...ok, rule: { id: '!!' } }, null, 5], t.cols, t.rows);
  assert.equal(out.length, 3); assert.equal(out[0].v.length, 40); assert.equal(out[0].rule.t.length, 60); assert.equal(out[0].st, 'fixed'); assert.equal(out[0].fixedAt, 9);
  assert.equal(new Set(out.map((e) => e.id)).size, 3); assert.equal(out[2].st, 'open'); assert.equal('fixedAt' in out[2], false);
  assert.deepEqual(cleanErrLog('x', t.cols, t.rows), []); assert.deepEqual(cleanErrLog(undefined, t.cols, t.rows), []);
  const many = Array.from({ length: 250 }, (_, i) => ({ ...ok, id: 'e' + i + 'aaaa', at: i, st: 'open' })); const o2 = cleanErrLog(many, t.cols, t.rows); assert.equal(o2.length, 200); assert.equal(o2[199].at, 249);
});
test('cleanTab/cleanSheet menyimpan errlog (cadangan, pulihkan) dan membuang entri dengan baris hilang; tanpa errlog tetap tanpa properti', () => {
  const { sh, t } = mk(); set(t, 1, 0, 'x'); run(t, 10);
  const back = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.deepEqual(back.tabs[0].errlog, t.errlog);
  const raw = JSON.parse(JSON.stringify(sh)); raw.tabs[0].rows.splice(1, 1); assert.equal('errlog' in L.cleanSheet(raw).tabs[0], false);
  const plain = L.newSheet({ name: 'P' }); assert.equal('errlog' in L.cleanSheet(JSON.parse(JSON.stringify(plain))).tabs[0], false);
});
test('riwayat TIDAK dihitung ke batas ukuran lembar kerja (lembar hampir penuh tidak dibuang karena riwayat)', () => {
  const { sh, t } = mk(); const b0 = L.sheetBytes(sh); set(t, 1, 0, 'x'); run(t, 1); const withLog = JSON.stringify(sh).length; assert.ok(withLog > b0);
  const noLog = JSON.parse(JSON.stringify(sh)); delete noLog.tabs[0].errlog; assert.equal(L.sheetBytes(sh), L.sheetBytes(noLog));
});
test('SCHEMA 22: data v20 (tab tanpa errlog) tetap valid; data v21 dengan errlog lolos normalize; cadangan membawa errlog', () => {
  assert.equal(S.SCHEMA, 22); const { sh, t } = mk(); set(t, 1, 0, 'x'); run(t, 10);
  const d = S.normalize({ version: 20, habits: [], tasks: [], notes: [], priv: [], trash: [], sheets: { [sh.id]: JSON.parse(JSON.stringify(sh)) } }); assert.equal(d.version, 22); assert.equal(d.sheets[sh.id].tabs[0].errlog.length, 1);
  const old = L.newSheet({ name: 'Lama' }); const d2 = S.normalize({ version: 20, habits: [], tasks: [], notes: [], priv: [], trash: [], sheets: { [old.id]: old } }); assert.equal('errlog' in d2.sheets[old.id].tabs[0], false);
});
test('kabel: riwayat disamakan lewat onChange (isi, aturan, Urungkan), gagal = diam; modul murni + malas; tidak ikut ekspor', () => {
  const ui = src('src/js/lembar-ui.js');
  assert.match(ui, /import \{ syncErrLog(, MAX_ERRLOG)? \} from '\.\/lembar-riwayat\.js';/);
  assert.match(ui, /const emitUp = onChange; onChange = \(s\) => \{ try \{ const iv = getIV\(\)/); assert.match(ui, /if \(typeof emitUp === 'function'\) emitUp\(s\);/);
  assert.match(ui, /const ser = \(\) => JSON\.stringify\(\{ name: sheet\.name, tabs: sheet\.tabs \}\)/, 'Urungkan membawa tab (termasuk errlog)');
  const m = src('src/js/lembar-riwayat.js'); assert.doesNotMatch(m, /document\.|window\.|localStorage|sessionStorage|\beval\s*\(|new Function/); assert.equal((m.match(/^import /gm) || []).length, 1);
  assert.ok(!staticGraph('js/main.js').includes('js/lembar-riwayat.js'), 'dimuat malas, bukan jalur buka');
  for (const f of ['export.js', 'lembar-alat.js', 'lembar-pulau.js']) assert.doesNotMatch(src('src/js/' + f), /errlog/, f);
  assert.doesNotMatch(src('src/js/lembar-validasi.js'), /^import /m);
});
test('versi 0.3.121, SCHEMA 22, tes terdaftar, tanpa dependensi baru', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121')); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.match(pk.scripts.test, /node tests\/rev278\.test\.mjs/); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
