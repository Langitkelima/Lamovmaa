// Rev 103 / U5c: lembar "Ingatkan saya" + lonceng di baris kotak centang. Tes Node: fungsi murni + kontrak sumber + alur data lewat jembatan palsu.
// Perilaku DOM (ketuk lonceng, lembar, keyboard) dicek terpisah di Chromium/HP (bukan bagian npm test).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as I from '../src/js/ingatkan.js';
import * as C from '../src/js/cb-alarm.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const L = (y, m, d, h = 0, mi = 0) => new Date(y, m - 1, d, h, mi, 0, 0).getTime();
const NOW = L(2026, 11, 8, 10);
const row = (cid, text, done = false) => `<div class="todo"${cid ? ` data-cid="${cid}"` : ''}><input type="checkbox"${done ? ' checked=""' : ''}>${text}</div>`;
function fakeApi() {
  const calls = { sched: [], cancel: [] };
  globalThis.AndroidAPI = { scheduleNotification: (id, t, m, d, r) => { calls.sched.push({ id, t, m, d, r }); return 'exact_alarm'; }, cancelScheduledNotification: (id) => { calls.cancel.push(id); } };
  return calls;
}
const noApi = () => { delete globalThis.AndroidAPI; delete globalThis.KelimaaNative; };

test('Rev 103: formatRemindAt memakai nama hari/bulan Indonesia, jam bertitik, tahun hanya bila beda', () => {
  assert.equal(I.formatRemindAt(L(2026, 11, 9, 9), NOW), 'Sen, 9 Nov 09.00');
  assert.equal(I.formatRemindAt(L(2027, 1, 3, 14, 5), NOW), 'Min, 3 Jan 2027 14.05');
  assert.equal(I.formatRemindAt(NaN, NOW), '');
});
test('Rev 103: describeRule: sekali, berulang (menampilkan kemunculan BERIKUTNYA), aturan rusak = kosong', () => {
  assert.equal(I.describeRule({ at: L(2026, 11, 9, 9), repeat: 'none' }, NOW), 'Sen, 9 Nov 09.00');
  assert.equal(I.describeRule({ at: L(2026, 11, 9, 9), repeat: 'daily' }, NOW), 'Sen, 9 Nov 09.00 · Setiap hari');
  assert.equal(I.describeRule({ at: L(2026, 11, 1, 9), repeat: 'weekly' }, NOW), 'Min, 15 Nov 09.00 · Setiap minggu'); // 1 Nov Min -> 8 Nov 09.00 sudah lewat -> 15 Nov
  assert.equal(I.describeRule({ at: L(2026, 10, 31, 9), repeat: 'monthly' }, NOW), 'Sen, 30 Nov 09.00 · Setiap bulan'); // Nov tidak punya tanggal 31 -> dijepit ke 30 Nov
  assert.equal(I.describeRule(null, NOW), '');
});
test('Rev 103: ruleIsLive dan bellState (lonceng baris)', () => {
  const later = { at: L(2026, 11, 9, 9), repeat: 'none' }, past = { at: L(2026, 11, 7, 9), repeat: 'none' }, daily = { at: L(2026, 11, 1, 9), repeat: 'daily' };
  assert.equal(I.ruleIsLive(later, NOW), true); assert.equal(I.ruleIsLive(past, NOW), false); assert.equal(I.ruleIsLive(daily, NOW), true);
  assert.equal(I.ruleIsLive({ at: NOW + 30000, repeat: 'none' }, NOW), false, 'kurang dari 1 menit = sudah lewat');
  assert.equal(I.bellState(later, false, NOW), 'on');
  assert.equal(I.bellState(null, false, NOW), 'idle');
  assert.equal(I.bellState(past, false, NOW), 'idle', 'pengingat sekali yang sudah lewat = lonceng biasa');
  assert.equal(I.bellState(null, true, NOW), 'off', 'baris dicentang tanpa pengingat: lonceng hilang');
  assert.equal(I.bellState(later, true, NOW), 'off', 'dicentang + sekali = alarm dihentikan, lonceng hilang');
  assert.equal(I.bellState(daily, true, NOW), 'on', 'berulang tetap hidup walau dicentang');
});
test('Rev 103: checkChoice menolak waktu kosong/lewat/hampir lewat dan pengulangan asing', () => {
  assert.equal(I.checkChoice(0, 'none', NOW).ok, false);
  assert.equal(I.checkChoice(NOW - 1000, 'none', NOW).ok, false);
  assert.equal(I.checkChoice(NOW + 30000, 'daily', NOW).ok, false);
  assert.equal(I.checkChoice(L(2026, 11, 9, 9), 'yearly', NOW).ok, false);
  for (const r of I.REPEATS) assert.equal(I.checkChoice(L(2026, 11, 9, 9), r, NOW).ok, true);
});
test('Rev 103: setCbRule / clearCbRule menulis note.cbRem; batas 30; cid tidak sah ditolak; kosong dihapus', () => {
  const n = { id: 'n1' };
  assert.equal(I.setCbRule(n, 'ab12c', { at: L(2026, 11, 9, 9), repeat: 'daily' }), true);
  assert.deepEqual(n.cbRem, { ab12c: { at: L(2026, 11, 9, 9), repeat: 'daily', sticky: false } });
  assert.equal(I.setCbRule(n, 'BAD!', { at: 5 }), false); assert.equal(I.setCbRule(n, 'zz99z', { at: 'x' }), false);
  assert.equal(I.clearCbRule(n, 'tidakada'), false);
  assert.equal(I.clearCbRule(n, 'ab12c'), true); assert.equal('cbRem' in n, false);
  const big = { id: 'n2' };
  for (let i = 0; i < 30; i++) assert.equal(I.setCbRule(big, 'c' + (1000 + i), { at: 5 }), true);
  assert.equal(I.setCbRule(big, 'extra1', { at: 5 }), false, 'cid ke-31 ditolak');
  assert.equal(I.setCbRule(big, 'c1000', { at: 9, repeat: 'weekly' }), true, 'mengubah yang sudah ada tetap boleh');
});
test('Rev 103: cancelRowAlarms membatalkan SEMUA kemungkinan ID satu baris (sekali/harian/mingguan + :m1..:m12) dan tidak menyentuh baris lain', () => {
  const calls = fakeApi();
  C.cancelRowAlarms({ id: 'n1' }, 'ab12c');
  assert.equal(calls.cancel.length, 13);
  assert.ok(calls.cancel.includes('cb:n1:ab12c') && calls.cancel.includes('cb:n1:ab12c:m1') && calls.cancel.includes('cb:n1:ab12c:m12'));
  assert.ok(calls.cancel.every((id) => id.startsWith('cb:n1:ab12c')));
  C.cancelRowAlarms(null, 'x'); C.cancelRowAlarms({ id: 'n1' }, '');
  assert.equal(calls.cancel.length, 13);
  noApi();
});
test('Rev 103: alur lonceng: pasang aturan -> jadwal; centang baris "Tidak" -> alarm dihentikan; hapus aturan -> alarm dibatalkan', () => {
  const calls = fakeApi();
  const n = { id: 'n1', title: 'Belanja', html: row('ab12c', 'Beli susu') + row('mn345', 'Bayar listrik') };
  I.setCbRule(n, 'ab12c', { at: L(2026, 11, 9, 9), repeat: 'none' });
  I.setCbRule(n, 'mn345', { at: L(2026, 11, 10, 8), repeat: 'weekly' });
  C.syncNoteAlarms(n, NOW);
  assert.deepEqual(calls.sched.map((c) => c.id).sort(), ['cb:n1:ab12c', 'cb:n1:mn345']);
  assert.equal(calls.sched.find((c) => c.id === 'cb:n1:ab12c').m, 'Beli susu');
  // centang baris ab12c (Tidak): rencana melewatinya, sinkron membatalkan lalu hanya memasang yang berulang
  calls.sched.length = 0; calls.cancel.length = 0;
  n.html = row('ab12c', 'Beli susu', true) + row('mn345', 'Bayar listrik');
  C.reconcileNoteAlarms(n, NOW);
  assert.deepEqual(calls.sched.map((c) => c.id), ['cb:n1:mn345']);
  assert.ok(calls.cancel.includes('cb:n1:ab12c'));
  // hapus aturan mn345: batalkan DULU, lalu hapus (save() hanya membatalkan ID dari aturan yang masih ada)
  calls.cancel.length = 0;
  C.cancelRowAlarms(n, 'mn345'); I.clearCbRule(n, 'mn345');
  assert.ok(calls.cancel.includes('cb:n1:mn345'));
  assert.deepEqual(Object.keys(n.cbRem), ['ab12c']);
  noApi();
});
test('Rev 103: mengubah Mingguan -> Tidak untuk cid yang sama tidak meninggalkan alarm yatim (sinkron membatalkan semua ID cid itu)', () => {
  const calls = fakeApi();
  const n = { id: 'n1', title: 't', html: row('ab12c', 'x') };
  I.setCbRule(n, 'ab12c', { at: L(2026, 11, 9, 9), repeat: 'monthly' }); C.syncNoteAlarms(n, NOW);
  assert.equal(calls.sched.length, 12);
  calls.cancel.length = 0; calls.sched.length = 0;
  I.setCbRule(n, 'ab12c', { at: L(2026, 11, 9, 9), repeat: 'none' }); C.syncNoteAlarms(n, NOW);
  assert.equal(calls.cancel.length, 13); assert.equal(calls.sched.length, 1);
  noApi();
});

test('Rev 103: kontrak sumber notes.js: lonceng, lembar, alur simpan/hapus, Privat tanpa lonceng', () => {
  const s = src('src/js/notes.js');
  assert.match(s, /const openRemindSheet = \(row(?:, presetAt)?\) =>/);
  assert.match(s, /h\('h3', \{\}, 'Ingatkan saya'\)/);
  assert.match(s, /'Pilih tanggal dan waktu'/);
  assert.match(s, /presetsFor\(now0\)/);
  assert.match(s, /REPEATS\.map\(\(r\) => h\('button'/);
  assert.match(s, /'Simpan pengingat'/); assert.match(s, /'Hapus pengingat'/);
  assert.match(s, /newCid\(\[\.\.\.cidsInHtml\(ed\.innerHTML\), \.\.\.Object\.keys\(n\.cbRem \|\| \{\}\)\]\)/, 'cid baru dibuat saat lonceng pertama disimpan');
  assert.match(s, /setCbRule\(n, cid,/); assert.match(s, /row\.setAttribute\('data-cid', cid\)/);
  assert.match(s, /clearTimeout\(tm\); save\(\);/, 'simpan langsung agar save() memicu reconcileNoteAlarms');
  const del = s.slice(s.indexOf('const doDelete = () =>'), s.indexOf('const bDel ='));
  assert.ok(del.indexOf('cancelRowAlarms(n, cid)') >= 0 && del.indexOf('cancelRowAlarms(n, cid)') < del.indexOf('clearCbRule(n, cid)'), 'batalkan alarm SEBELUM aturan dihapus');
  assert.match(s, /if \(isP\) o\.classList\.add\('nobell'\)/);
  assert.match(s, /if \(!isP\) \{\s*ed\.addEventListener\('pointerdown'/);
  assert.match(s, /BELL_W = 44/);
  assert.match(s, /stopBellObs/); assert.match(s, /querySelectorAll\('\.ov\.rm-ov'\)\.forEach\(\(x\) => x\.remove\(\)\)/);
});
test('Rev 103: lonceng tidak ikut tersimpan: data-rem TIDAK ada di daftar atribut sanitize; UI tidak memanggil jembatan native langsung', () => {
  const s = src('src/js/notes.js');
  assert.ok(!/k === 'data-rem'/.test(s), 'data-rem harus dibuang sanitize (atribut sementara)');
  assert.ok(!/scheduleNotification|cancelScheduledNotification/.test(s), 'semua alarm lewat cb-alarm.js');
  assert.ok(!/createElement\('button'\)[^;]*todo|\.todo[^;]*appendChild\(bell/.test(s), 'lonceng bukan elemen di dalam baris');
});
test('Rev 103: tombol Kembali HP menutup lembar: kelas dlgov + .dlgb dengan tombol Batal (line) PERTAMA', () => {
  const s = src('src/js/notes.js');
  assert.match(s, /class: 'ov dlgov rm-ov'/);
  assert.match(s, /h\('div', \{ class: 'dlgb rm-foot' \}, bCancel, bSave\)/);
  assert.match(s, /const bCancel = h\('button', \{ type: 'button', class: 'btn line'/);
  const ui = src('src/js/ui.js');
  assert.match(ui, /\.dlgb button\.line/);
});
test('Rev 103: CSS lonceng (pseudo-elemen, aktif hanya untuk baris belum dicentang atau ber-data-rem) + lembar', () => {
  const css = src('src/css/styles.css');
  assert.match(css, /\.ed2 \.todo:not\(:has\(input\[type="checkbox"\]:checked\)\)::after,\.ed2 \.todo\[data-rem\]::after(?:,\.ed2 li\[data-rem\]::after)?\{content:""/); // Rev 349 / R4: li ikut
  assert.match(css, /\.ed2 \.todo\[data-rem\]:not\(:has\(input\[type="checkbox"\]:checked\)\)::after,\.ed2 \.todo\[data-rem\]::after(?:,\.ed2 li\[data-rem\]::after)?\{border-color:transparent;background:url\(/, 'lonceng berpengingat (Rev 106: lencana gradasi aksen), juga menang atas aturan baris aktif');
  assert.match(css, /\.fs\.nobell \.ed2 \.todo::after(?:,\.fs\.nobell \.ed2 li::after)?\{content:none!important\}/);
  assert.match(css, /\.ov\.dlgov\.rm-ov\{align-items:flex-end\}/);
  assert.match(css, /\.rm-opt\[aria-checked="true"\]/);
  assert.match(css, /\.rm-seg\[aria-pressed="true"\]/);
  assert.match(css, /prefers-reduced-motion:reduce\)\{\.rm-sheet/);
});
test('Rev 103: native/dependensi/SCHEMA tidak berubah; versi 0.3.121; tes terdaftar', () => {
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('node tests/rev103.test.mjs'));
  const g = src('src/js/cb-alarm.js').replace(/\/\/.*$/gm, '');
  assert.ok(!/document\.|window\.|localStorage|Intl\./.test(g));
  const ing = src('src/js/ingatkan.js').replace(/\/\/.*$/gm, '');
  assert.ok(!/document\.|window\.|localStorage|Intl\.|toLocale/.test(ing), 'mesin tetap murni');
});
