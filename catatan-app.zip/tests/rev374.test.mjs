// Rev 374 / OJ5: tombol MANUAL "Coba jalur lain" di dialog Pindai. Tes Node: bagian murni + kabel sumber. BUKAN bukti dari HP atau Sakelar/Relay nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import * as O from '../src/js/ai/ocr.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8'), SRC = rd('src/js/ai/ocr-ui.js');
test('jalurBerikut: gemini -> sakelar -> relay -> gemini; bawaan/ngawur dianggap Gemini', () => {
  assert.equal(O.jalurBerikut('gemini'), 'sakelar'); assert.equal(O.jalurBerikut('sakelar'), 'relay'); assert.equal(O.jalurBerikut('relay'), 'gemini');
  for (const v of ['', undefined, null, 'xyz', 5]) assert.equal(O.jalurBerikut(v), 'sakelar');
  assert.equal(O.jalurBerikut(' RELAY '), 'gemini');
});
test('bisaCobaLain: gagal di jalan = ya; Worker lama, passcode salah, foto gagal disiapkan = tidak', () => {
  assert.equal(O.bisaCobaLain({ ok: false, msg: 'x' }), true);
  assert.equal(O.bisaCobaLain({ ok: false, msg: 'x', workerLama: true }), false);
  assert.equal(O.bisaCobaLain({ ok: false, msg: 'x', passcode: true }), false);
  assert.equal(O.bisaCobaLain({ ok: false, msg: 'x', siapkan: true }), false);
  for (const v of [null, undefined, 3, 'a']) assert.equal(O.bisaCobaLain(v), false);
});
test('bisaCobaLain: sukses cepat = tidak; foto tanpa teks = ya; lambat (>= 20 dtk) = ya', () => {
  assert.equal(O.OCR_LAMBAT_MS, 20000);
  assert.equal(O.bisaCobaLain({ ok: true, text: 'a', ms: 3000 }), false);
  assert.equal(O.bisaCobaLain({ ok: true, text: 'a' }), false);
  assert.equal(O.bisaCobaLain({ ok: true, text: 'a', ms: 19999 }), false);
  assert.equal(O.bisaCobaLain({ ok: true, text: 'a', ms: 20000 }), true);
  assert.equal(O.bisaCobaLain({ ok: true, text: '', empty: true, ms: 1000 }), true);
});
test('uraiJawaban memberi tanda: 401 = passcode, Worker lama = workerLama, galat lain tanpa tanda', () => {
  const a = O.uraiJawaban(401, JSON.stringify({ ok: false, error: 'Passcode salah' })); assert.equal(a.ok, false); assert.equal(a.passcode, true); assert.match(a.msg, /Setelan > Kelimaa AI/);
  const b = O.uraiJawaban(400, JSON.stringify({ ok: false, error: 'Aksi tidak dikenal' })); assert.equal(b.workerLama, true); assert.ok(!b.passcode);
  const c = O.uraiJawaban(502, JSON.stringify({ ok: false, error: 'Jawaban kosong' })); assert.ok(!c.passcode && !c.workerLama && !c.siapkan); assert.equal(O.bisaCobaLain(c), true);
});
test('bacaFoto: foto gagal disiapkan -> tanda siapkan, TANPA jaringan dan tanpa tawaran jalur lain', async () => {
  let net = 0; const r = await O.bacaFoto({ url: 'https://a.workers.dev', key: 'abcdefgh' }, {}, { perkecil: async () => { throw new Error('Foto tidak bisa dibuka.'); }, http: async () => { net++; return { status: 200, text: '{}' }; } });
  assert.equal(r.ok, false); assert.equal(r.siapkan, true); assert.equal(net, 0); assert.equal(O.bisaCobaLain(r), false);
});
test('kabel: tombol tersembunyi awal, hilang saat foto baru dipilih / membaca, ditawarkan lewat tawarLain, pindah MANUAL lewat simpanJ lalu gerbang persetujuan yang sama', () => {
  assert.match(SRC, /const bLain = h\('button', \{ type: 'button', class: 'btn line2', hidden: 'hidden' \}, 'Coba jalur lain'\);/);
  assert.equal((SRC.match(/bCopy\.hidden = true; bLain\.hidden = true;/g) || []).length, 2, 'foto baru + mulai membaca');
  assert.match(SRC, /const tawarLain = \(r\) => \{ const ya = !!O && O\.bisaCobaLain\(r\); bLain\.hidden = !ya;/);
  assert.match(SRC, /'Coba jalur lain: ' \+ O\.JALUR_NAMA\[O\.jalurBerikut\(jal\.provider\)\]/);
  assert.match(SRC, /bLain\.onclick = \(\) => \{ if \(busy \|\| !file \|\| !O\) return; const n = O\.jalurBerikut\(jal\.provider\); if \(!simpanJ\(\{ provider: n, model: '' \}\)\) return;/);
  assert.match(SRC, /bRead\.onclick\(\); \};/); // lewat gerbang persetujuan, bukan memanggil baca() langsung
  assert.equal((SRC.match(/tawarLain\(r\)/g) || []).length, 3, 'gagal, kosong, sukses');
  assert.match(SRC, /bRead, bLain, ta,/);
});
test('kabel: TIDAK ada pindah jalur otomatis dan bacaFoto tetap dipanggil satu kali; tanpa penyimpanan baru; ocr.js tetap malas; Worker tak berubah', () => {
  assert.equal((SRC.match(/bacaFoto\(/g) || []).length, 1); assert.equal((SRC.match(/setItem\(/g) || []).length, 2);
  assert.match(SRC, /await import\('\.\/ocr\.js'\)/); assert.doesNotMatch(SRC, /^import .*ocr\.js/m);
  assert.doesNotMatch(SRC, /console\.|sessionStorage|innerHTML/);
  assert.ok(!rd('backend/cloudflare/worker.mjs').includes('Rev 374'));
});
