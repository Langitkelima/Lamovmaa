// Tes Rev 19 (bagian 2): bagikan satu catatan (teks / PDF / JPG). Bagian murni di src/js/export.js; menggambar ke canvas dicek di Chromium (lihat RIWAYAT).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as E from '../src/js/export.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const measure = (s, st) => s.length * st.size * 0.5 * (st.b ? 1.1 : 1); // pengukur tiruan: lebar sebanding jumlah huruf
const O = { width: 600, padX: 40, size: 30, titleSize: 44, measure };
const kinds = (bl) => bl.map((b) => b.kind + (b.blank ? ':kosong' : ''));
const txt = (b) => b.runs.map((r) => r.t).join('');

await t('decodeEntities dan cssColor', () => {
  assert.equal(E.decodeEntities('a &amp; b &lt;c&gt; &quot;d&quot; &#39;e&#39; &nbsp;f &#x1F600; &bukan;'), 'a & b <c> "d" \'e\' \u00a0f \u{1F600} &bukan;');
  assert.equal(E.cssColor('#ABC'), '#aabbcc'); assert.equal(E.cssColor('#D63A55'), '#d63a55'); assert.equal(E.cssColor('rgb(63, 143, 107);'), '#3f8f6b');
  assert.equal(E.cssColor('rgba(255,0,0,.5)'), '#ff0000'); assert.equal(E.cssColor('red'), ''); assert.equal(E.cssColor(''), ''); assert.equal(E.cssColor(null), '');
});
await t('parseNoteHtml: tebal, miring, coret, garis bawah, warna (font dan span style), entitas', () => {
  const b = E.parseNoteHtml('<b>T</b><strong>2</strong> <i>M</i><em>3</em> <s>C</s><strike>4</strike> <u>U</u> <font color="#D63A55">R</font> <span style="color: rgb(63, 143, 107);">H</span> a&amp;b');
  assert.equal(b.length, 1); const r = b[0].runs;
  const by = (x) => r.find((q) => q.t === x);
  assert.ok(by('T').b && by('2').b && by('M').i && by('3').i && by('C').s && by('4').s && by('U').u);
  assert.equal(by('R').color, '#d63a55'); assert.equal(by('H').color, '#3f8f6b');
  assert.equal(txt(b[0]).replace(/\s+/g, ' ').endsWith('a&b'), true);
  const nest = E.parseNoteHtml('<b>a<i>b</i>c</b>d')[0].runs;
  assert.deepEqual(nest.map((q) => [q.t, q.b, q.i]), [['a', true, false], ['b', true, true], ['c', true, false], ['d', false, false]]);
});
await t('parseNoteHtml: blok baris, baris kosong, centang, poin, nomor, bersarang', () => {
  const bl = E.parseNoteHtml('<div>Satu</div><div><br></div><div class="todo"><input type="checkbox" checked="">&nbsp;Beli</div><div class="todo"><input type="checkbox">&nbsp;Cuci</div><ul><li>a</li><li>b<ul><li>b1</li></ul></li></ul><ol><li>x</li><li>y</li></ol><div>Akhir</div>');
  assert.deepEqual(kinds(bl), ['p', 'p:kosong', 'todo', 'todo', 'ul', 'ul', 'ul', 'ol', 'ol', 'p']);
  assert.equal(bl[2].checked, true); assert.equal(bl[3].checked, false); assert.equal(txt(bl[2]), 'Beli'); assert.equal(txt(bl[3]), 'Cuci');
  assert.deepEqual(bl.filter((x) => x.kind === 'ul').map((x) => x.depth), [0, 0, 1]);
  assert.deepEqual(bl.filter((x) => x.kind === 'ol').map((x) => x.num), [1, 2]);
});
await t('Rev 65: kutipan dipertahankan pada TXT/Markdown dan garis kutipan pada tata letak PDF', () => {
  const html = '<blockquote><div>Kalimat kutipan</div></blockquote><div>Paragraf biasa</div>';
  const bl = E.parseNoteHtml(html);
  assert.equal(bl[0].kind, 'quote'); assert.equal(txt(bl[0]), 'Kalimat kutipan');
  assert.equal(E.blocksToText('', bl), '> Kalimat kutipan\nParagraf biasa');
  assert.equal(E.blocksToMarkdown('', bl), '> Kalimat kutipan\n\nParagraf biasa\n');
  const lines = E.layoutDoc({ title: '', blocks: bl }, O).filter((x) => x.kind === 'text');
  assert.equal(lines[0].mark.type, 'quote'); assert.equal(lines[1].mark, undefined);
});
await t('parseNoteHtml: teks lepas tanpa div, <br> di tengah = baris baru dalam blok, <br> di ujung dibuang, kosong dan rusak tidak melempar', () => {
  const a = E.parseNoteHtml('Awal<div>Kedua<br>masih kedua</div>');
  assert.equal(a.length, 2); assert.equal(txt(a[0]), 'Awal'); assert.equal(txt(a[1]), 'Kedua\nmasih kedua');
  assert.equal(txt(E.parseNoteHtml('<div>x<br></div>')[0]), 'x');
  assert.deepEqual(E.parseNoteHtml(''), []); assert.deepEqual(E.parseNoteHtml(null), []); assert.deepEqual(E.parseNoteHtml('<div><br></div><div><br></div>'), [], 'kosong di ujung dibuang');
  assert.doesNotThrow(() => E.parseNoteHtml('<div><b>tak ditutup <i>x</div></b></span><<>>&&<input'));
  const tag = E.parseNoteHtml('<div>&lt;script&gt;alert(1)&lt;/script&gt;</div>'); assert.equal(txt(tag[0]), '<script>alert(1)</script>', 'teks, bukan tag');
});
await t('blocksToText: judul + isi, penanda poin/centang/nomor, indentasi, tanpa baris kosong berlebihan', () => {
  const bl = E.parseNoteHtml('<div>Isi</div><div><br></div><div><br></div><div><br></div><div class="todo"><input type="checkbox" checked="">&nbsp;Beli</div><div class="todo"><input type="checkbox">&nbsp;Cuci</div><ul><li>a<ul><li>b</li></ul></li></ul><ol><li>x</li></ol>');
  assert.equal(E.blocksToText('Judul', bl), 'Judul\n\nIsi\n\n\u2611 Beli\n\u2610 Cuci\n\u2022 a\n  \u2022 b\n1. x');
  assert.equal(E.blocksToText('', bl).startsWith('Isi'), true); assert.equal(E.blocksToText('Saja', []), 'Saja'); assert.equal(E.blocksToText('', []), '');
});
await t('shareFileName: aman (huruf kecil, tanpa aksen/simbol), cadangan "catatan", nomor bagian', () => {
  const d = new Date(2026, 9, 3);
  assert.equal(E.shareFileName('Rapat Mingguan: Tim Ōsaka!!', 'pdf', d), 'rapat-mingguan-tim-osaka-20261003.pdf');
  assert.equal(E.shareFileName('', 'jpg', d), 'catatan-20261003.jpg'); assert.equal(E.shareFileName('😀 ../../etc', 'jpg', d, 2), 'etc-20261003-2.jpg');
  assert.ok(E.shareFileName('a'.repeat(100), 'pdf', d).length <= 30 + 1 + 8 + 4); assert.ok(!/[\/\\ :]/.test(E.shareFileName('x/y \\ z:', 'pdf', d)));
});
await t('layoutDoc: judul kapital dibungkus, garis pemisah, mark centang/poin/nomor, baris tidak melebihi lebar, kata panjang dipatahkan', () => {
  const bl = E.parseNoteHtml('<div>' + 'kata '.repeat(40) + '</div><div class="todo"><input type="checkbox" checked="">&nbsp;Beli</div><ul><li>poin</li></ul><ol><li>no</li></ol><div>' + 'x'.repeat(200) + '</div>');
  const ls = E.layoutDoc({ title: 'judul yang cukup panjang sampai harus turun ke baris berikutnya ya', blocks: bl }, O);
  const text = ls.filter((l) => l.kind === 'text');
  assert.ok(text[0].segs[0].t === text[0].segs[0].t.toUpperCase() && text[0].size === 44, 'judul kapital + ukuran judul');
  assert.ok(ls.some((l) => l.kind === 'rule'));
  for (const l of text) for (const s of l.segs) assert.ok(s.x + measure(s.t, { size: s.size, b: s.b }) <= O.width - O.padX + 0.01 || s.x === l.x, 'tidak keluar kanan: ' + s.t.slice(0, 15));
  const marks = text.filter((l) => l.mark).map((l) => l.mark.type + (l.mark.checked ? '+' : '')); assert.deepEqual(marks, ['todo+', 'bullet', 'num']);
  assert.equal(text.find((l) => l.mark && l.mark.type === 'num').mark.label, '1.');
  const body = text.filter((l) => l.size === 30 && !l.mark); assert.ok(body.length >= 6, 'bungkus ke banyak baris: ' + body.length);
  assert.ok(!text.some((l) => l.segs.length && /^\s|\s$/.test(l.segs[0].t.slice(0, 1)) && l.segs[0].x === l.x), 'tanpa spasi di awal baris');
});
await t('layoutDoc: catatan kosong/tanpa judul tidak melempar; baris kosong di ujung dibuang; teks gaya ikut ke segmen', () => {
  assert.deepEqual(E.layoutDoc({ title: '', blocks: [] }, O), []);
  const ls = E.layoutDoc({ title: '', blocks: E.parseNoteHtml('<div><b>Tebal</b> <font color="#d63a55">merah</font></div><div><br></div>') }, O);
  assert.equal(ls.length, 1); const s = ls[0].segs;
  assert.ok(s[0].b && !s[0].i); assert.equal(s.find((x) => x.t === 'merah').color, '#d63a55');
});
await t('paginate: halaman terisi sesuai tinggi, baris tidak terpotong, kosong/jarak di puncak halaman dibuang, minimal 1 halaman', () => {
  const lines = Array.from({ length: 25 }, (_, i) => ({ kind: i % 5 === 4 ? 'gap' : 'text', lh: 40, size: 30, x: 0, segs: [] }));
  const pg = E.paginate(lines, { pageH: 500, padTop: 50, padBottom: 50 });
  assert.ok(pg.length > 1); for (const p of pg) { assert.ok(p.used <= 400, 'muat'); assert.ok(p.lines[0].kind === 'text', 'tidak diawali jarak'); assert.ok(p.lines[p.lines.length - 1].kind !== 'gap'); }
  assert.equal(pg.reduce((a, p) => a + p.lines.length, 0) <= 25, true);
  assert.equal(E.paginate([], { pageH: 500, padTop: 50, padBottom: 50 }).length, 1);
  assert.equal(E.paginate([{ kind: 'text', lh: 900, size: 30, x: 0, segs: [] }], { pageH: 500, padTop: 50, padBottom: 50 }).length, 1, 'satu baris lebih tinggi dari halaman tidak membuat halaman kosong tak berujung');
});
await t('base64: bolak-balik utuh untuk berkas besar dan semua nilai byte', () => {
  const big = new Uint8Array(300000); for (let i = 0; i < big.length; i++) big[i] = (i * 7 + (i >> 8)) & 255;
  assert.deepEqual(E.b64ToBytes(E.bytesToB64(big)), big);
  assert.deepEqual(E.b64ToBytes(E.bytesToB64(new Uint8Array([0, 255, 1]))), new Uint8Array([0, 255, 1])); assert.equal(E.bytesToB64(new Uint8Array(0)), '');
});
await t('buildPdf: struktur sah (header, jumlah halaman, xref menunjuk tepat ke tiap objek, startxref, JPEG utuh, judul UTF-16)', () => {
  const j1 = new Uint8Array(1000).map((_, i) => (i * 13) & 255); j1[0] = 0xff; j1[1] = 0xd8; const j2 = new Uint8Array([0xff, 0xd8, 1, 2, 3, 0xff, 0xd9]);
  const pdf = E.buildPdf([{ jpeg: j1, w: 1240, h: 1754 }, { jpeg: j2, w: 1240, h: 1754 }, { jpeg: j2, w: 10, h: 10 }], { title: 'Catatan ✓ 😀' });
  const s = Buffer.from(pdf).toString('latin1');
  assert.ok(s.startsWith('%PDF-1.4') && s.trimEnd().endsWith('%%EOF'));
  assert.ok(s.includes('/Count 3') && s.includes('/MediaBox [0 0 595.28 841.89]') && s.includes('/Filter /DCTDecode') && s.includes('/Length 1000'));
  const sx = Number(/startxref\n(\d+)\n/.exec(s)[1]); assert.equal(s.slice(sx, sx + 4), 'xref');
  const size = Number(/\/Size (\d+)/.exec(s)[1]); assert.equal(size, 4 + 3 * 3);
  const entries = s.slice(sx).split('\n').slice(3, 3 + size - 1);
  entries.forEach((e, i) => { const off = Number(e.slice(0, 10)); assert.ok(s.slice(off).startsWith((i + 1) + ' 0 obj'), 'objek ' + (i + 1) + ' di offset ' + off); });
  const at = pdf.findIndex((_, i) => i + 1000 < pdf.length && pdf[i] === 0xff && pdf[i + 1] === 0xd8 && pdf[i + 2] === j1[2] && pdf[i + 3] === j1[3]);
  assert.deepEqual(pdf.slice(at, at + 1000), j1, 'JPEG tertanam byte demi byte');
  assert.ok(s.includes('<feff00430061') , 'judul UTF-16BE dengan BOM'); assert.ok(s.includes('d83dde00'), 'emoji sebagai pasangan surrogate');
  assert.throws(() => E.buildPdf([]), /tanpa halaman/);
});
await t('sumber: tombol Bagikan hanya di editor catatan biasa (bukan Privat); lembar ikut ditutup tombol Kembali sebelum editor; hanya jalur yang dibutuhkan', () => {
  const nt = src('../src/js/notes.js');
  assert.ok(nt.includes("isP ? null : mi(PATH.share, 'Bagikan', () => { save(); openShare(ctx, n); })"), 'Rev 25: Bagikan kini item menu ⋮ dan tetap tidak ada untuk Privat');
  const sh = src('../src/js/share.js');
  for (const k of ["class: 'ov pickov shareov'", 'renderPages(n, PDF, true', 'renderPages(n, JPG, false', 'buildPdf(pages', 'sendText(n)', 'Bagikan teks', 'MAX_PDF_PAGES', 'MAX_JPG_PARTS', "directory: 'CACHE'", 'bytesToB64(f.bytes)', 'contrastRatio(s.color, th.bg) >= 3', 'if (!alive()) return']) assert.ok(sh.includes(k), k);
  assert.ok(!/data\.priv|\bisP\b|kind === 'priv'|\.priv\b/.test(sh), 'share.js tidak mengakses data Catatan Privat');
  const m = src('../src/js/main.js'); assert.ok(m.indexOf('.ov.pickov') < m.indexOf('backEditor()', m.indexOf('function handleBack')));
  const pk = JSON.parse(src('../package.json')); assert.ok(!Object.keys(pk.dependencies).some((d) => /pdf|canvas|jspdf/i.test(d)), 'tanpa plugin/pustaka baru');
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
console.log(n + ' tes bagikan lulus');
