// Rev 223 / Bagian 1 desain ulang chat: layar penuh, laci Riwayat, tanpa pilihan jenis pekerjaan. Tes Node murni (struktur kode + fungsi ruang.js); tampilan nyata diperiksa terpisah di Chromium dan HP.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as R from '../src/js/ai/ruang.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('ruang.js: uniqueName menambah angka bila bentrok dan tidak melewati batas panjang', () => {
  const i = R.defaultIndex(1);
  assert.equal(R.uniqueName(i, 'Rencana'), 'Rencana');
  assert.equal(R.uniqueName(i, 'umum'), 'umum 2');
  const j = R.addWs(i, 'Obrolan baru').idx; assert.equal(R.uniqueName(j, R.NEW_NAME), 'Obrolan baru 2');
  assert.ok(R.uniqueName(i, 'x'.repeat(80)).length <= R.NAME_MAX);
  assert.equal(R.uniqueName(j, 'Obrolan baru', j.active), 'Obrolan baru');
});
test('ruang.js: titleFrom memotong pesan pertama jadi judul pendek; isFresh hanya untuk nama otomatis', () => {
  assert.equal(R.titleFrom('  halo   dunia '), 'halo dunia');
  assert.ok(R.titleFrom('a'.repeat(100)).length <= 28); assert.equal(R.titleFrom('   '), R.NEW_NAME);
  assert.ok(R.isFresh({ name: 'Umum' })); assert.ok(R.isFresh({ name: 'Obrolan baru 3' })); assert.ok(!R.isFresh({ name: 'Rencana' })); assert.ok(!R.isFresh(null));
});
test('ruang.js: touchWs menaikkan urutan Terkini tanpa mengubah data lain; id asing tak berpengaruh', () => {
  let i = R.defaultIndex(100); const a = R.activeWs(i).id; i = R.addWs(i, 'B', 200).idx; const b = i.active;
  assert.deepEqual(R.byRecent(i).map((w) => w.id), [b, a]);
  const k = R.touchWs(i, a, 300); assert.deepEqual(R.byRecent(k).map((w) => w.id), [a, b]); assert.equal(k.active, i.active); assert.equal(R.touchWs(i, 'wtidakada', 300), i);
  assert.deepEqual(R.normIndex(k).list.map((w) => w.at).sort(), [200, 300]);
});
test('obrolan.js: layar penuh, tanpa jenis pekerjaan, ikon riwayat + gerigi, ruang tetap lewat ruang.js, teks lewat node teks', () => {
  const ob = src('src/js/ai/obrolan.js');
  for (const k of ["class: 'kc-top'", "'aria-label': 'Riwayat percakapan'", "'aria-label': 'Pengaturan AI'", "PATH.lainnya", "class: 'kc-dock'", "class: 'ov kc-drov'", "'Obrolan baru'", "task: TUGAS", "R.isFresh(", "R.titleFrom("]) assert.ok(ob.includes(k), k);
  assert.ok(!ob.includes('TASK_CHOICES') && !ob.includes('setTask'));
  assert.doesNotMatch(ob, /innerHTML|insertAdjacentHTML|outerHTML|localStorage|sessionStorage|console\./);
});
test('main.js: bilah bawah disembunyikan hanya saat chat terbuka; Kembali HP: pengaturan -> chat -> tab sebelumnya', () => {
  const m = src('src/js/main.js'), c = src('src/css/styles.css');
  assert.match(m, /app\.classList\.toggle\('aifull', aiFull\)/); assert.match(m, /ui\.prevTab = ui\.tab/); assert.match(m, /ui\.aiFrom === 'chat'/);
  assert.match(c, /#app\.aifull>nav\{display:none\}/); assert.doesNotMatch(m, /\/ai\//);
});
test('CSS Rev 223 seimbang dan tanpa heks/blur; tes terdaftar', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 223'); assert.ok(i > 0); assert.doesNotMatch(css.slice(i), /#[0-9a-fA-F]{6}|backdrop-filter|blur\(/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev225\.test\.mjs/);
});
test('Rev 224: gaya Pengaturan AI baru menimpa Rev 211 lewat #app .kai; tanpa heks/blur, kurung seimbang', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 224'); assert.ok(i > css.indexOf('/* Rev 223'));
  const r = css.slice(i); assert.doesNotMatch(r, /#[0-9a-fA-F]{6}|backdrop-filter|blur\(/);
  for (const k of ['#app .kai .kai-stk{', '#app .kai .kai-sw{', '#app .kai .btn{', '#app .kai .kai-card{']) assert.ok(r.includes(k), k);
  assert.doesNotMatch(r, /rotate\(/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('Rev 226: tombol salin dan tombol ke bawah; teks simpan-ke-Catatan hanya node teks pertama; CSS tanpa heks/blur', () => {
  const ob = src('src/js/ai/obrolan.js'), css = src('src/css/styles.css'), i = css.indexOf('/* Rev 226'); assert.ok(i > css.indexOf('/* Rev 224'));
  for (const k of ["class: 'kc-cp'", "ev.stopPropagation()", "navigator.clipboard.writeText", "class: 'kc-down'", "noteDraft(el._raw", "pasangSalin(el)", "'role', 'status'"]) assert.ok(ob.includes(k), k);
  assert.doesNotMatch(ob, /innerHTML|insertAdjacentHTML/); assert.doesNotMatch(css.slice(i), /#[0-9a-fA-F]{6}|backdrop-filter|blur\(/);
  for (const k of ['.kc-cp{', '.kc-down{', '@keyframes kc-dot', '@keyframes kc-in', 'prefers-reduced-motion']) assert.ok(css.slice(i).includes(k), k);
});
