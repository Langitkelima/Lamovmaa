// Rev 62: gabungan alarm tagihan dengan servis/pajak, kompatibel dengan Rev 61.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const tp = await import('../src/js/twopockets.js');
const al = await import('../src/js/tp-alarm.js');
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const store = () => { const m = new Map(); return { getItem:k=>m.has(k)?m.get(k):null, setItem:(k,v)=>m.set(k,String(v)), removeItem:k=>m.delete(k) }; };
const NOW = new Date(2026, 10, 5, 10, 0, 0).getTime();
const at = (y,m,d,h,mi=0) => new Date(y,m-1,d,h,mi,0).getTime();
const service = { id:'same', vehicle:'Vario', name:'Pajak', kind:'pajak', dueDate:'2026-11-12', dueKm:0, daysLeft:7, kmLeft:null, status:'aman' };
const bill = { id:'same', name:'Listrik', amount:250000, repeat:'monthly', nextDue:'2026-11-12', daysLeft:7, status:'segera', remind:[{d:7,t:'01:00'},{d:0,t:'20:30'}] };
const api = () => { const calls=[],cancels=[]; return {calls,cancels,scheduleNotification:(id,title,message,delay,repeat)=>{calls.push({id,title,message,delay,repeat});return 'exact_alarm';},cancelScheduledNotification:id=>cancels.push(id)}; };
let n=0; const test=async(name,fn)=>{await fn();n++;console.log('ok -',name);};

await test('normalizeBills membatasi ID, tanggal, status, jam, hari, dan empat pengingat',()=>{
  const b=tp.normalizeBills({bills:[bill,{...bill,id:'../bad'},{...bill,id:'badtime',remind:[{d:31,t:'25:99'},{d:1,t:'09:15'}]},{...bill,id:'bad-date',nextDue:'2026-2-1'}]});
  assert.equal(b.length,2); assert.deepEqual(b[1].remind,[{d:1,t:'09:15'}]); assert.equal(b[0].name,'Listrik');
});
await test('fetchDue membaca bills tambahan dan tetap menerima jawaban server lama',async()=>{
  const conn={url:'https://script.google.com/macros/s/Abc/exec',key:'x'};
  const http=async()=>({status:200,text:JSON.stringify({ok:true,me:'RAMA',due:{today:'2026-11-05',items:[service],bills:[bill]}})});
  const r=await tp.fetchDue(conn,http); assert.equal(r.ok,true); assert.equal(r.due.items.length,1); assert.equal(r.due.bills.length,1);
  const old=await tp.fetchDue(conn,async()=>({status:200,text:JSON.stringify({ok:true,me:'RAMA',due:{today:'2026-11-05',items:[service]}})}));
  assert.deepEqual(old.due.bills,[]);
});
await test('cache baru menyimpan bills dan cache Rev 57/61 lama tetap terbaca',()=>{
  const s=store(); tp.saveDueCache({fetchedAt:NOW,today:'2026-11-05',items:[service],bills:[bill],sched:['tp:same:w','tpb:same:b0'],alarm:true},s);
  const c=tp.loadDueCache(s); assert.equal(c.bills.length,1); assert.equal(c.sched.length,2);
  s.setItem(tp.DUE_KEY,JSON.stringify({fetchedAt:NOW,items:[service],sched:['tp:same:w']}));
  const old=tp.loadDueCache(s); assert.deepEqual(old.bills,[]); assert.equal(old.items.length,1);
});
await test('planAlarms menggabungkan dua jenis dan ID tpb tidak bertabrakan dengan tp',()=>{
  const p=al.planAlarms([service],NOW,{},[bill]);
  assert.deepEqual(p.map(x=>x.id),['tp:same:d','tpb:same:b1']);
  assert.equal(p[1].at,at(2026,11,12,20,30));
});
await test('tagihan terlambat mengingatkan harian pada jam pengingat pertama; tanpa remind tidak ada alarm',()=>{
  const late={...bill,nextDue:'2026-11-04',status:'terlambat'};
  const p=al.planAlarms([],NOW,{},[late]);
  assert.deepEqual(p.map(x=>x.id),['tpb:same:bn']); assert.equal(p[0].at,at(2026,11,6,1));
  // Rev 73: tagihan tanpa pengingat lama memakai jadwal bawaan Notes; bila sakelar tagihan dimatikan, tidak ada alarm.
  assert.deepEqual(al.planAlarms([],NOW,{bil_same:{on:false}},[{...late,remind:[]}]),[]);
});
await test('batas 60 alarm gabungan memilih yang paling dekat',()=>{
  const items=Array.from({length:40},(_,i)=>({...service,id:'s'+i,dueDate:'2026-12-30'}));
  const bills=Array.from({length:40},(_,i)=>({...bill,id:'b'+i,nextDue:'2026-11-06',remind:[{d:0,t:'20:00'}]}));
  const p=al.planAlarms(items,NOW,{},bills); assert.equal(p.length,60);
  assert.ok(p.every(x=>x.at>NOW)); assert.equal(p[0].id.startsWith('tpb:'),true);
});
await test('refreshDue memasang alarm tagihan bersama servis dan menyimpan jadwal gabungan',async()=>{
  const s=store(); tp.saveConn({url:'https://script.google.com/macros/s/Abc/exec',key:'x'},s); const a=api();
  const r=await al.refreshDue({store:s,api:a,now:NOW,force:true,http:async()=>({status:200,text:JSON.stringify({ok:true,me:'RAMA',due:{today:'2026-11-05',items:[service],bills:[bill]}})})});
  assert.equal(r.ok,true); assert.equal(r.cache.bills.length,1); assert.equal(r.cache.sched.length,2);
  assert.ok(a.calls.some(x=>x.id==='tp:same:d')); assert.ok(a.calls.some(x=>x.id==='tpb:same:b1'));
});
await test('setAlarmEnabled dan setItemCfg mempertahankan alarm tagihan',()=>{
  const s=store(),a=api(); tp.saveDueCache({fetchedAt:NOW,items:[service],bills:[bill],sched:['tp:same:w','tpb:same:b0'],alarm:true},s);
  al.setItemCfg('same',{hour:19,min:0,before:[1]}, {now:NOW,store:s,api:a});
  assert.ok(a.calls.some(x=>x.id==='tpb:same:b1'));
  const b=api(); al.setAlarmEnabled(false,{now:NOW,store:s,api:b}); assert.deepEqual(b.cancels.sort(),['tp:same:b1','tpb:same:b1']);
});
await test('layar Setelan menyebut tagihan dan ID notifikasi tpb diarahkan ke Two Pockets',()=>{
  const settings=src('../src/js/settings.js'), reminders=src('../src/js/reminders.js');
  assert.ok(settings.includes('Servis, pajak, tagihan & utang')); assert.ok(settings.includes('describeBill'));
  assert.ok(reminders.includes("kind === 'tp' || kind === 'tpb'"));
});
console.log(`${n} tes lulus (Rev 62)`);
