// Rev 128 / U8a-3: ketik rumus di bilah isian (A1 -> bentuk simpan), tolak yang salah, pratinjau saat mengetik.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { isFormulaText, parseInput } from '../src/js/lembar-ui.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('isFormulaText: hanya isian berawalan = (spasi depan boleh)', () => {
  assert.equal(isFormulaText('=A1+1'), true); assert.equal(isFormulaText('  =SUM(A1:A2)'), true);
  assert.equal(isFormulaText('A1=2'), false); assert.equal(isFormulaText(''), false); assert.equal(isFormulaText(null), false); assert.equal(isFormulaText('12'), false);
  assert.equal(parseInput('=A1+1'), '=A1+1'); // parseInput tetap tidak membuat rumus
});
test('alur ketik: a1ToStored sah disimpan sebagai fx; sintaks salah / fungsi tak dikenal / rujukan luar ditolak', () => {
  const t = L.newTab('T', 5); L.setCell(t, 'r1', 'cA', { v: 4 });
  const ok = R.a1ToStored('=A1*2', t); assert.ok(ok.ok); assert.ok(L.setCell(t, 'r2', 'cA', { fx: ok.fx }));
  assert.equal(R.computeTab(t, { now: 0 }).get('r2', 'cA'), 8);
  for (const bad of ['=', '=1+', '=FOO(1)', '=SUM(', '=A99+1', '=SUM(A1))']) assert.equal(R.a1ToStored(bad, t).ok, false, bad);
  assert.ok(R.a1ToStored('=A1*2', t).error === undefined);
  assert.ok(R.a1ToStored('=1+', t).error.length > 0);
});
test('pratinjau: evalExpr memberi hasil tanpa menyimpan; sel tidak berubah', () => {
  const t = L.newTab('T', 3); L.setCell(t, 'r1', 'cA', { v: 10 });
  const r = R.a1ToStored('=A1/4', t), c = R.computeTab(t, { now: 0 });
  assert.equal(c.evalExpr(r.fx), 2.5); assert.equal(t.rows.some((rw) => Object.values(rw.cells).some((cl) => 'fx' in cl)), false); // Rev 297: dulu JSON.stringify(t).includes('fx'), kadang gagal karena ID lembar acak kebetulan memuat "fx"
  assert.equal(R.valueToText(c.evalExpr(R.a1ToStored('=A1/0', t).fx)), '#DIV/0!');
});
test('kabel lembar-ui: commit memakai a1ToStored + toast galat; input memberi pratinjau; blur memulihkan info', () => {
  const s = src('src/js/lembar-ui.js');
  assert.match(s, /a1ToStored\(val\.value\.trim\(\), tab\)/); assert.match(s, /Rumus tidak disimpan'/); /* Rev 311b: kini dialog (batas(...)), bukan toast */
  assert.match(s, /patch = \{ fx: r\.fx \}/); assert.match(s, /patch = \{ v: next \}/);
  assert.match(s, /val\.addEventListener\('input'/); assert.match(s, /c\.evalExpr\(r\.fx\)/);
  assert.doesNotMatch(s, /eval\(|new Function/);
});
test('Rev 128: versi 0.3.121, SCHEMA 13 (naik di Rev 132), tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev128.test.mjs'));
});
