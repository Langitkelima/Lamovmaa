// Rev 402 / PART K3: pemilih warna bebas (gaya B: kotak + pita rona + hex) + riwayat warna terakhir di layar Gambar kartu. Tes AI (Node, penyimpanan PALSU).
// Geser jari, tampilan, dan penyimpanan nyata diuji di Chromium (tools/audit_kartu_ui_401.py, 51 butir); HP BELUM.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import { normHex, hsvToHex, hexToHsv, tambahRiwayat, bacaRiwayat, simpanRiwayat, RIWAYAT_KEY, RIWAYAT_MAX } from '../src/js/kartu-ui.js';
import { temaKartu } from '../src/js/kartu.js';
import { contrastRatio } from '../src/js/logic.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('normHex: #rrggbb dan rrggbb (huruf besar/kecil, spasi) diterima, lainnya ditolak', () => {
  assert.equal(normHex('#F2C94C'), '#f2c94c'); assert.equal(normHex(' f2c94c '), '#f2c94c');
  for (const x of ['#12', 'merah', '', null, undefined, '#gggggg', '#f2c94c0', '#fff', 42]) assert.equal(normHex(x), null, String(x));
});

test('hsvToHex / hexToHsv: warna pokok benar dan bolak-balik hampir sama (selisih <= 1 per kanal)', () => {
  assert.equal(hsvToHex(0, 1, 1), '#ff0000'); assert.equal(hsvToHex(120, 1, 1), '#00ff00'); assert.equal(hsvToHex(240, 1, 1), '#0000ff');
  assert.equal(hsvToHex(0, 0, 1), '#ffffff'); assert.equal(hsvToHex(0, 0, 0), '#000000'); assert.equal(hsvToHex(60, 1, 1), '#ffff00');
  assert.deepEqual(hexToHsv('#ff0000'), [0, 1, 1]); assert.deepEqual(hexToHsv('#000000'), [0, 0, 0]); assert.deepEqual(hexToHsv('#ffffff'), [0, 0, 1]);
  const ch = (x) => [1, 3, 5].map((i) => parseInt(x.slice(i, i + 2), 16));
  for (const hx of ['#f2c94c', '#2e7d32', '#8e24aa', '#dbe9fb', '#1c2442', '#7f7f7f', '#010203', '#fe00fd']) {
    const back = hsvToHex(...hexToHsv(hx)); ch(hx).forEach((v, i) => assert.ok(Math.abs(v - ch(back)[i]) <= 1, hx + ' -> ' + back));
  }
  assert.deepEqual(hexToHsv('rusak'), hexToHsv('#dbe9fb')); // nilai rusak jatuh ke Biru, tanpa galat
  for (let hh = 0; hh < 360; hh += 7) for (const [s, v] of [[1, 1], [0.5, 0.5], [0, 0.3], [1, 0.02]]) assert.match(hsvToHex(hh, s, v), /^#[0-9a-f]{6}$/);
});

test('kontras teks kartu tetap >= 4,5 : 1 untuk warna apa pun dari pemilih (rona 0..359 x kejenuhan x kecerahan)', () => {
  let n = 0; for (let hh = 0; hh < 360; hh += 15) for (const s of [0, 0.25, 0.6, 1]) for (const v of [0.05, 0.3, 0.55, 0.8, 1]) {
    const bg = hsvToHex(hh, s, v), t = temaKartu(bg); n++;
    assert.ok(contrastRatio(t.ink, bg) >= 4.5 && contrastRatio(t.mut, bg) >= 4.5, bg);
  }
  assert.ok(n > 400);
});

test('riwayat: terbaru di depan, tanpa duplikat, maksimal 8, nilai rusak dibuang; penyimpanan rusak/penuh tidak menjatuhkan apa pun', () => {
  let l = []; for (let i = 0; i < 12; i++) l = tambahRiwayat(l, '#' + String(i).padStart(2, '0') + '0000');
  assert.equal(l.length, RIWAYAT_MAX); assert.equal(l[0], '#110000'); assert.equal(l[7], '#040000');
  l = tambahRiwayat(l, '#060000'); assert.equal(l[0], '#060000'); assert.equal(l.length, 8); assert.equal(l.filter((x) => x === '#060000').length, 1);
  assert.deepEqual(tambahRiwayat(['#aa0000'], 'bukan'), ['#aa0000']); assert.deepEqual(tambahRiwayat([], 'AABBCC'), ['#aabbcc']);
  const mem = {}; const st = { getItem: (k) => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = v; } };
  assert.deepEqual(bacaRiwayat(st), []); simpanRiwayat(['#aabbcc', '#112233'], st); assert.deepEqual(bacaRiwayat(st), ['#aabbcc', '#112233']); assert.ok(RIWAYAT_KEY in mem);
  mem[RIWAYAT_KEY] = '{bukan json'; assert.deepEqual(bacaRiwayat(st), []);
  mem[RIWAYAT_KEY] = JSON.stringify(['#aabbcc', 'x', 5, null, '#112233', ...Array(20).fill('#010101')]); assert.equal(bacaRiwayat(st).length, 8); assert.deepEqual(bacaRiwayat(st).slice(0, 2), ['#aabbcc', '#112233']);
  const rusak = { getItem: () => { throw new Error('diblokir'); }, setItem: () => { throw new Error('penuh'); } };
  assert.deepEqual(bacaRiwayat(rusak), []); assert.doesNotThrow(() => simpanRiwayat(['#aabbcc'], rusak));
  assert.deepEqual(bacaRiwayat(undefined), []); // tanpa localStorage (Node)
});

test('kartu-ui.js: chip Lainnya + kotak + pita + hex + riwayat terpasang; riwayat dicatat SAAT DITUTUP (bukan tiap geseran); hex salah dijelaskan; pemilih hanya aktif bila tidak sibuk', () => {
  const k = rd('src/js/kartu-ui.js');
  for (const x of ["class: 'kartu-chip kartu-lain'", "'data-w': 'lain'", "class: 'kartu-sv'", "class: 'kartu-hue'", "class: 'kartu-hex'", "class: 'kartu-riw'", "'Terakhir dipakai'", 'setPointerCapture', 'releasePointerCapture', "'pointercancel'", 'tambahRiwayat(riwayat, warna)', 'selesai(); ov.remove();', "tWarn('Kode warna harus 6 huruf atau angka, contoh #F2C94C.')", 'clearTimeout(tm)']) assert.ok(k.includes(x), x);
  assert.ok((k.match(/selesai\(\)/g) || []).length === 1); // hanya satu pemanggil: tutup
  assert.ok(/if \(busy\) return; e\.preventDefault\(\); el\.setPointerCapture/.test(k));
  assert.ok(!/fetch\(|XMLHttpRequest|nativePlugin/.test(k));
});

test('CSS K3: kelas pemilih ada dan layar tidak meluap (pratinjau mengecil saat pemilih terbuka, sentuhan tidak menggulir halaman)', () => {
  const css = rd('src/css/styles.css'), i = css.indexOf('/* Rev 402 / K3'); assert.ok(i > 0); const b = css.slice(i);
  for (const sel of ['.kartu-lain', '.kartuov.kpick .kartu-pv', '.kartu-pick', '.kartu-sv', '.kartu-hue', '.kartu-knob', '.kartu-hex', '.kartu-riw', '.kartu-dot', 'touch-action:none']) assert.ok(b.includes(sel), sel);
});

test('pemasangan: tes terdaftar, versi dan SCHEMA tetap (riwayat warna di localStorage, bukan data aplikasi), anggaran JS aman, banner Rev 402, uji HP CC diperluas', () => {
  const pk = JSON.parse(rd('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev402\.test\.mjs/);
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(rd('tools/audit-ukuran.mjs'), /jsMaks: 1600 \* 1024/);
  let js = 0; for (const dir of ['src/js', 'src/js/ai']) for (const f of fs.readdirSync(new URL('../' + dir + '/', import.meta.url)).filter((n) => n.endsWith('.js'))) js += fs.statSync(new URL('../' + dir + '/' + f, import.meta.url)).size;
  assert.ok(js <= 1600 * 1024, 'JS ' + js);
  for (const f of ['RIWAYAT.md', 'PROMPT_SERAH_TERIMA.md']) { const d = rd(f); assert.ok(/^\*\*Rev 4(?:0[2-9]|[123]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 402 /') < d.indexOf('**Rev 401 /'), f); }
  assert.ok(rd('PROMPT_SERAH_TERIMA.md').includes('**39.10 STATUS (Rev 402):**')); assert.ok(rd('UJI_HP_RILIS.md').includes('10. (Rev 402, K3)'));
});
