// Rev 311c: sisa batas/penolakan di catatan, chat AI, proyek, Setelan kini dialog lewat infoKey (teks di modul MALAS tolak-msg.js).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const R = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const { M } = await import('../src/js/tolak-msg.js');
test('setiap pesan: judul + alasan + solusi, tanpa awalan Error dan tanpa istilah teknis', () => {
  const contoh = { maks: M.maks('gambar di catatan ini', 10, 'Hapus gambar.'), dlmTabel: M.dlmTabel('Tabel'), gbrKunci: M.gbrKunci('dihapus'), kartuDekat: M.kartuDekat(), izin: M.izin(), jadwal: M.jadwal(), alarmTepat: M.alarmTepat(), tulisBlok: M.tulisBlok(), chatWaktu: M.chatWaktu(), gbrGagal: M.gbrGagal(2), muatGagal: M.muatGagal() };
  for (const [k, o] of Object.entries(contoh)) {
    assert.ok(o.title && o.msg && o.fix, k + ' lengkap');
    assert.doesNotMatch(o.title + o.msg + o.fix, /Error|exception|undefined|\[object|null/i, k);
  }
  assert.match(contoh.maks.msg, /\(10\)/); assert.match(contoh.gbrGagal.msg, /2 gambar sebelumnya/);
});
test('ui.js: infoKey memuat tolak-msg.js secara malas (bukan impor statis)', () => {
  const u = R('src/js/ui.js'); assert.match(u, /export const infoKey = \(k, \.\.\.a\) => import\('\.\/tolak-msg\.js'\)/);
  for (const f of ['notes', 'settings', 'proyek-ui', 'ai/obrolan', 'ai/pemilihui', 'ai/tulisui', 'ui', 'main']) assert.doesNotMatch(R('src/js/' + f + '.js'), /from '\.\.?\/tolak-msg\.js'/, f);
});
test('notes.js: batas dan penolakan kini dialog; tidak ada pesan mentah dari exception', () => {
  const n = R('src/js/notes.js');
  for (const k of ["toast('Maksimal 10 gambar", "toast('Gambar terkunci", "tidak bisa disisipkan di dalam sel tabel", "toast('Maksimal ' + LZ.MAX_SHEETS", "toast('Satu catatan maksimal", "toast('Tanggal kartu sudah terlalu dekat", "toast('Izinkan notifikasi", "e && e.message ? e.message"]) assert.ok(!n.includes(k), k);
  for (const k of ["infoKey('maks', 'gambar di catatan ini', 10", "infoKey('gbrKunci', 'dipindahkan')", "infoKey('gbrKunci', 'dihapus')", "infoKey('dlmTabel', label)", "infoKey('kartuDekat')", "infoKey('gbrGagal', added)", "infoKey('izin')"]) assert.ok(n.includes(k), k);
});
test('settings, proyek, chat AI, Tulis AI: batas dan izin lewat dialog', () => {
  const s = R('src/js/settings.js'), p = R('src/js/proyek-ui.js'), o = R('src/js/ai/obrolan.js'), pm = R('src/js/ai/pemilihui.js'), t = R('src/js/ai/tulisui.js');
  assert.ok(!s.includes("toast('Maksimal") && !s.includes("Kesalahan tak terduga: ")); assert.match(s, /infoKey\('alarmTepat'\)/); assert.match(s, /infoKey\('izin', 'Daftar sudah dimuat/);
  assert.ok(!p.includes("toast('Maksimal")); assert.equal((p.match(/infoKey\('maks'/g) || []).length, 3);
  assert.match(o, /infoKey\('chatWaktu'\)/); assert.equal((pm.match(/infoKey\('maks', 'pilihan'/g) || []).length, 2); assert.match(t, /infoKey\('tulisBlok'\)/);
});
test('A5: rumus salah mempertahankan teks yang diketik (tidak direset) dan tidak berulang-ulang', () => {
  const s = R('src/js/lembar-ui.js'); assert.match(s, /if \(badTxt === val\.value\) return; badTxt = val\.value;/); assert.match(s, /classList\.add\('inerr'\)/);
});
