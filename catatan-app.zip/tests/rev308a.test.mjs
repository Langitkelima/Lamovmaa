// Rev 308a / v0.3.121: mesin pilihan konteks AI PER ID (logika murni, tanpa UI baru). Bawaan KOSONG; bentuk lama = kosong; ID gugur sendiri; catatan bukan sumber lagi.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { CTX_KEY, CTX_VER, CTX_PICK_MAX, CTX_SOURCES, normPerms, loadPerms, savePerms, anyOn, pickedCount, togglePick, setPicks, pickable, livePerms, buildContext } from '../src/js/ai/konteks.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mem = (init) => { const m = new Map(init ? [[CTX_KEY, init]] : []); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)) }; };
const data = () => ({
  tasks: [{ id: 't1', title: 'Bayar listrik', done: false, due: '2026-11-20', pri: 1 }, { id: 't2', title: 'Sudah beres', done: true }, { id: 't3', title: 'Cuci mobil', done: false }, { id: 't4', title: 'Servis motor', done: false }],
  notes: [{ id: 'n1', title: 'Resep rahasia', text: 'ISI-CATATAN', updated: 1 }], priv: [{ id: 'p1', title: 'PRIVAT' }], trash: [{ id: 'x', title: 'SAMPAH' }],
  projects: [{ id: 'a', name: 'Renovasi', status: 'aktif', at: 5, tasks: ['t1'], notes: [] }, { id: 'b', name: 'Arsip', status: 'arsip', at: 9, tasks: [], notes: [] }, { id: 'c', name: 'Belajar', status: 'aktif', at: 7, tasks: [], notes: [] }],
});
test('bentuk baku {v:2,tugas,proyek}; bawaan kosong; bentuk lama (boolean) dan versi lain dibaca KOSONG (D2)', () => {
  assert.equal(CTX_VER, 2); assert.deepEqual(normPerms(null), { v: 2, tugas: [], proyek: [] });
  assert.deepEqual(normPerms({ tugas: true, catatan: true, proyek: true }), { v: 2, tugas: [], proyek: [] });
  assert.deepEqual(normPerms({ v: 1, tugas: ['a'] }), { v: 2, tugas: [], proyek: [] }); assert.deepEqual(normPerms([1, 2]), { v: 2, tugas: [], proyek: [] });
  assert.deepEqual(loadPerms(mem('{"tugas":true,"catatan":false,"proyek":true}')), { v: 2, tugas: [], proyek: [] }); assert.deepEqual(loadPerms(mem('{rusak')), { v: 2, tugas: [], proyek: [] });
});
test('normPerms membersihkan: hanya string tak kosong, tanpa duplikat, kunci asing dibuang, dibatasi 15 tugas / 10 proyek', () => {
  const n = normPerms({ v: 2, tugas: ['a', 'a', '', 5, null, 'b', 'x'.repeat(81)], proyek: 'bukan-array', catatan: ['n1'], lain: ['z'] });
  assert.deepEqual(n, { v: 2, tugas: ['a', 'b'], proyek: [] });
  const big = normPerms({ v: 2, tugas: Array.from({ length: 40 }, (_, i) => 't' + i), proyek: Array.from({ length: 40 }, (_, i) => 'p' + i) });
  assert.equal(big.tugas.length, CTX_PICK_MAX.tugas); assert.equal(big.proyek.length, CTX_PICK_MAX.proyek); assert.equal(big.tugas[0], 't0');
});
test('simpan/muat bolak-balik di kunci terpisah; anyOn dan pickedCount', () => {
  const st = mem(); assert.equal(anyOn(loadPerms(st)), false); assert.equal(savePerms({ v: 2, tugas: ['t1'], proyek: ['a', 'c'] }, st).ok, true);
  const l = loadPerms(st); assert.deepEqual(l, { v: 2, tugas: ['t1'], proyek: ['a', 'c'] }); assert.equal(anyOn(l), true); assert.equal(pickedCount(l, 'proyek'), 2); assert.equal(pickedCount(l, 'catatan'), 0);
  assert.equal(JSON.parse(st.getItem(CTX_KEY)).v, 2); assert.equal(savePerms({}, { setItem() { throw new Error('penuh'); } }).ok, false);
});
test('togglePick: tambah, lepas, penuh, ID/sumber tidak sah; masukan tidak diubah', () => {
  const p0 = normPerms(null), a = togglePick(p0, 'tugas', 't1'); assert.equal(a.result, 'added'); assert.deepEqual(a.perms.tugas, ['t1']); assert.deepEqual(p0.tugas, []);
  assert.equal(togglePick(a.perms, 'tugas', 't1').result, 'removed'); assert.deepEqual(togglePick(a.perms, 'tugas', 't1').perms.tugas, []);
  let p = p0; for (let i = 0; i < 15; i++) p = togglePick(p, 'tugas', 't' + i).perms; const full = togglePick(p, 'tugas', 'baru'); assert.equal(full.result, 'full'); assert.equal(full.perms.tugas.length, 15);
  assert.equal(togglePick(p0, 'catatan', 'n1').result, 'bad'); assert.equal(togglePick(p0, 'tugas', '').result, 'bad'); assert.equal(togglePick(p0, 'tugas', 7).result, 'bad');
});
test('setPicks mengganti seluruh pilihan satu sumber; sumber lain utuh', () => {
  const p = setPicks({ v: 2, tugas: ['t1'], proyek: ['a'] }, 'tugas', ['t3', 't4']); assert.deepEqual(p, { v: 2, tugas: ['t3', 't4'], proyek: ['a'] });
  assert.deepEqual(setPicks(p, 'tugas', []).tugas, []); assert.deepEqual(setPicks(p, 'catatan', ['n1']), p); assert.deepEqual(setPicks(p, 'tugas', 'x').tugas, []);
});
test('pickable: tugas belum selesai (urutan data), proyek aktif terbaru dulu; catatan/privat/sampah tidak ada; data rusak aman', () => {
  const d = data(); assert.deepEqual(pickable(d, 'tugas').map((x) => x.id), ['t1', 't3', 't4']); assert.deepEqual(pickable(d, 'proyek').map((x) => x.id), ['c', 'a']);
  assert.deepEqual(pickable(d, 'catatan'), []); assert.deepEqual(pickable(d, 'priv'), []);
  for (const bad of [null, {}, { tasks: 'x', projects: 5 }, { tasks: [null, 3, {}, { id: 1, title: 'a' }], projects: [null, {}] }]) { assert.deepEqual(pickable(bad, 'tugas'), []); assert.deepEqual(pickable(bad, 'proyek'), []); }
});
test('buildContext: HANYA ID terpilih yang ikut; yang tidak dicentang tidak dikirim', () => {
  const d = data(), t = buildContext(d, { v: 2, tugas: ['t3'] }); assert.match(t.text, /Cuci mobil/); assert.doesNotMatch(t.text, /Bayar listrik|Servis motor/); assert.deepEqual(t.parts, [{ id: 'tugas', label: 'Tugas yang belum selesai', count: 1 }]);
  const pr = buildContext(d, { v: 2, proyek: ['a'] }); assert.match(pr.text, /Renovasi, 0 dari 1 tugas selesai|Renovasi, /); assert.doesNotMatch(pr.text, /Belajar|Arsip/);
  assert.equal(buildContext(d, { v: 2, tugas: [], proyek: [] }).text, ''); assert.equal(buildContext(d, null).text, '');
});
test('ID yang sudah selesai, dihapus, atau diarsipkan gugur sendiri (tanpa mengubah izin tersimpan)', () => {
  const d = data(), perms = { v: 2, tugas: ['t1', 't2', 'hilang'], proyek: ['a', 'b', 'zzz'] };
  const t = buildContext(d, perms).text; assert.match(t, /Bayar listrik/); assert.doesNotMatch(t, /Sudah beres/); assert.doesNotMatch(t, /Arsip/);
  assert.deepEqual(livePerms(d, perms), { v: 2, tugas: ['t1'], proyek: ['a'] }); assert.deepEqual(perms.tugas, ['t1', 't2', 'hilang']);
  d.tasks[0].done = true; assert.equal(buildContext(d, { v: 2, tugas: ['t1'] }).text, ''); assert.equal(anyOn(livePerms(d, { v: 2, tugas: ['t1'] })), false);
});
test('catatan BUKAN sumber lagi; Catatan Privat dan sampah tidak pernah ikut walau ID-nya dipilih', () => {
  assert.deepEqual(CTX_SOURCES.map((s) => s.id), ['tugas', 'proyek']);
  const d = data(), all = buildContext(d, { v: 2, tugas: ['t1', 'p1', 'x', 'n1'], proyek: ['a', 'p1'], catatan: ['n1'] }).text;
  assert.doesNotMatch(all, /PRIVAT|SAMPAH|ISI-CATATAN|Resep rahasia/); const k = src('src/js/ai/konteks.js'); assert.doesNotMatch(k, /\.priv\b|\.trash\b|\.notes\b|innerHTML|document\.|window\./);
});
test('dialog memakai izin per ID: baris sumber membuka pemilih, tanpa boolean lama', () => {
  const o = src('src/js/ai/obrolan.js'); assert.match(o, /bukaPemilihData\(\{ data: ctx.data, src: x.id, perms/); assert.match(o, /anyOn\(livePerms\(ctx\.data, perms\)\)/); assert.doesNotMatch(o, /\[x\.id\]: !perms\[x\.id\]/);
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\//);
});
