// Rev 136 / U8b-3: baris Total tabel -> RUMUS hidup di lembar kerja + audit cadangan/salin/Urungkan untuk rumus dan format angka.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { a1ToStored, computeTab } from '../src/js/rumus.js';
import { sheetFromMatrix, TOTAL_FN } from '../src/js/lembar-pulau.js';
import { makeDisplay, fxFromA1 } from '../src/js/lembar-tampil.js';
import { normalize, importJSON, exportJSON, emptyData } from '../src/js/storage.js';
import { cloneSheetsForCopy } from '../src/js/lembar-siklus.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const cell = (v, o = {}) => ({ v, b: false, ha: 'start', ...o });
const M = () => [
  [cell('Item', { b: true }), cell('Harga', { b: true })],
  [cell('Kopi'), cell(12000)], [cell('Teh'), cell(8000.5)], [cell('Roti'), cell(5000)],
  [cell(''), cell('Jumlah: 25.000,5', { b: true, tf: 'sum', r1: 1, r2: 3 })],
  [cell(''), cell('Rata-rata: 8.333,5', { b: true, tf: 'avg', r1: 1, r2: 3 })],
  [cell(''), cell('Jumlah: 25.000,5', { b: true, tf: 'bogus', r1: 1, r2: 3 })], // fungsi tak dikenal = tetap nilai biasa
];
test('sheetFromMatrix: sel Total ber-tf jadi rumus hidup dan menghitung sama dengan tabel', () => {
  const sh = sheetFromMatrix(M(), { id: 'stot0001' }); const t = sh.tabs[0], d = makeDisplay(t);
  assert.equal(typeof L.cellAt(t, 4, 1).fx, 'string'); assert.equal(L.cellAt(t, 4, 1).v, undefined); assert.equal(L.cellAt(t, 4, 1).s.b, true);
  assert.equal(d.text(4, 1), '25000,5'); assert.equal(d.text(5, 1), '8333,5'); // 25000,5 / 3 = 8333,5
  assert.equal(L.cellAt(t, 6, 1).fx, undefined); assert.equal(L.cellAt(t, 6, 1).v, 'Jumlah: 25.000,5');
  // rumus hidup: ubah data, total ikut
  L.setCell(t, 'r2', 'cB', { v: 20000 }); assert.equal(makeDisplay(t).text(4, 1), '33000,5');
});
test('sheetFromMatrix: tanpa tf / rentang rusak = perilaku lama (nilai biasa); fxFromA1 menolak rumus salah', () => {
  const m = [[cell('a'), cell(1)], [cell('x'), cell('Jumlah: 1', { tf: 'sum', r1: 5, r2: 2 })]]; const t = sheetFromMatrix(m, { id: 'stot0002' }).tabs[0];
  assert.equal(L.cellAt(t, 1, 1).fx, undefined); assert.equal(L.cellAt(t, 1, 1).v, 'Jumlah: 1');
  assert.equal(fxFromA1('=SUM(', t), null); assert.equal(typeof fxFromA1('=SUM(B1:B1)', t), 'string'); assert.deepEqual(Object.keys(TOTAL_FN), ['sum', 'avg', 'cnt', 'min', 'max']);
});
test('audit cadangan: rumus (fx) dan format angka (nf) selamat lewat ekspor/impor JSON dan normalize', () => {
  const d = emptyData(); const sh = sheetFromMatrix(M(), { id: 'stot0003' }); L.setCell(sh.tabs[0], 'r2', 'cB', { s: { nf: { k: 'currency', c: 'IDR', d: 0 } } }); d.sheets = { [sh.id]: sh };
  const r = importJSON(exportJSON(d)); assert.equal(r.ok, true);
  const t = r.data.sheets.stot0003.tabs[0]; assert.equal(L.cellAt(t, 4, 1).fx, L.cellAt(sh.tabs[0], 4, 1).fx); assert.deepEqual(L.cellAt(t, 1, 1).s.nf, { k: 'currency', c: 'IDR', d: 0 });
  assert.equal(makeDisplay(t).text(4, 1), '25000,5'); assert.equal(makeDisplay(t).text(1, 1), 'Rp 12.000');
  const n = normalize(JSON.parse(JSON.stringify(d))); assert.equal(L.cellAt(n.sheets.stot0003.tabs[0], 4, 1).fx, L.cellAt(sh.tabs[0], 4, 1).fx);
});
test('audit salin catatan: lembar KLON menjaga rumus dan format, dan tetap menghitung sendiri (tidak berbagi)', () => {
  const sh = sheetFromMatrix(M(), { id: 'stot0004' }); L.setCell(sh.tabs[0], 'r2', 'cB', { s: { nf: { k: 'number', d: 1 } } });
  const sheets = { stot0004: sh }, html = '<p>x</p><div class="ksheet" contenteditable="false" data-sheet="stot0004"></div>';
  const r = cloneSheetsForCopy(html, sheets); assert.equal(r.cloned, 1); const id2 = /data-sheet="([a-z0-9]+)"/.exec(r.html)[1]; assert.notEqual(id2, 'stot0004');
  const c = sheets[id2].tabs[0]; assert.equal(makeDisplay(c).text(4, 1), '25000,5'); assert.equal(makeDisplay(c).text(1, 1), '12.000,0');
  L.setCell(c, 'r2', 'cB', { v: 1 }); assert.equal(makeDisplay(c).text(4, 1), '13001,5'); assert.equal(makeDisplay(sh.tabs[0]).text(4, 1), '25000,5'); // asli tidak berubah
});
test('audit Urungkan lembar: snapshot JSON memulihkan rumus + format (cache hitung berkunci versi)', () => {
  const sh = sheetFromMatrix(M(), { id: 'stot0005' }), snap = JSON.stringify(sh.tabs[0]);
  L.setCell(sh.tabs[0], 'r2', 'cB', { v: 99999, s: { nf: { k: 'percent', d: 1 } } }); L.setCell(sh.tabs[0], 'r5', 'cB', { v: 'timpa' });
  const back = JSON.parse(snap); assert.equal(typeof L.cellAt(back, 4, 1).fx, 'string'); assert.equal(makeDisplay(back).text(4, 1), '25000,5');
});
test('struktur + kabel: lembar-pulau tetap tanpa mesin rumus langsung; to-sheet memakai matrixFromTable; tes terdaftar; versi 0.3.121', () => {
  assert.doesNotMatch(src('src/js/lembar-pulau.js'), /rumus\.js/); assert.match(src('src/js/notes.js'), /sheetFromMatrix\(matrixFromTable\(table\)/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121')); assert.ok(pk.scripts.test.includes('tests/rev136.test.mjs'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
});
