import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { localTimeHM, isValidTimeHM, formatTimeID } from '../src/js/waktu.js';
import { parseNoteHtml } from '../src/js/export.js';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

test('Rev 84: waktu lokal memakai jam dan menit perangkat dengan format 24 jam', () => {
  assert.equal(localTimeHM(new Date(2026, 10, 7, 0, 5)), '00:05');
  assert.equal(localTimeHM(new Date(2026, 10, 7, 23, 59)), '23:59');
  assert.equal(isValidTimeHM('00:00'), true);
  assert.equal(isValidTimeHM('23:59'), true);
  assert.equal(isValidTimeHM('24:00'), false);
  assert.equal(isValidTimeHM('12:60'), false);
  assert.equal(formatTimeID('08:07'), '08:07');
  assert.equal(formatTimeID('8:07'), '');
});

test('Rev 84: tombol Waktu tersedia di bilah Langit dan handler terhubung', () => {
  const notes = read('../src/js/notes.js');
  assert.match(notes, /insertBtn\('time', 'Waktu'\)/);
  assert.match(notes, /kind === 'time'\) insertTime\(\)/);
  assert.match(notes, /className = 'kb-time-block'/);
  assert.match(notes, /registerBlock\(\{ type: 'time', selector: '\.kb-time-block'/);
});

test('Rev 84: parser ekspor merangkum blok Waktu sebagai teks tetap', () => {
  const blocks = parseNoteHtml('<div class="kb-time-block" contenteditable="false" data-kb-time="14:35"><span class="kb-time-value">14:35</span></div><p>Catatan</p>');
  assert.equal(blocks[0].runs.map((r) => r.t).join(''), 'Waktu: 14:35');
  assert.equal(blocks[1].runs.map((r) => r.t).join(''), 'Catatan');
});

test('Rev 84: sanitizer mengizinkan hanya waktu valid dan tidak mengubah SCHEMA/native', () => {
  const notes = read('../src/js/notes.js');
  const storage = read('../src/js/storage.js');
  const pkg = JSON.parse(read('../package.json'));
  assert.match(notes, /k === 'data-kb-time' && isValidTimeHM\(v\)/);
  assert.match(storage, /SCHEMA\s*=\s*22/);
  assert.equal(pkg.version, '0.3.121');
  assert.doesNotMatch(notes, /registerPlugin\(|Capacitor\.Plugins/);
});
