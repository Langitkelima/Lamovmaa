// Rev 243 / Tahap 9d: audit keamanan Worker. Fetch PALSU; bukan bukti dari Cloudflare nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', GEMINI_KEY: 'gm-FAKE-0123456789-tes', ...x });
const post = (o, headers = {}) => new Request('https://w.example/', { method: 'POST', headers, body: JSON.stringify({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', limit: 0, messages: [{ role: 'user', content: 'Hai' }], ...o }) });
test('pesan galat penyedia: untaian mirip kunci dibuang, pesan biasa tetap utuh', () => {
  const j = { error: { message: 'Incorrect API key provided: AIzaSyD-abcdefghijklmnop1234567890 tidak sah' } };
  const a = T.providerError('gemini', 400, j); assert.doesNotMatch(a.error, /AIzaSyD/); assert.match(a.error, /Incorrect API key provided/);
  const b = T.providerError('gemini', 429, { error: { message: 'Quota habis, coba lagi nanti' } }); assert.match(b.error, /Quota habis, coba lagi nanti/);
  assert.doesNotMatch(T.providerError('sakelar', 400, [{ error: { message: 'bad sk-live_0123456789abcdefXYZ' } }]).error, /sk-live/);
});
test('Content-Length raksasa ditolak 413 sebelum badan dibaca; ukuran wajar tetap diproses', async () => {
  let dibaca = false; const r = post({}, { 'Content-Length': '999999' }); const asli = r.text.bind(r); Object.defineProperty(r, 'text', { value: () => { dibaca = true; return asli(); } });
  const x = await T.handle(r, env0(), Date.UTC(2026, 10, 12, 5)); assert.equal(x.status, 413); assert.equal(dibaca, false);
  const orig = globalThis.fetch; globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'ok' } }], usage: {} }) });
  try { const y = await T.handle(post({}), env0({ KV: { get: async () => null, put: async () => {} } }), Date.UTC(2026, 10, 12, 5)); assert.equal(y.status, 200); } finally { globalThis.fetch = orig; }
});
test('galat tak terduga: jawaban 500 generik tanpa detail dalam, tetap berformat JSON dengan CORS', async () => {
  const bad = new Proxy({}, { get() { throw new Error('rahasia-dalam-123'); }, ownKeys() { throw new Error('rahasia-dalam-123'); } });
  const r = await W.fetch(new Request('https://w.example/', { method: 'POST', headers: { Origin: 'https://localhost' }, body: '{}' }), bad);
  assert.equal(r.status, 500); const j = await r.json(); assert.equal(j.ok, false); assert.doesNotMatch(JSON.stringify(j), /rahasia-dalam/); assert.equal(r.headers.get('Access-Control-Allow-Origin'), 'https://localhost');
});
test('tes terdaftar; versi 0.3.121', () => { const pk = JSON.parse(src('package.json')); assert.match(pk.scripts.test, /node tests\/rev243\.test\.mjs/); assert.equal(pk.version, '0.3.121'); });
