// Rev 262 / S8: panel warna dengan roda warna (lembar-warna.js murni + panel di lembar-ui.js). Tes Node; BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as W from '../src/js/lembar-warna.js'; import * as L from '../src/js/lembar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8'); const ui = src('src/js/lembar-ui.js'), pulau = src('src/js/lembar-pulau.js'), css = src('src/css/styles.css');
test('normHex: #abc, abc, #AABBCC, spasi; selain itu null; hasil selalu #RRGGBB besar', () => {
  assert.equal(W.normHex('#abc'), '#AABBCC'); assert.equal(W.normHex('abc'), '#AABBCC'); assert.equal(W.normHex(' #aabbcc '), '#AABBCC'); assert.equal(W.normHex('AABBCC'), '#AABBCC');
  for (const bad of ['', '#', '#ab', '#abcd', 'ggg', '#1234567', null, undefined, 12, {}]) assert.equal(W.normHex(bad), null, String(bad));
});
test('HSL <-> hex bolak-balik (selisih maks 1 per kanal) dan nilai baku', () => {
  assert.equal(W.hslToHex(0, 100, 50), '#FF0000'); assert.equal(W.hslToHex(120, 100, 50), '#00FF00'); assert.equal(W.hslToHex(240, 100, 50), '#0000FF'); assert.equal(W.hslToHex(0, 0, 100), '#FFFFFF'); assert.equal(W.hslToHex(0, 0, 0), '#000000');
  assert.deepEqual(W.hexToHsl('#FF0000'), { h: 0, s: 100, l: 50 }); assert.equal(W.hexToHsl('#808080').s, 0); assert.equal(W.hexToHsl('zzz'), null);
  for (let i = 0; i < 400; i++) { const c = W.rgbToHex((i * 37) % 256, (i * 91) % 256, (i * 53) % 256), q = W.hexToHsl(c), b = W.hexToRgb(W.hslToHex(q.h, q.s, q.l)), a = W.hexToRgb(c); a.forEach((v, k) => assert.ok(Math.abs(v - b[k]) <= 2, c)); }
  assert.equal(W.hslToHex(NaN, NaN, NaN), '#000000'); assert.equal(W.hslToHex(720, 100, 50), '#FF0000'); assert.equal(W.hslToHex(-120, 100, 50), '#0000FF'); // masukan liar tidak menghasilkan NaN
});
test('roda warna: sudut = rona, jari-jari = kejenuhan, tepi dijepit; pergi-balik', () => {
  assert.deepEqual(W.wheelToHs(10, 0, 10), { h: 0, s: 100 }); assert.deepEqual(W.wheelToHs(0, 5, 10), { h: 90, s: 50 }); assert.equal(W.wheelToHs(-10, 0, 10).h, 180); assert.equal(W.wheelToHs(0, -10, 10).h, 270);
  assert.equal(W.wheelToHs(0, 0, 10).s, 0); assert.equal(W.wheelToHs(500, 0, 10).s, 100); assert.equal(W.wheelToHs(1, 1, 0).s, 100); // R=0 tidak membagi nol
  for (const [h, s] of [[0, 100], [45, 30], [200, 77], [359, 10]]) { const p = W.hsToWheel(h, s, 110), q = W.wheelToHs(p.x, p.y, 110); assert.ok(Math.abs(q.h - h) < 0.2 && Math.abs(q.s - s) < 0.2, h + ',' + s); }
});
test('kontras dan teks otomatis: isian terang -> teks gelap, isian gelap -> teks terang', () => {
  assert.equal(W.inkOn('#FDE68A'), '#111827'); assert.equal(W.inkOn('#FFFFFF'), '#111827'); assert.equal(W.inkOn('#000000'), '#F9FAFB'); assert.equal(W.inkOn('#1E3A8A'), '#F9FAFB'); assert.equal(W.inkOn('#592222'), '#F9FAFB'); assert.equal(W.inkOn('bukan'), '#111827');
  assert.ok(W.contrast('#000000', '#FFFFFF') > 20.9 && W.contrast('#777777', '#777777') === 1); assert.equal(W.rating(4.5), 'baik'); assert.equal(W.rating(3), 'cukup'); assert.equal(W.rating(2.9), 'lemah');
  for (const c of W.FILL_ROWS[0].colors) assert.equal(W.inkOn(c), '#111827'); for (const c of W.FILL_ROWS[2].colors) assert.equal(W.inkOn(c), '#F9FAFB'); // deret cahaya = teks gelap, deret gelap = teks terang
});
test('salinan inkOnFill di lembar-pulau.js SAMA dengan inkOn di seluruh ruang warna (tanpa impor baru di jalur buka)', () => {
  const m = pulau.match(/const inkOnFill = (\(bg\) => \{.*\});\n/); assert.ok(m); const f = new Function('return ' + m[1])();
  assert.ok(!/from '\.\/lembar-warna\.js'/.test(pulau)); let n = 0;
  for (let r = 0; r < 256; r += 15) for (let g = 0; g < 256; g += 15) for (let b = 0; b < 256; b += 15) { const c = W.rgbToHex(r, g, b); assert.equal(f(c), W.inkOn(c), c); n++; }
  assert.ok(n > 4000); assert.ok(pulau.includes('else if (c.bg) s.style.color = inkOnFill(c.bg);') && !pulau.includes("s.style.color = '#111827'"));
});
test('deret per tema: semua hex sah, unik per deret, diterima L.cleanStyle apa adanya (tanpa SCHEMA baru)', () => {
  for (const rw of [...W.FILL_ROWS, ...W.TEXT_ROWS]) { assert.equal(rw.colors.length, 9); assert.equal(new Set(rw.colors).size, 9); for (const c of rw.colors) { assert.match(c, /^#[0-9A-F]{6}$/); assert.equal(L.cleanStyle({ bg: c }).bg, c); assert.equal(L.cleanStyle({ fg: c }).fg, c); } }
  assert.deepEqual(W.FILL_ROWS.map((r) => r.id), ['cahaya', 'kaya', 'gelap']); assert.deepEqual(W.TEXT_ROWS.map((r) => r.id), ['untukTerang', 'untukGelap']);
  for (const c of W.TEXT_ROWS[0].colors) assert.ok(W.contrast(c, W.SURF_TERANG) >= 4.5, 'teks untuk latar terang ' + c); for (const c of W.TEXT_ROWS[1].colors) assert.ok(W.contrast(c, W.SURF_GELAP) >= 4.5, 'teks untuk latar gelap ' + c);
});
test('themePreview: isian = sel + teks otomatis (atau teks sel yang sudah ada); teks = latar terang, gelap, dan isian sel', () => {
  const a = W.themePreview('bg', '#0A0F24'); assert.equal(a.length, 2); assert.equal(a[0].ink, '#F9FAFB'); assert.equal(a[1].samar, true); assert.equal(a[0].samar, false); // isian segelap latar gelap = menyatu
  const b = W.themePreview('bg', '#FDE68A', { fg: '#111827' }); assert.equal(b[0].ink, '#111827'); assert.equal(b[0].nilai, 'baik');
  const c = W.themePreview('fg', '#111827'); assert.equal(c[0].nilai, 'baik'); assert.equal(c[1].nilai, 'lemah'); // teks gelap hilang di tema gelap
  const d = W.themePreview('fg', '#2563EB', { bg: '#FDE68A' }); assert.equal(d.length, 3); assert.equal(d[2].nama, 'Di isian sel'); assert.equal(W.themePreview('bg', 'bukan'), null);
});
test('panel di lembar-ui.js: roda warna dibuka dari palet, satu applyStyle (satu Urungkan), tanpa penyimpanan/native, tanpa touch-action di grid', () => {
  const f = ui.slice(ui.indexOf('function openColorPanel(key, ext) {'), ui.indexOf('// --- Rev 132 / U8a-5: tombol Format'));
  assert.ok(f.length > 2500); assert.ok(ui.includes("import * as WN from './lembar-warna.js'"));
  assert.ok(ui.includes("class: 'lz-swk'") && ui.includes('onclick: () => openColorPanel(key)'));
  assert.equal((f.match(/applyStyle\(/g) || []).length, 1); assert.ok(f.includes('applyStyle({ [key]: c })') && f.includes('done(null)') && f.includes('done(cur())')); // Rev 296: Atur ulang (done(null)) + Terapkan (done(cur())) lewat SATU applyStyle; geser roda TIDAK mengubah data
  assert.ok(f.includes("document.querySelector('.lz-wn')") && f.includes("'ov dlgov lz-more lz-cm lz-wn'")); // satu panel; Kembali HP menutup lewat .lz-more
  assert.ok(f.includes('setPointerCapture') && f.includes('requestAnimationFrame') && f.includes('WN.themePreview(key')); assert.ok(!/localStorage|sessionStorage|Capacitor|fetch\(|eval\(/.test(f));
  assert.ok(ui.includes('else if (st.bg) el.style.color = WN.inkOn(st.bg);') && !ui.includes("else if (st.bg) el.style.color = '#111827'"));
  assert.ok(css.includes('.wn-wheel{') && css.includes('touch-action:none') && !/\.lz-scroll\{[^}]*touch-action:none/.test(css)); assert.ok(css.includes('.lembarfs .lz-swk{'));
});
test('modul murni: hanya mengimpor lembar-aturan.js; tanpa DOM/penyimpanan/native/eval', () => {
  const w = src('src/js/lembar-warna.js'); assert.deepEqual([...w.matchAll(/^import .* from '([^']+)'/gm)].map((m) => m[1]), ['./lembar-aturan.js']);
  assert.ok(!/document\.|window\.|localStorage|Capacitor|fetch\(|eval\(|new Function/.test(w));
});
