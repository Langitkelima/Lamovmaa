// Rev 295 (Paket Data): 4-1 gagal-muat tidak boleh menghapus gambar / menimpa salinan rusak, 7-1 log tanpa isi data, 4-2 habitLog ikut Pulihkan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as S from '../src/js/storage.js';
import * as L from '../src/js/logic.js';
import * as GA from '../src/js/gambar-app.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const fake = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, v), _m: m }; };
const mockFS = () => {
  const calls = { readdir: 0, deleted: [] };
  const old = Date.now() - 5 * 24 * 3600 * 1000;
  const FS = {
    readdir: async () => { calls.readdir++; return { files: [{ name: 'abcdef123456.webp' }] }; },
    stat: async () => ({ mtime: old, size: 100 }),
    deleteFile: async ({ path }) => { calls.deleted.push(path); },
  };
  return { FS, calls };
};
test('Rev 295 / 4-1: load() gagal menandai wasLoadFailure; load() sukses menghapus penanda', () => {
  const st = fake(); st.setItem(S.KEY, '{rusak');
  S.load(st); assert.equal(S.wasLoadFailure(), true);
  S.load(fake()); assert.equal(S.wasLoadFailure(), false);
});
test('Rev 295 / 4-1: salinan _rusak yang sudah ada TIDAK ditimpa (yang tertua disimpan)', () => {
  const st = fake(); st.setItem(S.KEY, '{rusak1'); S.load(st);
  assert.equal(st.getItem(S.KEY + '_rusak'), '{rusak1');
  st.setItem(S.KEY, '{rusak2'); S.load(st);
  assert.equal(st.getItem(S.KEY + '_rusak'), '{rusak1');
});
test('Rev 295 / 4-1: gagal-muat -> cleanupOrphanImages dan clearUnusedImages tidak menghapus apa pun; muat sukses -> pembersihan berjalan seperti biasa', async () => {
  const { FS, calls } = mockFS();
  globalThis.Capacitor = { registerPlugin: () => FS };
  try {
    const st = fake(); st.setItem(S.KEY, '{rusak'); const d = S.load(st);
    const r1 = await GA.cleanupOrphanImages(d); assert.equal(r1.removed, 0); assert.equal(calls.readdir, 0); assert.equal(calls.deleted.length, 0);
    const r2 = await GA.clearUnusedImages(d, Date.now(), FS); assert.equal(r2.removed, 0); assert.equal(calls.deleted.length, 0);
    const ok = S.load(fake());
    const r3 = await GA.cleanupOrphanImages(ok); assert.ok(calls.readdir >= 1); assert.equal(r3.removed, 1); assert.equal(calls.deleted.length, 1);
  } finally { delete globalThis.Capacitor; }
});
test('Rev 295 / 7-1: log gagal-muat hanya memuat nama galat, bukan pesan (bisa berisi potongan catatan)', () => {
  const logs = []; const orig = console.error; console.error = (...a) => logs.push(a);
  try { const st = fake(); st.setItem(S.KEY, '{"notes":"RAHASIA-CATATAN" x'); S.load(st); } finally { console.error = orig; }
  assert.ok(logs.length >= 1);
  assert.ok(!JSON.stringify(logs).includes('RAHASIA-CATATAN'));
  assert.equal(logs[0][1], 'SyntaxError');
});
test('Rev 295 / 4-2: replaceData mengganti habitLog; cadangan lama tanpa habitLog = kosong', () => {
  const target = S.emptyData(); target.habitLog = [{ d: '2026-11-01', done: 1, total: 2 }];
  const src1 = S.emptyData(); src1.habitLog = [{ d: '2026-10-01', done: 2, total: 3 }];
  L.replaceData(target, src1); assert.deepEqual(target.habitLog, [{ d: '2026-10-01', done: 2, total: 3 }]);
  const lama = S.emptyData(); delete lama.habitLog; L.replaceData(target, lama); assert.deepEqual(target.habitLog, []);
});
test('Rev 295: sumber memuat penjaga satu titik + toast; tiga pemanggil cleanupOrphanImages(data) tidak berubah', () => {
  assert.match(src('src/js/gambar-app.js'), /export async function cleanupOrphanImages\(data, now = Date\.now\(\)\) \{\n  if \(wasLoadFailure\(\)\)/);
  assert.match(src('src/js/main.js'), /wasLoadFailure\(\)\) setTimeout\(\(\) => t(?:Ok|Warn|Err|Info)\('Data gagal dibaca/);
  assert.ok(src('src/js/main.js').includes('cleanupOrphanImages(data)')); assert.ok(src('src/js/settings.js').includes('cleanupOrphanImages(data)'));
});
