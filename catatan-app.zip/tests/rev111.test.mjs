// Rev 111 / U6c: Enter / Backspace / Delete lengkap di bagian lipat (beforeinput, pola kotak centang Rev 108).
// Perilaku DOM nyata (Enter/Backspace/Delete dengan keyboard sungguhan, pengaman fold tertutup, Urungkan) dicek di Chromium 360x800
// saat revisi dibuat (29 pemeriksaan); tes Node ini mengunci fungsi murni (DOM mini) dan kontrak kode.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { isBlankBlock, isPlainRow, caretStartOf, endOfHead } from '../src/js/lipat.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const notes = src('src/js/notes.js'), lipat = src('src/js/lipat.js');

// DOM mini (cukup untuk fungsi murni)
class N {
  constructor(type, tag, data) { this.nodeType = type; this.tagName = tag; this.data = data; this.childNodes = []; this.className = ''; this.parentNode = null; }
  get firstChild() { return this.childNodes[0] || null; }
  get lastChild() { return this.childNodes[this.childNodes.length - 1] || null; }
  get textContent() { return this.nodeType === 3 ? this.data : this.childNodes.map((c) => c.textContent).join(''); }
  append(...k) { for (const c of k) { c.parentNode = this; this.childNodes.push(c); } }
  querySelector(sel) { const want = sel.split(',').map((x) => x.trim().toUpperCase()); const walk = (n) => { for (const c of n.childNodes) { if (c.nodeType === 1 && (want.includes(c.tagName) || walk(c))) return c; } return null; }; return walk(this); }
}
const el = (t, ...k) => { const e = new N(1, t.toUpperCase()); e.append(...k); return e; };
const tx = (d) => new N(3, undefined, d);

test('Rev 111: lipat.js mengekspor fungsi U6c dan tetap bebas penyimpanan/native/Intl/eval', async () => {
  const m = await import('../src/js/lipat.js');
  for (const k of ['isBlankBlock', 'isPlainRow', 'caretStartOf', 'endOfHead', 'bodyRowOf', 'exitFoldFromBody', 'unfoldToParagraph', 'mergeFirstRowIntoHead', 'foldHead', 'foldBody']) assert.equal(typeof m[k], 'function', k);
  assert.doesNotMatch(lipat, /localStorage|AndroidAPI|Intl\.|eval\(|new Function/);
});
test('Rev 111: isBlankBlock = tanpa teks/gambar/tabel/kotak (spasi, nbsp, <br> dianggap kosong)', () => {
  assert.equal(isBlankBlock(el('p', el('br'))), true);
  assert.equal(isBlankBlock(el('p', tx(' \u00a0\u200b'))), true);
  assert.equal(isBlankBlock(el('p', tx('a'))), false);
  assert.equal(isBlankBlock(el('p', el('img'))), false);
  assert.equal(isBlankBlock(el('div', el('input'))), false);
  assert.equal(isBlankBlock(null), false);
});
test('Rev 111: isPlainRow = <p> atau <div> tanpa kelas saja (kotak centang, blok pulau, lipat bukan baris biasa)', () => {
  assert.equal(isPlainRow(el('p')), true);
  assert.equal(isPlainRow(el('div')), true);
  const todo = el('div'); todo.className = 'todo'; assert.equal(isPlainRow(todo), false);
  const mood = el('div'); mood.className = 'mood-block'; assert.equal(isPlainRow(mood), false);
  assert.equal(isPlainRow(el('ul')), false); assert.equal(isPlainRow(el('blockquote')), false); assert.equal(isPlainRow(el('table')), false);
  assert.equal(isPlainRow(tx('x')), false);
});
test('Rev 111: caretStartOf dan endOfHead memberi titik kursor yang benar (teks, judul kosong)', () => {
  const t = tx('Judul'); const fh = el('div', t);
  assert.deepEqual([endOfHead(fh).node === t, endOfHead(fh).offset], [true, 5]);
  const em = tx('tebal'); const fh2 = el('div', tx('a '), el('b', em));
  assert.deepEqual([endOfHead(fh2).node === em, endOfHead(fh2).offset], [true, 5], 'akhir teks terdalam');
  const empty = el('div', el('br')); assert.deepEqual([endOfHead(empty).node === empty, endOfHead(empty).offset], [true, 0]);
  const p = el('p', tx('abc')); assert.deepEqual([caretStartOf(p).node === p.firstChild, caretStartOf(p).offset], [true, 0]);
  const pe = el('p', el('br')); assert.deepEqual([caretStartOf(pe).node === pe, caretStartOf(pe).offset], [true, 0]);
});
test('Rev 111: aturan Enter di isi (hanya baris isi biasa, kosong, TERAKHIR; baris tunggal dipertahankan; paragraf kosong sesudah dipakai ulang)', () => {
  const f = lipat.slice(lipat.indexOf('export function exitFoldFromBody'), lipat.indexOf('export function unfoldToParagraph'));
  assert.match(f, /!isPlainRow\(row\) \|\| !isBlankBlock\(row\) \|\| row !== fb\.lastElementChild\) return null/);
  assert.match(f, /if \(fb\.children\.length > 1\) row\.remove\(\)/);
  assert.match(f, /nx && isPlainRow\(nx\) && isBlankBlock\(nx\) \? nx : null/);
  assert.match(f, /fold\.after\(p\)/);
});
test('Rev 111: Backspace di awal judul = flattenFold; isi yang hanya baris kosong dibuang; Delete = gabung hanya bila terbuka + baris biasa', () => {
  const u = lipat.slice(lipat.indexOf('export function unfoldToParagraph'), lipat.indexOf('export function mergeFirstRowIntoHead'));
  assert.match(u, /kids\.every\(\(k\) => isPlainRow\(k\) && isBlankBlock\(k\)\)\) kids\.forEach\(\(k\) => k\.remove\(\)\)/);
  assert.match(u, /caretStartOf\(flattenFold\(fold, doc\)\)/);
  const m = lipat.slice(lipat.indexOf('export function mergeFirstRowIntoHead'));
  assert.match(m, /!isFoldOpen\(fold\)\) return null/);
  assert.match(m, /if \(!isPlainRow\(row\)\) return null/);
  assert.match(m, /c\.tagName === 'BR'\) continue/);
  assert.match(m, /if \(!fb\.firstElementChild\) fb\.append\(emptyPara\(doc\)\)/);
  assert.match(m, /healFold\(fold, doc\)/);
});
test('Rev 111: pengendali beforeinput U6c dipasang SESUDAH pengendali kotak centang dan sebelum pemulih input; melewati defaultPrevented, mode Baca, IME', () => {
  const a = notes.indexOf('// Rev 109 / U6a: Enter di judul bagian lipat');
  const b = notes.indexOf('// Rev 111 / U6c: Enter / Backspace / Delete lengkap di bagian lipat');
  const c = notes.indexOf("ed.addEventListener('input', () => { healTodos();");
  const todoH = notes.indexOf('if (!row || row === ed || !ed.contains(row) || !boxOf(row)) return; // baris yatim');
  assert.ok(a > 0 && todoH > a && b > todoH && c > b, 'urutan pengendali');
  const h = notes.slice(b, c);
  assert.match(h, /if \(e\.defaultPrevented \|\| o\.classList\.contains\('ed-baca'\) \|\| e\.isComposing \|\| composing\) return;/);
  assert.match(h, /if \(!sl \|\| !sl\.rangeCount \|\| !sl\.isCollapsed\) return;/);
});
test('Rev 111: tiap tindakan menyimpan satu langkah Undo (flushHist sebelum dan sesudah) dan mereset rng', () => {
  const b = notes.indexOf('// Rev 111 / U6c'); const h = notes.slice(b, notes.indexOf("ed.addEventListener('input', () => { healTodos();"));
  assert.match(h, /const apply = \(c\) => \{/);
  assert.match(h, /rng = null; ed\.dispatchEvent\(new Event\('input', \{ bubbles: true \}\)\); flushHist\(\);\s*\};/);
  assert.equal((h.match(/e\.preventDefault\(\); flushHist\(\);/g) || []).length, 3, 'Backspace judul, Delete judul, Enter isi');
});
test('Rev 111: kasus judul (Backspace di awal, Delete di akhir) dan isi (Enter kosong terakhir, Backspace awal isi pertama)', () => {
  const b = notes.indexOf('// Rev 111 / U6c'); const h = notes.slice(b, notes.indexOf("ed.addEventListener('input', () => { healTodos();"));
  assert.match(h, /if \(isBack && !textBetween\(fh, 0, nd, off\)\.length\) \{ e\.preventDefault\(\); flushHist\(\); apply\(unfoldToParagraph\(fold, document\)\); return; \}/);
  assert.match(h, /endR\.setStart\(nd, off\); endR\.setEnd\(fh, fh\.childNodes\.length\);/);
  assert.match(h, /const c = mergeFirstRowIntoHead\(fold, document\);\s*if \(c\) apply\(c\);/);
  assert.match(h, /if \(!isPlainRow\(br\.row\)\) return;/);
  assert.match(h, /isEnter && isBlankBlock\(br\.row\) && br\.row === br\.fb\.lastElementChild/);
  assert.match(h, /isBack && br\.row === br\.fb\.firstElementChild && !textBetween\(br\.row, 0, nd, off\)\.length\) \{\s*e\.preventDefault\(\); toHeadEnd\(br\.fold\);/);
});
test('Rev 111: pengaman data fold TERTUTUP (Backspace di blok biasa tepat sesudahnya ditahan, kursor ke akhir judul; Delete di akhir judul ditahan)', () => {
  const b = notes.indexOf('// Rev 111 / U6c'); const h = notes.slice(b, notes.indexOf("ed.addEventListener('input', () => { healTodos();"));
  assert.match(h, /pv && isFold\(pv\) && !isFoldOpen\(pv\) && isPlainRow\(blk\) && !textBetween\(blk, 0, nd, off\)\.length\) \{\s*e\.preventDefault\(\); toHeadEnd\(pv\);/);
  // Delete di akhir judul SELALU ditahan (bawaan Chromium menghapus isi tersembunyi); gabung hanya lewat mergeFirstRowIntoHead
  assert.match(h, /e\.preventDefault\(\); flushHist\(\);\s*const c = mergeFirstRowIntoHead/);
});
test('Rev 111: import notes.js memuat semua fungsi baru; pengendali U6a (Enter di judul) tidak berubah', () => {
  const imp = notes.split('\n').find((l) => l.startsWith("import { healAllFolds"));
  for (const k of ['isFoldOpen', 'bodyRowOf', 'isPlainRow', 'isBlankBlock', 'foldHead', 'endOfHead', 'exitFoldFromBody', 'unfoldToParagraph', 'mergeFirstRowIntoHead']) assert.ok(imp.includes(k), k);
  assert.match(notes, /const fh = headOf\(sl\.anchorNode, ed\); if \(!fh\) return;\s*e\.preventDefault\(\); flushHist\(\);\s*const first = openToBody\(fh\.parentElement, document\);/);
});
test('Rev 111: versi 0.3.121, SCHEMA 10, native dan dependensi tidak berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(pk.scripts.test.includes('node tests/rev110.test.mjs && node tests/rev111.test.mjs'));
});
