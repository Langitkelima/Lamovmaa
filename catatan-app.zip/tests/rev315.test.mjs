// Rev 315 / PART A1: token gerak terpusat + reduced-motion juga untuk @keyframes. Tampilan TIDAK berubah (token belum dipakai komponen).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
test('Rev 315: token gerak ada di :root (pegas = pilihan pengguna)', () => {
  for (const k of ['--g1:120ms', '--g2:200ms', '--g3:380ms', '--ease-o:cubic-bezier(.2,.7,.2,1)', '--ease-p:cubic-bezier(.34,1.56,.64,1)']) assert.ok(css.includes(k), k);
});
test('Rev 315: reduced-motion mematikan transisi DAN mempercepat animasi (animationend tetap terbit)', () => {
  const m = css.match(/@media \(prefers-reduced-motion:reduce\)\{\*,\*::before,\*::after\{[^}]*\}\}/);
  assert.ok(m, 'aturan global tidak ada');
  for (const p of ['transition:none!important', 'animation-duration:.01ms!important', 'animation-iteration-count:1!important']) assert.ok(m[0].includes(p), p);
  assert.ok(!/animation:\s*none/.test(m[0]), 'animation:none akan menghilangkan animationend (langit.js memakainya)');
});
test('Rev 315: semua @keyframes dipakai (tanpa yatim); tw lewat variabel --tw1/--tw2', () => {
  const names = [...css.matchAll(/@keyframes ([\w-]+)/g)].map((x) => x[1]);
  assert.ok(names.length >= 19);
  for (const n of names) assert.ok(new RegExp('(animation[^;{}]*|--tw\\d:[^;{}]*)\\b' + n + '\\b').test(css.replace(/@keyframes[^{]+\{/g, '')), 'yatim: ' + n);
});
test('Rev 315: versi dan SCHEMA tidak berubah', () => {
  assert.ok(readFileSync(new URL('../package.json', import.meta.url), 'utf8').includes('"version": "0.3.121"'));
  assert.ok(readFileSync(new URL('../src/js/storage.js', import.meta.url), 'utf8').includes('export const SCHEMA = 22;'));
});
