// Rev 241 / Tahap 9b: pilihan Batas bulanan di aplikasi (Setelan > Kelimaa AI) dan pengirimannya ke Worker Rev 240. HP/WebView tidak diuji (hanya Node + DOM tiruan).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as K from '../src/js/ai/sambungan.js';
import W from '../backend/cloudflare/worker.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mem = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };
const conn = { url: 'https://kelimaa-ai.akun.workers.dev', key: 'rama-secret-12' };
const okRes = (o) => async (r) => ({ status: 200, text: JSON.stringify({ ok: true, text: 'Jawab', model: 'm', provider: 'gemini', used: 1, limit: 100, ...o }) });
test('cleanMonthLimit: angka >= 1 dibulatkan ke bawah, maks. 100000; selain itu 0 (mati)', () => {
  for (const v of [undefined, null, '', 0, '0', -5, 'abc', NaN, Infinity]) assert.equal(K.cleanMonthLimit(v), 0, String(v));
  assert.equal(K.cleanMonthLimit(3000), 3000); assert.equal(K.cleanMonthLimit('1500'), 1500); assert.equal(K.cleanMonthLimit(7.9), 7); assert.equal(K.cleanMonthLimit(1e9), 100000);
  assert.deepEqual(K.MONTH_CHOICES.map((c) => c[0]), [0, 1500, 3000, 6000]);
});
test('cfg: bawaan TIDAK punya monthLimit (bentuk lama utuh); disimpan hanya bila aktif; 0 menghapusnya; data rusak dibersihkan', () => {
  const s = mem(); assert.equal('monthLimit' in K.loadCfg(s), false);
  K.saveCfg({ ...K.loadCfg(s), monthLimit: 3000 }, s); assert.equal(K.loadCfg(s).monthLimit, 3000); assert.deepEqual(K.chatOpts(K.loadCfg(s)), { provider: '', model: '', limit: 100, monthLimit: 3000 });
  K.saveCfg({ ...K.loadCfg(s), monthLimit: 0 }, s); assert.equal('monthLimit' in K.loadCfg(s), false); assert.deepEqual(K.chatOpts(K.loadCfg(s)), { provider: '', model: '', limit: 100 });
  s.setItem('kelimaa_ai_cfg', 'x'); assert.equal('monthLimit' in K.loadCfg(s), false);
  K.saveCfg({ monthLimit: 'banyak' }, s); assert.equal('monthLimit' in K.loadCfg(s), false);
});
test('pilihanText menyebut batas bulanan hanya bila aktif', () => {
  assert.doesNotMatch(K.pilihanText({}), /bulan/); assert.match(K.pilihanText({ monthLimit: 3000 }), /batas 100\/hari \u00b7 bulan 3000$/);
});
test('kirimChat dan kirimRiset: monthLimit ikut permintaan HANYA bila aktif; tanpa itu isi permintaan sama persis seperti sebelumnya', async () => {
  let body; const http = async (r) => { body = JSON.parse(r.body); return okRes({})(r); };
  await K.kirimChat(conn, [{ role: 'user', content: 'a' }], http, { limit: 100 }); assert.equal('monthLimit' in body, false);
  await K.kirimChat(conn, [{ role: 'user', content: 'a' }], http, { limit: 100, monthLimit: 3000 }); assert.equal(body.monthLimit, 3000);
  await K.kirimChat(conn, [{ role: 'user', content: 'a' }], http, { monthLimit: 'rusak' }); assert.equal('monthLimit' in body, false);
  await K.kirimRiset(conn, [{ role: 'user', content: 'a' }], http, { limit: 100 }); assert.equal('monthLimit' in body, false); assert.equal(body.action, 'research');
  await K.kirimRiset(conn, [{ role: 'user', content: 'a' }], http, { limit: 100, monthLimit: 1500 }); assert.equal(body.monthLimit, 1500);
});
test('hasil: monthUsed/monthLimit dibawa bila Worker mengirimnya; tidak ada bila tidak; galat bulanan diteruskan apa adanya', async () => {
  const a = await K.kirimChat(conn, [{ role: 'user', content: 'a' }], okRes({ monthUsed: 5, monthLimit: 3000 }), {}); assert.equal(a.monthUsed, 5); assert.equal(a.monthLimit, 3000);
  const b = await K.kirimChat(conn, [{ role: 'user', content: 'a' }], okRes({}), {}); assert.equal('monthUsed' in b, false);
  const c = await K.kirimRiset(conn, [{ role: 'user', content: 'a' }], okRes({ sources: [], monthUsed: 2, monthLimit: 1500 }), {}); assert.equal(c.monthUsed, 2); assert.equal(c.monthLimit, 1500);
  const e = await K.kirimChat(conn, [{ role: 'user', content: 'a' }], async () => ({ status: 429, text: JSON.stringify({ ok: false, error: 'Batas bulanan tercapai (3000/3000). Naikkan atau matikan batas bulanan di Setelan > Kelimaa AI, atau tunggu bulan depan.' }) }), {});
  assert.equal(e.ok, false); assert.match(e.msg, /Batas bulanan tercapai \(3000\/3000\)/);
});
test('tes sambungan: monthUsed dari Worker tampil di info dan catatan; Worker lama tanpa monthUsed tetap rapi', async () => {
  const mk = (o) => async (r) => (r.method === 'GET' ? { status: 200, text: '{"ok":true,"app":"KELIMAA AI","v":1}' } : { status: 200, text: JSON.stringify({ ok: true, me: 'rama', limit: 100, used: 4, kv: true, ai: true, ...o }) });
  const r = await K.testConnection(conn, mk({ monthUsed: 12 })); assert.equal(r.ok, true); assert.equal(r.info.monthUsed, 12); assert.match(r.steps[2].msg, /Terpakai hari ini: 4; bulan ini: 12/);
  const o = await K.testConnection(conn, mk({})); assert.equal(o.info.monthUsed, null); assert.doesNotMatch(o.steps[2].msg, /bulan ini/);
});
test('ujung ke ujung dengan Worker asli (fetch palsu): batas bulanan dari aplikasi dihormati', async () => {
  const m = new Map(), KV = { get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } };
  const env = { PASS_RAMA: 'rama-secret-12', KV, GEMINI_KEY: 'gm-FAKE-0123456789-tes' };
  const GOOD = { candidates: [{ content: { role: 'model', parts: [{ text: 'Jawab.' }] }, finishReason: 'STOP' }], usageMetadata: {} };
  const orig = globalThis.fetch; globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => GOOD });
  const http = async (r) => { const res = await W._t.handle(new Request(r.url, { method: 'POST', body: r.body }), env, Date.UTC(2026, 10, 12, 5)); return { status: res.status, text: await res.text() }; };
  try {
    const msgs = [{ role: 'user', content: 'Tes?' }], opts = { limit: 100, monthLimit: 1500 };
    const a = await K.kirimRiset(conn, msgs, http, opts); assert.equal(a.ok, true); assert.equal(a.monthUsed, 1); assert.equal(a.monthLimit, 1500);
    m.set('mon:rama:2026-11', '1500'); const b = await K.kirimRiset(conn, msgs, http, opts); assert.equal(b.ok, false); assert.match(b.msg, /Batas bulanan tercapai \(1500\/1500\)/);
    const c = await K.kirimRiset(conn, msgs, http, { limit: 100 }); assert.equal(c.ok, true); assert.equal('monthUsed' in c, false);
  } finally { globalThis.fetch = orig; }
});
test('layar dan obrolan: tombol Batas bulanan memakai keep({ monthLimit }), catatan jujur; riset ikut mengirim monthLimit; status "bulan ini x/y"; versi 0.3.121; tes terdaftar', () => {
  const l = src('src/js/ai/layar.js'); assert.match(l, /MONTH_CHOICES/); assert.match(l, /keep\(\{ monthLimit: n \}\)/); assert.match(l, /stk\('BATAS BULANAN'\)/); assert.match(l, /bawaan mati/); assert.match(l, /1 penulisan KV tambahan/);
  const o = src('src/js/ai/obrolan.js'); assert.match(o, /monthLimit: chatOpts\(loadCfg\(\)\)\.monthLimit/); assert.match(o, /'bulan ini ' \+ res\.monthUsed \+ '\/' \+ res\.monthLimit/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev241\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
});
