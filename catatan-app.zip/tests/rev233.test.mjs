// Rev 233 / Tahap 6c: Search Suggestions Google (wajib menurut dokumentasi resmi ai.google.dev, dibaca 12 Nov 2026). Semua tes memakai fetch PALSU; bentuk jawaban = bentuk dari dokumentasi (searchEntryPoint.renderedContent), BUKAN bukti dari server nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
import { cleanSuggest, googleLink, researchExtras, MAX_SUGGEST } from '../src/js/ai/riset.js';
import { normMsgs } from '../src/js/ai/ruang.js';
import { buildMessages } from '../src/js/ai/sambungan.js';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const GK = 'gm-FAKE-0123456789-tes';
const env0 = () => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), GEMINI_KEY: GK });
const NOW = Date.UTC(2026, 10, 12, 5, 0, 0);
const post = (b) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify(b) });
const req = () => ({ key: 'rama-secret-12', action: 'research', messages: [{ role: 'user', content: 'Siapa juara Euro 2024?' }] });
const HTML = '<style>.c{font:14px sans-serif}</style><div class="c"><a class="chip" href="https://www.google.com/search?q=UEFA+Euro+2024+winner">UEFA Euro 2024 winner</a></div>';
const reply = (rc) => ({ ok: true, status: 200, json: async () => ({ candidates: [{ content: { role: 'model', parts: [{ text: 'Spanyol juara.' }] }, groundingMetadata: { webSearchQueries: ['q'], groundingChunks: [{ web: { uri: 'https://vertexaisearch.cloud.google.com/x/1', title: 'uefa.com' } }], ...(rc === undefined ? {} : { searchEntryPoint: { renderedContent: rc } }) } }] }) });
async function run(fn) { const orig = globalThis.fetch; globalThis.fetch = async () => fn(); try { const r = await T.handle(post(req()), env0(), NOW); const raw = await r.text(); return { status: r.status, j: JSON.parse(raw), raw }; } finally { globalThis.fetch = orig; } }

test('Worker: renderedContent dikembalikan APA ADANYA sebagai `suggest`; kunci tak bocor', async () => {
  const r = await run(() => reply(HTML)); assert.equal(r.j.ok, true); assert.equal(r.j.suggest, HTML); assert.equal(r.j.grounded, true); assert.ok(!r.raw.includes(GK));
});
test('Worker: tanpa searchEntryPoint / terlalu besar / berisi skrip atau bingkai = suggest kosong (tidak pernah dipotong atau diubah)', async () => {
  assert.equal((await run(() => reply(undefined))).j.suggest, '');
  assert.equal((await run(() => reply('x'.repeat(16001)))).j.suggest, '');
  assert.equal((await run(() => reply('a'.repeat(16000)))).j.suggest, 'a'.repeat(16000));
  assert.equal((await run(() => reply('<div></div><script>alert(1)</script>'))).j.suggest, '');
  assert.equal((await run(() => reply('<IFRAME src="https://x.example"></IFRAME>'))).j.suggest, '');
  assert.equal((await run(() => reply(42))).j.suggest, '');
});
test('cleanSuggest: lolos apa adanya; bukan teks, kosong, > batas, atau skrip/bingkai/objek/base/meta = kosong', () => {
  assert.equal(cleanSuggest(HTML), HTML); assert.equal(MAX_SUGGEST, 16000);
  for (const bad of [null, undefined, 5, {}, '', '   ', 'x'.repeat(16001), '<script>1</script>', '<iframe></iframe>', '<object></object>', '<embed src=x>', '<base href="https://x.example/">', '<meta http-equiv="refresh" content="0;url=https://x.example">']) assert.equal(cleanSuggest(bad), '', String(bad).slice(0, 30));
});
test('googleLink: hanya https ke google.com; peniru domain, http, skema lain, dan teks bukan-string ditolak', () => {
  assert.equal(googleLink('https://www.google.com/search?q=a+b'), 'https://www.google.com/search?q=a+b'); assert.equal(googleLink('https://google.com/'), 'https://google.com/');
  for (const bad of ['http://www.google.com/search?q=a', 'https://www.google.com.evil.example/search', 'https://google.com@evil.example/', 'https://evil.example/?u=https://www.google.com/', 'javascript:alert(1)', 'intent://x#Intent;end', '', null, undefined, 'https://www.google.com/ a', 'https://www.google.com/' + 'a'.repeat(2000)]) assert.equal(googleLink(bad), '', String(bad).slice(0, 40));
});
test('researchExtras: sumber sah + saran sah; tanpa keduanya = objek kosong', () => {
  const x = researchExtras({ sources: [{ title: 'uefa.com', uri: 'https://v.example/1' }, { title: 'x', uri: 'http://x.example' }], suggest: HTML }); assert.deepEqual(x, { src: [{ title: 'uefa.com', uri: 'https://v.example/1' }], sg: HTML });
  assert.deepEqual(researchExtras({ sources: [], suggest: '' }), {}); assert.deepEqual(researchExtras(null), {});
});
test('normMsgs: balasan asisten menyimpan src + sg yang sah (tetap tampil saat riwayat dibuka lagi); pesan pengguna dan data rusak tidak membawanya', () => {
  const m = normMsgs([{ role: 'user', content: 'tanya', t: '10:00', src: [{ title: 'a', uri: 'https://a.example/1' }], sg: HTML }, { role: 'assistant', content: 'jawab', t: '10:01', src: [{ title: 'uefa.com', uri: 'https://v.example/1' }, { title: 'j', uri: 'javascript:1' }], sg: HTML }, { role: 'user', content: 'lagi' }, { role: 'assistant', content: 'jawab2', sg: '<script>1</script>', src: 'bukan larik' }]);
  assert.equal(m.length, 4); assert.equal(m[0].sg, undefined); assert.equal(m[0].src, undefined);
  assert.deepEqual(m[1].src, [{ title: 'uefa.com', uri: 'https://v.example/1' }]); assert.equal(m[1].sg, HTML);
  assert.equal(m[3].sg, undefined); assert.equal(m[3].src, undefined);
});
test('buildMessages: yang dikirim ke Worker hanya role + content (src/sg tidak ikut)', () => {
  const out = buildMessages([{ role: 'user', content: 'a' }, { role: 'assistant', content: 'b', src: [{ title: 't', uri: 'https://v.example/1' }], sg: HTML }], 'c'); assert.deepEqual(out.map((x) => Object.keys(x).sort()), [['content', 'role'], ['content', 'role'], ['content', 'role']]);
  assert.ok(!JSON.stringify(out).includes('google.com/search'));
});
test('kabel obrolan.js: iframe saran tanpa izin skrip, tautan hanya lewat googleLink, tersimpan di riwayat, CSS ada', () => {
  const ob = src('src/js/ai/obrolan.js'), css = src('src/css/styles.css');
  for (const k of ["const kartuSaran = (el, html)", "sandbox: 'allow-same-origin'", "f.srcdoc = sg", "googleLink(a.href)", "const ekstraBot", "researchExtras(res)", "...ex }", "ekstraBot(w, ex)", "m.role === 'assistant' ? m : null", "kc-sg", "saran pencarian Google tidak dikembalikan"]) assert.ok(ob.includes(k), k);
  assert.doesNotMatch(ob, /allow-scripts|allow-top-navigation|allow-popups/); assert.doesNotMatch(ob, /innerHTML|insertAdjacentHTML|outerHTML/);
  assert.ok(css.includes('.kc .kc-sg{') && css.includes('.kc .kc-sgf{') && /\.kc-sgf\{[^}]*width:100%/.test(css));
  const w = src('backend/cloudflare/worker.mjs'); assert.ok(w.includes('searchEntryPoint') && w.includes('MAX_SUGGEST = 16000'));
});
test('versi 0.3.121 dan SCHEMA 18 tetap; tes terdaftar di package.json', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.ok(src('package.json').includes('node tests/rev233.test.mjs'));
  assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/);
});
