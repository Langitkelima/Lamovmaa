// Rev 333 / PART TE: aria-live toast (err = assertive, lainnya polite), penutup Paket Toast.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const ui = readFileSync(new URL('../src/js/ui.js', import.meta.url), 'utf8');
test('Rev 333: toast punya aria-live menurut nada', () => {
  assert.match(ui, /'aria-live': tone === 'err' \? 'assertive' : 'polite'/);
  assert.match(ui, /'aria-atomic': 'true'/);
});
test('Rev 333: role tetap alert untuk err/warn dan status untuk lainnya', () => {
  assert.match(ui, /role: tone === 'err' \|\| tone === 'warn' \? 'alert' : 'status'/);
});
test('Rev 333: durasi menurut nada dan panjang tetap dalam batas', async () => {
  const { toastMs } = await import('../src/js/ui.js').catch(() => ({}));
  if (!toastMs) return; // ui.js butuh DOM; batas dicek lewat sumber
  assert.ok(toastMs('a', 'err') >= 8000 && toastMs('x'.repeat(900), 'info') <= 14000);
});
