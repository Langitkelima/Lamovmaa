// Rev 202b / v0.3.121: layar CHAT UMUM Kelimaa AI (logika murni di ai/sambungan.js, layar di ai/obrolan.js, dimuat malas). Semua tes memakai pengirim HTTP PALSU (tanpa jaringan, tanpa kunci asli).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as S from '../src/js/ai/sambungan.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const CONN = { url: 'https://kelimaa-ai.contoh.workers.dev', key: 'passcode-uji-123' };
const ok = (o, status = 200) => async () => ({ status, text: JSON.stringify(o) });

test('cleanChatInput: kosong ditolak, terlalu panjang ditolak, spasi dipangkas', () => {
  assert.equal(S.cleanChatInput('   ').ok, false); assert.equal(S.cleanChatInput(null).ok, false);
  assert.equal(S.cleanChatInput('x'.repeat(4001)).ok, false);
  assert.deepEqual(S.cleanChatInput('  halo  '), { ok: true, value: 'halo' });
  assert.equal(S.cleanChatInput('x'.repeat(4000)).ok, true);
});
test('buildMessages: mulai dari pengguna, berakhir pengguna, maks. 12, tiap pesan dipotong 4000', () => {
  const hist = []; for (let i = 0; i < 10; i++) hist.push({ role: 'user', content: 'u' + i }, { role: 'assistant', content: 'a' + i });
  const m = S.buildMessages(hist, 'baru'); assert.ok(m.length <= 12); assert.equal(m[0].role, 'user'); assert.deepEqual(m[m.length - 1], { role: 'user', content: 'baru' });
  for (let i = 1; i < m.length; i++) assert.notEqual(m[i].role, m[i - 1].role);
  const panjang = S.buildMessages([{ role: 'user', content: 'a' }, { role: 'assistant', content: 'z'.repeat(9000) }], 'lanjut'); assert.equal(panjang[1].content.length, 4000);
  assert.deepEqual(S.buildMessages(null, 'hai'), [{ role: 'user', content: 'hai' }]);
  assert.deepEqual(S.buildMessages([{ role: 'assistant', content: 'sisa' }], 'hai'), [{ role: 'user', content: 'hai' }]);
});
test('kirimChat berhasil: POST ke alamat Worker dengan key, action chat, task chat.general, messages; timeout 60 dtk', async () => {
  let seen; const http = async (q) => { seen = q; return { status: 200, text: JSON.stringify({ ok: true, text: 'Halo juga', model: 'm1', provider: 'gemini', used: 3, limit: 100 }) }; };
  const r = await S.kirimChat(CONN, [{ role: 'user', content: 'hai' }], http);
  assert.deepEqual(r, { ok: true, text: 'Halo juga', model: 'm1', provider: 'gemini', used: 3, limit: 100 });
  assert.equal(seen.method, 'POST'); assert.equal(seen.url, 'https://kelimaa-ai.contoh.workers.dev/'); assert.equal(seen.timeout, 60000);
  assert.deepEqual(JSON.parse(seen.body), { key: 'passcode-uji-123', action: 'chat', task: 'chat.general', messages: [{ role: 'user', content: 'hai' }] });
});
test('kirimChat galat: 401, batas harian (pesan Worker dipakai), jawaban tak dikenal, jaringan, waktu habis, masukan salah; tidak pernah melempar', async () => {
  const m = [{ role: 'user', content: 'hai' }];
  let r = await S.kirimChat(CONN, m, ok({ ok: false, error: 'Passcode salah' }, 401)); assert.equal(r.ok, false); assert.match(r.msg, /Passcode salah atau sudah berubah/);
  r = await S.kirimChat(CONN, m, ok({ ok: false, error: 'Batas harian tercapai (100/100). Coba lagi besok.' }, 429)); assert.match(r.msg, /Batas harian tercapai/);
  r = await S.kirimChat(CONN, m, ok({ ok: false, error: 'Penghitung pemakaian (KV) belum terpasang' }, 503)); assert.match(r.msg, /KV/);
  r = await S.kirimChat(CONN, m, async () => ({ status: 200, text: '<html>Hello World</html>' })); assert.match(r.msg, /tidak dikenali/);
  r = await S.kirimChat(CONN, m, ok({ ok: true, text: '   ' })); assert.equal(r.ok, false);
  r = await S.kirimChat(CONN, m, async () => { throw new Error('boom'); }); assert.match(r.msg, /Tidak tersambung/);
  r = await S.kirimChat(CONN, m, async () => { throw new Error('timeout'); }); assert.match(r.msg, /60 detik/);
  assert.equal((await S.kirimChat({ url: 'https://contoh.com', key: 'passcode-uji-123' }, m, ok({}))).ok, false);
  assert.equal((await S.kirimChat(CONN, [], ok({}))).ok, false);
});
test('struktur: layar chat dimuat malas lewat layar.js; teks balasan lewat node teks; tanpa HTML mentah; tanpa data aplikasi; tanpa penyimpanan', () => {
  const st = src('src/js/settings.js'); assert.doesNotMatch(st, /^import .*['"]\.\/ai\//m);
  assert.match(st, /export function viewKelimaaAI\(ctx\)/); /* Rev 215: rute dipindah ke tab AI di main.js */ assert.match(st, /aiMod\.viewChat\(ctx\)/);
  const ob = src('src/js/ai/obrolan.js');
  assert.doesNotMatch(ob, /innerHTML|insertAdjacentHTML|outerHTML|document\.write/); assert.doesNotMatch(ob, /localStorage|sessionStorage|Filesystem|catatan_app_data|\.priv|\.trash|\.notes|\.tasks|data\./);
  assert.match(ob, /isiBot\(w, isi\)/); assert.match(ob, /const isi = cari \? res\.shown : res\.text/); /* Rev 232: balasan riset memakai teks + baris sumber, tetap lewat isiBot (node teks) */ assert.match(ob, /'Hapus riwayat\?'/);
  assert.match(src('src/js/ai/layar.js'), /ui\.moreView = 'aichat'/); assert.match(src('src/js/ai/layar.js'), /export \{ viewChat \}/);
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\//); /* Rev 223: main.js kini tahu rute 'aichat' (chat layar penuh), tetapi tetap tidak mengimpor modul AI */ assert.doesNotMatch(src('src/js/startup.js'), /\/ai\/|aichat/);
  const lg = src('src/js/ai/sambungan.js'); assert.deepEqual([...lg.matchAll(/^import .*$/gm)].map((x) => x[0]), ["import { isNative, nativePlugin } from '../native.js';"]); assert.doesNotMatch(lg, /document\.|window\./);
});
test('versi 0.3.121, SCHEMA 18 tetap, tes terdaftar', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev208\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/);
});
