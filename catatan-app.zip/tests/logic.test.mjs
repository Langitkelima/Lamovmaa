import assert from 'node:assert/strict';
import * as L from '../src/js/logic.js';
import * as S from '../src/js/storage.js';

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const fake = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, v), _m: m }; };

t('todayISO memakai tanggal lokal', () => assert.equal(L.todayISO(new Date(2026, 9, 24)), '2026-10-24'));
t('dayOfWeek: 24 Okt 2026 = Sabtu', () => assert.equal(L.dayOfWeek('2026-10-24'), 6));
t('validateTitle menolak kosong dan spasi', () => { assert.equal(L.validateTitle('   ').ok, false); assert.equal(L.validateTitle(null).ok, false); });
t('validateTitle memangkas spasi', () => assert.equal(L.validateTitle('  Halo ').value, 'Halo'));
t('validateTitle menolak terlalu panjang', () => assert.equal(L.validateTitle('a'.repeat(121)).ok, false));
t('sortTasks: Penting dulu, lalu tenggat terdekat, tanpa tenggat terakhir', () => {
  const r = L.sortTasks([
    { id: 'a', pri: 0, due: '2026-10-25' }, { id: 'b', pri: 1, due: '2026-10-30' },
    { id: 'c', pri: 0, due: '' }, { id: 'd', pri: 1, due: '2026-10-26' }, { id: 'e', pri: 0, due: '2026-10-24' },
  ]).map((x) => x.id);
  assert.deepEqual(r, ['d', 'b', 'e', 'a', 'c']);
});
t('sortTasks tidak mengubah array asli', () => { const a = [{ id: 1, pri: 0 }, { id: 2, pri: 1 }]; L.sortTasks(a); assert.equal(a[0].id, 1); });
t('tasksByScope menyaring per bagian', () => assert.equal(L.tasksByScope([{ scope: 'hari' }, { scope: 'minggu' }], 'minggu').length, 1));
t('needsReset: hari kerja baru -> true', () => assert.equal(L.needsReset('2026-10-22', '2026-10-23', [1, 2, 3, 4, 5]), true));
t('needsReset: sudah direset hari ini -> false', () => assert.equal(L.needsReset('2026-10-23', '2026-10-23', [1, 2, 3, 4, 5]), false));
t('needsReset: bukan hari kerja (Sabtu) -> false', () => assert.equal(L.needsReset('2026-10-23', '2026-10-24', [1, 2, 3, 4, 5]), false));
t('needsReset: Sabtu jadi hari kerja -> true', () => assert.equal(L.needsReset('2026-10-23', '2026-10-24', [1, 2, 3, 4, 5, 6]), true));
t('resetHabits mengosongkan centang tanpa mengubah asli', () => {
  const a = [{ id: 1, done: true }]; const b = L.resetHabits(a);
  assert.equal(b[0].done, false); assert.equal(a[0].done, true);
});
t('storage: simpan lalu muat kembali sama', () => {
  const st = fake(); const d = S.emptyData(); d.tasks.push({ id: 'x', title: 'Tes' });
  assert.equal(S.save(d, st).ok, true);
  assert.equal(S.load(st).tasks[0].title, 'Tes');
});
t('storage: data kosong saat pertama dibuka', () => assert.deepEqual(S.load(fake()).tasks, []));
t('storage: data rusak -> aplikasi tetap jalan, salinan rusak diamankan', () => {
  const st = fake(); st.setItem(S.KEY, '{rusak');
  const d = S.load(st);
  assert.deepEqual(d.tasks, []); assert.equal(st.getItem(S.KEY + '_rusak'), '{rusak');
});
t('storage: gagal simpan memberi pesan, tidak crash', () => {
  const r = S.save(S.emptyData(), { setItem() { throw new Error('penuh'); } });
  assert.equal(r.ok, false); assert.match(r.msg, /Gagal menyimpan/);
});
t('storage: ekspor lalu impor sama', () => {
  const d = S.emptyData(); d.habits.push({ id: 'h', title: 'Matikan AC', done: false });
  const r = S.importJSON(S.exportJSON(d));
  assert.equal(r.ok, true); assert.equal(r.data.habits[0].title, 'Matikan AC');
});
t('storage: impor menolak berkas bukan JSON dan bentuk salah', () => {
  assert.equal(S.importJSON('bukan json').ok, false);
  assert.equal(S.importJSON('{"tasks":"salah"}').ok, false);
});
t('storage: data lama tanpa settings tetap dimuat dengan default', () => {
  const st = fake(); st.setItem(S.KEY, JSON.stringify({ version: 1, tasks: [] }));
  assert.deepEqual(S.load(st).settings.days, [1, 2, 3, 4, 5]);
});

// ---- Catatan ----
t('normalizeHex: variasi masukan', () => {
  assert.equal(L.normalizeHex('F4C2C2'), '#f4c2c2');
  assert.equal(L.normalizeHex('#F4C2C2'), '#f4c2c2');
  assert.equal(L.normalizeHex(' #abc '), '#aabbcc');
  assert.equal(L.normalizeHex('xyz123'), '');
  assert.equal(L.normalizeHex('#12345'), '');
  assert.equal(L.normalizeHex(''), '');
});
t('contrast: latar terang -> teks gelap, latar gelap -> teks terang, tidak valid -> null', () => {
  assert.equal(L.contrast('#fdebd6').ink, '#1E2A3D');
  assert.equal(L.contrast('#2f3e4e').ink, '#F2F5FB');
  assert.equal(L.contrast('merah'), null);
});
t('contrast: biru sedang (#56a0bf, kasus screenshot) -> ikon gelap, dan semua warna dijamin terbaca', () => {
  assert.equal(L.contrast('#56a0bf').ink, '#1E2A3D');
  let worst = 99, worstMut = 99;
  for (let r = 0; r < 256; r += 15) for (let g = 0; g < 256; g += 15) for (let b = 0; b < 256; b += 15) {
    const hx = '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('');
    const c = L.contrast(hx);
    worst = Math.min(worst, L.contrastRatio(c.ink, hx)); worstMut = Math.min(worstMut, L.contrastRatio(c.mut, hx));
  }
  assert.ok(worst >= 4.5, 'ink terburuk ' + worst);
  assert.ok(worstMut >= 3.0, 'mut terburuk ' + worstMut);
});
t('HSV <-> hex bolak-balik; hitam/putih/abu aman', () => {
  for (const hx of ['#ff0000', '#00ff00', '#0000ff', '#56a0bf', '#000000', '#ffffff', '#808080', '#f4c2c2']) {
    const v = L.hexToHsv(hx); assert.equal(L.hsvToHex(v.h, v.s, v.v), hx);
  }
  assert.equal(L.hexToHsv('zzz'), null);
  assert.equal(L.hsvToHex(360, 1, 1), '#ff0000');
});
t('saran warna: semua valid, terang -> teks gelap, gelap -> teks terang, kontras >= 7', () => {
  for (const [hx] of L.SUGGEST_LIGHT) { const c = L.contrast(hx); assert.equal(c.dark, true); assert.ok(L.contrastRatio(c.ink, hx) >= 7, hx); assert.ok(L.relLum(hx) > 0.6, hx + ' terlalu gelap untuk "lembut"'); }
  for (const [hx] of L.SUGGEST_DARK) { const c = L.contrast(hx); assert.equal(c.dark, false); assert.ok(L.contrastRatio(c.ink, hx) >= 7, hx); }
});
t('filterNotes: tidak peka huruf, cari judul dan isi, kosong = semua', () => {
  const ns = [{ title: 'Rapat Tim', text: 'target bulan depan' }, { title: 'Belanja', text: 'Kertas A4' }];
  assert.equal(L.filterNotes(ns, 'rapat').length, 1);
  assert.equal(L.filterNotes(ns, 'KERTAS').length, 1);
  assert.equal(L.filterNotes(ns, '  ').length, 2);
  assert.equal(L.filterNotes(ns, 'zzz').length, 0);
});
t('sortNotes: disematkan dulu, lalu terbaru; tidak mengubah array asli', () => {
  const a = [{ id: 1, pin: false, updated: 5 }, { id: 2, pin: true, updated: 1 }, { id: 3, pin: false, updated: 9 }];
  assert.deepEqual(L.sortNotes(a).map((x) => x.id), [2, 3, 1]);
  assert.equal(a[0].id, 1);
});
t('addRecent: terbaru di depan, tanpa duplikat, maksimal 8', () => {
  let r = []; for (const c of ['#000001', '#000002', '#000003']) r = L.addRecent(r, c);
  assert.deepEqual(r, ['#000003', '#000002', '#000001']);
  assert.deepEqual(L.addRecent(r, '#000002'), ['#000002', '#000003', '#000001']);
  let big = []; for (let i = 0; i < 12; i++) big = L.addRecent(big, '#0000' + (10 + i));
  assert.equal(big.length, 8);
});
t('storage: pengaturan lama tanpa recent dilengkapi', () => {
  const st = fake(); st.setItem(S.KEY, JSON.stringify({ version: 1, settings: { days: [1] } }));
  assert.deepEqual(S.load(st).settings.recent, []);
});
// ---- Pengaturan ----
const mk = () => S.emptyData();
t('toggleDay: menyala/mati dan selalu berurutan Sen..Min', () => {
  assert.deepEqual(L.toggleDay([1, 2, 3, 4, 5], 6), [1, 2, 3, 4, 5, 6]);
  assert.deepEqual(L.toggleDay([1, 2, 3, 4, 5, 6], 3), [1, 2, 4, 5, 6]);
  assert.deepEqual(L.toggleDay([1, 5], 0), [1, 5, 0]);
});
t('applyDailyReset: reset di hari kerja baru, tidak dua kali, dilewati di hari libur', () => {
  const d = mk(); d.habits = [{ id: 'a', title: 'AC', done: true }];
  assert.equal(L.applyDailyReset(d, '2026-10-23'), true);
  assert.equal(d.habits[0].done, false); assert.equal(d.settings.lastReset, '2026-10-23');
  d.habits[0].done = true;
  assert.equal(L.applyDailyReset(d, '2026-10-23'), false); assert.equal(d.habits[0].done, true);
  assert.equal(L.applyDailyReset(d, '2026-10-24'), false); assert.equal(d.habits[0].done, true);
  d.settings.days = [1, 2, 3, 4, 5, 6];
  assert.equal(L.applyDailyReset(d, '2026-10-24'), true); assert.equal(d.habits[0].done, false);
});
t('restoreFromTrash: tugas, kebiasaan, catatan kembali ke daftar yang benar', () => {
  const d = mk();
  d.trash = [{ kind: 'task', item: { id: 1 } }, { kind: 'habit', item: { id: 2 } }, { kind: 'note', item: { id: 3 } }];
  assert.equal(L.restoreFromTrash(d, 1), true); assert.equal(d.habits[0].id, 2); assert.equal(d.trash.length, 2);
  assert.equal(L.restoreFromTrash(d, 0), true); assert.equal(d.tasks[0].id, 1);
  assert.equal(L.restoreFromTrash(d, 0), true); assert.equal(d.notes[0].id, 3); assert.equal(d.trash.length, 0);
});
t('restoreFromTrash: indeks salah atau jenis tak dikenal -> false, data aman', () => {
  const d = mk(); d.trash = [{ kind: 'aneh', item: { id: 9 } }];
  assert.equal(L.restoreFromTrash(d, 5), false); assert.equal(L.restoreFromTrash(d, 0), false); assert.equal(d.trash.length, 1);
});
t('backupSummary dan backupFileName', () => {
  const d = mk(); d.tasks = [1, 2]; d.priv = [1];
  assert.deepEqual(L.backupSummary(d), { tasks: 2, habits: 0, notes: 0, priv: 1 });
  assert.equal(L.backupFileName(new Date(2026, 9, 25)), 'notes-kelimaa-2026-10-25.json');
});
t('replaceData menimpa isi data tanpa mengganti objek aslinya', () => {
  const target = mk(); const ref = target; target.tasks = [{ id: 'lama' }];
  const src = mk(); src.tasks = [{ id: 'baru' }]; src.settings.theme = 'dark';
  L.replaceData(target, src);
  assert.equal(ref.tasks[0].id, 'baru'); assert.equal(ref.settings.theme, 'dark');
});
t('ekspor lalu impor lalu timpa: semua bagian kembali sama', () => {
  const a = mk(); a.notes.push({ id: 'n', title: 'Rapat', text: 'x', col: '#fdebd6' }); a.priv.push({ id: 'p', title: 'Rahasia' }); a.settings.days = [1, 6];
  const r = S.importJSON(S.exportJSON(a)); assert.equal(r.ok, true);
  const b = mk(); L.replaceData(b, r.data);
  assert.equal(b.notes[0].col, '#fdebd6'); assert.equal(b.priv[0].title, 'Rahasia'); assert.deepEqual(b.settings.days, [1, 6]);
});
console.log(`\n${n} tes lulus (total)`);
