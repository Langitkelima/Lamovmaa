import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const notes = readFileSync(new URL('../src/js/notes.js', import.meta.url), 'utf8');
const a = notes.indexOf('const svgEl =');
const b = notes.indexOf('const insertBtn =');
const blok = notes.slice(a, b);
test('Ikon sisip dibuat di namespace SVG (bukan createElement HTML)', () => {
  assert.ok(a >= 0 && b > a);
  assert.match(blok, /createElementNS\('http:\/\/www\.w3\.org\/2000\/svg'/);
  assert.doesNotMatch(blok, /\bh\('(svg|path|circle|rect)'/);
});
test('Ketujuh tombol sisip punya ikon', () => {
  for (const k of ['mood', 'date', 'time', 'countdown', 'quote', 'table', 'image']) assert.match(blok, new RegExp(`\\b${k}: 'M`));
});
