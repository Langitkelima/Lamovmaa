// Rev 170 (diubah Rev 172): Isi seri KEMBALI ke setelan awal = lajur sumber berumus DILEWATI (tanpa tempel rumus). Menyalin rumus = Salin & Tempel (rev172.test.mjs).
import test from 'node:test';
import assert from 'node:assert/strict';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { fillSeries } from '../src/js/lembar-alat.js';
import { fillMessage, patternLabel } from '../src/js/lembar-ui.js';

const mk = () => { const sh = L.newSheet('t'), tab = sh.tabs[0]; return { sh, tab }; };
const put = (tab, a, v) => { const c = a.charCodeAt(0) - 65, r = Number(a.slice(1)) - 1; L.setCell(tab, tab.rows[r].id, tab.cols[c].id, typeof v === 'string' && v[0] === '=' ? { fx: R.a1ToStored(v, tab).fx } : { v }); };
const cellAt = (tab, a) => { const c = a.charCodeAt(0) - 65, r = Number(a.slice(1)) - 1; return tab.rows[r].cells[tab.cols[c].id]; };

test('Isi seri ke kanan: sumber berumus DILEWATI (rumus tidak disalin)', () => {
  const { tab } = mk(); for (let i = 1; i <= 5; i++) put(tab, 'B' + i, i);
  put(tab, 'B6', '=SUM(B1:B5)');
  const res = fillSeries(tab, { r1: 5, c1: 1, r2: 5, c2: 1 }, 2, { dir: 'right' });
  assert.equal(res.filled, 0); assert.equal(res.skippedFormula, 1); assert.equal(res.fxCopied, 0);
  assert.ok(!cellAt(tab, 'C6') || (!cellAt(tab, 'C6').fx && cellAt(tab, 'C6').v == null));
});
test('Isi seri angka biasa tetap jalan (ke kanan dan ke bawah)', () => {
  const { tab } = mk(); put(tab, 'A1', 1); put(tab, 'A2', 2);
  const r1 = fillSeries(tab, { r1: 0, c1: 0, r2: 1, c2: 0 }, 3, { dir: 'down' });
  assert.equal(r1.filled, 3); assert.equal(cellAt(tab, 'A5').v, 5);
});
test('Teks pesan dan label pola Isi seri', () => {
  assert.match(fillMessage({ filled: 0, skippedFormula: 2 }), /2 lajur sumber berumus dilewati/); assert.match(patternLabel({ kind: 'formula' }), /dilewati/);
});
test('Mesin geser rujukan tetap ada untuk Salin & Tempel', () => {
  const { tab } = mk(); const sh = R.shiftFx(R.a1ToStored('=A1+1', tab).fx, tab, -1, 0); assert.equal(sh.lost, true); assert.match(sh.fx, /#REF!/);
});
