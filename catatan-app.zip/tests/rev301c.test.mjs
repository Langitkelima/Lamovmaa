// Rev 301c / v0.3.121: audit Chromium dialog Olah catatan + perbaikan dialog di layar pendek (gulir) + penutup paket 301.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('CSS: dialog Tulis AI / Olah catatan dibatasi setinggi layar dan bisa digulir (vh sebagai cadangan dvh), tanpa warna mentah', () => {
  const c = src('src/css/styles.css'), i = c.indexOf('Rev 301c'); assert.ok(i > 0);
  const r = c.slice(i).split('\n')[1];
  assert.match(r, /^\.kai-tulis \.sheet\.dlg\{/); assert.match(r, /max-height:calc\(100vh - 24px\);max-height:calc\(100dvh - 24px\)/); assert.match(r, /overflow-y:auto/); assert.doesNotMatch(r, /#[0-9a-fA-F]{3,6}\b|rgb/);
  assert.equal(c.split('Rev 301c').length - 1, 1);
});
test('alat audit: tools/audit_catatan_ai.py ada, memalsukan Worker (tanpa jaringan nyata), terang + gelap, 360x720', () => {
  assert.ok(existsSync(new URL('../tools/audit_catatan_ai.py', import.meta.url)));
  const a = src('tools/audit_catatan_ai.py');
  assert.match(a, /pg\.route\('https:\/\/tes\.akun\.workers\.dev/); assert.match(a, /\['light', 'dark'\]/); assert.match(a, /'width': 360, 'height': 720/);
  for (const k of ['Usul judul', 'judul_urungkan', 'ringkas_urungkan_pulih', 'rapikan_urungkan', 'status_tolak', 'status_panjang', 'tombolTeksTerpotong']) assert.ok(a.includes(k), k);
});
test('UJI_HP_RILIS bagian AF: butir 1-8 berurutan, butir 8 = layar pendek / keyboard terbuka', () => {
  const u = src('UJI_HP_RILIS.md'), f = u.slice(u.indexOf('## AF.')); const nums = [...f.matchAll(/^(\d+)\. \[ \]|^(\d+)\. /gm)].map((m) => Number(m[1] || m[2]));
  assert.deepEqual(nums.slice(0, 8), [1, 2, 3, 4, 5, 6, 7, 8]); assert.match(f, /8\. .*(pendek|keyboard)/);
});
test('README tetap ringkas (< 12000 huruf), jujur soal status; entri Rev 301c di PROMPT dan RIWAYAT; tes terdaftar; versi + SCHEMA tetap', () => {
  const r = src('README.md'); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */); assert.match(r, /Rev 301c/); assert.match(r, /bukan\*\* bukti APK/);
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 301c / v0.3.121')); assert.ok(src('RIWAYAT.md').includes('**Rev 301c / v0.3.121')); // Rev 302a: startsWith -> includes (entri Rev 302a kini di paling atas)
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev301c\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
