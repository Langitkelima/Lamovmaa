// Tes Rev 20: terima teks dari Bagikan Android. Bagian murni (logic.js), kode native yang DIBANGKITKAN (apply-native.mjs),
// manifest, dan sambungan JS. Alur layar dicek di Chromium (lihat RIWAYAT). MainActivity.java tidak bisa dikompilasi AI terhadap SDK asli.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseShared, sharedToHtml, SHARE_IN_MAX, SHARE_IN_TITLE_MAX } from '../src/js/logic.js';
import { mainActivitySource, ensureShareIntentFilter, hasShareFilter, ensureAdjustResize, ensureInternetPermission, ensureReminderManifest, patchLaunchStyles, SHARE_FILTER_XML } from '../scripts/apply-native.mjs';
import { readShared } from '../src/js/terima.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const pay = (o) => JSON.stringify(o);

await t('parseShared: tidak ada yang diproses bila kosong, bukan string, bukan JSON, atau bukan objek', () => {
  for (const v of ['', '   ', null, undefined, 5, {}, 'bukan json', '[1,2]', 'null', '"teks"', '12']) {
    if (v === '[1,2]') { assert.deepEqual(parseShared(v), { ok: false, reason: 'tolak' }); continue; } // array = objek tanpa teks
    assert.equal(parseShared(v), null, String(v));
  }
});
await t('parseShared: tanpa teks / reject / teks hanya spasi = ditolak (mis. berkas dibagikan, bukan teks)', () => {
  assert.deepEqual(parseShared(pay({ text: '', subject: 'x', reject: true })), { ok: false, reason: 'tolak' });
  assert.deepEqual(parseShared(pay({ text: '  \n\t ', subject: 'x' })), { ok: false, reason: 'tolak' });
  assert.deepEqual(parseShared(pay({ text: 'ada', reject: true })), { ok: false, reason: 'tolak' }, 'reject menang');
  assert.deepEqual(parseShared(pay({ subject: 'tanpa teks' })), { ok: false, reason: 'tolak' });
  assert.deepEqual(parseShared(pay({ text: 123 })), { ok: false, reason: 'tolak' }, 'teks bukan string diabaikan');
});
await t('parseShared: judul = subjek, isi = teks', () => {
  const r = parseShared(pay({ text: 'https://contoh.id/a', subject: 'Resep Nasi Goreng' }));
  assert.deepEqual(r, { ok: true, title: 'Resep Nasi Goreng', text: 'https://contoh.id/a', truncated: false });
  assert.equal(parseShared(pay({ text: 'halo' })).title, '', 'tanpa subjek: judul kosong');
  assert.equal(parseShared(pay({ text: 'halo', subject: 5 })).title, '', 'subjek bukan string diabaikan');
});
await t('parseShared: subjek sama dengan isi tidak dijadikan judul (tautan dobel)', () => {
  assert.equal(parseShared(pay({ text: 'https://a.id', subject: 'https://a.id' })).title, '');
  assert.equal(parseShared(pay({ text: 'a  b', subject: ' a b ' })).title, '', 'spasi dirapikan sebelum dibandingkan');
  assert.equal(parseShared(pay({ text: 'isi', subject: 'isi lain' })).title, 'isi lain');
});
await t('parseShared: judul satu baris, spasi rapi, maks. 120 huruf, karakter kontrol dibuang', () => {
  assert.equal(parseShared(pay({ text: 'x', subject: '  Satu\n\nDua\t\tTiga\u0007  ' })).title, 'Satu Dua Tiga');
  const long = parseShared(pay({ text: 'x', subject: 'a'.repeat(500) })).title;
  assert.equal(long.length, SHARE_IN_TITLE_MAX);
});
await t('parseShared: CRLF jadi LF, tab jadi spasi, kontrol dibuang, spasi ujung baris dibuang, baris kosong berlebih dirapikan', () => {
  const r = parseShared(pay({ text: '\r\nBaris 1  \r\n\tBaris\u0000 2\r\n\r\n\r\n\r\n\r\n\r\nBaris 3\r\n\n' }));
  assert.equal(r.text, 'Baris 1\n  Baris 2\n\n\nBaris 3');
});
await t('parseShared: teks tepat di batas tidak dipotong, lewat batas dipotong + penanda truncated', () => {
  const ok = parseShared(pay({ text: 'a'.repeat(SHARE_IN_MAX) }));
  assert.equal(ok.text.length, SHARE_IN_MAX); assert.equal(ok.truncated, false);
  const cut = parseShared(pay({ text: 'a'.repeat(SHARE_IN_MAX + 1) }));
  assert.equal(cut.text.length, SHARE_IN_MAX); assert.equal(cut.truncated, true);
  const big = parseShared(pay({ text: 'b'.repeat(100000) }));
  assert.equal(big.text.length, SHARE_IN_MAX); assert.equal(big.truncated, true);
});
await t('parseShared: pemotongan tidak membelah emoji dan tidak menyisakan spasi di ujung', () => {
  const r = parseShared(pay({ text: 'a'.repeat(SHARE_IN_MAX - 1) + '\u{1F600}\u{1F600}' }));
  assert.equal(r.truncated, true);
  const last = r.text.charCodeAt(r.text.length - 1);
  assert.ok(!(last >= 0xd800 && last <= 0xdbff), 'tidak berakhir di separuh pasangan surrogate');
  assert.equal(r.text.length, SHARE_IN_MAX - 1);
  const sp = parseShared(pay({ text: 'a'.repeat(SHARE_IN_MAX - 3) + '   zzzz' }));
  assert.equal(sp.text, 'a'.repeat(SHARE_IN_MAX - 3), 'spasi di ujung potongan dibuang');
});
await t('parseShared: teks berisi HTML tidak diubah (di-escape belakangan oleh sharedToHtml)', () => {
  assert.equal(parseShared(pay({ text: '<script>alert(1)</script>' })).text, '<script>alert(1)</script>');
});
await t('sharedToHtml: tiap baris satu div, baris kosong div+br, karakter HTML di-escape, tanpa tag dari luar', () => {
  assert.equal(sharedToHtml('satu\n\ndua'), '<div>satu</div><div><br></div><div>dua</div>');
  assert.equal(sharedToHtml('a & b <c> "d"'), '<div>a &amp; b &lt;c&gt; "d"</div>');
  const h = sharedToHtml('<img src=x onerror=alert(1)>\n<script>alert(1)</script>');
  assert.ok(!/<img|<script/.test(h), 'tidak ada tag mentah'); assert.ok(h.includes('&lt;img') && h.includes('&lt;script&gt;'));
  assert.equal(sharedToHtml(''), '<div><br></div>'); assert.equal(sharedToHtml(null), '<div><br></div>');
});

// ---- Manifest ----
const MANIFEST = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:label="x">
        <activity
            android:name=".MainActivity"
            android:launchMode="singleTask"
            android:exported="true">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

        </activity>
        <provider android:name="androidx.core.content.FileProvider" android:exported="false">
            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" android:resource="@xml/file_paths"></meta-data>
        </provider>
    </application>
    <uses-permission android:name="android.permission.INTERNET" />
</manifest>
`;
const actBlock = (x) => /<activity\b[\s\S]*?<\/activity>/.exec(x)[0];
await t('manifest: filter Bagikan teks dipasang DI DALAM activity utama sebagai intent-filter terpisah dari MAIN/LAUNCHER', () => {
  const x = ensureShareIntentFilter(MANIFEST);
  assert.ok(hasShareFilter(x));
  const a = actBlock(x);
  assert.ok(a.includes('android.intent.action.SEND') && a.includes('android:mimeType="text/plain"') && a.includes('android.intent.category.DEFAULT'));
  assert.equal((a.match(/<intent-filter>/g) || []).length, 2, 'dua filter: LAUNCHER dan SEND');
  const sendFilter = /<intent-filter>(?:(?!<\/intent-filter>)[\s\S])*android\.intent\.action\.SEND"[\s\S]*?<\/intent-filter>/.exec(a)[0];
  assert.ok(!sendFilter.includes('LAUNCHER') && !sendFilter.includes('action.MAIN'), 'tidak digabung dengan filter LAUNCHER');
  assert.ok(!sendFilter.includes('SEND_MULTIPLE') && !/mimeType="(?!text\/plain)/.test(sendFilter), 'hanya satu teks biasa, tanpa gambar/berkas');
  assert.ok(x.indexOf('android.intent.action.SEND"') < x.indexOf('<provider'), 'bukan di provider/application');
  assert.ok(x.includes('FILE_PROVIDER_PATHS') && x.includes('permission.INTERNET'), 'bagian lain utuh');
});
await t('manifest: idempoten (build ulang tidak menggandakan) dan sudah ada filter SEND dari sumber lain tidak ditimpa', () => {
  const a = ensureShareIntentFilter(MANIFEST), b = ensureShareIntentFilter(a);
  assert.equal(a, b); assert.equal((b.match(/action\.SEND"/g) || []).length, 1);
  const own = MANIFEST.replace('</activity>', '<intent-filter><action android:name="android.intent.action.SEND" /><data android:mimeType="text/plain" /></intent-filter></activity>');
  assert.equal(ensureShareIntentFilter(own), own);
});
await t('manifest: exported dan launchMode dilengkapi bila hilang, tidak diubah bila sudah ada (singleTop tetap singleTop)', () => {
  const bare = MANIFEST.replace('\n            android:launchMode="singleTask"', '').replace('\n            android:exported="true">', '>');
  const x = ensureShareIntentFilter(bare);
  const open = /<activity\b[^>]*>/.exec(x)[0];
  assert.ok(open.includes('android:exported="true"') && open.includes('android:launchMode="singleTask"'));
  const top = MANIFEST.replace('singleTask', 'singleTop');
  const y = ensureShareIntentFilter(top); assert.ok(/<activity\b[^>]*>/.exec(y)[0].includes('android:launchMode="singleTop"') && !y.includes('singleTask'));
  assert.equal((/<activity\b[^>]*>/.exec(ensureShareIntentFilter(MANIFEST))[0].match(/android:launchMode=/g) || []).length, 1, 'tidak ada launchMode ganda');
});
await t('manifest: tanpa activity LAUNCHER / activity swatutup / manifest kosong = tidak diubah dan tidak melempar', () => {
  const noAct = '<manifest><application></application></manifest>';
  assert.equal(ensureShareIntentFilter(noAct), noAct);
  const other = MANIFEST.replace('android.intent.category.LAUNCHER', 'android.intent.category.INFO');
  assert.equal(ensureShareIntentFilter(other), other);
  const selfClosing = '<manifest><application><activity android:name=".A" /><activity android:name=".B"><intent-filter><category android:name="android.intent.category.LAUNCHER" /></intent-filter></activity></application></manifest>';
  const z = ensureShareIntentFilter(selfClosing);
  assert.ok(z.includes('<activity android:name=".A" />'), 'activity swatutup tidak disentuh');
  assert.ok(/android:name="\.B"[\s\S]*action\.SEND"/.test(z), 'filter masuk ke activity yang punya LAUNCHER');
  assert.equal(ensureShareIntentFilter(''), '');
});
await t('manifest: urutan dengan perbaikan lain (adjustResize, INTERNET) tetap menghasilkan satu filter dan satu adjustResize', () => {
  const x = ensureShareIntentFilter(ensureAdjustResize(ensureInternetPermission(MANIFEST.replace('<uses-permission android:name="android.permission.INTERNET" />', ''))));
  assert.equal((x.match(/action\.SEND"/g) || []).length, 1); assert.equal((x.match(/windowSoftInputMode/g) || []).length, 1); assert.ok(x.includes('permission.INTERNET'));
  assert.ok(SHARE_FILTER_XML.includes('text/plain'));
});

// ---- Kode native yang dibangkitkan ----
const J = mainActivitySource('com.kelimaa.notes');
await t('native: MainActivity memuat jembatan takeShared, penangkap Intent, onNewIntent, dan perlindungan buka ulang', () => {
  for (const k of ['public String takeShared()', 'private void captureShare(Intent it)', 'Intent.ACTION_SEND.equals(it.getAction())', 'FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY',
    'getCharSequenceExtra(Intent.EXTRA_TEXT)', 'getCharSequenceExtra(Intent.EXTRA_SUBJECT)', 'new JSONObject()', 'import org.json.JSONObject;',
    'protected void onNewIntent(Intent intent)', 'super.onNewIntent(intent)', 'setIntent(intent)', 'window.__kelimaaShared', 'if (savedInstanceState == null) { captureShare(getIntent()); captureReminder(getIntent()); }',
    'SHARE_LOCK', 'sharedPayload = null']) assert.ok(J.includes(k), k);
  const i = J.indexOf('@JavascriptInterface\n    public String takeShared()'); assert.ok(i > 0, 'takeShared diberi @JavascriptInterface');
});
await t('native: semua kode Bagikan dibungkus try/catch, dan JS tidak didorong isi teks (hanya sinyal; teks ditarik)', () => {
  const cap = J.slice(J.indexOf('private void captureShare'), J.indexOf('protected void onNewIntent'));
  assert.ok(cap.includes('try {') && cap.includes('catch (Exception e)'), 'captureShare');
  const nn = J.slice(J.indexOf('protected void onNewIntent'), J.indexOf('/** Warna latar'));
  assert.ok(nn.includes('try {') && nn.includes('catch (Exception e)'), 'onNewIntent');
  const tk = J.slice(J.indexOf('public String takeShared()'), J.indexOf('public void openUrl'));
  assert.ok(tk.includes('try {') && tk.includes('catch (Exception e)') && tk.includes('return \"\"'.replace(/\\/g, '')), 'takeShared');
  assert.ok(!/evaluateJavascript\([^;]*sharedPayload/.test(J), 'isi teks tidak disisipkan ke skrip (anti injeksi): hanya sinyal');
  assert.ok(J.indexOf('super.onCreate(savedInstanceState)') < J.indexOf('captureShare(getIntent())'), 'captureShare setelah super.onCreate');
});
await t('native: batas panjang di sisi native, gambar/berkas tanpa teks ditandai reject, tidak membaca EXTRA_STREAM', () => {
  assert.ok(J.includes('100000') && J.includes('o.put("reject", text.trim().length() == 0)'));
  assert.ok(!J.includes('EXTRA_STREAM'), 'berkas tidak dibaca');
});
await t('native: hal lama tetap utuh (Kembali, keluar total, buka tautan, bar, inset) dan styles.xml tetap tidak disentuh', () => {
  for (const k of ['public void exit()', 'public void setBars', 'public void openUrl', 'OnBackPressedCallback', '__kelimaaBack', 'closeAppTotal', 'removeCallbacks(killTask)', 'setDecorFitsSystemWindows(getWindow(), false)', 'applyBars(', 'FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS']) assert.ok(J.includes(k), k);
  const a = src('../scripts/apply-native.mjs');
  assert.ok(!/patchLaunchStyles\(/.test(a.slice(a.indexOf('export function applyNative'))), 'patchLaunchStyles tetap tidak dipanggil (aturan 2)');
  assert.equal(typeof patchLaunchStyles, 'function');
  assert.ok(a.includes('ensureReminderManifest(before)') && a.includes('ensureShareIntentFilter(ensureAdjustResize(ensureInternetPermission(after)))'));
});

// ---- Sambungan JS ----
await t('readShared: tanpa jembatan / tanpa takeShared = kosong; mengembalikan isi; galat dari jembatan tidak melempar', () => {
  assert.equal(readShared({}), ''); assert.equal(readShared({ KelimaaNative: {} }), ''); assert.equal(readShared({ KelimaaNative: { takeShared: 1 } }), '');
  assert.equal(readShared({ KelimaaNative: { takeShared: () => '{"text":"a"}' } }), '{"text":"a"}');
  assert.equal(readShared({ KelimaaNative: { takeShared: () => null } }), '');
  const err = console.error; let logged = 0; console.error = () => { logged++; };
  assert.equal(readShared({ KelimaaNative: { takeShared: () => { throw new Error('x'); } } }), ''); console.error = err; assert.equal(logged, 1);
});
await t('sumber: terima.js tidak menyentuh Catatan Privat; main.js menarik teks saat buka, saat kembali ke layar, dan memasang penerima dorongan', () => {
  const s = src('../src/js/terima.js');
  assert.ok(!/data\.priv|openEditor\(ctx, [^)]*'priv'/.test(s), 'tidak menulis ke privat');
  for (const k of ['lockPrivat(ctx)', "openEditor(ctx, n.id, 'note', false, true)", 'data.notes.push(n)', 'ctx.persist()', 'sanitize(sharedToHtml(p.text))', '__kelimaaShared', 'closeDialog()', 'Teks terlalu panjang', 'hanya bisa menerima teks']) assert.ok(s.includes(k), k);
  assert.ok(s.indexOf('ctx.persist()') < s.indexOf("openEditor(ctx, n.id"), 'disimpan dulu, baru editor dibuka');
  assert.ok(s.indexOf('lockPrivat(ctx)') < s.indexOf('data.notes.push(n)'), 'privat dikunci sebelum catatan dibuat');
  const m = src('../src/js/main.js');
  assert.ok(m.includes("import { installShareInbox, pullShared } from './terima.js'") && m.includes('installShareInbox(ctx); pullShared(ctx);'));
  const vis = m.slice(m.indexOf("addEventListener('visibilitychange'")); assert.ok(vis.slice(0, vis.indexOf('\n});')).includes('pullShared(ctx)'), 'ditarik saat aplikasi kembali ke layar');
  const nt = src('../src/js/notes.js'); assert.ok(nt.includes('keepTrail = false, quiet = false') && nt.includes('fromShare: quiet'));
});
await t('versi 0.3.2 di tiga tempat (package.json, teks Lainnya, RIWAYAT)', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('../RIWAYAT.md').includes('**Rev 21 (31 Okt 2026, versi 0.2.21)'));
});
console.log(`\n${n} tes terima lulus`);
