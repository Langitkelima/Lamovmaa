// Tes Rev 38: tampilan Setelan lebih rapi (tema segmen, hari kerja satu baris, grup baris, kaki halaman).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const st = src('../src/js/settings.js'), css = src('../src/css/styles.css');

t('Rev 173: Setelan = judul, hero, tema, hari kerja, lalu kolase ubin (urutan tetap)', () => {
  const vs = st.indexOf('export function viewSettings'); let at = vs;
  for (const k of ["h('h1', {}, 'Setelan')", "class: 'sethero mzhero'", "class: 'seg3 mzs'", "class: 'mzwrap'", "class: 'mzlist'", "class: 'mz'", "class: 'foot'"]) { const i = st.indexOf(k, at); assert.ok(i > at, k); at = i; }
});
t('Rev 173: tema = kontrol segmen, hari kerja = tujuh tombol satu baris, tanpa wrap', () => {
  assert.ok(st.includes("class: 'pri days'") && !st.includes("'pri wrap'"));
  assert.ok(css.includes('.pri.days{gap:6px;flex-wrap:nowrap}') && css.includes('.pri.days button{flex:1 1 0;min-width:0'));
});
t('Rev 173: semua ubin lama ada (Label, Gambar, Lembar kerja, Cadangan, Sampah, Ekspor, Pulihkan, TWO POCKETS, Tutup); keterangan cadangan di ubin', () => {
  const vs = st.indexOf('export function viewSettings');
  for (const k of ["'Label catatan'", "'Gambar'", "'Lembar kerja'", "'Cadangan otomatis'", "'Tempat sampah'", "'Sync'", "'Tutup aplikasi'", 'Terakhir: ']) assert.ok(st.indexOf(k, vs) > vs, k);
  assert.ok(st.indexOf('tpSetCard(ctx, conn)', vs) > vs && st.includes("class: 'tp2-word'")); // Rev 410: kartu TWO POCKETS di bawah kartu Notes Kelimaa, tulisan dari gambar
  assert.ok(!st.slice(vs).includes("class: 'setgrp'"));
});
t('Rev 38: fungsi tombol tidak berubah (tema, hari kerja, label, sampah, ekspor, pulihkan, tutup)', () => {
  for (const k of ['applyTheme(v)', 'toggleDay(s.days, d)', "go('labels')", "go('trash')", "go('backup')", "go('sync')", 'askExit(ctx)']) assert.ok(st.includes(k), k);
});
t('Rev 38: (gaya lama tetap ada di CSS) kartu Setelan tembus pandang di tema gelap agar gradasi terlihat; teks kaki tetap kontras (memakai --mut)', () => {
  assert.ok(css.includes('rgba(19,27,46,.72)') && css.includes('.foot{color:var(--mut)'));
});
console.log(n + ' tes lulus (Rev 38 Setelan)');
