// Rev 370 / PART OJ3: pilihan JALUR + MODEL baca foto di dialog Pindai. Tes Node: bagian murni + kabel sumber (DOM diaudit terpisah: tools/audit_ocr_370.py, Chromium). BUKAN bukti dari HP atau Sakelar/Relay nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import * as U from '../src/js/ai/ocr-ui.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8'), SRC = rd('src/js/ai/ocr-ui.js');
const store = () => { const m = new Map(); return { m, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { m.set(k, String(v)); }, removeItem: (k) => { m.delete(k); } }; };
test('persetujuan jalur lain: kunci SENDIRI (tidak bentrok dengan Gemini), bolak-balik, tahan penyimpanan rusak', () => {
  assert.equal(U.OK_KEY_LAIN, 'kelimaa_ocr_ok_lain'); assert.notEqual(U.OK_KEY_LAIN, U.OK_KEY);
  const st = store(); assert.equal(U.sudahSetujuLain(st), false); assert.equal(U.catatSetujuLain(true, st), true); assert.equal(U.sudahSetujuLain(st), true); assert.equal(U.sudahSetuju(st), false, 'Gemini tetap belum setuju');
  assert.equal(U.catatSetuju(true, st), true); assert.equal(U.catatSetujuLain(false, st), true); assert.equal(U.sudahSetujuLain(st), false); assert.equal(U.sudahSetuju(st), true);
  const bad = { getItem: () => { throw new Error('x'); }, setItem: () => { throw new Error('x'); }, removeItem: () => { throw new Error('x'); } };
  assert.equal(U.sudahSetujuLain(bad), false); assert.equal(U.catatSetujuLain(true, bad), false);
});
test('teks persetujuan jalur lain JUJUR: menyebut layanan perantara, ketentuan belum diperiksa, KTP, model harus bisa baca gambar; tidak mengaku soal gratis/berbayar Google', () => {
  const t = U.TEKS_SETUJU_LAIN.join(' '); assert.equal(U.TEKS_SETUJU_LAIN.length, 3);
  for (const k of ['Sakelar', 'Relay', 'layanan perantara', 'belum memeriksa', 'KTP', 'membaca gambar']) assert.ok(t.includes(k), k);
  assert.ok(!/GRATIS|BERBAYAR|Google/.test(t)); assert.ok(U.TEKS_SETUJU.join(' ').includes('GRATIS'), 'teks Gemini lama utuh');
});
test('kabel: gerbang persetujuan sesuai jalur; bacaFoto tetap SATU dan membawa jalur; ocr.js tetap dimuat malas', () => {
  assert.match(SRC, /const setuju = \(\) => \(perluLain\(jal\) \? sudahSetujuLain\(\) : sudahSetuju\(\)\);/);
  assert.match(SRC, /if \(setuju\(\)\) baca\(\); else tanyaSetuju\(\(\) => \{ bRev\.hidden = false; baca\(\); \}, perluLain\(jal\)\);/);
  assert.match(SRC, /const perluLain = \(j\) => !!j && \(j\.provider === 'sakelar' \|\| j\.provider === 'relay'\);/);
  assert.equal((SRC.match(/bacaFoto\(/g) || []).length, 1); assert.match(SRC, /jalur: \{ provider: jal\.provider, model: jal\.model \}/);
  assert.match(SRC, /await import\('\.\/ocr\.js'\)/); assert.doesNotMatch(SRC, /^import .*ocr\.js/m);
  assert.match(SRC, /lain \? catatSetujuLain\(true\) : catatSetuju\(true\)/); assert.match(SRC, /catatSetujuLain\(false\); if \(catatSetuju\(false\)\) \{ bRev\.hidden = true;/);
});
test('kabel UI: 4 jalur (Bawaan/Gemini/Sakelar/Relay), model dari modelSiapPilih + ketik manual, simpan lewat simpanJalur, jalur diganti = model dikosongkan, tombol nonaktif sampai modul termuat', () => {
  for (const k of ["['', 'Bawaan']", "['gemini', 'Gemini']", "['sakelar', 'Sakelar']", "['relay', 'Relay']", 'O.modelSiapPilih(jal.provider)', 'O.simpanJalur(p)', 'O.bacaJalur()', "simpanJ({ provider: v, model: '' })", "disabled: 'disabled'", "'Model baca foto'", 'Ketik manual', 'MODEL_RELAY', 'HARUS bisa membaca gambar']) assert.ok(SRC.includes(k), k);
  assert.match(SRC, /if \(busy \|\| !O\) return;/); assert.match(SRC, /jSel\.disabled = !O \|\| !jal\.provider/);
});
test('status hasil memuat jalur, model, penanda model cadangan, dan lama baca (detik, koma desimal; hanya bila >= 100 ms)', () => {
  assert.match(SRC, /const info = \[r\.provider \? \(\(O && O\.JALUR_NAMA\[r\.provider\]\) \|\| r\.provider\) : '', r\.model, r\.fallbackFrom \? '\(model cadangan\)' : '', r\.ms >= 100 \? String\(Math\.round\(r\.ms \/ 100\) \/ 10\)\.replace\('\.', ','\) \+ ' dtk' : ''\]\.filter\(Boolean\)\.join/);
  assert.match(SRC, /'Hasil bacaan' \+ \(info \? ' \\u00b7 ' \+ info : ''\)/);
});
test('privasi: ocr-ui.js tanpa console/sessionStorage/innerHTML; localStorage hanya sebagai nilai bawaan parameter (globalThis.); tidak ada kunci penyimpanan baru selain persetujuan lain; Worker tidak berubah', () => {
  assert.doesNotMatch(SRC, /console\.|sessionStorage|innerHTML|insertAdjacentHTML|outerHTML/); assert.doesNotMatch(SRC, /(?<!globalThis\.)localStorage/);
  assert.equal((SRC.match(/setItem\(/g) || []).length, 2, 'dua: persetujuan Gemini dan persetujuan jalur lain');
  assert.ok(rd('backend/cloudflare/worker.mjs').includes('Rev 368 / PART OJ1') && !rd('backend/cloudflare/worker.mjs').includes('Rev 370'));
});
test('CSS: aturan dialog jalur ada (label, tombol nonaktif, kolom model, chip rapat), hanya variabel tema; tidak ada berkas CSS baru', () => {
  const c = rd('src/css/styles.css'); for (const k of ['.kai-ocr .kai-ocr-jl{', '.kai-ocr .kai-wc:disabled{', '.kai-ocr select.aisel,.kai-ocr input.in{', '.kai-ocr .kai-wc[data-j]{']) assert.ok(c.includes(k), k);
  const i = c.indexOf('.kai-ocr .kai-ocr-jl{'), blok = c.slice(i, c.indexOf('\n', c.indexOf('.kai-ocr .kai-wc[data-j]{')) + 1); assert.doesNotMatch(blok, /#[0-9a-f]{3,8}\b/i);
  assert.ok(fs.existsSync(new URL('../tools/audit_ocr_370.py', import.meta.url)));
});
test('dokumen dan tes: banner Rev 370 + status 37.8; tes terdaftar; versi 0.3.121 dan SCHEMA 22 tetap; ocr.js dan Worker tidak diubah oleh revisi ini', () => {
  const p = JSON.parse(rd('package.json')); assert.ok(p.scripts.test.includes('node tests/rev370.test.mjs')); assert.equal(p.version, '0.3.121'); assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/);
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) { const d = rd(f); assert.ok(d.includes('**Rev 370 / v0.3.121') && d.indexOf('**Rev 370') < d.indexOf('**Rev 369'), f); }
  assert.ok(rd('PROMPT_SERAH_TERIMA.md').includes('37.8 STATUS (Rev 370)')); assert.ok(rd('src/js/ai/ocr.js').includes('Rev 369 / OJ2') && !rd('src/js/ai/ocr.js').includes('Rev 370'));
});
