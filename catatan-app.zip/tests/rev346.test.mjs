// Rev 346 / PART R1: model murni pengingat baris bullet dan bernomor: rowsFromHtml juga membaca <li data-cid> (tanpa DOM, tanpa UI). + anggaran dinaikkan atas izin pengguna.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { rowsFromHtml, cidsInHtml, planCbAlarms, cleanNoteRem } from '../src/js/ingatkan.js';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('R1: baris centang lama tetap terbaca persis (teks, done)', () => {
  const h = '<div class="todo" data-cid="abcd1"><input type="checkbox" checked> Beli susu</div><div class="todo" data-cid="efgh2"><input type="checkbox"> Cuci mobil</div>';
  assert.deepEqual(rowsFromHtml(h), { abcd1: { text: 'Beli susu', done: true }, efgh2: { text: 'Cuci mobil', done: false } });
});
test('R1: li bullet dan bernomor ber-data-cid terbaca; done selalu false; li tanpa cid diabaikan', () => {
  const h = '<ul><li data-cid="bul01">Telepon ibu</li><li>tanpa cid</li></ul><ol><li data-cid="num02">Kirim <b>laporan</b>&nbsp;besok</li></ol>';
  assert.deepEqual(rowsFromHtml(h), { bul01: { text: 'Telepon ibu', done: false }, num02: { text: 'Kirim laporan besok', done: false } });
});
test('R1: campuran todo + bullet + bernomor; urutan dokumen menentukan cid kembar (yang PERTAMA menang, lintas jenis)', () => {
  const h = '<ul><li data-cid="dupl1">Bullet dulu</li></ul><div class="todo" data-cid="dupl1"><input type="checkbox" checked> Centang kemudian</div><div class="todo" data-cid="todo3"><input type="checkbox"> T</div>';
  const r = rowsFromHtml(h);
  assert.deepEqual(r.dupl1, { text: 'Bullet dulu', done: false });
  assert.deepEqual(Object.keys(r).sort(), ['dupl1', 'todo3']);
  const h2 = '<div class="todo" data-cid="dupl1"><input type="checkbox" checked> Centang dulu</div><ul><li data-cid="dupl1">Bullet</li></ul>';
  assert.deepEqual(rowsFromHtml(h2).dupl1, { text: 'Centang dulu', done: true });
});
test('R1: li bersarang: tiap item memegang teksnya sendiri (induk berhenti di sub-daftar)', () => {
  const h = '<ul><li data-cid="induk">Induk<ul><li data-cid="anak1">Anak satu</li><li data-cid="anak2">Anak dua</li></ul></li><li data-cid="adik3">Adik</li></ul>';
  const r = rowsFromHtml(h);
  assert.equal(r.induk.text, 'Induk'); assert.equal(r.anak1.text, 'Anak satu'); assert.equal(r.anak2.text, 'Anak dua'); assert.equal(r.adik3.text, 'Adik');
});
test('R1: cid tak sah (huruf besar, terlalu pendek/panjang) dan li rusak tanpa penutup tidak melempar', () => {
  const h = '<ul><li data-cid="ABCD1">x</li><li data-cid="abc">y</li><li data-cid="abcdefghijk">z</li><li data-cid="oke99">tanpa penutup';
  assert.deepEqual(rowsFromHtml(h), { oke99: { text: 'tanpa penutup', done: false } });
  assert.deepEqual(rowsFromHtml(null), {}); assert.deepEqual(rowsFromHtml(''), {});
});
test('R1: cidsInHtml dan cleanNoteRem sudah mengenali cid di li (pengingat li tidak dibuang saat catatan dibersihkan)', () => {
  const html = '<ul><li data-cid="bul01">Telepon</li></ul>';
  assert.deepEqual(cidsInHtml(html), ['bul01']);
  const rule = { at: 4102444800000, repeat: 'none' };
  const note = { id: 'n1', title: 'T', html, cbRem: { bul01: rule, hilang: rule } };
  assert.deepEqual(Object.keys(cleanNoteRem(note).cbRem), ['bul01']);
});
test('R1: perencana alarm menjadwalkan pengingat li dengan teks item (pakai rowsFromHtml)', () => {
  const now = Date.UTC(2026, 10, 19, 1, 0);
  const rule = { at: now + 5 * 3600 * 1000, repeat: 'none' };
  const note = { id: 'n1', title: 'Belanja', html: '<ol><li data-cid="num02">Beli susu</li></ol>', cbRem: { num02: rule } };
  const plan = planCbAlarms(note, rowsFromHtml(note.html), now);
  assert.equal(plan.length, 1); assert.equal(plan[0].at, rule.at); assert.ok(JSON.stringify(plan[0]).includes('Beli susu'));
});
test('anggaran dinaikkan atas izin pengguna: JS buka < 784.000, jsMaks 1480 KB, cssMaks 262 KB; sumber ingatkan.js tetap tanpa DOM', () => {
  assert.match(read('tests/rev193.test.mjs'), /tot < 810000/); assert.match(read('tests/rev194.test.mjs'), /tot < 810000/);
  const a = read('tools/audit-ukuran.mjs'); assert.match(a, /cssMaks: 270 \* 1024, jsMaks: 1600 \* 1024, totalMaks: 2100 \* 1024/);
  assert.doesNotMatch(read('src/js/ingatkan.js'), /document\.|window\.|localStorage/);
});
