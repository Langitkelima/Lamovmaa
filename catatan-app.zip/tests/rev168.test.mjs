// Rev 168 / Q10 tahap 2 (Cari data bagian 4): HLOOKUP(nilai; rentang; baris; [cocok]) + audit akhir Cari data (urutan hitung rentang 2D, kinerja).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { argHint } from '../src/js/rumus-bantu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 9, 0, 0).getTime();
function mk(grid, n = 12) { const t = L.newTab('T', n); grid.forEach((row, ri) => row.forEach((v, ci) => { if (v === undefined || v === null) return; L.setCell(t, t.rows[ri].id, t.cols[ci].id, { v }); })); return t; }
function at(grid, f) { const t = mk(grid); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cH = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cH'); }
const BULAN = [['Jan', 'Feb', 'Mar', 'Apr'], [100, 200, 300, 400], ['a', 'b', 'c', 'd']];
const TARIF = [[0, 100, 500], ['Rendah', 'Sedang', 'Tinggi']];

test('HLOOKUP sama persis (cocok FALSE/0/kosong): baris ke-n, huruf besar/kecil, wildcard, #N/A', () => {
  assert.equal(at(BULAN, '=HLOOKUP("Mar";A1:D3;2;FALSE)'), 300); assert.equal(at(BULAN, '=HLOOKUP("MAR";A1:D3;3;0)'), 'c'); assert.equal(at(BULAN, '=HLOOKUP("Jan";A1:D3;1;FALSE)'), 'Jan'); assert.equal(at(BULAN, '=HLOOKUP("Ap*";A1:D3;2;FALSE)'), 400);
  assert.equal(at(BULAN, '=HLOOKUP("Feb";A1:D3;2;)'), 200); assert.equal(at(BULAN, '=HLOOKUP("Mei";A1:D3;2;FALSE)').e, '#N/A');
  assert.equal(at([['a', 'a'], [1, 2]], '=HLOOKUP("a";A1:B2;2;FALSE)'), 1); // kembar: kolom pertama
  assert.equal(at([[10, '10'], ['x', 'y']], '=HLOOKUP(10;A1:B2;2;FALSE)'), 'x'); assert.equal(at([['10'], ['y']], '=HLOOKUP(10;A1:A2;2;FALSE)').e, '#N/A');
  assert.equal(at(BULAN, '=HLOOKUP("Jan";A2:D3;1;FALSE)').e, '#N/A'); // pencarian hanya di BARIS PERTAMA rentang (baris 2), bukan baris 1
});
test('HLOOKUP perkiraan (cocok TRUE / dihilangkan): terbesar <= nilai di baris pertama terurut', () => {
  assert.equal(at(TARIF, '=HLOOKUP(250;A1:C2;2)'), 'Sedang'); assert.equal(at(TARIF, '=HLOOKUP(250;A1:C2;2;TRUE)'), 'Sedang'); assert.equal(at(TARIF, '=HLOOKUP(500;A1:C2;2)'), 'Tinggi'); assert.equal(at(TARIF, '=HLOOKUP(99999;A1:C2;2)'), 'Tinggi');
  assert.equal(at(TARIF, '=HLOOKUP(-5;A1:C2;2)').e, '#N/A'); assert.equal(at(TARIF, '=HLOOKUP(250;A1:C2;2;0)').e, '#N/A'); assert.equal(at([[10, 'teks', 30], ['x', 'y', 'z']], '=HLOOKUP(35;A1:C2;2)'), 'z');
});
test('HLOOKUP baris: 1 = baris pertama, 0/negatif #VALUE!, melebihi tinggi #REF!, galat menjalar, nilai tunggal, sama hasil dengan VLOOKUP transposisi', () => {
  assert.equal(at(BULAN, '=HLOOKUP("Mar";A1:D3;\"3\";FALSE)'), 'c'); assert.equal(at(BULAN, '=HLOOKUP("Mar";A1:D3;2,9;FALSE)'), 300);
  assert.equal(at(BULAN, '=HLOOKUP("Mar";A1:D3;0;FALSE)').e, '#VALUE!'); assert.equal(at(BULAN, '=HLOOKUP("Mar";A1:D3;-1;FALSE)').e, '#VALUE!'); assert.equal(at(BULAN, '=HLOOKUP("Mar";A1:D3;4;FALSE)').e, '#REF!'); assert.equal(at(BULAN, '=HLOOKUP("Mar";A1:D3;"x";FALSE)').e, '#VALUE!');
  assert.equal(at(BULAN, '=HLOOKUP(1/0;A1:D3;2;FALSE)').e, '#DIV/0!'); assert.equal(at(BULAN, '=HLOOKUP("Mar";A1:D3;2;"x")').e, '#VALUE!'); assert.equal(at(BULAN, '=HLOOKUP(A1:B1;A1:D3;2;FALSE)').e, '#VALUE!'); assert.equal(at([], '=HLOOKUP(5;5;1;FALSE)'), 5); assert.equal(at([], '=HLOOKUP(5;5;2;FALSE)').e, '#REF!');
  const v = at([['apel', 1], ['jeruk', 2], ['kiwi', 3]], '=VLOOKUP("kiwi";A1:B3;2;FALSE)'), h = at([['apel', 'jeruk', 'kiwi'], [1, 2, 3]], '=HLOOKUP("kiwi";A1:C2;2;FALSE)'); assert.equal(v, 3); assert.equal(h, v);
  const t = mk([['a', 'b'], [1, 2]]); t.rows[1].cells.cA = { fx: R.a1ToStored('=1/0', t).fx }; t.rows[3].cells.cH = { fx: R.a1ToStored('=HLOOKUP("a";A1:B2;2;FALSE)', t).fx }; t.rows[4].cells.cH = { fx: R.a1ToStored('=HLOOKUP("b";A1:B2;2;FALSE)', t).fx };
  const c = R.computeTab(t, { now: NOW }); assert.equal(c.get('r4', 'cH').e, '#DIV/0!'); assert.equal(c.get('r5', 'cH'), 2); // hanya galat di sel yang diambil
});
test('HLOOKUP dipakai nyata + audit urutan hitung rentang 2D (sel berumus di tengah rentang, rantai, siklus, rentang melewati tepi tab ditolak saat diketik)', () => {
  assert.equal(at(BULAN, '=IFERROR(HLOOKUP("Mei";A1:D3;2;FALSE);0)'), 0); assert.equal(at(BULAN, '=HLOOKUP("Feb";A1:D3;2;FALSE)*2'), 400); assert.equal(at(BULAN, '="Total: "&TEXT(HLOOKUP("Feb";A1:D3;2;FALSE);"Rp #.##0")'), 'Total: Rp 200');
  assert.equal(at([['Mar', 0, 0], ['Jan', 'Feb', 'Mar'], [1, 2, 3]], '=HLOOKUP(A1;A2:C3;2;FALSE)'), 3); // kunci dari sel lain
  const t = mk([['k', null], ['z', 7]]); t.rows[0].cells.cB = { fx: R.a1ToStored('=B2*2', t).fx }; t.rows[3].cells.cH = { fx: R.a1ToStored('=HLOOKUP("k";A1:B2;2;FALSE)', t).fx }; // dihitung SESUDAH B1 walau barisnya di bawah
  assert.equal(R.computeTab(t, { now: NOW }).get('r4', 'cH'), 'z'); // kolom k = A: baris 2 kolom A = 'z'
  const u = mk([['a', null]]); u.rows[0].cells.cB = { fx: R.a1ToStored('=HLOOKUP("a";A1:B2;2;FALSE)', u).fx }; assert.equal(R.computeTab(u, { now: NOW }).get('r1', 'cB').e, '#CIRC!');
  const w = mk([['a', null], [null, null]]); w.rows[0].cells.cB = { fx: R.a1ToStored('=D1', w).fx }; w.rows[0].cells.cD = { fx: R.a1ToStored('=HLOOKUP("a";A1:B2;2;FALSE)', w).fx }; const cw = R.computeTab(w, { now: NOW }); assert.equal(cw.get('r1', 'cD').e, '#CIRC!'); assert.equal(cw.get('r1', 'cB').e, '#CIRC!'); // siklus lewat rentang 2D
  const r = mk([['k', 9]], 5); assert.equal(R.a1ToStored('=VLOOKUP("k";A1:B20;2;FALSE)', r).ok, false); // rentang melewati baris tab ditolak saat diketik (sama dengan SUM dan fungsi lain), bukan jadi galat diam-diam
  const q = mk([['a', 1], ['b', 2]]); q.rows[0].cells.cH = { fx: R.a1ToStored('=VLOOKUP(VLOOKUP("a";A1:B2;2;FALSE)+1;B1:B2;1;FALSE)', q).fx }; assert.equal(R.computeTab(q, { now: NOW }).get('r1', 'cH'), 2); // rantai
});
test('kinerja: 300 VLOOKUP/HLOOKUP di data 300 baris selesai cepat (batas longgar 2 detik) dan wildcard tidak meledak', () => {
  const t = L.newTab('P', 300); for (let i = 0; i < 300; i++) { L.setCell(t, t.rows[i].id, t.cols[0].id, { v: 'item' + i }); L.setCell(t, t.rows[i].id, t.cols[1].id, { v: i * 10 }); }
  for (let i = 0; i < 300; i++) t.rows[i].cells.cF = { fx: R.a1ToStored('=VLOOKUP("item"&' + i + ';A1:B300;2;FALSE)', t).fx };
  const s = Date.now(), c = R.computeTab(t, { now: NOW }); assert.ok(Date.now() - s < 2000); assert.equal(c.get('r300', 'cF'), 2990);
  const w = mk([['a'.repeat(1500)]]); w.rows[0].cells.cD = { fx: R.a1ToStored('=VLOOKUP("*a*a*a*a*a*a*a*b";A1:A2;1;FALSE)', w).fx }; const s2 = Date.now(); assert.equal(R.computeTab(w, { now: NOW }).get('r1', 'cD').e, '#N/A'); assert.ok(Date.now() - s2 < 1000);
});
test('daftar fungsi 52; HLOOKUP di chip saran + petunjuk 4 argumen; VLOOKUP/MATCH/INDEX tidak berubah; modul murni; tes terdaftar; versi 0.3.121', () => {
  const names = R.FUNCTION_LIST.map((f) => f.name); assert.equal(names.length, 53); const f = R.FUNCTION_LIST.find((x) => x.name === 'HLOOKUP'); assert.ok(f && f.sig.startsWith('HLOOKUP(') && f.ket.length > 3);
  assert.equal(argHint('HLOOKUP', 9).parts.length, 4); assert.deepEqual(R.suggestFunctions('hl').map((x) => x.name), ['HLOOKUP']); assert.ok(R.suggestFunctions('h').map((x) => x.name).includes('HOUR'));
  assert.equal(at([['a', 1], ['b', 2]], '=VLOOKUP("b";A1:B2;2;FALSE)'), 2); assert.equal(at([['a'], ['b'], ['c']], '=MATCH("b";A1:A3;0)'), 2); assert.equal(at([[5, 6, 7]], '=INDEX(A1:C1;3)'), 7);
  const s = src('src/js/rumus.js'); assert.ok(!/^\s*import\s/m.test(s)); assert.ok(!/document\.|window\.|localStorage|eval\(|new Function/.test(s));
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(pk.scripts.test.includes('tests/rev168.test.mjs')); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
