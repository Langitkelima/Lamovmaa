// Rev 213c / v0.3.121: pilihan JENIS PEKERJAAN di layar Chat (Umum, Analisis, Kreatif, Cepat). Aplikasi mengirim jenis pekerjaan, bukan nama model. SCHEMA tetap 18.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as S from '../src/js/ai/sambungan.js';
import W from '../backend/cloudflare/worker.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const conn = { url: 'https://kelimaa-ai.contoh.workers.dev', key: 'rama-secret-12' };
const msgs = [{ role: 'user', content: 'Halo' }];
const okHttp = (box) => async (o) => { box.body = JSON.parse(o.body); return { status: 200, text: JSON.stringify({ ok: true, text: 'ok', model: 'm', provider: 'gemini', used: 1, limit: 100 }) }; };
test('TASK_CHOICES = tepat empat jenis dan SEMUANYA dikenal Worker (tabel rute)', () => {
  assert.deepEqual(S.TASK_CHOICES.map((t) => t[0]), ['chat.general', 'analysis.general', 'creative.general', 'utility.small']);
  for (const [k] of S.TASK_CHOICES) assert.ok(W._t.ROUTES[k], k);
});
test('kirimChat memakai jenis pekerjaan yang sah; tanpa task atau task asing = chat.general', async () => {
  for (const [opts, want] of [[{ task: 'analysis.general' }, 'analysis.general'], [{ task: 'utility.small' }, 'utility.small'], [{}, 'chat.general'], [{ task: 'research.search' }, 'chat.general'], [{ task: '../x' }, 'chat.general']]) {
    const box = {}; const r = await S.kirimChat(conn, msgs, okHttp(box), opts); assert.equal(r.ok, true); assert.equal(box.body.task, want);
  }
});
test('hasil kirimChat memuat fallbackProvider HANYA bila Worker mengirimnya', async () => {
  const mk = (extra) => async () => ({ status: 200, text: JSON.stringify({ ok: true, text: 'ok', model: 'm', provider: 'gemini', used: 1, limit: 5, ...extra }) });
  assert.equal('fallbackProvider' in (await S.kirimChat(conn, msgs, mk({}))), false);
  assert.equal((await S.kirimChat(conn, msgs, mk({ fallbackProvider: 'sakelar' }))).fallbackProvider, 'sakelar');
});
test('obrolan.js: tombol jenis pekerjaan, task dikirim lewat opsi, tanpa HTML mentah/penyimpanan; yang dikirim tetap hanya pesan', () => {
  const ob = src('src/js/ai/obrolan.js');
  for (const k of ["task: TUGAS", "dialihkan dari", "const TUGAS = 'chat.general'"]) assert.ok(ob.includes(k), k); /* Rev 223: tombol jenis pekerjaan dihapus dari layar; chat selalu chat.general */ assert.ok(!ob.includes('TASK_CHOICES'));
  assert.doesNotMatch(ob, /innerHTML|insertAdjacentHTML|outerHTML|localStorage|sessionStorage|console\./);
});
test('obrolan.js tidak memakai penyimpanan peramban; SCHEMA tetap 18 (riwayat ruang lewat ai/ruang.js, bukan catatan_app_data)', () => {
  assert.doesNotMatch(src('src/js/ai/obrolan.js'), /setItem|localStorage|sessionStorage|catatan_app_data/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
test('CSS Rev 213c ada, seimbang, tanpa heks/blur; versi 0.3.121 dan tes terdaftar', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* Rev 213c'); assert.ok(i > 0); assert.doesNotMatch(css.slice(i), /#[0-9a-fA-F]{6}|blur\(/);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(pk.scripts.test, /node tests\/rev215\.test\.mjs/);
});
