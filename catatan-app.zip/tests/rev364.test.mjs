// Rev 364 / PART W4: Enter + penyembuhan untuk tebal `*x*` / miring `_x_` gaya WhatsApp. Perilaku DOM nyata diaudit di Chromium: tools/audit_format_wa_364.py (tes ini = kunci struktur kode).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, statSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const k = read('src/js/ketik-ui.js'), n = read('src/js/notes.js');
const part = (from, to) => k.slice(k.indexOf(from), k.indexOf(to));

test('Enter: onBefore (fase capture) memanggil waEnter HANYA untuk insertParagraph; Shift+Enter (insertLineBreak) sengaja tidak memformat', () => {
  const b = part('const onBefore', 'const format =');
  assert.match(b, /e\.inputType === 'insertParagraph'/); assert.match(b, /waEnter\(\)/); assert.ok(!/insertLineBreak/.test(b));
  assert.match(b, /e\.isComposing\) return/);
  assert.match(k, /ed\.addEventListener\('beforeinput', onBefore, true\)/);
  assert.match(k, /last\.kind === 'wa' \? undoWa\(\) : undoFmt\(\)/, 'Backspace-batal W2/W3 tetap');
});
test('waEnter: kursor di UJUNG simpul teks, penanda `*`/`_` tepat di kiri, tidak ada teks lain sesudahnya, lalu waApply(null, "enter")', () => {
  const w = part('const waEnter', 'const healEnter');
  assert.match(w, /off !== nd\.data\.length/); assert.match(w, /c !== '\*' && c !== '_'/); assert.match(w, /tagName === 'BR'/); assert.match(w, /waApply\(null, 'enter'\)/);
  assert.match(w, /busy \|\| composing/); assert.match(w, /!sl\.isCollapsed/);
});
test('waApply mode enter: karakter pemicu MAYA (tidak pernah ditulis ke DOM), simpul kosong penampung kursor, tanpa Backspace-batal', () => {
  const w = part('const waApply', 'const waEnter');
  assert.match(w, /const en = mode === 'enter'/); assert.match(w, /nd\.data \+ '\\u00a0'/); assert.match(w, /createTextNode\(en \? '' : dat\.slice\(off - 1\)\)/);
  assert.match(w, /setCaret\(post, en \? 0 : 1\)/); assert.match(w, /last = null/); assert.match(w, /waTyped\(e\)/, 'syarat W2 (karakter diketik) tetap untuk mode biasa');
  assert.match(w, /pairsClosedBefore\(ctx, ctx\.length\)/); assert.match(w, /flushHist\(\)[\s\S]*flushHist\(\)/, 'format = langkah Urungkan sendiri');
  assert.match(w, /off < 2/); assert.match(w, /if \(off < 4\) return false/, 'lintas simpul boleh pendek (penutup + pemicu), satu simpul tetap minimal `*x* `');
});
test('healEnter: hanya sesudah Enter yang tadi memformat; membuang <b>/<i> KOSONG terluar di baris baru; tidak menyentuh teks', () => {
  const h = part('const healEnter', 'const undoWa2');
  assert.match(h, /e\.inputType !== 'insertParagraph'/); assert.match(h, /x\.tagName === 'B' \|\| x\.tagName === 'I'/); assert.match(h, /x\.textContent === ''/);
  assert.match(h, /hl\.n\.remove\(\)/); assert.match(h, /querySelector\('br'\)/);
  assert.match(k, /if \(enterHeal\) \{ const hl = enterHeal; enterHeal = null; healEnter\(hl, e\); \}/);
  assert.match(k, /if \(!\(spaceTyped && format\(\)\)\) waApply\(e\)/, 'jalur ketikan W2 tidak berubah');
});
test('IME: compositionend memproses pemicu yang tiba bersama selesainya komposisi; Privat/Baca tidak berubah', () => {
  assert.match(k, /if \(spaceTyped\) format\(\); waApply\(null, 'comp'\)/);
  assert.match(k, /composing = e\.type === 'compositionstart'/);
});
test('notes.js: `*`/`_` memuat modul (pemanasan, Enter tidak balapan dengan pemuatan) dan pemicu yang diketik selama pemuatan tidak hilang; modul tetap tidak diimpor statis', () => {
  assert.match(n, /const inWa = \/\[\*_\]\[ \\u00a0\.,;:!\?\)\]\$\/\.test\(nd\.data\.slice\(0, sl\.anchorOffset\)\) \|\| c === '\*' \|\| c === '_'/);
  assert.match(n, /if \(!kt\.format\(\)\) kt\.wa\(ev\) \|\| kt\.wa\(null, 'comp'\)/);
  assert.match(n, /if \(inTodoBang \|\| inWiki \|\| inWa\)/);
  assert.ok(!/format-wa/.test(n)); assert.ok(!/^import .*ketik-ui/m.test(n));
});
test('anggaran JS buka tidak dilanggar (< 792.000); tes terdaftar; versi dan SCHEMA tetap; tidak ada berkas baru di src/js', () => {
  const js = ['notes.js', 'ketik-ui.js'].map((f) => statSync(new URL('../src/js/' + f, import.meta.url)).size);
  assert.ok(js[0] < 400000);
  const pk = JSON.parse(read('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev364\.test\.mjs/);
  assert.match(read('src/js/storage.js'), /SCHEMA = 22/);
});
