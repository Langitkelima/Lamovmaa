// Rev 197b: workflow ukur Chromium + skrip skenario (tidak dijalankan di sini; hanya penjaga keberadaan/isi). Berkas rev200 = Rev 197b.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, existsSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
// Rev 197e: berkas workflow tinggal di akar REPO (.github/workflows), bukan di folder proyek hasil bongkar zip saat build APK, jadi tidak boleh WAJIB ada di sini.
const adaYml = existsSync(new URL('../.github/workflows/ukur-performa.yml', import.meta.url));
test('workflow ukur: manual saja, tidak menyentuh build APK, memanggil skrip yang ada', () => {
  for (const f of ['tools/buat_data.mjs', 'tools/ukur_performa.py', 'tools/ukur_node.mjs', 'tools/audit-ukuran.mjs']) assert.ok(existsSync(new URL('../' + f, import.meta.url)), f + ' ada');
  if (!adaYml) return; // build APK membongkar zip tanpa folder .github: lewati pemeriksaan isi workflow
  const y = src('.github/workflows/ukur-performa.yml');
  assert.match(y, /workflow_dispatch:/); assert.doesNotMatch(y, /\n\s*(push|pull_request|schedule):/); assert.doesNotMatch(y, /gradlew|assembleDebug|keystore/i);
  for (const f of ['tools/buat_data.mjs', 'tools/ukur_performa.py', 'tools/ukur_node.mjs', 'tools/audit-ukuran.mjs']) assert.ok(y.includes(f), f + ' dipanggil');
});
test('skenario S1-S6 ada di skrip Python dan memakai selektor nyata dari kode', () => {
  const py = src('tools/ukur_performa.py'); for (const s of ['S1', 'S2', 'S3', 'S4', 'S5', 'S6']) assert.ok(py.includes(s + ' '), s);
  const notes = src('src/js/notes.js'), main = src('src/js/main.js');
  assert.match(notes, /class: 'ed2', contenteditable: 'true'/); assert.match(notes, /'aria-label': 'Kembali'/); assert.match(notes, /class: 'sw'/); assert.match(main, /'data-tab': id/);
  assert.match(py, /nav button\[data-tab="catatan"\]/); assert.match(py, /\.ed2/); assert.match(py, /aria-label="Kembali"/);
});
test('tanpa versi/SCHEMA/native berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev200\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
