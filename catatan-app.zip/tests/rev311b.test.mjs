// Rev 311b: lembar kerja dan pengingat catatan menolak lewat dialog yang menjelaskan alasan + solusi.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const R = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('lembar-ui: tidak ada lagi toast penolakan/batas; semuanya dialog', () => {
  const s = R('src/js/lembar-ui.js');
  for (const k of ["toast('Lembar kerja terlalu besar", "toast('Maksimal", "toast('Rumus tidak disimpan", "toast('Sel berumus", "toast('Berkas terlalu besar", "toast('Gagal ", "toast('Rentang tidak sah", "toast('Riwayat tidak bisa"]) assert.ok(!s.includes(k), 'masih toast: ' + k);
  assert.ok((s.match(/tooBig\(/g) || []).length >= 15);
  assert.match(s, /const batas = \(judul, msg, fix\) => infoDlg/);
});
test('lembar-ui: pesan rumus salah menyebut rumus yang diketik + alasan + solusi', () => {
  const s = R('src/js/lembar-ui.js');
  assert.match(s, /infoDlg\(\{ title: 'Rumus tidak disimpan', msg: 'Rumus ' \+ String\(val\.value\)/); assert.match(s, /masih ada di kolom isian/);
  assert.doesNotMatch(s, /Perbaiki rumusnya lalu ketik ulang/); /* Rev 311c: teks yang diketik DIPERTAHANKAN, bukan direset */
});
test('notes: pengingat catatan lampau memakai infoPast (nilai konkret), bukan toast', () => {
  const n = R('src/js/notes.js');
  assert.match(n, /infoPast\(at, ''/); assert.ok(!n.includes("toast('Waktu pengingat sekali harus"));
});
test('setCell false = tidak ada perubahan (bukan penolakan): tidak perlu dialog', async () => {
  const L = await import('../src/js/lembar.js');
  assert.equal(typeof L.setCell, 'function');
});
