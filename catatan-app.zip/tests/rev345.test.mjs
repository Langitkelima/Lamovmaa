// Rev 345 / PART I5b: audit penutup Paket Ketikan Tersembunyi (skrip Chromium + dokumen; tanpa perubahan kode aplikasi).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('audit_panduan_344.py ada dan memeriksa pembuatan sekali, 7 pemicu, `[] ` dan hitung cepat, tanpa salinan', () => {
  assert.ok(existsSync(new URL('../tools/audit_panduan_344.py', import.meta.url)));
  const s = read('tools/audit_panduan_344.py');
  for (const k of ['Panduan ketikan cepat', '== 1', "'6.000.000'", 'tidak boleh membuat salinan', 'scrollWidth', 'pageerror', "'!besok 9'"]) assert.ok(s.includes(k), k);
});
test('dokumen: entri Rev 345 di PROMPT dan RIWAYAT, README menyebut Rev 345 dan tetap < 12000 huruf', () => {
  assert.ok(read('PROMPT_SERAH_TERIMA.md').includes('**Rev 345 / v0.3.121'));
  assert.ok(read('RIWAYAT.md').includes('**Rev 345 / v0.3.121'));
  const r = read('README.md'); assert.match(r, /Rev 345/); assert.ok(r.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */);
});
test('tanpa perubahan versi/SCHEMA/anggaran: 0.3.121, SCHEMA 22; panduan-ketik.js tetap di luar graf buka', () => {
  assert.match(read('package.json'), /"version": "0\.3\.121"/);
  assert.match(read('src/js/storage.js'), /SCHEMA = 22;/);
  assert.ok(!/^import .*panduan-ketik/m.test(read('src/js/settings.js')));
});
