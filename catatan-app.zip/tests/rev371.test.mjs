// Rev 371 / PART OJ4: penutup Paket Jalur OCR. Revisi ini HANYA dokumen + tes: kode aplikasi (Rev 370) dan Worker (Rev 368) tidak berubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('UJI_HP_RILIS: bagian BV ada, memuat syarat Worker Rev 368 + APK Rev 370, 13 butir bernomor, isian waktu/mutu, tiap jalur dan butir penting (persetujuan terpisah, diingat, jatah, ketik manual)', () => {
  const d = rd('UJI_HP_RILIS.md'), i = d.indexOf('## BV. Jalur dan model baca foto'); assert.ok(i > 0 && i > d.indexOf('## BU.'));
  const k = d.indexOf('\n## ', i + 5), b = d.slice(i, k > 0 ? k : undefined); /* Rev 374: bagian BV dibatasi sampai judul berikutnya (BW ditambah di bawahnya, DISENGAJA) */ assert.ok(b.includes('Worker Rev 368') && b.includes('APK Rev 370') && b.includes('BERFUNGSI-BELUM-DIUJI'));
  const n = (b.match(/^\d+\. /gm) || []).length; assert.equal(n, 13); assert.ok(!/^\d+\. \[ \]/m.test(b), 'format polos seperti bagian B*, supaya tes bagian E (rev245) tidak ikut menghitung');
  for (const k of ['gemini-3.5-flash-lite', 'anthropic/haiku-5.5', 'deepseek/deepseek-v4-flash', 'MODEL_RELAY', 'model salah!', 'Cabut persetujuan kirim foto', 'Ketik manual', 'TOTAL', 'Waktu: ____', 'Mutu', 'pesan PERSIS', 'jatah']) assert.ok(b.includes(k), k);
  assert.ok((b.match(/____/g) || []).length >= 12);
});
test('banner Rev 371 paling atas di serah terima dan riwayat (di atas Rev 370); 37.9 ada; tes terdaftar; versi dan SCHEMA tetap', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) { const d = rd(f); assert.ok(/^\*\*Rev (37[1-9]|38\d|39\d|4[0-3][0-9])b? \/ v0\.3\.121/.test(d), f); /* Rev 372: banner baru boleh di atas (DISENGAJA) */ assert.ok(d.indexOf('**Rev 371') < d.indexOf('**Rev 370') && d.indexOf('**Rev 370') < d.indexOf('**Rev 369'), f); }
  assert.ok(rd('PROMPT_SERAH_TERIMA.md').includes('37.9 STATUS PENUTUP (Rev 371)'));
  const p = JSON.parse(rd('package.json')); assert.ok(p.scripts.test.includes('node tests/rev371.test.mjs')); assert.equal(p.version, '0.3.121'); assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/);
});
test('kode TIDAK berubah di revisi ini: Worker tetap Rev 368, ocr.js Rev 369, ocr-ui.js Rev 370; tidak ada penanda Rev 371 di src/ maupun backend/', () => {
  const w = rd('backend/cloudflare/worker.mjs'); assert.ok(w.includes('Rev 368 / PART OJ1')); assert.ok(rd('src/js/ai/ocr.js').includes('Rev 369 / OJ2')); assert.ok(rd('src/js/ai/ocr-ui.js').includes('Rev 370 / OJ3'));
  const walk = (d) => fs.readdirSync(new URL('../' + d, import.meta.url), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(d + '/' + e.name) : [d + '/' + e.name]));
  for (const f of [...walk('src'), ...walk('backend')]) if (/\.(js|mjs|css|html)$/.test(f)) assert.ok(!rd(f).includes('Rev 371'), f);
});
