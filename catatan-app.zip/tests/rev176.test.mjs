// Rev 176: urut baris tidak mengubah rentang diagram tersimpan (rentang dijaga tetap pada posisinya, seperti Excel).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as G from '../src/js/lembar-grafik.js';
import * as A from '../src/js/lembar-alat.js';
import { sortMessage } from '../src/js/lembar-ui.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
function mk(vals, rows = 12) {
  const t = L.newTab('T', rows);
  vals.forEach((v, i) => { L.setCell(t, t.rows[i].id, t.cols[0].id, { v: 'k' + i }); L.setCell(t, t.rows[i].id, t.cols[1].id, { v }); });
  return t;
}
const colB = (t, n) => t.rows.slice(0, n).map((r) => r.cells[t.cols[1].id].v);

test('Rev 176: urut Z-A: rentang diagram tetap A1:B5, isinya yang terurut', () => {
  const t = mk([3, 1, 5, 2, 4, 9]); const { id } = G.addChart(t, { r1: 0, c1: 0, r2: 4, c2: 1 }, 1, { title: 'x' });
  const res = A.sortTab(t, 1, 'desc', { header: false });
  assert.equal(res.ok, true); assert.ok(res.moved > 0); assert.equal(res.charts, 1);
  assert.deepEqual(colB(t, 6), [9, 5, 4, 3, 2, 1]);
  const g = G.getChart(t, id); assert.equal(g.ref, 'A1:B5'); assert.deepEqual(g.src, { r1: 0, c1: 0, r2: 4, c2: 1 }); assert.equal(g.valueCol, 1);
  assert.equal(t.charts[0].r1, t.rows[0].id); assert.equal(t.charts[0].r2, t.rows[4].id); assert.equal(t.charts[0].title, 'x');
});
test('Rev 176: baris sudut yang berpindah jauh tetap tidak menggeser rentang (A-Z, dua diagram)', () => {
  const t = mk([9, 8, 7, 6, 5, 4, 3, 2]); G.addChart(t, { r1: 1, c1: 0, r2: 5, c2: 1 }, 1); G.addChart(t, { r1: 0, c1: 0, r2: 7, c2: 1 }, 1, { kind: 'bar' });
  const res = A.sortTab(t, 1, 'asc', { header: false }); assert.equal(res.charts, 2);
  assert.deepEqual(G.chartList(t).map((c) => c.ref), ['A2:B6', 'A1:B8']); assert.deepEqual(colB(t, 8), [2, 3, 4, 5, 6, 7, 8, 9]);
  assert.equal(G.chartList(t)[1].kind, 'bar');
});
test('Rev 176: tidak ada baris yang pindah = diagram tidak disentuh; tab tanpa diagram tidak mendapat kunci charts', () => {
  const t = mk([1, 2, 3, 4]); G.addChart(t, { r1: 0, c1: 0, r2: 3, c2: 1 }, 1); const before = JSON.stringify(t.charts);
  const res = A.sortTab(t, 1, 'asc', { header: false }); assert.equal(res.moved, 0); assert.equal(res.charts, 0); assert.equal(JSON.stringify(t.charts), before);
  const u = mk([3, 1, 2]); const r2 = A.sortTab(u, 1, 'asc', { header: false }); assert.ok(r2.moved > 0); assert.equal(r2.charts, 0); assert.equal('charts' in u, false);
});
test('Rev 176: baris bergabungan tegak tetap di tempatnya dan rentang diagram tetap posisinya', () => {
  const t = mk([4, 3, 2, 1, 5, 0]); G.addChart(t, { r1: 0, c1: 0, r2: 5, c2: 1 }, 1);
  const m = L.mergeCells(t, 1, 0, 2, 0, { clear: true }); assert.equal(m.ok, true);
  const res = A.sortTab(t, 1, 'asc', { header: false }); assert.equal(res.ok, true); assert.equal(res.fixedRows, 2); assert.ok(res.moved > 0); assert.equal(res.charts, 1);
  assert.equal(G.chartList(t)[0].ref, 'A1:B6');
});
test('Rev 176: urut dengan judul (baris 1 dilewati) menjaga rentang yang mencakup judul', () => {
  const t = L.newTab('T', 8); const vals = ['Nilai', 5, 3, 9, 1]; vals.forEach((v, i) => { L.setCell(t, t.rows[i].id, t.cols[0].id, { v: 'n' + i }); L.setCell(t, t.rows[i].id, t.cols[1].id, { v }); });
  G.addChart(t, { r1: 0, c1: 0, r2: 4, c2: 1 }, 1); const res = A.sortTab(t, 1, 'asc', { header: true });
  assert.equal(res.header, true); assert.equal(G.chartList(t)[0].ref, 'A1:B5'); assert.equal(t.rows[0].cells[t.cols[1].id].v, 'Nilai');
});
test('Rev 176: chartRowSnap/Restore murni dan aman pada masukan buruk', () => {
  assert.equal(G.chartRowSnap(null), null); assert.equal(G.chartRowSnap({ rows: [], cols: [] }), null); assert.equal(G.chartRowRestore({ rows: [], charts: [] }, null), false);
  const t = mk([1, 2, 3]); G.addChart(t, { r1: 0, c1: 0, r2: 2, c2: 1 }, 1); const snap = G.chartRowSnap(t); assert.equal(snap.length, 1); assert.deepEqual([snap[0].r1, snap[0].r2], [0, 2]);
  assert.equal(G.chartRowRestore(t, snap), false); // tidak ada perubahan
  t.rows.reverse(); assert.equal(G.chartRowRestore(t, snap), true); assert.equal(G.chartList(t)[0].ref, 'A1:B3');
  assert.equal(G.chartRowRestore(t, [{ id: 'gnone', r1: 0, r2: 1 }, { id: t.charts[0].id, r1: 0, r2: 99 }]), false); // id hilang / indeks di luar = diabaikan
});
test('Rev 176: pesan urutkan menyebut diagram hanya bila ada; urutan data lama tak berubah', () => {
  assert.match(sortMessage({ ok: true, moved: 3, header: false, charts: 2 }, 'B', 'asc'), /Rentang 2 diagram tetap di posisinya\./);
  assert.doesNotMatch(sortMessage({ ok: true, moved: 3, header: false, charts: 0 }, 'B', 'asc'), /diagram/);
  assert.doesNotMatch(sortMessage({ ok: true, moved: 3, header: false }, 'B', 'asc'), /diagram/);
});
test('Rev 176: batas modul terjaga (lembar-grafik murni tanpa impor; hanya lembar.js yang mengimpornya), SCHEMA 17, versi 0.3.121', () => {
  assert.ok(!/^\s*import\s/m.test(src('src/js/lembar-grafik.js')));
  assert.doesNotMatch(src('src/js/lembar-alat.js'), /lembar-grafik/); assert.match(src('src/js/lembar-alat.js'), /pinChartRows, restoreChartRows \} from '\.\/lembar\.js'/);
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
  assert.match(src('package.json'), /"version": "0\.3\.121"/); assert.match(src('src/js/settings.js'), /v0\.3\.121/);
});
