// Rev 329 / PART TA: skrip inventaris toast jalan, hanya membaca, dan hitungannya masuk akal. Tidak mengubah perilaku aplikasi.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { inventaris, ringkas, bacaArg, literal, ragu, potongDiam } from '../tools/audit_toast_inventaris.mjs';
test('Rev 329: pemindai argumen menghormati string dan tanda kurung', () => {
  const r = bacaArg("toast('a, (b)', () => { x(1, 2); }, null, 'Urungkan', 'warn');", 'toast('.length);
  assert.equal(r.args.length, 5);
  assert.equal(literal(r.args[0]), 'a, (b)');
  assert.equal(literal(r.args[4]), 'warn');
  assert.equal(literal("'x' + y"), null);
});
test('Rev 329: inventaris menemukan toast di banyak modul dan ringkasannya konsisten', () => {
  const b = inventaris(), r = ringkas(b);
  assert.ok(r.total >= 200, 'total ' + r.total);
  assert.equal(r.literal + r.dinamis, r.total);
  assert.equal(Object.values(r.nadaLiteral).reduce((a, c) => a + c, 0), r.literal);
  assert.ok(Object.keys(r.perBerkas).length >= 10);
  assert.ok(b.every((x) => x.jenis === 'dinamis' ? x.tebakan === null : ['ok', 'warn', 'err', 'info'].includes(x.tebakan)));
});
test('Rev 329: pesan ragu dan kandidat pemotongan bisa didaftar', () => {
  const b = inventaris();
  assert.ok(Array.isArray(b.filter(ragu)));
  assert.ok(potongDiam().length > 0);
});
test('Rev 329: skrip hanya membaca (tidak menulis berkas)', () => {
  const s = readFileSync(new URL('../tools/audit_toast_inventaris.mjs', import.meta.url), 'utf8');
  assert.ok(!/writeFile|appendFile|unlink|rmSync|mkdirSync/.test(s));
});
