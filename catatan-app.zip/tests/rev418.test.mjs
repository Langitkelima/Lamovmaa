// Rev 418 / PART SY1 (Paket SY): aksi `sync` di Worker (mesin penggabung catatan HP <-> laptop). KV TIRUAN; tanpa jaringan. BUKAN bukti dari Cloudflare nyata dan BELUM ada pemanggil di aplikasi (SY2).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, readdirSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, rd = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = Date.UTC(2026, 10, 23, 5, 0, 0), DAY = 86400000;
const kv = () => { const m = new Map(), o = { m, failPutOnce: null, puts: [], get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { if (o.failPutOnce && o.failPutOnce(k)) { o.failPutOnce = null; throw new Error('KV putus'); } o.puts.push(k); m.set(k, v); }, delete: async (k) => { m.delete(k); } }; return o; };
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', PASS_DESY: 'desy-secret-34', KV: kv(), ...x });
const N = (o = {}) => ({ title: 'Belanja', html: '<div>susu</div>', col: '', pin: false, labels: [], updated: NOW - 1000, ...o });
const post = (o, key = 'rama-secret-12') => new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key, action: 'sync', ...o }) });
async function sy(env, o, now = NOW, key) { const r = await T.handle(post(o, key), env, now); return { status: r.status, j: await r.json() }; }
const put = (id, o = {}, bv = 0) => ({ id, bv, note: N(o) });
const ids = (r) => r.j.changes.map((c) => c.id);

test('tanpa passcode benar = 401; tanpa KV = 503 dengan petunjuk; aksi sync tidak memakai jatah AI', async () => {
  assert.equal((await sy(env0(), {}, NOW, 'salah-salah-1')).status, 401);
  const r0 = await sy({ PASS_RAMA: 'rama-secret-12' }, {}); assert.equal(r0.status, 503); assert.match(r0.j.error, /KV/);
  const e = env0(), r = await sy(e, { push: [put('abc12345')] }); assert.equal(r.status, 200); assert.equal(r.j.ok, true); assert.equal(r.j.sync, 1);
  for (const k of e.KV.m.keys()) assert.match(k, /^s[xn]:rama(:|$)/, k); // hanya kunci sinkron; tidak ada kunci jatah harian/bulanan
});

test('catatan baru: ok v1; perangkat pengirim tidak menerima kembali miliknya; perangkat lain menariknya utuh', async () => {
  const e = env0(), a = await sy(e, { since: 0, push: [put('n0000001', { title: 'Belanja', labels: ['Rumah'], pin: true, col: '#ffe9a8' })] });
  assert.deepEqual(a.j.results, [{ id: 'n0000001', status: 'ok', v: 1 }]); assert.equal(a.j.seq, 1); assert.equal(a.j.upto, 1); assert.equal(a.j.more, false); assert.deepEqual(a.j.changes, []);
  const b = await sy(e, { since: 0 }); assert.equal(b.j.changes.length, 1); const c = b.j.changes[0];
  assert.equal(c.id, 'n0000001'); assert.equal(c.v, 1); assert.equal(c.s, 1); assert.deepEqual(c.note, { title: 'Belanja', html: '<div>susu</div>', col: '#ffe9a8', pin: true, labels: ['Rumah'] }); assert.equal(c.updated, NOW - 1000);
  assert.deepEqual((await sy(e, { since: 1 })).j.changes, [], 'tidak ada yang baru');
});

test('ubah dengan bv sama dengan versi server: ok, v naik; hanya perangkat lain yang menariknya', async () => {
  const e = env0(); await sy(e, { push: [put('n0000001')] });
  const r = await sy(e, { since: 1, push: [put('n0000001', { html: '<div>susu, telur</div>', updated: NOW }, 1)] });
  assert.deepEqual(r.j.results, [{ id: 'n0000001', status: 'ok', v: 2 }]); assert.deepEqual(r.j.changes, []);
  const b = await sy(e, { since: 1 }); assert.equal(b.j.changes[0].v, 2); assert.equal(b.j.changes[0].note.html, '<div>susu, telur</div>');
});

test('KONFLIK, klien lebih baru: klien menang; versi server tersimpan sebagai "(konflik)" dan terbaca perangkat lain', async () => {
  const e = env0(); await sy(e, { push: [put('n0000001', { title: 'Rencana', html: 'dari server', updated: NOW - 5000 })] });
  const r = await sy(e, { since: 0, push: [put('n0000001', { title: 'Rencana', html: 'dari klien', updated: NOW - 1000 }, 0)] }); // bv 0 != v 1
  const x = r.j.results[0]; assert.equal(x.status, 'conflict'); assert.equal(x.winner, 'client'); assert.equal(x.v, 2); assert.match(x.copy, /^n0000001-k\d+$/);
  const c = r.j.changes.find((k) => k.id === x.copy); assert.ok(c, 'salinan konflik ikut dikirim ke penyusul'); assert.equal(c.note.title, 'Rencana (konflik)'); assert.equal(c.note.html, 'dari server'); assert.equal(c.note.pin, false); assert.equal(c.v, 1);
  assert.ok(!ids(r).includes('n0000001'), 'klien yang menang tidak menarik balik catatannya');
  const b = await sy(e, { since: 0 }); assert.equal(b.j.changes.find((k) => k.id === 'n0000001').note.html, 'dari klien');
});

test('KONFLIK, server lebih baru atau seri: server menang; versi klien disimpan sebagai salinan; klien diminta menarik versi server', async () => {
  for (const klienUpd of [NOW - 9000, NOW - 5000]) { // lebih lama, lalu seri
    const e = env0(); await sy(e, { push: [put('n0000001', { title: 'Rencana', html: 'dari server', updated: NOW - 5000 })] });
    const r = await sy(e, { since: 0, push: [put('n0000001', { title: 'Rencana', html: 'dari klien', updated: klienUpd }, 0)] }), x = r.j.results[0];
    assert.equal(x.status, 'conflict'); assert.equal(x.winner, 'server'); assert.equal(x.v, 1);
    assert.ok(ids(r).includes('n0000001'), 'klien menarik versi server'); assert.equal(r.j.changes.find((k) => k.id === 'n0000001').note.html, 'dari server');
    assert.equal(r.j.changes.find((k) => k.id === x.copy).note.html, 'dari klien'); assert.equal(r.j.changes.find((k) => k.id === x.copy).note.title, 'Rencana (konflik)');
  }
});

test('kiriman ULANG yang sama (jawaban hilang) idempoten: tidak ada salinan konflik, seq tidak naik; isi sama dengan bv usang juga aman', async () => {
  const e = env0(), it = put('n0000001', { html: 'v1' });
  await sy(e, { push: [it] }); const a = await sy(e, { push: [put('n0000001', { html: 'v2', updated: NOW }, 1)] }); assert.equal(a.j.results[0].v, 2); const seq = a.j.seq;
  const again = await sy(e, { push: [put('n0000001', { html: 'v2', updated: NOW }, 1)] }); // ulang persis, bv 1 sudah usang
  assert.deepEqual(again.j.results, [{ id: 'n0000001', status: 'ok', v: 2 }]); assert.equal(again.j.seq, seq); assert.equal(again.j.changes.length, 0);
  assert.equal([...e.KV.m.keys()].filter((k) => k.startsWith('sn:rama:')).length, 1, 'tidak ada salinan');
});

test('HAPUS: tanda hapus berversi, terbaca perangkat lain sebagai del; hapus catatan yang tak pernah ada = ok v0 tanpa tulis; hapus dua kali idempoten', async () => {
  const e = env0(); await sy(e, { push: [put('n0000001')] });
  const d = await sy(e, { since: 1, push: [{ id: 'n0000001', bv: 1, del: true, updated: NOW }] }); assert.deepEqual(d.j.results, [{ id: 'n0000001', status: 'ok', v: 2 }]);
  const b = await sy(e, { since: 1 }); assert.deepEqual(b.j.changes, [{ id: 'n0000001', v: 2, s: 2, updated: NOW, del: true }]);
  const rec = JSON.parse(e.KV.m.get('sn:rama:n0000001')); assert.equal(rec.del, 1); assert.ok(!('note' in rec), 'isi dibuang dari tanda hapus');
  const n0 = e.KV.puts.length; assert.deepEqual((await sy(e, { push: [{ id: 'n0000001', bv: 2, del: true, updated: NOW }] })).j.results, [{ id: 'n0000001', status: 'ok', v: 2 }]); assert.equal(e.KV.puts.length, n0, 'tanpa tulis');
  assert.deepEqual((await sy(e, { push: [{ id: 'zzzz9999', bv: 0, del: true, updated: NOW }] })).j.results, [{ id: 'zzzz9999', status: 'ok', v: 0 }]); assert.equal(e.KV.puts.length, n0);
});

test('HAPUS vs UBAH serentak: ubah menang. Hapus basi = kept (klien menarik versi hidup); ubah atas catatan terhapus = resurrected', async () => {
  const e = env0(); await sy(e, { push: [put('n0000001', { html: 'a' })] });
  await sy(e, { push: [put('n0000001', { html: 'b', updated: NOW }, 1)] }); // perangkat A mengubah -> v2
  const k = await sy(e, { since: 0, push: [{ id: 'n0000001', bv: 1, del: true, updated: NOW + 1000 }] }); // perangkat B menghapus dari v1
  assert.deepEqual(k.j.results, [{ id: 'n0000001', status: 'kept', v: 2, winner: 'server' }]); assert.equal(k.j.changes.find((c) => c.id === 'n0000001').note.html, 'b');
  const e2 = env0(); await sy(e2, { push: [put('n0000001')] }); await sy(e2, { push: [{ id: 'n0000001', bv: 1, del: true, updated: NOW }] }); // sudah terhapus (v2)
  const r = await sy(e2, { push: [put('n0000001', { html: 'masih kuedit', updated: NOW + 5 }, 1)] });
  assert.deepEqual(r.j.results, [{ id: 'n0000001', status: 'resurrected', v: 3 }]); const rec = JSON.parse(e2.KV.m.get('sn:rama:n0000001')); assert.ok(!rec.del); assert.equal(rec.note.html, 'masih kuedit');
});

test('PRIVAT: item bertanda priv/private/kind=priv ditolak; tidak ada yang tertulis', async () => {
  const e = env0(), r = await sy(e, { push: [{ id: 'p0000001', bv: 0, note: { ...N(), priv: true } }, { id: 'p0000002', bv: 0, note: { ...N(), private: 1 } }, { id: 'p0000003', bv: 0, note: { ...N(), kind: 'priv' } }] });
  assert.deepEqual(r.j.results.map((x) => x.status), ['rejected', 'rejected', 'rejected']); assert.match(r.j.results[0].why, /Privat/); assert.equal(e.KV.m.size, 0);
});

test('validasi per item: nomor, bv, isi, judul, label, waktu; yang salah ditolak tanpa menghentikan yang sah; kirim dobel ditolak', async () => {
  const e = env0(), big = 'x'.repeat(T.SYNC_MAX_HTML + 1), bad = [
    { id: 'a', bv: 0, note: N() }, { id: 'bukan valid!', bv: 0, note: N() }, { id: 'n0000002', bv: -1, note: N() }, { id: 'n0000003', bv: 1.5, note: N() }, { id: 'n0000004', bv: 0 }, { id: 'n0000005', bv: 0, note: [] },
    { id: 'n0000006', bv: 0, note: N({ html: big }) }, { id: 'n0000007', bv: 0, note: N({ title: 'j'.repeat(301) }) }, { id: 'n0000008', bv: 0, note: N({ labels: 'x' }) }, { id: 'n0000009', bv: 0, note: N({ labels: [''] }) },
    { id: 'n0000010', bv: 0, note: N({ labels: ['l'.repeat(41)] }) }, { id: 'n0000011', bv: 0, note: N({ labels: Array.from({ length: 21 }, (_, i) => 'l' + i) }) }, { id: 'n0000012', bv: 0, note: N({ updated: 'kemarin' }) }, { id: 'n0000013', bv: 0, note: N({ updated: 0 }) },
    { id: 'n0000014', bv: 0, del: true }, null, 'teks',
  ];
  const r = await sy(e, { push: [...bad, put('oke00001'), put('oke00001')] });
  assert.equal(r.status, 200); assert.equal(r.j.results.length, bad.length + 2);
  assert.ok(r.j.results.slice(0, bad.length).every((x) => x.status === 'rejected' && typeof x.why === 'string'), JSON.stringify(r.j.results.filter((x) => x.status !== 'rejected')));
  assert.equal(r.j.results[bad.length].status, 'ok'); assert.equal(r.j.results[bad.length + 1].status, 'rejected'); assert.match(r.j.results[bad.length + 1].why, /dua kali/);
  assert.equal([...e.KV.m.keys()].filter((k) => k.startsWith('sn:')).length, 1);
});

test('pembersih isi: label dipangkas dan tanpa duplikat; kolom kosong bawaan; waktu masa depan dijepit ke sekarang + 5 menit', async () => {
  const c = T.cleanSyncNote({ title: undefined, html: undefined, labels: [' A ', 'A', 'B'], updated: NOW + 9 * DAY, pin: 'ya' }, NOW);
  assert.deepEqual(c.note, { title: '', html: '', col: '', pin: false, labels: ['A', 'B'] }); assert.equal(c.updated, NOW + 300000);
  const e = env0(); await sy(e, { push: [put('n0000001', { updated: NOW + 9 * DAY })] });
  assert.equal(JSON.parse(e.KV.m.get('sn:rama:n0000001')).updated, NOW + 300000);
});

test('batas permintaan: > 50 item = 400; since tidak sah = 400; badan > 600000 = 413; sync boleh melewati 90000 dan 4096 seperti ocr, aksi lain tidak', async () => {
  const e = env0();
  assert.equal((await sy(e, { push: Array.from({ length: 51 }, (_, i) => put('n' + String(i).padStart(7, '0'))) })).status, 400);
  assert.equal((await sy(e, { push: 'x' })).status, 400); for (const since of [-1, 1.5, 'a', null]) assert.equal((await sy(e, { since })).status, 400, String(since));
  assert.equal((await sy(e, { push: [put('n0000001', { html: 'h'.repeat(150000) })] })).status, 200, '150 KB lewat batas 90000 milik chat');
  assert.equal((await sy(e, { pad: 'x'.repeat(600001) })).status, 413);
  const lain = await T.handle(new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'whoami', pad: 'x'.repeat(5000) }) }), e, NOW); assert.equal(lain.status, 413);
});

test('paginasi tarik: 120 catatan = 100 + 20, more/upto benar; since = upto melanjutkan; tidak ada yang hilang atau ganda', async () => {
  const e = env0(); for (let i = 0; i < 120; i += 50) await sy(e, { push: Array.from({ length: Math.min(50, 120 - i) }, (_, k) => put('n' + String(i + k).padStart(7, '0'), { title: 't' + (i + k) })) });
  const p1 = await sy(e, { since: 0 }); assert.equal(p1.j.changes.length, T.SYNC_PULL_MAX); assert.equal(p1.j.more, true); assert.equal(p1.j.upto, p1.j.changes.at(-1).s); assert.equal(p1.j.seq, 120);
  const p2 = await sy(e, { since: p1.j.upto }); assert.equal(p2.j.changes.length, 20); assert.equal(p2.j.more, false); assert.equal(p2.j.upto, 120);
  const all = new Set([...ids(p1), ...ids(p2)]); assert.equal(all.size, 120);
  assert.ok(p1.j.changes.every((c, i, a) => !i || a[i - 1].s < c.s), 'urut menurut s');
});

test('paginasi menurut ukuran: 4 catatan 150 KB tidak ditarik sekaligus; minimal satu selalu ikut', async () => {
  const e = env0(); for (let i = 0; i < 4; i++) await sy(e, { push: [put('b000000' + i, { html: String(i).repeat(150000) })] });
  const p = await sy(e, { since: 0 }); assert.ok(p.j.changes.length >= 1 && p.j.changes.length < 4); assert.equal(p.j.more, true);
  let got = p.j.changes.length, up = p.j.upto, guard = 0; while (guard++ < 10) { const q = await sy(e, { since: up }); got += q.j.changes.length; up = q.j.upto; if (!q.j.more) break; } assert.equal(got, 4);
});

test('since lebih besar dari seq server (server dikosongkan/perangkat salah): reset = true dan semua ditarik ulang', async () => {
  const e = env0(); await sy(e, { push: [put('n0000001')] });
  const r = await sy(e, { since: 999 }); assert.equal(r.j.reset, true); assert.equal(r.j.changes.length, 1);
  assert.ok(!('reset' in (await sy(e, { since: 1 })).j));
});

test('tiap orang punya ruang sendiri: catatan Rama tidak terbaca Desy dan sebaliknya; versi dan seq terpisah', async () => {
  const e = env0(); await sy(e, { push: [put('n0000001', { title: 'Milik Rama' })] });
  const d = await sy(e, { since: 0 }, NOW, 'desy-secret-34'); assert.deepEqual(d.j.changes, []); assert.equal(d.j.seq, 0);
  const dp = await sy(e, { push: [put('n0000001', { title: 'Milik Desy' })] }, NOW, 'desy-secret-34'); assert.equal(dp.j.results[0].v, 1);
  assert.equal((await sy(e, { since: 0 })).j.changes[0].note.title, 'Milik Rama'); assert.equal((await sy(e, { since: 0 }, NOW, 'desy-secret-34')).j.changes.length, 1);
});

test('tanda hapus lewat 180 hari dibuang (rekam + indeks); perangkat basi yang mengirim ulang id itu diterima sebagai baru', async () => {
  const e = env0(); await sy(e, { push: [put('n0000001'), put('n0000002')] });
  await sy(e, { push: [{ id: 'n0000001', bv: 1, del: true, updated: NOW }] }, NOW);
  const dini = await sy(e, { since: 0 }, NOW + 179 * DAY); assert.ok(e.KV.m.has('sn:rama:n0000001'), 'belum 180 hari'); assert.equal(dini.j.changes.length, 2);
  const lama = await sy(e, { since: 0 }, NOW + 181 * DAY); assert.ok(!e.KV.m.has('sn:rama:n0000001'), 'rekam dibuang'); assert.ok(e.KV.m.has('sn:rama:n0000002'), 'catatan hidup tetap');
  assert.deepEqual(ids(lama), ['n0000002']); assert.ok(!('n0000001' in JSON.parse(e.KV.m.get('sx:rama')).n));
  const basi = await sy(e, { push: [put('n0000001', { html: 'dari perangkat lama' }, 2)] }, NOW + 181 * DAY); assert.deepEqual(basi.j.results, [{ id: 'n0000001', status: 'ok', v: 1 }]);
});

test('tulis terputus sebelum indeks: status 500 lalu kiriman ulang berhasil dan catatan sampai ke perangkat lain', async () => {
  const e = env0(); e.KV.failPutOnce = (k) => k === 'sx:rama';
  const res = await W.fetch(post({ push: [put('n0000001', { html: 'penting' })] }), e); assert.equal(res.status, 500); assert.ok(e.KV.m.has('sn:rama:n0000001'), 'rekam sempat tertulis'); assert.ok(!e.KV.m.has('sx:rama'), 'indeks belum');
  assert.deepEqual((await sy(e, { since: 0 })).j.changes, [], 'belum terlihat perangkat lain');
  const r2 = await sy(e, { push: [put('n0000001', { html: 'penting' })] }); assert.deepEqual(r2.j.results, [{ id: 'n0000001', status: 'ok', v: 1 }]);
  const b = await sy(e, { since: 0 }); assert.equal(b.j.changes.length, 1); assert.equal(b.j.changes[0].note.html, 'penting');
});

test('ruang penuh: id baru ke-3001 ditolak, tetapi mengubah catatan yang ada tetap boleh', async () => {
  const e = env0(), ix = {}; for (let i = 0; i < T.SYNC_MAX_IDS; i++) ix['q' + String(i).padStart(7, '0')] = [i + 1, 0];
  e.KV.m.set('sx:rama', JSON.stringify({ seq: T.SYNC_MAX_IDS, n: ix })); e.KV.m.set('sn:rama:q0000000', JSON.stringify({ v: 1, s: 1, updated: NOW - 9, note: N() }));
  const r = await sy(e, { since: T.SYNC_MAX_IDS, push: [put('baru0001'), put('q0000000', { html: 'ubah' }, 1)] });
  assert.equal(r.j.results[0].status, 'rejected'); assert.match(r.j.results[0].why, /penuh/); assert.equal(r.j.results[1].status, 'ok'); assert.equal(r.j.results[1].v, 2);
});

test('indeks rusak/tidak sah dibaca aman (tanpa galat); aksi tak dikenal tetap 400; sync tidak mengubah ping', async () => {
  const e = env0(); e.KV.m.set('sx:rama', '{rusak'); assert.equal((await sy(e, {})).status, 200);
  e.KV.m.set('sx:rama', JSON.stringify({ seq: 'x', n: { a: 'b', c: [0], d: [3, 0] } })); const r = await sy(e, {}); assert.equal(r.status, 200); assert.equal(r.j.seq, 0);
  assert.deepEqual(Object.keys(T.syIndex({ seq: 4, n: { x: [2, 5], y: 'z' } }).n), ['x']);
  assert.equal((await T.handle(post({ action: 'sinkron' }), e, NOW)).status, 400);
  const ping = await T.handle(new Request('https://w.example/?ping=1'), e, NOW); assert.equal((await ping.json()).ok, true);
});

test('dokumen dan berkas: banner Rev 418 paling atas; PANDUAN_WORKER memuat bagian sync; tes terdaftar; versi/SCHEMA/src tidak berubah', () => {
  const p = rd('PROMPT_SERAH_TERIMA.md'); assert.ok(/^\*\*Rev 4(?:18|19|[23]\d) \/ v0\.3\.121/.test(p), 'banner Rev 418 atau lebih baru di baris pertama'); assert.ok(p.indexOf('**Rev 418 /') < p.indexOf('**Rev 417 /'));
  assert.match(p.slice(p.indexOf('**Rev 418 /'), p.indexOf('**Rev 417 /')), /SY1/); assert.match(p.slice(p.indexOf('**Rev 418 /'), p.indexOf('**Rev 417 /')), /BERFUNGSI-BELUM-DIUJI/); assert.match(rd('RIWAYAT.md').split('\n').find((l) => /^\*\*Rev 418 \//.test(l)) || '', /SY1/);
  const g = rd('backend/cloudflare/PANDUAN_WORKER.md'); assert.match(g, /Rev 418/); assert.match(g, /sync/); assert.match(g, /KV/);
  assert.ok(JSON.parse(rd('package.json')).scripts.test.includes('node tests/rev418.test.mjs')); assert.equal(JSON.parse(rd('package.json')).version, '0.3.121');
  assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/);
  const semua = readdirSync(new URL('../src/js/', import.meta.url), { recursive: true }).filter((f) => f.endsWith('.js')); assert.ok(semua.includes('sync.js'), 'mesin sinkron aplikasi (SY2, Rev 419) sudah ada: BELUM ada pemanggil/UI (SY3)');
  for (const f of semua.filter((x) => x !== 'sync.js')) assert.ok(!/action:\s*['"]sync['"]|['"]action['"]:\s*['"]sync['"]/.test(rd('src/js/' + f)), f + ' belum boleh memanggil aksi sync (hanya sync.js, dan sync.js belum diimpor siapa pun)');
});
