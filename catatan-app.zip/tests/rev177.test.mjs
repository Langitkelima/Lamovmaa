// Rev 177: gabungan TEGAK yang terbelah di pergantian halaman PDF/JPG ditutup rapi (tepi bawah halaman lama + tepi atas halaman baru).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { exportModel } from '../src/js/lembar-pulau.js';
import { sheetBlocks, layoutDoc, paginate } from '../src/js/export.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const row = (cells, lh = 100) => ({ kind: 'tableRow', x: 0, w: 300, lh, lineH: 30, cells: cells.map((c, i) => ({ x: i * 100, w: 100, header: false, lines: [], padX: 7, padY: 6, a: '', ...c })), headerRow: false });
const O = { pageH: 400, padTop: 50, padBottom: 50 }; // ruang isi 300 = 3 baris

test('Rev 177: gabungan tegak terbelah: baris akhir halaman kehilangan vd, baris awal halaman berikutnya kehilangan vu; baris asli utuh', () => {
  const r = [row([{ vd: true }, {}, {}]), row([{ vu: true, vd: true }, {}, {}]), row([{ vu: true, vd: true }, {}, {}]), row([{ vu: true }, {}, {}])];
  const pages = paginate(r, O); assert.equal(pages.length, 2);
  const last = pages[0].lines[2], first = pages[1].lines[0];
  assert.equal('vd' in last.cells[0], false); assert.equal(last.cells[0].vu, true); assert.equal('vu' in first.cells[0], false); assert.equal(first.cells[0].vu === undefined, true);
  assert.equal(r[2].cells[0].vd, true); assert.equal(r[3].cells[0].vu, true); // baris asli tidak diubah
  assert.equal(pages[0].lines[0], r[0]); assert.equal(pages[0].lines[1], r[1]); // yang tidak di batas = objek yang sama
  assert.equal(pages[0].used, 300); assert.equal(pages[1].used, 100);
});
test('Rev 177: gabungan yang tidak terbelah, dan tabel tanpa gabungan tegak, tidak berubah sama sekali', () => {
  const r = [row([{}, {}, {}]), row([{ vd: true }, {}, {}]), row([{ vu: true }, {}, {}])]; const pages = paginate(r, O);
  assert.equal(pages.length, 1); assert.ok(pages[0].lines.every((l, i) => l === r[i]));
  const plain = Array.from({ length: 7 }, () => row([{}, {}, {}])); const pp = paginate(plain, O); assert.equal(pp.length, 3); assert.equal(pp.flatMap((p) => p.lines).filter((l, i) => l !== plain[i]).length, 0);
});
test('Rev 177: jarak (gap) di ujung halaman dibuang dulu, baru tepi dihitung; baris bukan tabel tidak disentuh', () => {
  const gap = { kind: 'gap', lh: 40, size: 30, x: 0, segs: [] }, tx = { kind: 'text', lh: 100, size: 30, x: 0, segs: [] };
  const r = [tx, row([{ vd: true }]), row([{ vu: true }, {}], 100), gap, row([{ vu: true }]), tx];
  const pages = paginate(r, { pageH: 360, padTop: 30, padBottom: 30 }); assert.ok(pages.length >= 2);
  const flat = pages.flatMap((p) => p.lines); assert.ok(flat.includes(tx)); assert.equal(pages.every((p) => !(p.lines.length && p.lines[p.lines.length - 1].kind === 'gap')), true);
  for (let i = 0; i < pages.length - 1; i++) { const l = pages[i].lines[pages[i].lines.length - 1]; if (l.kind === 'tableRow') assert.equal(l.cells.some((c) => c.vd), false); }
  for (let i = 1; i < pages.length; i++) { const l = pages[i].lines[0]; if (l.kind === 'tableRow') assert.equal(l.cells.some((c) => c.vu), false); }
});
test('Rev 177: dari lembar kerja sungguhan: gabungan A2:A4 terbelah di halaman pendek, tepi tertutup; halaman tinggi tetap menyatu', () => {
  const measure = (t, st) => String(t).length * (st.size || 30) * 0.5; const o = { width: 1240, pageH: 1754, padX: 110, padTop: 120, padBottom: 130, size: 30, titleSize: 46, measure };
  const sh = L.newSheet({ id: 'sabc123', name: 'Laporan' }), t = sh.tabs[0]; for (let i = 0; i < 6; i++) for (let j = 0; j < 3; j++) L.setCell(t, t.rows[i].id, t.cols[j].id, { v: 'x' + i + j });
  assert.equal(L.mergeCells(t, 1, 0, 3, 0, { clear: true }).ok, true);
  const lines = layoutDoc({ title: 'T', blocks: sheetBlocks(exportModel(sh)) }, o); const tr = lines.filter((l) => l.kind === 'tableRow'); assert.equal(tr.length, 6);
  const tall = paginate(lines, o); assert.equal(tall.length, 1); assert.equal(tall[0].lines.filter((l) => l.kind === 'tableRow' && l.cells.some((c) => c.vd)).length, 2);
  const upTo = lines.slice(0, lines.indexOf(tr[2]) + 1).reduce((a, l) => a + l.lh, 0); // pecah tepat sesudah baris ke-3 (tengah gabungan)
  const small = paginate(lines, { pageH: upTo + 120 + 130 + 1, padTop: 120, padBottom: 130 }); assert.ok(small.length >= 2);
  const p0 = small[0].lines.filter((l) => l.kind === 'tableRow'), p1 = small[1].lines.filter((l) => l.kind === 'tableRow');
  assert.equal(p0[p0.length - 1].cells.some((c) => c.vd), false); assert.equal(p1[0].cells.some((c) => c.vu), false); assert.equal(p1[0].cells.length, 3);
});
test('Rev 177: penggambar share.js tidak berubah (rev155 tetap berlaku); SCHEMA 17; versi 0.3.121; tes terdaftar', () => {
  const sh = src('src/js/share.js'); assert.ok(sh.includes('c.vu || c.vd') && sh.includes('if (!c.vu) seg(') && sh.includes('if (!c.vd) seg(') && sh.includes('} else g.strokeRect(l.x, y, l.w, l.lh);'));
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev177.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
  assert.match(src('src/js/export.js'), /Rev 177/);
});
