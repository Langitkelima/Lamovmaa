// Rev 366 / K9: dokumen dipadatkan ke ARSIP/ tanpa kehilangan isi.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const root = new URL('../', import.meta.url), rd = (p) => fs.readFileSync(new URL(p, root), 'utf8');
test('RIWAYAT dan PROMPT utama kecil, arsip ada, penunjuk ada', () => {
  assert.ok(fs.statSync(new URL('RIWAYAT.md', root)).size < 400000);
  assert.ok(fs.statSync(new URL('PROMPT_SERAH_TERIMA.md', root)).size < 500000);
  for (const f of ['ARSIP/RIWAYAT_ARSIP.md', 'ARSIP/PROMPT_SERAH_TERIMA_ARSIP.md']) assert.ok(fs.statSync(new URL(f, root)).size > 100000, f);
  assert.ok(rd('RIWAYAT.md').includes('ARSIP/RIWAYAT_ARSIP.md') && rd('PROMPT_SERAH_TERIMA.md').includes('ARSIP/PROMPT_SERAH_TERIMA_ARSIP.md'));
});
test('entri baru tetap paling atas; entri lama terbaca lewat pembaca tes (utama + arsip)', () => {
  for (const f of ['RIWAYAT.md', 'PROMPT_SERAH_TERIMA.md']) { const d = rd(f); assert.ok(/^\*\*Rev \d+b? \//.test(d) && d.includes('**Rev 366 /'), f); const lama = f === 'RIWAYAT.md' ? '**Rev 95 / 0.3.9' : '## 13. Jadwal "Paket Editor'; assert.ok(d.includes(lama) && d.indexOf('**Rev 366 /') < d.indexOf(lama), f + ' lama'); /* Rev 383: batas 30.000 huruf pertama diganti urutan (Rev 366 di atas isi lama) karena Rev 367-382 menumpuk di atasnya */ }
});
test('package.json memuat pembaca arsip dan tes terdaftar; PANDUAN_WORKER rapi', () => {
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.includes('_arsip.mjs') && t.includes('node tests/rev366.test.mjs'));
  const g = rd('backend/cloudflare/PANDUAN_WORKER.md'); assert.equal((g.match(/^## 9\. /gm) || []).length, 1); assert.ok(g.includes('MAX_TOKENS'));
});
