// Rev 158 / U10c-2b: model + mesin DIAGRAM TERSIMPAN per tab (SCHEMA 17, tanpa UI)
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as G from '../src/js/lembar-grafik.js';
import * as D from '../src/js/lembar-diagram.js';
import * as S from '../src/js/storage.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = () => L.newSheet({ name: 'A' }).tabs[0];
test('addChart: simpan rentang sebagai ID, pengaturan dibersihkan, id unik', () => {
  const t = mk(); const r = G.addChart(t, { r1: 0, c1: 0, r2: 5, c2: 1 }, 1, { kind: 'donut', title: '  Penjualan   Q1 ', legend: false }); assert.equal(r.ok, true); assert.match(r.id, /^g[a-z0-9]{3,12}$/);
  assert.deepEqual(t.charts[0], { id: r.id, kind: 'donut', title: 'Penjualan Q1', legend: false, r1: t.rows[0].id, c1: t.cols[0].id, r2: t.rows[5].id, c2: t.cols[1].id, vc: t.cols[1].id });
  const r2 = G.addChart(t, { r1: 0, c1: 0, r2: 2, c2: 2 }, 2, { kind: 'aneh' }); assert.notEqual(r2.id, r.id); assert.equal(t.charts[1].kind, 'column'); assert.equal(t.charts[1].legend, true);
  const l = G.chartList(t); assert.equal(l[0].ref, 'A1:B6'); assert.deepEqual(l[0].src, { r1: 0, c1: 0, r2: 5, c2: 1 }); assert.equal(l[0].valueCol, 1); assert.equal(l[1].valueCol, 2); assert.equal(G.getChart(t, r.id).kind, 'donut'); assert.equal(G.getChart(t, 'gnone'), null);
});
test('addChart: menolak rentang buruk, kolom nilai salah, dan melebihi batas tanpa mengubah apa pun', () => {
  const t = mk(); const before = JSON.stringify(t);
  for (const [s, v, why] of [[{ r1: 3, c1: 0, r2: 1, c2: 1 }, 1, 'rentang'], [{ r1: 0, c1: 0, r2: 999, c2: 1 }, 1, 'rentang'], [{ r1: 0, c1: 0.5, r2: 1, c2: 1 }, 1, 'rentang'], [null, 1, 'rentang'], [{ r1: 0, c1: 0, r2: 3, c2: 2 }, 0, 'kolom'], [{ r1: 0, c1: 1, r2: 3, c2: 2 }, 0, 'kolom'], [{ r1: 0, c1: 0, r2: 3, c2: 1 }, 2, 'kolom'], [{ r1: 0, c1: 0, r2: 3, c2: 1 }, 1.5, 'kolom']]) assert.equal(G.addChart(t, s, v, {}).reason, why);
  assert.equal(JSON.stringify(t), before);
  for (let i = 0; i < G.MAX_CHARTS; i++) assert.ok(G.addChart(t, { r1: 0, c1: 0, r2: 2, c2: 1 }, 1).ok); const full = JSON.stringify(t); assert.equal(G.addChart(t, { r1: 0, c1: 0, r2: 2, c2: 1 }, 1).reason, 'batas'); assert.equal(JSON.stringify(t), full);
});
test('updateChart dan removeChart; kunci charts hilang bila kosong', () => {
  const t = mk(); const { id } = G.addChart(t, { r1: 0, c1: 0, r2: 4, c2: 1 }, 1, { title: 'x' });
  assert.equal(G.updateChart(t, id, { kind: 'bar', title: 'Baru', legend: false }), true); assert.deepEqual([t.charts[0].kind, t.charts[0].title, t.charts[0].legend], ['bar', 'Baru', false]);
  assert.equal(G.updateChart(t, id, { kind: 'bar' }), false); assert.equal(G.updateChart(t, 'gnone', { kind: 'bar' }), false); assert.equal(G.updateChart(t, id, { title: 'y'.repeat(200) }), true); assert.equal(t.charts[0].title.length, G.MAX_CHART_TITLE);
  assert.equal(G.removeChart(t, 'gnone'), false); assert.equal(G.removeChart(t, id), true); assert.equal('charts' in t, false); assert.equal(G.removeChart(t, id), false);
});
test('sisip/hapus baris-kolom: rentang ikut menyusut/membesar; sudut atau kolom nilai terhapus membuang diagram', () => {
  const t = mk(); G.addChart(t, { r1: 0, c1: 0, r2: 4, c2: 2 }, 2);
  L.insertRow(t, 2); assert.equal(G.chartList(t)[0].ref, 'A1:C6'); L.deleteRow(t, t.rows[2].id); assert.equal(G.chartList(t)[0].ref, 'A1:C5');
  L.deleteCol(t, t.cols[1].id); assert.equal(G.chartList(t)[0].ref, 'A1:B5'); assert.equal(G.chartList(t)[0].valueCol, 1);
  L.deleteRow(t, t.rows[3].id); assert.equal(G.chartList(t)[0].ref, 'A1:B4'); // baris tengah terhapus: rentang menyusut, diagram tetap
});
test('sudut terhapus melepas diagram', () => {
  const a = mk(); G.addChart(a, { r1: 1, c1: 0, r2: 4, c2: 1 }, 1); L.deleteRow(a, a.rows[1].id); assert.equal('charts' in a, false);
  const b = mk(); G.addChart(b, { r1: 1, c1: 0, r2: 4, c2: 1 }, 1); L.deleteRow(b, b.rows[4].id); assert.equal('charts' in b, false);
  const c = mk(); G.addChart(c, { r1: 0, c1: 0, r2: 3, c2: 2 }, 2); L.deleteCol(c, c.cols[2].id); assert.equal('charts' in c, false); // kolom nilai (dan sudut) terhapus
  const d = mk(); G.addChart(d, { r1: 0, c1: 0, r2: 3, c2: 2 }, 1); L.deleteCol(d, d.cols[1].id); assert.equal('charts' in d, false); // kolom nilai terhapus, sudut masih ada
  const e = mk(); G.addChart(e, { r1: 0, c1: 0, r2: 3, c2: 2 }, 2); L.deleteCol(e, e.cols[0].id); assert.equal('charts' in e, false); // kolom label terhapus
});
test('simpan/muat: cleanTab membuang diagram rusak, id ganda, dan melebihi batas; data lama tetap sama persis', () => {
  const t = mk(); const { id } = G.addChart(t, { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, { kind: 'bar', title: 'T' });
  const raw = JSON.parse(JSON.stringify(t)); const ok = raw.charts[0];
  raw.charts.push({ ...ok }, { ...ok, id: 'gbad1', r1: 'rX' }, { ...ok, id: 'BAD' }, { ...ok, id: 'gv0001', vc: 'cA' }, { ...ok, id: 'gv0002', vc: 'cC', c2: 'cB' }, null, 'x', { ...ok, id: 'gswap1', r1: ok.r2, r2: ok.r1, kind: 'zzz', title: 5, legend: 0 });
  const c = L.cleanTab(raw); assert.deepEqual(c.charts.map((x) => x.id), [id, 'gswap1']); assert.deepEqual(c.charts[0], t.charts[0]);
  assert.deepEqual(c.charts[1], { id: 'gswap1', kind: 'column', title: '5', legend: true, r1: ok.r1, c1: ok.c1, r2: ok.r2, c2: ok.c2, vc: ok.vc }); // sudut ditukar dinormalkan
  const many = JSON.parse(JSON.stringify(t)); many.charts = []; for (let i = 0; i < 20; i++) many.charts.push({ ...ok, id: 'gx' + String(i).padStart(3, '0') }); assert.equal(L.cleanTab(many).charts.length, G.MAX_CHARTS);
  const old = mk(); const oc = L.cleanTab(JSON.parse(JSON.stringify(old))); assert.equal('charts' in oc, false); assert.equal(JSON.stringify(oc), JSON.stringify(old));
  const sh = L.newSheet({ name: 'A' }); G.addChart(sh.tabs[0], { r1: 0, c1: 0, r2: 2, c2: 1 }, 1); const back = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.deepEqual(back.tabs[0].charts, sh.tabs[0].charts);
});
test('normalize data penuh + ekspor JSON: diagram bertahan lewat penyimpanan (SCHEMA 17)', () => {
  const sh = L.newSheet({ name: 'A' }); const t = sh.tabs[0]; G.addChart(t, { r1: 0, c1: 0, r2: 3, c2: 1 }, 1, { kind: 'donut' });
  const d = S.normalize({ version: 16, tasks: [], habits: [], priv: [], trash: [], notes: [], sheets: { [sh.id]: sh } });
  assert.deepEqual(d.sheets[sh.id].tabs[0].charts, t.charts); const back = S.importJSON(S.exportJSON(d)); assert.equal(back.ok, true); assert.deepEqual(back.data.sheets[sh.id].tabs[0].charts, t.charts);
  assert.ok(S.exportJSON(d).includes('"version": 22'));
});
test('diagram tersimpan dapat digambar: chartList -> chartData -> chartSvg (mesin Rev 156)', () => {
  const t = mk(); const put = (i, j, v) => L.setCell(t, t.rows[i].id, t.cols[j].id, { v });
  put(0, 0, 'Bulan'); put(0, 1, 'Jual'); put(1, 0, 'Jan'); put(1, 1, 10); put(2, 0, 'Feb'); put(2, 1, 30);
  const { id } = G.addChart(t, { r1: 0, c1: 0, r2: 2, c2: 1 }, 1, { kind: 'bar', title: '' }); const c = G.getChart(t, id);
  const data = D.chartData(t, c.src, { valueCol: c.valueCol }); assert.equal(data.ok, true); assert.deepEqual(data.values, [10, 30]);
  const svg = D.chartSvg(data, { kind: c.kind, title: c.title || data.title, legend: c.legend }); assert.equal(svg.ok, true); assert.match(svg.svg, /^<svg /); assert.ok(svg.svg.includes('Jan')); assert.ok(svg.svg.includes('Batang: Jual'));
  assert.deepEqual(G.CHART_KINDS_SAVED, D.CHART_KINDS); assert.equal(G.MAX_CHART_TITLE, D.MAX_TITLE);
});
test('Rev 158: modul murni TANPA impor, belum ada UI/penyimpanan baru, SCHEMA 17, versi 0.3.121, tes terdaftar', () => {
  const g = src('src/js/lembar-grafik.js'); assert.ok(!/^\s*import\s/m.test(g)); assert.ok(!/document\.|localStorage|eval\(|new Function|Capacitor/.test(g));
  for (const f of ['lembar-ui', 'lembar-pulau', 'export', 'share', 'notes', 'main', 'storage', 'lembar-diagram', 'lembar-alat']) assert.doesNotMatch(src('src/js/' + f + '.js'), /lembar-grafik/, f); // hanya lembar.js yang mengimpor
  assert.match(src('src/js/lembar.js'), /from '\.\/lembar-grafik\.js'/); assert.doesNotMatch(src('src/js/lembar.js'), /lembar-diagram/);
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/); assert.equal(S.SCHEMA, 22);
  const pk = src('package.json'); assert.match(pk, /"version": "0\.3\.121"/); assert.ok(pk.includes('tests/rev158.test.mjs')); assert.match(src('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
