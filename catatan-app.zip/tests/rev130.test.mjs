// Rev 130 / U8a-4b: tombol Σ (tebakan rentang AutoSum) + kabel UI.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { sumGuess } from '../src/js/rumus-bantu.js';
import { a1ToStored, computeTab } from '../src/js/rumus.js';
import * as L from '../src/js/lembar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => L.newTab('T', 8);
const put = (t, r, c, p) => L.setCell(t, t.rows[r].id, t.cols[c].id, p);
test('sumGuess: deretan angka di atas -> rentang kolom; satu sel -> tanpa titik dua', () => {
  const t = mk(); put(t, 0, 0, { v: 1 }); put(t, 1, 0, { v: 2 }); put(t, 2, 0, { v: 3 });
  assert.deepEqual(sumGuess(t, 3, 0), { text: '=SUM(A1:A3)', dir: 'up' });
  assert.deepEqual(sumGuess(t, 1, 0), { text: '=SUM(A1)', dir: 'up' });
});
test('sumGuess: teks/kosong menghentikan deretan; header teks tidak ikut', () => {
  const t = mk(); put(t, 0, 1, { v: 'Judul' }); put(t, 1, 1, { v: 5 }); put(t, 2, 1, { v: 6 });
  assert.equal(sumGuess(t, 3, 1).text, '=SUM(B2:B3)');
  put(t, 4, 1, { v: 7 }); assert.equal(sumGuess(t, 6, 1), null); // sel kosong di r5 memutus deretan
});
test('sumGuess: tanpa angka di atas, cari ke kiri; sel berumus dihitung angka; di luar batas / masukan rusak = null', () => {
  const t = mk(); put(t, 2, 0, { v: 4 }); put(t, 2, 1, { v: 5 });
  assert.deepEqual(sumGuess(t, 2, 2), { text: '=SUM(A3:B3)', dir: 'left' });
  const u = mk(); put(u, 0, 0, { v: 1 }); put(u, 1, 0, { fx: '=1' }); assert.equal(sumGuess(u, 2, 0).text, '=SUM(A1:A2)');
  assert.equal(sumGuess(u, 0, 0), null); assert.equal(sumGuess(null, 0, 0), null); assert.equal(sumGuess(u, 99, 0), null); assert.equal(sumGuess(u, 1.5, 0), null); assert.equal(sumGuess(u, 2, -1), null);
});
test('hasil tebakan valid dan benar bila disimpan lewat alur ketik', () => {
  const t = mk(); put(t, 0, 0, { v: 10 }); put(t, 1, 0, { v: 20 });
  const g = sumGuess(t, 2, 0), r = a1ToStored(g.text, t); assert.ok(r.ok); put(t, 2, 0, { fx: r.fx });
  assert.equal(computeTab(t, { now: 0 }).get(t.rows[2].id, t.cols[0].id), 30);
});
test('kabel lembar-ui: bS di baris alat, pointerdown preventDefault, memicu input; sumGuess murni', () => {
  const u = src('src/js/lembar-ui.js'), m = src('src/js/rumus-bantu.js');
  assert.match(u, /sumGuess\(tab, sel\.r, sel\.c\)/); assert.match(u, /bU, bR, bS, bB, bI, bAL, bAC, bAR, bBg, bFg/); assert.match(u, /bS\.addEventListener\('pointerdown', \(e\) => e\.preventDefault\(\)\)/);
  assert.match(u, /g \? g\.text : '=SUM\('/); assert.match(u, /bS\.disabled = !on/);
  assert.doesNotMatch(m, /document|window|localStorage|eval\(|new Function/); assert.match(src('src/css/styles.css'), /\.lz-fb\.fb-s\{/);
});
test('Rev 130: versi 0.3.121, SCHEMA 13 (naik di Rev 132), tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev130.test.mjs'));
});
