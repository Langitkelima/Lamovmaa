// Rev 240 / Tahap 9a: Worker batas BULANAN opsional (monthLimit). Fetch PALSU; KV tiruan. Bukan bukti dari Cloudflare nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = (o = {}) => { const m = new Map(), reads = []; return { m, reads, get: async (k) => { reads.push(k); if (o.getFail) throw new Error('kv'); return m.has(k) ? m.get(k) : null; }, put: async (k, v) => { if (o.putFail && k.startsWith(o.putFail)) throw new Error('kv'); m.set(k, v); } }; };
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), GEMINI_KEY: 'gm-FAKE-0123456789-tes', ...x });
const NOW = Date.UTC(2026, 10, 12, 5, 0, 0);
const req = (o = {}) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'research', messages: [{ role: 'user', content: 'Tes?' }], ...o }) });
const GOOD = { candidates: [{ content: { role: 'model', parts: [{ text: 'Jawab.' }] }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: 3, candidatesTokenCount: 2 } };
async function run(env, o, now = NOW) { const calls = []; const orig = globalThis.fetch; globalThis.fetch = async (url, init) => { calls.push({ url, init }); return { ok: true, status: 200, json: async () => GOOD }; }; try { const r = await T.handle(req(o), env, now); return { calls, status: r.status, j: await r.json() }; } finally { globalThis.fetch = orig; } }
test('monthLimitFor: tanpa/0/rusak = 0 (tanpa batas bulanan); pecahan dibulatkan ke bawah; maks. 100000', () => {
  for (const v of [undefined, null, 0, -3, '5', NaN, Infinity, {}, [], true]) assert.equal(T.monthLimitFor({ monthLimit: v }), 0, String(v));
  assert.equal(T.monthLimitFor(undefined), 0); assert.equal(T.monthLimitFor({ monthLimit: 5.9 }), 5); assert.equal(T.monthLimitFor({ monthLimit: 999999 }), 100000);
});
test('monthKey mengikuti WIB: 31 Okt 16.59 UTC masih Oktober, 17.00 UTC sudah November', () => {
  assert.equal(T.monthKey(Date.UTC(2026, 9, 31, 16, 59)), '2026-10'); assert.equal(T.monthKey(Date.UTC(2026, 9, 31, 17, 0)), '2026-11'); assert.equal(T.monthKey(NOW), '2026-11');
});
test('tanpa monthLimit: perilaku lama; tidak ada baca/tulis KV bulanan; jawaban tanpa monthUsed', async () => {
  const e = env0(), r = await run(e, {}); assert.equal(r.status, 200); assert.equal(r.j.used, 1); assert.equal('monthUsed' in r.j, false);
  assert.deepEqual([...e.KV.m.keys()].filter((k) => k.startsWith('mon:')), []); assert.equal(e.KV.reads.some((k) => k.startsWith('mon:')), false);
});
test('monthLimit 3: tiga permintaan lolos dan dihitung; yang keempat 429, tanpa memanggil penyedia dan tanpa menambah hitungan harian/bulanan', async () => {
  const e = env0(); let last;
  for (let i = 1; i <= 3; i++) { last = await run(e, { monthLimit: 3 }); assert.equal(last.status, 200); assert.equal(last.j.monthUsed, i); assert.equal(last.j.monthLimit, 3); }
  assert.equal(T.parseMon(e.KV.m.get('mon:rama:2026-11')).n, 3); assert.equal(e.KV.m.get('use:rama:2026-11-12'), '3');
  const r = await run(e, { monthLimit: 3 }); assert.equal(r.status, 429); assert.equal(r.j.ok, false); assert.match(r.j.error, /Batas bulanan tercapai \(3\/3\)/); assert.equal(r.calls.length, 0);
  assert.equal(T.parseMon(e.KV.m.get('mon:rama:2026-11')).n, 3); assert.equal(e.KV.m.get('use:rama:2026-11-12'), '3');
});
test('bulan baru memakai hitungan baru; orang lain tidak terpengaruh', async () => {
  const e = env0({ PASS_DESY: 'desy-secret-12' }); e.KV.m.set('mon:rama:2026-11', '3');
  assert.equal((await run(e, { monthLimit: 3 })).status, 429);
  const des = await run(e, { key: 'desy-secret-12', monthLimit: 3 }); assert.equal(des.status, 200); assert.equal(des.j.monthUsed, 1);
  const des2 = await run(e, { monthLimit: 3 }, Date.UTC(2026, 11, 1, 5, 0, 0)); assert.equal(des2.status, 200); assert.equal(des2.j.monthUsed, 1); assert.equal(T.parseMon(e.KV.m.get('mon:rama:2026-12')).n, 1);
});
test('batas harian 0 (tanpa batas harian) tetap menaati batas bulanan; batas bulanan dicek lebih dulu dari harian', async () => {
  const e = env0(); e.KV.m.set('mon:rama:2026-11', '2'); const r = await run(e, { limit: 0, monthLimit: 2 }); assert.equal(r.status, 429); assert.match(r.j.error, /Batas bulanan/);
  const f = env0(); f.KV.m.set('mon:rama:2026-11', '2'); f.KV.m.set('use:rama:2026-11-12', '5'); const g = await run(f, { limit: 5, monthLimit: 2 }); assert.equal(g.status, 429); assert.match(g.j.error, /Batas bulanan/);
  const h = env0(); h.KV.m.set('use:rama:2026-11-12', '5'); const i = await run(h, { limit: 5, monthLimit: 100 }); assert.equal(i.status, 429); assert.match(i.j.error, /Batas harian/); assert.equal(h.KV.m.has('mon:rama:2026-11'), false);
});
test('aman bila KV bermasalah: tanpa KV atau gagal baca = 503 dan tidak memanggil penyedia; gagal tulis hitungan bulan = permintaan tetap jalan', async () => {
  const a = await run(env0({ KV: undefined }), { monthLimit: 3 }); assert.equal(a.status, 503); assert.equal(a.calls.length, 0);
  const b = await run(env0({ KV: kv({ getFail: true }) }), { monthLimit: 3 }); assert.equal(b.status, 503); assert.equal(b.calls.length, 0);
  const e = env0({ KV: kv({ putFail: 'mon:' }) }), c = await run(e, { monthLimit: 3 }); assert.equal(c.status, 200); assert.equal(e.KV.m.get('use:rama:2026-11-12'), '1');
});
test('whoami/usage melaporkan monthUsed; chat, research, dan ocr sama-sama memakai monthLimitFor; kunci KV hanya bulan per orang', async () => {
  const e = env0(); e.KV.m.set('mon:rama:2026-11', '7'); const r = await run(e, { action: 'usage' }); assert.equal(r.j.monthUsed, 7); assert.equal(r.j.used, 0);
  const w = src('backend/cloudflare/worker.mjs'); assert.equal((w.match(/consume\(env, me, now, limitFor\(env, body\), monthLimitFor\(body\)\)/g) || []).length, 3); // Rev 352: aksi ocr = pemakai ketiga (chat, research, ocr), disesuaikan DISENGAJA
  assert.ok(!/mon:' \+ me \+ ':' \+ monthKey\(now\)[^;]*(passcode|pass|key)/i.test(w));
});
test('versi 0.3.121; SCHEMA 20 tetap; tes terdaftar; panduan Worker menyebut batas bulanan opsional', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev240\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22;/);
  assert.match(src('backend/cloudflare/PANDUAN_WORKER.md'), /monthLimit/);
});
