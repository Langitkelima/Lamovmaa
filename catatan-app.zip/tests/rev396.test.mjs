// Rev 396 / PART M1: mesin murni catatan <-> Markdown (tanpa UI). Perilaku HP belum diuji.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import { noteToMarkdown, markdownToNote, MD_MAX } from '../src/js/md-catatan.js';
import { parseNoteHtml } from '../src/js/export.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const plain = (b) => (b.runs || []).map((r) => r.t).join('');
const HTML = '<div>Satu <b>tebal</b> dan <i>miring</i></div><div class="todo"><input type="checkbox" checked="">&nbsp;Beli beras</div><div class="todo"><input type="checkbox">&nbsp;Cuci</div><ul><li>a<ul><li>b</li></ul></li></ul><ol><li>x</li><li>y</li></ol><blockquote>kutipan</blockquote>';

test('ekspor: front matter judul/label/dibuat + isi Markdown, tanpa heading judul ganda', () => {
  const md = noteToMarkdown({ title: 'Belanja "mingguan"', html: HTML }, { labelNames: ['rumah', 'penting'], created: '2026-11-20' });
  assert.ok(md.startsWith('---\njudul: "Belanja \\"mingguan\\""\nlabel: ["rumah", "penting"]\ndibuat: 2026-11-20\n---\n'));
  assert.ok(md.includes('- [x] Beli beras') && md.includes('- [ ] Cuci') && md.includes('**tebal**') && md.includes('> kutipan'));
  assert.ok(!/^# /m.test(md));
  const k = noteToMarkdown({ title: '', html: '' }, {}); assert.ok(k.startsWith('---\njudul: ""\n---'));
  assert.ok(!noteToMarkdown({ title: 'x', html: '<div>a</div>' }, { created: 'kemarin' }).includes('dibuat'));
});
test('impor: kembali bolak-balik (ekspor lalu impor) menjaga judul, label, ceklis, daftar, format', () => {
  const md = noteToMarkdown({ title: 'Belanja', html: HTML }, { labelNames: ['rumah'], created: '2026-11-20' });
  const r = markdownToNote(md);
  assert.equal(r.title, 'Belanja'); assert.deepEqual(r.labels, ['rumah']); assert.equal(r.created, '2026-11-20');
  const bl = parseNoteHtml(r.html); const k = bl.map((b) => b.kind);
  assert.deepEqual(k, ['p', 'todo', 'todo', 'ul', 'ul', 'ol', 'ol', 'quote']);
  assert.equal(bl[1].checked, true); assert.equal(bl[2].checked, false); assert.equal(plain(bl[1]), 'Beli beras');
  assert.equal(bl[3].depth, 0); assert.equal(bl[4].depth, 1); assert.equal(plain(bl[4]), 'b');
  const p = bl[0].runs; assert.ok(p.some((x) => x.b && x.t === 'tebal') && p.some((x) => x.i && x.t === 'miring'));
});
test('impor dari aplikasi lain: judul # pertama, heading jadi tebal, * + sebagai bullet, 1) bernomor, tag/URL', () => {
  const r = markdownToNote('# Rapat\n\n## Agenda\n* satu\n+ dua\n\n1) pertama\n2) kedua\n\nLihat [situs](https://a.id) dan https://b.id\n');
  assert.equal(r.title, 'Rapat');
  const bl = parseNoteHtml(r.html);
  assert.deepEqual(bl.map((b) => b.kind), ['p', 'ul', 'ul', 'ol', 'ol', 'p']);
  assert.ok(bl[0].runs.some((x) => x.b && x.t === 'Agenda'));
  assert.ok(plain(bl[5]).includes('situs (https://a.id)') && plain(bl[5]).includes('https://b.id'));
});
test('impor aman: HTML mentah di-escape, kode dan garis pemisah, escape \\*, gambar dicatat sebagai warning', () => {
  const r = markdownToNote('<script>alert(1)</script> & <b>x</b>\n\n---\n\n```\n**bukan tebal**\n```\n\n\\*polos\\* dan `a*b*c`\n\n![peta](img/p.png)\n');
  assert.ok(!/<script|<b>x/.test(r.html) && r.html.includes('&lt;script&gt;') && r.html.includes('&amp;'));
  assert.ok(r.html.includes('**bukan tebal**') && r.html.includes('*polos*') && r.html.includes('a*b*c'));
  assert.ok(!r.html.includes('<i>') && !r.html.includes('<hr'));
  assert.ok(r.html.includes('[gambar: peta]') && r.warnings.includes('gambar:1'));
});
test('impor tabel: baris judul jadi TH dan sel kosong dilengkapi; hanya tag yang diizinkan sanitize()', () => {
  const r = markdownToNote('| Nama | Qty |\n| --- | ---: |\n| Beras | 2 |\n| Telur |\n\nsesudah');
  const bl = parseNoteHtml(r.html); const t = bl.find((b) => b.kind === 'table');
  assert.ok(t && t.rows.length === 3 && t.rows[0].length === 2 && t.rows[2].length === 2 && t.headerRow === true);
  assert.equal(plain(bl[bl.length - 1]), 'sesudah');
  const OK = new Set(['B', 'I', 'S', 'UL', 'OL', 'LI', 'DIV', 'BLOCKQUOTE', 'BR', 'INPUT', 'TABLE', 'TBODY', 'TR', 'TD', 'TH']);
  for (const m of r.html.matchAll(/<\/?([a-z0-9]+)/gi)) assert.ok(OK.has(m[1].toUpperCase()), m[1]);
});
test('front matter gaya aplikasi lain (title/tags daftar, CRLF, BOM) dan teks polos tanpa judul', () => {
  const r = markdownToNote('\uFEFF---\r\ntitle: Ide\r\ntags:\r\n  - kerja\r\n  - "#baru"\r\ndate: 2025-01-02T10:00:00\r\n---\r\nIsi satu\r\nIsi dua\r\n');
  assert.equal(r.title, 'Ide'); assert.deepEqual(r.labels, ['kerja', 'baru']); assert.equal(r.created, '2025-01-02');
  assert.deepEqual(parseNoteHtml(r.html).map(plain), ['Isi satu', 'Isi dua']);
  const p = markdownToNote('hanya teks\nbaris dua'); assert.equal(p.title, ''); assert.equal(parseNoteHtml(p.html).length, 2);
  assert.deepEqual(markdownToNote('').html, ''); assert.deepEqual(markdownToNote(null).labels, []);
});
test('batas: berkas terlalu panjang dipotong + warning; judul maksimal 120 huruf', () => {
  const r = markdownToNote('x\n'.repeat(MD_MAX)); assert.ok(r.warnings.includes('terpotong'));
  assert.equal(markdownToNote('# ' + 'a'.repeat(300)).title.length, 120);
});
test('modul murni: tanpa DOM/storage/jaringan; kode aplikasi lain tidak berubah (SCHEMA 22, versi 0.3.121); pemakai hanya ekspor-md.js (Rev 397) dan impor-md.js (Rev 398)', () => {
  const s = rd('src/js/md-catatan.js'); assert.ok(!/\b(document|window|localStorage|fetch)\b/.test(s));
  assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/); assert.equal(JSON.parse(rd('package.json')).version, '0.3.121');
  assert.ok(!fs.readdirSync(new URL('../src/js/', import.meta.url)).some((f) => !['md-catatan.js', 'ekspor-md.js', 'impor-md.js'].includes(f) && f.endsWith('.js') && rd('src/js/' + f).includes('md-catatan')));
});
