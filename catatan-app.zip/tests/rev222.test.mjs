// Rev 220 / v0.3.121: Creative Studio (Tahap 3c) = aksi kreatif di dialog Tulis AI.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { WRITE_ACTIONS, CREATIVE_ACTIONS, ALL_ACTIONS, buildPrompt, tulisDenganAI } from '../src/js/ai/tulis.js';
import { TASK_CHOICES, CHAT_MAX_MSG } from '../src/js/ai/sambungan.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const conn = { url: 'https://kelimaa-ai.dhani5081.workers.dev', key: 'abcdefgh1', me: 'rama' };
test('tabel kreatif: id unik se-ALL_ACTIONS, jalur creative, jenis pekerjaan sah, 7 aksi tulis lama utuh', () => {
  assert.equal(WRITE_ACTIONS.length, 7); assert.equal(CREATIVE_ACTIONS.length, 5); assert.equal(new Set(ALL_ACTIONS.map((a) => a.id)).size, ALL_ACTIONS.length);
  for (const a of CREATIVE_ACTIONS) { assert.equal(a.task, 'creative.general'); assert.ok(TASK_CHOICES.some((t) => t[0] === a.task)); assert.ok(a.ins.length > 20 && a.label); }
  assert.deepEqual(CREATIVE_ACTIONS.filter((a) => a.tambah).map((a) => a.id), ['judul', 'caption', 'ide']);
});
test('buildPrompt kreatif: satu pesan di bawah batas Worker, membawa tanda tambah', () => {
  const j = buildPrompt('judul', 'Kopi pagi'); assert.ok(j.ok); assert.equal(j.tambah, true); assert.equal(j.task, 'creative.general'); assert.ok(j.content.endsWith('Kopi pagi')); assert.ok(j.content.length <= CHAT_MAX_MSG);
  assert.equal(buildPrompt('puisi', 'Kopi pagi').tambah, false); assert.equal(buildPrompt('rapikan', 'x').tambah, false);
});
test('tulisDenganAI kreatif: task creative.general, satu pesan, tambah diteruskan', async () => {
  let sent; const http = async (q) => { sent = JSON.parse(q.body); return { status: 200, text: JSON.stringify({ ok: true, text: '1. Satu\n2. Dua', provider: 'sakelar', model: 'm' }) }; };
  const r = await tulisDenganAI(conn, { on: true }, 'caption', 'Kopi enak', http);
  assert.equal(r.ok, true); assert.equal(r.tambah, true); assert.equal(sent.task, 'creative.general'); assert.equal(sent.messages.length, 1); assert.match(r.text, /^1\. Satu/);
});
test('tulisui.js: dua kelompok chip, Ganti nonaktif untuk usulan, tetap dimuat malas', () => {
  const u = src('src/js/ai/tulisui.js');
  assert.match(u, /CREATIVE_ACTIONS/); assert.match(u, /bReplace\.disabled = !!r\.tambah/); assert.match(u, /'Kreatif'/);
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\//); assert.doesNotMatch(src('src/js/notes.js'), /from '\.\/ai\//);
});
