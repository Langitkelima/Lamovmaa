// Rev 249: pencarian gagal di Google (batas/sibuk) -> jawaban lewat jalur lain TANPA web, ditandai noSearch. Fetch PALSU.
import test from 'node:test'; import assert from 'node:assert/strict';
import W from '../backend/cloudflare/worker.mjs';
import { researchText, NO_SEARCH } from '../src/js/ai/riset.js';
const T = W._t;
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const GK = 'gm-FAKE-0123456789-tes', SK = 'sk-FAKE-0123456789-tes';
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), GEMINI_KEY: GK, RETRY_MS: [], ...x });
const NOW = Date.UTC(2026, 10, 12, 5, 0, 0);
const post = (b) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify(b) });
const req = (o = {}) => ({ key: 'rama-secret-12', action: 'research', messages: [{ role: 'user', content: 'Berita hari ini?' }], ...o });
const quota = { ok: false, status: 429, json: async () => ({ error: { message: 'You exceeded your current quota' } }) };
const chatOk = { ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'Jawaban dari pengetahuan.' } }], usage: { prompt_tokens: 7, completion_tokens: 4 } }) };
async function run(env, b, fn) { const calls = []; const orig = globalThis.fetch; globalThis.fetch = async (url, init) => { calls.push({ url, init }); return fn(url, init); }; try { const r = await T.handle(post(b), env, NOW); return { calls, status: r.status, j: await r.json() }; } finally { globalThis.fetch = orig; } }
const route = (url) => (url.includes('generativelanguage') ? quota : chatOk);

test('Gemini kena batas + ada kunci Sakelar -> jawaban noSearch lewat Sakelar, tanpa sumber, jatah dihitung 1x', async () => {
  const r = await run(env0({ SAKELAR_KEY: SK }), req(), route);
  assert.equal(r.status, 200); assert.equal(r.j.ok, true); assert.equal(r.j.noSearch, true); assert.equal(r.j.grounded, false);
  assert.equal(r.j.provider, 'sakelar'); assert.equal(r.j.fallbackProvider, 'gemini'); assert.deepEqual(r.j.sources, []); assert.equal(r.j.used, 1);
  assert.equal(r.j.text, 'Jawaban dari pengetahuan.'); assert.deepEqual(r.j.usage, { in: 7, out: 4 });
  const body = JSON.parse(r.calls[r.calls.length - 1].init.body); assert.ok(body.messages[0].content.includes('TIDAK tersedia'));
  assert.ok(!JSON.stringify(r.j).includes(GK) && !JSON.stringify(r.j).includes(SK));
});
test('Gemini kena batas dan TIDAK ada kunci jalur lain -> galat lama (tidak ada cadangan)', async () => {
  const r = await run(env0(), req(), route); assert.equal(r.status, 503); assert.equal(r.j.ok, false); assert.ok(/Gemini/.test(r.j.error));
});
test('Gemini sukses -> tidak ada panggilan ke jalur lain dan tanpa noSearch', async () => {
  const good = { ok: true, status: 200, json: async () => ({ candidates: [{ content: { parts: [{ text: 'ok' }] }, groundingMetadata: { groundingChunks: [{ web: { uri: 'https://a.example/x', title: 'a' } }] } }] }) };
  const r = await run(env0({ SAKELAR_KEY: SK }), req(), () => good); assert.equal(r.calls.length, 1); assert.equal(r.j.noSearch, undefined); assert.equal(r.j.grounded, true);
});
test('jalur cadangan juga gagal -> galat Gemini dikembalikan', async () => {
  const r = await run(env0({ SAKELAR_KEY: SK }), req(), () => quota); assert.equal(r.j.ok, false);
});
test('aplikasi: teks riset noSearch diberi label khusus, bukan "belum terverifikasi"', () => {
  const t = researchText({ text: 'Halo', noSearch: true, sources: [] }); assert.ok(t.endsWith(NO_SEARCH)); assert.ok(!t.includes('Belum terverifikasi'));
  assert.ok(researchText({ text: 'Halo', sources: [] }).includes('Belum terverifikasi'));
});
