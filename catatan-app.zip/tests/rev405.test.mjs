// Rev 405 / K5: penutup Paket Kartu. TANPA perubahan kode aplikasi: hanya audit Chromium baru (tools/audit_kartu_k5.py), dokumen, dan tes ini.
// Tes AI (pemeriksaan berkas). Audit Chromium dijalankan terpisah (python3 tools/audit_kartu_k5.py); HP BELUM.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 405: audit K5 ada dan memeriksa gambar, dua gambar, gambar tinggi (dipotong), gambar hilang, lembar kerja, campuran, dan jalur layar', () => {
  const a = rd('tools/audit_kartu_k5.py');
  for (const k of ['gambar_biru', 'dua_gambar_gelap', 'gambar_tinggi', 'gambar_hilang', 'lembar_hijau', 'lembar_gelap', 'campuran_kuning', 'ui_gambar', 'ui_lembar', 'ui_gambar_hilang']) assert.ok(a.includes("'" + k + "'"), k);
  assert.ok(a.includes('window.__sheets = { sk5abc1: sh }'), 'data.sheets = peta {id: lembar}, BUKAN daftar'); // salah data uji ini sempat membuat lembar tampil "(tidak tersedia)"
  assert.ok(a.includes('Gambar di catatan tidak ikut karena tidak bisa dimuat.'));
});

test('Rev 405: kode kartu TIDAK berubah (pesan gambar hilang dan penanda potong masih ada) dan perilaku yang diaudit tetap tertulis di kode', () => {
  const ui = rd('src/js/kartu-ui.js'), k = rd('src/js/kartu.js');
  assert.ok(ui.includes("catatan = ' Gambar di catatan tidak ikut karena tidak bisa dimuat.'"));
  assert.ok(ui.includes('setSheetsSource(() => ctx.data.sheets)'));
  assert.ok(k.includes('… dipotong, selengkapnya ada di catatan'));
});

test('pemasangan: tes terdaftar, versi/SCHEMA tetap, banner Rev 405 paling atas di dokumen, 39.12 dan bagian uji HP CC diperbarui', () => {
  const pk = JSON.parse(rd('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev405\.test\.mjs/);
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
  for (const f of ['RIWAYAT.md', 'PROMPT_SERAH_TERIMA.md']) { const d = rd(f); assert.ok(/^\*\*Rev 4[0-3][0-9] \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 405 /') < d.indexOf('**Rev 404 /'), f); }
  assert.ok(rd('PROMPT_SERAH_TERIMA.md').includes('**39.12 STATUS (Rev 405):**'));
  assert.ok(rd('UJI_HP_RILIS.md').includes('(Rev 405, K5)'));
  assert.match(rd('README.md'), /Rev 405/);
});
