import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { addLocalDays, cleanCountdownTitle, countdownDays, countdownLabel, countdownDateLine, countdownBadge } from '../src/js/hitung-mundur.js';
import { parseNoteHtml } from '../src/js/export.js';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

test('Rev 85: tanggal lokal +7 hari dan hitung selisih kalender lintas bulan/tahun', () => {
  assert.equal(addLocalDays(new Date(2026, 10, 5, 23, 30), 7), '2026-11-12');
  assert.equal(addLocalDays(new Date(2026, 11, 29), 7), '2027-01-05');
  assert.equal(countdownDays('2026-11-12', new Date(2026, 10, 5, 23, 59)), 7);
  assert.equal(countdownDays('2026-11-04', new Date(2026, 10, 5, 0, 1)), -1);
});

test('Rev 85: label hari-H, masa depan, lewat, lencana dan judul aman', () => {
  const now = new Date(2026, 10, 5, 12);
  assert.equal(countdownLabel('2026-11-05', now), 'Hari ini!');
  assert.equal(countdownLabel('2026-11-12', now), '7 hari lagi');
  assert.equal(countdownLabel('2026-11-03', now), '2 hari lalu');
  assert.deepEqual(countdownBadge('2026-11-17'), { month: 'NOV', day: '17' });
  assert.equal(cleanCountdownTitle('  Acara\n  <uji>  '), 'Acara <uji>');
  assert.equal(cleanCountdownTitle('x'.repeat(100)).length, 80);
  assert.match(countdownDateLine('2026-11-17', '09:00'), /Selasa, 17 November 2026 · 09:00/);
});

test('Rev 85: kartu Hitung Mundur terdaftar, panel Sisipkan dan editor tersedia', () => {
  const notes = read('../src/js/notes.js');
  assert.match(notes, /insertBtn\('countdown'/);
  assert.match(notes, /registerBlock\(\{ type: 'cd', selector: '\.kb-countdown-block'/);
  assert.match(notes, /openCountdownEditor/);
  assert.match(notes, /data-kb-title/);
  assert.match(notes, /syncCountdownBlock/);
});

test('Rev 85: ekspor merangkum judul, tanggal, waktu opsional dan sisa hari', () => {
  const blocks = parseNoteHtml('<div class="kb-countdown-block" contenteditable="false" data-kb-date="2026-11-17" data-kb-time="09:00" data-kb-title="Ulang Tahun"><span class="kb-cd-badge"><span class="kb-cd-month">NOV</span><strong class="kb-cd-day">17</strong></span><span class="kb-cd-copy"><strong class="kb-cd-title">Ulang Tahun</strong><strong class="kb-cd-remaining">12 hari lagi</strong><small class="kb-cd-date">Selasa</small></span></div>');
  assert.equal(blocks.length, 1);
  assert.match(blocks[0].runs.map((r) => r.t).join(''), /^Hitung mundur: Ulang Tahun, Selasa, 17 November 2026 · 09:00 \(/);
});

test('Rev 85: sanitizer mengizinkan atribut terbatas dan SCHEMA/native tetap', () => {
  const notes = read('../src/js/notes.js');
  const storage = read('../src/js/storage.js');
  assert.match(notes, /k === 'data-kb-title' && v.length <= 80/);
  assert.match(notes, /k === 'data-kb-date' && isValidDateISO\(v\)/);
  assert.match(storage, /SCHEMA\s*=\s*22/);
  assert.doesNotMatch(notes, /registerPlugin\(|Capacitor\.Plugins/);
});
