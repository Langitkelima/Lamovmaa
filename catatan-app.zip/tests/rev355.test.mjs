// Rev 355 / PART O3b (Paket OCR): "Jadikan catatan baru" di dialog Pindai. Tes MURNI (draftDariOcr) + KABEL (tampilan dicek di audit Chromium).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { staticGraph } from '../scripts/preload.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const U = src('src/js/ai/ocr-ui.js'), N = src('src/js/notes.js');
const { draftDariOcr, OCR_TITLE_MAX } = await import('../src/js/ai/ocr-ui.js');
const { SHARE_IN_MAX } = await import('../src/js/logic.js'); const { TITLE_MAX } = await import('../src/js/ai/aksi.js');
test('draftDariOcr: judul = baris pertama berisi, isi = seluruh teks, html di-escape', () => {
  const d = draftDariOcr('\n  Belanja   mingguan \nSusu <b>2</b>\nRoti & telur');
  assert.equal(d.title, 'Belanja mingguan'); assert.equal(d.cut, false);
  assert.equal(d.text, 'Belanja   mingguan\nSusu <b>2</b>\nRoti & telur');
  assert.equal(d.html, '<div>Belanja   mingguan</div><div>Susu &lt;b&gt;2&lt;/b&gt;</div><div>Roti &amp; telur</div>');
  assert.doesNotMatch(d.html, /<b>/);
});
test('draftDariOcr: satu baris tetap jadi judul; tanda Markdown dari foto tidak diubah', () => {
  const d = draftDariOcr('**Tagihan** #12 _listrik_'); assert.equal(d.title, '**Tagihan** #12 _listrik_'); assert.equal(d.text, '**Tagihan** #12 _listrik_');
});
test('draftDariOcr: kosong/spasi/kontrol = null; CRLF dan baris kosong beruntun dirapikan; kontrol dibuang', () => {
  for (const v of ['', '   ', '\n\n', null, undefined, '\u0001\u0002']) assert.equal(draftDariOcr(v), null);
  const d = draftDariOcr('A\r\nB\n\n\n\n\n\nC\u0007'); assert.equal(d.text, 'A\nB\n\n\nC');
});
test('draftDariOcr: judul dipotong 60 huruf (sama dengan TITLE_MAX aksi.js); isi dipotong di SHARE_IN_MAX dan ditandai cut', () => {
  assert.equal(OCR_TITLE_MAX, TITLE_MAX); const d = draftDariOcr('x'.repeat(100)); assert.equal(d.title.length, 60);
  const big = draftDariOcr('Judul\n' + 'y'.repeat(SHARE_IN_MAX + 500)); assert.equal(big.cut, true); assert.ok(big.text.length <= SHARE_IN_MAX);
  const emo = draftDariOcr('a'.repeat(SHARE_IN_MAX - 1) + '\u{1F600}'); assert.doesNotMatch(emo.text, /[\ud800-\udbff]$/);
});
test('kabel: tombol baru, hanya muncul bersama hasil, memakai createNote/removeNote (dimuat malas), Urungkan lewat toast, dialog tutup hanya bila berhasil', () => {
  assert.ok(U.includes("'Jadikan catatan baru'")); assert.match(U, /ta\.hidden = bIns\.hidden = bNew\.hidden = bCopy\.hidden = false/); assert.match(U, /ta\.hidden = bIns\.hidden = bNew\.hidden = bCopy\.hidden = true/);
  assert.match(U, /await import\('\.\/aksi\.js'\)/); assert.doesNotMatch(U, /^import .*aksi\.js/m); assert.match(U, /createNote\(ctx, \{ title: d\.title, text: d\.text, html: d\.html \}\)/);
  assert.match(U, /tOk\('Catatan baru dibuat dari foto'[^\n]*removeNote\(ctx, n\.id\)/); assert.match(U, /if \(ok && ov\.isConnected\) close\(\);/);
  assert.match(U, /if \(!d\) \{ tWarn\('Teks kosong\.'\); return; \}/); assert.match(U, /tErr\('Catatan baru gagal dibuat\.'\)/);
  assert.match(N, /m\.mulaiOcr\(\{ ctx, r: caretRange\(\)/);
});
test('kabel: catatan yang sedang terbuka tidak disentuh (tanpa openEditor/appendNote/sisipTeks di jalur catatan baru), tanpa jaringan baru, tanpa penyimpanan lain', () => {
  const b = U.slice(U.indexOf('bNew.onclick'), U.indexOf('bCopy.onclick')); assert.doesNotMatch(b, /openEditor|appendNote|sisipTeks|onInsert|bacaFoto|fetch|localStorage/);
  const m = U.slice(U.indexOf('export function mulaiOcr')); assert.doesNotMatch(m.slice(0, m.indexOf('onInsert:')), /sisipTeks|ed\./);
  assert.equal((U.match(/bacaFoto\(/g) || []).length, 1); assert.doesNotMatch(U, /console\.|(?<!globalThis\.)localStorage|sessionStorage|innerHTML|insertAdjacentHTML|outerHTML/);
});
test('MALAS dan versi: ocr-ui/aksi tidak masuk jalur buka; versi 0.3.121 dan SCHEMA 22 tetap; tes terdaftar', () => {
  const g = staticGraph('js/main.js'); assert.equal(g.includes('js/ai/ocr-ui.js'), false);
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev355\.test\.mjs/);
});
