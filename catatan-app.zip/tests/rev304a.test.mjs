// Rev 304a / v0.3.121: kolom beku menyempit SEMENTARA saat digeser (tampilan saja). SCHEMA 22, CSS, Worker, native tidak berubah.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as B from '../src/js/lembar-beku.js';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('fzScale: 1 di posisi awal; menyempit sejalan geseran; berhenti di cap/W; tidak pernah naik lagi saat digeser jauh', () => {
  assert.equal(B.fzScale(288, 0, 221), 1); assert.ok(Math.abs(B.fzScale(288, 30, 221) - 258 / 288) < 1e-9); assert.ok(Math.abs(B.fzScale(288, 67, 221) - 221 / 288) < 1e-9);
  assert.ok(Math.abs(B.fzScale(288, 5000, 221) - 221 / 288) < 1e-9); assert.equal(B.fzScale(288, -20, 221), 1); assert.equal(B.fzScale(288, NaN, 221), 1);
});
test('fzScale: lebar beku <= cap atau masukan rusak = selalu 1 (perilaku lama tidak berubah)', () => {
  assert.equal(B.fzScale(192, 100, 221), 1); assert.equal(B.fzScale(0, 10, 221), 1); assert.equal(B.fzScale(288, 10, 0), 1); assert.equal(B.fzScale(NaN, 10, 221), 1);
});
test('fzTooWide: hanya bila faktor terkecil < 0,4 (W > 2,5 x cap)', () => {
  assert.equal(B.fzTooWide(288, 221), false); assert.equal(B.fzTooWide(552, 221), false); assert.equal(B.fzTooWide(553, 221), true); assert.equal(B.fzTooWide(960, 221), true);
});
test('pemasangan: lebar/kiri kolom beku memakai calc(... var(--fzs, 1)), onScroll memanggil fzUpdate, data lebar kolom tidak disentuh', () => {
  const ui = src('src/js/lembar-ui.js');
  assert.match(ui, /const fzPx = \(v\) => 'calc\(' \+ v \+ 'px \* var\(--fzs, 1\)\)'/); assert.match(ui, /const onScroll = \(\) => \{ fzUpdate\(\);/);
  assert.match(ui, /fzTooWide\(colLeft\(tab, cnt\), room \* 0\.7\)/); assert.ok(!/colLeft\(tab, cnt\) > room \* 0\.7/.test(ui));
  assert.ok(!/\.w\s*=\s*[^=].*fzs/.test(ui));
});
test('modul awal tidak berubah: lembar-beku.js tetap tanpa impor selain lembar.js; SCHEMA 22; versi 0.3.121', () => {
  const imps = [...src('src/js/lembar-beku.js').matchAll(/^import .* from '([^']+)'/gm)].map((m) => m[1]); assert.deepEqual(imps, ['./lembar.js']);
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
console.log(n + ' tes rev304a ok');
