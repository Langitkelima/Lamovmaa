// Rev 202a/202c / v0.3.121 (TANPA perubahan src/): Worker Kelimaa AI aksi `chat` lewat TIGA jalur (Sakelar, Relay Router, Gemini Google); Anthropic langsung dihapus. Berkas rev207.
// Semua tes memakai fetch PALSU (tidak ada jaringan, tidak ada kunci asli). Bentuk jawaban gaya OpenAI di sini adalah ASUMSI pengurai (Gemini sesuai dokumentasi resmi, lainnya belum terverifikasi), bukan bukti dari server nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, readdirSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const KEY = 'sk-FAKE-0123456789-tes';
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', PASS_DESY: 'desy-secret-34', KV: kv(), SAKELAR_KEY: KEY, ...x });
const NOW = Date.UTC(2026, 10, 11, 5, 0, 0);
const post = (b) => new Request('https://w.example/', { method: 'POST', body: typeof b === 'string' ? b : JSON.stringify(b) });
const chatReq = (o = {}) => ({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', messages: [{ role: 'user', content: 'Halo, apa kabar?' }], ...o });
const okJson = (o) => ({ ok: true, status: 200, json: async () => o });
const bad = (status, o) => ({ ok: false, status, json: async () => o });
async function withFetch(fn, body) { const calls = []; const orig = globalThis.fetch; globalThis.fetch = async (url, init) => { calls.push({ url, init }); return fn(url, init, calls.length); }; try { return { calls, ...(await body(calls)) }; } finally { globalThis.fetch = orig; } }
const run = async (env, b, fn = () => okJson({ choices: [{ message: { content: 'Baik!' }, finish_reason: 'stop' }], usage: { prompt_tokens: 5, completion_tokens: 2 } })) =>
  withFetch(fn, async () => { const r = await T.handle(post(b), env, NOW); const j = await r.json(); return { status: r.status, j, raw: JSON.stringify(j) }; });

test('kunci penyedia dan passcode TIDAK pernah ada di jawaban ke aplikasi', async () => {
  const r = await run(env0(), chatReq()); assert.ok(!r.raw.includes(KEY)); assert.ok(!r.raw.includes('rama-secret-12'));
  const r2 = await run(env0(), chatReq(), () => bad(401, { error: { message: 'invalid key ' + KEY } })); assert.ok(!r2.raw.includes(KEY));
});
test('tanpa KV = 503 (demi aman) dan tidak memanggil penyedia', async () => {
  const r = await run(env0({ KV: undefined }), chatReq()); assert.equal(r.status, 503); assert.match(r.j.error, /KV/); assert.equal(r.calls.length, 0);
});
test('batas harian: dipakai tiap chat, ditolak 429 setelah batas, per orang, tanpa memanggil penyedia saat ditolak', async () => {
  const e = env0({ DAILY_LIMIT: '2' });
  assert.equal((await run(e, chatReq())).j.used, 1); assert.equal((await run(e, chatReq())).j.used, 2);
  const r = await run(e, chatReq()); assert.equal(r.status, 429); assert.match(r.j.error, /2\/2/); assert.equal(r.calls.length, 0);
  assert.equal((await run(e, chatReq({ key: 'desy-secret-34' }))).j.me, 'desy');
});
test('jenis pekerjaan tak dikenal / pesan tak sah = 400 tanpa penyedia dan tanpa memakai jatah', async () => {
  const e = env0(); const U = (c) => ({ role: 'user', content: c });
  const kasus = [chatReq({ task: 'creative.caption' }), chatReq({ task: undefined }), chatReq({ messages: [] }), chatReq({ messages: 'halo' }), chatReq({ messages: [{ role: 'assistant', content: 'x' }] }),
    chatReq({ messages: [U('a'), { role: 'assistant', content: 'b' }] }), chatReq({ messages: [{ role: 'system', content: 'x' }] }), chatReq({ messages: [U('   ')] }), chatReq({ messages: [U('x'.repeat(16001))] }),
    chatReq({ messages: [{ role: 'user', content: 123 }] }), chatReq({ messages: Array.from({ length: 21 }, () => U('a')) }), chatReq({ messages: [null] })];
  for (const k of kasus) { const r = await run(e, k); assert.equal(r.status, 400, JSON.stringify(k).slice(0, 80)); assert.equal(r.calls.length, 0); }
  assert.equal(e.KV.m.size, 0);
  const ok = await run(e, chatReq({ messages: [U('a'), { role: 'assistant', content: 'b' }, U('c')] })); assert.equal(ok.status, 200);
  assert.equal((await run(e, chatReq({ messages: [U('x'.repeat(4001))] }))).status, 200); // Rev 306a: batas per pesan 4000 -> 16000 (lampiran catatan), disesuaikan DISENGAJA
  assert.equal((await run(e, chatReq({ messages: [U('x'.repeat(16000))] }))).status, 200);
});
test('passcode salah di chat = 401, tidak memanggil penyedia', async () => {
  const r = await run(env0(), chatReq({ key: 'passcode-salah-99' })); assert.equal(r.status, 401); assert.equal(r.calls.length, 0);
});
test('ukuran: chat boleh > 4096 byte (sampai 90000, Rev 306a); selain chat tetap 4096; > 90000 = 413', async () => {
  const e = env0(); const msgs = Array.from({ length: 6 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: 'x'.repeat(3900) })).concat([{ role: 'user', content: 'lanjut' }]);
  const big = chatReq({ messages: msgs }); assert.ok(JSON.stringify(big).length > 4096 && JSON.stringify(big).length < 90000);
  assert.equal((await run(e, big)).status, 200);
  assert.equal((await T.handle(post({ key: 'rama-secret-12', action: 'whoami', pad: 'x'.repeat(5000) }), e, NOW)).status, 413);
  assert.equal((await T.handle(post(chatReq({ pad: 'x'.repeat(91000) })), e, NOW)).status, 413);
});
test('jaringan ke penyedia gagal = 502; kehabisan waktu (AbortError) = 504', async () => {
  let r = await run(env0(), chatReq(), () => { throw new Error('boom'); }); assert.equal(r.status, 502); assert.match(r.j.error, /Tidak bisa menghubungi/);
  r = await run(env0(), chatReq(), () => { const e = new Error('x'); e.name = 'AbortError'; throw e; }); assert.equal(r.status, 504); assert.match(r.j.error, /45 detik/);
});
test('Sakelar: URL, header Bearer, model bawaan, system + messages; tanpa temperature/top_p/stream', async () => {
  const r = await run(env0(), chatReq());
  assert.equal(r.status, 200); assert.equal(r.j.text, 'Baik!'); assert.equal(r.j.provider, 'sakelar'); assert.equal(r.j.model, 'deepseek/deepseek-v4-flash'); assert.deepEqual(r.j.usage, { in: 5, out: 2 }); assert.equal(r.j.used, 1);
  const c = r.calls[0]; assert.equal(c.url, 'https://api.sakelar.web.id/v1/chat/completions'); assert.equal(c.init.headers.Authorization, 'Bearer ' + KEY);
  const b = JSON.parse(c.init.body); assert.equal(b.messages[0].role, 'system'); assert.match(b.messages[0].content, /Bahasa Indonesia/); assert.deepEqual(b.messages.slice(1), [{ role: 'user', content: 'Halo, apa kabar?' }]);
  for (const k of ['temperature', 'top_p', 'stream', 'tools']) assert.ok(!(k in b), k);
});
test('Gemini: alamat resmi dan model bawaan; Relay Router: model WAJIB diisi (tidak dikarang)', async () => {
  const g = await run(env0({ SAKELAR_KEY: undefined, GEMINI_KEY: 'AIza-FAKE-0123456789' }), chatReq());
  assert.equal(g.j.provider, 'gemini'); assert.equal(g.calls[0].url, 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions'); assert.equal(g.j.model, 'gemini-3.5-flash');
  const e = env0({ SAKELAR_KEY: undefined, RELAY_KEY: 'rl-FAKE-0123456789' }); const r0 = await run(e, chatReq());
  assert.equal(r0.status, 503); assert.match(r0.j.error, /MODEL_RELAY/); assert.equal(r0.calls.length, 0); assert.equal(e.KV.m.size, 0);
  const r1 = await run(env0({ SAKELAR_KEY: undefined, RELAY_KEY: 'rl-FAKE-0123456789', MODEL_RELAY: 'model-uji-1' }), chatReq());
  assert.equal(r1.j.provider, 'relay'); assert.equal(r1.calls[0].url, 'https://api.relayrouter.ai/v1/chat/completions'); assert.equal(r1.j.model, 'model-uji-1');
});
test('pilihan jalur: CHAT_PROVIDER menang; tanpa itu urutan sakelar, relay, gemini; tidak ada jalur Anthropic', async () => {
  const k = { SAKELAR_KEY: KEY, RELAY_KEY: 'rl-FAKE-0123456789', GEMINI_KEY: 'AIza-FAKE-0123456789', MODEL_RELAY: 'model-uji-1' };
  assert.equal(T.pickProvider(env0(k)), 'sakelar'); assert.equal(T.pickProvider(env0({ ...k, CHAT_PROVIDER: 'gemini' })), 'gemini');
  assert.equal(T.pickProvider(env0({ SAKELAR_KEY: undefined, GEMINI_KEY: 'AIza-FAKE-0123456789', CHAT_PROVIDER: 'sakelar' })), null);
  assert.equal(T.pickProvider(env0({ SAKELAR_KEY: undefined, ANTHROPIC_KEY: 'sk-ant-FAKE-0123456789', CHAT_PROVIDER: 'anthropic' })), null);
  assert.equal(T.pickProvider({ PASS_RAMA: 'rama-secret-12', ANTHROPIC_KEY: 'sk-ant-FAKE-0123456789' }), null);
});
test('model aneh jatuh ke bawaan; model slug dengan garis miring diterima', async () => {
  assert.equal((await run(env0({ MODEL_SAKELAR: 'anthropic/haiku-5.5' }), chatReq())).j.model, 'anthropic/haiku-5.5');
  assert.equal((await run(env0({ MODEL_SAKELAR: 'Model Aneh; DROP' }), chatReq())).j.model, 'deepseek/deepseek-v4-flash');
});
test('blok teks berupa array digabung; jawaban kosong = 502 jelas', async () => {
  const r = await run(env0(), chatReq(), () => okJson({ choices: [{ message: { content: [{ type: 'text', text: 'A' }, { type: 'text', text: 'B' }] } }] })); assert.equal(r.j.text, 'AB');
  const r2 = await run(env0(), chatReq(), () => okJson({ choices: [{ message: { content: '' }, finish_reason: 'length' }] })); assert.equal(r2.status, 502); assert.match(r2.j.error, /tidak mengembalikan teks \(length\)/);
  assert.equal((await run(env0(), chatReq(), () => okJson({}))).status, 502);
});
test('galat penyedia diterjemahkan dengan nama penyedia dan nama Secret; tidak membocorkan kunci', async () => {
  const kode = async (st, o) => run(env0(), chatReq(), () => bad(st, o));
  let r = await kode(401, { error: { message: 'x' } }); assert.equal(r.status, 502); assert.match(r.j.error, /Kunci Sakelar ditolak.*SAKELAR_KEY/);
  r = await kode(402, {}); assert.match(r.j.error, /Saldo/); r = await kode(404, { error: { message: 'no model' } }); assert.match(r.j.error, /MODEL_SAKELAR/);
  r = await kode(429, {}); assert.equal(r.status, 503); r = await kode(400, { error: { message: 'pesan salah' } }); assert.match(r.j.error, /pesan salah/);
  r = await run(env0({ RETRY_MS: [0, 0] }), chatReq(), () => bad(500, null)); assert.match(r.j.error, /kode 500/); // Rev 210a: 5xx dicoba ulang dulu
  r = await run(env0({ RETRY_MS: [0, 0] }), chatReq(), () => ({ ok: false, status: 502, json: async () => { throw new Error('bukan json'); } })); assert.equal(r.status, 503); // Rev 210a: 502 sementara = dicoba ulang, lalu 503 ramah
});
test('whoami memberi tahu apakah ada kunci penyedia (ai), tanpa mengungkap nilainya', async () => {
  const w = async (e) => (await (await T.handle(post({ key: 'rama-secret-12', action: 'whoami' }), e, NOW)).json());
  assert.equal((await w(env0())).ai, true); assert.equal((await w(env0({ SAKELAR_KEY: undefined }))).ai, false); assert.ok(!JSON.stringify(await w(env0())).includes(KEY));
});
test('tidak ada kunci asli di repo; kode aplikasi memanggil chat hanya dari ai/; ping tetap sama; ekspor bawaan saja', () => {
  const semua = src('backend/cloudflare/worker.mjs') + src('backend/cloudflare/PANDUAN_WORKER.md') + src('tests/rev207.test.mjs');
  assert.doesNotMatch(semua.replace(/sk-FAKE-0123456789-tes|sk-ant-FAKE-0123456789|AIza-FAKE-0123456789|rl-FAKE-0123456789/g, ''), /sk-ant-[A-Za-z0-9_-]{10,}|AIza[0-9A-Za-z_-]{20,}/);
  assert.doesNotMatch(src('backend/cloudflare/worker.mjs'), /api\.anthropic|x-api-key|anthropic-version/);
  for (const f of readdirSync(new URL('../src/js/', import.meta.url), { recursive: true }).filter((n) => n.endsWith('.js'))) { assert.doesNotMatch(src('src/js/' + f), /ANTHROPIC|api\.anthropic/, f); if (!f.startsWith('ai/')) assert.doesNotMatch(src('src/js/' + f), /action: 'chat'/, f); }
  assert.doesNotMatch(src('backend/cloudflare/worker.mjs'), /^export (async )?function|^export const/m); assert.match(src('backend/cloudflare/worker.mjs'), /export default \{ fetch:/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev207\.test\.mjs/); assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
});
