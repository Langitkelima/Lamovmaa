// Rev 321 / PART L1: mesin Link Card (murni). Tanpa UI; bagian DOM nyata dicek di L2/L3 (Chromium), bukan di npm test.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { staticGraph } from '../scripts/preload.mjs';
import * as K from '../src/js/linkcard.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 321: alamat sah diterima dan dinormalkan (www. jadi https)', () => {
  const a = K.linkCardUrl('https://www.google.com/search?q=kucing');
  assert.ok(a.ok); assert.equal(a.url, 'https://www.google.com/search?q=kucing'); assert.equal(a.host, 'google.com'); assert.equal(a.error, '');
  assert.equal(K.linkCardUrl('  www.contoh.co.id/a b'.replace(' b', '')).url, 'https://www.contoh.co.id/a');
  assert.ok(K.linkCardUrl('http://contoh.id').ok);
  assert.equal(K.LK_ERR, 'Alamat web tidak sah');
});
test('Rev 321: alamat tidak sah ditolak dengan pesan baku dan alasan', () => {
  const cases = [['', 'kosong'], ['   ', 'kosong'], ['javascript:alert(1)', 'skema'], ['data:text/html,<b>', 'skema'], ['file:///sdcard/a', 'skema'], ['ftp://a.com', 'skema'],
    ['google.com', 'skema'], ['https://a b.com', 'spasi'], ['https://a.com/\u0000x', 'spasi'], ['https://user:pw@a.com', 'akun'], ['https://google.com@jahat.com', 'akun'],
    ['https://localhost', 'host'], ['https://192.168.0.1/admin', 'host'], ['https://tanpatitik', 'host'], ['https://' + 'a'.repeat(2001) + '.com', 'panjang'], [null, 'kosong'], [undefined, 'kosong']];
  for (const [v, why] of cases) { const r = K.linkCardUrl(v); assert.equal(r.ok, false, String(v)); assert.equal(r.error, 'Alamat web tidak sah'); assert.equal(r.why, why, String(v)); assert.equal(r.url, ''); }
});
test('Rev 321: normalizeLinkCard membersihkan teks, menjepit panjang, gambar hanya https, rata hanya l/c/r', () => {
  const c = K.normalizeLinkCard({ u: 'https://a.com', t: '  Judul\n\u0007 panjang  ' + 'x'.repeat(300), i: 'http://a.com/i.jpg', s: 'S'.repeat(90), a: 'zzz' });
  assert.equal(c.u, 'https://a.com/'); assert.equal(c.t.length, 140); assert.ok(!/[\u0000-\u001f]/.test(c.t)); assert.ok(c.t.startsWith('Judul panjang')); assert.equal(c.i, '');
  assert.equal(c.s.length, 60); assert.equal(c.a, 'l');
  assert.equal(K.normalizeLinkCard({ u: 'https://a.com', i: 'https://a.com/i.jpg', a: 'c' }).i, 'https://a.com/i.jpg');
  assert.equal(K.normalizeLinkCard({ u: 'https://a.com', a: 'r' }).a, 'r');
  assert.equal(K.normalizeLinkCard({ u: 'javascript:1' }), null); assert.equal(K.normalizeLinkCard(null), null); assert.equal(K.normalizeLinkCard('x'), null);
});
test('Rev 321: kontrak HTML: cangkang kosong, atribut bawaan tidak ditulis, nilai di-escape (tanpa injeksi)', () => {
  assert.equal(K.linkCardHtml({ u: 'https://a.com' }), '<div class="lk-card" contenteditable="false" data-u="https://a.com/"></div>');
  const h = K.linkCardHtml({ u: 'https://a.com/?x=1&y=2', t: 'A "kutip" <b>tebal</b> & lain', i: 'https://a.com/i.png', s: 'Situs', a: 'c' });
  assert.equal((h.match(/</g) || []).length, 2, 'hanya <div ...> dan </div>: tidak ada tag lolos dari atribut');
  assert.ok(h.includes('data-t="A &quot;kutip&quot; &lt;b&gt;tebal&lt;/b&gt; &amp; lain"')); assert.ok(h.includes('data-a="c"')); assert.ok(h.includes('data-u="https://a.com/?x=1&amp;y=2"'));
  assert.equal(K.linkCardHtml({ u: 'tidak sah' }), ''); assert.equal(K.linkCardAttrs({ u: '' }), null);
});
test('Rev 321: bolak-balik html -> parseLinkCards mempertahankan data (termasuk & dan kutip)', () => {
  const orig = { u: 'https://a.com/p?x=1&y=2', t: 'Judul "A" & <B>', i: 'https://a.com/i.png', s: 'Situs', a: 'r' };
  const html = '<p>awal</p>' + K.linkCardHtml(orig) + '<p>tengah</p>' + K.linkCardHtml({ u: 'www.b.id' }) + '<p>akhir</p>';
  const cards = K.parseLinkCards(html);
  assert.equal(cards.length, 2); assert.deepEqual(cards[0], K.normalizeLinkCard(orig)); assert.equal(cards[1].u, 'https://www.b.id/');
  const rusak = '<div class="lk-card" contenteditable="false" data-u="javascript:alert(1)"></div><div class="lk-card" data-u="https://ok.id"></div>';
  assert.deepEqual(K.parseLinkCards(rusak).map((c) => c.u), ['https://ok.id/']);
  assert.deepEqual(K.parseLinkCards(''), []); assert.deepEqual(K.parseLinkCards(null), []); assert.deepEqual(K.parseLinkCards('<div class="lain"></div>'), []);
});
test('Rev 321: replaceLinkCards mengganti tiap kartu dengan teks dan membuang kartu rusak', () => {
  const html = '<p>a</p>' + K.linkCardHtml({ u: 'https://a.com', t: 'Satu' }) + '<div class="lk-card" data-u="bukan alamat"></div>' + K.linkCardHtml({ u: 'https://b.com' });
  assert.equal(K.replaceLinkCards(html, K.cardPlain), '<p>a</p>Tautan: Satu - https://a.com/Tautan: https://b.com/');
});
test('Rev 321: ekstraksi teks untuk pencarian, TXT, dan Markdown', () => {
  const c = K.normalizeLinkCard({ u: 'https://www.google.com/search?q=a', t: 'Google Search', s: 'Google' });
  assert.equal(K.cardSearchText(c), 'Google Search Google google.com https://www.google.com/search?q=a');
  assert.equal(K.cardPlain(c), 'Tautan: Google Search - https://www.google.com/search?q=a');
  assert.equal(K.cardMarkdown(c), '[Google Search](https://www.google.com/search?q=a)');
  const d = K.normalizeLinkCard({ u: 'https://id.wikipedia.org/wiki/Kucing_(hewan)', t: 'Kucing [x] \\ y' });
  assert.equal(K.cardMarkdown(d), '[Kucing \\[x\\] \\\\ y](https://id.wikipedia.org/wiki/Kucing_%28hewan%29)');
  assert.equal(K.cardMarkdown(K.normalizeLinkCard({ u: 'https://a.com/x' })), '[a.com](https://a.com/x)');
  assert.equal(K.cardPlain(K.normalizeLinkCard({ u: 'https://a.com/x' })), 'Tautan: https://a.com/x');
});
test('Rev 321: kunci tautan untuk D5 (pratinjau lama melewati URL yang sudah jadi kartu)', () => {
  assert.equal(K.linkKey('https://A.com/'), 'https://a.com'); assert.equal(K.linkKey('https://a.com/x/#bagian'), 'https://a.com/x'); assert.equal(K.linkKey('https://a.com/x?q=1'), 'https://a.com/x?q=1');
  assert.ok(K.sameLink('www.a.com/x/', 'https://www.a.com/x')); assert.ok(!K.sameLink('https://a.com/x', 'https://a.com/y')); assert.ok(!K.sameLink('tidak sah', 'tidak sah'));
  assert.ok(!K.sameLink('http://a.com', 'https://a.com'), 'skema berbeda = tautan berbeda');
  const cards = [K.normalizeLinkCard({ u: 'https://a.com/x' })];
  assert.deepEqual(K.skipCardUrls(['https://a.com/x', 'https://b.com', 'www.a.com/x'], cards), ['https://b.com', 'www.a.com/x'].filter((u) => !K.sameLink(u, 'https://a.com/x')));
  assert.deepEqual(K.skipCardUrls(['https://b.com'], []), ['https://b.com']); assert.deepEqual(K.skipCardUrls(null, null), []);
});
test('Rev 321: predikat sanitasi menolak atribut asing dan nilai berbahaya', () => {
  const ok = K.linkCardAttrOk;
  assert.ok(ok('class', 'lk-card')); assert.ok(!ok('class', 'lk-card x')); assert.ok(ok('contenteditable', 'false')); assert.ok(!ok('contenteditable', 'true'));
  assert.ok(ok('data-u', 'https://a.com')); assert.ok(!ok('data-u', 'javascript:alert(1)')); assert.ok(ok('data-i', 'https://a.com/i.jpg')); assert.ok(!ok('data-i', 'http://a.com/i.jpg')); assert.ok(!ok('data-i', 'data:image/png;base64,AAAA'));
  assert.ok(ok('data-t', 'Judul')); assert.ok(!ok('data-t', 'x'.repeat(141))); assert.ok(!ok('data-t', 'a\u0000b')); assert.ok(ok('data-s', 'S')); assert.ok(!ok('data-s', 'S'.repeat(61)));
  assert.ok(ok('data-a', 'c')); assert.ok(!ok('data-a', 'x'));
  for (const k of ['onclick', 'style', 'href', 'src', 'id', 'data-x']) assert.ok(!ok(k, 'x'), k);
});
// DOM palsu sekecil mungkin supaya sanitizeLinkCardEl bisa dicek di Node (DOM nyata dicek di Chromium pada L2).
function fakeEl(attrs, kids = 1) {
  const m = new Map(Object.entries(attrs)); const el = {
    removed: false, kids, get attributes() { return [...m.keys()].map((name) => ({ name })); },
    getAttribute: (k) => (m.has(k) ? m.get(k) : null), setAttribute: (k, v) => m.set(k, String(v)), removeAttribute: (k) => m.delete(k),
    remove() { el.removed = true; }, replaceChildren() { el.kids = 0; }, map: m,
  }; return el;
}
test('Rev 321: sanitizeLinkCardEl menulis ulang atribut, membuang atribut asing dan anak elemen, membuang kartu rusak', () => {
  const el = fakeEl({ class: 'lk-card', onclick: 'x()', style: 'x', 'data-u': 'www.a.com', 'data-t': ' J ', 'data-a': 'q' });
  const c = K.sanitizeLinkCardEl(el);
  assert.equal(c.u, 'https://www.a.com/'); assert.equal(el.kids, 0); assert.equal(el.removed, false);
  assert.deepEqual([...el.map.keys()], ['class', 'contenteditable', 'data-u', 'data-t']); assert.equal(el.map.get('data-t'), 'J'); assert.equal(el.map.get('contenteditable'), 'false');
  const bad = fakeEl({ class: 'lk-card', 'data-u': 'javascript:alert(1)' }); assert.equal(K.sanitizeLinkCardEl(bad), null); assert.equal(bad.removed, true);
  const none = fakeEl({ class: 'lk-card' }); assert.equal(K.sanitizeLinkCardEl(none), null); assert.equal(none.removed, true);
});
test('Rev 321b (D6): Catatan Privat boleh punya kartu tetapi hanya lokal (tanpa judul/gambar dari internet); pratinjau lama dimatikan di privat', () => {
  assert.equal(K.linkCardAllowed('priv'), true); assert.equal(K.linkCardFetchAllowed('priv'), false); assert.equal(K.linkCardFetchAllowed('note'), true);
  const c = K.normalizeLinkCard({ u: 'https://a.com/x', t: 'J', i: 'https://a.com/i.png', s: 'S', a: 'c' });
  assert.deepEqual(K.linkCardForKind(c, 'priv'), { u: 'https://a.com/x', t: '', i: '', s: '', a: 'c' }); assert.equal(K.linkCardForKind(c, 'note'), c); assert.equal(K.linkCardForKind(null, 'priv'), null);
  assert.equal(K.linkCardHtml(K.linkCardForKind(c, 'priv')), '<div class="lk-card" contenteditable="false" data-u="https://a.com/x" data-a="c"></div>');
  const n = src('src/js/notes.js'); const i = n.indexOf('function syncLinks()'); const body = n.slice(i, i + 300);
  assert.match(body, /if \(isP\) \{ delete n\.prev; renderLinks\(\); return; \}/, 'syncLinks berhenti sebelum fetchPreview di privat');
  assert.ok(body.indexOf('isP') < n.indexOf('fetchPreview(u)', i), 'penjaga isP ada sebelum pengambilan');
});
test('Rev 321: anggaran: linkcard.js murni, hanya impor logic.js, TIDAK ada di graf statis main.js, notes.js/lipat.js belum disentuh', () => {
  const k = src('src/js/linkcard.js');
  const imports = [...k.matchAll(/^import .* from '([^']+)'/gm)].map((m) => m[1]); assert.deepEqual(imports, ['./logic.js']);
  assert.ok(!/\b(document|window|localStorage|sessionStorage|fetch|XMLHttpRequest|innerHTML|setTimeout|addEventListener)\b/.test(k.replace(/\/\/.*$/gm, '')), 'tanpa DOM/jaringan/penyimpanan/pewaktu');
  assert.ok(!staticGraph('js/main.js').includes('js/linkcard.js'), 'tidak boleh impor statis dari main.js');
  assert.ok(/lk-card/.test(src('src/js/notes.js')) && /lk-card/.test(src('src/js/lipat.js')), 'Rev 323 / L2: kait sanitize + OUT_OF_BODY sudah dipasang (tes ini dulu mengunci kebalikannya di L1)');
  assert.ok(!/from '\.\/linkcard\.js'/.test(src('src/js/notes.js')), 'notes.js tidak mengimpor linkcard.js (hanya linkcard-ui.js lewat import() malas)');
});
