// Rev 119 / U7a-2c-1: gaya sel (Tebal, Miring, Rata, warna Isian/Teks)
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { BG_COLORS, FG_COLORS, HA_NAMES, nextAlign } from '../src/js/lembar-ui.js'; import * as L from '../src/js/lembar.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
test('palet warna lolos pembersih gaya lembar.js (tidak ada yang dibuang)', () => {
  for (const c of BG_COLORS) assert.equal(L.cleanStyle({ bg: c }).bg, c, c);
  for (const c of FG_COLORS) assert.equal(L.cleanStyle({ fg: c }).fg, c, c);
  assert.equal(new Set(BG_COLORS).size, BG_COLORS.length); assert.equal(new Set(FG_COLORS).size, FG_COLORS.length);
});
test('nextAlign: Kiri -> Tengah -> Kanan -> Kiri; nama tampilan', () => {
  assert.equal(nextAlign('start'), 'center'); assert.equal(nextAlign('center'), 'end'); assert.equal(nextAlign('end'), 'start'); assert.equal(nextAlign(undefined), 'center');
  assert.deepEqual(HA_NAMES, { start: 'Kiri', center: 'Tengah', end: 'Kanan' });
});
test('setCell gaya: gabung, null menghapus kunci, sel hanya-gaya tetap ada, nilai tidak hilang', () => {
  const t = L.newTab('A', 3), r = t.rows[0].id, c = t.cols[0].id;
  assert.ok(L.setCell(t, r, c, { v: 'x' })); assert.ok(L.setCell(t, r, c, { s: { b: true } })); assert.ok(L.setCell(t, r, c, { s: { bg: BG_COLORS[0] } }));
  assert.deepEqual(L.cellAt(t, 0, 0), { v: 'x', s: { b: true, bg: BG_COLORS[0] } });
  assert.ok(L.setCell(t, r, c, { s: { b: null } })); assert.deepEqual(L.cellAt(t, 0, 0).s, { bg: BG_COLORS[0] });
  assert.ok(L.setCell(t, r, c, { v: null })); assert.deepEqual(L.cellAt(t, 0, 0), { s: { bg: BG_COLORS[0] } }); // nilai dihapus, gaya tetap
  assert.ok(L.setCell(t, r, c, { s: { bg: null } })); assert.equal(L.cellAt(t, 0, 0), null); assert.deepEqual(t.rows[0].cells, {});
  assert.equal(L.setCell(t, r, c, { s: { ha: 'start' } }), false); // 'start' = bawaan, tidak disimpan
  assert.ok(L.setCell(t, r, c, { s: { ha: 'center' } })); assert.equal(L.cellAt(t, 0, 0).s.ha, 'center');
});
test('gaya lolos cleanSheet (penyimpanan/cadangan)', () => {
  const sh = L.newSheet({ name: 'G' }), t = sh.tabs[0];
  L.setCell(t, t.rows[1].id, t.cols[2].id, { v: 5, s: { b: true, i: true, fg: FG_COLORS[0], bg: BG_COLORS[2], ha: 'end' } });
  const back = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.deepEqual(back.tabs[0].rows[1].cells[t.cols[2].id], { v: 5, s: { b: true, i: true, fg: FG_COLORS[0], bg: BG_COLORS[2], ha: 'end' } });
});
test('kontrak kode: gaya lewat L.setCell({s}), fitsLimit, simpan via touched, tidak mencuri fokus, isian terang tetap terbaca', () => {
  const ui = src('js/lembar-ui.js');
  for (const k of ['L.setCell(tab, row.id, col.id, { s: patch })', 'L.fitsLimit(sheet)', 'function applyStyle(patch)', "addEventListener('pointerdown', (e) => e.preventDefault())", 'el.style.color = WN.inkOn(st.bg)', 'paintFmt();']) assert.ok(ui.includes(k), k);
  const ap = ui.slice(ui.indexOf('function applyStyle'), ui.indexOf("[bB, bI, bA, bBg, bFg].forEach((b) => b.addEventListener")); assert.ok(ap.includes('commit();') && ap.includes('touched();'));
  assert.ok(!/localStorage|persist\(|eval\(|new Function|Capacitor/.test(ui));
});
test('CSS dan versi 0.3.121', () => {
  assert.match(src('css/styles.css'), /Rev 119 \/ U7a-2c-1/); assert.match(src('css/styles.css'), /\.lz-fb\{[^}]*height:36px/);
  assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /"version": "0\.3\.121"/); assert.match(src('js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
