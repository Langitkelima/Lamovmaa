// Rev 354 / PART O3a (Paket OCR): tombol Pindai + dialog. Tes KABEL dan batas (tanpa DOM nyata; tampilan dicek di audit Chromium/HP).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { staticGraph } from '../scripts/preload.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const N = src('src/js/notes.js'), U = src('src/js/ai/ocr-ui.js'), C = src('src/css/styles.css');
test('notes.js: tombol Pindai hanya di catatan BIASA (bukan Privat), ikon ada, jalur Sisipkan + mode Edit + import() malas', () => {
  assert.match(N, /\.\.\.\(isP \? \[\] : \[insertBtn\('ocr', 'Pindai'\)\]\)/); assert.match(N, /\n    ocr: 'M4 8V6\.5/);
  assert.match(N, /else if \(kind === 'ocr' && !isP\) openOcr\(\);/);
  const i = N.indexOf('const openOcr = () =>'), b = N.slice(i, i + 700); assert.ok(i > 0);
  assert.match(b, /if \(isP\) \{ return; \}/); assert.match(b, /editorMode !== 'edit'/); assert.match(b, /import\('\.\/ai\/ocr-ui\.js'\)/); assert.match(b, /mulaiOcr\(\{ (?:ctx, )?r: caretRange\(\), ed, flushHist, auto, setRng/);
  assert.doesNotMatch(N, /from '\.\/ai\/ocr-ui\.js'|from '\.\/ai\/ocr\.js'/);
});
test('MALAS: ocr-ui.js dan ocr.js tidak masuk jalur buka; ocr.js dimuat lewat import() dari dialog', () => {
  const g = staticGraph('js/main.js'); assert.equal(g.includes('js/ai/ocr-ui.js'), false); assert.equal(g.includes('js/ai/ocr.js'), false);
  assert.match(U, /await import\('\.\/ocr\.js'\)/); assert.doesNotMatch(U, /^import .*ocr\.js/m);
});
test('dialog: butuh Kelimaa AI menyala + sambungan; satu foto; Kamera (capture) + Galeri; hasil di textarea editable; Sisipkan/Salin/Batal', () => {
  assert.match(U, /if \(!conn \|\| !cfg\.on\) \{ tWarn\(/); assert.match(U, /capture: 'environment'/); assert.match(U, /accept: 'image\/\*'/); assert.doesNotMatch(U, /multiple/);
  for (const t of ["'Kamera'", "'Galeri'", "'Baca teks'", "'Sisipkan di catatan'", "'Salin'", "'Batal'"]) assert.ok(U.includes(t), t);
  assert.match(U, /h\('textarea', \{ class: 'kai-ocr-ta'/); assert.match(U, /bacaFoto\(conn, file, \{ limit: o\.limit/); assert.match(U, /monthLimit: o\.monthLimit/);
  assert.match(U, /tidak ada teks yang terbaca/i); assert.match(U, /r\.truncated \? ' Teks sangat panjang/); assert.match(U, /Foto tidak disimpan di aplikasi maupun Worker/); // Rev 356: bunyi diganti (persetujuan O4)
});
test('privasi dialog: alamat objek dicabut + teks dikosongkan saat tutup; tanpa console/penyimpanan/innerHTML; dikirim hanya saat Baca teks diketuk', () => {
  assert.match(U, /const close = \(\) => \{ if \(url\) \{ try \{ URL\.revokeObjectURL\(url\)/); assert.match(U, /ta\.value = ''; ov\.remove\(\)/);
  assert.doesNotMatch(U, /console\.|(?<!globalThis\.)localStorage|sessionStorage|innerHTML|insertAdjacentHTML|outerHTML/);
  assert.equal((U.match(/bacaFoto\(/g) || []).length, 1, 'satu-satunya pemanggil jaringan = tombol Baca teks');
  assert.match(U, /const baca = async \(\) => \{\s+if \(busy \|\| !file\) return;/); // Rev 356: Baca teks kini lewat persetujuan (bRead.onclick)
});
test('sisipTeks: baris baru jadi <br>, teks lewat node teks, kosong ditolak, satu langkah riwayat (flushHist sebelum dan sesudah)', () => {
  const f = U.slice(U.indexOf('export function sisipTeks'), U.indexOf('async function salin'));
  assert.match(f, /createTextNode\(ln\)/); assert.match(f, /createElement\('br'\)/); assert.match(f, /lines\.some\(\(l\) => l\.trim\(\)\)\)/); assert.match(f, /flushHist\(\); rr\.deleteContents\(\)/); assert.match(f, /flushHist\(\); auto\(\); return true;/);
});
test('CSS: blok Rev 354 hanya variabel tema (tanpa hex/rgba), dalam anggaran; versi dan SCHEMA tetap', () => {
  const k = C.slice(C.indexOf('/* Rev 354 / O3a')); assert.ok(k.length > 100); assert.doesNotMatch(k, /#[0-9a-fA-F]{3,8}\b|rgba?\(/);
  assert.ok(C.length < 272 * 1024 /* Rev 410: naik 262 -> 272 KB ATAS IZIN PENGGUNA (23 Nov 2026); kartu TWO POCKETS + bulatan centang menambah sekitar 3 KB CSS */); assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev354\.test\.mjs/);
});
