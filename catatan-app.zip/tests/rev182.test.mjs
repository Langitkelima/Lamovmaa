// Rev 181 / U10d-2: tiga templat lembar kerja baru (Bagi biaya, Jadwal mingguan, Pelacak nilai) + perluasan mesin templat (tanggal contoh relatif, gaya per sel, Total per sel).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { chartList } from '../src/js/lembar-grafik.js';
import { formatDate } from '../src/js/lembar-format.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 12, 0, 0).getTime(); // 10 Nov 2026 (waktu lokal, sama dengan cara serialOf menghitung)
const mk = (id, o = {}) => T.makeFromTemplate(id, { now: NOW, ...o });
const row = (d, i, n) => Array.from({ length: n }, (_, j) => d.text(i, j));

test('Rev 181: empat templat lama pertama = Anggaran bulanan, Bagi biaya, Jadwal mingguan, Pelacak nilai (Bahasa Indonesia, ID unik)', () => {
  const l = T.templateList().slice(-10); // Rev 293: templat lama kini paling belakang
  assert.deepEqual(l.slice(0, 4).map((t) => t.id), ['anggaran', 'bagi', 'jadwal', 'nilai']); // Rev 182 menambah 4 templat sesudahnya (lihat rev185.test.mjs)
  assert.deepEqual(l.slice(0, 4).map((t) => t.name), ['Anggaran bulanan', 'Bagi biaya', 'Jadwal mingguan', 'Pelacak nilai']);
  assert.equal(new Set(l.map((t) => t.id)).size, l.length);
  for (const t of l) { assert.ok(t.desc.length > 10 && /^[a-z0-9_-]+$/.test(t.id)); assert.doesNotMatch(t.name + ' ' + t.desc, /\b(Expense|split|Weekly|timetable|Grade|tracker|Planned|Spent)\b/); assert.equal(T.hasTemplate(t.id), true); }
});
test('Rev 181: semua templat membangun lembar sah (tanpa rumus ditolak, muat batas, bulat-balik cleanSheet, ID unik per panggilan)', () => {
  for (const t of T.templateList()) {
    const r = mk(t.id); assert.ok(r, t.id); assert.equal(r.failed, 0, t.id);
    const sh = r.sheet; assert.equal(sh.name, t.name); assert.equal(sh.tabs.length, /^(fitur|rumus|admin|centang)-/.test(t.id) ? 2 : 1); assert.ok(L.fitsLimit(sh)); assert.ok(L.isSheetId(sh.id)); // Rev 287/288: templat Fitur, Rumus, Admin, dan (Rev 305) Centang punya tab Panduan
    assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(sh)))), JSON.stringify(sh), t.id);
    assert.notEqual(mk(t.id).sheet.id, mk(t.id).sheet.id);
    assert.equal(mk(t.id, { name: 'Punyaku' }).sheet.name, 'Punyaku');
  }
});

test('Rev 181: Bagi biaya = rumus hidup (Sudah dibayar, Bagian adil, Terima/bayar), tanggal contoh relatif hari ini, Total selisih 0', () => {
  const tab = mk('bagi').sheet.tabs[0], d = makeDisplay(tab);
  assert.equal(tab.name, 'Bagi biaya');
  assert.deepEqual(row(d, 0, 9), ['Tanggal', 'Keperluan', 'Dibayar oleh', 'Jumlah', '', 'Orang', 'Sudah dibayar', 'Bagian adil', 'Terima (+) / bayar (-)']);
  assert.deepEqual(row(d, 1, 9), ['04/11/2026', 'Belanja bulanan', 'Andi', 'Rp 450.000', '', 'Andi', 'Rp 720.000', 'Rp 520.000', 'Rp 200.000']);
  assert.deepEqual(row(d, 2, 9).slice(5), ['Budi', 'Rp 510.000', 'Rp 520.000', '-Rp 10.000']);
  assert.deepEqual(row(d, 3, 9).slice(5), ['Citra', 'Rp 330.000', 'Rp 520.000', '-Rp 190.000']);
  assert.deepEqual(row(d, 4, 9).slice(5), ['Total', 'Rp 1.560.000', 'Rp 1.560.000', 'Rp 0']);
  assert.equal(d.text(7, 0), '10/11/2026'); assert.equal(d.text(7, 3), 'Rp 120.000'); // tanggal contoh terakhir = hari ini
  assert.equal(d.raw(1, 0), d.raw(7, 0) - 6); assert.equal(formatDate(d.raw(7, 0)), '10/11/2026');
});
test('Rev 181: Bagi biaya ikut hidup saat biaya ditambah; Total hanya menebalkan sel F5:I5 (bukan biaya di A5:D5)', () => {
  const tab = mk('bagi').sheet.tabs[0], cid = (j) => tab.cols[j].id, rid = (i) => tab.rows[i].id;
  L.setCell(tab, rid(8), cid(1), { v: 'Parkir' }); L.setCell(tab, rid(8), cid(2), { v: 'Budi' }); L.setCell(tab, rid(8), cid(3), { v: 30000 }); // baris 9 (kosong di templat)
  const d = makeDisplay(tab);
  assert.equal(d.text(2, 6), 'Rp 540.000'); assert.equal(d.text(1, 7), 'Rp 530.000'); assert.equal(d.text(1, 8), 'Rp 190.000'); assert.equal(d.text(4, 8), 'Rp 0');
  const sty = (i, j) => (tab.rows[i].cells[cid(j)] || {}).s || {};
  for (const j of [5, 6, 7, 8]) { assert.equal(sty(4, j).b, true); assert.equal(sty(4, j).fg, '#111827'); }
  for (const j of [0, 1, 2, 3]) assert.equal(sty(4, j).bg, undefined, 'biaya di baris 5 bukan baris Total');
  assert.equal(sty(0, 0).b, true); assert.equal(sty(0, 0).fg, '#111827');
  const fx = tab.rows[1].cells[cid(6)]; assert.match(fx.fx, /^=/); assert.equal(fx.v, undefined);
});
test('Rev 181: Bagi biaya = diagram kolom Sudah dibayar per orang (F1:G4, kolom nilai G) memakai ID baris/kolom', () => {
  const tab = mk('bagi').sheet.tabs[0], cs = chartList(tab);
  assert.equal(cs.length, 1); assert.equal(cs[0].kind, 'column'); assert.equal(cs[0].title, 'Sudah dibayar per orang'); assert.equal(cs[0].ref, 'F1:G4'); assert.equal(cs[0].valueCol, 6);
});

test('Rev 181: Jadwal mingguan = Jam + Senin..Minggu, 07.00-18.00, kegiatan contoh berlatar terang + teks gelap, tanpa rumus dan tanpa diagram', () => {
  const tab = mk('jadwal').sheet.tabs[0], d = makeDisplay(tab);
  assert.equal(tab.name, 'Jadwal'); assert.deepEqual(row(d, 0, 8), ['Jam', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu']);
  assert.deepEqual(Array.from({ length: 12 }, (_, i) => d.text(i + 1, 0)), ['07.00', '08.00', '09.00', '10.00', '11.00', '12.00', '13.00', '14.00', '15.00', '16.00', '17.00', '18.00']);
  assert.deepEqual(row(d, 1, 8), ['07.00', 'Olahraga', '', 'Olahraga', '', 'Olahraga', '', '']);
  assert.equal(d.text(3, 6), 'Belanja'); assert.equal(d.text(4, 7), 'Keluarga'); assert.equal(d.text(6, 1), 'Makan siang');
  for (const r of tab.rows) for (const c of Object.values(r.cells || {})) assert.equal(c.fx, undefined);
  const cell = (i, j) => tab.rows[i].cells[tab.cols[j].id];
  assert.equal(cell(1, 0).s.b, true); // jam tebal
  assert.equal(cell(1, 1).s.bg, '#DCFCE7'); assert.equal(cell(1, 1).s.fg, '#111827'); // isian terang selalu bersama teks gelap (aturan Rev 119)
  assert.equal(chartList(tab).length, 0); assert.equal(tab.charts, undefined);
  assert.equal(tab.cols[0].w, 70); assert.equal(tab.cols[7].w, 104);
});

test('Rev 181: Pelacak nilai = Rata-rata dihitung sendiri (1 desimal), baris Rata-rata semua, sel kosong tidak galat', () => {
  const tab = mk('nilai').sheet.tabs[0], d = makeDisplay(tab);
  assert.equal(tab.name, 'Nilai'); assert.deepEqual(row(d, 0, 5), ['Mata pelajaran', 'Rata-rata', 'Ulangan 1', 'Ulangan 2', 'Ujian akhir']);
  assert.deepEqual(row(d, 1, 5), ['Matematika', '81,0', '80', '75', '88']);
  assert.deepEqual(row(d, 4, 5), ['IPA', '87,3', '88', '84', '90']);
  assert.deepEqual(row(d, 7, 5), ['Rata-rata semua', '84,4', '83,2', '83,5', '86,5']);
  assert.equal(d.raw(1, 1), 81);
  // Hapus semua nilai satu mapel: rata-ratanya kosong (bukan #DIV/0!) dan baris Rata-rata semua tetap jalan.
  for (const j of [2, 3, 4]) L.setCell(tab, tab.rows[1].id, tab.cols[j].id, { v: undefined });
  const d2 = makeDisplay(tab); assert.equal(d2.text(1, 1), ''); assert.equal(d2.text(7, 1), '85,1'); assert.doesNotMatch(row(d2, 7, 5).join('|'), /#/);
  // Ubah satu nilai: Rata-rata ikut berubah.
  L.setCell(tab, tab.rows[2].id, tab.cols[4].id, { v: 100 }); assert.equal(makeDisplay(tab).text(2, 1), '91,7');
});
test('Rev 181: Pelacak nilai = diagram batang Rata-rata per mata pelajaran (A1:B7, kolom nilai B), Total tebal di baris 8', () => {
  const tab = mk('nilai').sheet.tabs[0], cs = chartList(tab);
  assert.equal(cs.length, 1); assert.equal(cs[0].kind, 'bar'); assert.equal(cs[0].title, 'Rata-rata per mata pelajaran'); assert.equal(cs[0].ref, 'A1:B7'); assert.equal(cs[0].valueCol, 1);
  assert.equal(tab.rows[7].cells[tab.cols[0].id].s.b, true); assert.equal(tab.rows[7].cells[tab.cols[4].id].s.b, true);
  assert.equal(tab.rows[6].cells[tab.cols[0].id].s, undefined); // baris data biasa tanpa gaya
});

test('Rev 181: mesin templat = tanggal contoh mengikuti `now`, Total per sel (t), gaya tambahan per sel (s); tetap murni dan hanya settings.js yang memakai', () => {
  const a = makeDisplay(mk('bagi').sheet.tabs[0]), b = makeDisplay(T.makeFromTemplate('bagi', { now: NOW + 3 * 86400000 }).sheet.tabs[0]);
  assert.equal(b.raw(1, 0) - a.raw(1, 0), 3); assert.equal(b.text(7, 0), '13/11/2026');
  assert.ok(Number.isFinite(makeDisplay(T.makeFromTemplate('bagi').sheet.tabs[0]).raw(1, 0))); // tanpa `now` = hari ini sungguhan
  const s = src('src/js/lembar-templat.js');
  assert.doesNotMatch(s, /localStorage|document\.|window\.|AndroidAPI|Intl\.|eval\(|new Function/);
  assert.match(s, /from '\.\/lembar\.js'/); assert.match(s, /from '\.\/lembar-tampil\.js'/); assert.doesNotMatch(s, /from '\.\/(rumus|lembar-ui|lembar-pulau|storage)\.js'/);
  for (const f of ['notes', 'main', 'lembar', 'lembar-ui', 'lembar-pulau', 'storage', 'export', 'share']) assert.doesNotMatch(src('src/js/' + f + '.js'), /lembar-templat/, f);
  assert.match(src('src/js/settings.js'), /templateList\(\)\.map/); // pemilih menampilkan SEMUA templat lewat daftar (tanpa daftar tersendiri)
  assert.doesNotMatch(src('src/js/settings.js'), /'anggaran'|'bagi'|'jadwal'|'nilai'/); // settings.js tidak menyebut templat satu per satu
});
