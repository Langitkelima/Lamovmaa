// Rev 249: checkpoint DOKUMEN SAJA untuk Paket Seleksi gaya Google Sheets (bagian 28). Tanpa perubahan kode; bukan uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('bagian 28 memuat S1-S8, fakta kode, larangan, dan keputusan terbuka', () => {
  const d = src('PROMPT_SERAH_TERIMA.md'); const k = d.slice(d.indexOf('## 28. PAKET SELEKSI')); assert.ok(k.length > 1000);
  for (const x of ['28.1', '28.2', '28.3', '28.4', '28.5', '28.6', '28.7', '28.8', '28.9']) assert.ok(k.includes('### ' + x), x);
  for (const x of ['Rev 250 / S1', 'Rev 251 / S2', 'Rev 252 / S3', 'Rev 253 / S4', 'Rev 254 / S5', 'Rev 255 / S6', 'Rev 256 / S7', 'Rev 257 / S8']) assert.ok(k.includes(x), x);
  for (const x of ['lembar-seleksi.js', 'MAX_RANGE_CELLS', 'D-S1', 'CHECKPOINT']) assert.ok(k.includes(x), x);
});
test('fakta kode yang dicatat di 28.3 masih benar (sel tunggal, rentang lewat mode, virtualisasi baris)', () => {
  const ui = src('src/js/lembar-ui.js'); assert.doesNotMatch(ui, /rngMode/); assert.match(ui, /lz-rzr/); assert.match(ui, /lz-rz\b/); assert.match(ui, /visibleRange/);
  assert.match(src('src/js/lembar-rentang.js'), /MAX_RANGE_CELLS = 2000/);
  // Rev 250 membuat lembar-seleksi.js; lembar-ui.js tetap belum memakainya (S2 = Rev 251), jadi fakta 28.3 tentang UI masih berlaku.
});
test('tanpa versi/SCHEMA berubah; banner Rev 249 ada di RIWAYAT dan serah terima; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev249\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.ok(src('RIWAYAT.md').includes('**Rev 249 / v0.3.121')); assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**Rev 249 / v0.3.121'));
});
