// Rev 267 / V2+V3 (paket Validasi, bagian 29): warna pilihan tampil di grid + editor Validasi baru (rentang, pilihan berwarna) + tampilan baru Warna bersyarat/Pilih. Tes AI saja (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as V from '../src/js/lembar-validasi.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const mk = (nc = 3, nr = 10) => ({ cols: Array.from({ length: nc }, (_, i) => ({ id: 'c' + i + 'aa' })), rows: Array.from({ length: nr }, (_, i) => ({ id: 'r' + i + 'bb' })) });

test('parseRange/rangeText/partsFromRect: alamat gaya Sheets pulang-pergi; yang ambigu atau di luar tab ditolak', () => {
  const tab = mk();
  assert.deepEqual(V.parseRange('b2:b5', tab), { r1: 1, r2: 4, c1: 1, c2: 1, open: false });
  assert.deepEqual(V.parseRange(' B ', tab), { r1: 0, r2: 9, c1: 1, c2: 1, open: true });
  assert.deepEqual(V.parseRange('C:A', tab), { r1: 0, r2: 9, c1: 0, c2: 2, open: true }); // ujung terbalik ditukar
  assert.deepEqual(V.parseRange('B5:A2', tab), { r1: 1, r2: 4, c1: 0, c2: 1, open: false });
  for (const bad of ['B2:B', 'D', 'A11', 'A0', '', 'B2:', '1', 'AA', 'B2 B3', null, undefined, 5]) assert.equal(V.parseRange(bad, tab), null, String(bad));
  const ids = new Set(tab.cols.map((c) => c.id)), rids = new Set(tab.rows.map((r) => r.id));
  for (const t of ['B2:B5', 'B2', 'A1:C10', 'B:B', 'A:C', 'B3:C4']) {
    const rc = V.parseRange(t, tab), p = V.partsFromRect(tab, rc, rc.open), ck = V.cleanCheck({ id: '', c: p.c, k: 'list', items: ['x'], ...(p.rg ? { rg: p.rg } : {}) }, ids, rids, new Map(tab.cols.map((c, i) => [c.id, i])));
    assert.ok(ck, t); const back = V.parseRange(V.rangeText(tab, ck), tab);
    assert.deepEqual([back.r1, back.r2, back.c1, back.c2], [rc.r1, rc.r2, rc.c1, rc.c2], t);
  }
  assert.equal(V.rangeText(tab, { c: 'c1aa', k: 'list', items: ['a'] }), 'B:B'); assert.equal(V.rangeText(tab, { c: 'zzzz', k: 'list', items: ['a'] }), null);
  assert.equal(V.partsFromRect(tab, V.parseRange('A1:A10', tab), false).rg, null, 'menutup semua baris = kolom penuh (ikut tumbuh)');
  assert.equal(V.rangeText(tab, { c: 'c1aa', rg: { c2: 'c1aa', r1: 'r1bb', r2: 'r1bb' }, k: 'list', items: ['a'] }), 'B2');
});

test('itemsFromRows/itemRowsOf: kosong dan kembar dibuang, warna ikut pilihan pertama, hex rusak dibuang, urutan tetap', () => {
  const o = V.itemsFromRows([{ t: ' Belum ', bg: '#fecaca' }, { t: 'belum', bg: '#000000' }, { t: '', bg: '#111111' }, { t: 'Proses', bg: 'merah', fg: '#111827' }, { t: 'x'.repeat(60), bg: '#BBF7D0' }]);
  assert.deepEqual(o.items, ['Belum', 'Proses', 'x'.repeat(40)]);
  assert.deepEqual(o.cl, { Belum: { bg: '#FECACA' }, Proses: { fg: '#111827' }, ['x'.repeat(40)]: { bg: '#BBF7D0' } });
  assert.deepEqual(V.itemsFromRows(null), { items: [], cl: {} }); assert.deepEqual(V.itemsFromRows([{ t: 1 }, { t: 2 }]).items, ['1', '2']);
  const ck = { id: 'v1', c: 'c0aa', k: 'list', items: ['A', 'B'], cl: { B: { bg: '#BAE6FD' } } };
  assert.deepEqual(V.itemRowsOf(ck), [{ t: 'A', bg: '', fg: '' }, { t: 'B', bg: '#BAE6FD', fg: '' }]); assert.deepEqual(V.itemRowsOf(null), []);
  const again = V.itemsFromRows(V.itemRowsOf(ck)); assert.deepEqual(again.items, ck.items); assert.deepEqual(again.cl, ck.cl); // pulang-pergi tanpa perubahan
  assert.equal(V.ITEM_COLORS.length, 20); assert.ok(V.ITEM_COLORS.every((c) => /^#[0-9A-F]{6}$/.test(c)) && new Set(V.ITEM_COLORS).size === 20);
});

test('warna pilihan menurut rentang: checkAt memilih aturan pertama, colorOf tak peka huruf, di luar rentang tanpa warna', () => {
  const tab = mk(); tab.checks = V.cleanChecks([
    { id: '', c: 'c1aa', k: 'list', items: ['Belum', 'Selesai'], cl: { Belum: { bg: '#FECACA' }, Selesai: { bg: '#BBF7D0', fg: '#14532D' } }, rg: { c2: 'c1aa', r1: 'r1bb', r2: 'r3bb' } },
    { id: '', c: 'c1aa', k: 'list', items: ['Belum', 'Lain'], cl: { Belum: { bg: '#000000' } } }], tab.cols, tab.rows);
  assert.equal(tab.checks.length, 2);
  assert.equal(V.colorOf(V.checkAt(tab, 2, 1), ' selesai ').bg, '#BBF7D0'); assert.equal(V.colorOf(V.checkAt(tab, 2, 1), 'SELESAI').fg, '#14532D');
  assert.equal(V.colorOf(V.checkAt(tab, 2, 1), 'Belum').bg, '#FECACA', 'sel di rentang pertama memakai aturan PERTAMA');
  assert.equal(V.colorOf(V.checkAt(tab, 7, 1), 'Belum').bg, '#000000', 'di luar rentang pertama = aturan kolom penuh kedua');
  assert.equal(V.checkAt(tab, 2, 0), null); assert.equal(V.colorOf(V.checkAt(tab, 2, 1), 'Bebas'), null); assert.equal(V.colorOf(V.checkAt(tab, 7, 1), 'Lain'), null, 'pilihan tanpa warna');
  const w = V.withColor(tab.checks[0], 'Belum', '#BAE6FD'); assert.equal(w.cl.Belum.bg, '#BAE6FD'); assert.equal(tab.checks[0].cl.Belum.bg, '#FECACA', 'asli tidak berubah');
});

test('kabel UI grid: warna pilihan di bawah gaya manual dan di bawah warna bersyarat; rentang dihitung sekali; panah menurut aturan sel', () => {
  const ui = src('src/js/lembar-ui.js'), d = ui.slice(ui.indexOf('const drawRows'), ui.indexOf('const paintBar'));
  assert.equal((d.match(/checkRect\(/g) || []).length, 1, 'rentang aturan dihitung SEKALI per gambar, bukan per sel');
  assert.ok(d.indexOf('const ckr = ') < d.indexOf('for (let k = from; k < to; k++)'));
  assert.match(d, /if \(vck && vck\.cl && !st\.bg && !\(fxd && fxd\.err\)\)/); assert.match(d, /colorOf\(vck, el\.textContent\)/);
  assert.ok(d.indexOf('colorOf(vck') > d.indexOf('if (st.bg) el.style.background') && d.indexOf('colorOf(vck') < d.indexOf('const rcol = '), 'urutan: gaya sel manual < warna pilihan < warna bersyarat');
  assert.match(d, /if \(vck && vck\.dd !== false\) el\.classList\.add\('dd'\)/); assert.doesNotMatch(d, /vcols/);
  assert.doesNotMatch(ui, /checkOf\(/, 'pembaca per-kolom lama tidak dipakai lagi di layar');
});

test('kabel UI editor: Rentang sel + pilihan berwarna + palet + sakelar panah; satu Urungkan; kembar rentang ditolak; mode Tolak (sejak Rev 269 ada sakelarnya)', () => {
  const ui = src('src/js/lembar-ui.js'), o = ui.slice(ui.indexOf('const openChecks'), ui.indexOf('const openFilter'));
  for (const k of ['parseRange(rg.value, tab)', 'partsFromRect(', 'itemsFromRows(rows)', 'itemRowsOf(', 'ITEM_COLORS', "openColorPanel('bg', {", "role: 'switch'", "'data-f': 'save'", "'data-f': 'del'", "'data-f': 'new'", 'sudah punya aturan', 'Isi minimal satu pilihan', 'MAX_CHECKS']) assert.ok(o.includes(k), k);
  assert.equal((o.match(/hist\.push\(/g) || []).length, 1, 'semua perubahan lewat apply()'); assert.ok(o.indexOf('const snap = ser()') < o.indexOf('L.setChecks(') && o.indexOf('L.setChecks(') < o.indexOf('hist.push(snap)'));
  assert.doesNotMatch(o, /'Tolak'/, 'Rev 276 / W1: sakelar Tolak DIHAPUS'); assert.doesNotMatch(o, /tolak/);
  assert.match(o, /e\.key === 'Enter'/); assert.match(o, /'paste'/); assert.doesNotMatch(o, /textarea/);
  const p = ui.slice(ui.indexOf('const openPick'), ui.indexOf('const openChecks')); assert.match(p, /checkAt\(tab, sel\.r, sel\.c\)/); assert.match(p, /WN\.inkOn\(e\.bg\)/); assert.match(p, /'data-pick': it/);
  const r = ui.slice(ui.indexOf('const openRules'), ui.indexOf('const openPick')); for (const k of ["'data-f': 'add'", "'data-rule': r.id", 'lz-presets', 'lz-scales', 'L.setRules(tab, next)', 'dlgHead(']) assert.ok(r.includes(k), k);
});

test('CSS Rev 267: ada, hanya variabel tema (tanpa heks mentah), teks kotak isian berwarna, tema terang dan gelap lewat variabel yang sama', () => {
  const css = src('src/css/styles.css'), i = css.indexOf('/* ===== Rev 267'); assert.ok(i > 0); const blk = css.slice(i);
  for (const k of ['.vd-card{', '.vd-it{', '.vd-pal{', '.vd-sw[aria-checked=true]', '.vp-list{', '.lz-vd .lz-mi.vp-it.on .vp-ck', '.lembarfs .lz-c.vc{', '.vd-rg{', '.lz-vd:has([data-tone=validasi])']) assert.ok(blk.includes(k), k);
  assert.doesNotMatch(blk, /#[0-9a-fA-F]{3,8}\b/, 'warna tetap lewat var(--...); warna pilihan datang dari data'); assert.doesNotMatch(blk, /rgba?\(/);
  assert.match(blk, /\.vd-it \.vd-ti\{[^}]*-webkit-text-fill-color:currentColor/); assert.match(blk, /\.vd-rg\{[^}]*-webkit-text-fill-color:var\(--ink\)/);
  assert.match(blk, /prefers-reduced-motion/); assert.ok(css.includes('.lz-rules .lz-pc[aria-pressed=true]') && css.includes('.lz-checks .lz-ta'), 'aturan lama yang dikunci tes lama tetap ada');
});

test('lingkup Rev 267: ekspor/pratinjau catatan: warna pilihan dikerjakan di Rev 268 (V2b), SCHEMA 20 tetap, native/Worker tak berubah, tes terdaftar, versi 0.3.121', () => {
  for (const f of ['src/js/lembar-tampil.js', 'src/js/lembar-alat.js', 'src/js/export.js']) assert.doesNotMatch(src(f), /lembar-validasi/, f); // Rev 268: lembar-pulau.js kini mengimpornya (V2b)
  assert.match(src('src/js/storage.js'), /SCHEMA = 22/); const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(pk.scripts.test.includes('tests/rev267.test.mjs')); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
