// Rev 300b: Bekukan BARIS di lembar kerja: tombol di Lainnya > Tampilan + lapisan baris beku (sticky) di grid. Model/alat = Rev 300a.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as B from '../src/js/lembar-beku.js';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');

test('Rev 300b: lembar-ui mengimpor alat beku (modul malas) dan lembar.js/main.js statis TIDAK mengimpornya', () => {
  assert.match(ui, /from '\.\/lembar-beku\.js'/); assert.ok(!/lembar-beku/.test(src('src/js/lembar.js'))); assert.ok(!/lembar-beku/.test(src('src/js/main.js')));
});
test('Rev 300b: menu Lainnya punya grup Tampilan > Bekukan baris; dialog punya Baris 1, 2 baris, Sampai baris, Lepas', () => {
  assert.match(ui, /grp\('Tampilan', item\('beku', 'Bekukan baris( & kolom)?'/);
  for (const m of ["opt('row1'", "opt('row2'", "opt('rows'", "opt('none'"]) assert.ok(ui.includes(m), m);
});
test('Rev 300b: applyFreeze = satu langkah Urungkan: snapshot SEBELUM ubah, hist.push hanya bila berubah', () => {
  const a = ui.slice(ui.indexOf('const applyFreeze'), ui.indexOf('const openFreeze'));
  assert.ok(a.indexOf('const snap = ser()') < a.indexOf('setFreeze(') && a.indexOf('freezeBy(') < a.indexOf('hist.push(snap)') && a.includes('touched()'));
  assert.match(a, /if \(ok\) \{ ver\+\+, hist\.push\(snap\)/);
});
test('Rev 300b: lapisan beku = anak body, digambar SEKALI (bukan tiap gulir), baris beku tidak digambar dobel di body', () => {
  assert.match(ui, /const frz = h\('div', \{ class: 'lz-frz' \}\)/); assert.match(ui, /if \(!inc\) \{ frz\.textContent = ''/);
  assert.match(ui, /if \(k < fr\) continue;/); assert.match(ui, /if \(el === frz\) continue;/);
  assert.ok(/applyFreeze[\s\S]*lastKey = ''; drawRows\(\)/.test(ui), 'ganti beku mengosongkan kunci gambar (gambar penuh, bukan inkremental)');
});
test('Rev 300b: seleksi di baris beku menempel (translate + z-index) dan seret pegangan memetakan pita beku', () => {
  assert.match(ui, /e\.style\.translate = dx \|\| dy/); assert.match(ui, /fzSel = k2 < frCount/); assert.match(ui, /y - st < lay\.tops\[fn\]/);
});
test('Rev 300b: CSS lapisan beku kecil, memakai variabel tema (terang+gelap), sticky', () => {
  const i = css.indexOf('Rev 300b'); assert.ok(i > 0); const blk = css.slice(i, (css.indexOf('/* Rev 303c') > i ? css.indexOf('/* Rev 303c') : undefined));
  assert.match(blk, /\.lz-frz\{position:sticky/); assert.match(blk, /var\(--bg\)/); assert.ok(blk.length < 800, 'blok CSS kecil: ' + blk.length); // Rev 302a: 600 -> 800 (blok kolom beku berpindah ke pembungkus sticky, sedikit lebih panjang)
  assert.ok(!/#[0-9a-fA-F]{3,6}\b/.test(blk), 'tanpa warna mentah');
});
test('Rev 300b: frCount-setara: baris beku hanya yang indeks aslinya < fz.r (model tetap Rev 300a)', () => {
  const t = L.newTab('U', 12); B.setFreeze(t, { r: 2 }); assert.deepEqual(B.getFreeze(t), { r: 2, c: 0 });
  // meniru frCount: tanpa filter = min(z,total); dengan filter = awalan yang indeksnya < z; selalu sisakan 1 baris
  const fc = (z, ord, total) => { if (!z || !total) return 0; let k = 0; if (ord) { while (k < ord.length && ord[k] < z) k++; } else k = Math.min(z, total); return Math.min(k, total - 1); };
  assert.equal(fc(2, null, 12), 2); assert.equal(fc(2, [0, 1, 5, 9], 4), 2); assert.equal(fc(2, [1, 5, 9], 3), 1); assert.equal(fc(2, [5, 9], 2), 0); assert.equal(fc(5, [0, 1], 2), 1); assert.equal(fc(0, null, 9), 0);
  assert.match(ui, /const frCount = \(ord, total\) =>/);
});
console.log('rev300b: ' + n + ' tes');
