// Rev 407 diganti Rev 408: seleksi rentang gaya ZArchiver (tanpa seret). Logika murni rentang tetap dipakai.
import { readFileSync, existsSync } from 'node:fs';
import { test } from 'node:test';
import { strict as assert } from 'node:assert';
import * as PL from '../src/js/pilih.js';
const rd = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const order = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

test('rangeIds: naik, turun, satu kartu, id tak dikenal', () => {
  assert.deepEqual(PL.rangeIds(order, 'b', 'd'), ['b', 'c', 'd']);
  assert.deepEqual(PL.rangeIds(order, 'd', 'b'), ['b', 'c', 'd']);
  assert.deepEqual(PL.rangeIds(order, 'c', 'c'), ['c']);
  assert.deepEqual(PL.rangeIds(order, 'c', 'zzz'), []);
});
test('skenario pengguna: 1 lalu tahan 4 = 1-4; lalu 6 lalu tahan 8 = 6-8, 5 TIDAK terpilih', () => {
  let ids = PL.dragSelection(['a'], order, 'a', 'd');
  assert.deepEqual(ids, ['a', 'b', 'c', 'd']);
  ids = PL.toggle(ids, 'f'); // ketuk kartu 6 (anchor = f)
  ids = PL.dragSelection(ids, order, 'f', 'h'); // tahan kartu 8
  assert.deepEqual([...ids].sort(), ['a', 'b', 'c', 'd', 'f', 'g', 'h']);
  assert.ok(!ids.includes('e'));
});
test('pemasangan: tanpa seret, tanpa modul seret-pilih, anchor dipakai', () => {
  const n = rd('src/js/notes.js');
  assert.ok(!existsSync(new URL('../src/js/seret-pilih.js', import.meta.url)));
  assert.ok(!/seret-pilih|mulaiSeret|startDrag/.test(n));
  assert.ok(n.includes('selState.anchor') && n.includes('PL.dragSelection(selState.ids, order, a, id)'));
  assert.ok(n.includes('sel.press(n.id)'));
  assert.ok(!rd('src/css/styles.css').includes('.dragsel'));
});
test('pemasangan: tes terdaftar dan SCHEMA tetap', () => {
  assert.match(JSON.parse(rd('package.json')).scripts.test, /node tests\/rev407\.test\.mjs/);
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
});
