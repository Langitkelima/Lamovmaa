// Rev 143 / U9a-3b: Isi seri di lembar Lainnya (dialog; sumber berakhir di sel terpilih; satu langkah Urungkan; sel tujuan berumus tidak ditimpa).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fillSource, fillRangeText, defaultSourceLen, patternLabel, fillMessage } from '../src/js/lembar-ui.js';
import * as L from '../src/js/lembar.js';
import * as A from '../src/js/lembar-alat.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = (rows) => { const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; rows.forEach((row, r) => row.forEach((v, c) => { if (v !== undefined) L.setCell(tab, tab.rows[r].id, tab.cols[c].id, typeof v === 'object' && v !== null && 'fx' in v ? v : { v }); })); return tab; };
const col = (tab, c, n) => Array.from({ length: n }, (_, r) => { const x = tab.rows[r].cells[tab.cols[c].id]; return x ? x.v : undefined; });

test('fillSource dan fillRangeText: sumber berakhir di sel terpilih, ke bawah dan ke kanan', () => {
  assert.deepEqual(fillSource({ r: 4, c: 2 }, 2, 'down'), { r1: 3, c1: 2, r2: 4, c2: 2 });
  assert.deepEqual(fillSource({ r: 4, c: 2 }, 3, 'right'), { r1: 4, c1: 0, r2: 4, c2: 2 });
  assert.deepEqual(fillSource({ r: 0, c: 0 }, 5, 'down'), { r1: 0, c1: 0, r2: 0, c2: 0 }); // tidak keluar dari lembar
  assert.equal(fillSource(null, 1, 'down'), null);
  assert.equal(fillRangeText({ r1: 0, c1: 0, r2: 1, c2: 0 }, 10, 'down'), 'Sumber A1:A2 \u2192 isi A3:A12');
  assert.equal(fillRangeText({ r1: 2, c1: 1, r2: 2, c2: 1 }, 1, 'right'), 'Sumber B3 \u2192 isi C3');
  assert.equal(fillRangeText(null, 3, 'down'), '');
});

test('defaultSourceLen dan patternLabel: 2 bila sel terpilih + sebelumnya membentuk pola, selain itu 1', () => {
  const t = mk([[1], [2], ['abc'], ['xyz'], [undefined]]);
  assert.equal(defaultSourceLen(t, { r: 1, c: 0 }, 'down'), 2); // 1,2 = linear
  assert.equal(defaultSourceLen(t, { r: 0, c: 0 }, 'down'), 1); // tidak ada sel di atas
  assert.equal(defaultSourceLen(t, { r: 3, c: 0 }, 'down'), 1); // teks tanpa angka = salin saja
  assert.equal(defaultSourceLen(t, { r: 4, c: 0 }, 'down'), 1); // sel kosong
  const f = mk([[{ fx: '=1' }], [2]]); assert.equal(defaultSourceLen(f, { r: 1, c: 0 }, 'down'), 1); // sumber berumus tidak diandalkan
  const rt = mk([[1, 2]]); assert.equal(defaultSourceLen(rt, { r: 0, c: 1 }, 'right'), 2);
  assert.equal(patternLabel({ kind: 'linear', step: 2 }), 'angka +2'); assert.equal(patternLabel({ kind: 'linear', step: -0.5 }), 'angka \u22120,5');
  assert.equal(patternLabel({ kind: 'texnum', step: 1 }), 'teks + angka +1'); assert.equal(patternLabel({ kind: 'copy' }), 'ulangi isi sumber');
});

test('fillMessage: hasil, tidak ada, dan laporan yang dilewati', () => {
  assert.equal(fillMessage({ filled: 10 }), '10 sel diisi.');
  assert.equal(fillMessage({ filled: 0 }), 'Tidak ada yang diisi.');
  assert.equal(fillMessage(null), 'Tidak ada yang diisi.');
  assert.equal(fillMessage({ filled: 3, skippedTarget: 2, truncated: 4 }), '3 sel diisi. 2 sel tujuan berumus tidak ditimpa, 4 sel di luar lembar dilewati.');
  assert.equal(fillMessage({ filled: 0, skippedFormula: 1 }), 'Tidak ada yang diisi. 1 lajur sumber berumus dilewati.'); // Rev 172: kembali ke setelan awal (sumber berumus dilewati)
});

test('jalur data: seri angka dari dialog (sumber 2 sel) dan sel tujuan berumus TIDAK ditimpa', () => {
  const t = mk([[1], [2]]); const s = fillSource({ r: 1, c: 0 }, 2, 'down');
  const r = A.fillSeries(t, s, 3, { dir: 'down' }); assert.equal(r.filled, 3); assert.deepEqual(col(t, 0, 5), [1, 2, 3, 4, 5]);
  const g = mk([[1], [2], [undefined], [{ fx: '=SUM([r1.cA:r2.cA])' }]]); const gs = fillSource({ r: 1, c: 0 }, 2, 'down');
  const rg = A.fillSeries(g, gs, 3, { dir: 'down' });
  assert.equal(rg.skippedTarget, 1); assert.equal(rg.filled, 2); assert.ok(g.rows[3].cells[g.cols[0].id].fx, 'rumus di sel tujuan tetap utuh');
  assert.equal(g.rows[2].cells[g.cols[0].id].v, 3); assert.equal(g.rows[4].cells[g.cols[0].id].v, 5);
});

test('penjaga kode: item Isi seri sesudah Cari dan ganti, snapshot sebelum isi, Kembali HP, tanpa penyimpanan di UI', () => {
  const u = src('src/js/lembar-ui.js');
  assert.match(u, /import \{ sortTab, tabToDelimited, usedRange, findAll, replaceAll, seriesPlan, fillSeries(?:, importDelimited, parseDelimited, detectDelimiter)? \} from '\.\/lembar-alat\.js'/);
  assert.match(u, /item\('cari', 'Cari dan ganti', 'di seluruh tab ini', openFind\),\n\s+item\('seri', 'Isi seri', /);
  assert.match(u, /const snap = ser\(\), res = fillSeries\(tab, src, n, \{ dir, inc: inc\.checked \}\);\n      if \(res\.filled\) \{/);
  assert.match(u, /class: 'ov dlgov lz-more lz-find lz-fill'/); assert.doesNotMatch(u, /localStorage|sessionStorage|\beval\s*\(/);
  for (const nope of []) assert.ok(!u.includes(nope), nope + ' belum boleh ada'); // Rev 149: item filter kini ada
  const a = src('src/js/lembar-alat.js'); assert.doesNotMatch(a, /from '\.\/rumus\.js'/);
});
