// Rev 306b / Kelimaa AI LAMPIRAN CATATAN, bagian B (UI): sambungan ke layar chat, modul UI, CSS, anggaran. Tanpa DOM nyata: yang dikunci adalah bentuk kode dan perilaku mesin yang dipakai UI.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as A from '../src/js/ai/lampiran.js';
import * as R from '../src/js/ai/ruang.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const ui = src('src/js/ai/lampiranui.js'), ob = src('src/js/ai/obrolan.js'), css = src('src/css/styles.css');

test('modul UI: hanya node teks, tanpa HTML mentah, tanpa penyimpanan/jaringan, impor terbatas', () => {
  assert.doesNotMatch(ui, /innerHTML|insertAdjacentHTML|outerHTML|localStorage|fetch\(|XMLHttp/);
  const imps = [...ui.matchAll(/^import .* from '(.+)';/gm)].map((m) => m[1]).sort(); assert.deepEqual(imps, ['../ui.js', './lampiran.js']);
  for (const k of ['export function bukaPemilih', 'export function bukaPratinjau', 'export function buatBarisChip', 'export function chipBalon', 'role: \'checkbox\'', "type: 'search'", 'toggleAtt(', 'attachable(', 'buildAttachment(', 'budgetFor(']) assert.ok(ui.includes(k), k);
});
test('layar chat: item Lampirkan catatan ada di lembar tombol +, chip di atas dock, dock tetap utuh', () => {
  assert.match(ob, /from '\.\/lampiranui\.js'/); assert.match(ob, /from '\.\/lampiran\.js'/);
  assert.match(ob, /h\('div', \{ class: 'kd-list' \}, lampir, tempel\)/); assert.ok(ob.includes("'Lampirkan catatan'"));
  assert.match(ob, /bilahLamp\.el, h\('div', \{ class: 'kc-dock' \}, kc, kw, ta, send\)/);
});
test('kirim: lampiran dibangun sebelum apa pun berubah, ditolak saat Cari di web, tidak dilepas bila gagal, riwayat hanya menyimpan rujukan', () => {
  const i = ob.indexOf('send.onclick'), seg = ob.slice(i, i + 6500);
  assert.ok(seg.indexOf('buildAttachment(') < seg.indexOf('sibuk = true'), 'lampiran dibangun sebelum sibuk');
  assert.match(seg, /if \(web\) \{ t(?:Ok|Warn|Err|Info)\('Lampiran tidak ikut saat Cari di web menyala/);
  assert.match(seg, /else if \(ab\) \{/); assert.match(seg, /withAttachment\(buildMessages\(riwayat, c\.value\)/);
  assert.match(seg, /WORKER_LAMA\.test\(res\.msg/); assert.match(seg, /att: attRef/); assert.match(ob, /chipUser\(bub\('user', c\.value, t0\), attRef\)/);
  assert.doesNotMatch(seg, /if \(ab\) \{ lamp = \[\]/, 'Rev 306c: lampiran TIDAK lagi dilepas otomatis setelah terkirim (menempel)');
  assert.match(seg, /else \{ const cx = buildContext\(ctx\.data, loadPerms\(\)\), at = attachContext\(/, 'jalur tanpa lampiran tidak berubah');
});
test('riwayat: pesan pengguna menyimpan {id,judul} tanpa isi catatan', () => {
  const m = R.normMsgs([{ role: 'user', content: 'ringkas', att: [{ id: 'a1', title: 'Belanja', isi: 'RAHASIA', text: 'x' }] }, { role: 'assistant', content: 'ok' }]);
  assert.deepEqual(m[0].att, [{ id: 'a1', title: 'Belanja' }]); assert.ok(!JSON.stringify(m).includes('RAHASIA'));
});
test('pesan Worker lama dikenali; Worker baru dan galat lain tidak', async () => {
  const U = await import('../src/js/ai/lampiranui.js').catch(() => null); // butuh DOM (ui.js); bila gagal dimuat di Node, uji lewat sumber
  const re = /maks\.\s*4000 huruf|terlalu besar/i;
  assert.match(ui, /export const WORKER_LAMA = \/maks\\\.\\s\*4000 huruf\|terlalu besar\/i;/);
  assert.ok(re.test('Pesan tidak sah (1-20 pesan, tiap pesan maks. 4000 huruf, mulai dan berakhir dari pengguna)')); assert.ok(re.test('Permintaan terlalu besar'));
  assert.ok(!re.test('Pesan tidak sah (1-20 pesan, tiap pesan maks. 16000 huruf, mulai dan berakhir dari pengguna)')); assert.ok(!re.test('Passcode salah'));
  void U;
});
test('anggaran pesan: ketikan + konteks + lampiran selalu muat satu pesan Worker', () => {
  const data = { notes: [{ id: 'n1', title: 'Panjang', text: 'kata '.repeat(5000), updated: 1 }, { id: 'n2', title: 'Pendek', text: 'isi pendek', updated: 2 }] };
  for (const [typed, ctxL] of [[10, 0], [4000, 0], [4000, 1500], [100, 1500]]) {
    const ab = A.buildAttachment(data, ['n1', 'n2'], { total: A.budgetFor(typed, ctxL) }); assert.ok(ab.ok, typed + '/' + ctxL);
    const r = A.composePrompt({ ctxText: 'k'.repeat(ctxL), attText: ab.text, typed: 't'.repeat(typed) }); assert.ok(r.ok && r.content.length <= A.WORKER_MSG_MAX, typed + '/' + ctxL + ' = ' + (r.content || '').length);
  }
});
test('CSS: kelas baru ada, memakai variabel tema (terang dan gelap), tanpa warna tebakan, batas CSS 238 KB', () => {
  for (const k of ['.lp-bar', '.lp-chip', '.lp-o', '.lp-x', '.lp-bub', '.lp-bc', '.lp-row', '.lp-ck', '.lp-list', '.lp-bar:empty']) assert.ok(css.includes(k), k);
  const blok = css.slice(css.indexOf('/* Rev 306b'), css.indexOf('.lp-bc span'));
  assert.doesNotMatch(blok, /#[0-9a-fA-F]{3,8}\b/, 'tanpa warna heksa tetap'); assert.match(blok, /var\(--ink\)/); assert.match(blok, /var\(--gbd\)/);
  assert.ok(Buffer.byteLength(css) < 270 * 1024); assert.match(src('tools/audit-ukuran.mjs'), /cssMaks: 270 \* 1024/);
  assert.match(src('package.json'), /tests\/rev306b\.test\.mjs/); assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
});
