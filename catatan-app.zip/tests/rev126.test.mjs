// Rev 126 / U8a-1: mesin rumus lembar kerja (src/js/rumus.js), murni dan belum dipanggil UI.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 9, 14, 30, 0).getTime(); // 9 Nov 2026 14.30 (waktu lokal)

// Bangun tab: grid[r][c] = angka/teks (nilai) atau '=...' (rumus A1, dikonversi ke bentuk simpan)
function mk(grid, nrows = 12) {
  const t = L.newTab('T', nrows);
  grid.forEach((row, ri) => row.forEach((v, ci) => {
    if (v === undefined || v === null) return; const rowId = t.rows[ri].id, colId = t.cols[ci].id;
    if (typeof v === 'string' && v[0] === '=') { const r = R.a1ToStored(v, t); assert.ok(r.ok, v + ' -> ' + r.error); t.rows[ri].cells[colId] = { fx: r.fx }; }
    else L.setCell(t, rowId, colId, { v });
  }));
  return t;
}
const val = (t, a, o = {}) => { const p = L.parseAddr(a); return R.computeTab(t, { now: NOW, ...o }).get(t.rows[p.row].id, t.cols[p.col].id); };
const calc = (f, grid = []) => { const t = mk([[...grid, f]]); const row = t.rows[0]; return R.computeTab(t, { now: NOW }).get(row.id, t.cols[grid.length].id); };

test('modul murni: tanpa DOM/penyimpanan/native/Intl/eval/impor; konstanta batas sama dengan lembar.js; belum dipakai modul lain', () => {
  const s = src('src/js/rumus.js');
  assert.doesNotMatch(s, /localStorage|document\.|window\.|AndroidAPI|Intl\.|eval\(|new Function|^import /m);
  assert.equal(L.MAX_COLS, 26); assert.equal(L.MAX_ROWS, 500);
  for (const f of ['notes.js', 'main.js', 'settings.js', 'lembar.js', 'storage.js']) // Rev 127: lembar-ui.js kini memakai rumus.js (U8a-2); model/penyimpanan tetap tidak mengimpornya
   assert.doesNotMatch(src('src/js/' + f), /rumus\.js/, f);
});
test('aritmetika dan prioritas operator gaya Excel', () => {
  assert.equal(calc('=1+2*3'), 7); assert.equal(calc('=(1+2)*3'), 9); assert.equal(calc('=2^3^2'), 64); assert.equal(calc('=-2^2'), 4);
  assert.equal(calc('=10/4'), 2.5); assert.equal(calc('=50%'), 0.5); assert.equal(calc('=200*10%'), 20); assert.equal(calc('=1,5+1'), 2.5); assert.equal(calc('=1.5+1'), 2.5);
  assert.equal(calc('=--3'), 3); assert.equal(calc('=7-2-1'), 4); assert.equal(calc('="3"+4'), 7); assert.equal(calc('=TRUE+1'), 2);
});
test('galat: DIV/0, VALUE, NAME-lewat-evaluator, NUM; menjalar ke sel lain', () => {
  assert.equal(calc('=1/0'), R.E.DIV0); assert.equal(calc('="a"+1'), R.E.VALUE); assert.equal(calc('=0^0'), R.E.NUM); assert.equal(calc('=0^-1'), R.E.DIV0);
  const t = mk([[1, '=A1/0', '=B1+1', '=SUM(A1:C1)']]); const res = R.computeTab(t, { now: NOW });
  assert.equal(res.get('r1', 'cB'), R.E.DIV0); assert.equal(res.get('r1', 'cC'), R.E.DIV0); assert.equal(res.get('r1', 'cD'), R.E.DIV0);
  assert.equal(R.valueToText(R.E.DIV0), '#DIV/0!');
});
test('perbandingan, teks, dan penggabungan', () => {
  assert.equal(calc('=1<2'), true); assert.equal(calc('=2<=1'), false); assert.equal(calc('=3<>3'), false); assert.equal(calc('="a"="A"'), true);
  assert.equal(calc('="a"<"b"'), true); assert.equal(calc('=1<"a"'), true); assert.equal(calc('="x"&1&TRUE'), 'x1TRUE'); assert.equal(calc('="a""b"'), 'a"b');
  assert.equal(calc('=1+1&"x"'), '2x'); assert.equal(calc('=0.1+0.2=0.3'), true);
});
test('SUM/AVERAGE/MIN/MAX/COUNT/COUNTA: rentang hanya angka, argumen langsung dikoersi', () => {
  const g = [1, 2, 'x', true, null, 4]; // A1..F1 (E1 kosong)
  assert.equal(calc('=SUM(A1:F1)', g), 7); assert.equal(calc('=SUM(A1:F1;10)', g), 17); assert.equal(calc('=SUM("5";TRUE)'), 6); assert.equal(calc('=SUM(A1;C1)', g), 1);
  assert.equal(calc('=AVERAGE(A1:F1)', g), 7 / 3); assert.equal(calc('=AVERAGE(C1:E1)', g), R.E.DIV0);
  assert.equal(calc('=MIN(A1:F1)', g), 1); assert.equal(calc('=MAX(A1:F1)', g), 4); assert.equal(calc('=MIN(C1:E1)', g), 0);
  assert.equal(calc('=COUNT(A1:F1)', g), 3); assert.equal(calc('=COUNTA(A1:F1)', g), 5); assert.equal(calc('=COUNT(1;"2";"x")'), 2);
  assert.equal(calc('=SUM(1;;2)'), 3); assert.equal(calc('=SUM("x")'), R.E.VALUE); assert.equal(calc('=SUM(A1:F1;1/0)', g), R.E.DIV0);
});
test('IF malas, AND/OR/NOT', () => {
  assert.equal(calc('=IF(1>2;"a";"b")'), 'b'); assert.equal(calc('=IF(TRUE;1)'), 1); assert.equal(calc('=IF(FALSE;1)'), false);
  assert.equal(calc('=IF(1;IF(0;1;2);3)'), 2); assert.equal(calc('=IF(TRUE;5;1/0)'), 5); assert.equal(calc('=IF("x";1;2)'), R.E.VALUE);
  const t = mk([[0, 5, '=IF(A1=0;0;B1/A1)']]); assert.equal(R.computeTab(t).get('r1', 'cC'), 0);
  assert.equal(calc('=AND(1;TRUE;2>1)'), true); assert.equal(calc('=AND(1;0)'), false); assert.equal(calc('=OR(0;FALSE;1)'), true); assert.equal(calc('=OR(0;0)'), false);
  assert.equal(calc('=AND("x")'), R.E.VALUE); assert.equal(calc('=NOT(0)'), true); assert.equal(calc('=NOT(TRUE)'), false);
  assert.equal(calc('=IF(OR(A1="";B1="");"";A1*B1)', [null, 3]), ''); assert.equal(calc('=IF(OR(A1="";B1="");"";A1*B1)', [2, 3]), 6);
});
test('ROUND (setengah menjauhi nol), ABS', () => {
  assert.equal(calc('=ROUND(2.675;2)'), 2.68); assert.equal(calc('=ROUND(-2.5;0)'), -3); assert.equal(calc('=ROUND(2.5;0)'), 3); assert.equal(calc('=ROUND(1234;-2)'), 1200);
  assert.equal(calc('=ROUND(0.4;0)'), 0); assert.equal(Object.is(calc('=ROUND(-0.4;0)'), -0), false); assert.equal(calc('=ROUND(1;99)'), R.E.NUM); assert.equal(calc('=ABS(-3)'), 3); assert.equal(calc('=ABS("x")'), R.E.VALUE);
});
test('SUMIF/COUNTIF: operator, teks tanpa huruf besar-kecil, wildcard, rentang jumlah terpisah', () => {
  const g = [['apel', 10], ['Jeruk', 20], ['apel', 30], ['pisang', 5], [null, 7], ['10', 1]];
  const t = mk(g); const at = (f) => { t.rows[0].cells.cD = { fx: R.a1ToStored(f, t).fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cD'); };
  assert.equal(at('=COUNTIF(A1:A6;"apel")'), 2); assert.equal(at('=COUNTIF(A1:A6;"APEL")'), 2); assert.equal(at('=COUNTIF(A1:A6;"*e*")'), 3); assert.equal(at('=COUNTIF(A1:A6;"?isang")'), 1);
  assert.equal(at('=COUNTIF(B1:B6;">8")'), 3); assert.equal(at('=COUNTIF(B1:B6;"<=7")'), 3); assert.equal(at('=COUNTIF(B1:B6;10)'), 1); assert.equal(at('=COUNTIF(A1:A6;10)'), 1); assert.equal(at('=COUNTIF(A1:A6;"<>apel")'), 4);
  assert.equal(at('=COUNTIF(A1:A6;"")'), 1); assert.equal(at('=SUMIF(A1:A6;"apel";B1:B6)'), 40); assert.equal(at('=SUMIF(B1:B6;">8")'), 60); assert.equal(at('=SUMIF(A1:A6;"~*")'), 0);
  assert.equal(at('=COUNTIF(5;1)'), R.E.VALUE);
});
test('SUMIF dengan rentang jumlah yang lebih pendek dibaca selebar rentang pertama', () => {
  const t = mk([['a', 1], ['a', 2], ['b', 4], [null, 8]]); // sum_range B1:B2 tetapi range A1:A3 -> B1..B3
  t.rows[0].cells.cD = { fx: R.a1ToStored('=SUMIF(A1:A3;"a";B1:B2)', t).fx }; assert.equal(R.computeTab(t).get('r1', 'cD'), 3);
});
test('TODAY dan NOW memakai jam yang diberikan (nomor seri gaya Excel)', () => {
  assert.equal(calc('=TODAY()'), R.serialOf(NOW)); assert.equal(R.serialOf(new Date(2026, 10, 9).getTime()), 46335);
  const n = calc('=NOW()'); assert.ok(n > 46335 && n < 46336); assert.ok(Math.abs(n - 46335 - (14.5 / 24)) < 1e-9);
  assert.equal(calc('=TODAY()+7'), 46342);
});
test('urutan hitung: rantai, rentang berumus, dan 26x500 sel < 1 detik tanpa rekursi dalam', () => {
  const t = L.newTab('T', 500);
  for (let ri = 0; ri < 500; ri++) for (let ci = 0; ci < 26; ci++) {
    const rowId = t.rows[ri].id, colId = t.cols[ci].id;
    t.rows[ri].cells[colId] = ri === 0 ? { v: ci + 1 } : { fx: '=[' + t.rows[ri - 1].id + '.' + colId + ']+1' };
  }
  const t0 = Date.now(); const res = R.computeTab(t, { now: NOW }); const ms = Date.now() - t0;
  assert.equal(res.count, 499 * 26); assert.equal(res.get('r500', 'cA'), 500); assert.equal(res.get('r500', 'cZ'), 525); assert.equal(res.circular, 0); assert.ok(ms < 1000, 'lama: ' + ms);
  const t2 = L.newTab('T', 500); for (let ri = 0; ri < 499; ri++) t2.rows[ri].cells.cA = { v: 1 }; t2.rows[499].cells.cA = { fx: '=SUM([r1.cA:r499.cA])' };
  for (let ci = 1; ci < 26; ci++) for (let ri = 0; ri < 500; ri++) t2.rows[ri].cells[t2.cols[ci].id] = { fx: '=SUM([$r1.$cA:$r500.$cA])' };
  const t1 = Date.now(); const r2 = R.computeTab(t2, { now: NOW }); assert.equal(r2.get('r500', 'cA'), 499); assert.equal(r2.get('r3', 'cB'), 998); assert.ok(Date.now() - t1 < 3000, 'rentang besar lambat');
});
test('lingkaran terdeteksi (#CIRC!) dan menjalar; sel lain tetap benar', () => {
  const t = mk([['=B1+1', '=A1+1', '=A1', 5, '=D1*2']]); const res = R.computeTab(t); assert.equal(res.get('r1', 'cA'), R.E.CIRC); assert.equal(res.get('r1', 'cB'), R.E.CIRC); assert.equal(res.get('r1', 'cC'), R.E.CIRC); assert.equal(res.get('r1', 'cE'), 10); assert.equal(res.circular, 3);
  const s = mk([['=A1']]); assert.equal(R.computeTab(s).get('r1', 'cA'), R.E.CIRC);
});
test('rujukan ke baris yang dihapus jadi #REF!; hapus/sisip baris-kolom tidak merusak rumus (ID tetap)', () => {
  const t = mk([[1, 2], [3, 4], ['=A1+B2', '=SUM(A1:B2)']]);
  assert.equal(val(t, 'A3'), 5); assert.equal(val(t, 'B3'), 10);
  const before = t.rows[2].cells.cA.fx; const nid = L.insertRow(t, 0); assert.ok(nid); L.setCell(t, nid, 'cA', { v: 100 });
  assert.equal(t.rows[3].cells.cA.fx, before); assert.equal(R.computeTab(t).get('r3', 'cA'), 5); assert.equal(R.computeTab(t).get('r3', 'cB'), 10); // sisip baris di atas tidak mengubah hasil
  assert.equal(R.storedToA1(t.rows[3].cells.cA.fx, t), '=A2+B3'); // tampilan A1 ikut bergeser
  L.deleteCol(t, 'cZ'); const cid = L.insertCol(t, 0); assert.ok(cid); assert.equal(R.storedToA1(t.rows[3].cells.cA.fx, t), '=B2+C3'); assert.equal(R.computeTab(t).get('r3', 'cA'), 5);
  L.deleteRow(t, 'r2'); assert.equal(R.computeTab(t).get('r3', 'cA'), R.E.REF); assert.equal(R.storedToA1(t.rows.find((r) => r.id === 'r3').cells.cA.fx, t), '=B2+#REF!');
});
test('konversi A1 -> simpan -> A1: ID, mutlak, rentang, pemisah, desimal, teks', () => {
  const t = L.newTab('T', 10);
  const c = (a) => R.a1ToStored(a, t); assert.deepEqual(c('=B2+C3'), { ok: true, fx: '=[r2.cB]+[r3.cC]' });
  assert.equal(c('= sum( A1:A5 ; $B$2 ; 2,5 ) ').fx, '=SUM([r1.cA:r5.cA],[$r2.$cB],2.5)'); assert.equal(c('=b2').fx, '=[r2.cB]'); assert.equal(c('=SUMIF(A1:A9;"a;b";B1:B9)').fx, '=SUMIF([r1.cA:r9.cA],"a;b",[r1.cB:r9.cB])');
  assert.equal(R.storedToA1('=SUM([r1.cA:r5.cA],[$r2.$cB],2.5)', t), '=SUM(A1:A5;$B$2;2,5)'); assert.equal(R.storedToA1('=[r2.cB]&"x""y"', t), '=B2&"x""y"');
  for (const f of ['=SUM(A1:B2)', '=IF(A1>=2;"ya";"tidak")', '=A1*-3%', '=COUNTIF($A$1:$A$9;">5")', '=TODAY()+1,5']) { const s = c(f); assert.ok(s.ok, f); assert.equal(R.storedToA1(s.fx, t).replace(/,5$/, ',5'), f); }
});
test('a1ToStored menolak: sintaks salah, fungsi/nama tak dikenal, jumlah argumen, rujukan di luar tab, terlalu panjang/bersarang', () => {
  const t = L.newTab('T', 10);
  for (const [f, re] of [['A1+1', /diawali/], ['=1+', /tidak lengkap/], ['=(1+2', /kurung/], ['=SUM(1;', /kurung/], ['=FOO(1)', /Fungsi tidak dikenal/], ['=abc', /Nama tidak dikenal/], ['=IF(1)', /Jumlah argumen/], ['=ROUND(1)', /Jumlah argumen/],
    ['=A11', /belum ada/], ['=AA1', /Rujukan di luar/], ['=A501', /Rujukan di luar/], ['="abc', /kutip/], ['=1:2', /Titik dua/], ['=@1', /tidak dikenal/], ['=' + '('.repeat(40) + '1' + ')'.repeat(40), /bersarang/], ['=' + '1+'.repeat(300) + '1', /panjang/]]) {
    const r = R.a1ToStored(f, t); assert.equal(r.ok, false, f); assert.match(r.error, re, f);
  }
  assert.equal(R.a1ToStored('=SUM(A1:A2;B1;)', t).ok, true); // argumen kosong boleh (Excel)
});
test('nama fungsi tak dikenal di data simpan tidak menjatuhkan hitungan: #NAME?; rumus simpan rusak: #NAME?', () => {
  const t = L.newTab('T', 3); t.rows[0].cells.cA = { fx: '=FOO(1)' }; t.rows[0].cells.cB = { fx: '=1+' }; t.rows[0].cells.cC = { fx: '=SUM(' };
  const res = R.computeTab(t); assert.equal(res.get('r1', 'cA'), R.E.NAME); assert.equal(res.get('r1', 'cB'), R.E.NAME); assert.equal(res.get('r1', 'cC'), R.E.NAME);
  assert.equal(R.storedToA1('=1+', t), '=1+');
});
test('hasil rentang atau sel kosong: =A1:A3 -> #VALUE!, =A1 (kosong) -> 0; evalExpr untuk pratinjau', () => {
  const t = mk([[1, 2], [3]]); assert.equal(R.computeTab(t).evalExpr('=SUM([r1.cA:r2.cB])'), 6); assert.equal(R.computeTab(t).evalExpr('=[r2.cB]'), 0); assert.equal(R.computeTab(t).evalExpr('=[r1.cA:r2.cA]'), R.E.VALUE);
  assert.equal(R.computeTab(t).evalExpr('=['), R.E.NAME);
});
test('format teks hasil: desimal koma, 15 digit signifikan, TRUE/FALSE, kosong', () => {
  assert.equal(R.valueToText(2.5), '2,5'); assert.equal(R.valueToText(2.5, { comma: false }), '2.5'); assert.equal(R.valueToText(0.1 + 0.2), '0,3'); assert.equal(R.valueToText(true), 'TRUE'); assert.equal(R.valueToText(null), ''); assert.equal(R.valueToText('abc'), 'abc'); assert.equal(R.valueToText(1e21), '1e+21');
  assert.equal(R.numToText(-0), '0'); assert.equal(R.numToText(Infinity), '');
});
test('saran fungsi untuk bilah rumus (dipakai U8b)', () => {
  assert.deepEqual(R.suggestFunctions('su').map((f) => f.name), ['SUM', 'SUMIF', 'SUMIFS']); assert.deepEqual(R.suggestFunctions('co').map((f) => f.name), ['CONCAT', 'COUNT', 'COUNTA', 'COUNTIF', 'COUNTIFS']); assert.equal(R.suggestFunctions('').length, 6); assert.deepEqual(R.suggestFunctions('zz'), []);
  assert.equal(R.FUNCTION_LIST.length, 53); // Rev 138: 16 fungsi tahap 1 + 6 tahap 2 for (const f of R.FUNCTION_LIST) assert.ok(f.sig.startsWith(f.name + '(') && f.ket.length > 3);
});
test('wildcard tanpa ReDoS: pola berbintang banyak pada teks panjang selesai cepat', () => {
  const t = mk([['a'.repeat(1900)]]); t.rows[0].cells.cB = { fx: R.a1ToStored('=COUNTIF(A1:A1;"' + 'a*'.repeat(30) + 'b")', t).fx };
  const t0 = Date.now(); assert.equal(R.computeTab(t).get('r1', 'cB'), 0); assert.ok(Date.now() - t0 < 500);
});
test('versi (dinaikkan Rev 127), tes terdaftar; fx kini disimpan model sel sejak Rev 127 (U8a-2)', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(pk.scripts.test.includes('tests/rev126.test.mjs')); assert.equal(L.cleanCell({ fx: '=1', v: 1 }).fx, '=1'); // Rev 127: fx disimpan, v dibuang
});
