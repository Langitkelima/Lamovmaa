// Rev 416: teks gaya Google Keep ("[ ] a" / "[X] b") jadi kotak centang sungguhan + geser urutan baris centang. Murni (logic.js, todo.js) + statis.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseCheckLine, sharedToHtml } from '../src/js/logic.js';
const rd = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const notes = rd('../src/js/notes.js'), css = rd('../src/css/styles.css'), todo = rd('../src/js/todo.js');

test('parseCheckLine: bentuk Keep dan variannya', () => {
  assert.deepEqual(parseCheckLine('[ ] Kuliner'), { done: false, text: 'Kuliner' });
  assert.deepEqual(parseCheckLine('[X] Photobox'), { done: true, text: 'Photobox' });
  assert.deepEqual(parseCheckLine('[x] a'), { done: true, text: 'a' });
  assert.deepEqual(parseCheckLine('[] tanpa spasi'), { done: false, text: 'tanpa spasi' });
  assert.deepEqual(parseCheckLine('- [ ] markdown'), { done: false, text: 'markdown' });
  assert.deepEqual(parseCheckLine('\u2611 sudah'), { done: true, text: 'sudah' });
  assert.deepEqual(parseCheckLine('\u2610 belum'), { done: false, text: 'belum' });
});
test('parseCheckLine: bukan kotak centang tetap null', () => {
  for (const s of ['Catatan biasa', '[link](https://a.id)', '[abc] huruf', '', '1. satu', 'a [ ] di tengah']) assert.equal(parseCheckLine(s), null, s);
});
test('sharedToHtml: baris centang jadi <div class="todo"> sama bentuknya dengan insertTodo', () => {
  const h = sharedToHtml('Judul\n[X] satu\n[ ] dua <b>\n\nakhir');
  assert.equal(h, '<div>Judul</div><div class="todo"><input type="checkbox" checked="">\u00a0satu</div><div class="todo"><input type="checkbox">\u00a0dua &lt;b&gt;</div><div><br></div><div>akhir</div>');
});
test('sharedToHtml: teks tanpa kotak centang TIDAK berubah dari perilaku lama', () => {
  assert.equal(sharedToHtml('a\n\nb & c'), '<div>a</div><div><br></div><div>b &amp; c</div>');
});
test('insertTodoLines: terdaftar, dipakai tempel, dan gagang geser ada di notes.js + CSS', () => {
  assert.match(todo, /export function insertTodoLines/);
  assert.match(notes, /insertTodoLines\(ed, at, lines\)/);
  assert.match(notes, /parseCheckLine\(l\)/);
  assert.match(notes, /classList\.contains\('ed-baca'\)\) return null; \/\/ mode Baca/);
  assert.match(notes, /addEventListener\('touchstart'[\s\S]{0,160}passive: false/);
  assert.match(css, /\.fs:not\(\.ed-baca\) \.ed2 \.todo::before\{/);
  assert.match(css, /\.ed2 \.todo\.kdrag\{/);
});
test('gagang = pseudo-elemen CSS, tidak masuk HTML tersimpan', () => {
  assert.ok(!/kdrag|\bgh\b/.test(sharedToHtml('[ ] a')));
});
