// Rev 423 / PART SY3c (Paket SY): sinkron otomatis (src/js/sync-auto.js) + pemasangan di main.js. Tes Node dengan jam, penjadwal, dan penjalan PALSU. BUKAN bukti dari HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { buatPenjadwal, AUTO } from '../src/js/sync-auto.js';
import { SYNC_CFG_KEY } from '../src/js/sync-jalan.js'; import { CONN_KEY } from '../src/js/ai/sambungan.js';
const rd = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const store = () => { const m = new Map(); return { m, getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => { m.set(k, String(v)); }, removeItem: (k) => { m.delete(k); } }; };
function dunia({ auto = true, conn = true, online = true, editor = false, hasil } = {}) {
  const st = store(); if (conn) st.setItem(CONN_KEY, JSON.stringify({ url: 'https://k.contoh.workers.dev', key: 'rama-secret-12' }));
  if (auto) st.setItem(SYNC_CFG_KEY, JSON.stringify({ v: 1, auto: true, lastTryAt: 0 }));
  const w = { t: 1_000_000, q: [], on: online, ed: editor, panggil: [], warn: [] };
  const deps = { store: st, now: () => w.t, online: () => w.on, editorBuka: () => w.ed, sanitize: () => '', toast: { warn: (m) => w.warn.push(m) },
    setTimeout: (f, ms) => { const o = { f, at: w.t + ms, id: w.q.length + 1 }; w.q.push(o); return o.id; }, clearTimeout: (id) => { const o = w.q.find((x) => x.id === id); if (o) o.dead = true; },
    jalan: async (o) => { w.panggil.push(o); return typeof hasil === 'function' ? hasil(w) : { ok: true, msg: 'ok' }; } };
  // majukan jam dan jalankan semua pewaktu yang jatuh tempo (berulang bila pewaktu baru muncul)
  w.maju = async (ms) => { const target = w.t + ms; for (;;) { const o = w.q.filter((x) => !x.dead && x.at <= target).sort((a, b) => a.at - b.at)[0]; if (!o) break; o.dead = true; w.t = Math.max(w.t, o.at); o.f(); await new Promise((r) => setImmediate(r)); } w.t = target; };
  w.p = buatPenjadwal({ data: { notes: [] }, persist: () => ({ ok: true }), render() {} }, deps);
  return w;
}

test('mati bila sakelar Otomatis mati atau belum tersambung', async () => {
  for (const o of [{ auto: false }, { conn: false }]) { const w = dunia(o); assert.equal(w.p.pemicu('buka'), false); await w.maju(60000); assert.equal(w.panggil.length, 0); }
});
test('buka: jalan setelah jeda singkat; simpan beruntun digabung jadi SATU putaran sesudah tenang', async () => {
  const w = dunia(); w.p.pemicu('buka'); await w.maju(AUTO.bukaTunda + 10); assert.equal(w.panggil.length, 1);
  for (let i = 0; i < 5; i++) { w.p.pemicu('simpan'); await w.maju(2000); } assert.equal(w.panggil.length, 1, 'belum tenang');
  await w.maju(AUTO.simpanTunda + AUTO.jedaMin); assert.equal(w.panggil.length, 2);
});
test('jeda minimal antar putaran dihormati', async () => {
  const w = dunia(); w.p.pemicu('simpan'); await w.maju(AUTO.simpanTunda + 10); assert.equal(w.panggil.length, 1);
  w.p.pemicu('simpan'); await w.maju(AUTO.simpanTunda + 10); assert.equal(w.panggil.length, 1, 'jeda 30 dtk belum lewat');
  await w.maju(AUTO.jedaMin); assert.equal(w.panggil.length, 2);
});
test('kembali dari latar: dilewati bila baru saja mencoba, jalan bila sudah lama', async () => {
  const w = dunia(); w.t = 10_000_000; const st = w.p; // lastTryAt=0 => sudah lama
  st.pemicu('kembali'); await w.maju(AUTO.bukaTunda + 10); assert.equal(w.panggil.length, 1);
});
test('offline: menunggu kejadian online, tidak memanggil jaringan; online memicu satu putaran', async () => {
  const w = dunia({ online: false }); w.p.pemicu('buka'); await w.maju(10000); assert.equal(w.panggil.length, 0); assert.equal(w.p.status().menungguOnline, true);
  w.on = true; w.p.pemicu('online'); await w.maju(AUTO.bukaTunda + 10); assert.equal(w.panggil.length, 1);
});
test('editor layar penuh terbuka: ditunda sampai ditutup, tidak pernah jalan selama terbuka', async () => {
  const w = dunia({ editor: true }); w.p.pemicu('simpan'); await w.maju(60000); assert.equal(w.panggil.length, 0);
  w.ed = false; await w.maju(AUTO.cekEditor + 10); assert.equal(w.panggil.length, 1);
});
test('gagal: jeda panjang (backoff); passcode ditolak = satu peringatan; hapus massal TIDAK pernah diizinkan otomatis dan ditahan = diberi tahu', async () => {
  const w = dunia({ hasil: () => ({ ok: false, msg: 'x', passcode: true, status: 401 }) });
  w.p.pemicu('simpan'); await w.maju(AUTO.simpanTunda + 10); assert.equal(w.panggil.length, 1); assert.equal(w.warn.length, 1); assert.equal(w.panggil[0].allowMassDelete, false);
  w.p.pemicu('simpan'); await w.maju(AUTO.simpanTunda + AUTO.jedaMin + 10); assert.equal(w.panggil.length, 1, 'masih dalam backoff'); await w.maju(AUTO.jedaGagal); assert.equal(w.panggil.length, 2); assert.equal(w.warn.length, 1, 'peringatan passcode tidak diulang');
  const h = dunia({ hasil: () => ({ ok: true, held: { deletes: 42, tracked: 60 } }) }); h.p.pemicu('buka'); await h.maju(AUTO.bukaTunda + 10); assert.match(h.warn[0], /42 penghapusan ditahan/);
});
test('pemasangan: main.js memuat sync-auto MALAS hanya bila auto menyala; simpan yang dipicu sinkron tidak memicu lagi; tanpa Catatan Privat/passcode', () => {
  const m = rd('src/js/main.js'), a = rd('src/js/sync-auto.js').replace(/\/\/.*$/gm, '');
  assert.match(m, /includes\('"auto":true'\)/); assert.match(m, /import\('\.\/sync-auto\.js'\)/); assert.doesNotMatch(m.replace(/\/\/.*$/gm, ''), /^import .*sync-auto/m);
  for (const w of ['simpan', 'buka', 'kembali']) assert.match(m, new RegExp("autoSync\\('" + w + "'\\)"));
  assert.match(a, /why === 'simpan' && sedangSinkron\(\)/); assert.doesNotMatch(a, /\.priv\b|\.key\b|document\.write|localStorage\.(get|set)Item/);
  assert.match(rd('src/js/sync-ui.js'), /saat app dibuka, setelah menyimpan/);
});
test('dokumen dan pemasangan: banner Rev 423, tes terdaftar, versi/SCHEMA tetap', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) { const d = rd(f); assert.ok(/^\*\*Rev 4(?:2[3-9]|3\d) \/ v0\.3\.121/.test(d), f); const e = d.slice(d.indexOf('**Rev 423 /'), d.indexOf('**Rev 422 /')); assert.match(e, /SY3c/); assert.match(e, /BERFUNGSI-BELUM-DIUJI/); assert.match(e, /SCHEMA \(22\)/); }
  assert.match(rd('package.json'), /tests\/rev423\.test\.mjs/); assert.equal(JSON.parse(rd('package.json')).version, '0.3.121'); assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
});
