// Rev 138 / Q10: fungsi rumus TAHAP 2 (saran minimal): IFERROR, SUMIFS, COUNTIFS, ROUNDUP, ROUNDDOWN, MEDIAN.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { argHint } from '../src/js/rumus-bantu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 9, 14, 30, 0).getTime();
function mk(grid) {
  const t = L.newTab('T', 12);
  grid.forEach((row, ri) => row.forEach((v, ci) => { if (v === undefined || v === null) return; L.setCell(t, t.rows[ri].id, t.cols[ci].id, { v }); }));
  return t;
}
// satu rumus di sel F1 (kolom F), data di A:C
function at(grid, f) { const t = mk(grid); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cF = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cF'); }
const calc = (f) => at([], f);
const DATA = [['apel', 'A', 10], ['jeruk', 'A', 20], ['apel', 'B', 30], ['apel', 'A', 5], ['pisang', 'B', 7]];

test('IFERROR: pakai nilai bila sah, ganti bila galat; cabang kedua malas; #CIRC! tidak ditelan', () => {
  assert.equal(calc('=IFERROR(1/0;"x")'), 'x'); assert.equal(calc('=IFERROR(4/2;"x")'), 2); assert.equal(calc('=IFERROR(FOO(1);9)').rejected !== undefined, true);
  assert.equal(calc('=IFERROR("a"*2;0)'), 0); assert.equal(calc('=IFERROR(1/0;1/0)').e, '#DIV/0!');
  const t = mk([]); t.rows[0].cells.cA = { fx: R.a1ToStored('=IFERROR(A1;0)', t).fx }; // merujuk diri sendiri
  assert.equal(R.computeTab(t, { now: NOW }).get('r1', 'cA').e, '#CIRC!');
});
test('SUMIFS: semua kriteria, operator, wildcard, rentang berbeda ukuran = #VALUE!', () => {
  assert.equal(at(DATA, '=SUMIFS(C1:C5;A1:A5;"apel";B1:B5;"A")'), 15);
  assert.equal(at(DATA, '=SUMIFS(C1:C5;A1:A5;"apel";C1:C5;">5")'), 40);
  assert.equal(at(DATA, '=SUMIFS(C1:C5;A1:A5;"*e*")'), 65); assert.equal(at(DATA, '=SUMIFS(C1:C5;A1:A5;"tidak ada")'), 0);
  assert.equal(at(DATA, '=SUMIFS(C1:C5;A1:A4;"apel")').e, '#VALUE!'); assert.equal(at(DATA, '=SUMIFS(5;A1:A5;"apel")').e, '#VALUE!');
});
test('COUNTIFS: semua kriteria, tanpa rentang jumlah', () => {
  assert.equal(at(DATA, '=COUNTIFS(A1:A5;"apel";B1:B5;"A")'), 2); assert.equal(at(DATA, '=COUNTIFS(C1:C5;">=10";C1:C5;"<=30")'), 3);
  assert.equal(at(DATA, '=COUNTIFS(A1:A5;"apel")'), 3); assert.equal(at(DATA, '=COUNTIFS(A1:A5;"apel";B1:B4;"A")').e, '#VALUE!');
});
test('jumlah argumen genap/ganjil ditolak saat diketik; galat sel sumber menjalar', () => {
  assert.match(at(DATA, '=SUMIFS(C1:C5;A1:A5)').rejected, /Jumlah argumen SUMIFS/); assert.match(at(DATA, '=COUNTIFS(A1:A5;"a";B1:B5)').rejected, /Jumlah argumen COUNTIFS/);
  const t = mk(DATA); t.rows[2].cells.cC = { fx: R.a1ToStored('=1/0', t).fx }; t.rows[0].cells.cF = { fx: R.a1ToStored('=SUMIFS(C1:C5;A1:A5;"apel")', t).fx };
  assert.equal(R.computeTab(t, { now: NOW }).get('r1', 'cF').e, '#DIV/0!');
});
test('ROUNDUP / ROUNDDOWN: menjauhi / menuju nol, digit negatif, aman dari galat floating', () => {
  assert.equal(calc('=ROUNDUP(2.341;2)'), 2.35); assert.equal(calc('=ROUNDUP(-2.341;2)'), -2.35); assert.equal(calc('=ROUNDUP(1234;-2)'), 1300); assert.equal(calc('=ROUNDUP(5;0)'), 5);
  assert.equal(calc('=ROUNDDOWN(2.349;2)'), 2.34); assert.equal(calc('=ROUNDDOWN(-2.349;2)'), -2.34); assert.equal(calc('=ROUNDDOWN(1299;-2)'), 1200);
  assert.equal(calc('=ROUNDDOWN(1.15;2)'), 1.15); assert.equal(calc('=ROUNDUP(1.15;2)'), 1.15); assert.equal(calc('=ROUNDUP(1;99)').e, '#NUM!'); assert.equal(calc('=ROUNDDOWN("x";1)').e, '#VALUE!');
  assert.equal(Object.is(calc('=ROUNDDOWN(-0.4;0)'), -0), false);
});
test('MEDIAN: ganjil, genap, teks diabaikan di rentang, kosong = #NUM!', () => {
  assert.equal(at([[3], [1], [2]], '=MEDIAN(A1:A3)'), 2); assert.equal(at([[4], [1], [3], [2]], '=MEDIAN(A1:A4)'), 2.5);
  assert.equal(at([['x'], [10], [20]], '=MEDIAN(A1:A3)'), 15); assert.equal(at([['x']], '=MEDIAN(A1:A1)').e, '#NUM!'); assert.equal(calc('=MEDIAN(1;9;5)'), 5);
});
test('daftar fungsi + petunjuk argumen: 39 fungsi, tahap 2 punya sig dan keterangan', () => {
  const names = R.FUNCTION_LIST.map((f) => f.name);
  for (const n of ['IFERROR', 'SUMIFS', 'COUNTIFS', 'ROUNDUP', 'ROUNDDOWN', 'MEDIAN']) { assert.ok(names.includes(n), n); const a = argHint(n, 0); assert.ok(a && a.sig.startsWith(n + '(') && a.ket); }
  assert.equal(names.length, 53); assert.ok(argHint('SUMIFS', 7).parts.length >= 4);
});
test('rumus tahap 2 tersimpan dan terbaca balik (A1 <-> simpan)', () => {
  const t = mk(DATA); for (const f of ['=SUMIFS(C1:C5;A1:A5;"apel";B1:B5;"A")', '=COUNTIFS(A1:A5;"apel")', '=IFERROR(C1/C2;0)', '=MEDIAN(C1:C5)', '=ROUNDUP(C1/3;2)']) { const s = R.a1ToStored(f, t); assert.ok(s.ok, f); assert.equal(R.storedToA1(s.fx, t), f); }
});
test('mesin tetap murni; Rev 138: versi 0.3.121, SCHEMA 13 tetap, tes terdaftar', () => {
  assert.doesNotMatch(src('src/js/rumus.js'), /localStorage|document\.|window\.|AndroidAPI|Intl\.|eval\(|new Function|^import /m);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev138.test.mjs'));
});
