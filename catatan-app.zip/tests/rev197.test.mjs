// Rev 195a / P5a: kebocoran pendengar placeSoon saat editor ditutup. Berkas rev197 = Rev 195a.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const N = src('src/js/notes.js');
test('setiap pendengar placeSoon yang dipasang editor (window resize, vv resize/scroll) dilepas di cleanup()', () => {
  assert.match(N, /addEventListener\('resize', placeSoon\);/); assert.match(N, /vv\.addEventListener\('resize', placeSoon\); vv\.addEventListener\('scroll', placeSoon\)/);
  const i = N.indexOf('const cleanup = () => {'); const j = N.indexOf('\n', i); const cl = N.slice(i, j);
  assert.match(cl, /removeEventListener\('resize', placeSoon\)/); assert.match(cl, /vv\.removeEventListener\('resize', placeSoon\); vv\.removeEventListener\('scroll', placeSoon\)/);
  assert.match(cl, /try \{ syncBars\(\); \} catch/, 'cleanup lama tetap utuh');
});
test('semua vv.addEventListener editor punya pasangan removeEventListener (fit, kbUi, placeSoon)', () => {
  const add = [...N.matchAll(/vv\.addEventListener\('(resize|scroll)', (\w+)\)/g)].map((m) => m[1] + ':' + m[2]).sort();
  const rem = [...N.matchAll(/vv\.removeEventListener\('(resize|scroll)', (\w+)\)/g)].map((m) => m[1] + ':' + m[2]).sort();
  assert.deepEqual([...new Set(add)], [...new Set(rem)]);
});
test('tanpa native/dependensi/SCHEMA berubah; versi 0.3.121 dan tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(pk.scripts.test, /node tests\/rev197\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
