// Rev 401 / PART K2: layar "Gambar kartu" di menu Bagikan (pratinjau + 4 warna bawaan + Bagikan/Simpan). Tes AI (Node, pemeriksaan sumber).
// Perilaku sungguhan (kanvas, pratinjau, tombol, unduhan) diuji di Chromium lewat tools/audit_kartu_ui_401.py; HP BELUM.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs'; import { spawnSync } from 'node:child_process';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const strip = (s) => s.replace(/\/\/.*$/gm, '');

test('menu Bagikan: opsi "Gambar kartu" memuat kartu-ui.js MALAS (import dinamis, gagal = tErr), tidak ada impor statis di mana pun', () => {
  const s = rd('src/js/share.js');
  assert.ok(s.includes("import('./kartu-ui.js').then((m) => m.bukaKartu(ctx, n)).catch(() => tErr('Gambar kartu gagal dibuka.'))"));
  assert.ok(s.includes("h('b', {}, 'Gambar kartu')"));
  assert.ok(s.indexOf("'Gambar kartu'") > s.indexOf("opt('Gambar JPG'") && s.indexOf("'Gambar kartu'") < s.indexOf("opt('Teks (.txt)'")); // di antara JPG dan Teks
  const statis = []; for (const dir of ['src/js', 'src/js/ai']) for (const f of fs.readdirSync(new URL('../' + dir + '/', import.meta.url)).filter((x) => x.endsWith('.js'))) if (/^import .*kartu-ui/m.test(rd(dir + '/' + f))) statis.push(dir + '/' + f);
  assert.deepEqual(statis, []);
  assert.ok(!/kartu-ui/.test(rd('scripts/preload.mjs')) && !/kartu-ui|kartu\.js/.test(rd('src/js/main.js'))); // bukan jalur buka
});

test('share.js: hanya menambah export (sendFiles, loadShareImages) dan satu tombol; aturan "tanpa Catatan Privat" tetap', () => {
  const s = rd('src/js/share.js');
  assert.ok(s.includes('export async function sendFiles(files, title) {') && s.includes('export async function loadShareImages(n) {'));
  assert.ok(!/data\.priv|\bisP\b|kind === 'priv'|\.priv\b/.test(s));
  assert.ok(!/data\.priv|\bisP\b|kind === 'priv'|\.priv\b|izinPriv/.test(strip(rd('src/js/kartu-ui.js')))); // Catatan Privat tidak pernah sampai sini (tombol Bagikan-nya tidak ada)
  assert.match(rd('src/js/notes.js'), /isP \? null : mi\(PATH\.share, 'Bagikan'/);
});

test('kartu-ui.js: memakai mesin kartu + jalur kirim/simpan yang sudah ada, memuat gambar dan mesin rumus, hanya 4 warna bawaan, tidak ada penyimpanan/jaringan', () => {
  const k = strip(rd('src/js/kartu-ui.js'));
  for (const x of ["from './kartu.js'", "from './share.js'", "from './lembar-pulau.js'", "from './lembar-mesin.js'", 'renderKartu(n, { warna, images: images || null })', 'loadShareImages(n)', 'sheetsHaveFx(ctx.data.sheets)', 'setSheetsSource(() => ctx.data.sheets)', 'sendFiles([f], n.title)', 'simpanGaleri(f)', "role: 'radiogroup'", "role: 'radio'", 'URL.revokeObjectURL']) assert.ok(k.includes(x), x);
  assert.ok(!/fetch\(|XMLHttpRequest|Capacitor|nativePlugin/.test(k) && (k.match(/localStorage/g) || []).length === 2); // Rev 402: hanya riwayat warna (baca + tulis, bawaan parameter)
  assert.ok(/image\/jpeg/.test(k) && /-kartu\.jpg/.test(k));
});

test('kartu-ui.js: kegagalan selalu dijelaskan (render gagal, gambar tak termuat, kirim/simpan gagal), batal dari menu Bagikan tidak dianggap galat, hasil render basi dibuang', () => {
  const k = rd('src/js/kartu-ui.js');
  assert.ok(k.includes("'Kartu gagal dibuat: '") && k.includes('Gambar di catatan tidak ikut karena tidak bisa dimuat.') && k.includes("'Gagal ' + (mode === 'save' ? 'menyimpan' : 'membagikan') + ' kartu: '"));
  assert.ok(/!\/cancel\/i\.test\(msgOf\(e\)\)/.test(k));
  assert.ok(k.includes('if (my !== tok || !alive()) return;')); // ketukan warna cepat: hanya hasil terakhir yang dipakai
  assert.ok(k.includes("tWarn('Catatan masih kosong.')"));
});

test('CSS: kelas layar kartu ada dan hanya memakai variabel tema (terang dan gelap)', () => {
  const css = rd('src/css/styles.css'), i = css.indexOf('/* Rev 401 / K2'); assert.ok(i > 0);
  const blok = css.slice(i, css.indexOf('/* Rev 402 / K3'));
  for (const sel of ['.kartuov .sheet', '.kartu-pv', '.kartu-pv img', '.kartu-warna', '.kartu-chip', '.kartu-chip[aria-checked="true"]', '.kartu-aksi', '.kartu-tutup']) assert.ok(blok.includes(sel), sel);
  assert.ok(!/#[0-9a-fA-F]{3,6}\b/.test(blok.replace(/\/\*.*?\*\//g, ''))); // warna kartu bawaan dipasang lewat style inline dari mesin, bukan dari CSS
});

test('pemasangan: anggaran JS 1540 KB (izin pengguna 22 Nov 2026), tes terdaftar, versi dan SCHEMA tetap, semua modul bisa diurai', () => {
  assert.match(rd('tools/audit-ukuran.mjs'), /cssMaks: 270 \* 1024, jsMaks: 1600 \* 1024, totalMaks: 2100 \* 1024/);
  const pk = JSON.parse(rd('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev401\.test\.mjs/);
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
  const bad = []; for (const f of ['kartu-ui.js', 'share.js', 'kartu.js']) { const r = spawnSync(process.execPath, ['--check', new URL('../src/js/' + f, import.meta.url).pathname], { encoding: 'utf8' }); if (r.status !== 0) bad.push(f); }
  assert.deepEqual(bad, []);
  let js = 0; for (const dir of ['src/js', 'src/js/ai']) for (const f of fs.readdirSync(new URL('../' + dir + '/', import.meta.url)).filter((n) => n.endsWith('.js'))) js += fs.statSync(new URL('../' + dir + '/' + f, import.meta.url)).size;
  assert.ok(js <= 1600 * 1024, 'JS ' + js);
});

test('dokumen: banner Rev 401 paling atas di RIWAYAT dan PROMPT, izin anggaran tercatat jujur, bagian uji HP CC ada, status 39.9', () => {
  for (const f of ['RIWAYAT.md', 'PROMPT_SERAH_TERIMA.md']) { const d = rd(f); assert.ok(/^\*\*Rev 4(?:0[1-9]|[123]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 401 /') < d.indexOf('**Rev 400 /'), f); assert.ok(d.includes('BERFUNGSI-BELUM-DIUJI') && d.includes('jsMaks` 1520 -> 1540 KB')); }
  assert.ok(rd('UJI_HP_RILIS.md').includes('## CC. Gambar kartu (Rev 401, PART K2)'));
  assert.ok(rd('PROMPT_SERAH_TERIMA.md').includes('**39.9 STATUS (Rev 401):**'));
  assert.match(rd('README.md'), /Rev 4(?:0[1-9]|[123]\d) · SCHEMA 22/);
});
