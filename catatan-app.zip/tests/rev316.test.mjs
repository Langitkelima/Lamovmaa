// Rev 316 / PART T1 (diperbarui Rev 322): kolom tabel di editor tidak boleh melebarkan tabel; teks panjang dipatah ke bawah dan baris tumbuh tinggi. Hanya CSS.
// Rev 322: tabel kini selalu pas lebar catatan (width:100%) dengan kolom sama lebar (table-layout:fixed); tabel 4-8 kolom diberi lebar minimum per kolom
// lalu digulir di .tbl-wrap; tabel dengan data-w (lebar diseret) memakai layout otomatis agar kolom yang diseret tetap persis.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const rule = css.split('\n').find((l) => l.startsWith('.ed2 td, .ed2 th {') && l.includes('min-width:80px'));
test('Rev 316/322: sel tabel punya lebar min 80 dan maks 220 px + pematahan teks', () => {
  assert.ok(rule, 'aturan sel tidak ada');
  assert.ok(/min-width:80px/.test(rule) && /max-width:220px/.test(rule) && /overflow-wrap:anywhere/.test(rule));
});
test('Rev 322: tabel pas lebar catatan, kolom sama lebar, teks turun ke bawah (bukan menggeser)', () => {
  assert.ok(/\.ed2 table \{[^}]*table-layout:fixed;[^}]*width:100%/.test(css));
  assert.ok(!/\.ed2 table \{[^}]*width:max-content/.test(css), 'width:max-content membuat teks panjang melebarkan tabel');
  for (const [n, w] of [[4, 352], [5, 440], [6, 528], [7, 616], [8, 704]]) assert.ok(css.includes(`.ed2 table:has(tr>:nth-child(${n})) { min-width:${w}px; }`), 'min-width ' + n + ' kolom');
  assert.ok(/\.ed2 table\[data-w\] \{[^}]*table-layout:auto;[^}]*width:100%/.test(css));
  assert.ok(/\.ed2 \.tbl-wrap \{[^}]*overflow-x:auto/.test(css));
});
test('Rev 316: versi dan SCHEMA tidak berubah', () => {
  assert.ok(readFileSync(new URL('../package.json', import.meta.url), 'utf8').includes('"version": "0.3.121"'));
  assert.ok(readFileSync(new URL('../src/js/storage.js', import.meta.url), 'utf8').includes('export const SCHEMA = 22;'));
});
