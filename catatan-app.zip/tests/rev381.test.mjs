// Rev 381 / PART AL3b-3: pemilih mode pengingat di dialog tugas (+ sub-tugas) dan panel Pengingat catatan; chip pembeda alarm (2B). Tes Node: teks sumber + mesin.
import test from 'node:test'; import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { withMode, cleanSubs } from '../src/js/logic.js';
import { normalizeReminder, scheduleReminder, scheduleSubReminder } from '../src/js/reminders.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('main.js: dialog tugas dimuat lewat alarm-ui.js MALAS; pengingat tugas bermode sendiri (sub-tugas: lihat rev394)', () => {
  const m = src('src/js/main.js');
  assert.ok(!/^import .* from '\.\/alarm-ui\.js'/m.test(m)); assert.equal((m.match(/import\('\.\/alarm-ui\.js'\)/g) || []).length, 1);
  assert.ok(m.includes('function openSheetNow(kind, item, opts, A)') && m.includes('A.modePicker('));
  assert.ok(m.includes("remFields, mp ? mp.el : null"));
  assert.equal((m.match(/withMode\(\{ at, repeat: remRepeat\.value === 'daily' \? 'daily' : 'once' \}, rmode\)/g) || []).length, 2, 'tugas baru + ubah');
  // Rev 394 / SM2: DISENGAJA berubah. Dulu satu mode menimpa semua sub-tugas; kini tiap sub-tugas membawa modenya sendiri (subMode), tanpa penimpaan saat Simpan.
  assert.ok(m.includes("withMode({ at: t, repeat: rp.value === 'daily' ? 'daily' : 'once' }, subMode())") && !m.includes('if (subsMode) draft.forEach((x) => { if (x.reminder) x.reminder = withMode('));
  assert.ok(m.includes("'⏰ Alarm berdering'") && m.includes("'⏰ Ada pengingat'"));
});
test('notes.js: panel Pengingat catatan memuat pemilih ke slot, simpan lewat withMode, ikon header alarm solid', () => {
  const n = src('src/js/notes.js');
  assert.ok(n.includes("let nMode = n.reminder && n.reminder.mode === 'alarm' ? 'alarm' : 'notif'") && n.includes('modeSlot'));
  assert.ok(n.includes("withMode({ at, repeat: remRepeat.value === 'daily' ? 'daily' : 'once' }, nMode)") && n.includes("onChange: (m) => { nMode = m; auto(); }"));
  assert.ok(n.includes("'cbd' + (n.reminder.mode === 'alarm' ? ' alm' : '')"));
  assert.ok(n.includes('if (!isP) import(\'./alarm-ui.js\')'));
});
test('mesin: mode alarm dibawa pengingat tugas, catatan, dan sub-tugas ke jembatan scheduleAlarm; notif tetap scheduleNotification', () => {
  const calls = []; const old = globalThis.AndroidAPI;
  globalThis.AndroidAPI = { scheduleNotification: (...x) => { calls.push(['notif', x[0]]); return 'scheduled'; }, scheduleAlarm: (...x) => { calls.push(['alarm', x[0]]); return 'scheduled'; }, cancelScheduledNotification() {}, requestNotificationPermission() {} };
  try {
    const NOW = Date.now(), at = NOW + 3600000;
    const task = { id: 't1', title: 'A', reminder: withMode({ at, repeat: 'once' }, 'alarm') };
    const note = { id: 'n1', title: 'B', reminder: withMode({ at, repeat: 'once' }, 'notif') };
    scheduleReminder('task', task, NOW); scheduleReminder('note', note, NOW);
    const sub = { id: 's1', title: 'C', reminder: withMode({ at, repeat: 'once' }, 'alarm') }; scheduleSubReminder(task, sub, NOW);
    assert.deepEqual(calls.map((c) => c[0]), ['alarm', 'notif', 'alarm']);
  } finally { if (old === undefined) delete globalThis.AndroidAPI; else globalThis.AndroidAPI = old; }
  assert.equal(normalizeReminder(withMode({ at: 1900000000000, repeat: 'once' }, 'alarm')).mode, 'alarm');
  assert.ok(!('mode' in normalizeReminder({ at: 1900000000000, repeat: 'once' })));
  assert.equal(cleanSubs([{ id: 'a1', title: 'x', done: false, reminder: withMode({ at: 1900000000000, repeat: 'once' }, 'alarm') }])[0].reminder.mode, 'alarm');
});
test('CSS: chip pembeda alarm memakai variabel tema; kurung seimbang', () => {
  const css = src('src/css/styles.css'); const i = css.indexOf('Rev 380 / AL3b-2'); const b = css.slice(i);
  for (const k of ['.am-slot:not(:empty)', '.alm-meta{', '.cbd.alm{']) assert.ok(b.includes(k), k);
  assert.ok(!/#[0-9a-fA-F]{6}/.test(b)); let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('tanpa perubahan SCHEMA/versi/native; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/); assert.ok(pk.scripts.test.includes('tests/rev381.test.mjs'));
});
