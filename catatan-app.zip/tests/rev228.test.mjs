// Rev 228: cadangan/pemulihan riwayat AI. Logika murni, tanpa HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as C from '../src/js/ai/cadangan.js';
import * as R from '../src/js/ai/ruang.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const msgs = (n) => Array.from({ length: n }, (_, i) => [{ role: 'user', content: 'tanya ' + i, t: '08:0' + (i % 10) }, { role: 'assistant', content: 'jawab **' + i + '**', t: '08:1' + (i % 10) }]).flat();
const rooms = [{ id: 'wabcde1', name: 'Konten', task: 'chat.general', at: 5, msgs: msgs(2) }, { id: 'wfghij2', name: 'Kosong', task: 'chat.general', at: 6, msgs: [] }, { id: '../bad', name: 'X', msgs: msgs(1) }];

test('backupName: riwayat-ai-TTTTBBHH-JJMM.json', () => { assert.equal(C.backupName(new Date(2026, 10, 12, 8, 5)), 'riwayat-ai-20261112-0805.json'); });
test('buildBackup lalu parseBackup: ruang kosong dan id berbahaya dibuang, pesan utuh', () => {
  const t = C.buildBackup(rooms, 99), o = JSON.parse(t); assert.equal(o.app, C.APP_ID); assert.deepEqual(Object.keys(o.msgs), ['wabcde1']);
  const p = C.parseBackup(t); assert.ok(p.ok); assert.equal(p.count, 1); assert.equal(p.msgCount, 4); assert.equal(p.rooms[0].name, 'Konten'); assert.equal(p.rooms[0].msgs[1].content, 'jawab **0**');
});
test('parseBackup menolak sampah dan menyaring isi', () => {
  for (const bad of ['', '   ', 'bukan json', '{}', '{"app":"lain"}', JSON.stringify({ app: C.APP_ID, idx: { list: [] }, msgs: {} }), JSON.stringify({ app: C.APP_ID, idx: { list: [{ id: 'wabcde1', name: 'A' }] }, msgs: { wabcde1: [] } })]) assert.equal(C.parseBackup(bad).ok, false, bad);
  assert.equal(C.parseBackup('x'.repeat(C.FILE_MAX + 1)).ok, false);
  const t = JSON.stringify({ app: C.APP_ID, idx: { list: [{ id: 'wabcde1', name: 'A', task: 'aneh' }] }, msgs: { wabcde1: [{ role: 'system', content: 'x' }, { role: 'user', content: 'halo' }, { role: 'assistant', content: 'hai' }, { role: 'user', content: '' }] } });
  const p = C.parseBackup(t); assert.ok(p.ok); assert.equal(p.rooms[0].task, 'chat.general'); assert.deepEqual(p.rooms[0].msgs.map((m) => m.role), ['user', 'assistant']);
});
test('mergeRestore: hanya menambah, id baru, nama unik, batas MAX_WS', () => {
  const idx = R.defaultIndex(1, () => 0.5), p = C.parseBackup(C.buildBackup([{ id: 'wabcde1', name: 'Umum', task: 'chat.general', at: 5, msgs: msgs(1) }]));
  const m = C.mergeRestore(idx, p.rooms, 10, () => 0.2); assert.equal(m.idx.list.length, 2); assert.equal(m.idx.active, idx.active); assert.equal(m.idx.list[1].name, 'Umum 2'); assert.notEqual(m.idx.list[1].id, idx.list[0].id); assert.ok(R.ID_RE.test(m.added[0].id)); assert.equal(m.skipped, 0);
  let full = idx; for (let i = 0; i < R.MAX_WS - 1; i++) full = R.addWs(full, 'R' + i, 100 + i, () => i / 40).idx;
  const m2 = C.mergeRestore(full, p.rooms); assert.equal(m2.added.length, 0); assert.equal(m2.skipped, 1); assert.equal(m2.idx, full);
});
test('obrolan.js: tombol Cadangkan/Pulihkan riwayat di laci, lewat dialog konfirmasi; modul tanpa data aplikasi', () => {
  const o = src('src/js/ai/obrolan.js'), c = src('src/js/ai/cadangan.js');
  assert.match(o, /'Cadangkan riwayat'/); assert.match(o, /'Pulihkan riwayat'/); assert.match(o, /dlg\(\{ title: 'Cadangkan riwayat AI\?'/); assert.match(o, /dlg\(\{ title: 'Pulihkan riwayat AI\?'/);
  const kode = c.split('\n').filter((l) => !l.trim().startsWith('//')).join('\n'); assert.doesNotMatch(kode, /innerHTML|localStorage|\.priv\b|loadConn|passcode/i);
});
