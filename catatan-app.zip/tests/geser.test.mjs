import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const js = readFileSync(new URL('../src/js/notes.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
let n = 0; const ok = (m, f) => { f(); n++; console.log('ok - ' + m); };
ok('Rev 30b: Ukuran dipicu dari bindBar (bukan click yang mati karena touchstart preventDefault)', () => {
  assert.ok(!/fsBtn\.addEventListener\('click'/.test(js));
  assert.match(js, /if \(c === 'font-size'\) \{ toggleFs\(\); return; \}/);
  assert.match(js, /!fsBtn\.contains\(e\.target\)/);
});
ok('Rev 30b: bilah punya geser sendiri; tombol format bereaksi saat jari diangkat tanpa bergeser', () => {
  assert.match(js, /const bindBar = /);
  assert.match(js, /Math\.abs\(dx\) > 8/);
  assert.match(js, /classList\.contains\('fmt'\)/);
  assert.match(js, /bar\.scrollLeft = st\.left - dx/);
});
ok('Rev 30b: CSS 4,5 tombol terlihat, bintang menempel di kiri, bilah bisa digulir', () => {
  assert.match(css, /\.fbar\.open\{overflow-x:auto/);
  assert.match(css, /\.fbar\.open button\.fmt\{flex:0 0 calc\(\(100% - 54px\) \/ 4\.5\)[^}]*\}/);
  assert.match(css, /\.fbar\.open button\.star\{position:sticky/);
});
ok('Rev 30b: tanpa perubahan data: SCHEMA 8 sejak Rev 60', () => { assert.match(readFileSync(new URL('../src/js/storage.js', import.meta.url), 'utf8'), /SCHEMA\s*=\s*22/); });
console.log(n + ' tes lulus (geser)');
