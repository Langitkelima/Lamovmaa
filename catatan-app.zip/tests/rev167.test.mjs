// Rev 167 / Q10 tahap 2 (Cari data bagian 3): VLOOKUP(nilai; rentang; kolom; [cocok]). HLOOKUP + audit = Rev 168.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { argHint } from '../src/js/rumus-bantu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 9, 0, 0).getTime();
function mk(grid) { const t = L.newTab('T', 12); grid.forEach((row, ri) => row.forEach((v, ci) => { if (v === undefined || v === null) return; L.setCell(t, t.rows[ri].id, t.cols[ci].id, { v }); })); return t; }
function at(grid, f) { const t = mk(grid); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cH = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cH'); }
const HARGA = [['apel', 10000, 'A'], ['jeruk', 20000, 'B'], ['pisang', 30000, 'C'], ['kiwi', 40000, 'D']];
const TARIF = [[0, 'Rendah'], [100, 'Sedang'], [500, 'Tinggi']]; // kolom pertama naik, cocok perkiraan

test('VLOOKUP sama persis (cocok FALSE/0/kosong): kolom ke-n, huruf besar/kecil, wildcard, #N/A', () => {
  assert.equal(at(HARGA, '=VLOOKUP("pisang";A1:C4;2;FALSE)'), 30000); assert.equal(at(HARGA, '=VLOOKUP("PISANG";A1:C4;3;0)'), 'C'); assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;1;FALSE)'), 'kiwi'); assert.equal(at(HARGA, '=VLOOKUP("pis*";A1:C4;2;FALSE)'), 30000);
  assert.equal(at(HARGA, '=VLOOKUP("jeruk";A1:C4;2;)'), 20000); // argumen kosong = FALSE
  assert.equal(at(HARGA, '=VLOOKUP("durian";A1:C4;2;FALSE)').e, '#N/A'); assert.equal(at([['a', 1], ['a', 2]], '=VLOOKUP("a";A1:B2;2;FALSE)'), 1); // kembar: baris pertama
  assert.equal(at([[10, 'x'], ['10', 'y']], '=VLOOKUP(10;A1:B2;2;FALSE)'), 'x'); assert.equal(at([['10', 'y']], '=VLOOKUP(10;A1:B1;2;FALSE)').e, '#N/A'); // teks "10" bukan angka 10
  assert.equal(at(HARGA, '=VLOOKUP("jeruk";B1:C4;1;FALSE)').e, '#N/A'); // pencarian hanya di kolom PERTAMA rentang (B), bukan A
});
test('VLOOKUP perkiraan (cocok TRUE / dihilangkan): terbesar <= nilai di kolom pertama terurut', () => {
  assert.equal(at(TARIF, '=VLOOKUP(250;A1:B3;2)'), 'Sedang'); assert.equal(at(TARIF, '=VLOOKUP(250;A1:B3;2;TRUE)'), 'Sedang'); assert.equal(at(TARIF, '=VLOOKUP(500;A1:B3;2)'), 'Tinggi'); assert.equal(at(TARIF, '=VLOOKUP(99,9;A1:B3;2)'), 'Rendah'); assert.equal(at(TARIF, '=VLOOKUP(99999;A1:B3;2)'), 'Tinggi');
  assert.equal(at(TARIF, '=VLOOKUP(-5;A1:B3;2)').e, '#N/A'); assert.equal(at(TARIF, '=VLOOKUP(250;A1:B3;2;1)'), 'Sedang'); assert.equal(at(TARIF, '=VLOOKUP(250;A1:B3;2;0)').e, '#N/A');
  assert.equal(at([['a', 1], ['c', 2], ['e', 3]], '=VLOOKUP("d";A1:B3;2)'), 2); assert.equal(at([[10, 'x'], ['teks', 'y'], [30, 'z']], '=VLOOKUP(35;A1:B3;2)'), 'z'); // sel beda jenis dilewati
});
test('VLOOKUP kolom: 1 = kolom pertama, 0/negatif #VALUE!, melebihi lebar #REF!, galat menjalar, nilai tunggal', () => {
  assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;3;FALSE)'), 'D'); assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;"2";FALSE)'), 40000); assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;2,9;FALSE)'), 40000); // pecahan dipotong
  assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;0;FALSE)').e, '#VALUE!'); assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;-1;FALSE)').e, '#VALUE!'); assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;4;FALSE)').e, '#REF!'); assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;"x";FALSE)').e, '#VALUE!');
  assert.equal(at(HARGA, '=VLOOKUP(1/0;A1:C4;2;FALSE)').e, '#DIV/0!'); assert.equal(at(HARGA, '=VLOOKUP("kiwi";A1:C4;2;"x")').e, '#VALUE!'); assert.equal(at(HARGA, '=VLOOKUP(A1:A2;A1:C4;2;FALSE)').e, '#VALUE!'); assert.equal(at([], '=VLOOKUP(5;5;1;FALSE)'), 5); assert.equal(at([], '=VLOOKUP(5;5;2;FALSE)').e, '#REF!');
  const t = mk([['a', 1], ['b', 2]]); t.rows[0].cells.cB = { fx: R.a1ToStored('=1/0', t).fx }; t.rows[0].cells.cH = { fx: R.a1ToStored('=VLOOKUP("a";A1:B2;2;FALSE)', t).fx }; t.rows[1].cells.cH = { fx: R.a1ToStored('=VLOOKUP("b";A1:B2;2;FALSE)', t).fx };
  const c = R.computeTab(t, { now: NOW }); assert.equal(c.get('r1', 'cH').e, '#DIV/0!'); assert.equal(c.get('r2', 'cH'), 2); // hanya galat di sel yang diambil
});
test('VLOOKUP dipakai nyata: IFERROR, hitung harga x jumlah, TEXT, dan kunci diketik dari sel lain; urutan hitung dan siklus', () => {
  assert.equal(at(HARGA, '=IFERROR(VLOOKUP("durian";A1:C4;2;FALSE);0)'), 0); assert.equal(at(HARGA, '=VLOOKUP("jeruk";A1:C4;2;FALSE)*3'), 60000); assert.equal(at(HARGA, '="Harga: "&TEXT(VLOOKUP("jeruk";A1:C4;2;FALSE);"Rp #.##0")'), 'Harga: Rp 20.000');
  assert.equal(at([['kiwi', 0], ['apel', 10], ['kiwi', 40]], '=VLOOKUP(A1;A2:B3;2;FALSE)'), 40); // kunci dari sel
  const t = mk([['k', null], ['z', 7]]); t.rows[0].cells.cB = { fx: R.a1ToStored('=B2*2', t).fx }; t.rows[0].cells.cH = { fx: R.a1ToStored('=VLOOKUP("k";A1:B2;2;FALSE)', t).fx };
  assert.equal(R.computeTab(t, { now: NOW }).get('r1', 'cH'), 14); // B1 dihitung dulu
  const u = mk([['a', null]]); u.rows[0].cells.cB = { fx: R.a1ToStored('=VLOOKUP("a";A1:B2;2;FALSE)', u).fx }; assert.equal(R.computeTab(u, { now: NOW }).get('r1', 'cB').e, '#CIRC!');
});
test('MATCH tidak berubah setelah pemisahan lookupPos; daftar fungsi 51; modul murni; tes terdaftar', () => {
  assert.equal(at([['a'], ['b'], ['c']], '=MATCH("b";A1:A3;0)'), 2); assert.equal(at([[10], [20], [30]], '=MATCH(25;A1:A3)'), 2); assert.equal(at([[30], [20], [10]], '=MATCH(25;A1:A3;-1)'), 1);
  const names = R.FUNCTION_LIST.map((f) => f.name); assert.equal(names.length, 53); const f = R.FUNCTION_LIST.find((x) => x.name === 'VLOOKUP'); assert.ok(f && f.sig.startsWith('VLOOKUP(') && f.ket.length > 3);
  assert.equal(argHint('VLOOKUP', 9).parts.length, 4); assert.deepEqual(R.suggestFunctions('vl').map((x) => x.name), ['VLOOKUP']); assert.ok(names.includes('HLOOKUP'));
  const s = src('src/js/rumus.js'); assert.ok(!/^\s*import\s/m.test(s)); assert.ok(!/document\.|window\.|localStorage|eval\(|new Function/.test(s)); assert.ok(src('package.json').includes('tests/rev167.test.mjs'));
});
