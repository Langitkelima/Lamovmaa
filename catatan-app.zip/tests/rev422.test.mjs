// Rev 422: Worker menerima asal tambahan lewat variabel ALLOWED_ORIGINS (untuk versi web SY4). Tes Node, bukan Cloudflare nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs'; import W from '../backend/cloudflare/worker.mjs';
const opt = (origin, env) => W.fetch(new Request('https://w.example/', { method: 'OPTIONS', headers: { Origin: origin } }), env);
test('ALLOWED_ORIGINS: asal https valid diizinkan, selain itu tidak; tanpa variabel = perilaku lama', async () => {
  assert.equal((await opt('https://catatan.pages.dev', { ALLOWED_ORIGINS: 'https://catatan.pages.dev, https://x.id:8443' })).headers.get('Access-Control-Allow-Origin'), 'https://catatan.pages.dev');
  assert.equal((await opt('https://x.id:8443', { ALLOWED_ORIGINS: 'https://catatan.pages.dev,https://x.id:8443' })).headers.get('Access-Control-Allow-Origin'), 'https://x.id:8443');
  assert.equal((await opt('https://jahat.com', { ALLOWED_ORIGINS: 'https://catatan.pages.dev' })).headers.get('Access-Control-Allow-Origin'), null);
  assert.equal((await opt('http://catatan.pages.dev', { ALLOWED_ORIGINS: 'http://catatan.pages.dev, *, https://a.com/jalur' })).headers.get('Access-Control-Allow-Origin'), null);
  assert.equal((await opt('https://catatan.pages.dev', {})).headers.get('Access-Control-Allow-Origin'), null);
  assert.equal((await opt('https://localhost', {})).headers.get('Access-Control-Allow-Origin'), 'https://localhost');
});
test('terdaftar, versi dan SCHEMA tetap', () => { assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /tests\/rev422\.test\.mjs/); });
