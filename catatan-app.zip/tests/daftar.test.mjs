// Tes Rev 28: daftar bernomor + ekspor tabel/gambar (persiapan tanpa tampilan import).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as E from '../src/js/export.js';

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const measure = (s, st) => s.length * st.size * 0.5 * (st.b ? 1.1 : 1);
const O = { width: 600, padX: 40, size: 30, titleSize: 44, measure, pageH: 900, padTop: 40, padBottom: 40 };

t('panel Langit punya tombol Nomor di samping Poin; perintah masuk status aktif', () => {
  const nt = src('../src/js/notes.js');
  const p = nt.indexOf("'data-cmd': 'insertUnorderedList'");
  const q = nt.indexOf("'data-cmd': 'insertOrderedList'");
  const c = nt.indexOf("'data-cmd': 'todo'", q);
  assert.ok(p >= 0 && q > p && c > q);
  assert.ok(nt.includes("'aria-label': 'Nomor'") && nt.includes("h('small', {}, 'Nomor')"));
  assert.ok(nt.includes("'insertOrderedList']"));
});
t('CSS daftar bernomor memakai angka desimal dan indentasi', () => {
  const css = src('../src/css/styles.css');
  assert.match(css, /\.ed2 ol\{[^}]*padding-left:[^}]*list-style-type:decimal/);
  assert.ok(css.includes('.fbar .numfmt'));
});
t('parser daftar bernomor: urut, mulai ulang dari 1, dan bertingkat', () => {
  const b = E.parseNoteHtml('<ol><li>Satu</li><li>Dua<ol><li>Dua satu</li></ol></li></ol><ol><li>Mulai lagi</li></ol>');
  assert.deepEqual(b.filter((x) => x.kind === 'ol').map((x) => [x.num, x.depth]), [[1,0],[2,0],[1,1],[1,0]]);
  assert.equal(E.blocksToText('', b), '1. Satu\n2. Dua\n  1. Dua satu\n1. Mulai lagi');
});
t('parser tabel: baris/sel, header row/column, format inline, atribut tanda kutip tunggal', () => {
  const html = `<p>Sebelum</p><div class="kt" contenteditable="false"><div class="kt-scroll"><table class='kt-t' data-hr='1' data-hc='1'><tbody><tr><td><div><b>Nama</b></div></td><td><div>Jumlah</div></td></tr><tr><td><div>Apel</div></td><td><div><i>2</i></div></td></tr></tbody></table></div></div><p>Sesudah</p>`;
  const b = E.parseNoteHtml(html), table = b.find((x) => x.kind === 'table');
  assert.ok(table); assert.equal(table.headerRow, true); assert.equal(table.headerCol, true);
  assert.equal(table.rows.length, 2); assert.deepEqual(table.rows.map((r) => r.length), [2,2]);
  assert.equal(table.rows[0][0].runs[0].b, true); assert.equal(table.rows[1][1].runs[0].i, true);
  assert.deepEqual(b.filter((x) => x.kind === 'p').map((x) => x.runs.map((r) => r.t).join('')), ['Sebelum','Sesudah']);
});
t('teks biasa: setiap baris tabel dipisah | dan gambar menjadi [gambar]', () => {
  const b = E.parseNoteHtml('<table data-hr="1"><tr><td><b>Nama</b></td><td>Jumlah</td></tr><tr><td>Apel</td><td>2</td></tr></table><figure class="ki" data-kimg="abcde12345" data-w="1280" data-h="960"></figure>');
  assert.equal(E.blocksToText('Stok', b), 'Stok\n\nNama | Jumlah\nApel | 2\n[gambar]');
});
t('layout tabel: kolom proporsional mengisi lebar, judul tebal, teks dibungkus, baris siap dipaginasi', () => {
  const b = E.parseNoteHtml('<table data-hr="1"><tr><td>Nama</td><td>Catatan panjang sekali yang harus dibungkus menjadi beberapa baris di kolom ini</td></tr><tr><td>Apel</td><td>2</td></tr></table>');
  const ls = E.layoutDoc({ title: '', blocks: b }, O), rows = ls.filter((x) => x.kind === 'tableRow');
  assert.equal(rows.length, 2);
  assert.ok(Math.abs(rows[0].cells.reduce((sum, c) => sum + c.w, 0) - (O.width - 2 * O.padX)) < 0.01);
  assert.ok(rows[0].cells[0].header && rows[0].cells[1].header);
  assert.ok(rows[0].cells[0].lines[0][0].b);
  assert.ok(rows[0].cells[1].lines.length > 1);
  const pages = E.paginate(ls, { pageH: 500, padTop: 40, padBottom: 40 });
  assert.ok(pages.length >= 1 && pages.flatMap((p) => p.lines).filter((x) => x.kind === 'tableRow').length === 2);
});
t('gambar: hanya figure.ki berdimensi sah dipakai; layout mengikuti rasio tanpa membuka berkas', () => {
  const b = E.parseNoteHtml('<figure class="ki" data-kimg="abcde12345" data-w="1280" data-h="960"></figure><figure class="lain" data-w="10" data-h="10"></figure><figure class="ki" data-w="0" data-h="2"></figure>');
  assert.deepEqual(b, [{ kind: 'image', id: 'abcde12345', width: 1280, height: 960, scale: 100, align: 'c', float: false }]); // Rev 46: scale = data-s (bawaan 100); Rev 47: align = data-a (bawaan c)
  const l = E.layoutDoc({ title: '', blocks: b }, O).find((x) => x.kind === 'image');
  assert.ok(l); assert.equal(l.sourceWidth, 1280); assert.equal(l.sourceHeight, 960);
  assert.ok(Math.abs(l.w / l.h - 1280 / 960) < 0.01);
  assert.equal(E.blocksToText('', b), '[gambar]');
});
t('PDF/JPG punya titik sambung gambar opsional; belum memuat byte gambar di Rev 28', () => {
  const sh = src('../src/js/share.js');
  assert.ok(sh.includes('images = null') && sh.includes('images.get(l.id)') && sh.includes('g.drawImage(img'));
  assert.ok(sh.includes("g.fillText('[gambar]'"));
  assert.ok(!sh.includes('Filesystem.readFile') && !sh.includes('Directory.Data'));
});
t('data dan native tidak berubah; SCHEMA 8 sejak Rev 60', () => {
  assert.match(src('../src/js/storage.js'), /SCHEMA = 22/);
  assert.ok(src('../src/js/notes.js').includes('figure.ki')); // Rev 45 / G3: editor kini menyisipkan dan menampilkan blok gambar.
});
console.log(`\n${n} tes lulus (Rev 28)`);
