// Rev 118 / U7a-2b-3: seret lebar kolom lembar kerja
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { dragWidth, colLeft, gridSize, NUM_W } from '../src/js/lembar-ui.js'; import * as L from '../src/js/lembar.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
test('dragWidth: tambah geseran, bulat, dibatasi 40..320, masukan rusak aman', () => {
  assert.equal(dragWidth(96, 30), 126); assert.equal(dragWidth(96, -30.4), 66); assert.equal(dragWidth(96.4, 0.4), 97);
  assert.equal(dragWidth(96, -500), L.COL_W_MIN); assert.equal(dragWidth(96, 900), L.COL_W_MAX);
  assert.equal(dragWidth('x', 'y'), L.COL_W_DEF); assert.equal(dragWidth(NaN, 10), L.COL_W_DEF + 10); assert.equal(dragWidth(96, undefined), 96);
  assert.equal(dragWidth(10, 0), L.COL_W_MIN); assert.equal(dragWidth(999, 0), L.COL_W_MAX);
});
test('seret lewat setColWidth: tersimpan di model, colLeft/gridSize ikut, kolom lain tetap', () => {
  const t = L.newTab('A', 5), before = t.cols.map((c) => c.w);
  assert.equal(L.setColWidth(t, t.cols[1].id, dragWidth(t.cols[1].w, 50)), true); assert.equal(t.cols[1].w, 146);
  assert.equal(L.setColWidth(t, t.cols[1].id, 146), false); // tanpa perubahan = false
  assert.equal(colLeft(t, 2), before[0] + 146); assert.equal(gridSize(t).w, NUM_W + before.reduce((a, b) => a + b, 0) + 50);
  assert.deepEqual(t.cols.filter((_, i) => i !== 1).map((c) => c.w), before.filter((_, i) => i !== 1));
  const sh = L.newSheet({ name: 'X' }); L.setColWidth(sh.tabs[0], sh.tabs[0].cols[0].id, 200); assert.ok(L.fitsLimit(sh));
  assert.equal(L.cleanSheet(JSON.parse(JSON.stringify(sh))).tabs[0].cols[0].w, 200); // lolos pembersihan penyimpanan
});
// Rev 253 / S4: pemanggilan setColWidth kini per kolom dalam `rz.set` (satu kolom bila tidak ada seleksi kolom penuh)
test('kontrak kode: pegangan, pointer capture, simpan sekali saat lepas, batal memulihkan, klik pegangan tidak memilih kolom', () => {
  const ui = src('js/lembar-ui.js');
  for (const k of ["'lz-rz'", 'setPointerCapture', 'releasePointerCapture', "addEventListener('pointerdown', rzDown)", "addEventListener('pointercancel'", "addEventListener('lostpointercapture'", 'L.setColWidth(tab, it.id, w)', 'L.setColWidth(tab, it.id, it.w)', 'dragWidth(rz.w']) assert.ok(ui.includes(k), k);
  const mv = ui.slice(ui.indexOf('const rzMove'), ui.indexOf('const rzEnd')); assert.ok(!/touched\(|onChange|buildHead\(/.test(mv), 'saat menyeret: tidak menyimpan dan tidak membangun ulang kepala');
  const en = ui.slice(ui.indexOf('const rzEnd'), ui.indexOf("headRow.addEventListener('pointerdown'")); assert.equal((en.match(/touched\(\)/g) || []).length, 1);
  assert.ok(ui.indexOf('commit(); // simpan isian sel lama dulu') > ui.indexOf('const rzDown')); assert.match(ui, /closest\('\.lz-rz'\)\) e\.stopPropagation\(\)/);
  assert.ok(!/localStorage|persist\(|eval\(|new Function|Capacitor/.test(ui));
});
test('CSS pegangan: touch-action none, area sentuh >= 22px, versi 0.3.121', () => {
  const css = src('css/styles.css'); assert.match(css, /Rev 118 \/ U7a-2b-3/);
  const blk = css.slice(css.indexOf('Rev 118 / U7a-2b-3')); assert.match(blk, /\.lz-rz\{[^}]*touch-action:none/); assert.match(blk, /\.lz-rz\{[^}]*width:22px/);
  assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /"version": "0\.3\.121"/); assert.match(src('js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
