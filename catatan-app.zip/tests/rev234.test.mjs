// Rev 234 / Tahap 7a: model data Proyek (SCHEMA 19), migrasi normalize(), cadangan, tautan, kemajuan. Tanpa UI.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as C from '../src/js/proyek.js';
import * as A from '../src/js/proyek-alat.js';
const P = { ...C, ...A };
import * as S from '../src/js/storage.js';
import { replaceData } from '../src/js/logic.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('cleanProject: nama dan id wajib; batas panjang; status tak dikenal = aktif; due opsional', () => {
  assert.equal(P.cleanProject(null), null); assert.equal(P.cleanProject([]), null);
  assert.equal(P.cleanProject({ id: '', name: 'x' }), null); assert.equal(P.cleanProject({ id: 'a', name: '   ' }), null);
  const p = P.cleanProject({ id: ' a ', name: ' ' + 'n'.repeat(80), desc: 'd'.repeat(900), status: 'aneh', at: 5.9, due: -1, tasks: 'x', notes: null });
  assert.equal(p.id, 'a'); assert.equal(p.name.length, P.MAX_NAME); assert.equal(p.desc.length, P.MAX_DESC);
  assert.equal(p.status, 'aktif'); assert.equal(p.at, 5); assert.ok(!('due' in p)); assert.deepEqual([p.tasks, p.notes], [[], []]);
  assert.equal(P.cleanProject({ id: 'b', name: 'B', status: 'arsip', due: 99 }).due, 99);
});
test('cleanProjects: id ganda dan entri rusak dibuang; maks. 30; bukan larik = []', () => {
  assert.deepEqual(P.cleanProjects(undefined), []); assert.deepEqual(P.cleanProjects({}), []);
  const r = P.cleanProjects([{ id: 'a', name: 'A' }, { id: 'a', name: 'dobel' }, 5, { id: 'b' }, { id: 'c', name: 'C' }]);
  assert.deepEqual(r.map((x) => x.id), ['a', 'c']);
  const many = Array.from({ length: 40 }, (_, i) => ({ id: 'p' + i, name: 'P' + i }));
  assert.equal(P.cleanProjects(many).length, P.MAX_PROJECTS);
});
test('tautan: id unik, bukan teks dibuang, maks. 100', () => {
  const p = P.cleanProject({ id: 'a', name: 'A', tasks: ['t1', 't1', 7, '', 't2'], notes: Array.from({ length: 150 }, (_, i) => 'n' + i) });
  assert.deepEqual(p.tasks, ['t1', 't2']); assert.equal(p.notes.length, P.MAX_LINKS);
  assert.equal(P.toggleProjectLink(p, 'tasks', 't3'), 'added'); assert.equal(P.toggleProjectLink(p, 'tasks', 't3'), 'removed');
  assert.equal(P.toggleProjectLink(p, 'notes', 'baru'), 'full'); assert.equal(P.toggleProjectLink(p, 'x', 'a'), 'bad'); assert.equal(P.toggleProjectLink(p, 'tasks', ''), 'bad');
});
test('newProject/addProject/removeProject', () => {
  assert.equal(P.newProject('   ', () => 'z'), null);
  const p = P.newProject('Renovasi', () => 'p1', 1000); assert.deepEqual([p.id, p.name, p.status, p.at], ['p1', 'Renovasi', 'aktif', 1000]);
  const list = []; assert.equal(P.addProject(list, p), true); assert.equal(P.addProject(list, p), false);
  assert.equal(P.removeProject(list, 'nope'), false); assert.equal(P.removeProject(list, 'p1'), true); assert.deepEqual(list, []);
});
test('storage: SCHEMA 19; data kosong punya projects []; data v18 tanpa projects dimigrasi', () => {
  assert.equal(S.SCHEMA, 22); assert.deepEqual(S.emptyData().projects, []);
  const old = S.normalize({ version: 18, habits: [], tasks: [{ id: 't1', title: 'A', done: false, scope: 'fokus' }], notes: [], priv: [], trash: [], settings: {} });
  assert.deepEqual(old.projects, []); assert.equal(old.version, 22);
});
test('normalize: tautan ke tugas/catatan yang tidak ada dibuang; Catatan Privat dan sampah tidak pernah tertaut; cadangan JSON bertahan', () => {
  const d = { habits: [], tasks: [{ id: 't1', title: 'A', done: true, scope: 'fokus' }, { id: 't2', title: 'B', done: false, scope: 'fokus' }],
    notes: [{ id: 'n1', title: 'x', html: '' }], priv: [{ id: 'pv1', title: 'rahasia', html: '' }],
    trash: [{ kind: 'note', item: { id: 'n9', title: 'buang', html: '' } }], settings: {},
    projects: [{ id: 'p1', name: 'Proyek', tasks: ['t1', 'hilang'], notes: ['n1', 'pv1', 'n9'] }] };
  const n = S.normalize(d);
  assert.deepEqual(n.projects[0].tasks, ['t1']); assert.deepEqual(n.projects[0].notes, ['n1']);
  const back = S.importJSON(S.exportJSON(n)); assert.equal(back.ok, true); assert.deepEqual(back.data.projects, n.projects);
  assert.deepEqual(P.projectProgress(n, n.projects[0]), { total: 1, done: 1, pct: 100 });
});
test('projectProgress: hanya tugas yang ada; tanpa tugas = 0', () => {
  const data = { tasks: [{ id: 'a', done: true }, { id: 'b', done: false }, { id: 'c', done: false }, { id: 'd', done: true }] };
  assert.deepEqual(P.projectProgress(data, { tasks: ['a', 'b', 'c', 'gone'] }), { total: 3, done: 1, pct: 33 });
  assert.deepEqual(P.projectProgress(data, { tasks: [] }), { total: 0, done: 0, pct: 0 }); assert.deepEqual(P.projectProgress(null, null), { total: 0, done: 0, pct: 0 });
});
test('replaceData: pulihkan cadangan mengganti proyek; cadangan lama tanpa projects = []', () => {
  const t = { projects: [{ id: 'lama' }] }; const base = S.emptyData();
  replaceData(t, { ...base, projects: [{ id: 'baru', name: 'B', tasks: [], notes: [] }] }); assert.deepEqual(t.projects.map((x) => x.id), ['baru']);
  const { projects, ...tanpa } = base; replaceData(t, tanpa); assert.deepEqual(t.projects, []);
});
test('proyek.js murni (tanpa impor/DOM); belum dipakai UI/AI; versi 0.3.121; tes terdaftar', () => {
  for (const f of ['proyek.js', 'proyek-alat.js']) assert.doesNotMatch(src('src/js/' + f), /document\.|window\.|localStorage/);
  assert.doesNotMatch(src('src/js/proyek.js'), /^\s*import\s/m); assert.match(src('src/js/proyek-alat.js'), /^import \{[^}]*\} from '\.\/proyek\.js';/m);
  assert.doesNotMatch(src('src/js/storage.js'), /proyek-alat/); // alat tidak ikut startup
  for (const f of ['main.js', 'notes.js', 'settings.js', 'todo.js']) assert.doesNotMatch(src('src/js/' + f), /proyek(-alat)?\.js/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev234\.test\.mjs/);
});
