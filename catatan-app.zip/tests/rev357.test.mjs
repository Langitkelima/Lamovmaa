// Rev 357 / PART O5 (penutup Paket OCR): tanpa perubahan kode aplikasi. Mengunci keberadaan audit penutup, bagian uji HP, dan dokumen rencana ke depan.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, existsSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('audit penutup ada dan memeriksa Privat sungguhan, riwayat token, foto 108 MP, berkas > 30 MB, bukan gambar', () => {
  assert.ok(existsSync(new URL('../tools/audit_penutup_357.py', import.meta.url))); const a = src('tools/audit_penutup_357.py');
  for (const k of ['9000, 12000', 'Simpan PIN', "'ocr'", '31 * 1024 * 1024', 'catatan.txt', 'kelimaa_ai_riwayat', 'ocr-ui.js']) assert.ok(a.includes(k), k);
});
test('UJI_HP_RILIS: bagian BO memuat butir O5 (13-15); PROMPT memuat bagian 35 rencana ke depan dan status 33.16', () => {
  const u = src('UJI_HP_RILIS.md'), b = u.slice(u.indexOf('## BO.')); for (const k of ['\n13. ', '\n14. ', '\n15. ']) assert.ok(b.includes(k), k);
  const p = src('PROMPT_SERAH_TERIMA.md'); assert.ok(p.includes('## 35. RENCANA KE DEPAN')); assert.ok(p.includes('33.16 STATUS PAKET OCR (Rev 357)'));
});
test('kode aplikasi tidak berubah: versi 0.3.121, SCHEMA 22, tes terdaftar', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/); assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev357\.test\.mjs/);
});
