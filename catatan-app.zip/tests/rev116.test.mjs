// Rev 116 / U7a-2b-1: isi sel, Tambah baris 10/100, Hapus lembar kerja
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { parseInput } from '../src/js/lembar-ui.js'; import * as L from '../src/js/lembar.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
test('parseInput: angka, koma, teks, kosong, batas', () => {
  assert.equal(parseInput('12'), 12); assert.equal(parseInput(' 3,5 '), 3.5); assert.equal(parseInput('-4.25'), -4.25);
  assert.equal(parseInput('Halo'), 'Halo'); assert.equal(parseInput('=A1+1'), '=A1+1'); assert.equal(parseInput('007a'), '007a');
  assert.equal(parseInput(''), null); assert.equal(parseInput('   '), null); assert.equal(parseInput(null), null);
  assert.equal(parseInput('x'.repeat(5000)).length, L.MAX_CELL); assert.equal(typeof parseInput('1234567890123456789'), 'string');
});
test('setCell lewat parseInput: isi, ubah, kosongkan sel jarang', () => {
  const t = L.newTab('A', 5); const r = t.rows[1].id, c = t.cols[2].id;
  assert.ok(L.setCell(t, r, c, { v: parseInput('42') })); assert.equal(L.cellAt(t, 1, 2).v, 42);
  assert.ok(L.setCell(t, r, c, { v: parseInput('') })); assert.equal(L.cellAt(t, 1, 2), null); assert.deepEqual(t.rows[1].cells, {});
});
test('addRows 10/100 sampai batas 500 dan fitsLimit', () => {
  const sh = L.newSheet({ name: 'X' }), t = sh.tabs[0];
  assert.equal(L.addRows(t, 10), 10); assert.equal(t.rows.length, 40); assert.equal(L.addRows(t, 100), 100);
  assert.equal(L.addRows(t, 500), 360); assert.equal(t.rows.length, 500); assert.equal(L.addRows(t, 10), 0); assert.ok(L.fitsLimit(sh));
});
test('kontrak kode: edit lewat lembar.js, callback simpan/hapus, konfirmasi hapus', () => {
  const ui = src('js/lembar-ui.js');
  assert.match(ui, /L\.setCell\(tab, row\.id, col\.id/); assert.match(ui, /L\.fitsLimit\(sheet\)/); assert.match(ui, /L\.addRows\(tab, n\)/);
  assert.ok(ui.indexOf('commit(); // simpan') < ui.indexOf('sel = { r, c: sel ? sel.c : 0 }'));
  assert.match(ui, /dlg\(\{ title: 'Hapus lembar kerja\?'/); assert.ok(!/localStorage|persist\(|eval\(|new Function|Capacitor/.test(ui));
  const st = src('js/settings.js'); assert.match(st, /onChange: \(\) => ctx\.persist\(\)/); assert.match(st, /delete data\.sheets\[sh\.id\]/);
});
test('versi 0.3.121 dan CSS', () => {
  assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /"version": "0\.3\.121"/); assert.match(src('css/styles.css'), /Rev 116 \/ U7a-2b-1/); assert.match(src('js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
