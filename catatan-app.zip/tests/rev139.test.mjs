// Rev 139 / U9a-1: alat lembar kerja MURNI (urutkan, CSV/TSV, cari-ganti, isi seri). Belum ada UI (U9a-2).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import * as A from '../src/js/lembar-alat.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 9, 14, 30, 0).getTime();
function mk(grid, rows = 12) {
  const t = L.newTab('T', rows);
  grid.forEach((row, ri) => row.forEach((v, ci) => { if (v === undefined || v === null) return; L.setCell(t, t.rows[ri].id, t.cols[ci].id, { v }); }));
  return t;
}
const col = (t, j, n = t.rows.length) => { const o = []; for (let i = 0; i < n; i++) { const c = t.rows[i].cells[t.cols[j].id]; o.push(c ? (c.v !== undefined ? c.v : c.fx) : undefined); } return o; };

test('urutkan: angka, teks (tanpa beda huruf, urut Indonesia), kosong selalu di akhir, stabil, Z-A', () => {
  const t = mk([[3, 'c'], [1, 'a'], [undefined, 'z'], [2, 'b'], [1, 'a2']]);
  const r = A.sortTab(t, 0, 'asc', { header: false }); assert.equal(r.ok, true);
  assert.deepEqual(col(t, 0, 5), [1, 1, 2, 3, undefined]); assert.deepEqual(col(t, 1, 5), ['a', 'a2', 'b', 'c', 'z']); // stabil: a sebelum a2
  A.sortTab(t, 0, 'desc', { header: false }); assert.deepEqual(col(t, 0, 5), [3, 2, 1, 1, undefined]); // kosong tetap terakhir pada Z-A
  const s = mk([['pisang'], ['Apel'], ['jeruk'], [5], [true]]); A.sortTab(s, 0, 'asc', { header: false });
  assert.deepEqual(col(s, 0, 5), [5, 'Apel', 'jeruk', 'pisang', true]); // angka < teks < boolean
});
test('urutkan: judul (baris 1) dilewati otomatis, bisa dipaksa, baris utuh ikut pindah termasuk gaya', () => {
  const t = mk([['Nama', 'Nilai'], ['x', 30], ['y', 10], ['z', 20]]); L.setCell(t, 'r3', 'cB', { s: { b: true } });
  const r = A.sortTab(t, 1, 'asc'); assert.equal(r.header, true); assert.equal(r.skipped, 1);
  assert.deepEqual(col(t, 0, 4), ['Nama', 'y', 'z', 'x']); assert.deepEqual(col(t, 1, 4), ['Nilai', 10, 20, 30]);
  assert.deepEqual(t.rows[1].cells.cB.s, { b: true }); // gaya baris y ikut
  const u = mk([['b'], ['a'], ['c']]); assert.equal(A.sortTab(u, 0, 'asc').header, false); assert.deepEqual(col(u, 0, 3), ['a', 'b', 'c']); // semua teks = bukan judul
  const w = mk([['b', 1], ['a', 2]]); A.sortTab(w, 0, 'asc', { header: true }); assert.deepEqual(col(w, 0, 2), ['b', 'a']); // dipaksa: hanya 1 baris diurut
});
test('urutkan: memakai HASIL rumus; ID baris tidak berubah (rumus satu baris tetap benar)', () => {
  const t = mk([[5], [1], [3]]);
  for (let i = 0; i < 3; i++) t.rows[i].cells.cB = { fx: R.a1ToStored('=A' + (i + 1) + '*10', t).fx };
  A.sortTab(t, 1, 'asc', { header: false, now: NOW });
  assert.deepEqual(t.rows.slice(0, 3).map((r) => r.id), ['r2', 'r3', 'r1']); assert.deepEqual(col(t, 0, 3), [1, 3, 5]);
  const c = R.computeTab(t, { now: NOW }); assert.equal(c.get('r2', 'cB'), 10); assert.equal(c.get('r1', 'cB'), 50);
  assert.equal(A.sortTab(t, 99, 'asc').ok, false); assert.equal(A.sortTab(null, 0).ok, false);
});
test('CSV: kutip untuk pemisah/kutip/baris baru, hasil rumus + format ikut, jangkauan isi saja', () => {
  const t = mk([['a,b', 'say "hi"', 'x\ny'], [1.5, true]]); t.rows[1].cells.cC = { fx: R.a1ToStored('=A2*2', t).fx };
  const csv = A.tabToCsv(t, { now: NOW }); assert.equal(csv, '"a,b","say ""hi""","x\ny"\r\n1.5,TRUE,3');
  assert.equal(A.tabToDelimited(t, '\t', { now: NOW }).split('\r\n')[1], '1.5\tTRUE\t3'); assert.equal(A.tabToCsv(L.newTab('K')), '');
  assert.deepEqual(A.usedRange(t), { rows: 2, cols: 3 });
});
test('parseDelimited: kutipan, "" , baris baru dalam kutipan, CRLF/LF/CR, BOM, baris akhir tanpa newline', () => {
  assert.deepEqual(A.parseDelimited('a,b\r\n"c,1","d""e"\n"x\ny",z', ','), [['a', 'b'], ['c,1', 'd"e'], ['x\ny', 'z']]);
  assert.deepEqual(A.parseDelimited('\uFEFFa\tb\rc\td\n', '\t'), [['a', 'b'], ['c', 'd']]); assert.deepEqual(A.parseDelimited('', ','), []);
  assert.deepEqual(A.parseDelimited('a,,\n', ','), [['a', '', '']]);
});
test('detectDelimiter: tab, titik koma, koma; kutipan tidak mengecoh; bawaan koma', () => {
  assert.equal(A.detectDelimiter('a\tb\tc\n1\t2\t3'), '\t'); assert.equal(A.detectDelimiter('a;b;c\n1,5;2;3'), ';'); assert.equal(A.detectDelimiter('a,b\n1,2'), ',');
  assert.equal(A.detectDelimiter('"a;b",c\n"d;e",f'), ','); assert.equal(A.detectDelimiter('satu kolom saja'), ',');
});
test('cellFromText: angka murni, koma desimal hanya bila pemisah bukan koma, nol di depan/rumus tetap teks, boolean', () => {
  assert.equal(A.cellFromText('12'), 12); assert.equal(A.cellFromText('-3.5'), -3.5); assert.equal(A.cellFromText('12,5', ';'), 12.5); assert.equal(A.cellFromText('12,5', ','), '12,5');
  assert.equal(A.cellFromText('007'), '007'); assert.equal(A.cellFromText('=SUM(A1)'), '=SUM(A1)'); assert.equal(A.cellFromText('1e5'), '1e5'); assert.equal(A.cellFromText('true'), true);
  assert.equal(A.cellFromText(''), undefined); assert.equal(A.cellFromText('1234567890123456789'), '1234567890123456789'); // terlalu panjang = teks (hindari kehilangan presisi)
  assert.equal(A.cellFromText('x'.repeat(3000)).length, L.MAX_CELL);
});
test('impor: tulis di posisi, replace mengosongkan jangkauan, rumus dari berkas TIDAK dibuat, pemotongan dilaporkan', () => {
  const t = mk([['lama', 'lama2'], ['lama3']]);
  const r = A.importDelimited(t, 'Nama;Nilai\nAni;12,5\nBudi;=1+1\n', { replace: true });
  assert.equal(r.ok, true); assert.equal(r.delim, ';'); assert.equal(r.rows, 3); assert.equal(r.cols, 2);
  assert.deepEqual(col(t, 0, 4), ['Nama', 'Ani', 'Budi', undefined]); assert.equal(t.rows[1].cells.cB.v, 12.5); assert.equal(t.rows[2].cells.cB.v, '=1+1'); assert.equal(t.rows[2].cells.cB.fx, undefined);
  const u = mk([['x']]); A.importDelimited(u, 'a,b\nc,d', { row: 5, col: 3 }); assert.equal(u.rows[5].cells.cD.v, 'a'); assert.equal(u.rows[6].cells.cE.v, 'd'); assert.equal(u.rows[0].cells.cA.v, 'x');
  const wide = Array.from({ length: 30 }, (_, i) => i + 1).join(','); const big = A.importDelimited(L.newTab('W', 5), wide + '\n' + wide + '\n' + wide + '\n' + wide + '\n' + wide + '\n' + wide);
  assert.equal(big.cols, 26); assert.equal(big.truncatedCols, 4); assert.equal(big.rows, 5); assert.equal(big.truncatedRows, 1);
  assert.equal(A.importDelimited(L.newTab('K'), '').ok, false); assert.equal(A.importDelimited(L.newTab('K'), 'a,b', { row: 999 }).ok, false);
});
test('ekspor lalu impor kembali = sama (nilai, teks berkutip)', () => {
  const t = mk([['n', 'v'], ['a,b', 1.25], ['"q"', false]]); const csv = A.tabToCsv(t); const u = L.newTab('U', 5); A.importDelimited(u, csv, { delim: ',' });
  assert.deepEqual(col(u, 0, 3), ['n', 'a,b', '"q"']); assert.deepEqual(col(u, 1, 3), ['v', 1.25, false]);
});
test('cari: teks tampil (hasil rumus, angka berformat), huruf besar/kecil, sel utuh, jangkauan', () => {
  const t = mk([['Apel', 'apel pie'], [1250000, 'x']]); L.setCell(t, 'r2', 'cA', { s: { nf: { k: 'currency', c: 'IDR', d: 0 } } }); t.rows[1].cells.cC = { fx: R.a1ToStored('="APEL"&"s"', t).fx };
  assert.equal(A.findAll(t, 'apel', { now: NOW }).length, 3); assert.equal(A.findAll(t, 'apel', { matchCase: true, now: NOW }).length, 1);
  assert.deepEqual(A.findAll(t, 'apel', { whole: true, now: NOW }), [{ row: 0, col: 0 }]); assert.deepEqual(A.findAll(t, '1.250', { now: NOW }), [{ row: 1, col: 0 }]);
  assert.equal(A.findAll(t, 'apel', { scope: { r1: 0, c1: 1, r2: 0, c2: 1 }, now: NOW }).length, 1); assert.deepEqual(A.findAll(t, ''), []);
});
test('ganti: teks dan angka murni; rumus dan angka berformat DILEWATI dan dilaporkan; karakter khusus regex aman', () => {
  const t = mk([['a.b a.b', 100, 'Cat'], [5]]); t.rows[0].cells.cD = { fx: R.a1ToStored('="a.b"', t).fx }; L.setCell(t, 'r2', 'cA', { s: { nf: { k: 'number' } } });
  let r = A.replaceAll(t, 'a.b', 'X'); assert.equal(r.replaced, 2); assert.equal(r.cells, 1); assert.equal(t.rows[0].cells.cA.v, 'X X'); assert.equal(r.skippedFormula, 1);
  r = A.replaceAll(t, '0', '7'); assert.equal(t.rows[0].cells.cB.v, 177); assert.equal(typeof t.rows[0].cells.cB.v, 'number');
  r = A.replaceAll(t, '5', '9'); assert.equal(r.skippedFormat, 1); assert.equal(t.rows[1].cells.cA.v, 5);
  A.replaceAll(t, 'cat', 'Dog', { matchCase: true }); assert.equal(t.rows[0].cells.cC.v, 'Cat'); A.replaceAll(t, 'cat', 'Dog'); assert.equal(t.rows[0].cells.cC.v, 'Dog');
  assert.equal(A.replaceAll(t, '', 'x').replaced, 0); assert.equal(A.replaceAll(t, 'Dog', 'Anjing', { whole: true }).replaced, 1);
});
test('seriesPlan: linear, teks+angka dengan nol di depan, salin', () => {
  assert.deepEqual(A.seriesPlan([1, 2, 3]), { kind: 'linear', step: 1 }); assert.equal(A.seriesPlan([10, 20]).step, 10); assert.equal(A.seriesPlan([1, 2, 4]).kind, 'copy');
  assert.equal(A.seriesPlan([5]).kind, 'copy-or-inc'); assert.deepEqual(A.seriesPlan(['Minggu 1', 'Minggu 2']), { kind: 'texnum', prefix: 'Minggu ', step: 1, pad: 0, last: 2 });
  assert.equal(A.seriesPlan(['Item 07']).pad, 2); assert.equal(A.seriesPlan(['a1', 'b2']).kind, 'copy'); assert.equal(A.seriesPlan([0.1, 0.2, 0.3]).kind, 'linear');
});
test('isi seri: turun/kanan, angka, teks+angka, tanggal (nomor seri), pola berulang, gaya diulang, satu angka disalin kecuali inc', () => {
  const t = mk([[1, 'Minggu 1', 'x'], [2, 'Minggu 2', 'y']]); L.setCell(t, 'r2', 'cA', { s: { b: true } });
  const r = A.fillSeries(t, { r1: 0, c1: 0, r2: 1, c2: 2 }, 3); assert.equal(r.ok, true);
  assert.deepEqual(col(t, 0, 5), [1, 2, 3, 4, 5]); assert.deepEqual(col(t, 1, 5), ['Minggu 1', 'Minggu 2', 'Minggu 3', 'Minggu 4', 'Minggu 5']); assert.deepEqual(col(t, 2, 5), ['x', 'y', 'x', 'y', 'x']);
  assert.equal(t.rows[2].cells.cA.s, undefined); assert.deepEqual(t.rows[3].cells.cA.s, { b: true }); // gaya sumber diulang bergantian: baris isian ke-1 = gaya sumber ke-1 (polos), ke-2 = tebal
  const d = mk([[46000, 46007]]); A.fillSeries(d, { r1: 0, c1: 0, r2: 0, c2: 1 }, 2, { dir: 'right' }); assert.deepEqual(col(d, 2, 1), [46014]); // mingguan
  const one = mk([[5]]); A.fillSeries(one, { r1: 0, c1: 0, r2: 0, c2: 0 }, 2); assert.deepEqual(col(one, 0, 3), [5, 5, 5]);
  const inc = mk([[5]]); A.fillSeries(inc, { r1: 0, c1: 0, r2: 0, c2: 0 }, 2, { inc: true }); assert.deepEqual(col(inc, 0, 3), [5, 6, 7]);
  const pad = mk([['Item 07']]); A.fillSeries(pad, { r1: 0, c1: 0, r2: 0, c2: 0 }, 2); assert.deepEqual(col(pad, 0, 3), ['Item 07', 'Item 08', 'Item 09']); // satu teks berakhiran angka = naik (seperti Excel), nol di depan dijaga; angka murni tunggal = salin
  const fl = mk([[0.1, 0.2]]); A.fillSeries(fl, { r1: 0, c1: 0, r2: 0, c2: 1 }, 1, { dir: 'right' }); assert.equal(fl.rows[0].cells.cC.v, 0.3); // tanpa galat floating
});
test('isi seri: lajur berumus DILEWATI (kembali ke setelan awal, Rev 172), batas lembar dilaporkan, masukan buruk aman', () => {
  const t = mk([[1], [2]], 4); t.rows[0].cells.cB = { fx: R.a1ToStored('=A1', t).fx };
  const r = A.fillSeries(t, { r1: 0, c1: 0, r2: 1, c2: 1 }, 10); assert.equal(r.skippedFormula, 1); assert.equal(r.fxCopied, 0); assert.equal(r.truncated, 8); assert.deepEqual(col(t, 0, 4), [1, 2, 3, 4]); assert.ok(!t.rows[2].cells.cB); // Rev 172: lajur berumus dilewati, rumus tidak disalin
  assert.equal(A.fillSeries(t, null, 3).ok, false); assert.equal(A.fillSeries(t, { r1: 0, c1: 0, r2: 99, c2: 0 }, 3).ok, false); assert.equal(A.fillSeries(t, { r1: 0, c1: 0, r2: 0, c2: 0 }, 0).ok, false);
});
test('keamanan: modul murni, tanpa eval/DOM/penyimpanan, tanpa impor mesin rumus langsung', () => {
  const s = src('src/js/lembar-alat.js');
  assert.doesNotMatch(s, /\beval\s*\(|new Function|document\.|localStorage|Capacitor|window\./); assert.doesNotMatch(s, /from '\.\/rumus\.js'/);
  assert.match(s, /from '\.\/lembar-tampil\.js'/); assert.match(s, /from '\.\/lembar\.js'/);
  assert.doesNotMatch(src('src/js/lembar.js'), /lembar-alat/); // arah impor satu jalur: alat -> model
});
