// Rev 169 / Q10 tahap 2: DATEVALUE(teks) = teks tanggal jadi nomor seri (hari/bulan/tahun Indonesia).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { argHint } from '../src/js/rumus-bantu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 9, 0, 0).getTime();
function at(grid, f) { const t = L.newTab('T', 12); grid.forEach((row, ri) => row.forEach((v, ci) => { if (v !== undefined && v !== null) L.setCell(t, t.rows[ri].id, t.cols[ci].id, { v }); })); const r = R.a1ToStored(f, t); if (!r.ok) return { rejected: r.error }; t.rows[0].cells.cH = { fx: r.fx }; return R.computeTab(t, { now: NOW }).get('r1', 'cH'); }
const D = (f) => at([], f);
const S = D('=DATE(2026;11;10)');

test('DATEVALUE: format angka dd/mm/yyyy, dd-mm-yyyy, dd.mm.yyyy dan yyyy-mm-dd (hari dulu, bukan bulan)', () => {
  assert.equal(D('=DATEVALUE("10/11/2026")'), S); assert.equal(D('=DATEVALUE("10-11-2026")'), S); assert.equal(D('=DATEVALUE("10.11.2026")'), S); assert.equal(D('=DATEVALUE("2026-11-10")'), S); assert.equal(D('=DATEVALUE("2026/11/10")'), S);
  assert.equal(D('=DATEVALUE("1/2/2026")'), D('=DATE(2026;2;1)')); // 1 Februari, bukan 2 Januari
  assert.equal(D('=DATEVALUE(" 10/11/2026 ")'), S); assert.equal(D('=DATEVALUE("01/01/1900")'), D('=DATE(1900;1;1)')); assert.equal(D('=DATEVALUE("31/12/9999")'), D('=DATE(9999;12;31)'));
  assert.equal(D('=DATEVALUE("10/11/26")'), S); assert.equal(D('=DATEVALUE("10/11/29")'), D('=DATE(2029;11;10)')); assert.equal(D('=DATEVALUE("10/11/30")'), D('=DATE(1930;11;10)')); // tahun 2 digit: 00-29 = 20xx, 30-99 = 19xx
});
test('DATEVALUE: nama bulan Indonesia/Inggris, lengkap atau tiga huruf, huruf besar/kecil bebas', () => {
  assert.equal(D('=DATEVALUE("10 November 2026")'), S); assert.equal(D('=DATEVALUE("10 Nov 2026")'), S); assert.equal(D('=DATEVALUE("10-nov-2026")'), S); assert.equal(D('=DATEVALUE("10 NOV 26")'), S);
  assert.equal(D('=DATEVALUE("17 Agustus 1945")'), D('=DATE(1945;8;17)')); assert.equal(D('=DATEVALUE("17 Agu 1945")'), D('=DATE(1945;8;17)')); assert.equal(D('=DATEVALUE("17 August 1945")'), D('=DATE(1945;8;17)')); assert.equal(D('=DATEVALUE("1 Mei 2026")'), D('=DATE(2026;5;1)')); assert.equal(D('=DATEVALUE("1 May 2026")'), D('=DATE(2026;5;1)')); assert.equal(D('=DATEVALUE("25 Des 2026")'), D('=DATE(2026;12;25)')); assert.equal(D('=DATEVALUE("25 Dec 2026")'), D('=DATE(2026;12;25)'));
  assert.equal(D('=DATEVALUE("10 Xyz 2026")').e, '#VALUE!'); assert.equal(D('=DATEVALUE("10 No 2026")').e, '#VALUE!');
});
test('DATEVALUE: jam di belakang diabaikan; tanggal/bulan tidak sah, angka, boolean, kosong, teks lain = #VALUE!; galat menjalar', () => {
  assert.equal(D('=DATEVALUE("10/11/2026 14:30")'), S); assert.equal(D('=DATEVALUE("2026-11-10T14:30:00")'), S); assert.equal(D('=DATEVALUE("10/11/2026 09:15:20 PM")'), S); assert.equal(D('=DATEVALUE("10/11/2026 25:00")').e, '#VALUE!'); assert.equal(D('=DATEVALUE("10/11/2026 10:75")').e, '#VALUE!');
  for (const bad of ['31/02/2026', '30/02/2024', '0/1/2026', '1/0/2026', '10/13/2026', '32/01/2026', '10/11/1899', '1/1/0', 'besok', '', '10/11', '10/11/20266']) assert.equal(D('=DATEVALUE("' + bad + '")').e, '#VALUE!', bad);
  assert.equal(D('=DATEVALUE("29/02/2024")'), D('=DATE(2024;2;29)')); assert.equal(D('=DATEVALUE("29/02/2023")').e, '#VALUE!'); // hanya tahun kabisat
  assert.equal(D('=DATEVALUE(46336)').e, '#VALUE!'); assert.equal(D('=DATEVALUE(TRUE)').e, '#VALUE!'); assert.equal(D('=DATEVALUE(1/0)').e, '#DIV/0!'); assert.equal(at([['a', 'b']], '=DATEVALUE(A1:B1)').e, '#VALUE!'); assert.equal(at([], '=DATEVALUE(A5)').e, '#VALUE!'); // sel kosong = teks kosong
});
test('DATEVALUE dipakai nyata: teks di sel, DATEDIF/WEEKDAY/TEXT, selisih hari, IFERROR; format Tanggal otomatis', () => {
  assert.equal(at([['10/11/2026']], '=DATEVALUE(A1)'), S); assert.equal(at([['10/11/2026']], '=WEEKDAY(DATEVALUE(A1);2)'), 2); // Selasa
  assert.equal(at([['01/01/2026', '10/11/2026']], '=DATEVALUE(B1)-DATEVALUE(A1)'), 313); assert.equal(at([['01/01/2020', '10/11/2026']], '=DATEDIF(DATEVALUE(A1);DATEVALUE(B1);"Y")'), 6);
  assert.equal(at([['10/11/2026']], '=TEXT(DATEVALUE(A1);"dddd, dd mmmm yyyy")'), 'Selasa, 10 November 2026'); assert.equal(at([['tidak ada']], '=IFERROR(DATEVALUE(A1);0)'), 0); assert.equal(at([['5 Mei 2026']], '=DATEVALUE(A1)+30'), D('=DATE(2026;6;4)'));
  assert.deepEqual(R.fxAutoNf('=DATEVALUE("10/11/2026")'), { k: 'date', p: 'short' }); assert.equal(R.fxAutoNf('=DATEVALUE("10/11/2026")-DATEVALUE("1/1/2026")'), null); assert.deepEqual(R.fxAutoNf('=DATEVALUE("10/11/2026")+7'), { k: 'date', p: 'short' });
});
test('daftar fungsi 53; chip saran + petunjuk; fungsi lain tidak berubah; modul murni; tes terdaftar; versi 0.3.121', () => {
  const names = R.FUNCTION_LIST.map((f) => f.name); assert.equal(names.length, 53); const f = R.FUNCTION_LIST.find((x) => x.name === 'DATEVALUE'); assert.ok(f && f.sig.startsWith('DATEVALUE(') && f.ket.length > 3);
  assert.equal(argHint('DATEVALUE', 10).parts.length, 1); assert.deepEqual(R.suggestFunctions('datev').map((x) => x.name), ['DATEVALUE']); assert.deepEqual(R.suggestFunctions('date').map((x) => x.name), ['DATE', 'DATEDIF', 'DATEVALUE']);
  assert.equal(D('=DATE(2026;11;10)'), S); assert.equal(at([['a', 1]], '=HLOOKUP("a";A1:B1;1;FALSE)'), 'a');
  const s = src('src/js/rumus.js'); assert.ok(!/^\s*import\s/m.test(s)); assert.ok(!/document\.|window\.|localStorage|eval\(|new Function/.test(s));
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(pk.scripts.test.includes('tests/rev169.test.mjs')); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
