// Rev 290 / T5a: kelompok templat "Admin" bagian 1 (Daftar hadir, Surat masuk keluar, Kas kecil, Slip gaji): nilai kunci dihitung mesin rumus sungguhan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { chartList } from '../src/js/lembar-grafik.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN);
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 14, 12, 0, 0).getTime();
const IDS = ['admin-hadir', 'admin-surat', 'admin-kas', 'admin-slip'];
const mk = (id) => T.makeFromTemplate(id, { now: NOW });
const first = (id) => { const tab = mk(id).sheet.tabs[0]; return { tab, d: makeDisplay(tab) }; };
test('Rev 290: empat templat Admin ada, nama <= 30, keterangan, Panduan terakhir, failed 0, muat batas, tanpa galat rumus, bulat-balik', () => {
  const ids = T.templateList().map((t) => t.id); for (const id of IDS) assert.ok(ids.includes(id), id); assert.equal(new Set(ids).size, ids.length);
  for (const id of IDS) {
    const t = T.templateList().find((x) => x.id === id); assert.ok(t.name.startsWith('Admin · ') && t.name.length <= 30 && t.desc.length >= 20 && t.desc.length <= 100, id);
    const r = mk(id); assert.ok(r, id); assert.equal(r.failed, 0, id); assert.ok(L.fitsLimit(r.sheet)); const tabs = r.sheet.tabs;
    assert.equal(tabs[tabs.length - 1].name, 'Panduan', id); assert.ok(tabs.length <= 5);
    for (const tab of tabs) { const d = makeDisplay(tab); for (let i = 0; i < tab.rows.length; i++) for (let j = 0; j < tab.cols.length; j++) assert.doesNotMatch(String(d.text(i, j)), /^#/, id + ' ' + L.cellAddr(j, i)); }
    assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(r.sheet)))), JSON.stringify(r.sheet), id);
  }
});
test('Rev 290: Daftar hadir = Hadir per orang, persen, rekap 31/3/4/2 total 40, dropdown berwarna, donat; berubah saat sel diganti', () => {
  const { tab, d } = first('admin-hadir');
  assert.deepEqual(Array.from({ length: 8 }, (_, i) => d.raw(i + 1, 7)), [5, 4, 4, 3, 5, 3, 3, 4]); assert.ok(Math.abs(d.raw(4, 8) - 0.6) < 1e-9);
  assert.deepEqual([1, 2, 3, 4, 5].map((i) => d.raw(i, 11)), [31, 3, 4, 2, 40]); assert.equal(tab.checks.length, 1); assert.equal(tab.checks[0].cl.Alpa.bg, '#FEE2E2'); assert.equal(tab.rules.length, 2);
  assert.deepEqual(chartList(tab).map((c) => c.kind), ['donut']);
  L.setCell(tab, tab.rows[1].id, tab.cols[2].id, { v: 'Alpa' }); const d2 = makeDisplay(tab); assert.equal(d2.raw(1, 7), 4); assert.equal(d2.raw(1, 11), 30); assert.equal(d2.raw(4, 11), 3);
});
test('Rev 290: Surat = nomor otomatis 001/SM/11/2026, 002/SK/..., rekap status 2/3/5, masuk 6, keluar 4, total 10; dropdown Jenis dan Status', () => {
  const { tab, d } = first('admin-surat');
  assert.equal(d.raw(1, 3), '001/SM/11/2026'); assert.equal(d.raw(2, 3), '002/SK/11/2026'); assert.equal(d.raw(10, 3), '010/SM/11/2026');
  assert.deepEqual([1, 2, 3, 4, 5, 6].map((i) => d.raw(i, 9)), [2, 3, 5, 6, 4, 10]); assert.equal(tab.checks.length, 2); assert.deepEqual(chartList(tab).map((c) => c.kind), ['donut']);
  L.setCell(tab, tab.rows[8].id, tab.cols[6].id, { v: 'Selesai' }); const d2 = makeDisplay(tab); assert.equal(d2.raw(1, 9), 1); assert.equal(d2.raw(3, 9), 6);
});
test('Rev 290: Kas kecil = saldo berjalan, total debet 1.800.000 kredit 520.000 saldo 1.280.000, aturan warna, diagram; baris tanpa debet/kredit tidak galat', () => {
  const { tab, d } = first('admin-kas');
  assert.deepEqual(Array.from({ length: 10 }, (_, i) => d.raw(i + 1, 4)), [1000000, 915000, 765000, 1265000, 1220000, 1160000, 1120000, 1420000, 1400000, 1280000]);
  assert.deepEqual([2, 3, 4].map((j) => d.raw(11, j)), [1800000, 520000, 1280000]); assert.equal(tab.rules.length, 2); assert.deepEqual(chartList(tab).map((c) => c.kind), ['column']);
  L.setCell(tab, tab.rows[2].id, tab.cols[3].id, { v: 2000000 }); const d2 = makeDisplay(tab); assert.equal(d2.raw(2, 4), -1000000); assert.equal(d2.raw(11, 4), -635000);
});
test('Rev 290: Slip gaji = angka kunci benar dan ikut berubah (kotor 6.400.000, potongan 520.000, bersih 5.880.000)', () => {
  const { d } = first('admin-slip');
  assert.deepEqual([8, 9, 11, 13, 15, 16, 17, 18].map((i) => d.raw(i, 1)), [300000, 6400000, 150000, 320000, 520000, 5880000, 600000, 500000]);
  const { tab } = first('admin-slip'); L.setCell(tab, tab.rows[3].id, tab.cols[1].id, { v: 6000000 }); const d2 = makeDisplay(tab);
  assert.equal(d2.raw(9, 1), 7400000); assert.equal(d2.raw(11, 1), 180000); assert.equal(d2.raw(13, 1), 370000); assert.equal(d2.raw(16, 1), 7400000 - (180000 + 370000 + 50000));
});
test('Rev 290: modul data murni; hanya fungsi yang ada; urutan templat tetap; mesin dan settings tidak menyebut berkas data', () => {
  const s = src('src/js/templat-admin.js'); assert.doesNotMatch(s, /import |localStorage|document\.|window\.|eval\(|new Function/);
  const ada = new Set([...src('src/js/rumus.js').matchAll(/^\s{2}([A-Z][A-Z0-9]+): \{ min:/gm)].map((m) => m[1]));
  const used = new Set([...s.matchAll(/'(=[^']*)'/g)].flatMap((m) => [...m[1].matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1]))); assert.ok(used.size >= 8); for (const f of used) assert.ok(ada.has(f), f);
  const ids = T.templateList().map((t) => t.id); assert.equal(ids.length, 35); assert.deepEqual(ids.slice(11, 15), IDS); assert.deepEqual(ids.slice(-10, -6), ['anggaran', 'bagi', 'jadwal', 'nilai']);
  for (const f of ['settings', 'lembar', 'lembar-ui', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /templat-admin/, f);
});
