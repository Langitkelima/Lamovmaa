// Tes Rev 23c/23d: tombol Undo (Urungkan) dan Redo (Ulangi) di editor catatan.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHistory } from '../src/js/undo.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

await t('riwayat baru: belum ada yang bisa diurungkan', () => {
  const h = createHistory({ html: 'halo', caret: 4 });
  assert.equal(h.canUndo(), false);
  assert.equal(h.undo(), null);
  assert.equal(h.size(), 1);
});
await t('push lalu undo kembali ke keadaan sebelumnya (isi + kursor)', () => {
  const h = createHistory({ html: 'a', caret: 1 });
  assert.equal(h.push({ html: 'ab', caret: 2 }), true);
  assert.equal(h.push({ html: 'abc', caret: 3 }), true);
  assert.equal(h.canUndo(), true);
  assert.deepEqual(h.undo(), { html: 'ab', caret: 2 });
  assert.deepEqual(h.undo(), { html: 'a', caret: 1 });
  assert.equal(h.undo(), null);
  assert.equal(h.canUndo(), false);
});
await t('isi yang sama dengan langkah terakhir tidak dicatat dua kali', () => {
  const h = createHistory({ html: 'a' });
  assert.equal(h.push({ html: 'a', caret: 1 }), false);
  assert.equal(h.size(), 1);
  h.push({ html: 'b' });
  assert.equal(h.push({ html: 'b', caret: 9 }), false);
  assert.equal(h.size(), 2);
});
await t('setelah undo, perubahan baru dicatat dari titik itu (tanpa cabang lama)', () => {
  const h = createHistory({ html: 'a' });
  h.push({ html: 'ab' }); h.push({ html: 'abc' });
  h.undo(); // kini di 'ab'
  assert.equal(h.push({ html: 'abx' }), true);
  assert.deepEqual(h.undo(), { html: 'ab', caret: null });
  assert.deepEqual(h.undo(), { html: 'a', caret: null });
});
await t('batas jumlah langkah: yang tertua dibuang, langkah awal terbaru tetap', () => {
  const h = createHistory({ html: '0' }, 5);
  for (let i = 1; i <= 10; i++) h.push({ html: String(i) });
  assert.equal(h.size(), 5);
  let last = null, c = 0; for (let s = h.undo(); s; s = h.undo()) { last = s; c++; }
  assert.equal(c, 4);
  assert.equal(last.html, '6');
});
await t('batas total huruf: riwayat dipangkas tetapi keadaan terkini tidak pernah dibuang', () => {
  const h = createHistory({ html: 'x'.repeat(40) }, 100, 100);
  h.push({ html: 'y'.repeat(40) }); h.push({ html: 'z'.repeat(40) });
  assert.ok(h.size() >= 1 && h.size() <= 2);
  h.push({ html: 'w'.repeat(500) }); // satu langkah lebih besar dari batas
  assert.equal(h.size(), 1);
  assert.equal(h.canUndo(), false);
});
await t('masukan aneh (null, tanpa kursor, kursor bukan angka) tidak melempar galat', () => {
  const h = createHistory(null);
  assert.equal(h.push(null), false);
  assert.equal(h.push({ html: 'a', caret: 'abc' }), true);
  assert.deepEqual(h.undo(), { html: '', caret: null });
});

await t('redo: maju lagi setelah undo, bolak-balik, dan habis di ujung', () => {
  const h = createHistory({ html: 'a', caret: 1 });
  h.push({ html: 'ab', caret: 2 }); h.push({ html: 'abc', caret: 3 });
  assert.equal(h.canRedo(), false); assert.equal(h.redo(), null);
  h.undo(); h.undo();
  assert.equal(h.canRedo(), true);
  assert.deepEqual(h.redo(), { html: 'ab', caret: 2 });
  assert.deepEqual(h.redo(), { html: 'abc', caret: 3 });
  assert.equal(h.redo(), null); assert.equal(h.canRedo(), false);
  assert.deepEqual(h.undo(), { html: 'ab', caret: 2 });
  assert.deepEqual(h.redo(), { html: 'abc', caret: 3 });
});
await t('redo: perubahan baru setelah undo menutup jalur Ulangi', () => {
  const h = createHistory({ html: 'a' });
  h.push({ html: 'ab' }); h.undo();
  assert.equal(h.canRedo(), true);
  h.push({ html: 'ax' });
  assert.equal(h.canRedo(), false); assert.equal(h.redo(), null);
});
await t('redo: push isi sama (tidak dicatat) tidak menghapus jalur Ulangi', () => {
  const h = createHistory({ html: 'a' });
  h.push({ html: 'ab' }); h.undo();
  assert.equal(h.push({ html: 'a' }), false);
  assert.equal(h.canRedo(), true);
});
await t('setTop: mengganti isi langkah terkini tanpa menghapus jalur Ulangi', () => {
  const h = createHistory({ html: 'a' });
  h.push({ html: 'ab' }); h.push({ html: 'abc' }); h.undo();
  h.setTop({ html: 'ab-normal' });
  assert.equal(h.canRedo(), true);
  assert.equal(h.push({ html: 'ab-normal' }), false);
  assert.deepEqual(h.redo(), { html: 'abc', caret: null });
  assert.equal(h.undo().html, 'ab-normal');
});

// ---- Pemeriksaan sumber (tanpa DOM di Node; BUKAN uji di HP) ----
const notes = src('../src/js/notes.js');
await t('sumber: tombol Undo ada di bilah format (paling kiri) dan memakai ikon + label Undo', () => {
  assert.ok(notes.includes("import { createHistory } from './undo.js';"));
  const iBar = notes.indexOf("const bar = h('div', { class: 'fbar' },");
  const iUndo = notes.indexOf("'data-cmd': 'undo'", iBar);
  const iBold = notes.indexOf("'data-cmd': 'bold'", iBar);
  assert.ok(iBar > 0 && iUndo > iBar && iUndo < iBold, 'Undo harus tombol pertama di bilah');
  assert.ok(notes.includes("'aria-label': 'Urungkan'") && notes.includes("'aria-label': 'Ulangi'"));
  assert.ok(notes.indexOf("'data-cmd': 'redo'") > iUndo && notes.indexOf("'data-cmd': 'redo'") < iBold, 'Redo tepat setelah Undo');
  assert.ok(src('../src/js/ui.js').includes("undo: '") && src('../src/js/ui.js').includes("redo: '"));
});
await t('sumber: Undo dijalankan lewat pointerdown (bind) dan tidak memanggil undo bawaan WebView', () => {
  assert.ok(notes.includes("if (c === 'undo') { doUndo(); return; }") && notes.includes("if (c === 'redo') { doRedo(); return; }"));
  assert.ok(!notes.includes("execCommand('undo'") && !notes.includes('execCommand("undo"'), 'jangan pakai undo bawaan: baris centang dibuat lewat DOM');
});
await t('sumber: perubahan dicatat (ketikan ditunda, tombol format/warna/kotak centang langsung) dan timer dibersihkan', () => {
  assert.ok(notes.includes('markHist(); auto();'), 'ketikan -> markHist');
  assert.ok(/flushHist\(\); upd\(\); auto\(\);/.test(notes), 'tombol format -> flushHist');
  assert.ok(/reSel\(\); flushHist\(\); upd\(\); auto\(\);/.test(notes), 'palet warna teks -> flushHist');
  assert.ok(notes.includes("e.target.toggleAttribute('checked', e.target.checked); flushHist(); auto();"), 'kotak centang -> flushHist');
  assert.ok(notes.includes('clearTimeout(ht);'), 'timer riwayat dibersihkan saat editor ditutup');
});
await t('sumber: Undo/Redo mencatat ketikan tertunda dulu, kursor hanya bila editor fokus, keyboard tidak dibuka paksa', () => {
  for (const [fn, call] of [['doUndo', 'hist.undo()'], ['doRedo', 'hist.redo()']]) {
    const i = notes.indexOf(`const ${fn} = () => {`);
    const body = notes.slice(i, i + 400);
    assert.ok(body.indexOf('flushHist()') > 0 && body.indexOf('flushHist()') < body.indexOf(call), fn + ' mencatat dulu');
    assert.ok(body.includes('applyHist(st)'));
  }
  const i = notes.indexOf('const applyHist = (st) => {');
  const body = notes.slice(i, i + 600);
  assert.ok(body.includes('document.activeElement === ed'), 'kursor hanya ditaruh bila editor sedang fokus');
  assert.ok(!/ed\.focus\(\)/.test(body), 'tidak boleh memfokuskan editor (membuka keyboard)');
});
await t('sumber: Catatan Privat tidak berubah perilakunya dan data/SCHEMA tidak disentuh oleh undo (SCHEMA 7 sejak Rev 24A)', () => {
  assert.ok(src('../src/js/storage.js').includes('SCHEMA = 22'));
  assert.ok(!src('../src/js/undo.js').includes('localStorage'), 'riwayat hanya di memori, tidak disimpan ke data');
});
await t('CSS: tombol Undo redup saat tidak ada yang bisa diurungkan dan bilah muat 8 tombol', () => {
  const css = src('../src/css/styles.css');
  assert.ok(css.includes('.fbar button.dis{opacity:.38}'));
  assert.ok(css.includes('.fbar button>:first-child{height:28px'), 'ikon/huruf bilah satu tinggi: label Warna sejajar');
  assert.ok(css.includes('.fbar .u::after'), 'garis bawah Warna lewat ::after, bukan border yang menambah tinggi');
  assert.ok(!src('../src/js/ui.js').includes("palette: 'M12 3a9 9 0 100 18 9 9 0 000-18z"), 'ikon palet bukan lingkaran dengan tiga titik (mirip wajah)');
  assert.ok(/\.fbar button\{flex:1;min-width:0;padding:0;/.test(css));
});
await t('versi 0.3.2 di tiga tempat (package.json, teks Lainnya, RIWAYAT)', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('../RIWAYAT.md').includes('versi 0.3.2'));
});
console.log(`\n${n} tes undo lulus`);
