import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseNoteHtml, blocksToText, blocksToMarkdown } from '../src/js/export.js';

const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const now = new Date(2026, 10, 7, 14, 30);

test('Rev 87: tanggal dan waktu diekspor konsisten, tervalidasi, dan tidak membaca teks visual duplikat', () => {
  const html = '<div class="kb-date-block" data-kb-date="2026-11-07"><span class="kb-date-value">teks palsu</span></div>'
    + '<div class="kb-time-block" data-kb-time="14:35"><span class="kb-time-value">00:00</span></div>';
  const blocks = parseNoteHtml(html, now);
  assert.equal(blocks.length, 2);
  assert.equal(blocks[0].runs.map((r) => r.t).join(''), 'Tanggal: 7 November 2026');
  assert.equal(blocks[1].runs.map((r) => r.t).join(''), 'Waktu: 14:35');
  assert.match(blocksToText('Uji', blocks), /Tanggal: 7 November 2026[\s\S]*Waktu: 14:35/);
  assert.match(blocksToMarkdown('Uji', blocks), /Tanggal: 7 November 2026[\s\S]*Waktu: 14:35/);
});

test('Rev 87: Hitung Mundur memakai kalender lokal deterministik dan mengabaikan nilai waktu/judul tidak valid', () => {
  const html = '<div class="kb-countdown-block" data-kb-date="2026-11-09" data-kb-time="25:90" data-kb-title="  Acara&#10; Penting  "><span class="kb-cd-date">teks lama</span></div>';
  const blocks = parseNoteHtml(html, now);
  const text = blocks[0].runs.map((r) => r.t).join('');
  assert.match(text, /^Hitung mundur: Acara Penting, Senin, 9 November 2026 \(2 hari lagi\)$/);
  assert.doesNotMatch(text, /25:90|teks lama/);
});

test('Rev 87: tanggal tidak valid tidak dinormalisasi diam-diam saat ekspor', () => {
  const blocks = parseNoteHtml('<div class="kb-date-block" data-kb-date="2026-02-31">31 Februari</div><div class="kb-countdown-block" data-kb-date="2026-02-31" data-kb-title="Acara">x</div>', now);
  assert.equal(blocks[0].runs.map((r) => r.t).join(''), 'Tanggal: ');
  assert.equal(blocks[1].runs.map((r) => r.t).join(''), 'Hitung mundur: Acara, tanggal tidak valid');
});

test('Rev 87: sanitizer mempertahankan elemen small tanggal pada kartu hitung mundur dan membersihkan alat sementara', () => {
  const notes = read('../src/js/notes.js');
  assert.match(notes, /'SPAN', 'SMALL', 'FONT'/);
  assert.match(notes, /c\.tagName === 'SMALL' && v === 'kb-cd-date'/);
  assert.match(notes, /stripBlockTools\(t\.content\)/);
  assert.match(notes, /t\.content\.querySelectorAll\('\.kb-countdown-block'\)\.forEach\(\(el\) => syncCountdownBlock\(el\)\)/);
});

test('Rev 87: integrasi U3 tetap pada SCHEMA 9, tanpa perubahan native atau dependensi', () => {
  const storage = read('../src/js/storage.js');
  const pkg = JSON.parse(read('../package.json'));
  const native = read('../src/js/native.js');
  assert.match(storage, /SCHEMA\s*=\s*22/);
  assert.equal(pkg.version, '0.3.121');
  assert.doesNotMatch(native, /countdown|kb-date|kb-time/);
  assert.equal(pkg.dependencies['@capacitor/core'], '^8.0.0');
});
