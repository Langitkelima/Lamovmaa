// Rev 268 / V2b (paket Validasi, bagian 29): warna pilihan (validasi data) tampil di PULAU catatan dan diekspor PDF/JPG. Tes AI saja (BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { islandModel, exportModel, pickPainter } from '../src/js/lembar-pulau.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { parseNoteHtml, layoutDoc, sheetBlocks } from '../src/js/export.js';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const measure = (t, st) => String(t).length * (st.size || 30) * 0.5;

// Lembar: kolom A = Status (aturan berwarna), baris 1 = judul. Aturan hanya untuk A2:A6 (rentang) supaya batas aturan ikut diuji.
function sample() {
  const sh = L.newSheet({ id: 'sabc123', name: 'Status' }); const t = sh.tabs[0];
  L.setCell(t, 'r1', 'cA', { v: 'Status' });
  L.setCell(t, 'r2', 'cA', { v: 'Selesai' });
  L.setCell(t, 'r3', 'cA', { v: 'proses' }); // huruf kecil = tetap cocok
  L.setCell(t, 'r4', 'cA', { v: 'Selesai', s: { bg: '#111111' } }); // gaya manual MENANG
  L.setCell(t, 'r5', 'cA', { v: 'Lain' }); // tidak ada di daftar
  L.setCell(t, 'r6', 'cA', { v: 'Gelap' }); // hanya fg
  L.setCell(t, 'r7', 'cA', { v: 'Selesai' }); // di luar rentang aturan
  const rg = { c2: t.cols[0].id, r1: t.rows[1].id, r2: t.rows[5].id };
  L.setChecks(t, [{ id: '', c: t.cols[0].id, rg, k: 'list', items: ['Selesai', 'Proses', 'Gelap'], cl: { Selesai: { bg: '#BBF7D0' }, Proses: { bg: '#1E3A8A' }, Gelap: { fg: '#7F1D1D' } } }]);
  return sh;
}

test('pulau: warna pilihan tampil, gaya manual menang, di luar rentang dan pilihan tak berwarna tidak diwarnai', () => {
  const m = islandModel(sample(), 8, 3), col = (i) => m.rows[i][0];
  assert.equal(col(0).bg, ''); // judul di luar rentang
  assert.equal(col(1).bg, '#BBF7D0'); assert.equal(col(1).fg, '');
  assert.equal(col(2).bg, '#1E3A8A', 'tak peka huruf besar-kecil'); // teks otomatis dipilih penggambar (inkOnFill) bila fg kosong
  assert.equal(col(3).bg, '#111111', 'gaya sel manual menang');
  assert.equal(col(4).bg, ''); assert.equal(col(4).fg, '');
  assert.equal(col(5).bg, ''); assert.equal(col(5).fg, '#7F1D1D', 'warna teks saja tetap dipakai');
  assert.equal(col(6).bg, '', 'baris 7 di luar rentang aturan');
});

test('pulau: tanpa aturan atau tanpa warna, hasil SAMA dengan sebelumnya; pickPainter null', () => {
  const sh = sample(); const t = sh.tabs[0]; assert.equal(pickPainter({ cols: t.cols, rows: t.rows }, null), null);
  const plain = L.newSheet({ id: 'splain1' }); L.setCell(plain.tabs[0], 'r1', 'cA', { v: 'Selesai', s: { bg: '#FEE2E2' } });
  const m = islandModel(plain, 3, 3); assert.equal(m.rows[0][0].bg, '#FEE2E2');
  L.setChecks(t, [{ id: '', c: t.cols[0].id, k: 'list', items: ['Selesai'] }]); // aturan tanpa warna
  assert.equal(pickPainter(t, makeDisplay(t, {}))(1, 0, 'Selesai', ''), null);
  assert.equal(islandModel(sh, 8, 3).rows[1][0].bg, '');
});

test('pulau: sel galat rumus tidak diwarnai (sama dengan grid)', () => {
  const sh = sample(); const t = sh.tabs[0]; const d = makeDisplay(t, {});
  const pk = pickPainter(t, { err: (i) => i === 1 });
  assert.equal(pk(1, 0, 'Selesai', ''), null); assert.deepEqual(pk(2, 0, 'Selesai', ''), { bg: '#BBF7D0' });
  assert.ok(d);
});

test('ekspor: hanya sel berisian warna pilihan yang membawa bg + fg eksplisit; warna manual tetap tidak diekspor', () => {
  const m = exportModel(sample()), col = (i) => m.rows[i][0];
  assert.equal(col(1).bg, '#BBF7D0'); assert.equal(col(1).fg, '#111827', 'isian terang -> teks gelap');
  assert.equal(col(2).bg, '#1E3A8A'); assert.equal(col(2).fg, '#F9FAFB', 'isian gelap -> teks terang');
  assert.equal('bg' in col(3), false, 'gaya manual tidak diekspor (keputusan lama) dan juga mematikan warna pilihan');
  assert.equal('bg' in col(0), false); assert.equal('bg' in col(4), false);
  assert.equal('bg' in col(5), false, 'warna teks saja tanpa isian tidak diekspor (bisa hilang di kertas)');
});

test('ekspor: blok tabel dan tata letak membawa bg/fg ke sel baris; TXT/MD tidak terpengaruh', () => {
  const sh = sample(), m = exportModel(sh);
  const blocks = sheetBlocks(m), tb = blocks.find((b) => b.kind === 'table');
  assert.equal(tb.rows[1][0].bg, '#BBF7D0'); assert.equal(tb.rows[1][0].fg, '#111827'); assert.equal('bg' in tb.rows[0][0], false);
  const html = '<div class="ksheet" contenteditable="false" data-sheet="sabc123"></div>';
  const o = { width: 1240, pageH: 1754, padX: 110, padTop: 120, padBottom: 130, size: 30, titleSize: 46, measure };
  const lines = layoutDoc({ title: 'T', blocks: parseNoteHtml(html, new Date(), (id) => (id === 'sabc123' ? exportModel(sh) : null)) }, o);
  const rows = lines.filter((l) => l.kind === 'tableRow');
  assert.equal(rows[1].cells[0].bg, '#BBF7D0'); assert.equal(rows[1].cells[0].fg, '#111827'); assert.equal('bg' in rows[0].cells[0], false);
  assert.equal(rows[2].cells[0].bg, '#1E3A8A');
});

test('kode: penggambar PDF/JPG mengisi sel + memaksa warna teks eksplisit; modul validasi tetap murni; versi/skema tetap; tes terdaftar', () => {
  const sh = src('src/js/share.js');
  assert.ok(sh.includes("if (c.bg && HEX.test(c.bg)) { g.fillStyle = c.bg; g.fillRect(x, y, c.w, l.lh); }"));
  assert.ok(sh.includes('drawRuns(segs, x + c.padX + off, base, c.bg ? c.fg : undefined)'));
  assert.ok(sh.includes("const col = force && HEX.test(force) ? force :"));
  assert.doesNotMatch(src('src/js/lembar-validasi.js'), /^import /m);
  assert.match(src('src/js/lembar-pulau.js'), /from '\.\/lembar-validasi\.js'/);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(pk.scripts.test.includes('tests/rev268.test.mjs'));
  assert.equal(src('src/js/storage.js').match(/SCHEMA\s*=\s*(\d+)/)[1], '22');
});
