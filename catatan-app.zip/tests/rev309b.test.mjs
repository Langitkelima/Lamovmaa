// Rev 309b / v0.3.121: tab Riwayat token (isi, pengelompokan, hapus). Tampilan nyata diaudit di Chromium (tools/audit_riwayat_token.py).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { kelompok, labelHari, jam, SRC_LABEL } from '../src/js/ai/riwayatui.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 15, 12, 0, 0).getTime(), H = 86400000;
test('kelompok: per hari lokal, terbaru di atas, total per hari, label Hari ini / Kemarin / tanggal', () => {
  const list = [{ t: NOW - 2 * H, in: 1, out: 1, m: 'c', src: [] }, { t: NOW - 3600000, in: 10, out: 5, m: 'b', src: [] }, { t: NOW - 7200000, in: 2, out: 3, m: 'a', src: [] }, { t: NOW - H, in: 4, out: 4, m: 'k', src: [] }];
  const g = kelompok(list, NOW); assert.deepEqual(g.map((x) => x.label), ['Hari ini', 'Kemarin', 'Jum, 13 Nov']);
  assert.equal(g[0].total, 20); assert.deepEqual(g[0].items.map((e) => e.m), ['b', 'a']); assert.equal(labelHari(NOW, NOW), 'Hari ini');
});
test('jam berformat 2 digit; label sumber Tugas, Proyek, Lampiran, Baca foto (Rev 353)', () => { assert.equal(jam(new Date(2026, 10, 15, 7, 5).getTime()), '07.05'); assert.deepEqual(Object.keys(SRC_LABEL), ['tugas', 'proyek', 'lampiran', 'ocr']); });
test('tab Riwayat: diisi saat dibuka, keadaan kosong baru, tombol Hapus riwayat dengan konfirmasi, isi dibuat lewat h() bukan innerHTML', () => {
  const ob = src('src/js/ai/obrolan.js'), ui = src('src/js/ai/riwayatui.js');
  assert.match(ob, /import \{ isiRiwayat \} from '\.\/riwayatui\.js'/); assert.match(ob, /if \(id === 'riwayat'\) isiRiwayat\(pRiwayat\)/); assert.doesNotMatch(ob, /Riwayat token menyusul/);
  assert.ok(ui.includes("'Belum ada riwayat'") && ui.includes("'Hapus riwayat'") && ui.includes('red: true') && ui.includes('hapusSemua(store)'));
  assert.doesNotMatch(ui, /innerHTML|insertAdjacentHTML|outerHTML|document\.write|localStorage/); assert.doesNotMatch(ob, /localStorage|sessionStorage/);
});
test('ringkasan 3 kartu, grafik 7 hari (role=img), log per pesan, tanda perkiraan', () => {
  const ui = src('src/js/ai/riwayatui.js');
  for (const k of ["'Hari ini'", "'7 hari'", "'Bulan ini'", "role: 'img'", "'Per pesan'", "'\\u2248 '", 'tujuhHari(', 'ringkasan(', 'kelompok(']) assert.ok(ui.includes(k), k);
});
test('CSS riwayat memakai variabel tema (terang + gelap), tanpa warna mentah; cssMaks 270 KB (Rev 383)', () => {
  const css = src('src/css/styles.css'), seg = css.slice(css.indexOf('.rt-ks{'), css.indexOf('.kd-row:active,.kd-act:active'));
  assert.ok(seg.length > 1000); assert.doesNotMatch(seg, /#[0-9a-f]{3,8}\b/i); assert.match(seg, /var\(--ac\)/);
  assert.match(src('tools/audit-ukuran.mjs'), /cssMaks: 270 \* 1024/); assert.ok(Buffer.byteLength(css) < 270 * 1024);
});
