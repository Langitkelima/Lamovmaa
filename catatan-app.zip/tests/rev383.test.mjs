// Rev 383 / PART AL3c: pemeliharaan tes lama. Revisi ini HANYA tes + dokumen: kode aplikasi, Worker, native, versi, dan SCHEMA tidak berubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const walk = (d) => fs.readdirSync(new URL('../' + d, import.meta.url), { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(d + '/' + e.name) : [d + '/' + e.name]));
test('banner Rev 383 paling atas di serah terima dan riwayat (di atas Rev 382) dan menyebut rev330 sebagai temuan yang sengaja tidak diperbaiki', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) {
    const d = rd(f); assert.ok(/\*\*Rev 383b? \/ v0\.3\.121/.test(d), f); assert.ok(d.indexOf('**Rev 383') < d.indexOf('**Rev 382') && d.indexOf('**Rev 382') < d.indexOf('**Rev 381'), f);
    const b = d.slice(0, d.indexOf('**Rev 382')); assert.ok(b.includes('rev330') && b.includes('alarm-ui.js') && b.includes('settings.js') && b.includes('TIDAK DIPERBAIKI SENGAJA') && b.includes('BELUM TERBUKTI'), f);
  }
});
test('kode TIDAK berubah di revisi ini: tidak ada penanda Rev 383 di src/, scripts/, backend/; versi 0.3.121 dan SCHEMA 22 tetap', () => {
  for (const f of [...walk('src'), ...walk('scripts'), ...walk('backend')]) if (/\.(js|mjs|css|html)$/.test(f)) assert.ok(!/Rev 383(?!b)/.test(rd(f)), f); /* Rev 383b: penanda 'Rev 383b' boleh ada di kode (perbaikan 2 toast) */
  assert.equal(JSON.parse(rd('package.json')).version, '0.3.121'); assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/);
});
test('batas CSS di tes lama kini sama dengan anggaran resmi cssMaks 270 KB: tidak ada lagi angka usang 250 KB di tujuh tes yang diselaraskan', () => {
  assert.match(rd('tools/audit-ukuran.mjs'), /cssMaks: 270 \* 1024/);
  for (const t of ['rev302a', 'rev302b', 'rev302c', 'rev303b', 'rev303c', 'rev309b', 'rev373']) { const s = rd('tests/' + t + '.test.mjs'); assert.ok(s.includes('270 * 1024'), t); assert.ok(!/<=? ?250 \* 1024/.test(s), t); }
  assert.ok(Buffer.byteLength(rd('src/css/styles.css')) < 270 * 1024);
});
test('package.json mendaftarkan rev383 sesudah rev382; README < 12000 huruf dan menyebut Rev 383', () => {
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.includes('node tests/rev383.test.mjs') && t.indexOf('rev382.test.mjs') < t.indexOf('rev383.test.mjs'));
  const r = rd('README.md'); assert.ok(r.length < 12400, String(r.length)); assert.match(r, /Rev 383/);
});
