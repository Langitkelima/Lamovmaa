// Tes Rev 25: duplikat catatan (fungsi murni), header editor + menu ⋮, bagian "Catatan terkait" muncul hanya bila dipakai.
// Tampilan dicek terpisah di Chromium (lihat RIWAYAT); tes ini = logika murni + pemeriksaan sumber. BUKAN uji di HP.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/logic.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const asli = () => ({ id: 'a1', title: 'Rencana', text: 'isi', html: '<b>isi</b> <span style="color:#d63a55">merah</span>', col: '#f4c2c2', pin: true,
  updated: 1000, labels: ['l1', 'l2'], links: ['x9'], reminder: { at: 5000, repeat: 'daily' }, prev: { 'https://a.id': { t: 'A', s: 'a.id', i: '' } }, deleted: true });

await t('duplicateNote: aslinya tidak berubah, id baru, waktu edit = sekarang', () => {
  const a = asli(), snap = JSON.stringify(a);
  const c = L.duplicateNote(a, { id: 'b2', now: 9000 });
  assert.equal(JSON.stringify(a), snap);
  assert.equal(c.id, 'b2'); assert.equal(c.updated, 9000);
  assert.notEqual(L.duplicateNote(a).id, L.duplicateNote(a).id, 'id otomatis unik');
});
await t('duplicateNote: isi, warna, label disalin; sematan, pengingat, hubungan, status sampah TIDAK ikut', () => {
  const c = L.duplicateNote(asli(), { id: 'b2', now: 9000 });
  assert.equal(c.html, asli().html); assert.equal(c.text, 'isi'); assert.equal(c.col, '#f4c2c2');
  assert.deepEqual(c.labels, ['l1', 'l2']);
  assert.equal(c.pin, false);
  for (const k of ['reminder', 'links', 'deleted']) assert.ok(!(k in c), k + ' tidak boleh ikut');
});
await t('duplicateNote: larik label dan pratinjau adalah salinan (mengubah salinan tidak mengubah asli)', () => {
  const a = asli(); const c = L.duplicateNote(a, { id: 'b2', now: 1 });
  c.labels.push('l3'); c.prev['https://a.id'].t = 'Z';
  assert.deepEqual(a.labels, ['l1', 'l2']); assert.equal(a.prev['https://a.id'].t, 'A');
});
await t('duplicateNote: judul "Salinan ..." hanya bila asli punya judul; tanpa judul tetap tanpa judul', () => {
  assert.equal(L.duplicateNote({ title: 'Rencana' }, { id: 'x' }).title, 'Salinan Rencana');
  assert.equal(L.duplicateNote({ title: '   ' }, { id: 'x' }).title, '');
  assert.equal(L.duplicateNote({ title: '' }, { id: 'x' }).title, '');
  assert.equal(L.duplicateNote({ title: 'Salinan Rencana' }, { id: 'x' }).title, 'Salinan Salinan Rencana');
  assert.equal(L.copyTitle(undefined), '');
});
await t('duplicateNote: catatan tanpa label/warna/pratinjau tetap bersih; masukan aneh tidak melempar', () => {
  const c = L.duplicateNote({ id: 'q', title: 't', text: 'x', html: 'x' }, { id: 'n', now: 1 });
  assert.ok(!('labels' in c) && !('prev' in c)); assert.equal(c.col, ''); assert.equal(c.pin, false);
  for (const bad of [null, undefined, 5, 'x', []]) assert.doesNotThrow(() => L.duplicateNote(bad, { id: 'z', now: 1 }));
  assert.ok(Number.isFinite(L.duplicateNote({}, {}).updated));
});
await t('addDuplicate: catatan biasa masuk data.notes; Catatan Privat tetap di data.priv (tidak pernah pindah)', () => {
  const d = { notes: [asli()], priv: [asli()], trash: [] };
  const c1 = L.addDuplicate(d, 'note', d.notes[0], { id: 'n1', now: 1 });
  assert.equal(d.notes.length, 2); assert.equal(d.priv.length, 1); assert.equal(d.notes[1], c1);
  const c2 = L.addDuplicate(d, 'priv', d.priv[0], { id: 'p1', now: 2 });
  assert.equal(d.priv.length, 2); assert.equal(d.notes.length, 2); assert.equal(d.priv[1], c2);
  assert.equal(d.trash.length, 0);
});
await t('salinan naik ke posisi terbaru dan tidak tersemat (sortNotes)', () => {
  const a = { ...asli(), pin: false, updated: 100 }; const b = { id: 'z', title: 'lain', updated: 500 };
  const c = L.duplicateNote(a, { id: 'c', now: 900 });
  assert.deepEqual(L.sortNotes([a, b, c]).map((x) => x.id), ['c', 'z', 'a1']);
});

// ---- Pemeriksaan sumber ----
const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css'), main = src('../src/js/main.js');
await t('sumber: header = panah kembali, status + chip label, penanda, tombol mode, dan ⋮ di kanan; ikon lama dipindah ke menu', () => {
  const i = nt.indexOf("const head = h('div', { class: 'fsh' },"), j = nt.indexOf("const body = h('div', { class: 'fsb' }");
  const hd = nt.slice(i, j);
  for (const k of ['Kembali', "class: 'hmid'", "class: 'stp' }, svt, edt)", 'marks, modeBtn, moreBtn']) assert.ok(hd.includes(k), k);
  assert.ok(nt.includes("h('div', { class: 'hmk' }, hlab, linkMark, remMark, pinMark)"), 'label + penanda di pojok kanan');
  for (const k of ['Label catatan', 'Warna catatan', 'Bagikan catatan', 'Hapus catatan', 'pinBtn']) assert.ok(!hd.includes(k), 'tidak boleh lagi di header: ' + k);
  assert.ok(nt.includes("'aria-label': 'Menu catatan'") && nt.includes('icoMenu()'));
});
await t('sumber: urutan item menu = Label, Ubah warna, Hubungkan, Sematkan, Bagikan, Buat salinan, pemisah, Hapus (merah, paling bawah)', () => {
  const i = nt.indexOf('function openMenu()'); const m = nt.slice(i, nt.indexOf("menuOv = h('div'", i));
  const order = ["'Label'", "'Ubah warna'", "'Hubungkan catatan'", "'Lepas sematan' : 'Sematkan'", "'Bagikan'", "'Buat salinan'", "class: 'mdv'", "'Hapus'"];
  let at = -1; for (const k of order) { const p = m.indexOf(k); assert.ok(p > at, 'urutan salah di ' + k); at = p; }
  assert.ok(m.includes("'red'"));
  for (const k of ["isP ? null : mi(PATH.link", "isP ? null : mi(PATH.pin", "isP ? null : mi(PATH.share"]) assert.ok(m.includes(k), 'Privat tidak boleh: ' + k);
  assert.ok(!/isP \? null : mi\(PATH\.copy/.test(m), 'Buat salinan berlaku juga untuk Privat');
});
await t('sumber: menu menutup dulu baru menjalankan aksi; blur keyboard; Escape; ditutup tombol Kembali sebelum editor', () => {
  assert.ok(nt.includes('onclick: () => { closeMenu(); fn(); }'));
  assert.ok(nt.includes('document.activeElement.blur(); // tutup keyboard'));
  assert.ok(nt.includes("e.key === 'Escape'") && nt.includes("document.removeEventListener('keydown', menuKey)"));
  assert.ok(nt.includes('current = { kind, close: closeNow, back: done, menu: () => closeMenu() || closeLp() }') && nt.includes('export function closeEditorMenu()'));
  const hb = main.indexOf('function handleBack');
  assert.ok(main.indexOf('closeEditorMenu()', hb) > main.indexOf('closeDialog()', hb) && main.indexOf('closeEditorMenu()', hb) < main.indexOf('backEditor()', hb));
  assert.ok(nt.includes('const cleanup = () => { alive = false; closeViewer(); closeMenu();'), 'menu ikut dibersihkan saat editor ditutup');
});
await t('sumber: penanda pin hanya informasi; titik warna kecil dihapus (Rev 25b); alarm/tautan mengikuti status', () => {
  assert.ok(nt.includes("const pinUi = () => { pinMark.style.display = n.pin ? '' : 'none'; };"));
  assert.ok(!nt.includes('colMark') && !css.includes('.cdot'), 'titik warna kecil tidak boleh ada lagi');
  assert.ok(nt.includes("pinMark = h('span', { class: 'hb hpin'"), 'pin = penanda info (span), bukan tombol');
  assert.ok(nt.includes('if (linkMark) linkMark.style.display') && nt.includes('const remUi = () =>'));
});
await t('sumber: chip label di pojok kanan header hanya bila ada label (maks. 1 + "+N"), ketuk = pemilih label yang ada', () => {
  assert.ok(nt.includes('mine.slice(0, 1)') && nt.includes("'+' + rest") && nt.includes('onclick: () => openLp()'));
  assert.ok(!nt.includes("'+ Label'"), 'tombol "+ Label" lama di badan catatan dihapus');
  assert.ok(/\.hlab:empty\{display:none\}/.test(css));
});
await t('sumber: "Catatan terkait" hanya bila ada hubungan, "Disebut di" hanya bila ada hubungan balik, "+" kecil menambah', () => {
  const i = nt.indexOf('const relUi = () => {'); const r = nt.slice(i, nt.indexOf('function openPicker()'));
  assert.ok(r.includes("rel.style.display = out.length || inn.length ? '' : 'none'"));
  assert.ok(r.includes('out.length ? [h(') && r.includes('inn.length ? [h('));
  assert.ok(r.includes("'aria-label': 'Ubah hubungan catatan'") && r.includes("}, '+')"));
  assert.ok(!r.includes('+ Hubungkan catatan'));
});
await t('sumber: Buat salinan menyimpan dulu, menolak catatan kosong, toast "Salinan dibuat" + tombol Buka, editor asli tetap terbuka', () => {
  const i = nt.indexOf('function doDuplicate()'); const d = nt.slice(i, nt.indexOf('// Pratinjau tautan', i));
  assert.ok(d.indexOf('save();') >= 0 && d.indexOf('save();') < d.indexOf('addDuplicate('));
  assert.ok(d.includes('if (!list.includes(n))') && d.includes("isP ? 'priv' : 'note'"));
  assert.ok(d.includes("toast('Salinan dibuat'") && d.includes("'Buka'"));
  assert.ok(!d.includes('closeNow();\n    const copy'), 'editor asli tidak ditutup saat menyalin');
  assert.ok(nt.includes("if (isP && dupToast && dupToast.isConnected) dupToast.remove()"), 'tombol Buka salinan privat tidak bertahan setelah editor ditutup');
});
await t('sumber: toast kini di atas editor (z-index 8 > 7) dan di bawah dialog (9); label tombol toast bisa diganti', () => {
  assert.ok(/\.toast\{[^}]*z-index:8/.test(css) && /\.fs\{[^}]*z-index:7/.test(css) && /\.ov\.dlgov\{[^}]*z-index:9/.test(css));
  const ui = src('../src/js/ui.js'); assert.ok(ui.includes("export function toast(msg, undo, after, label = 'Urungkan', tone)") && ui.includes('}, label));'));
});
await t('tanpa perubahan data/native: SCHEMA 8 sejak Rev 60, workflow/native tidak disentuh', () => {
  assert.match(src('../src/js/storage.js'), /SCHEMA = 22/);
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
});
console.log(n + ' tes lulus (salinan)');
