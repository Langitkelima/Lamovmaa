// Rev 331 / PART TC: desain ulang toast = varian A (kapsul warna penuh) + garis waktu; tumpuk maks. 2; geser untuk tutup; jeda saat disentuh.
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const ui = readFileSync(new URL('../src/js/ui.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const blk = css.slice(css.indexOf('/* Rev 331 / TC'));

class Cl { constructor(e) { this.e = e; } add(c) { if (!this.contains(c)) this.e.className = (this.e.className + ' ' + c).trim(); } remove(c) { this.e.className = this.e.className.split(/\s+/).filter((x) => x && x !== c).join(' '); } contains(c) { return this.e.className.split(/\s+/).includes(c); } }
class El {
  constructor(tag) { this.tag = tag; this.attrs = {}; this.kids = []; this.className = ''; this.ls = {}; this.classList = new Cl(this); this.removed = false; this.offsetHeight = 40;
    const pr = {}; this.props = pr; this.style = { setProperty: (k, v) => { pr[k] = v; }, removeProperty: (k) => { delete pr[k]; }, set animationDuration(v) { pr.ad = v; }, set animationPlayState(v) { pr.aps = v; }, opacity: '' }; }
  get id() { return this.attrs.id || ''; } set id(v) { this.attrs.id = v; }
  setAttribute(k, v) { this.attrs[k] = v; } removeAttribute(k) { delete this.attrs[k]; }
  addEventListener(n, f) { (this.ls[n] ||= []).push(f); } fire(n, ev = {}) { for (const f of this.ls[n] || []) f({ target: { closest: () => null }, pointerId: 1, ...ev }); }
  append(...k) { for (const c of k) this.kids.push(c); } setPointerCapture() {}
  remove() { this.removed = true; const i = body.kids.indexOf(this); if (i >= 0) body.kids.splice(i, 1); }
  get tx() { return this.kids.find((k) => k.className === 'tx'); } get tact() { return this.kids.find((k) => k.className === 'tact'); }
}
class Tx { constructor(t) { this.nodeType = 3; this.text = t; } }
const body = new El('body');
const match = (e, sel) => sel === '#toast' ? e.id === 'toast' : sel === '.toast.tko' ? e.classList.contains('toast') && e.classList.contains('tko') : false;
globalThis.document = { body: Object.assign(body, { append: (...k) => body.kids.push(...k) }), createElement: (t) => { const e = new El(t); e.nodeType = 1; return e; }, createElementNS: (n, t) => { const e = new El(t); e.nodeType = 1; return e; }, createTextNode: (t) => new Tx(t), querySelector: (s) => body.kids.find((e) => match(e, s)) || null };
globalThis.window = { innerHeight: 800, visualViewport: { height: 800, offsetTop: 0 } };
const { toast, tOk, tWarn } = await import('../src/js/ui.js');
const toasts = () => body.kids.filter((e) => e.classList.contains('toast'));
let tmr = []; const realST = globalThis.setTimeout, realCT = globalThis.clearTimeout;
globalThis.setTimeout = (f, ms) => { const o = { f, ms, off: false }; tmr.push(o); return o; }; globalThis.clearTimeout = (o) => { if (o) o.off = true; };
const live = () => tmr.filter((x) => !x.off);

test('Rev 331: toast punya garis waktu .tpg dengan durasi sama dengan lamanya tampil', () => {
  tmr = []; body.kids.length = 0;
  tOk('Tersimpan');
  const t = toasts()[0], pg = t.kids.find((k) => k.className === 'tpg');
  assert.ok(pg, 'ada .tpg');
  assert.equal(pg.attrs.style, 'animation-duration:4500ms'); // toastMs ok, pesan pendek
  assert.equal(live().at(-1).ms, 4500);
});
test('Rev 331: tumpuk maksimal 2; yang baru memegang id=toast, yang lama jadi .tko dan naik lewat --ty', () => {
  tmr = []; body.kids.length = 0;
  tOk('Satu'); tWarn('Dua'); tOk('Tiga');
  const ts = toasts(); assert.equal(ts.length, 2, 'maks. 2');
  assert.ok(ts[0].classList.contains('tko') && ts[0].id === '' && ts[0].props['--ty'] === '-46px');
  assert.equal(ts[1].id, 'toast'); assert.ok(!ts[1].classList.contains('tko'));
  assert.match(ts[0].kids[1].kids.map((k) => k.text).join(''), /Dua/); // Satu terlempar, Dua jadi lama
});
test('Rev 331: menutup toast terbaru menurunkan yang lama menjadi #toast', () => {
  tmr = []; body.kids.length = 0;
  tOk('Lama'); tOk('Baru');
  toasts()[1].tx.fire('click');
  const ts = toasts(); assert.equal(ts.length, 1);
  assert.equal(ts[0].id, 'toast'); assert.ok(!ts[0].classList.contains('tko')); assert.equal(ts[0].props['--ty'], undefined);
});
test('Rev 331: tombol Urungkan di toast lama tetap jalan dan menutup hanya toast itu', () => {
  tmr = []; body.kids.length = 0; let n = 0;
  toast('Dihapus', () => { n++; }, null, 'Urungkan', 'ok'); tOk('Baru');
  const lama = toasts()[0]; lama.tact.fire('click');
  assert.equal(n, 1); assert.equal(toasts().length, 1); assert.equal(toasts()[0].id, 'toast');
});
test('Rev 331: geser > 70px menutup; geser pendek kembali; saat disentuh timer dijeda dan garis berhenti', () => {
  tmr = []; body.kids.length = 0;
  tOk('Geser'); const t = toasts()[0], pg = t.kids.find((k) => k.className === 'tpg');
  t.fire('pointerdown', { clientX: 100 }); assert.equal(pg.props.aps, 'paused'); assert.ok(t.classList.contains('tkh')); assert.ok(live().length === 0, 'timer dihentikan');
  t.fire('pointermove', { clientX: 130 }); assert.equal(t.props['--dx'], '30px');
  t.fire('pointerup'); assert.equal(t.props['--dx'], '0px'); assert.equal(pg.props.aps, 'running'); assert.equal(live().length, 1, 'timer jalan lagi'); assert.ok(toasts().length === 1);
  t.fire('pointerdown', { clientX: 100 }); t.fire('pointermove', { clientX: 20 }); t.fire('pointerup');
  assert.equal(t.props['--dx'], '-500px'); live().at(-1).f(); assert.equal(toasts().length, 0, 'geser jauh menutup');
});
test('Rev 331: menyentuh tombol tidak memulai geser', () => {
  tmr = []; body.kids.length = 0; tOk('X'); const t = toasts()[0];
  t.fire('pointerdown', { clientX: 1, target: { closest: () => ({}) } }); assert.ok(!t.classList.contains('tkh'));
});
test('Rev 331: CSS = translate (bukan transform), garis waktu, reduced-motion, tanpa hex/rgba, tinggi garis 3px', () => {
  assert.match(blk, /\.toast\[class\]\{translate:var\(--dx,0px\) var\(--ty,0px\);/);
  assert.match(blk, /\.tpg\{[^}]*height:3px;[^}]*animation:tpg linear forwards/);
  assert.match(blk, /@keyframes tpg\{from\{transform:scaleX\(1\)\}to\{transform:scaleX\(0\)\}\}/);
  assert.match(blk, /prefers-reduced-motion:reduce\)\{[^}]*transition:none\}[^}]*\.tpg\{display:none\}/);
  assert.ok(!/#[0-9a-f]{3,8}\b|rgba\(/i.test(blk));
  assert.ok(!/transform:/.test(blk.split('@keyframes')[0]), 'geser/tumpuk jangan memakai transform (bentrok dengan a2-up)');
});
test('Rev 331: ui.js menjaga kontrak lama (tanda tangan toast, id toast, tombol Tutup, naik di atas keyboard)', () => {
  assert.match(ui, /export function toast\(msg, undo, after, label = 'Urungkan', tone\)/);
  assert.match(ui, /id: 'toast'/); assert.match(ui, /aria-label': 'Tutup'/); assert.match(ui, /visualViewport/);
});
after(() => { globalThis.setTimeout = realST; globalThis.clearTimeout = realCT; });
