// Rev 336 / PART I1: mesin pemicu ketikan tersembunyi (murni). Tanpa UI, tanpa pemanggil.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { detectTrigger, evalExpr, formatCalc, parseRemind, filterSlash, normalizeTag, SLASH_COMMANDS, TRIGGER_KINDS } from '../src/js/ketik-pemicu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 18, 10, 0, 0); // Rab 18 Nov 2026 10.00 (jam lokal)
const D = (y, mo, d, h, mi) => new Date(y, mo, d, h, mi, 0, 0).getTime();

test('hitung: dasar, prioritas, pangkat, minus satuan, persen', () => {
  assert.equal(evalExpr('12*3').v, 36);
  assert.equal(evalExpr('2+3*4').v, 14);
  assert.equal(evalExpr('(2+3)*4').v, 20);
  assert.equal(evalExpr('2^3^2').v, 512, 'pangkat kanan-asosiatif');
  assert.equal(evalExpr('-2^2').v, -4);
  assert.equal(evalExpr('2^-1').v, 0.5);
  assert.equal(evalExpr('200*10%').v, 20);
  assert.equal(evalExpr('7×6').v, 42);
  assert.equal(evalExpr('9÷3').v, 3);
  assert.equal(evalExpr('0,1+0,2').v, 0.3, 'tidak ada ekor 0,30000000000000004');
});
test('hitung: angka Indonesia (koma desimal, titik ribuan, rb/jt)', () => {
  assert.equal(evalExpr('1.500.000+500.000').v, 2000000);
  assert.equal(evalExpr('12,5*2').v, 25);
  assert.equal(evalExpr('12.5*2').v, 25, 'titik bukan ribuan = desimal');
  assert.equal(evalExpr('1.500,5*2').v, 3001);
  assert.equal(evalExpr('2jt+500rb').v, 2500000);
  assert.equal(evalExpr('1,5jt*2').v, 3000000);
  assert.equal(evalExpr('5 ribu*3').v, 15000);
  assert.equal(evalExpr('2 juta/4').v, 500000);
});
test('hitung: yang tidak sah atau berbahaya = null (tanpa eval)', () => {
  for (const s of ['', '2+', '*3', '(2+3', '2+3)', '1.5.3*2', '10/0', 'abc*2', '2**3', '1e5*2', 'alert(1)', '2 3', '9^9^9^9']) assert.equal(evalExpr(s), null, s);
  assert.equal(evalExpr('((((((((((((((((((((((((1+1))))))))))))))))))))))))'), null, 'kedalaman dibatasi');
  assert.equal(evalExpr('1+'.repeat(40) + '1'), null, 'jumlah token dibatasi');
  assert.equal(evalExpr('99999999*99999999'), null, 'hasil >= 1e15 ditolak');
});
test('hitung: angka polos tanpa operator tidak dianggap ekspresi (ops 0)', () => {
  assert.equal(evalExpr('5').ops, 0);
  assert.equal(evalExpr('5rb').ops, 1);
  assert.equal(evalExpr('5%').ops, 1);
});
test('formatCalc: titik ribuan, koma desimal, tanpa nol di ujung, tanpa -0', () => {
  assert.equal(formatCalc(1500000), '1.500.000');
  assert.equal(formatCalc(0.5), '0,5');
  assert.equal(formatCalc(-1234.5), '-1.234,5');
  assert.equal(formatCalc(0.1 + 0.2), '0,3');
  assert.equal(formatCalc(-1e-12), '0');
  assert.equal(formatCalc(100), '100');
  assert.equal(formatCalc(NaN), '');
});

test('pemicu calc: 12*3= -> saran 36; rentang tepat; teks di depan dilewati', () => {
  const r = detectTrigger('12*3=');
  assert.deepEqual([r.kind, r.start, r.end, r.value, r.text, r.expr], ['calc', 0, 5, 36, '36', '12*3']);
  const r2 = detectTrigger('Total belanja 2jt+500rb=');
  assert.equal(r2.kind, 'calc'); assert.equal(r2.start, 14); assert.equal(r2.text, '2.500.000'); assert.equal(r2.end, 24);
  assert.equal(detectTrigger('5='), null, 'angka polos + = tidak memicu');
  assert.equal(detectTrigger('2026='), null);
  assert.equal(detectTrigger('10/0='), null);
  assert.equal(detectTrigger('12*3'), null, 'harus diakhiri =');
  assert.equal(detectTrigger('Bayar 5 12*3=').expr, '12*3', 'angka lepas di depan tidak ikut');
  assert.equal(detectTrigger('kata-kata 5*2=').expr, '5*2');
});
test('pemicu kotak centang dan daftar bernomor: hanya persis di awal baris', () => {
  assert.deepEqual(detectTrigger('[] '), { kind: 'checkbox', start: 0, end: 3, raw: '[] ' });
  assert.deepEqual(detectTrigger('1. '), { kind: 'numbered', start: 0, end: 3, raw: '1. ' });
  for (const s of ['[]', 'a [] ', ' [] ', '2. ', '1.', 'x1. ', '11. ']) assert.equal(detectTrigger(s), null, JSON.stringify(s));
});
test('pemicu [[ : pencarian judul, [[ terbuka menang atas hitung cepat', () => {
  assert.deepEqual(detectTrigger('Lihat [[Rapat'), { kind: 'wiki', start: 6, end: 13, query: 'Rapat' });
  assert.equal(detectTrigger('[[').query, '');
  assert.equal(detectTrigger('[[Rapat 2+2=').kind, 'wiki');
  assert.equal(detectTrigger('[[Rapat]]'), null, 'sudah tertutup');
  assert.equal(detectTrigger('[[' + 'a'.repeat(61)), null, 'terlalu panjang');
});
test('pemicu #tag: sah, lengkap saat diikuti spasi, bukan nomor atau warna', () => {
  assert.deepEqual(detectTrigger('#kerja'), { kind: 'tag', start: 0, end: 6, tag: 'kerja', complete: false });
  assert.deepEqual(detectTrigger('catat #kerja '), { kind: 'tag', start: 6, end: 13, tag: 'kerja', complete: true });
  assert.equal(detectTrigger('#proyek-baru_1 ').tag, 'proyek-baru_1');
  assert.equal(detectTrigger('#Écran ').tag, 'Écran', 'huruf non-ASCII sah');
  for (const s of ['#123 ', '#1', '# ', 'a#kerja', '#kerja.', '#' + 'a'.repeat(21)]) assert.equal(detectTrigger(s), null, s);
  assert.equal(normalizeTag('a'.repeat(20)), 'a'.repeat(20)); assert.equal(normalizeTag('a'.repeat(21)), '');
});
test('pemicu / : awal baris atau sesudah spasi; URL, tanggal, dan jalur tidak memicu', () => {
  const r = detectTrigger('/tab');
  assert.deepEqual([r.kind, r.start, r.end, r.query, r.items.map((c) => c.id)], ['slash', 0, 4, 'tab', ['table']]);
  assert.equal(detectTrigger('baris /').start, 6);
  assert.equal(detectTrigger('/').items.length, SLASH_COMMANDS.length);
  for (const s of ['http://x', 'dan/atau', '1/2', '/home/user', 'a/b', '/' + 'a'.repeat(13)]) assert.equal(detectTrigger(s), null, s);
});
test('menu cepat: penyaringan (awalan dulu, kata kunci, urutan daftar tetap)', () => {
  assert.deepEqual(filterSlash('tab').map((c) => c.id), ['table']);
  assert.deepEqual(filterSlash('ta').map((c) => c.id), ['table', 'date', 'bullet', 'todo'], 'awalan (Tabel, Tanggal) dulu, lalu potongan di tengah kata (daftar, kotak)');
  assert.deepEqual(filterSlash('hit').map((c) => c.id), ['countdown']);
  assert.deepEqual(filterSlash('KOTAK').map((c) => c.id), ['todo']);
  assert.deepEqual(filterSlash('zzz'), []);
  assert.equal(filterSlash('').length, 10);
  assert.deepEqual(SLASH_COMMANDS.map((c) => c.label), ['Judul', 'Daftar', 'Nomor', 'Kotak centang', 'Tabel', 'Kutipan', 'Tanggal', 'Suasana hati', 'Hitung mundur', 'Lembar kerja']);
});
test('pengingat !: jam, besok, nama hari, tanggal (tanpa menggeser waktu lampau)', () => {
  assert.deepEqual(parseRemind('jam 9', NOW), { when: D(2026, 10, 18, 9, 0), label: 'Hari ini 09.00', hasTime: true }, 'lampau tidak digeser');
  assert.equal(parseRemind('jam 14.30', NOW).when, D(2026, 10, 18, 14, 30));
  assert.equal(parseRemind('jam 14:30', NOW).when, D(2026, 10, 18, 14, 30));
  assert.equal(parseRemind('besok 9', NOW).when, D(2026, 10, 19, 9, 0));
  assert.equal(parseRemind('besok', NOW).label, 'Besok 09.00'); assert.equal(parseRemind('besok', NOW).hasTime, false);
  assert.equal(parseRemind('jumat 14.30', NOW).when, D(2026, 10, 20, 14, 30)); // Rab 18 -> Jum 20
  assert.equal(parseRemind('rabu 9', NOW).when, D(2026, 10, 25, 9, 0), 'hari ini sudah lewat = pekan depan');
  assert.equal(parseRemind('rabu 11', NOW).when, D(2026, 10, 18, 11, 0), 'hari ini masih ke depan = hari ini');
  assert.equal(parseRemind('15 des', NOW).when, D(2026, 11, 15, 9, 0));
  assert.equal(parseRemind('15 desember 8.15', NOW).label, '15 Des 08.15');
  assert.equal(parseRemind('10 nov', NOW).when, D(2027, 10, 10, 9, 0), 'tanggal lewat = tahun depan');
  for (const s of ['', 'jam', 'jam 25', 'jam 9.60', 'besok 99', '31 feb', '32 des', 'kemarin 9', '15 xyz', 'jam 9 10', 'x'.repeat(30)]) assert.equal(parseRemind(s, NOW), null, s);
});
test('pemicu !jam 9: hanya bila ! di awal/sesudah spasi dan seluruhnya sah', () => {
  const r = detectTrigger('Telepon !besok 9.30', { now: NOW });
  assert.deepEqual([r.kind, r.start, r.end, r.raw, r.label, r.when], ['remind', 8, 19, '!besok 9.30', 'Besok 09.30', D(2026, 10, 19, 9, 30)]);
  assert.equal(detectTrigger('!jam', { now: NOW }), null);
  assert.equal(detectTrigger('Wow!jam 9', { now: NOW }), null);
  assert.equal(detectTrigger('Wow! jam 9', { now: NOW }), null);
  assert.equal(detectTrigger('!ngawur 9', { now: NOW }), null);
});
test('konteks: hanya catatan biasa; Privat, sel tabel, lembar kerja tidak pernah memicu', () => {
  for (const ctx of ['private', 'cell', 'sheet', 'ai', null, '']) for (const s of ['12*3=', '#kerja ', '[[a', '/ta', '[] ', '1. ']) assert.equal(detectTrigger(s, { ctx, now: NOW }), null, ctx + ' ' + s);
  assert.equal(detectTrigger('12*3=', { ctx: 'note' }).kind, 'calc');
});
test('opsi only: pemicu yang dimatikan tidak muncul', () => {
  assert.equal(detectTrigger('12*3=', { only: ['tag'] }), null);
  assert.equal(detectTrigger('#a ', { only: ['tag'] }).kind, 'tag');
  assert.deepEqual(TRIGGER_KINDS, ['checkbox', 'numbered', 'bullet', 'calc', 'remind', 'wiki', 'tag', 'slash']); // Rev 358: 'bullet' ditambah (DISENGAJA)
});
test('masukan aneh: baris baru, kosong, bukan string, paragraf sangat panjang', () => {
  assert.equal(detectTrigger(''), null); assert.equal(detectTrigger(null), null); assert.equal(detectTrigger(undefined), null);
  assert.equal(detectTrigger('a\n12*3='), null, 'hanya satu baris');
  const long = 'x'.repeat(5000) + ' #ok';
  const r = detectTrigger(long); assert.deepEqual([r.kind, r.start, r.end, r.tag], ['tag', 5001, 5004, 'ok'], 'indeks tetap relatif ke teks utuh');
  const t0 = Date.now(); detectTrigger('1+'.repeat(500) + '2='); detectTrigger('9'.repeat(3000) + '*'); assert.ok(Date.now() - t0 < 500, 'cepat');
});

test('sumber: murni (tanpa impor, DOM, penyimpanan, eval) dan belum dipakai modul lain', () => {
  const s = src('src/js/ketik-pemicu.js');
  assert.doesNotMatch(s, /^\s*import\s/m); assert.doesNotMatch(s, /\bdocument\b|\bwindow\b|localStorage|\beval\s*\(|new Function|console\./);
  // Rev 337 / I4: SENGAJA dilonggarkan: hanya ketik-ui.js (tampilan, MALAS) yang boleh mengimpor mesin; modul lain tetap dilarang (notes.js memuatnya lewat ketik-ui.js, tidak langsung).
  for (const f of readdirSync(new URL('../src/js/', import.meta.url), { recursive: true }).filter((n) => n.endsWith('.js') && n !== 'ketik-pemicu.js' && n !== 'ketik-ui.js'))
    assert.doesNotMatch(src('src/js/' + f), /ketik-pemicu/, f + ' belum boleh mengimpor (hanya ketik-ui.js)');
});
test('tanpa versi/SCHEMA berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(pk.scripts.test, /node tests\/rev336\.test\.mjs/);
});
