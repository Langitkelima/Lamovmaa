// Tes Rev 36: panel label (Oke, hapus, +) dan menu bawah kapsul melayang.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css'), main = src('../src/js/main.js'), ui = src('../src/js/ui.js');

t('Rev 36: panel label punya tombol Oke yang menutup panel dan Kembali HP menutup panel label', () => {
  assert.ok(nt.includes("class: 'btn lpok', onclick: () => closeLp()"));
  assert.ok(nt.includes('menu: () => closeMenu() || closeLp()'));
});
t('Rev 36: kolom tambah label hanya muncul setelah ketuk chip +, bukan selalu tampil', () => {
  assert.ok(nt.includes("const lrow = h('div', { class: 'cpr', style: 'display:none' }, lnew, ladd)"));
  assert.ok(nt.includes("'aria-label': 'Tambah label baru'") && nt.includes("lrow.style.display = lAdding && !lDel ? '' : 'none'"));
});
t('Rev 36: mode hapus label meminta konfirmasi, memakai removeLabel, dan menyegarkan daftar label editor', () => {
  for (const k of ['const delLabel', "title: 'Hapus label?'", 'removeLabel(data, l.id); labelsAll = data.settings.labels;', "class: 'lab del'"]) assert.ok(nt.includes(k), k);
  assert.ok(nt.includes('let labelsAll = data.settings.labels'));
});
t('Rev 36: menu bawah = Tugas, Catatan, Private, Setelan (ikon roda gigi) dengan penanda geser', () => {
  assert.ok(main.includes("['privat', 'Private'], ['lainnya', 'Setelan']"));
  assert.ok(ui.includes('lainnya: ') && !ui.includes("lainnya: 'M5 12h.01M12 12h.01M19 12h.01'"));
  assert.ok(main.includes("class: 'navind'") && main.includes('navEl.dataset.i'));
  for (const k of ['.navind{', 'border-radius:33px', 'margin:0 14px calc(10px + var(--sab))']) assert.ok(css.includes(k), k);
  assert.ok(css.includes('prefers-reduced-motion:reduce){.navbg path,.navind'));
});
console.log(n + ' tes lulus (Rev 36 label + menu bawah)');
