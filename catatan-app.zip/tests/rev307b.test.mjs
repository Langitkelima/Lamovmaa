// Rev 307b: Worker menghitung token "pikir" Gemini (thoughtsTokenCount) sebagai token keluar, sehingga usage per permintaan dan token bulanan akurat. Fetch PALSU; KV tiruan. Bukan bukti dari Gemini nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const env0 = () => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), GEMINI_KEY: 'gm-FAKE-0123456789-tes' });
const NOW = Date.UTC(2026, 10, 15, 5, 0, 0);
const mkReq = (o = {}) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify({ key: 'rama-secret-12', action: 'research', messages: [{ role: 'user', content: 'Tes?' }], ...o }) });
const GEM = (um) => ({ candidates: [{ content: { role: 'model', parts: [{ text: 'Jawab.' }] }, finishReason: 'STOP' }], usageMetadata: um });
async function run(env, o, body) { const orig = globalThis.fetch; globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => body }); try { const r = await T.handle(mkReq(o), env, NOW); return { status: r.status, j: await r.json() }; } finally { globalThis.fetch = orig; } }
test('usage per permintaan: keluar = jawaban + token pikir', async () => {
  const r = await run(env0(), {}, GEM({ promptTokenCount: 10, candidatesTokenCount: 20, thoughtsTokenCount: 70 }));
  assert.equal(r.status, 200); assert.deepEqual(r.j.usage, { in: 10, out: 90 });
});
test('tanpa thoughtsTokenCount (model tanpa pikir): hitungan lama tidak berubah', async () => {
  const r = await run(env0(), {}, GEM({ promptTokenCount: 3, candidatesTokenCount: 2 })); assert.deepEqual(r.j.usage, { in: 3, out: 2 });
});
test('nilai rusak (teks, negatif, tak ada) tidak merusak hitungan: dianggap 0 atau diabaikan lewat Number()', async () => {
  const r = await run(env0(), {}, GEM({ promptTokenCount: 5, candidatesTokenCount: 4, thoughtsTokenCount: 'x' })); assert.deepEqual(r.j.usage, { in: 5, out: 4 });
  const r2 = await run(env0(), {}, GEM(undefined)); assert.deepEqual(r2.j.usage, { in: 0, out: 0 });
});
test('token bulanan (batas bulanan aktif) ikut memakai hitungan baru', async () => {
  const e = env0(), r = await run(e, { monthLimit: 50 }, GEM({ promptTokenCount: 10, candidatesTokenCount: 20, thoughtsTokenCount: 70 }));
  assert.deepEqual(r.j.monthTokens, { in: 10, out: 90 });
});
test('sumber: komentar Rev 307b ada dan rumus memakai thoughtsTokenCount', () => {
  const w = src('backend/cloudflare/worker.mjs'); assert.ok(w.includes('Rev 307b')); assert.ok(w.includes('thoughtsTokenCount'));
});
