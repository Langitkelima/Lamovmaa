import assert from 'node:assert/strict';
import { clampFontScale, MIN_FONT_SCALE, MAX_FONT_SCALE, FONT_SCALE_STEP } from '../src/js/ukuran.js';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok - ' + name); };
t('Rev 30: rentang ukuran huruf 70–250%', () => { assert.equal(MIN_FONT_SCALE,70); assert.equal(MAX_FONT_SCALE,250); });
t('Rev 30: langkah 10%, pembulatan terdekat', () => { assert.equal(FONT_SCALE_STEP,10); assert.equal(clampFontScale(146),150); assert.equal(clampFontScale(144),140); });
t('Rev 30: batas dan masukan tidak sah aman', () => { assert.equal(clampFontScale(20),70); assert.equal(clampFontScale(300),250); assert.equal(clampFontScale('x'),100); });
t('Rev 30: 100% tetap nilai normal', () => { assert.equal(clampFontScale(100),100); });
console.log(`${n} tes ukuran huruf lulus`);
