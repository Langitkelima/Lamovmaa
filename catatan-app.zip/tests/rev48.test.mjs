// Rev 48: teks mengalir di samping gambar rata kiri/kanan (CSS saja).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const css = src('../src/css/styles.css');
const blk = css.slice(css.indexOf('/* Rev 48'));
t('gambar rata kiri/kanan ukuran 20-70% mengambang; 75% ke atas dan tengah tidak', () => {
  for (const s of [20, 45, 70]) { assert.ok(blk.includes(`figure.ki[data-f="1"][data-a="l"][data-s="${s}"]`) && blk.includes(`figure.ki[data-f="1"][data-a="r"][data-s="${s}"]`)); }
  for (const s of [75, 100]) assert.ok(!blk.includes(`[data-s="${s}"]`));
  assert.ok(blk.includes('float:left') && blk.includes('float:right') && blk.includes('.ed2{display:flow-root}'));
  assert.ok(blk.includes('clear:both'));
});
t('mengalir hanya bila pengguna menyalakan: CSS butuh data-f=1, tombol di bar gambar, sanitize mengizinkan data-f', () => {
  assert.ok(!/figure\.ki\[data-a="[lr]"\]\[data-s=/.test(blk), 'tanpa data-f tidak boleh mengambang');
  const nt = src('../src/js/notes.js');
  for (const k of ["k === 'data-f' && v === '1'", 'tapBtn(imgFlow', "'Teks di samping gambar'", 'Teks di samping: Aktif', "fig.removeAttribute('data-f')", "fig.setAttribute('data-a', 'l')", "fig.setAttribute('data-s', '50')"]) assert.ok(nt.includes(k), k);
  assert.ok(src('../src/js/ui.js').includes('flow:'));
  assert.ok(blk.includes('.img-tools.locked .img-b.fl'));
});
t('data tidak berubah: SCHEMA 8 sejak Rev 60, tanpa native; versi 0.3.2', () => {
  assert.match(src('../src/js/storage.js'), /SCHEMA = 22/);
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../RIWAYAT.md').includes('versi 0.3.2'));
});
console.log(`${n} tes lulus (Rev 48)`);
