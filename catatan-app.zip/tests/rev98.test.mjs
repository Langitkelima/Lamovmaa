// Rev 98 / U4c: mesin angka tabel (murni). Belum ada UI; baris Total menyusul di U4d.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseNum, formatNum, columnTotal, TOTAL_FUNCS, isTotalFunc, DASH } from '../src/js/tabel-hitung.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 98: parseNum menerima format Indonesia', () => {
  const ok = { '1.234,5': 1234.5, 'Rp 12.000': 12000, 'Rp. 1.500,25': 1500.25, 'rp12.000': 12000, '-Rp 5.000': -5000, 'Rp -5.000': -5000, '50%': 50, '50 %': 50, '-3': -3, '+4': 4, '1234': 1234, '0,5': 0.5, ' 7 ': 7, '1.234': 1234, '1.234.567': 1234567, '1.234,50': 1234.5, '0,00': 0, '\u00a012.000\u00a0': 12000, '\u22125': -5 };
  for (const [k, v] of Object.entries(ok)) assert.equal(parseNum(k), v, JSON.stringify(k));
  assert.ok(Object.is(parseNum('-0'), 0), 'tanpa -0');
});
test('Rev 98: parseNum mengabaikan kosong dan teks (null, bukan 0)', () => {
  for (const k of ['', '   ', 'abc', '12 kg', '1e5', '1.2.3', '1,2,3', '1,234.5', '--3', 'Rp', 'Rp.', '.5', '5.', '12.34.567,1', '-', '%', null, undefined, {}, NaN, Infinity]) assert.equal(parseNum(k), null, String(k));
  assert.equal(parseNum(5), 5);
});
test('Rev 98: parseNum asumsi satu titik non-ribuan = desimal', () => {
  assert.equal(parseNum('3.14'), 3.14); assert.equal(parseNum('1.5'), 1.5); assert.equal(parseNum('1.2345'), 1.2345);
});
test('Rev 98: formatNum id-ID, maks 2 desimal, tanpa -0', () => {
  assert.equal(formatNum(1234.5), '1.234,5'); assert.equal(formatNum(12000), '12.000'); assert.equal(formatNum(0.1 + 0.2), '0,3');
  assert.equal(formatNum(-1234567.891), '-1.234.567,89'); assert.equal(formatNum(-0.001), '0'); assert.equal(formatNum(0), '0');
  assert.equal(formatNum(2.675), '2,68'); assert.equal(formatNum(999.999), '1.000'); assert.equal(formatNum(5), '5');
  assert.equal(formatNum(NaN), DASH); assert.equal(formatNum('x'), DASH); assert.equal(formatNum(Infinity), DASH);
  for (const n of [0, 7, 1234.5, -88.25, 1500.25]) assert.equal(parseNum(formatNum(n)), n, 'bolak-balik ' + n);
});
test('Rev 98: columnTotal jumlah, rata-rata, hitung, min, maks; sel kosong/teks diabaikan', () => {
  const col = ['1.000', 'Rp 2.500,5', 'x', '', '-500'];
  assert.deepEqual(columnTotal(col, 'sum'), { fn: 'sum', count: 3, value: 3000.5, text: '3.000,5' });
  assert.equal(columnTotal(col, 'avg').text, '1.000,17');
  assert.equal(columnTotal(col, 'cnt').text, '3'); assert.equal(columnTotal(col, 'cnt').value, 3);
  assert.equal(columnTotal(col, 'min').text, '-500'); assert.equal(columnTotal(col, 'max').text, '2.500,5');
  assert.equal(columnTotal(['0,1', '0,2'], 'sum').text, '0,3');
});
test('Rev 98: tanpa angka = "—" (bukan galat, bukan 0); hitung = 0; fungsi asing jatuh ke jumlah', () => {
  for (const f of ['sum', 'avg', 'min', 'max']) { const r = columnTotal(['a', '', 'b'], f); assert.equal(r.text, DASH); assert.equal(r.value, null); }
  assert.equal(columnTotal([], 'cnt').text, '0'); assert.equal(columnTotal(undefined, 'sum').text, DASH);
  assert.equal(columnTotal(['2', '3'], 'zzz').fn, 'sum');
  assert.deepEqual(TOTAL_FUNCS.map((f) => f.id), ['sum', 'avg', 'cnt', 'min', 'max']);
  assert.deepEqual(TOTAL_FUNCS.map((f) => f.label), ['Jumlah', 'Rata-rata', 'Hitung', 'Min', 'Maks']);
  assert.ok(isTotalFunc('avg') && !isTotalFunc('x'));
});
test('Rev 98: modul murni (tanpa DOM/Intl/eval), belum dipanggil UI; versi 0.3.121, SCHEMA 9, dependensi tetap', () => {
  const s = src('src/js/tabel-hitung.js');
  assert.ok(!/document|window|Intl|eval\(|new Function|import /.test(s.replace(/\/\/.*$/gm, '')));
  assert.ok(!src('src/js/notes.js').includes('tabel-hitung'));
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.deepEqual(Object.keys(JSON.parse(src('package.json')).dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(JSON.parse(src('package.json')).scripts.test.includes('node tests/rev98.test.mjs'));
});
