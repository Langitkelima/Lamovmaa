import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseNoteHtml, layoutDoc, cardGeom, blocksToText } from '../src/js/export.js';

const notes = readFileSync(new URL('../src/js/notes.js', import.meta.url), 'utf8');
const share = readFileSync(new URL('../src/js/share.js', import.meta.url), 'utf8');
const html = '<div class="kb-date-block" data-kb-date="2026-11-07"></div><div class="kb-time-block" data-kb-time="19:15" data-kb-size="large"></div><div class="kb-countdown-block" data-kb-date="2026-11-14" data-kb-title="Liburan"></div>';
const now = new Date(2026, 10, 7);

test('Ketuk Hitung mundur membuka baris alat Ubah/Hapus, bukan langsung dialog', () => {
  assert.doesNotMatch(notes, /editCountdownCard/);
  assert.match(notes, /\[\['edit', 'Ubah'\], \['delete', 'Hapus'\]\]/);
  assert.match(notes, /kbBlock = e\.target\.closest\('\.kb-date-block,\.kb-time-block,\.kb-countdown-block'\)/);
  assert.match(notes, /if \(v === 'edit'\) \{ openCountdownEditor\(blk\)/);
});
test('Parser memberi data kartu untuk Tanggal, Waktu, Hitung mundur; teks TXT tetap ada', () => {
  const b = parseNoteHtml(html, now);
  assert.deepEqual(b.map((x) => x.card.type), ['date', 'time', 'cd']);
  assert.equal(b[1].card.size, 'large');
  assert.equal(b[2].card.remain, '7 hari lagi');
  assert.equal(b[2].card.month, 'NOV');
  const txt = blocksToText('J', b);
  assert.match(txt, /Tanggal: 7 November 2026/); assert.match(txt, /Waktu: 19:15/); assert.match(txt, /Hitung mundur: Liburan/);
});
test('Tanggal tidak valid tidak menjadi kartu gambar', () => {
  const b = parseNoteHtml('<div class="kb-countdown-block" data-kb-date="2026-02-31"></div><div class="kb-date-block" data-kb-date="x"></div>', now);
  assert.equal(b.length, 2); assert.ok(b.every((x) => x.card === undefined));
});
test('Tata letak menghasilkan baris kartu dengan tinggi dari cardGeom', () => {
  const b = parseNoteHtml(html, now);
  const o = { width: 1080, padX: 72, size: 40, titleSize: 62, pageH: 7000, measure: (t) => t.length * 20 };
  const l = layoutDoc({ title: 'J', blocks: b }, o).filter((x) => x.kind === 'card');
  assert.equal(l.length, 3);
  l.forEach((x) => assert.equal(x.lh, cardGeom(o.size, x.card, 1080 - 144).h));
  assert.ok(cardGeom(40, { type: 'time', size: 'large' }, 900).h > cardGeom(40, { type: 'time', size: 'small' }, 900).h);
});
test('share.js menggambar jenis kartu', () => {
  assert.match(share, /l\.kind === 'card'\) \{ drawCard\(g, l, y, th, o\)/);
  assert.match(share, /function drawCard/);
});
