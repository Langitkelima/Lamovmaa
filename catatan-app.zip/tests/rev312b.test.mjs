// Rev 312b: nada toast otomatis (toastTone) diperluas: pesan "dulu", "tidak sah", "masih kosong", dst. = peringatan; pesan sukses (ditambahkan, diatur, disalin, dst.) = ok.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const s = readFileSync(new URL('../src/js/ui.js', import.meta.url), 'utf8');
const i = s.indexOf('export function toastTone'), j = s.indexOf('export function toastMs');
const toastTone = new Function(s.slice(i, j).replace('export function toastTone', 'return function toastTone'))();
const T = (m) => toastTone(m);
test('Rev 312b: peringatan', () => {
  for (const m of ['Beralih ke mode Edit dulu.', 'Tunggu balasan selesai dulu.', 'Nyalakan Kelimaa AI dulu di tab AI (simpan sambungan, lalu sakelar MENYALA).', 'Simpan sambungan dulu, baru nyalakan.', 'Tidak sah: B2', 'Rentang sumber tidak sah. Contoh: D2:D10.', 'Nama proyek tidak boleh kosong.', 'Catatan masih kosong.', 'Tab ini masih kosong.', 'Lampiran tidak ikut saat Cari di web menyala.', 'Hanya jalan di aplikasi HP.', 'Posisi teks berubah. Blok lagi lalu coba ulang.', 'Isi nilainya dulu.', 'Isi angka yang valid.', 'Berkas kosong.', 'Lembar kerja ini sudah tidak ada.', 'Tunggu sebentar sampai animasi Langit selesai.']) assert.equal(T(m), 'warn', m);
});
test('Rev 312b: sukses', () => {
  for (const m of ['Aturan ditambahkan.', 'Pengingat diatur: Besok', 'Salinan dibuat', 'Balasan disalin.', 'Nama label diganti.', 'Diagram disimpan di tab ini.', 'PIN dibuat.', 'Digabung: A1:B2', 'Tidak ada data yang tidak sah.', 'Proyek dihapus.']) assert.equal(T(m), 'ok', m);
});
test('Rev 312b: galat dan info tetap', () => {
  assert.equal(T('Data gagal dibaca.'), 'err'); assert.equal(T('Gagal menyimpan di HP.'), 'err'); assert.equal(T('Sebagian riwayat gagal dihapus: x'), 'err');
  assert.equal(T('Membuka lembar kerja…'), 'info'); assert.equal(T('Ringkasan masuk ke kolom pesan. Periksa dulu, lalu kirim.'), 'info'); assert.equal(T('Teks mengalir di samping gambar'), 'info');
});
