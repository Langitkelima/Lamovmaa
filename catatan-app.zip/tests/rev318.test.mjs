// Rev 318 / PART U1: mesin lebar kolom tabel (murni). Bagian DOM (applyTableWidths, normalize di sanitize) dicek di Chromium, bukan di npm test.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { COL_W_MIN, COL_W_MAX, COL_W_RE, clampW, parseWidths, formatWidths } from '../src/js/tabel.js';
import { setWidthAt, insertWidthAt, removeWidthAt } from '../src/js/tabel-lebar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('Rev 318: clampW menjepit 56..320, 0/aneh = otomatis', () => {
  assert.equal(COL_W_MIN, 56); assert.equal(COL_W_MAX, 320);
  assert.equal(clampW(10), 56); assert.equal(clampW(999), 320); assert.equal(clampW(120.4), 120);
  for (const v of [0, -5, NaN, 'abc', null, undefined, Infinity]) assert.equal(clampW(v), 0, String(v));
});
test('Rev 318: parseWidths/formatWidths bolak-balik, panjang mengikuti jumlah kolom', () => {
  assert.deepEqual(parseWidths('140,0,200', 3), [140, 0, 200]);
  assert.deepEqual(parseWidths('140,0,200', 5), [140, 0, 200, 0, 0]);
  assert.deepEqual(parseWidths('140,0,200', 2), [140, 0]);
  assert.deepEqual(parseWidths('tidak sah', 3), [0, 0, 0]); assert.deepEqual(parseWidths('', 2), [0, 0]); assert.deepEqual(parseWidths(null, 2), [0, 0]);
  assert.deepEqual(parseWidths('10,999', 2), [56, 320]);
  assert.equal(formatWidths([140, 0, 200]), '140,0,200'); assert.equal(formatWidths([0, 0]), ''); assert.equal(formatWidths(null), '');
  assert.equal(formatWidths(parseWidths('10,999', 2)), '56,320');
});
test('Rev 318: COL_W_RE menolak teks berbahaya dan yang kepanjangan', () => {
  for (const ok of ['0', '56', '140,0,200', '0,0,0,0,0,0,0,0']) assert.ok(COL_W_RE.test(ok), ok);
  for (const bad of ['', '5', '1000', '-3', '1.5', ' 100', '100,', ',100', '100;color:red', '<b>', '0,0,0,0,0,0,0,0,0', '01']) assert.ok(!COL_W_RE.test(bad), bad);
});
test('Rev 318: seret/tambah/hapus kolom tidak menggeser lebar kolom lain', () => {
  assert.deepEqual(setWidthAt([100, 0, 200], 1, 150, 3), [100, 150, 200]);
  assert.deepEqual(setWidthAt([100, 0, 200], 9, 150, 3), [100, 0, 200]);
  assert.deepEqual(insertWidthAt([100, 0, 200], 1, 4), [100, 0, 0, 200]);
  assert.deepEqual(insertWidthAt([100, 0, 200], 3, 4), [100, 0, 200, 0]);
  assert.deepEqual(removeWidthAt([100, 150, 200], 1, 2), [100, 200]);
  assert.deepEqual(removeWidthAt([100, 150, 200], 0, 2), [150, 200]);
  assert.equal(insertWidthAt(parseWidths('', 8), 0, 8).length, 8, 'maks. 8 kolom');
});
test('Rev 318: sanitize mengizinkan TABLE[data-w] dengan COL_W_RE dan menormalkannya; tanpa pemanggil UI', () => {
  const n = src('src/js/notes.js');
  assert.match(n, /c\.tagName === 'TABLE' && k === 'data-w' && COL_W_RE\.test\(v\)/);
  assert.match(n, /querySelectorAll\('table\[data-w\]'\)\.forEach\(\(tb\) => normalizeTableWidths\(tb\)\)/);
  assert.ok(!/applyTableWidths|writeTableWidths/.test(n), 'U1 belum dipakai UI');
});
test('Rev 318: modul DOM lazy: tabel-lebar.js TIDAK diimpor statis dari notes.js/main.js (jalur buka)', () => {
  for (const f of ['notes', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /^import .*tabel-lebar/m, f); // Rev 319: notes.js kini memuatnya lewat import() dinamis (malas); impor statis tetap dilarang
});
test('Rev 318: versi dan SCHEMA tidak berubah', () => {
  assert.ok(src('package.json').includes('"version": "0.3.121"')); assert.ok(src('src/js/storage.js').includes('export const SCHEMA = 22;'));
});
