// Rev 343 / PART I2: `[[` tautan antarcatatan di editor catatan (tampilan; mesin = ketik-pemicu.js). Tautan = span.nl + data-nid; hubungan Rev 18 ikut dipasang.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
globalThis.document = { createElement: () => ({ setAttribute() {}, addEventListener() {}, append() {}, className: '' }), createTextNode: (t) => ({ nodeType: 3, data: t }) };
const { wikiFor, wikiList, wikiHtml, WIKI_LIMIT } = await import('../src/js/ketik-ui.js');

const N = (id, title, updated) => ({ id, title, updated, text: '', html: '' });

test('wikiFor: `[[` terbuka = { query }; kosong, kata, spasi nbsp diterima', () => {
  assert.deepEqual(wikiFor('[['), { query: '' });
  assert.deepEqual(wikiFor('lihat [[rap'), { query: 'rap' });
  assert.deepEqual(wikiFor('lihat [[rapat tim'), { query: 'rapat tim' });
  assert.deepEqual(wikiFor('a\u00a0[[b\u00a0c'), { query: 'b c' }, 'nbsp dianggap spasi');
});
test('wikiFor: `[[` menang atas `=`, `/`, `!`, `#` (judul boleh memuat itu semua)', () => {
  for (const l of ['[[a=', '[[ /tab', '[[a !besok 9', '[[a #x']) assert.ok(wikiFor(l), JSON.stringify(l));
});
test('wikiFor: bukan pemicu = null (satu kurung, sudah ditutup, lewat 60 huruf, bukan teks)', () => {
  for (const l of ['[', 'a [b', '[[abc]]', '[[abc]', '[[' + 'x'.repeat(61), '', 'tanpa kurung']) assert.equal(wikiFor(l), null, JSON.stringify(l));
  assert.equal(wikiFor(null), null); assert.equal(wikiFor(5), null);
});
test('wikiList: awalan judul dulu, potongan di tengah menyusul, tiap peringkat terbaru dulu; huruf besar/kecil diabaikan', () => {
  const notes = [N('a', 'Rapat tim', 10), N('b', 'Notulen rapat', 50), N('c', 'RAPAT keluarga', 30), N('d', 'Belanja', 99)];
  assert.deepEqual(wikiList(notes, 'x', 'rap').map((c) => c.id), ['c', 'a', 'b']);
  assert.deepEqual(wikiList(notes, 'x', '  RAPAT ').map((c) => c.id), ['c', 'a', 'b'], 'spasi di tepi dibuang');
  assert.deepEqual(wikiList(notes, 'x', 'zzz'), []);
});
test('wikiList: tanpa kata = terbaru dulu; diri sendiri, tanpa judul, dan data rusak tidak ikut; maks. WIKI_LIMIT', () => {
  const notes = [N('a', 'A', 1), N('self', 'Diri', 500), N('e', '   ', 400), N('f', '', 300), null, { title: 'tanpa id', updated: 9 }, N('b', 'B', 2)];
  assert.deepEqual(wikiList(notes, 'self', '').map((c) => c.id), ['b', 'a']);
  const many = Array.from({ length: 20 }, (_, i) => N('n' + i, 'Judul ' + i, i));
  assert.equal(WIKI_LIMIT, 8);
  assert.equal(wikiList(many, 'x', '').length, 8);
  assert.equal(wikiList(many, 'x', '', 3).length, 3);
  assert.deepEqual(wikiList(undefined, 'x', ''), []);
});
test('wikiList: hanya mengembalikan { id, title } (judul dirapikan); tidak membawa isi catatan', () => {
  const r = wikiList([{ id: 'a', title: '  Rapat  ', updated: 1, text: 'RAHASIA', html: '<b>x</b>' }], 'x', '');
  assert.deepEqual(r, [{ id: 'a', title: 'Rapat' }]);
});
test('wikiHtml: bentuk tautan tetap, id dan judul di-escape (tidak bisa menyuntik atribut/tag)', () => {
  assert.equal(wikiHtml('abc123', 'Rapat'), '<span class="nl" data-nid="abc123" contenteditable="false">Rapat</span>&nbsp;');
  const h = wikiHtml('a"b', '<img src=x onerror=1> & "q"');
  assert.ok(!/<img/.test(h) && !/data-nid="a"b"/.test(h), h);
  assert.match(h, /&lt;img src=x onerror=1&gt; &amp; &quot;q&quot;/);
});
test('sumber ketik-ui.js: `[[` menang di find(), IME boleh menyusun, Esc menutup, kapsul tidak mencuri fokus, hapus `[[kata` lalu insertHTML, hubungan lewat env.wiki.done', () => {
  const k = read('src/js/ketik-ui.js');
  assert.match(k, /const isWk = !!env\.wiki && !muted && nd\.data\.lastIndexOf\('\[\[', off - 1\) >= 0/);
  assert.match(k, /if \(composing && !isSl && !isWk\) return null/);
  assert.match(k, /if \(isWk\) \{ const wf = wikiFor\(line\); if \(wf\) return \{ kind: 'wiki'[^]*?\}\s*\/\/ `\[\[` terbuka menang/);
  assert.match(k, /onpointerdown: stop, onmousedown: stop, onclick: \(\) => pickNote\(c\.id\)/);
  assert.match(k, /r\.query\.length \+ 2/, 'tepat `[[` + kata yang dihapus');
  assert.match(k, /execCommand\('delete'\);[^]*?execCommand\('insertHTML', false, wikiHtml\(it\.id, it\.title\)\);\s*env\.wiki\.done\(it\.id\)/);
  assert.match(k, /flushHist\(\); \/\/ ketikan `\[\[kata`/, 'satu langkah Urungkan membuang tautannya saja');
  assert.ok(!/import\s.*notes\.js/.test(k), 'modul tampilan tidak mengimpor notes.js');
});
test('sumber notes.js: sanitize mengenal HANYA span.nl + data-nid + contenteditable=false; tautan tanpa id jadi teks; gerbang `[[` murah; env.wiki; Catatan Privat tidak ikut', () => {
  const s = read('src/js/notes.js');
  assert.match(s, /c\.tagName === 'SPAN' && \(k === 'class' \? v === 'nl' : c\.classList\.contains\('nl'\) && \(k === 'contenteditable' \? v === 'false' : k === 'data-nid' && \/\^\[\\w-\]\{4,40\}\$\/\.test\(v\)\)\)/);
  assert.match(s, /querySelectorAll\('span\.nl:not\(\[data-nid\]\)'\)\.forEach\(\(el\) => el\.replaceWith\(el\.textContent\)\)/);
  assert.match(s, /const inWiki = c === '\[' && nd\.data\[sl\.anchorOffset - 2\] === '\['/);
  assert.match(s, /if \(inTodoBang \|\| inWiki \|\| inWa\) \{ \/\* muat modul \*\/ \}/);
  assert.match(s, /const wiki = \{ notes: \(\) => data\.notes, selfId: n\.id, done: \(id\) => \{ const r = toggleLink\(n, id\); if \(r\.ok && r\.on\) \{ n\.links = r\.ids; relUi\(\); \} auto\(\); \} \}/, 'daftar dari data.notes (tanpa Catatan Privat); hubungan Rev 18 hanya dipasang (tidak pernah dilepas) lewat toggleLink');
  assert.match(s, /pasangKetik\(\{ ed, flushHist, tags, slash, remind, wiki \}\)/);
  assert.match(s, /if \(!isP\) ed\.addEventListener\('click', \(e\) => \{[^]*?closest\('span\.nl'\)[^]*?goNote\(l\.getAttribute\('data-nid'\)\)[^]*?setAttribute\('data-nx', ''\)/);
  const san = s.slice(s.indexOf('export function sanitize'), s.indexOf('export function notePlain'));
  assert.ok(!/data-nx/.test(san), 'data-nx (tanda pudar sementara) tidak boleh lolos sanitize');
  assert.match(s, /import\('\.\/ketik-ui\.js'\)/, 'modul tampilan tetap malas');
  assert.ok(!/^import .*ketik-ui/m.test(s), 'tidak ada impor statis ketik-ui');
});
test('sumber CSS: tautan memakai variabel tema (tanpa hex/rgba), dan tanda pudar memakai atribut data-nx', () => {
  const c = read('src/css/styles.css'), i = c.indexOf('/* Rev 343 / I2');
  assert.ok(i > 0); const blok = c.slice(i);
  assert.ok(!/#[0-9a-fA-F]{3,6}\b|rgba?\(/.test(blok), 'tanpa warna literal');
  assert.match(blok, /\.nl\[data-nx\]/); assert.match(blok, /\.kq-note/); assert.match(blok, /\.kq-none/);
});
