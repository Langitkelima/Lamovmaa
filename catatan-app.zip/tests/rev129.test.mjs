// Rev 129 / U8a-4a: chip saran fungsi + petunjuk argumen saat mengetik rumus (pembantu murni + kabel UI).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { formulaContext, argHint, suggestionsFor, applySuggestion } from '../src/js/rumus-bantu.js';
import { FUNCTION_LIST, a1ToStored } from '../src/js/rumus.js';
import * as L from '../src/js/lembar.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('formulaContext: bukan rumus = null; awalan, fungsi terdalam, nomor argumen', () => {
  assert.equal(formulaContext('abc', 3), null); assert.equal(formulaContext('', 0), null); assert.equal(formulaContext('A1=2', 4), null);
  assert.deepEqual(formulaContext('=SU', 3), { prefix: 'SU', start: 1, fn: null, arg: 0, depth: 0 });
  const c = formulaContext('=IF(A1>2;SU', 11); assert.equal(c.prefix, 'SU'); assert.equal(c.fn, 'IF'); assert.equal(c.arg, 1); assert.equal(c.depth, 1);
  assert.equal(formulaContext('=SUM(A1;B2;', 11).arg, 2); assert.equal(formulaContext('=SUM(A1)', 8).fn, null);
  assert.equal(formulaContext('=SUM(A1', 7).prefix, ''); // A1 = rujukan, bukan awalan fungsi
  assert.equal(formulaContext('=FOO(1;', 7).fn, null); // fungsi tak dikenal: tanpa petunjuk
});
test('formulaContext: teks dalam tanda kutip dan koma desimal tidak dihitung pemisah', () => {
  assert.equal(formulaContext('=IF(A1="a;b";1', 14).arg, 1);
  assert.equal(formulaContext('=SUM(1,5;2', 10).arg, 1); // 1,5 = desimal
  assert.equal(formulaContext('=SUM(A1,5', 9).arg, 1); // A1,5 = dua argumen
  assert.equal(formulaContext('=IF(A1="ab', 10).prefix, ''); // di dalam teks: tanpa saran
});
test('formulaContext: kursor di tengah teks hanya membaca bagian sebelum kursor; kursor rusak dibatasi', () => {
  assert.equal(formulaContext('=SUM(A1;B2)', 6).arg, 0); assert.equal(formulaContext('=SU', 999).prefix, 'SU'); assert.equal(formulaContext('=SU', NaN).prefix, 'SU'); assert.equal(formulaContext('=SU', -4), null); // kursor sebelum '=' = bukan rumus
});
test('argHint: argumen disorot, melewati batas = terakhir, fungsi tanpa argumen, tak dikenal = null', () => {
  const h = argHint('if', 1); assert.equal(h.name, 'IF'); assert.deepEqual(h.parts, ['syarat', 'jika_benar', '[jika_salah]']); assert.equal(h.active, 1);
  assert.equal(argHint('IF', 9).active, 2); assert.equal(argHint('IF', -3).active, 0); assert.equal(argHint('IF', 'x').active, 0);
  assert.deepEqual(argHint('SUM', 5).parts, ['nilai1', '[nilai2; …]']); assert.equal(argHint('SUM', 5).active, 1); // argumen berulang = satu bagian
  const t = argHint('TODAY', 0); assert.deepEqual(t.parts, []); assert.equal(t.active, -1); assert.equal(argHint('NOPE', 0), null); assert.equal(argHint(null, 0), null);
  for (const f of FUNCTION_LIST) { const a = argHint(f.name, 0); assert.ok(a && a.sig === f.sig && a.ket); } // semua fungsi punya petunjuk
});
test('suggestionsFor + applySuggestion: saran sesuai awalan; sisip NAMA( atau NAMA() tanpa menggandakan kurung', () => {
  assert.deepEqual(suggestionsFor(formulaContext('=SU', 3)).map((f) => f.name), ['SUM', 'SUMIF', 'SUMIFS']); assert.deepEqual(suggestionsFor(formulaContext('=', 1)), []); assert.deepEqual(suggestionsFor(null), []);
  assert.deepEqual(suggestionsFor(formulaContext('=zz', 3)), []); assert.equal(suggestionsFor(formulaContext('=A', 2), 2).length, 2);
  assert.deepEqual(applySuggestion('=SU', 3, 'SUM'), { text: '=SUM(', caret: 5 });
  assert.deepEqual(applySuggestion('=1+TO', 5, 'TODAY'), { text: '=1+TODAY()', caret: 10 });
  assert.deepEqual(applySuggestion('=SU(A1)', 3, 'SUM'), { text: '=SUM(A1)', caret: 5 });
  assert.deepEqual(applySuggestion('abc', 3, 'SUM'), { text: 'abc', caret: 3 }); assert.deepEqual(applySuggestion('=SU', 3, 'XYZ'), { text: '=SU', caret: 3 });
});
test('hasil sisip saran lolos a1ToStored bila dilengkapi (alur ketik nyata)', () => {
  const t = L.newTab('T', 3); L.setCell(t, 'r1', 'cA', { v: 2 }); L.setCell(t, 'r2', 'cA', { v: 3 });
  const r = applySuggestion('=SU', 3, 'SUM'); assert.equal(a1ToStored(r.text, t).ok, false); // belum lengkap = ditolak, tidak tersimpan
  assert.equal(a1ToStored(r.text + 'A1:A2)', t).ok, true);
});
test('kabel lembar-ui: assistEl di atas bilah isian, chip pakai pointerdown preventDefault, tanpa eval, modul pembantu murni', () => {
  const u = src('src/js/lembar-ui.js'), m = src('src/js/rumus-bantu.js');
  assert.match(u, /from '\.\/rumus-bantu\.js'/); assert.match(u, /fmtBar, assistEl, bar, tabs/); assert.match(u, /applySuggestion\(val\.value, val\.selectionStart, name\)/);
  assert.match(u, /\['input', 'keyup', 'click', 'focus'\]\.forEach\(\(ev\) => val\.addEventListener\(ev, paintAssist\)\)/); assert.match(u, /b\.addEventListener\('pointerdown', \(e\) => e\.preventDefault\(\)\)/);
  assert.match(u, /val\.addEventListener\('input', \(\) => \{ \/\/ Rev 128/); // pratinjau Rev 128 tidak diubah
  assert.doesNotMatch(m, /document|window|localStorage|eval\(|new Function/); assert.match(m, /^import \{ FUNCTION_LIST, suggestFunctions \} from '\.\/rumus\.js';$/m);
  assert.match(src('src/css/styles.css'), /\.lembarfs \.lz-assist\{/);
});
test('Rev 129: versi 0.3.121, SCHEMA 13 (naik di Rev 132), tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev129.test.mjs'));
});
