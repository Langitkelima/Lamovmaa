// Rev 196 / P6: enam PNG judul -> WebP + skrip audit ukuran + anggaran. Berkas rev198 = Rev 196.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { telusuri, ringkas, periksaAnggaran, ANGGARAN } from '../tools/audit-ukuran.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const dir = new URL('../src/img/judul/', import.meta.url);
const NAMA = ['catatan', 'kebiasaan', 'rencana', 'target', 'privat', 'fokus', 'kelimaa'];
test('Rev 372: judul = 12 berkas SVG (6 x terang/gelap), tidak ada WebP/PNG judul tersisa', () => {
  const nama = NAMA.flatMap((n) => [n + '-t.svg', n + '-g.svg']);
  for (const n of nama) { const f = new URL(n, dir); assert.ok(existsSync(f), n + ' ada'); assert.ok(readFileSync(f, 'utf8').startsWith('<svg '), n + ' = SVG'); assert.ok(statSync(f).size > 1500, n + ' tidak kosong'); }
  assert.deepEqual(readdirSync(dir).sort(), nama.sort());
});
test('ui.js memakai .svg dan tidak ada rujukan judul .webp/.png', () => {
  assert.match(src('src/js/ui.js'), /img\/judul\/\$\{berkas\}-\$\{tema\}\.svg/); assert.doesNotMatch(src('src/js/ui.js'), /judul\/\$\{berkas\}\.(png|webp)/);
});
test('anggaran: total gambar judul di bawah batas, CSS dan JS di bawah batas', () => {
  const berkas = telusuri(new URL('../src', import.meta.url).pathname);
  const a = periksaAnggaran(berkas); assert.deepEqual(a.gagal, []); assert.ok(a.judul < ANGGARAN.gambarJudulMaks);
  const r = ringkas(berkas); assert.ok(r.total < ANGGARAN.totalMaks); assert.equal(r.terbesar.length, 20);
});
test('periksaAnggaran menangkap regresi (PNG judul kembali / gambar membengkak)', () => {
  assert.ok(periksaAnggaran([{ path: 'src/img/judul/x.png', ukuran: 10, jenis: 'png' }]).gagal.length > 0);
  assert.ok(periksaAnggaran([{ path: 'src/img/judul/x.webp', ukuran: ANGGARAN.gambarJudulMaks + 1, jenis: 'webp' }]).gagal.length > 0);
});
test('versi 0.3.121, tes terdaftar, tanpa native/dependensi/SCHEMA berubah', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(pk.scripts.test, /node tests\/rev198\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
