// Rev 145 / U9b-2a: aturan warna bersyarat per tab (model murni lembar-aturan.js + sambungan lembar.js + SCHEMA 14). Belum ada UI.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as R from '../src/js/lembar-aturan.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import * as S from '../src/js/storage.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = (rows) => { const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; rows.forEach((row, r) => row.forEach((v, c) => { if (v !== undefined) L.setCell(tab, tab.rows[r].id, tab.cols[c].id, typeof v === 'object' && v !== null && 'fx' in v ? v : { v }); })); return { sh, tab }; };
const ids = new Set(['cA', 'cB', 'cC']);

test('cleanRule: operator, kolom, angka/teks, warna, dan urutan between dibersihkan; yang tidak sah dibuang', () => {
  assert.deepEqual(R.cleanRule({ id: 'ab12', c: 'cA', op: 'gt', a: 5, bg: '#FFC9C9' }, ids), { id: 'ab12', c: 'cA', op: 'gt', a: 5, bg: '#FFC9C9' });
  assert.deepEqual(R.cleanRule({ c: 'cB', op: 'between', a: 9, b: 2, fg: 'red' }, ids), { id: '', c: 'cB', op: 'between', a: 2, b: 9, fg: 'red' }); // a <= b
  assert.equal(R.cleanRule({ c: 'cZ', op: 'gt', a: 1, bg: 'red' }, ids), null, 'kolom tidak ada');
  assert.equal(R.cleanRule({ c: 'cA', op: 'xx', a: 1, bg: 'red' }, ids), null);
  assert.equal(R.cleanRule({ c: 'cA', op: 'gt', a: 'lima', bg: 'red' }, ids), null, 'gt butuh angka');
  assert.equal(R.cleanRule({ c: 'cA', op: 'gt', a: NaN, bg: 'red' }, ids), null);
  assert.equal(R.cleanRule({ c: 'cA', op: 'gt', a: 1 }, ids), null, 'tanpa warna');
  assert.equal(R.cleanRule({ c: 'cA', op: 'gt', a: 1, bg: 'url(x)' }, ids), null, 'warna tidak sah');
  assert.equal(R.cleanRule({ c: 'cA', op: 'between', a: 1, bg: 'red' }, ids), null, 'between butuh b');
  assert.equal(R.cleanRule({ c: 'cA', op: 'eq', a: '   ', bg: 'red' }, ids), null, 'teks kosong');
  assert.equal(R.cleanRule({ c: 'cA', op: 'eq', a: 'x'.repeat(300), bg: 'red' }, ids).a.length, R.MAX_RULE_TEXT);
  assert.deepEqual(R.cleanRule({ c: 'cA', op: 'scale', lo: '#ffffff', hi: '#ff0000' }, ids), { id: '', c: 'cA', op: 'scale', lo: '#FFFFFF', hi: '#FF0000' });
  assert.equal(R.cleanRule({ c: 'cA', op: 'scale', lo: 'white', hi: '#ff0000' }, ids), null, 'skala butuh heksa');
});

test('cleanRules: maks. 10, ID unik, kolom hilang dibuang, bukan array = kosong', () => {
  const cols = [{ id: 'cA' }, { id: 'cB' }];
  const many = Array.from({ length: 14 }, () => ({ id: 'sama', c: 'cA', op: 'gt', a: 1, bg: 'red' }));
  const out = R.cleanRules(many, cols); assert.equal(out.length, R.MAX_RULES); assert.equal(new Set(out.map((x) => x.id)).size, 10);
  assert.deepEqual(R.cleanRules([{ c: 'cQ', op: 'gt', a: 1, bg: 'red' }, { c: 'cB', op: 'lt', a: 1, bg: 'red' }], cols).map((x) => x.c), ['cB']);
  assert.deepEqual(R.cleanRules(null, cols), []); assert.deepEqual(R.cleanRules('x', cols), []); assert.ok(R.cleanRules([{ c: 'cA', op: 'lt', a: 1, bg: 'red' }], cols)[0].id.length >= 4);
});

test('matches: angka, teks tidak peka huruf besar-kecil, sel kosong/galat/teks tidak cocok aturan angka', () => {
  const g = { op: 'gt', a: 10 }; assert.equal(R.matches(g, 11), true); assert.equal(R.matches(g, 10), false); assert.equal(R.matches(g, '11'), false); assert.equal(R.matches(g, undefined), false); assert.equal(R.matches(g, { e: '#DIV/0!' }), false);
  assert.equal(R.matches({ op: 'gte', a: 10 }, 10), true); assert.equal(R.matches({ op: 'lte', a: 10 }, 10), true); assert.equal(R.matches({ op: 'lt', a: 10 }, 10), false);
  assert.equal(R.matches({ op: 'between', a: 2, b: 4 }, 2), true); assert.equal(R.matches({ op: 'between', a: 2, b: 4 }, 4.1), false);
  assert.equal(R.matches({ op: 'eq', a: 'Lunas' }, ' lunas '), true); assert.equal(R.matches({ op: 'eq', a: 5 }, 5), true); assert.equal(R.matches({ op: 'eq', a: 5 }, '5'), false);
  assert.equal(R.matches({ op: 'ne', a: 'Lunas' }, 'Belum'), true); assert.equal(R.matches({ op: 'ne', a: 'Lunas' }, undefined), false, 'sel kosong tidak cocok ne'); assert.equal(R.matches({ op: 'ne', a: 5 }, { e: '#REF!' }), false);
  assert.equal(R.matches(null, 1), false);
});

test('ruleColors: memakai HASIL rumus, aturan pertama menang, sel kosong dilewati, tanpa aturan = kosong', () => {
  const { tab } = mk([[1, 'Lunas'], [20, 'Belum'], [{ fx: '=1' }, undefined], [undefined, 'lunas']]);
  const fx = L.setCell(tab, tab.rows[2].id, tab.cols[0].id, { fx: '=SUM(A1:A2)*1' }); // 21 sebagai hasil
  assert.equal(ruleColorsOf(tab).size, 0, 'tanpa aturan');
  tab.rules = R.cleanRules([{ c: tab.cols[0].id, op: 'gt', a: 10, bg: '#FF0000' }, { c: tab.cols[0].id, op: 'gt', a: 0, bg: '#00FF00' }, { c: tab.cols[1].id, op: 'eq', a: 'lunas', fg: '#008800' }], tab.cols);
  const m = ruleColorsOf(tab);
  assert.deepEqual(m.get('0,0'), { bg: '#00FF00' }); assert.deepEqual(m.get('1,0'), { bg: '#FF0000' }, 'aturan pertama menang'); assert.ok(fx !== undefined);
  assert.deepEqual(m.get('0,1'), { fg: '#008800' }); assert.deepEqual(m.get('3,1'), { fg: '#008800' }); assert.equal(m.has('1,1'), false);
  assert.equal(m.has('3,0'), false, 'kosong tidak diwarnai');
});
function ruleColorsOf(tab) { const d = makeDisplay(tab); return R.ruleColors(tab, d.raw); }

test('scale: warna menurut min/maks kolom, teks otomatis terbaca, satu angka = warna awal, teks diabaikan', () => {
  assert.equal(R.mixHex('#000000', '#FFFFFF', 0.5), '#808080'); assert.equal(R.mixHex('#000000', '#FFFFFF', 9), '#FFFFFF'); assert.equal(R.mixHex('#000000', '#FFFFFF', NaN), '#000000');
  assert.equal(R.textOn('#000000'), '#FFFFFF'); assert.equal(R.textOn('#FFFFFF'), '#111827');
  const { tab } = mk([[0], [50], [100], ['abc'], [undefined]]);
  tab.rules = R.cleanRules([{ c: tab.cols[0].id, op: 'scale', lo: '#FFFFFF', hi: '#000000' }], tab.cols);
  const m = ruleColorsOf(tab); assert.deepEqual(m.get('0,0'), { bg: '#FFFFFF', fg: '#111827' }); assert.deepEqual(m.get('2,0'), { bg: '#000000', fg: '#FFFFFF' }); assert.equal(m.get('1,0').bg, '#808080'); assert.equal(m.has('3,0'), false); assert.equal(m.has('4,0'), false);
  const one = mk([[7]]).tab; one.rules = R.cleanRules([{ c: one.cols[0].id, op: 'scale', lo: '#FFFFFF', hi: '#000000' }], one.cols); assert.equal(ruleColorsOf(one).get('0,0').bg, '#FFFFFF');
  assert.equal(R.ruleColors(null, () => 1).size, 0); assert.equal(R.ruleColors(tab, null).size, 0);
});

test('ruleText: deskripsi singkat berbahasa Indonesia', () => {
  assert.equal(R.ruleText({ op: 'gt', a: 1.5 }, 'B'), 'Kolom B: lebih dari 1,5'); assert.equal(R.ruleText({ op: 'between', a: 2, b: 4 }, 'A'), 'Kolom A: 2 sampai 4');
  assert.equal(R.ruleText({ op: 'scale' }, ''), 'skala warna'); assert.equal(R.ruleText({ op: 'ne', a: 'x' }, 'C'), 'Kolom C: bukan x'); assert.equal(R.ruleText(null), '');
});

test('model: setRules, tab tanpa aturan tidak punya kunci rules, hapus kolom membuang aturannya, cadangan/normalisasi menjaga aturan', () => {
  const { sh, tab } = mk([[1, 2]]); assert.equal('rules' in tab, false);
  assert.equal(L.setRules(tab, [{ c: tab.cols[0].id, op: 'gt', a: 1, bg: '#FF0000' }, { c: 'cNOPE', op: 'gt', a: 1, bg: '#FF0000' }]), true); assert.equal(tab.rules.length, 1);
  assert.equal(L.setRules(tab, tab.rules), false, 'sama = tidak berubah');
  const sh2 = L.cleanSheet(JSON.parse(JSON.stringify(sh))); assert.deepEqual(sh2.tabs[0].rules, tab.rules); assert.ok(L.fitsLimit(sh2));
  const d = S.normalize({ version: 13, tasks: [], habits: [], priv: [], trash: [], notes: [], sheets: { [sh.id]: JSON.parse(JSON.stringify(sh)) } }); assert.deepEqual(d.sheets[sh.id].tabs[0].rules, tab.rules); assert.equal(S.exportJSON(d).includes('"rules"'), true);
  const t2 = L.newTab('X'); L.setRules(t2, [{ c: t2.cols[1].id, op: 'lt', a: 3, fg: 'red' }]); assert.equal(L.deleteCol(t2, t2.cols[1].id), true); assert.equal('rules' in t2, false, 'aturan kolom terhapus ikut hilang');
  const t3 = L.newTab('Y'); L.setRules(t3, [{ c: t3.cols[0].id, op: 'lt', a: 3, fg: 'red' }, { c: t3.cols[1].id, op: 'lt', a: 3, fg: 'red' }]); L.deleteCol(t3, t3.cols[1].id); assert.equal(t3.rules.length, 1);
  assert.equal(L.setRules(t3, []), true); assert.equal('rules' in t3, false);
  const old = JSON.parse(JSON.stringify(L.newSheet({ name: 'Lama' }))); assert.equal('rules' in L.cleanSheet(old).tabs[0], false, 'data lama tetap sama persis');
});

test('Rev 145: modul murni, belum ada UI, versi 0.3.121, SCHEMA 14, tes terdaftar', () => {
  const m = src('src/js/lembar-aturan.js'); assert.doesNotMatch(m, /^import /m); assert.doesNotMatch(m, /document\.|window\.|localStorage|sessionStorage|\beval\s*\(|new Function/);
  assert.match(src('src/js/lembar.js'), /import \{ cleanRules \} from '\.\/lembar-aturan\.js'/);
  assert.match(src('src/js/lembar-ui.js'), /lembar-aturan/); /* UI ada sejak Rev 146 (U9b-2b) */ assert.doesNotMatch(src('src/js/lembar-alat.js'), /lembar-aturan/); // UI = U9b-2b
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121')); assert.equal(S.SCHEMA, 22);
  assert.ok(pk.scripts.test.includes('tests/rev145.test.mjs')); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
