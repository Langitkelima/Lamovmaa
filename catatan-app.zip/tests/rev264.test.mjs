// Rev 264: kotak teks Validasi data tidak lagi berhuruf hitam di tema gelap; menu Lainnya = daftar berkelompok tanpa item yang sudah ada di Menu sel (tekan lama). Tes Node; BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8'); const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
test('akar bug: textarea mewarisi warna teks (sebelumnya hanya button,input) + warna eksplisit di kotak pilihan', () => {
  assert.ok(css.includes('button,input,textarea{font:inherit;color:inherit}') && !css.includes('button,input{font:inherit;color:inherit}'));
  assert.ok(css.includes('.lz-checks .lz-ta{color:var(--ink);-webkit-text-fill-color:var(--ink)'));
});
test('Lainnya tidak lagi memuat item yang sudah ada di Menu sel', () => {
  const m = ui.slice(ui.indexOf('const openMore = () => {'), ui.indexOf('bM.addEventListener'));
  for (const k of ['aksi', 'gabung', 'validasi', 'diagram']) assert.ok(!m.includes("item('" + k + "'"), k);
  for (const k of ['salin', 'asc', 'desc', 'cari', 'seri', 'filter', 'warna', 'impor', 'csv', 'tsv']) assert.ok(m.includes("item('" + k + "'"), k);
  assert.ok(!ui.includes('openSelAct'));
  const c = ui.slice(ui.indexOf('const openCellMenu = () => {'), ui.indexOf('const onLongPress'));
  for (const k of ["'merge'", "'clear'", "'dropdown'", "'chart'", "'cut'", "'copy'", "'paste'", "'rowUp'", "'delCols'"]) assert.ok(c.includes(k), k);
  assert.ok(c.includes("'Pisahkan sel' : 'Gabungkan sel'"));
});
test('Lainnya berkelompok: Salin, Urutkan (dua ubin), Olah data, Impor & ekspor; kelas lama tetap', () => {
  const m = ui.slice(ui.indexOf('const openMore = () => {'), ui.indexOf('bM.addEventListener'));
  assert.ok(m.includes("class: 'ov dlgov lz-more lz-menu'") && m.includes("'sheet lm-sheet'"));
  for (const k of ["grp('Salin'", "'Urutkan'", "grp('Olah data'", "grp('Impor & ekspor'", "'lm-pair'", "'lm-q'"]) assert.ok(m.includes(k), k);
});
test('CSS Rev 264 memakai variabel tema (terang/gelap), tanpa heks mentah, kurung seimbang', () => {
  const blk = css.slice(css.indexOf('/* Rev 264')); assert.ok(blk.length > 500);
  assert.doesNotMatch(blk, /#[0-9a-fA-F]{3,6}\b/);
  for (const k of ['var(--gbg)', 'var(--gbd)', 'var(--ink)', 'var(--mut)', '.lm-gl{', '.lm-gt{']) assert.ok(blk.includes(k), k);
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
  assert.ok(!css.includes('.lz-selact'));
});
