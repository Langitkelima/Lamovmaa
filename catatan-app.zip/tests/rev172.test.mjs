// Rev 172: Isi seri kembali ke setelan awal; menu Salin & Tempel (4 cara tempel); Setelan = kolase; menu Lainnya = ubin.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import * as R from '../src/js/rumus.js';
import { copyCell, pasteClip } from '../src/js/lembar-alat.js';
import { PASTE_MODES, pasteMessage } from '../src/js/lembar-ui.js';

const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => { const sh = L.newSheet('t'), tab = sh.tabs[0]; return tab; };
const put = (tab, a, v, s) => { const c = a.charCodeAt(0) - 65, r = Number(a.slice(1)) - 1; const p = typeof v === 'string' && v[0] === '=' ? { fx: R.a1ToStored(v, tab).fx } : { v }; if (s) p.s = s; L.setCell(tab, tab.rows[r].id, tab.cols[c].id, p); };
const cell = (tab, a) => { const c = a.charCodeAt(0) - 65, r = Number(a.slice(1)) - 1; return tab.rows[r].cells[tab.cols[c].id] || {}; };
const at = (a) => ({ r: Number(a.slice(1)) - 1, c: a.charCodeAt(0) - 65 });

test('empat cara tempel terdaftar', () => { assert.deepEqual(PASTE_MODES.map((m) => m.id), ['all', 'content', 'values', 'style']); });
test('Semua: rumus bergeser + gaya ikut', () => {
  const t = mk(); put(t, 'A1', 2); put(t, 'A2', 3); put(t, 'B1', '=A1*2', { b: true }); const s = at('B1'), d = at('B2');
  const clip = copyCell(t, s.r, s.c).clip; const res = pasteClip(t, clip, d.r, d.c, { mode: 'all' });
  assert.equal(res.pasted, 1); assert.equal(R.storedToA1(cell(t, 'B2').fx, t), '=A2*2'); assert.equal(cell(t, 'B2').s.b, true);
});
test('Isi & rumus: rumus ikut, gaya tujuan TIDAK diubah', () => {
  const t = mk(); put(t, 'A1', 2); put(t, 'A2', 3); put(t, 'B1', '=A1*2', { b: true }); put(t, 'B2', 9, { i: true }); const s = at('B1'), d = at('B2');
  pasteClip(t, copyCell(t, s.r, s.c).clip, d.r, d.c, { mode: 'content' });
  assert.equal(R.storedToA1(cell(t, 'B2').fx, t), '=A2*2'); assert.equal(cell(t, 'B2').s.i, true); assert.ok(!cell(t, 'B2').s.b);
});
test('Nilai saja: hasil hitung tanpa rumus, gaya tujuan tetap', () => {
  const t = mk(); put(t, 'A1', 2); put(t, 'B1', '=A1*5', { b: true }); put(t, 'C1', 1, { i: true }); const s = at('B1'), d = at('C1');
  pasteClip(t, copyCell(t, s.r, s.c).clip, d.r, d.c, { mode: 'values' });
  assert.equal(cell(t, 'C1').v, 10); assert.ok(!cell(t, 'C1').fx); assert.equal(cell(t, 'C1').s.i, true);
  const t2 = mk(); put(t2, 'A1', 4); put(t2, 'B1', '=A1', {}); const c2 = copyCell(t2, 0, 1).clip; pasteClip(t2, c2, 1, 1, { valuesOnly: true }); assert.equal(cell(t2, 'B2').v, 4); // valuesOnly lama tetap jalan
});
test('Gaya saja: isi dan rumus tujuan TIDAK berubah, boleh menimpa sel berumus bila sederet', () => {
  const t = mk(); put(t, 'A1', 'x', { b: true, i: true }); put(t, 'B1', '=1+1'); put(t, 'B2', 7);
  pasteClip(t, copyCell(t, 0, 0).clip, 0, 1, { mode: 'style', count: 2, dir: 'down', keepFx: true });
  assert.ok(cell(t, 'B1').fx); assert.equal(cell(t, 'B1').s.b, true); assert.equal(cell(t, 'B2').v, 7); assert.equal(cell(t, 'B2').s.i, true);
});
test('Gaya saja boleh lintas tab (tanpa rumus)', () => {
  const sh = L.newSheet('t'); const a = sh.tabs[0]; put(a, 'A1', 'x', { b: true });
  const clip = copyCell(a, 0, 0).clip; const b = { ...mk(), id: 'lain' };
  const res = pasteClip(b, clip, 0, 0, { mode: 'style' }); assert.equal(res.blocked, ''); assert.equal(cell(b, 'A1').s.b, true);
});
test('Rumus ke tab lain tetap diblokir; pesan jelas', () => {
  const a = mk(); put(a, 'A1', '=1+1'); const clip = copyCell(a, 0, 0).clip; const b = { ...mk(), id: 'lain' };
  const res = pasteClip(b, clip, 0, 0, { mode: 'content' }); assert.equal(res.blocked, 'tab'); assert.match(pasteMessage(res), /tab asalnya/);
});
test('UI: satu item Salin & Tempel, dialog 4 cara, Isi seri tetap ada', () => {
  const u = src('src/js/lembar-ui.js');
  assert.ok(u.includes("item('salin', 'Salin & Tempel'")); for (const k of ["'tempel'", "'tempel-seder'", "'tempel-nilai'"]) assert.ok(!u.includes('item(' + k), k + ' sudah digabung');
  assert.ok(u.includes('const openCopyPaste = () =>')); assert.ok(u.includes("item('seri', 'Isi seri'")); assert.match(u, /class: 'ov dlgov lz-more lz-menu'/);
});
test('Setelan = daftar baris ringkas (kolase dibatalkan), menu sama', () => {
  const st = src('src/js/settings.js'); assert.ok(!st.includes("class: 'collage'"));
  for (const k of ["'Label catatan'", "'Gambar'", "'Lembar kerja'", "'Cadangan otomatis'", "'Tempat sampah'", "'Sync'", "'TWO POCKETS'", "'Tutup aplikasi'"]) assert.ok(st.includes(k), k);
  assert.match(src('src/js/main.js'), /mainEl\.dataset\.tab = ui\.tab/);
});
test('CSS Rev 172: kolase, ubin, menu, dialog; tanpa warna tetap (pakai variabel tema)', () => {
  const css = src('src/css/styles.css'); const i = css.indexOf('Rev 172'); assert.ok(i > 0); const blk = css.slice(i);
  for (const k of ['.lz-menu .lz-mi{', '.lz-cpv .cp-mode{', 'var(--gbg)', 'color-mix(in srgb,var(--tn)']) assert.ok(blk.includes(k), k);
  assert.ok(!/#[0-9a-fA-F]{6}/.test(blk.replace(/#4CC9A0|#E7A94B|#2FB38A/g, '')), 'warna mentah hanya untuk titik status');
  let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('Rev 172: versi 0.3.121, SCHEMA 18, tanpa perubahan native/dependensi', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/);
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']); assert.ok(pk.scripts.test.includes('tests/rev172.test.mjs'));
});
