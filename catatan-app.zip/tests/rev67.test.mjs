// Rev 67: Sub-tugas (task.subs, SCHEMA 9). Logika murni, migrasi data, kabel UI, dan batas perubahan.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as L from '../src/js/logic.js';
import * as S from '../src/js/storage.js';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const main = src('src/js/main.js'), css = src('src/css/styles.css');

test('Rev 67: canHaveSubs hanya untuk Fokus, Target, Rencana (bukan Kebiasaan)', () => {
  assert.equal(L.canHaveSubs('hari'), true); assert.equal(L.canHaveSubs('minggu'), true); assert.equal(L.canHaveSubs('bulan'), true);
  assert.equal(L.canHaveSubs('habit'), false); assert.equal(L.canHaveSubs(undefined), false);
});
test('Rev 67: cleanSubs membuang entri rusak, memotong judul 120, memberi id unik, batas 20', () => {
  const dirty = [null, 5, { title: '   ' }, { id: 'a', title: ' satu ', done: true }, { id: 'a', title: 'dua' }, { title: 'x'.repeat(300), done: 'ya' }];
  const c = L.cleanSubs(dirty);
  assert.equal(c.length, 3);
  assert.equal(c[0].title, 'satu'); assert.equal(c[0].done, true);
  assert.notEqual(c[1].id, 'a'); assert.equal(new Set(c.map((x) => x.id)).size, 3);
  assert.equal(c[2].title.length, 120); assert.equal(c[2].done, false);
  assert.equal(L.cleanSubs(Array.from({ length: 30 }, (_, i) => ({ id: 'i' + i, title: 't' + i }))).length, L.SUB_MAX);
  assert.deepEqual(L.cleanSubs('bukan larik'), []);
});
test('Rev 67: addSub menolak kosong, terlalu panjang, dan melewati batas 20; tidak mengubah larik asli', () => {
  const base = [{ id: '1', title: 'a', done: false }];
  const r = L.addSub(base, '  baru ');
  assert.equal(r.ok, true); assert.equal(r.subs.length, 2); assert.equal(r.subs[1].title, 'baru'); assert.equal(base.length, 1);
  assert.equal(L.addSub(base, '   ').ok, false);
  assert.equal(L.addSub(base, 'x'.repeat(121)).ok, false);
  const full = Array.from({ length: 20 }, (_, i) => ({ id: 'f' + i, title: 't', done: false }));
  const over = L.addSub(full, 'lagi'); assert.equal(over.ok, false); assert.match(over.msg, /Maksimal 20/);
});
test('Rev 67: subProgress menghitung selesai/total dan tidak otomatis menyelesaikan induk', () => {
  assert.deepEqual(L.subProgress({}), { done: 0, total: 0, text: '', all: false });
  const t = { done: false, subs: [{ done: true }, { done: true }, { done: false }] };
  const p = L.subProgress(t); assert.equal(p.text, '2/3'); assert.equal(p.all, false);
  t.subs[2].done = true;
  assert.equal(L.subProgress(t).all, true);
  assert.equal(t.done, false); // induk tidak berubah sendiri
});
test('Rev 67: SCHEMA 9; data v8 tanpa subs tetap valid dan tidak berubah', () => {
  assert.equal(S.SCHEMA, 22);
  const d = S.normalize({ version: 8, tasks: [{ id: 't', title: 'lama', scope: 'hari', done: false }], habits: [{ id: 'h', title: 'k', done: false }] });
  assert.equal(d.tasks[0].subs, undefined); assert.equal(d.tasks[0].title, 'lama'); assert.equal(d.habits.length, 1);
});
test('Rev 67: normalize membersihkan subs rusak, membuang subs di luar Fokus/Target/Rencana, dan membersihkan tugas di Tempat sampah', () => {
  const d = S.normalize({ tasks: [
    { id: 'a', title: 'A', scope: 'minggu', subs: [{ id: 'x', title: 'ok', done: true }, { title: '' }, 7] },
    { id: 'b', title: 'B', scope: 'habit', subs: [{ id: 'y', title: 'tidak boleh' }] },
    { id: 'c', title: 'C', scope: 'bulan', subs: [] },
  ], trash: [{ kind: 'task', at: 1, item: { id: 'd', title: 'D', scope: 'hari', subs: [{ title: ' sampah ' }, null] } }] });
  assert.equal(d.tasks[0].subs.length, 1); assert.equal(d.tasks[0].subs[0].done, true);
  assert.equal(d.tasks[1].subs, undefined); assert.equal(d.tasks[2].subs, undefined);
  assert.equal(d.trash[0].item.subs.length, 1); assert.equal(d.trash[0].item.subs[0].title, 'sampah');
});
test('Rev 67: sub-tugas ikut ekspor dan impor cadangan (roundtrip) dan ikut tugas ke Tempat sampah', () => {
  const d = S.emptyData();
  d.tasks.push({ id: 't1', title: 'Induk', scope: 'hari', done: false, subs: [{ id: 's1', title: 'Langkah 1', done: true }, { id: 's2', title: 'Langkah 2', done: false }] });
  const back = S.importJSON(S.exportJSON(d));
  assert.equal(back.ok, true);
  assert.deepEqual(back.data.tasks[0].subs, d.tasks[0].subs);
  // ke Tempat sampah sebagai objek yang sama (remove() di main.js memindahkan item utuh)
  const item = d.tasks.pop(); d.trash.push({ kind: 'task', item, at: Date.now() });
  const again = S.importJSON(S.exportJSON(d));
  assert.equal(again.data.trash[0].item.subs.length, 2);
});
test('Rev 67: kabel UI: chip progres, daftar buka/tutup, centang tersimpan, editor di lembar tugas, Kebiasaan tanpa sub-tugas', () => {
  assert.match(main, /subProgress\(item\)/);
  assert.match(main, /class: 'subchip'/);
  assert.match(main, /openSubs\.(has|add|delete)/);
  assert.match(main, /sb\.done = !sb\.done; syncTaskAlarms\(item\); persist\(\); render\(\)/); // Rev 68: centang juga menyelaraskan alarm sub-tugas
  assert.match(main, /const hasSubs = !isH && canHaveSubs\(/);
  assert.match(main, /'Sub-tugas', subHint, subSw/);
  assert.match(main, /addSub\(draft, subIn\.value\)/);
  assert.match(main, /cleanSubs\(draft\)/);
  assert.match(main, /else delete item\.subs/);
  assert.match(main, /e\.stopPropagation\(\)/); // chip tidak ikut membuka lembar ubah
});
test('Rev 67: teks yang sudah diketik tapi belum ditambah tidak hilang saat Simpan', () => {
  assert.match(main, /if \(hasSubs && subsOn\) \{ const sr = pushSub\(\); if \(!sr\.ok\)/);
});
test('Rev 67: CSS solid tanpa backdrop-filter/animasi berulang; teks pengguna lewat textContent (tanpa innerHTML)', () => {
  const blk = css.slice(css.indexOf('===== Rev 67'), css.indexOf('/* Rev 92')).replace(/\/\*[\s\S]*?\*\//g, '');
  for (const k of ['.subchip', '.subs{', '.srow', '.ck.sm', '.task-subs']) assert.ok(blk.includes(k), k);
  assert.ok(!/backdrop-filter|animation/.test(blk));
  assert.ok(!/innerHTML/.test(main));
});
test('Rev 67: tanpa perubahan native/plugin/workflow; versi 0.3.2 selaras', () => {
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121');
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(!/\bsubs\b|subtugas|sub-tugas/i.test(src('scripts/apply-native.mjs')));
});
