// Rev 253 / S4: ubah lebar/tinggi BANYAK kolom/baris sekaligus dari seleksi. Tes Node (model murni + kabel di lembar-ui.js); BUKAN uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as S from '../src/js/lembar-seleksi.js';
import { dragRowHeight, dragRowHeightN, GRID_MAX_H, HEAD } from '../src/js/lembar-baris.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), css = src('src/css/styles.css');
const between = (a, b) => ui.slice(ui.indexOf(a), ui.indexOf(b, ui.indexOf(a)));
const dm = { rows: 30, cols: 8 };
test('resizeSet: kepala "on" = semua kolom/baris terpilih; selain itu hanya dirinya; masukan rusak = []', () => {
  const k = S.selectCol(dm, 2); assert.deepEqual(S.resizeSet(S.extend(dm, k, { r: 5, c: 4 }), 'col', 3, dm), [2, 3, 4]);
  assert.deepEqual(S.resizeSet(S.extend(dm, k, { r: 5, c: 4 }), 'col', 6, dm), [6], 'kolom di luar seleksi = sendiri');
  const r = S.extend(dm, S.selectRow(dm, 1), { r: 3, c: 0 }); assert.deepEqual(S.resizeSet(r, 'row', 2, dm), [1, 2, 3]); assert.deepEqual(S.resizeSet(r, 'row', 9, dm), [9]);
  assert.deepEqual(S.resizeSet(S.selectCell(dm, 1, 1), 'col', 1, dm), [1], 'satu sel = hanya kolom itu (tersentuh, bukan penuh)');
  assert.equal(S.resizeSet(S.selectAll(dm), 'col', 0, dm).length, 8); assert.equal(S.resizeSet(S.selectAll(dm), 'row', 0, dm).length, 30);
  assert.deepEqual(S.resizeSet(null, 'col', 2, dm), [2]); assert.deepEqual(S.resizeSet(r, 'x', 2, dm), []); assert.deepEqual(S.resizeSet(r, 'row', -1, dm), []);
});
test('dragRowHeightN: count=1 sama dengan dragRowHeight; pagar total untuk banyak baris; menempel ke 40', () => {
  for (const [s, d, o] of [[40, 10, 0], [40, -100, 500], [100, 25, 9000], [40, 2, 0], [200, 1e9, 123]]) assert.equal(dragRowHeightN(s, d, 1, o), dragRowHeight(s, d, o));
  assert.equal(dragRowHeightN(40, 2, 5, 0), 40, 'snap ke 40');
  const cap = 10000, n = dragRowHeightN(100, 1e9, 4, 1000, cap); assert.ok(1000 + 4 * n <= cap - HEAD, 'total tidak melewati cap'); assert.equal(n, Math.floor((cap - HEAD - 1000) / 4));
  assert.equal(dragRowHeightN(100, -1e9, 7), 16, 'minimal ROW_MIN'); assert.equal(dragRowHeightN(NaN, NaN, 0, NaN), 40, 'rusak = bawaan');
  assert.ok(dragRowHeightN(100, 1e9, 500, 0) * 500 <= GRID_MAX_H);
});
test('kolom: semua kolom terpilih sama lebar, batal = semua kembali, SATU Urungkan, garis pratinjau', () => {
  const d = between('let rz = null;', '// --- Rev 184b');
  for (const k of ["SX.resizeSet(selx, 'col'", 'for (const it of rz.set) L.setColWidth(tab, it.id, w)', 'showGd(true', "gd.hidden = true", 'hist.push(r.snap)']) assert.ok(d.includes(k), k);
  assert.equal((d.match(/hist\.push/g) || []).length, 1, 'satu langkah Urungkan');
  assert.ok(d.includes('for (const it of r.set) L.setColWidth(tab, it.id, it.w)'), 'batal mengembalikan semua');
});
test('baris: semua baris terpilih sama tinggi, pagar fitsLimit mengembalikan semua, SATU Urungkan', () => {
  const d = between('let rr = null;', 'const onScroll');
  for (const k of ["SX.resizeSet(selx, 'row'", 'dragRowHeightN(rr.h, e.clientY - rr.y, rr.set.length, rr.others)', 'for (const it of rr.set) L.setRowHeight(tab, it.id, n)', 'showGd(false', 'back()', 'L.fitsLimit(sheet)']) assert.ok(d.includes(k), k);
  assert.equal((d.match(/hist\.push/g) || []).length, 1); assert.ok(d.includes('if (!inSet.has(i)) others += x.h || ROW_H'), 'others hanya baris yang tidak ikut');
});
test('garis pratinjau hanya di layar; pegangan lama dan seret satu kolom/baris tidak berubah', () => {
  assert.match(css, /\.lz-gd\{[^}]*pointer-events:none/); assert.match(css, /\.lz-gd\[hidden\]\{display:none\}/); assert.match(css, /\.lz-gd\.v\{/); assert.match(css, /\.lz-gd\.hz\{/);
  assert.doesNotMatch(css, /\.lz-gd\{[^}]*#[0-9a-fA-F]{3,6}/, 'tanpa heks mentah');
  assert.ok(ui.includes("headRow.addEventListener('pointerdown', rzDown)") && ui.includes("body.addEventListener('pointerdown', rrDown)"));
  assert.ok(ui.includes('set: set.length ? set : [{ id: c.id, w: c.w }]'), 'tanpa seleksi penuh = hanya kolom yang diseret');
});
