// Rev 49: ekspor PDF/JPG ikut teks mengalir di samping gambar (data-f=1), PDF tetap kanvas A4.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseNoteHtml, layoutDoc, paginate } from '../src/js/export.js';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const measure = (s, st) => s.length * (st.size || 30) * 0.5;
const o = { width: 1240, pageH: 1754, padX: 110, padTop: 120, padBottom: 130, size: 30, titleSize: 46, measure };
const fig = (extra = '') => `<figure class="ki" data-kimg="abcdefghij12" data-w="400" data-h="600" data-s="40" data-a="l" ${extra}></figure>`;
const words = (k) => Array.from({ length: k }, (_, i) => 'kata' + i).join(' ');
t('parser membawa data-f', () => {
  assert.equal(parseNoteHtml(fig('data-f="1"') + '<div>x</div>')[0].float, true);
  assert.equal(parseNoteHtml(fig() + '<div>x</div>')[0].float, false);
});
t('teks di samping gambar kiri: bergeser ke kanan gambar, satu kelompok float', () => {
  const lines = layoutDoc({ title: '', blocks: parseNoteHtml(fig('data-f="1"') + '<div>Ffff</div><div>Gghh</div>') }, o);
  assert.equal(lines.length, 1);
  const g = lines[0];
  assert.equal(g.kind, 'float');
  assert.ok(g.img.w < 1020 && g.img.x === 110);
  const texts = g.lines.filter((l) => l.kind === 'text');
  assert.equal(texts.length, 2);
  for (const l of texts) assert.ok(l.x >= 110 + g.img.w, 'teks harus di kanan gambar');
  assert.ok(g.lh >= g.img.h);
});
t('gambar kanan: teks tetap di kiri dan lebih sempit', () => {
  const html = fig('data-f="1"').replace('data-a="l"', 'data-a="r"') + '<div>' + words(60) + '</div>';
  const g = layoutDoc({ title: '', blocks: parseNoteHtml(html) }, o)[0];
  const first = g.lines.find((l) => l.kind === 'text');
  assert.equal(first.x, 110);
  for (const l of g.lines.filter((x) => x.kind === 'text')) {
    const last = l.segs[l.segs.length - 1]; assert.ok(last.x + measure(last.t, { size: 30 }) <= g.img.x, 'tidak menabrak gambar');
  }
});
t('teks panjang: yang melewati tinggi gambar kembali selebar penuh', () => {
  const lines = layoutDoc({ title: '', blocks: parseNoteHtml(fig('data-f="1"') + '<div>' + words(400) + '</div>') }, o);
  assert.equal(lines[0].kind, 'float');
  assert.ok(lines.length > 1 && lines[1].kind === 'text' && lines[1].x === 110);
  const wide = lines.slice(1).filter((l) => l.kind === 'text');
  const beside = lines[0].lines.filter((l) => l.kind === 'text');
  assert.ok(Math.min(...beside.map((l) => l.segs[0].x)) > Math.max(...wide.map((l) => l.segs[0].x)), 'baris di samping gambar mulai lebih ke kanan');
});
t('tanpa data-f, tengah, atau 75% ke atas: gambar tetap berdiri sendiri (perilaku lama)', () => {
  for (const html of [fig() + '<div>x</div>', fig('data-f="1"').replace('data-a="l"', 'data-a="c"') + '<div>x</div>', fig('data-f="1"').replace('data-s="40"', 'data-s="80"') + '<div>x</div>']) {
    const l = layoutDoc({ title: '', blocks: parseNoteHtml(html) }, o);
    assert.equal(l[0].kind, 'image'); assert.ok(!l.some((x) => x.kind === 'float'));
  }
});
t('tabel memutus aliran; satu kelompok tidak terbelah di antara halaman', () => {
  const html = fig('data-f="1"') + '<div>a</div><table><tr><td>x</td></tr></table>';
  const l = layoutDoc({ title: '', blocks: parseNoteHtml(html) }, o);
  assert.deepEqual(l.map((x) => x.kind), ['float', 'tableRow']);
  const pages = paginate(layoutDoc({ title: 'J', blocks: parseNoteHtml('<div>' + words(900) + '</div>' + fig('data-f="1"') + '<div>samping</div>') }, o), o);
  for (const p of pages) assert.ok(p.used <= o.pageH - o.padTop - o.padBottom + 60);
});
t('PDF tetap kanvas A4 (1240x1754 px = 210x297 mm pada 150 dpi) dan share.js menggambar kelompok float', () => {
  const sh = src('../src/js/share.js');
  assert.ok(sh.includes('width: 1240, pageH: 1754'));
  assert.ok(sh.includes("l.kind === 'float'"));
  assert.ok(src('../src/js/export.js').includes('pageW = 595.28, pageH = 841.89'));
});
t('data tidak berubah: SCHEMA 7; versi 0.3.2', () => {
  assert.match(src('../src/js/storage.js'), /SCHEMA = 22/);
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
});
console.log(`${n} tes lulus (Rev 49)`);
