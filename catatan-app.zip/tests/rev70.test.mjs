// Rev 70: teks kartu tugas/kebiasaan rata tengah dengan lingkaran centang + kebiasaan KAPITAL.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const src = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const main = src('src/js/main.js'), css = src('src/css/styles.css'), settings = src('src/js/settings.js');
test('Rev 70: judul kartu memakai kelas .tcap (bukan .cap yang bermargin atas 8px)', () => {
  assert.match(main, /h\('b', \{ class: 'tcap' \}, item\.title\)/);
  assert.ok(!/class: isH \? null : 'cap'/.test(main));
  assert.match(css, /\.tx b\.tcap\{margin:0;line-height:1\.3\}/);
  assert.match(css, /\.row \.tx\{display:flex;flex-direction:column;justify-content:center\}/);
});
test('Rev 70: keterangan kecil (.cap) tidak ikut kapital lagi', () => {
  assert.ok(!/\n\.cap,\.cap-in\{text-transform:uppercase\}/.test(css));
});
test('Rev 70: kebiasaan diketik dan disimpan KAPITAL', () => {
  assert.match(main, /capInput\(title\)/);
  assert.ok(!/isH \? v\.value/.test(main));
  assert.match(main, /title: v\.value\.toUpperCase\(\)/);
  assert.match(main, /item\.title = v\.value\.toUpperCase\(\)/);
});
test('Rev 70: versi 0.3.2', () => {
  assert.match(settings, /Notes Kelimaa v0\.3\.121/);
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
});
