// Rev 182 / U10d-3: empat templat lembar kerja baru (Perencana belajar, Faktur, Pelacak proyek, Pelacak kebiasaan) + dukungan gabung sel (`merges`) dan baris judul bernomor (`head: n`) di mesin templat.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { mergeList, isCovered } from '../src/js/lembar-gabung.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { chartList } from '../src/js/lembar-grafik.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 10, 12, 0, 0).getTime(); // 10 Nov 2026
const mk = (id, o = {}) => T.makeFromTemplate(id, { now: NOW, ...o });
const row = (d, i, n, from = 0) => Array.from({ length: n }, (_, j) => d.text(i, from + j));
const NEW = ['belajar', 'faktur', 'proyek', 'kebiasaan'];
const cid = (tab, j) => tab.cols[j].id, rid = (tab, i) => tab.rows[i].id;
const put = (tab, i, j, patch) => L.setCell(tab, rid(tab, i), cid(tab, j), patch);
const sty = (tab, i, j) => (tab.rows[i].cells[cid(tab, j)] || {}).s || {};

test('Rev 182: 8 templat lama pertama (4 lama + 4 baru, Bahasa Indonesia, ID unik)', () => {
  const l = T.templateList().slice(-10); // Rev 293: templat lama kini paling belakang
  assert.deepEqual(l.slice(0, 8).map((t) => t.id), ['anggaran', 'bagi', 'jadwal', 'nilai', ...NEW]); // Rev 183 menambah 4 sesudahnya (rev186.test.mjs)
  assert.deepEqual(l.slice(4, 8).map((t) => t.name), ['Perencana belajar', 'Faktur', 'Pelacak proyek', 'Pelacak kebiasaan']);
  assert.equal(new Set(l.map((t) => t.id)).size, l.length);
  for (const t of l.slice(4, 8)) { assert.ok(t.desc.length > 10); assert.doesNotMatch(t.name + ' ' + t.desc, /\b(Study|planner|Invoice|Project|tracker|Habit)\b/); assert.equal(T.hasTemplate(t.id), true); }
});
test('Rev 182: keempat templat baru membangun lembar sah (tanpa rumus ditolak, muat batas, bulat-balik cleanSheet, ID unik per panggilan, nama bisa diganti)', () => {
  for (const id of NEW) {
    const r = mk(id); assert.ok(r, id); assert.equal(r.failed, 0, id);
    const sh = r.sheet; assert.equal(sh.tabs.length, 1); assert.ok(L.fitsLimit(sh)); assert.ok(L.isSheetId(sh.id));
    assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(sh)))), JSON.stringify(sh), id);
    assert.notEqual(mk(id).sheet.id, mk(id).sheet.id); assert.equal(mk(id, { name: 'Punyaku' }).sheet.name, 'Punyaku');
    const d = makeDisplay(sh.tabs[0]);
    for (let i = 0; i < 16; i++) for (let j = 0; j < 9; j++) assert.doesNotMatch(d.text(i, j), /^#|NaN|undefined/, id + ' ' + i + ',' + j); // tidak ada galat rumus
  }
});

test('Rev 182: mesin = `merges` menggabung sel sesudah isi; sel tertutup kosong; gabungan lolos pembersih; nomor baris judul (`head: n`) menggaya baris itu saja', () => {
  const tab = mk('faktur').sheet.tabs[0];
  assert.deepEqual(mergeList(tab).map((m) => m.ref), ['A1:D1', 'B3:D3']);
  assert.equal(isCovered(tab, 0, 1), true); assert.equal(isCovered(tab, 0, 0), false); assert.equal(isCovered(tab, 2, 3), true);
  assert.equal(tab.merges.length, 2);
  const d = makeDisplay(tab); assert.deepEqual(row(d, 0, 4), ['FAKTUR', '', '', '']); assert.deepEqual(row(d, 2, 4), ['Kepada', 'Nama pelanggan', '', '']);
  assert.equal(sty(tab, 4, 0).bg, '#DBEAFE'); assert.equal(sty(tab, 4, 0).fg, '#111827'); assert.equal(sty(tab, 4, 0).b, true); // judul tabel di baris 5
  assert.equal(sty(tab, 1, 0).bg, undefined); assert.equal(sty(tab, 1, 0).b, true); // "Nomor" tebal tanpa latar
  assert.equal(sty(tab, 0, 0).ha, 'center'); assert.equal(sty(tab, 0, 0).fg, '#111827');
  for (const id of ['anggaran', 'bagi', 'jadwal', 'nilai', 'belajar', 'proyek', 'kebiasaan']) assert.equal(mk(id).sheet.tabs[0].merges, undefined, id); // tanpa `merges` = tanpa gabungan
});

test('Rev 182: Faktur = subtotal, pajak 11%, total; baris kosong tidak galat; berubah mengikuti isian', () => {
  const tab = mk('faktur').sheet.tabs[0]; let d = makeDisplay(tab);
  assert.equal(tab.name, 'Faktur'); assert.deepEqual(row(d, 4, 4), ['Barang', 'Jumlah', 'Harga', 'Subtotal']);
  assert.deepEqual(row(d, 5, 4), ['Desain logo', '1', 'Rp 1.500.000', 'Rp 1.500.000']); assert.deepEqual(row(d, 6, 4), ['Cetak brosur', '100', 'Rp 5.000', 'Rp 500.000']);
  assert.deepEqual(row(d, 8, 4), ['', '', '', '']); assert.deepEqual(row(d, 9, 4), ['', '', '', '']);
  assert.equal(d.text(10, 3), 'Rp 2.050.000'); assert.equal(d.text(11, 1), '11%'); assert.equal(d.text(11, 3), 'Rp 225.500'); assert.equal(d.text(12, 2), 'Total'); assert.equal(d.text(12, 3), 'Rp 2.275.500');
  assert.equal(d.text(1, 3), '10/11/2026'); assert.equal(d.text(1, 1), 'INV-001');
  put(tab, 8, 0, { v: 'Pajang' }); put(tab, 8, 1, { v: 2 }); put(tab, 8, 2, { v: 100000 }); // baris kosong dipakai
  put(tab, 11, 1, { v: 0 }); d = makeDisplay(tab); // tarif pajak 0
  assert.equal(d.text(8, 3), 'Rp 200.000'); assert.equal(d.text(10, 3), 'Rp 2.250.000'); assert.equal(d.text(11, 3), 'Rp 0'); assert.equal(d.text(12, 3), 'Rp 2.250.000');
  assert.equal(sty(tab, 12, 2).b, true); assert.equal(sty(tab, 12, 3).fg, '#111827'); assert.equal(sty(tab, 10, 2).b, true); assert.equal(sty(tab, 12, 0).bg, undefined);
  assert.equal(chartList(tab).length, 0);
});

test('Rev 182: Perencana belajar = sisa hari dari TODAY, kemajuan (maks. 100%), Selesai, Total', () => {
  const tab = mk('belajar').sheet.tabs[0]; let d = makeDisplay(tab);
  assert.equal(tab.name, 'Belajar'); assert.deepEqual(row(d, 0, 8), ['Mata pelajaran', 'Topik', 'Tenggat', 'Sisa hari', 'Jam rencana', 'Jam selesai', 'Kemajuan', 'Selesai']);
  assert.deepEqual([...row(d, 1, 3), ...row(d, 1, 8).slice(4)], ['Matematika', 'Latihan turunan', '13/11/2026', '6', '4', '67%', '']);
  const n = new Date(), todaySerial = Math.floor((Date.UTC(n.getFullYear(), n.getMonth(), n.getDate()) - Date.UTC(1899, 11, 30)) / 86400000);
  assert.equal(d.raw(1, 3), d.raw(1, 2) - todaySerial); // Sisa hari = Tenggat - TODAY() (jam sistem sungguhan)
  assert.equal(d.raw(1, 2) - d.raw(5, 2), 1); assert.equal(d.raw(6, 2) - d.raw(1, 2), 11); // tenggat contoh relatif terhadap `now`
  assert.deepEqual(row(d, 2, 8).slice(4), ['5', '5', '100%', 'Ya']); assert.equal(d.text(2, 3), ''); assert.equal(d.text(5, 3), ''); // selesai: sisa hari kosong
  assert.deepEqual(row(d, 7, 8), ['Total', '', '', '', '32', '16', '50%', '2']);
  put(tab, 4, 5, { v: 6 }); d = makeDisplay(tab); // Sejarah: jam selesai > rencana -> kemajuan dibatasi 100%
  assert.equal(d.text(4, 6), '100%'); assert.equal(d.text(4, 7), 'Ya'); assert.equal(d.text(4, 3), ''); assert.equal(d.text(7, 5), '22'); assert.equal(d.text(7, 6), '69%'); assert.equal(d.text(7, 7), '3');
  put(tab, 1, 4, { v: 0 }); d = makeDisplay(tab); assert.equal(d.text(1, 6), '0%'); assert.equal(d.text(1, 7), ''); // jam rencana 0 tidak galat
  assert.equal(sty(tab, 7, 0).b, true); assert.equal(sty(tab, 0, 0).bg, '#DBEAFE'); assert.equal(chartList(tab).length, 0);
});

test('Rev 182: Pelacak proyek = jumlah tugas per status (COUNTIF) + Total, diagram donat G1:H4', () => {
  const tab = mk('proyek').sheet.tabs[0]; let d = makeDisplay(tab);
  assert.equal(tab.name, 'Proyek'); assert.deepEqual(row(d, 0, 8), ['Tugas', 'Penanggung jawab', 'Status', 'Tenggat', 'Prioritas', '', 'Status', 'Jumlah']);
  assert.deepEqual(row(d, 1, 5), ['Rancang desain halaman', 'Citra', 'Selesai', '05/11/2026', 'Tinggi']); assert.equal(d.text(7, 3), '08/11/2026');
  assert.deepEqual([1, 2, 3, 4].map((i) => d.text(i, 6) + '=' + d.text(i, 7)), ['Belum mulai=3', 'Dikerjakan=2', 'Selesai=2', 'Total=7']);
  put(tab, 2, 2, { v: 'Selesai' }); d = makeDisplay(tab); // Tulis kode formulir -> Selesai
  assert.deepEqual([1, 2, 3, 4].map((i) => d.text(i, 7)), ['3', '1', '3', '7']);
  put(tab, 8, 0, { v: 'Tugas baru' }); put(tab, 8, 2, { v: 'Belum mulai' }); d = makeDisplay(tab); // baris 9 ikut terhitung
  assert.deepEqual([1, 2, 3, 4].map((i) => d.text(i, 7)), ['4', '1', '3', '8']);
  const cs = chartList(tab); assert.equal(cs.length, 1); assert.equal(cs[0].kind, 'donut'); assert.equal(cs[0].title, 'Tugas menurut status'); assert.equal(cs[0].ref, 'G1:H4'); assert.equal(cs[0].valueCol, 7);
  assert.equal(sty(tab, 4, 6).b, true); assert.equal(sty(tab, 4, 7).fg, '#111827'); assert.equal(sty(tab, 4, 0).bg, undefined); // Total hanya di G5:H5
});

test('Rev 182: Pelacak kebiasaan = centang ✓ dihitung per kebiasaan dan per hari, diagram kolom A9:B16, sel centang terang + teks gelap', () => {
  const tab = mk('kebiasaan').sheet.tabs[0]; let d = makeDisplay(tab);
  assert.equal(tab.name, 'Kebiasaan'); assert.deepEqual(row(d, 0, 9), ['Kebiasaan', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min', 'Pekan ini']);
  assert.deepEqual(row(d, 1, 9), ['Minum 8 gelas air', '✓', '✓', '✓', '✓', '✓', '', '', '5']); assert.equal(d.text(2, 8), '3'); assert.equal(d.text(6, 8), ''); // baris cadangan kosong
  assert.deepEqual([9, 10, 11, 12, 13, 14, 15].map((i) => d.text(i, 0) + '=' + d.text(i, 1)), ['Senin=4', 'Selasa=3', 'Rabu=3', 'Kamis=5', 'Jumat=1', 'Sabtu=3', 'Minggu=0']);
  assert.deepEqual(row(d, 8, 2), ['Hari', 'Selesai']);
  put(tab, 1, 7, { v: '✓' }); put(tab, 6, 0, { v: 'Peregangan' }); put(tab, 6, 1, { v: '✓' }); d = makeDisplay(tab); // centang baru + kebiasaan baru di baris cadangan
  assert.equal(d.text(1, 8), '6'); assert.equal(d.text(6, 8), '1'); assert.equal(d.text(15, 1), '1'); assert.equal(d.text(9, 1), '5');
  assert.equal(sty(tab, 1, 1).bg, '#DCFCE7'); assert.equal(sty(tab, 1, 1).fg, '#111827'); assert.equal(sty(tab, 1, 1).ha, 'center'); assert.equal(tab.rows[1].cells[cid(tab, 6)], undefined); // tanpa centang = sel kosong
  assert.equal(sty(tab, 8, 0).bg, '#DBEAFE'); assert.equal(sty(tab, 8, 1).fg, '#111827');
  const cs = chartList(tab); assert.equal(cs.length, 1); assert.equal(cs[0].kind, 'column'); assert.equal(cs[0].title, 'Kebiasaan selesai per hari'); assert.equal(cs[0].ref, 'A9:B16'); assert.equal(cs[0].valueCol, 1);
  assert.equal(tab.cols[0].w, 170); assert.equal(tab.cols[1].w, 52); assert.equal(tab.cols[8].w, 80);
});

test('Rev 182: modul tetap murni (hanya lembar.js dan lembar-tampil.js), memakai L.mergeCells dengan clear, hanya settings.js yang memakai; fungsi rumus hanya yang sudah ada', () => {
  const s = src('src/js/lembar-templat.js');
  assert.doesNotMatch(s, /localStorage|document\.|window\.|AndroidAPI|Intl\.|eval\(|new Function/);
  assert.match(s, /from '\.\/lembar\.js'/); assert.match(s, /from '\.\/lembar-tampil\.js'/); assert.doesNotMatch(s, /from '\.\/(rumus|lembar-ui|lembar-pulau|storage)\.js'/);
  assert.match(s, /L\.mergeCells\(tab, m\[0\], m\[1\], m\[2\], m\[3\], \{ clear: true \}\)/); assert.match(s, /def\.head === true \? 0 : Number\.isInteger\(def\.head\)/);
  for (const f of ['notes', 'main', 'lembar', 'lembar-ui', 'lembar-pulau', 'storage', 'export', 'share']) assert.doesNotMatch(src('src/js/' + f + '.js'), /lembar-templat/, f);
  assert.match(src('src/js/settings.js'), /templateList\(\)\.map/);
  const used = new Set([...s.matchAll(/'(=[^']*)'/g)].flatMap((m) => [...m[1].matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1])));
  for (const f of used) assert.ok(['SUM', 'SUMIF', 'AVERAGE', 'COUNT', 'COUNTA', 'COUNTIF', 'IF', 'OR', 'MIN', 'TODAY'].includes(f), 'fungsi ' + f);
});
test('Rev 182: versi 0.3.121, SCHEMA 18, tidak ada perubahan native/CSS', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22\b/);
  assert.ok(JSON.parse(src('package.json')).scripts.test.includes('tests/rev185.test.mjs'));
});
