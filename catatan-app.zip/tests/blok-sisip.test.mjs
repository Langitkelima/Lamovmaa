import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const notes = readFileSync(new URL('../src/js/notes.js', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
test('Sisip blok tidak pernah membelah isi blok sisipan lain', () => {
  assert.match(notes, /const BLOCK_SEL = '\.kb-date-block,\.kb-time-block,\.kb-countdown-block,\.mood-block,\.lk-card'/);
  assert.match(notes, /const insideBlock = top && top !== ed && top\.matches && top\.matches\(BLOCK_SEL\);\s*if \(insideBlock\) top\.after\(block, tail\)/);
});
test('Catatan yang sudah rusak (blok bersarang) diperbaiki saat dibuka/disanitasi', () => {
  assert.match(notes, /function ejectNestedBlocks\(block\)/);
  assert.equal((notes.match(/ejectNestedBlocks\(block\);/g) || []).length, 2);
  assert.equal((notes.match(/block\.replaceChildren\(label\);/g) || []).length, 2);
});
test('sanitize tidak meneruskan indeks forEach sebagai parameter now', () => {
  assert.doesNotMatch(notes, /\.forEach\(sync(Mood|DateBlock|TimeBlock|CountdownBlock)\)/);
});
test('Ketuk Tanggal/Waktu membuka alat Kecil/Normal/Besar/Hapus yang tidak ikut tersimpan', () => {
  assert.match(notes, /const kbTools = \(blk\)/);
  assert.match(notes, /\[\['small', 'Kecil'\], \['normal', 'Normal'\], \['large', 'Besar'\], \['delete', 'Hapus'\]\]/);
  assert.match(notes, /\[\['edit', 'Ubah'\], \['delete', 'Hapus'\]\]/); // Rev 90: kartu Hitung mundur
  assert.match(notes, /tools\.setAttribute\('data-kb-tool', ''\)/);
  assert.match(notes, /k === 'data-kb-size' && \/\^\(small\|normal\|large\)\$\/\.test\(v\)/);
  assert.match(notes, /closest\('\.mood-block,\.kb-date-block,\.kb-time-block,\.kb-countdown-block,\.kb-tools(,\.lk-card)?'\)/); // Rev 324: .lk-card ditambahkan (bilah kartu tautan tidak ditutup sebelum klik)
});
test('Hitung mundur punya tombol Hapus di dialog dan CSS ukuran tersedia', () => {
  assert.match(notes, /class: 'btn line cd-del'/);
  for (const sel of ['.kb-date-block[data-kb-size="small"]', '.kb-time-block[data-kb-size="large"]', '.kb-tools', '.cd-del']) assert.ok(css.includes(sel), sel);
});
