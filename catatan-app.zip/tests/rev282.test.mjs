// Rev 282 / V6c-2 (Validasi): editor kriteria "Daftar dari rentang". Tes AI saja (kabel dibaca dari kode; perilaku diaudit di Chromium lewat tools/audit_sumber_editor.py, BUKAN HP).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js'), ed = ui.slice(ui.indexOf('const openChecks = () =>'), ui.indexOf('// --- Rev 149 / U9b-1: Filter baris SEMENTARA'));
test('pilihan kriteria baru + kotak rentang sumber hanya tampil untuk jenis range', () => {
  assert.ok(ed.includes("['range', 'Daftar dari rentang']")); assert.match(ed, /class: 'in vd-src'/); assert.match(ed, /srcIn\.hidden = kind !== 'range'/);
  assert.match(ed, /c\.hidden = kind !== 'list' && kind !== 'range'/); // Rev 284 (DISENGAJA): kartu Pilihan juga tampil untuk range (baris hanya-baca + warna)
});
test('simpan: rentang sumber diparse, src dari ID kolom/baris, items segar dari isi rentang, k tetap list, pesan salah jelas', () => {
  assert.match(ed, /const isR = kind === 'range', list = kind === 'list' \|\| isR/); assert.ok(ed.includes("'Rentang sumber tidak sah. Contoh: D2:D10.'"));
  assert.match(ed, /sr = \{ c1: tab\.cols\[q\.c1\]\.id, c2: tab\.cols\[q\.c2\]\.id, r1: tab\.rows\[q\.r1\]\.id, r2: tab\.rows\[q\.r2\]\.id \}/);
  assert.match(ed, /items = itemsFromRange\(tab, sr, makeDisplay\(tab\)\.text\)/); assert.match(ed, /if \(sr\) next\.src = sr;/);
  assert.ok(ed.includes("'Isi minimal satu pilihan.'") && /kind === 'list' && !items\.length/.test(ed)); // hanya daftar manual yang wajib punya pilihan
});
test('muat + chip: aturan bersumber dibuka sebagai range dengan alamat sumber; chip berlabel Rentang', () => {
  assert.match(ed, /kind = ck && ck\.src \? 'range'/); assert.match(ed, /srcIn\.value = ck && ck\.src \? rangeText\(tab, \{ c: ck\.src\.c1, rg: \{ c2: ck\.src\.c2, r1: ck\.src\.r1, r2: ck\.src\.r2 \} \}\)/);
  assert.ok(ed.includes("ck.src ? 'Rentang' :"));
});
test('anggaran + terdaftar: modul statis tidak bertambah; SCHEMA 22; tes dan alat audit ada', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev282\.test\.mjs/); assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  for (const f of ['lembar.js', 'lembar-validasi.js', 'main.js']) assert.doesNotMatch(src('src/js/' + f), /lembar-sumber/, f);
  const a = src('tools/audit_sumber_editor.py'); for (const k of ["'light', 'dark'", 'Daftar dari rentang'.slice(0, 5), "select_option('range')", 'toast_salah']) assert.ok(a.includes(k), k);
});
