// Rev 197 / P7: pengukur data Node (tools/ukur_node.mjs) + tabel P1-P6 + daftar uji HP. Berkas rev199 = Rev 197. Tanpa uji waktu (rawan goyah).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync, existsSync } from 'node:fs';
import { ukur, buatData, buatLembar, PROFIL, KUOTA_PERKIRAAN } from '../tools/ukur_node.mjs';
import * as R from '../src/js/rumus.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('tiga profil data ada dengan jumlah sesuai spesifikasi P7', () => {
  assert.deepEqual(Object.keys(PROFIL), ['kecil', 'sedang', 'besar']);
  const s = buatData('sedang').d; assert.equal(s.notes.length, 200); assert.equal(s.tasks.length, 100); assert.equal(Object.keys(s.sheets).length, 10);
  assert.equal(Object.keys(buatData('besar').d.sheets).length, 50);
});
test('lembar penuh: 500 baris, rumus benar-benar terhitung (SUM baris 2 = 65), tidak melewati batas 500 KB', () => {
  const b = buatLembar(1, true); assert.equal(b.tab.rows.length, 500); assert.equal(b.terpotong, false);
  const calc = R.computeTab(b.tab); assert.equal(calc.get(b.tab.rows[1].id, b.tab.cols[5].id), 65);
});
test('ukur(): bentuk hasil lengkap, data kecil/sedang/besar muat di perkiraan kuota, JSON kembali lewat load()', () => {
  for (const n of ['kecil', 'sedang']) { const r = ukur(n, 1); assert.equal(r.muatKuota, true); assert.ok(r.jsonKarakter > 1000); assert.ok(r.loadMs >= 0 && r.stringifyMs >= 0); }
  const b = ukur('besar', 1); assert.ok(b.jsonKarakter < KUOTA_PERKIRAAN, 'profil besar (500 baris x 6 kolom x 50 lembar) muat'); assert.equal(b.lembar, 50); assert.equal(b.selLembar, 150000);
});
test('dokumen: daftar uji HP dan entri Rev 197 ada', () => {
  assert.ok(existsSync(new URL('../UJI_HP_RILIS.md', import.meta.url))); const u = src('UJI_HP_RILIS.md');
  assert.match(u, /Redmi Note 10 Pro/); assert.match(u, /HP Desy/); assert.match(src('RIWAYAT.md'), /Rev 197 \/ 0\.3\.112/);
});
test('tanpa versi/SCHEMA/native berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev199\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
