// Rev 411: CHECKPOINT Paket Sync (dokumen saja). Memastikan keputusan tercatat dan kode aplikasi belum berubah.
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { strict as assert } from 'node:assert';
const rd = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
test('banner Rev 411 di atas Rev 410 pada RIWAYAT dan PROMPT, memuat keputusan dan pembagian PART', () => {
  for (const f of ['RIWAYAT.md', 'PROMPT_SERAH_TERIMA.md']) {
    const d = rd(f); assert.ok(d.indexOf('**Rev 411 /') < d.indexOf('**Rev 410 /'), f); // Rev 412: banner 411 tidak lagi paling atas
    for (const k of ['"Sync"', 'Cadangkan semua', 'Catatan saja', 'Pulihkan semua', 'S0 = PRATINJAU', 'S4 = audit', 'DOKUMEN SAJA']) assert.ok(d.includes(k), f + ' ' + k);
  }
});
test('Rev 412 menggantikan empat baris lama dengan satu baris Sync; SCHEMA 22, tes terdaftar', () => {
  const st = rd('src/js/settings.js');
  for (const k of ["row(PATH.down, 'b', 'Ekspor cadangan'", "'Ekspor Markdown'", "'Impor Markdown'", "'Pulihkan dari cadangan'"]) assert.ok(!st.includes(k), k);
  assert.ok(rd('src/js/sync-ui.js').includes('viewSync'));
  assert.match(rd('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(JSON.parse(rd('package.json')).scripts.test, /node tests\/rev411\.test\.mjs/);
});
