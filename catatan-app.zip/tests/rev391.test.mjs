// Rev 391 / PART TN4: penutup paket Tunda alarm (dokumen + skrip audit). Kode aplikasi tidak berubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('UJI_HP_RILIS memuat bagian BY (9 butir) dan menyebut terang DAN gelap', () => {
  const u = rd('UJI_HP_RILIS.md'); const b = u.slice(u.indexOf('## BY.')); assert.ok(b.includes('terang DAN gelap'));
  for (let i = 1; i <= 9; i++) assert.ok(b.includes('\n' + i + '. '), 'butir ' + i);
});
test('skrip audit ada dan memeriksa kartu, aria-pressed, dan tersimpan', () => {
  const a = rd('tools/audit_tunda_391.py'); for (const k of ['.snzcard', 'aria_pressed', 'tersimpan', "['light', 'dark']"]) assert.ok(a.includes(k), k);
});
test('banner Rev 391 paling atas (di atas Rev 390), memuat PART TN4, BELUM TERBUKTI, BERFUNGSI-BELUM-DIUJI; tes terdaftar sesudah rev390', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) {
    const d = rd(f); assert.ok(/^\*\*Rev (?:39\d|4[0-3]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 391 /') < d.indexOf('**Rev 390 /'), f);
    const b = d.slice(d.indexOf('**Rev 391 /'), d.indexOf('**Rev 390 /')); for (const k of ['PART TN4', 'BELUM TERBUKTI', 'BERFUNGSI-BELUM-DIUJI']) assert.ok(b.includes(k), f + ' ' + k);
  }
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.indexOf('rev390.test.mjs') < t.indexOf('rev391.test.mjs'));
});
