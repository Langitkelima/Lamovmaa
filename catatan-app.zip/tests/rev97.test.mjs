// Rev 97 / U4b: chip header, perataan, hapus baris/kolom, Pilih ⌄, Hapus tabel; menu ▦ (Rev 76) dihapus. Tes Node: fungsi murni dan kontrak sumber.
// Perilaku DOM (ketuk chip, Undo, header, perataan, Pilih) dicek terpisah di Chromium 360x800 terang dan gelap (bukan bagian npm test).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { TABLE_CHIPS, ALIGN_CYCLE, ALIGN_NAMES, normAlign, nextAlign, alignLabel, scopeLabel, SCOPE_NAMES, tableLimits } from '../src/js/bilah-chip.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 97: isi bilah chip utama sesuai K4 (urut), ditambah Kolom header; Total ⌄ ditambah di U4d (Rev 99)', () => {
  assert.deepEqual(TABLE_CHIPS.main.map((c) => c.id), ['row-below', 'row-above', 'col-before', 'col-after', 'row-del', 'col-del', 'hdr-row', 'hdr-col', 'align', 'total', 'pick', 'tbl-del'] /* Rev 322: dikelompokkan tambah | hapus | format | pilih | hapus tabel */);
  assert.deepEqual(TABLE_CHIPS.main.filter((c) => c.danger).map((c) => c.id), ['row-del', 'col-del', 'tbl-del']);
  assert.equal(TABLE_CHIPS.main.find((c) => c.id === 'pick').page, 'pick');
  assert.deepEqual(TABLE_CHIPS.pick.map((c) => c.id), ['sel-cell', 'sel-row', 'sel-col', 'sel-all']);
  assert.deepEqual(TABLE_CHIPS.pick.map((c) => c.label), ['Sel', 'Baris', 'Kolom', 'Semua']);
  assert.ok(!TABLE_CHIPS.main.some((c) => /lembar/i.test(c.id + c.label)));
});
test('Rev 97: siklus perataan Awal -> Tengah -> Akhir -> Awal (data-a l/c/r Rev 76), nilai asing dianggap Awal', () => {
  assert.deepEqual(ALIGN_CYCLE, ['l', 'c', 'r']);
  assert.equal(nextAlign('l'), 'c'); assert.equal(nextAlign('c'), 'r'); assert.equal(nextAlign('r'), 'l');
  assert.equal(nextAlign(null), 'c'); assert.equal(nextAlign('e'), 'c'); assert.equal(normAlign('x'), 'l');
  assert.deepEqual(ALIGN_NAMES, { l: 'Awal', c: 'Tengah', r: 'Akhir' });
  assert.equal(alignLabel(null), 'Perataan: Awal'); assert.equal(alignLabel('c'), 'Perataan: Tengah'); assert.equal(alignLabel('r'), 'Perataan: Akhir');
});
test('Rev 97: label chip Pilih ⌄ menunjukkan bagian terpilih; batas hapus minimal 2 x 2', () => {
  assert.equal(scopeLabel('cell'), 'Pilih ⌄'); assert.equal(scopeLabel(undefined), 'Pilih ⌄');
  assert.equal(scopeLabel('row'), 'Pilih: Baris ⌄'); assert.equal(scopeLabel('col'), 'Pilih: Kolom ⌄'); assert.equal(scopeLabel('all'), 'Pilih: Semua ⌄');
  assert.deepEqual(SCOPE_NAMES, { cell: 'Sel', row: 'Baris', col: 'Kolom', all: 'Semua' });
  assert.equal(tableLimits(2, 5).delRow, false); assert.equal(tableLimits(3, 2).delCol, false); assert.equal(tableLimits(3, 3).delRow && tableLimits(3, 3).delCol, true);
});
test('Rev 97: operasi DOM di bilah-chip.js menjaga header (hapus baris/kolom header = header mati; toggle satu sumbu tidak merusak sumbu lain)', () => {
  const s = src('src/js/bilah-chip.js');
  assert.match(s, /export function toggleHeader\(table, axis\)/);
  assert.match(s, /flags\[key\] = !flags\[key\];\s*applyHeaderFlags\(table, flags\)/);
  assert.match(s, /export function deleteTableRow\(table, row, colIndex = 0\)/);
  assert.match(s, /if \(at === 0\) flags\.row = false;/);
  assert.match(s, /export function deleteTableCol\(table, refCell\)/);
  assert.match(s, /if \(at === 0\) flags\.col = false;/);
  assert.match(s, /!tableLimits\(d\.rows, d\.cols\)\.delRow/); assert.match(s, /!tableLimits\(d\.rows, d\.cols\)\.delCol/);
  assert.match(s, /def\.danger \? ' danger' : ''/); assert.match(s, /typeof s\.label === 'string'/);
});
test('Rev 97: notes.js tanpa menu ▦; semua aksi lewat tableChip; Undo satu langkah; toast diangkat di atas dock', () => {
  const n = src('src/js/notes.js');
  for (const k of ['tableTools', 'tableMenu', 'tbl-menu', 'tbl-tools', 'placeTableTools', 'toggleTableHeader', 'data-table-action']) assert.ok(!n.includes(k), 'sisa: ' + k);
  const fn = n.slice(n.indexOf('const tableChip ='), n.indexOf('const openTableDialog ='));
  for (const id of ['sel-cell', 'align', 'hdr-row', 'hdr-col', 'row-del', 'col-del', 'tbl-del', 'row-below', 'col-after']) assert.ok(fn.includes("'" + id + "'"), id);
  assert.match(fn, /nextAlign\(cell\.getAttribute\('data-a'\)\)/);
  assert.match(fn, /deleteTableRow\(table, row, colIndex\)/); assert.match(fn, /deleteTableCol\(table, cell\)/);
  assert.match(fn, /chipToast\(id === 'row-del' \? 'Baris dihapus\.' : 'Kolom dihapus\.', undoTo\(before\)/);
  assert.match(fn, /chipToast\('Tabel dihapus', undoTo\(before\), \(\) => tableUi\(\), top\)/);
  assert.ok(fn.indexOf('top = dockTop()') < fn.indexOf('chipBar.hide()'), 'batas toast dihitung sebelum chip disembunyikan (cegah ghost click pada Urungkan)');
  assert.ok(!/toast\(\(id === 'hdr/.test(fn) && !/toast\('Rata /.test(fn), 'header dan perataan tanpa toast (tidak menutupi chip)');
  assert.match(n, /const undoTo = \(before\) => \(\) => \{ ed\.innerHTML = sanitize\(before\); flushHist\(\); auto\(\); \};/);
  // pilihan bagian hanya penanda sementara (tanpa Undo, tidak tersimpan)
  assert.match(fn, /selScope = id\.slice\(4\); selCell = cell; markSel\(\); tableUi\(\); return;/);
  assert.match(n, /'pick': \{ label: scopeLabel\(selScope\), active: selScope !== 'cell' \}/);
  assert.match(n, /'align': \{ label: alignLabel\(cell\.getAttribute\('data-a'\)\) \}/);
  assert.match(n, /'row-del': \{ disabled: !lim\.delRow \}, 'col-del': \{ disabled: !lim\.delCol \}/);
});
test('Rev 97: CSS chip hapus merah; gaya menu ▦ dibuang; rata teks dan sorotan pilihan tetap', () => {
  const c = src('src/css/styles.css');
  assert.match(c, /\.chip\.danger\{color:var\(--danger,#c83248\)/);
  assert.ok(!/\.tbl-menu|\.tbl-tools|@keyframes tblIn/.test(c));
  assert.ok(c.includes('.ed2 [data-sel]{') && c.includes('.ed2 td[data-a="c"],.ed2 th[data-a="c"]{text-align:center}'));
});
test('Rev 97: versi 0.3.121, SCHEMA 9, native dan dependensi tidak berubah', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.deepEqual(Object.keys(JSON.parse(src('package.json')).dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(JSON.parse(src('package.json')).scripts.test.includes('node tests/rev97.test.mjs'));
});
