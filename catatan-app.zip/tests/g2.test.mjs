// Tes Rev 44 (tahap G2): cadangan dan Pulihkan mendukung gambar. ZIP murni (store + CRC32), Filesystem TIRUAN di memori, gambar BUATAN (byte acak).
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdtempSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import * as Z from '../src/js/zip.js';
import * as G from '../src/js/gambar.js';
import * as C from '../src/js/cadangan-gambar.js';
import * as S from '../src/js/storage.js';
import { runBackup } from '../src/js/backup.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const rnd = (len, seed) => { const b = new Uint8Array(len); let x = seed >>> 0 || 1; for (let i = 0; i < len; i++) { x = (Math.imul(x, 1664525) + 1013904223) >>> 0; b[i] = x >>> 24; } return b; };
const eq = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
const b64 = Z.bytesToBase64;

// Filesystem tiruan: kunci "DIR:path". Mencatat panggilan supaya bisa dicek jalur lama tidak menyentuh apa pun yang baru.
const mkFS = (o = {}) => {
  const files = new Map(), calls = [];
  const key = (d, p) => d + ':' + p;
  const f = {
    files, calls,
    async writeFile(a) { calls.push('writeFile'); if (o.failWrite && o.failWrite(a)) throw new Error('disk penuh'); files.set(key(a.directory, a.path), a.encoding === 'utf8' ? Z.utf8.encode(a.data) : Z.base64ToBytes(a.data)); return { uri: 'file:///' + key(a.directory, a.path) }; },
    async appendFile(a) { calls.push('appendFile'); const k = key(a.directory, a.path), old = files.get(k); const add = Z.base64ToBytes(a.data); const m = new Uint8Array(old.length + add.length); m.set(old); m.set(add, old.length); files.set(k, m); },
    async readFile(a) { calls.push('readFile'); const v = files.get(key(a.directory, a.path)); if (!v) throw new Error('File does not exist'); return { data: b64(v) }; },
    async stat(a) { calls.push('stat'); if (!files.has(key(a.directory, a.path))) throw new Error('File does not exist'); return {}; },
    async mkdir() { calls.push('mkdir'); },
    async copy(a) { calls.push('copy'); const v = files.get(key(a.directory, a.from)); if (!v) throw new Error('source missing'); files.set(key(a.toDirectory, a.to), v); return {}; },
    async deleteFile(a) { calls.push('deleteFile'); files.delete(key(a.directory, a.path)); },
  };
  return f;
};
const ID = (k) => 'img' + String(k).padStart(8, '0') + 'ab';
const fig = (k, bytes) => G.buildFigure({ id: ID(k), w: 800, h: 600, b: bytes, x: 'webp' });
const putImage = (fs, k, len) => { const b = rnd(len, k * 7919); fs.files.set('DATA:gambar/' + ID(k) + '.webp', b); return b; };
const dataWith = () => {
  const d = S.emptyData();
  d.notes = [{ id: 'n1', title: 'A', text: 'a', html: '<p>a</p>' + fig(1, 300), updated: 1 }, { id: 'n2', title: 'B', text: 'b', html: fig(2, 500) + fig(1, 300), updated: 2 }];
  d.priv = [{ id: 'p1', title: 'P', text: 'p', html: fig(3, 200), updated: 3 }];
  d.trash = [{ kind: 'note', item: { id: 'n9', title: 'T', text: 't', html: fig(4, 100), updated: 4 }, at: 5 }];
  return d;
};

// ---------- ZIP murni ----------
await t('crc32: nilai baku "123456789" = CBF43926 dan berkas kosong = 0', () => {
  assert.equal(Z.crc32(new TextEncoder().encode('123456789')), 0xCBF43926);
  assert.equal(Z.crc32(new Uint8Array(0)), 0);
});
await t('zip: bolak-balik (roundtrip) dengan byte acak, nama UTF-8, berkas kosong; CRC dicek', async () => {
  const files = [{ name: 'data.json', data: Z.utf8.encode('{"a":"é✦"}') }, { name: 'gambar/' + ID(1) + '.webp', data: rnd(70000, 1) }, { name: 'gambar/kosong.webp', data: new Uint8Array(0) }];
  const zip = Z.buildZip(files, new Date(2026, 10, 3, 12, 30, 10));
  assert.ok(Z.isZipBytes(zip));
  const blob = new Blob([zip]);
  const idx = await Z.readZipIndex(blob);
  assert.deepEqual(idx.map((e) => e.name), files.map((f) => f.name));
  for (let i = 0; i < files.length; i++) assert.ok(eq(await Z.readZipEntry(blob, idx[i]), files[i].data), files[i].name);
});
await t('zip: perakit bertahap (zipWriter) menghasilkan byte yang sama dengan buildZip', () => {
  const files = [{ name: 'a.txt', data: rnd(1000, 2) }, { name: 'b.txt', data: rnd(2000, 3) }]; const now = new Date(2026, 0, 1);
  const w = Z.zipWriter(now), parts = []; for (const f of files) parts.push(...w.add(f.name, f.data)); parts.push(...w.finish());
  const all = new Uint8Array(parts.reduce((s, p) => s + p.length, 0)); let o = 0; for (const p of parts) { all.set(p, o); o += p.length; }
  assert.ok(eq(all, Z.buildZip(files, now)));
  assert.throws(() => w.add('c', new Uint8Array(1)), /ditutup/);
});
await t('zip: bisa dibuka alat ZIP sungguhan (Python zipfile) bila tersedia', () => {
  const dir = mkdtempSync(join(tmpdir(), 'g2-')), p = join(dir, 't.zip');
  const files = [{ name: 'data.json', data: Z.utf8.encode('{"x":1}') }, { name: 'gambar/' + ID(1) + '.webp', data: rnd(5000, 5) }];
  writeFileSync(p, Z.buildZip(files));
  const r = spawnSync('python3', ['-I', '-c', 'import zipfile,sys;z=zipfile.ZipFile(sys.argv[1]);assert z.testzip() is None;print(",".join(sorted(z.namelist())))', p], { encoding: 'utf8' });
  if (r.error || r.status === null) { console.log('  (python3 tidak ada, dilewati)'); return; }
  assert.equal(r.status, 0, r.stderr); assert.equal(r.stdout.trim(), files.map((f) => f.name).sort().join(','));
});
await t('zip: isi rusak, terpotong, terkompresi, dan bukan ZIP ditolak dengan pesan jelas', async () => {
  const zip = Z.buildZip([{ name: 'data.json', data: rnd(500, 9) }]);
  const idx = await Z.readZipIndex(new Blob([zip]));
  const bad = zip.slice(); bad[idx[0].start + 10] ^= 0xFF;
  await assert.rejects(Z.readZipEntry(new Blob([bad]), idx[0]), /rusak/);
  await assert.rejects(Z.readZipIndex(new Blob([zip.slice(0, zip.length - 30)])), /rusak|terpotong/);
  await assert.rejects(Z.readZipIndex(new Blob([new Uint8Array(100)])), /rusak/);
  const comp = zip.slice(); const cd = comp.length - 22 - 46 - 'data.json'.length; comp[cd + 10] = 8; // metode di daftar pusat = deflate
  await assert.rejects(Z.readZipIndex(new Blob([comp])), /kompresi/);
});

// ---------- Ekspor ZIP ----------
await t('uniqueRefs: satu per ID, mencakup catatan, privat, dan Tempat sampah', () => {
  assert.deepEqual(C.uniqueRefs(dataWith()).map((r) => r.id), [ID(1), ID(2), ID(3), ID(4)]);
  assert.deepEqual(C.uniqueRefs(S.emptyData()), []);
});
await t('writeZipToCache: data.json + semua gambar; gambar hilang dilewati dan dilaporkan; CRC benar; ditulis bertahap', async () => {
  const fs = mkFS(), d = dataWith(), json = S.exportJSON(d);
  const orig = { 1: putImage(fs, 1, 900 * 1024), 2: putImage(fs, 2, 900 * 1024), 3: putImage(fs, 3, 1500) }; // gambar 4 sengaja tidak ada
  const r = await C.writeZipToCache(fs, d, json, 'x.zip', new Date(2026, 10, 3));
  assert.equal(r.included, 3); assert.deepEqual(r.missing, [ID(4)]); assert.ok(r.uri.includes('CACHE:x.zip'));
  assert.equal(fs.calls.filter((c) => c === 'writeFile').length, 1); assert.ok(fs.calls.filter((c) => c === 'appendFile').length >= 1, 'ditulis bertahap, bukan satu string raksasa');
  const zip = fs.files.get('CACHE:x.zip'), blob = new Blob([zip]), idx = await Z.readZipIndex(blob);
  assert.deepEqual(idx.map((e) => e.name), ['data.json', 'gambar/' + ID(1) + '.webp', 'gambar/' + ID(2) + '.webp', 'gambar/' + ID(3) + '.webp']);
  assert.equal(Z.utf8.decode(await Z.readZipEntry(blob, idx[0])), json);
  for (const k of [1, 2, 3]) assert.ok(eq(await Z.readZipEntry(blob, idx[k]), orig[k]));
});
await t('writeZipToCache: gagal di tengah -> berkas sementara dibuang dan galat diteruskan', async () => {
  const fs = mkFS({ failWrite: () => true }), d = dataWith(); putImage(fs, 1, 100);
  await assert.rejects(C.writeZipToCache(fs, d, '{}', 'y.zip'), /disk penuh/);
  assert.ok(!fs.files.has('CACHE:y.zip'));
});

// ---------- Pulihkan ----------
await t('readBackupFile: JSON lama dikenali dari isi (bukan nama); ZIP dibaca; entri bernama aneh diabaikan', async () => {
  const json = S.exportJSON(dataWith());
  const rj = await C.readBackupFile(new File([json], 'cadangan.zip')); // nama menyesatkan, isi JSON
  assert.equal(rj.kind, 'json'); assert.equal(rj.text, json); assert.deepEqual(rj.images, []);
  const zip = Z.buildZip([{ name: 'data.json', data: Z.utf8.encode(json) }, { name: 'gambar/' + ID(1) + '.webp', data: rnd(10, 1) },
    { name: 'gambar/../../evil.webp', data: rnd(10, 2) }, { name: '/abs/x.webp', data: rnd(10, 3) }, { name: 'gambar/pendek.webp', data: rnd(10, 4) }, { name: 'lain.txt', data: rnd(10, 5) }]);
  const rz = await C.readBackupFile(new File([zip], 'cadangan.json'));
  assert.equal(rz.kind, 'zip'); assert.equal(rz.text, json); assert.deepEqual(rz.images.map((e) => e.name), ['gambar/' + ID(1) + '.webp']);
});
await t('readBackupFile: ZIP tanpa data.json, ZIP rusak, dan gambar kebesaran ditolak; JSON terlalu besar ditolak', async () => {
  await assert.rejects(C.readBackupFile(new File([Z.buildZip([{ name: 'lain.txt', data: rnd(10, 1) }])], 'a.zip')), /bukan cadangan/);
  const z = Z.buildZip([{ name: 'data.json', data: Z.utf8.encode('{}') }, { name: 'gambar/' + ID(1) + '.webp', data: rnd(10, 1) }]);
  await assert.rejects(C.readBackupFile(new File([z.slice(0, z.length - 5)], 'a.zip')), /rusak/);
  await assert.rejects(C.readBackupFile({ size: C.MAX_JSON_BYTES + 1, slice: () => ({ arrayBuffer: async () => new TextEncoder().encode('{').buffer }), text: async () => '' }), /terlalu besar/);
});
await t('Pulihkan ZIP: roundtrip ekspor -> pulihkan ke HP baru; byte gambar identik; data identik', async () => {
  const src1 = mkFS(), d = dataWith(), json = S.exportJSON(d);
  const orig = { 1: putImage(src1, 1, 40000), 2: putImage(src1, 2, 50000), 3: putImage(src1, 3, 3000), 4: putImage(src1, 4, 1000) };
  await C.writeZipToCache(src1, d, json, 'z.zip');
  const file = new File([src1.files.get('CACHE:z.zip')], 'z.zip');
  const rb = await C.readBackupFile(file); assert.equal(rb.images.length, 4);
  const dst = mkFS(); const prog = [];
  assert.equal(await C.writeBackupImages(dst, file, rb.images, (a, b) => prog.push(a + '/' + b)), 4); assert.equal(prog.at(-1), '4/4');
  for (const k of [1, 2, 3, 4]) assert.ok(eq(dst.files.get('DATA:gambar/' + ID(k) + '.webp'), orig[k]), 'gambar ' + k);
  const back = S.importJSON(rb.text); assert.ok(back.ok); assert.deepEqual(C.uniqueRefs(back.data).map((r) => r.id), [ID(1), ID(2), ID(3), ID(4)]);
  assert.deepEqual(C.idsMissingFromZip(back.data, rb.images), []);
});
await t('Pulihkan ZIP: CRC salah di tengah -> gagal SEBELUM data diganti (tidak ada yang melempar ke luar selain galat jelas)', async () => {
  const fs = mkFS(); putImage(fs, 1, 3000); const d = dataWith();
  await C.writeZipToCache(fs, d, S.exportJSON(d), 'z.zip');
  const zip = fs.files.get('CACHE:z.zip').slice(); const idx = await Z.readZipIndex(new Blob([zip])); zip[idx[1].start + 5] ^= 0xFF;
  const file = new File([zip], 'z.zip'), rb = await C.readBackupFile(file);
  await assert.rejects(C.writeBackupImages(mkFS(), file, rb.images), /rusak/);
  assert.deepEqual(C.idsMissingFromZip(S.importJSON(rb.text).data, rb.images.filter((e) => e.name.includes(ID(1)))).sort(), [ID(2), ID(3), ID(4)]);
});
await t('Pulihkan dari JSON: gambar dicari di <folder cadangan>/gambar/; yang sudah ada dilewati; yang hilang dihitung; tidak melempar', async () => {
  const d = dataWith(); d.settings.backup.folder = 'Kelimaa'; d.settings.backup.base = 'documents';
  const fs = mkFS(); fs.files.set('DOCUMENTS:Kelimaa/gambar/' + ID(1) + '.webp', rnd(10, 1)); fs.files.set('DOCUMENTS:Kelimaa/gambar/' + ID(2) + '.webp', rnd(10, 2));
  fs.files.set('DATA:gambar/' + ID(2) + '.webp', rnd(10, 2)); // sudah ada di HP
  const r = await C.restoreImagesFromBackupFolder(fs, d);
  assert.deepEqual(r, { restored: 1, present: 1, missing: 2 });
  assert.ok(fs.files.has('DATA:gambar/' + ID(1) + '.webp'));
  assert.deepEqual(await C.restoreImagesFromBackupFolder(mkFS(), S.emptyData()), { restored: 0, present: 0, missing: 0 });
});

// ---------- Cadangan otomatis ----------
await t('runBackup TANPA gambar: persis seperti sebelumnya (satu writeFile, tanpa stat/copy/mkdir, pesan riwayat = nama berkas)', async () => {
  const fs = { writes: [], writeFile: async (a) => { fs.writes.push(a); return { uri: 'u' }; } }; // FS minimal: kalau kode baru memanggil hal lain, tes ini pecah
  const ctx = { data: S.emptyData(), ui: { tab: 'tugas' }, persist() {}, render() {} };
  ctx.data.notes = [{ id: 'n', title: 't', text: 'x', html: '<p>x</p>', updated: 1 }];
  const before = S.exportJSON(ctx.data); // isi yang dicadangkan = data SEBELUM waktu/riwayat cadangan dicatat
  const r = await runBackup(ctx, 'manual', { FS: fs, native: true, now: () => 1000 });
  assert.equal(r.ok, true); assert.equal(fs.writes.length, 1);
  assert.equal(fs.writes[0].data, before); assert.equal(ctx.data.settings.backup.history[0].msg, r.name);
});
await t('runBackup DENGAN gambar: JSON ditulis + gambar disalin ke <folder>/gambar/; ulang = dilewati; gagal salin tidak menggagalkan cadangan', async () => {
  const fs = mkFS(), ctx = { data: dataWith(), ui: { tab: 'tugas' }, persist() {}, render() {} };
  for (const k of [1, 2, 3, 4]) putImage(fs, k, 500);
  const dir = ctx.data.settings.backup.folder;
  const r1 = await runBackup(ctx, 'manual', { FS: fs, native: true, now: () => 1000 });
  assert.equal(r1.ok, true); assert.ok(r1.note.includes('4 gambar disalin'));
  for (const k of [1, 2, 3, 4]) assert.ok(fs.files.has('DOCUMENTS:' + dir + '/gambar/' + ID(k) + '.webp'));
  const r2 = await runBackup(ctx, 'manual', { FS: fs, native: true, now: () => 2000 });
  assert.ok(r2.note.includes('4 sudah ada') && !r2.note.includes('disalin'));
  fs.files.delete('DATA:gambar/' + ID(1) + '.webp'); fs.files.delete('DOCUMENTS:' + dir + '/gambar/' + ID(1) + '.webp');
  const r3 = await runBackup(ctx, 'manual', { FS: fs, native: true, now: () => 3000 });
  assert.equal(r3.ok, true); assert.ok(r3.note.includes('1 gagal'));
  assert.ok(ctx.data.settings.backup.history[0].msg.includes('1 gagal'));
});

// ---------- Sambungan di aplikasi ----------
await t('settings.js: ekspor ZIP hanya bila ada gambar; Pulihkan menerima ZIP; gambar ditulis SEBELUM data diganti; JSON lama tetap jalan', () => {
  const s = src('../src/js/settings.js');
  for (const k of ['backupZipName()', 'writeZipToCache(', 'application/zip', '.zip', 'readBackupFile(f)', 'writeBackupImages(', 'restoreImagesFromBackupFolder(', 'data TIDAK diganti', 'uniqueRefs(ctx.data).length > 0'])
    assert.ok(s.includes(k), k);
  assert.ok(s.indexOf('writeBackupImages(') < s.indexOf('replaceData(ctx.data, r.data)'), 'gambar ditulis lebih dulu');
  assert.ok(s.includes('backupFileName()') && s.includes("directory: 'CACHE', encoding: 'utf8'"), 'jalur JSON lama utuh');
  assert.ok(src('../src/js/logic.js').includes("'.zip'"));
});
await t('modul baru murni dan aman: zip.js tanpa DOM/penyimpanan/jaringan; tanpa plugin atau native baru', () => {
  const z = src('../src/js/zip.js').replace(/\/\/.*$/gm, '');
  assert.ok(!/\b(document|window|localStorage|fetch|XMLHttpRequest|Capacitor|FileReader|import\s)/.test(z));
  const pk = JSON.parse(src('../package.json')); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
});
console.log(n + ' tes lulus (Rev 44 G2 cadangan gambar)');
