// Rev 144 / U9a-3c: Impor CSV/TSV di lembar Lainnya (ringkasan, Ganti isi tab / Tempel dari sel, laporan, satu langkah Urungkan).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { importSummary, importMessage, DELIM_NAME, IMPORT_MAX_BYTES } from '../src/js/lembar-ui.js';
import * as L from '../src/js/lembar.js';
import * as A from '../src/js/lembar-alat.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('importSummary: pemisah dan ukuran terdeteksi, baris akhir kosong diabaikan', () => {
  assert.deepEqual(importSummary('a,b,c\n1,2,3\n'), { delim: ',', rows: 2, cols: 3 });
  assert.deepEqual(importSummary('a\tb\n1\t2\n3\t4'), { delim: '\t', rows: 3, cols: 2 });
  assert.equal(importSummary('').rows, 0); assert.equal(DELIM_NAME[';'], 'titik koma'); assert.equal(IMPORT_MAX_BYTES, 2000000);
});
test('importMessage: hasil, kosong, dan laporan dipotong/rumus dilewati', () => {
  assert.equal(importMessage({ ok: true, rows: 3, cols: 2 }), '3 baris \u00d7 2 kolom diimpor.');
  assert.equal(importMessage({ ok: true, rows: 500, cols: 26, truncatedRows: 20, truncatedCols: 4, skippedFormula: 2 }), '500 baris \u00d7 26 kolom diimpor. 20 baris dipotong, 4 kolom dipotong, 2 sel berumus dilewati.');
  assert.equal(importMessage({ ok: false, reason: 'kosong' }), 'Berkas kosong.'); assert.equal(importMessage(null), 'Tidak ada yang diimpor.');
});
test('jalur data: tempel TIDAK menimpa rumus; ganti isi tab mengosongkan; teks rumus dari CSV tetap teks', () => {
  const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; const c = (r, k) => tab.rows[r].cells[tab.cols[k].id];
  L.setCell(tab, tab.rows[0].id, tab.cols[1].id, { fx: '=1+1' }); L.setCell(tab, tab.rows[5].id, tab.cols[0].id, { v: 'lama' });
  const r = A.importDelimited(tab, 'x,y\n=SUM(1),3', { row: 0, col: 0 });
  assert.equal(r.skippedFormula, 1); assert.ok(c(0, 1).fx, 'rumus utuh'); assert.equal(c(0, 0).v, 'x'); assert.equal(c(1, 1).v, 3); assert.equal(c(1, 0).fx, undefined);
  const g = A.importDelimited(tab, 'p,q', { row: 0, col: 0, replace: true }); assert.equal(g.ok, true); assert.equal(c(0, 1).fx, undefined); assert.equal(c(0, 1).v, 'q');
});
test('penjaga kode: item Impor, snapshot sebelum impor, batas 2 MB, tanpa penyimpanan di UI', () => {
  const u = src('src/js/lembar-ui.js');
  assert.match(u, /item\('seri', 'Isi seri', /); assert.ok(u.indexOf("item('seri'") < u.indexOf("item('impor', 'Impor CSV/TSV'")); // Rev 264: Impor kini di kelompok Impor & ekspor
  assert.match(u, /const snap = ser\(\), res = importDelimited\(tab, text,/);
  assert.match(u, /f\.size > IMPORT_MAX_BYTES/); assert.match(u, /class: 'ov dlgov lz-more lz-imp'/);
  assert.doesNotMatch(u, /localStorage|sessionStorage|\beval\s*\(/);
  assert.doesNotMatch(src('src/js/lembar-alat.js'), /from '\.\/rumus\.js'/);
});
