// Rev 88 (0.3.3): menu Sisipkan dihapus; semua isinya jadi tombol langsung di menu Langit; jalur sisip disatukan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const nt = read('src/js/notes.js'), css = read('src/css/styles.css'), ui = read('src/js/ui.js');

test('Rev 88: tombol Sisipkan dan panelnya hilang total (kode, CSS, ikon)', () => {
  assert.doesNotMatch(nt, /insert-panel|insert-trigger|insertPanel|closeIns|icoPeniti|insertCard/);
  assert.doesNotMatch(css, /insert-panel|insert-card|insert-mark|insert-trigger/);
  assert.doesNotMatch(ui, /icoPeniti/);
});
test('Rev 88: tujuh tombol sisip ada di bilah Langit (Gambar tidak di Privat), setelah Ukuran', () => {
  const bar = nt.slice(nt.indexOf("const bar = h('div', { class: 'fbar' }"), nt.indexOf('const starBtn'));
  const order = ['date', 'time', 'countdown', 'mood', 'quote', 'table', 'image'].map((k) => bar.indexOf(`insertBtn('${k}'`));
  assert.ok(order.every((i, n) => i > (n ? order[n - 1] : bar.indexOf("'data-cmd': 'font-size'"))), 'urutan tombol');
  assert.match(bar, /\.\.\.\(isP \? \[\] : \[insertBtn\('image', 'Gambar'\)\]\)/);
  assert.match(nt, /const insertBtn = \(kind, label\) => fb\(\{ 'data-insert': kind, class: 'fmt'/);
});
test('Rev 88: satu jalur sisip (placeBlock) dipakai Suasana hati, Tanggal, Waktu, dan Hitung mundur', () => {
  assert.match(nt, /const placeBlock = \(block, range, label\)/);
  for (const l of ['Suasana hati', 'Tanggal', 'Waktu', 'Hitung mundur']) assert.match(nt, new RegExp(`placeBlock\\([a-z]+, [a-zA-Z()]+, '${l}'\\)`));
  assert.match(nt, /infoKey\('dlmTabel', label\)/);
  assert.match(nt, /top\.replaceWith\(block, tail\)/, 'paragraf kosong diganti blok, div tidak bersarang di <p>');
});
test('Rev 88: ketukan tombol sisip menutup panel lain dan menuju handler yang sama', () => {
  assert.match(nt, /const runInsert = \(kind\) => \{\s*closePanels\(\);/);
  for (const k of ['mood', 'date', 'time', 'countdown', 'quote', 'table', 'image']) assert.match(nt, new RegExp(`kind === '${k}'`));
  assert.match(nt, /if \(b\.dataset\.insert\) \{ runInsert\(b\.dataset\.insert\); return; \}/);
});
test('Rev 88: timer hitung mundur tidak bekerja saat aplikasi tersembunyi; CSS ikon sisip ada', () => {
  assert.match(nt, /if \(!alive \|\| document\.hidden\) return;/);
  assert.match(css, /\.fbar \.fmt \.tile svg\{width:23px/);
});
test('Rev 88: versi 0.3.3 konsisten dan tercatat di dokumen', () => {
  assert.equal(JSON.parse(read('package.json')).version, '0.3.121');
  assert.match(read('src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
  assert.match(read('RIWAYAT.md'), /Rev 88 \(.*versi 0\.3\.3\)/);
  assert.match(read('PROMPT_SERAH_TERIMA.md'), /Rev 88 \(versi 0\.3\.3/);
});
