// Rev 250 / S1: model seleksi murni (lembar-seleksi.js). Tanpa UI; bukan uji HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import * as S from '../src/js/lembar-seleksi.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const D = { rows: 114, cols: 5 }; const addr = (c, r) => String.fromCharCode(65 + c) + (r + 1);
test('sel, baris, kolom, semua: rentang dan alamat gaya Sheets (kolom penuh D1:D114, baris penuh A6:E6)', () => {
  const c = S.selectCell(D, 3, 3); assert.equal(c.kind, 'cell'); assert.equal(S.refText(c, addr), 'D4'); assert.equal(S.cellCount(c), 1); assert.ok(S.isSingle(c) && !S.isFull(c));
  const k = S.selectCol(D, 3); assert.equal(k.kind, 'col'); assert.equal(S.refText(k, addr), 'D1:D114'); assert.ok(S.isFull(k)); assert.equal(S.cellCount(k), 114);
  const r = S.selectRow(D, 5); assert.equal(S.refText(r, addr), 'A6:E6'); assert.equal(S.colCount(r), 5);
  const a = S.selectAll(D); assert.equal(S.refText(a, addr), 'A1:E114'); assert.equal(S.cellCount(a), 570);
  const g = S.selectRange(D, { r: 4, c: 3 }, { r: 7, c: 4 }); assert.equal(g.kind, 'range'); assert.equal(S.refText(g, addr), 'D5:E8'); assert.equal(S.selectRange(D, { r: 2, c: 2 }, { r: 2, c: 2 }).kind, 'cell');
  assert.equal(S.selectCell(D, 114, 0), null); assert.equal(S.selectCell(D, 0, 5), null); assert.equal(S.selectCol(D, 9), null); assert.equal(S.selectRow({ rows: 0, cols: 3 }, 0), null); assert.equal(S.selectCell(D, -1, 0), null);
});
test('TANPA batas 2000 sel: seleksi penuh lembar terbesar 500 x 26 = 13.000 sel, tetap satu rentang', () => {
  const big = { rows: 500, cols: 26 }, a = S.selectAll(big); assert.equal(S.cellCount(a), 13000); assert.deepEqual(a.rect, { r1: 0, c1: 0, r2: 499, c2: 25 });
  assert.equal(S.selectRange(big, { r: 0, c: 0 }, { r: 499, c: 25 }).kind, 'range'); assert.equal(S.cellCount(S.selectRange(big, { r: 0, c: 0 }, { r: 499, c: 25 })), 13000);
});
test('extend: seret ujung (jangkar tetap; baris/kolom tetap penuh; semua tidak berubah; ke atas/kiri jangkar)', () => {
  const g = S.extend(D, S.selectCell(D, 4, 3), { r: 7, c: 4 }); assert.equal(S.refText(g, addr), 'D5:E8'); assert.deepEqual(g.a, { r: 4, c: 3 });
  const up = S.extend(D, g, { r: 1, c: 1 }); assert.equal(S.refText(up, addr), 'B2:D5'); const back = S.extend(D, up, { r: 4, c: 3 }); assert.equal(back.kind, 'cell');
  const rows = S.extend(D, S.selectRow(D, 5), { r: 8, c: 0 }); assert.equal(rows.kind, 'row'); assert.equal(S.refText(rows, addr), 'A6:E9'); assert.equal(S.refText(S.extend(D, rows, { r: 2, c: 4 }), addr), 'A3:E6');
  const cols = S.extend(D, S.selectCol(D, 2), { r: 50, c: 4 }); assert.equal(cols.kind, 'col'); assert.equal(S.refText(cols, addr), 'C1:E114'); assert.equal(S.refText(S.extend(D, cols, { r: 0, c: 0 }), addr), 'A1:C114');
  const all = S.selectAll(D); assert.equal(S.extend(D, all, { r: 3, c: 3 }), all); assert.equal(S.extend(D, g, { r: 999, c: 0 }), null);
});
test('gabungan sel yang tersentuh masuk utuh (berantai), juga untuk baris/kolom penuh', () => {
  const m = [{ r1: 2, c1: 1, r2: 4, c2: 2 }, { r1: 5, c1: 2, r2: 6, c2: 3 }]; // tidak tumpang tindih (data nyata sudah dibersihkan cleanMerges)
  const s = S.selectCell(D, 2, 1, m); assert.deepEqual(s.rect, { r1: 2, c1: 1, r2: 4, c2: 2 }); assert.equal(s.kind, 'cell');
  const g = S.selectRange(D, { r: 3, c: 1 }, { r: 3, c: 1 }, m); assert.deepEqual(g.rect, { r1: 2, c1: 1, r2: 4, c2: 2 });
  const chain = S.selectRange(D, { r: 2, c: 1 }, { r: 5, c: 2 }, m); assert.deepEqual(chain.rect, { r1: 2, c1: 1, r2: 6, c2: 3 }); assert.equal(chain.kind, 'range');
  const row = S.selectRow(D, 3, m); assert.deepEqual(row.rect, { r1: 2, c1: 0, r2: 4, c2: 4 }); assert.equal(S.refText(row, addr), 'A3:E5'); assert.equal(S.refText(S.selectRow(D, 5, m), addr), 'A6:E7');
  assert.deepEqual(S.growToMerges({ r1: 0, c1: 0, r2: 0, c2: 0 }, m), { r1: 0, c1: 0, r2: 0, c2: 0 }); assert.deepEqual(S.growToMerges({ r1: 0, c1: 0, r2: 0, c2: 0 }), { r1: 0, c1: 0, r2: 0, c2: 0 });
});
test('headState: on = seluruh kolom/baris terpilih, in = tersentuh, kosong = di luar; contains', () => {
  const k = S.selectCol(D, 3); assert.equal(S.headState(k, 'col', 3, D), 'on'); assert.equal(S.headState(k, 'col', 2, D), ''); assert.equal(S.headState(k, 'row', 10, D), 'in'); assert.equal(S.headState(k, 'row', 113, D), 'in');
  const r = S.selectRow(D, 5); assert.equal(S.headState(r, 'row', 5, D), 'on'); assert.equal(S.headState(r, 'col', 4, D), 'in');
  const g = S.selectRange(D, { r: 4, c: 3 }, { r: 7, c: 4 }); assert.equal(S.headState(g, 'col', 3, D), 'in'); assert.equal(S.headState(g, 'row', 9, D), ''); assert.ok(S.contains(g, 5, 4) && !S.contains(g, 8, 4));
  const a = S.selectAll(D); assert.equal(S.headState(a, 'col', 0, D), 'on'); assert.equal(S.headState(a, 'row', 113, D), 'on'); assert.equal(S.headState(null, 'col', 0, D), '');
});
test('clampSel: potong ke ukuran baru (hapus baris/kolom), null bila tidak tersisa, semua ikut ukuran baru', () => {
  const k = S.selectCol(D, 3); const c = S.clampSel({ rows: 100, cols: 5 }, k); assert.equal(S.refText(c, addr), 'D1:D100'); assert.equal(S.clampSel({ rows: 100, cols: 3 }, k), null);
  const g = S.selectRange(D, { r: 90, c: 1 }, { r: 110, c: 4 }); assert.equal(S.refText(S.clampSel({ rows: 100, cols: 3 }, g), addr), 'B91:C100'); assert.equal(S.clampSel({ rows: 50, cols: 5 }, g), null);
  assert.equal(S.refText(S.clampSel({ rows: 7, cols: 4 }, S.selectAll(D)), addr), 'A1:D7'); const r = S.selectRow(D, 100); assert.equal(S.clampSel({ rows: 100, cols: 5 }, r), null); assert.equal(S.refText(S.clampSel({ rows: 100, cols: 4 }, S.selectRow(D, 5)), addr), 'A6:D6'); assert.equal(S.clampSel(D, null), null);
});
test('existingCells: hanya sel yang ADA, generator, kolom/baris penuh, tanpa membuat sel', () => {
  const tab = { rows: Array.from({ length: 6 }, (_, i) => ({ id: 'r' + i, cells: i % 2 ? { cA: { v: 'x' + i }, cC: { v: i } } : {} })), cols: ['A', 'B', 'C'].map((k) => ({ id: 'c' + k, w: 90 })) };
  assert.deepEqual(S.dimsOfTab(tab), { rows: 6, cols: 3 }); const col = S.selectCol(S.dimsOfTab(tab), 0);
  const got = [...S.existingCells(tab, col)].map((x) => x.r + ':' + x.c + ':' + x.cell.v); assert.deepEqual(got, ['1:0:x1', '3:0:x3', '5:0:x5']);
  assert.equal(S.countExisting(tab, S.selectAll(S.dimsOfTab(tab))), 6); assert.equal(S.countExisting(tab, S.selectRow(S.dimsOfTab(tab), 0)), 0); assert.equal(S.countExisting(tab, S.selectRow(S.dimsOfTab(tab), 1)), 2);
  assert.equal(Object.keys(tab.rows[0].cells).length, 0); assert.equal(typeof S.existingCells(tab, col).next, 'function'); assert.equal(S.countExisting(null, col), 0);
  const nosel = [...S.existingCells(tab, S.selectRange(S.dimsOfTab(tab), { r: 4, c: 1 }, { r: 5, c: 2 }))]; assert.deepEqual(nosel.map((x) => x.r + ':' + x.c), ['5:2']);
});
test('sig berbeda untuk seleksi berbeda; modul murni (satu impor, tanpa DOM/penyimpanan); dipakai UI sejak Rev 251; tanpa SCHEMA/versi berubah', () => {
  assert.notEqual(S.sig(S.selectCol(D, 3)), S.sig(S.selectRow(D, 3))); assert.equal(S.sig(null), '-'); assert.equal(S.sig(S.selectCell(D, 1, 1)), S.sig(S.selectCell(D, 1, 1)));
  const m = src('src/js/lembar-seleksi.js'); assert.deepEqual([...m.matchAll(/^import .* from '(.*)';/gm)].map((x) => x[1]), ['./lembar-rentang.js']); assert.doesNotMatch(m, /document|window|localStorage|eval\(|Capacitor/);
  assert.match(src('src/js/lembar-ui.js'), /from '\.\/lembar-seleksi\.js'/); /* Rev 251 / S2: kini dipakai UI */ const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev250\.test\.mjs/); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
});
