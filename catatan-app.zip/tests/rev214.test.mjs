// Rev 213b: tabel rute per jenis pekerjaan (chat/analysis/creative/utility). Fetch PALSU, tanpa jaringan/kunci asli.
import test from 'node:test'; import assert from 'node:assert/strict';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t;
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), SAKELAR_KEY: 'sk-FAKE-0123456789', GEMINI_KEY: 'AIza-FAKE-0123456789', RETRY_MS: [0, 0], ...x });
const NOW = Date.UTC(2026, 10, 12, 5, 0, 0);
const post = (b) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify(b) });
const req = (o = {}) => ({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', limit: 0, messages: [{ role: 'user', content: 'Halo' }], ...o });
const good = () => ({ ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'ok' } }], usage: {} }) });
async function run(env, b) {
  const calls = []; const orig = globalThis.fetch;
  globalThis.fetch = async (url, init) => { const bd = JSON.parse(init.body); calls.push({ host: new URL(url).host, model: bd.model, sys: bd.messages[0].content }); return good(); };
  try { const r = await T.handle(post(b), env, NOW); return { status: r.status, j: await r.json(), calls }; } finally { globalThis.fetch = orig; }
}
test('chat.general: urutan lama (Sakelar dulu) TIDAK berubah, tanpa petunjuk tambahan', async () => {
  const r = await run(env0(), req());
  assert.equal(r.j.provider, 'sakelar'); assert.equal(r.j.role, 'chat'); assert.equal(r.calls[0].sys.includes('analisis'), false);
});
test('analysis.general: Gemini diutamakan, petunjuk analisis ikut ke system prompt', async () => {
  const r = await run(env0(), req({ task: 'analysis.general' }));
  assert.equal(r.j.provider, 'gemini'); assert.equal(r.j.role, 'analysis'); assert.match(r.calls[0].sys, /analisis atau kode/);
});
test('creative.general: Sakelar diutamakan', async () => {
  const r = await run(env0(), req({ task: 'creative.general' }));
  assert.equal(r.j.provider, 'sakelar'); assert.equal(r.j.role, 'creative'); assert.match(r.calls[0].sys, /kreatif/);
});
test('utility.small: Gemini dengan model lite (model yang sudah tercantum), kecuali MODEL_GEMINI diisi', async () => {
  const r = await run(env0(), req({ task: 'utility.small' }));
  assert.equal(r.calls[0].model, 'gemini-3.5-flash-lite');
  const r2 = await run(env0({ MODEL_GEMINI: 'gemini-3.5-flash' }), req({ task: 'utility.small' }));
  assert.equal(r2.calls[0].model, 'gemini-3.5-flash');
});
test('ROUTE_ANALYSIS menimpa urutan tanpa APK baru; nama tak sah diabaikan', async () => {
  assert.deepEqual(T.routeOrder({ ROUTE_ANALYSIS: 'sakelar, bogus ,gemini' }, 'analysis.general'), ['sakelar', 'gemini', 'relay']);
  assert.deepEqual(T.routeOrder({ ROUTE_ANALYSIS: 'xxx' }, 'analysis.general'), ['gemini', 'sakelar', 'relay']);
  const r = await run(env0({ ROUTE_ANALYSIS: 'sakelar' }), req({ task: 'analysis.general' }));
  assert.equal(r.j.provider, 'sakelar');
});
test('Pilihan eksplisit dan CHAT_PROVIDER tetap menang atas tabel rute', async () => {
  const r = await run(env0(), req({ task: 'analysis.general', provider: 'sakelar' }));
  assert.equal(r.j.provider, 'sakelar');
  const r2 = await run(env0({ CHAT_PROVIDER: 'sakelar' }), req({ task: 'analysis.general' }));
  assert.equal(r2.j.provider, 'sakelar');
});
test('jenis pekerjaan tak dikenal ditolak 400, dan tidak ada rute riset (belum diverifikasi)', async () => {
  for (const t of ['research.search', 'bogus']) { const r = await run(env0(), req({ task: t })); assert.equal(r.status, 400); assert.equal(r.calls.length, 0); }
});
test('pesan galat cadangan dan jatah tetap bekerja pada rute non-chat', async () => {
  const e = env0(); const orig = globalThis.fetch; let n = 0;
  globalThis.fetch = async (url) => { n++; return new URL(url).host.includes('google') ? { ok: false, status: 402, json: async () => ({}) } : good(); };
  try { const r = await T.handle(post(req({ task: 'analysis.general', limit: 3 })), e, NOW); const j = await r.json(); assert.equal(j.provider, 'sakelar'); assert.equal(j.fallbackProvider, 'gemini'); assert.equal(j.used, 1); } finally { globalThis.fetch = orig; }
});
test('versi mengikuti revisi terbaru dan tes terdaftar', async () => {
  const { readFileSync } = await import('node:fs'); const pk = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
  assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev214\.test\.mjs/);
});
