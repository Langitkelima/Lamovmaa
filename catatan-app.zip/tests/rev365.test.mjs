// Rev 365 / PART W5: audit penutup paket format gaya WhatsApp. Perilaku DOM diaudit di Chromium: tools/audit_penutup_365.py (tes ini = kunci Node).
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
import { resolveLine } from '../src/js/format-wa.js';
import { parseNoteHtml, blocksToText, blocksToMarkdown } from '../src/js/export.js';
const { PANDUAN, PANDUAN_FORMAT, panduanText } = await import('../src/js/panduan-ketik.js');
const { TRIGGER_KINDS } = await import('../src/js/ketik-pemicu.js');

test('Panduan: contoh format WhatsApp benar-benar berformat lewat mesin W1, dan BUKAN jenis pemicu', () => {
  assert.equal(PANDUAN_FORMAT.length, 2);
  for (const p of PANDUAN_FORMAT) {
    const r = resolveLine(p.ketik.trimEnd());
    assert.equal(r.plain, 'halo', p.nama); assert.equal(r.runs.length, 1, p.nama);
    assert.ok(p.ketik.endsWith(' '), 'pemicu = karakter sesudah penutup: ' + p.nama);
  }
  assert.equal(resolveLine('*halo*').runs[0].tebal, true); assert.equal(resolveLine('_halo_').runs[0].miring, true);
  const g = resolveLine('*_halo_*').runs[0]; assert.ok(g.tebal && g.miring, 'gabungan di teks panduan benar');
  assert.equal(resolveLine('snake_case_nama').runs.length, 0); assert.equal(resolveLine('2*3*4').runs.length, 0);
  assert.deepEqual([...PANDUAN.map((p) => p.kind)].sort(), [...TRIGGER_KINDS].sort(), 'daftar pemicu tidak tercampur format');
});
test('Panduan: teks catatan memuat Tebal dan Miring, bentuk teks lama tetap (tanpa baris kosong di ujung)', () => {
  const t = panduanText();
  for (const p of PANDUAN_FORMAT) { assert.ok(t.includes(p.nama)); assert.ok(t.includes(p.hasil)); assert.ok(t.includes('Ketik: ' + p.ketik.replace(/ $/, ' (spasi)'))); }
  assert.ok(t.indexOf('Pengingat') < t.indexOf('Tebal'), 'format sesudah pemicu');
  assert.ok(!/\n\n$/.test(t) && !/^\s/.test(t));
});
test('Ekspor: <b>/<i> tampil benar di TXT (tanda hilang), MD (** dan *), dan runs PDF/JPG (b/i); baris centang dan bullet ikut', () => {
  const bl = parseNoteHtml('<div>kata <b>halo</b> dan <i>miring</i> serta <b><i>dua</i></b></div><ul><li><b>item</b> satu</li></ul><div class="todo" data-cid="c1"><b>tugas</b></div>');
  const t = blocksToText('J', bl), m = blocksToMarkdown('J', bl);
  assert.ok(t.includes('kata halo dan miring serta dua') && !/[*_]/.test(t.replace(/\u2610|\u2022/g, '')), 'TXT tanpa penanda');
  assert.ok(m.includes('kata **halo** dan *miring* serta ***dua***') && m.includes('- **item** satu') && m.includes('- [ ] **tugas**'), m);
  const r = bl[0].runs; assert.ok(r.find((x) => x.t === 'halo').b && r.find((x) => x.t === 'miring').i); const d = r.find((x) => x.t === 'dua'); assert.ok(d.b && d.i);
});
test('Ekspor: teks yang MASIH berpenanda mentah (bukan pemicu) tidak dimanipulasi ekspor', () => {
  const bl = parseNoteHtml('<div>2*3*4 dan snake_case_nama</div>');
  assert.ok(blocksToText('J', bl).includes('2*3*4 dan snake_case_nama'));
});
test('Sanitize + simpan: b/i lolos sanitize dan teks pencarian tidak memuat tag (kunci kabel)', () => {
  const n = read('src/js/notes.js');
  assert.match(n, /'B'|"B"|\bb\b.*\bi\b/s); // b/i ada di daftar tag yang diizinkan
  assert.ok(!/format-wa\.js/.test(read('src/js/main.js')), 'modul format-wa tetap tidak di jalur buka');
});
test('Paket W (W1-W4) tuntas: tanpa perubahan di Worker, SCHEMA, versi; panduan modul MALAS', () => {
  const pk = JSON.parse(read('package.json')); assert.equal(pk.version, '0.3.121');
  assert.ok(!/panduan-ketik/.test(read('src/js/main.js')));
  assert.match(read('README.md'), /Rev 36[2-5]/); /* Rev 383: README dipadatkan (K9), Paket W kini tercatat di baris Rev 362-364 */
});
