// Rev 426 / SY4c: laptop.js/css: sorotan catatan terbuka + mode panel hanya bila daftar ada (Private terkunci tampil penuh). Hanya web.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const baca = (p) => readFileSync(p, 'utf8');

test('laptop.css: aturan panel memakai data-pane, bukan data-tab, dan ada sorotan lap-open', () => {
  const css = baca('web/laptop.css');
  assert.ok(!/data-tab="privat"/.test(css));
  assert.match(css, /body\[data-lap\]\[data-pane\] \.fs/);
  assert.match(css, /\.card\.lap-open/);
});

test('laptop.js: data-pane hanya bila ada .selhost; sorotan mempertahankan kartu saat judul belum tersimpan; amati .fs di body', () => {
  const js = baca('web/laptop.js');
  assert.doesNotThrow(() => new Function(js));
  assert.match(js, /\.selhost/);
  assert.match(js, /pertahankan sorotan/);
  assert.match(js, /observe\(document\.body, \{ childList: true \}\)/);
  assert.ok(!/localStorage|fetch\(/.test(js));
});
