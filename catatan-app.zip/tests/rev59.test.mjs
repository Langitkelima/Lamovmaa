// Rev 59: sistem ekspor ala aplikasi catatan umum (Bagikan | Simpan ke perangkat; PDF, JPG, TXT, Markdown, Salin teks).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as E from '../src/js/export.js';
let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');

await t('Markdown: judul, tebal/miring/coret, centang, poin, nomor, paragraf tidak menyatu', () => {
  const b = E.parseNoteHtml('<div><b>Tebal</b> biasa <i>miring</i> <s>coret</s></div><div>Dua</div><div class="todo"><input type="checkbox" checked="">&nbsp;Beli</div><div class="todo"><input type="checkbox">&nbsp;Cuci</div><ul><li>a<ul><li>a1</li></ul></li></ul><ol><li>x</li></ol>');
  const md = E.blocksToMarkdown('Judul', b);
  assert.ok(md.startsWith('# Judul\n\n'));
  assert.ok(md.includes('**Tebal** biasa *miring* ~~coret~~'));
  assert.ok(/\*\*Tebal\*\*[^\n]*\n\nDua\n/.test(md), 'dua paragraf dipisah baris kosong');
  assert.ok(md.includes('- [x] Beli') && md.includes('- [ ] Cuci') && md.includes('- a\n') && md.includes('  - a1') && md.includes('1. x'));
  assert.ok(md.endsWith('\n') && !md.endsWith('\n\n'));
});
await t('Markdown: tanda khusus di-escape, tabel jadi tabel pipa, gambar jadi [gambar], kosong aman', () => {
  assert.ok(E.blocksToMarkdown('a*b_c', []).startsWith('# a\\*b\\_c'));
  const tb = E.blocksToMarkdown('', E.parseNoteHtml('<table data-hr="1"><tr><td>H1</td><td>H2</td></tr><tr><td>a|b</td><td>c</td></tr></table>'));
  assert.ok(tb.includes('| H1 | H2 |') && tb.includes('| --- | --- |') && tb.includes('a\\|b'));
  assert.ok(E.blocksToMarkdown('', [{ kind: 'image', id: 'abcdefghij', width: 10, height: 10 }]).includes('[gambar]'));
  assert.equal(E.blocksToMarkdown('', []).trim(), '');
});
await t('lembar ekspor: pilihan Bagikan/Simpan, empat format + Salin teks, tanpa dialog WYSIWYG', () => {
  const s = src('../src/js/share.js');
  for (const k of ["'Bagikan'", "'Simpan ke perangkat'", "'PDF'", "'Gambar JPG'", "'Teks (.txt)'", "'Markdown (.md)'", "'Salin teks'", "'txt'", "'md'", 'saveFiles', 'noteMarkdown']) assert.ok(s.includes(k), k);
  assert.ok(!/WYSIWYG/i.test(s) && !s.includes('metode lama'));
});
await t('Simpan ke perangkat: Dokumen/NotesKelimaa/Ekspor, rekursif, teks utf8 dan biner base64, nama diberi jam-menit', () => {
  const s = src('../src/js/share.js');
  assert.ok(s.includes("'NotesKelimaa/Ekspor'") && s.includes("directory: 'DOCUMENTS'") && s.includes('recursive: true') && s.includes("encoding: 'utf8'"));
  assert.ok(s.includes('getHours()') && s.includes('getMinutes()'));
  assert.ok(s.includes('checkPermissions'));
});
await t('jalur Bagikan lama tetap: berkas lewat CACHE + Share, teks utf8; tidak ada plugin baru', () => {
  const s = src('../src/js/share.js');
  assert.ok(s.includes("directory: 'CACHE'") && s.includes('SH.share('));
  const pk = JSON.parse(src('../package.json'));
  assert.ok(!Object.keys(pk.dependencies).some((k) => /print|pdf|file-opener|saf/i.test(k)));
});
await t('versi 0.3.2 selaras di package.json, layar Setelan, RIWAYAT', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(src('../RIWAYAT.md').includes('versi 0.3.2'));
});
console.log(`${n} tes lulus (Rev 59)`);
