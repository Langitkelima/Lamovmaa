// Rev 399 / PART M4: gambar ikut diimpor dari Markdown/ZIP (dikecilkan ke kualitas Hemat) + PERBAIKAN sintaks impor-md-ui.js (Rev 398).
// Tes AI (Node, FS dan pengecil gambar PALSU). Pengecilan gambar nyata (kanvas), Filesystem dan pemilih berkas Android BELUM diuji di HP.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs'; import { spawnSync } from 'node:child_process';
import { markdownToNote } from '../src/js/md-catatan.js';
import { planMarkdownImport, commitMarkdownImport, materializeImages, importSummary, isImageName, IMPOR_MAX_IMAGES, IMPOR_IMAGE_PRESET } from '../src/js/impor-md.js';
import { planMarkdownExport, writeMarkdownZipToCache, mdZipName } from '../src/js/ekspor-md.js';
import { readZipIndex, readZipEntry, utf8, base64ToBytes } from '../src/js/zip.js';
import { parseRefs, MAX_IMAGES_PER_NOTE } from '../src/js/cadangan-gambar.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
let seq = 0; const deps0 = { sanitize: (h) => h, newId: () => 'id' + (++seq), now: 1000 };
const ent = (name, size = 1000) => ({ name, size, read: async () => new Uint8Array([1, 2, 3]) });

test('SINTAKS: semua modul src/js dan src/js/ai bisa diurai (Rev 398 sempat memuat } yang tertelan komentar di impor-md-ui.js)', () => {
  const bad = [];
  for (const dir of ['src/js', 'src/js/ai']) for (const f of fs.readdirSync(new URL('../' + dir + '/', import.meta.url)).filter((n) => n.endsWith('.js'))) {
    const r = spawnSync(process.execPath, ['--check', new URL('../' + dir + '/' + f, import.meta.url).pathname], { encoding: 'utf8' });
    if (r.status !== 0) bad.push(dir + '/' + f + ': ' + String(r.stderr).split('\n').slice(0, 3).join(' | '));
  }
  assert.deepEqual(bad, []);
});

test('markdownToNote: opsi image hanya untuk gambar SENDIRIAN di satu baris; tanpa opsi atau callback null = penanda teks seperti sebelumnya', () => {
  const calls = [];
  const r = markdownToNote('Teks ![kecil](x.png) di tengah\n\n![Foto liburan](gambar/a.webp)\n\n![](b.jpg "judul")\n\n![x](https://situs.com/c.png)', { image: (src, alt) => { calls.push([src, alt]); return /situs/.test(src) ? null : '<!--mdimg:' + calls.length + '-->'; } });
  assert.deepEqual(calls, [['gambar/a.webp', 'Foto liburan'], ['b.jpg', ''], ['https://situs.com/c.png', 'x']]);
  assert.ok(r.html.includes('<!--mdimg:1--><!--mdimg:2-->'));
  assert.ok(r.html.includes('[gambar: kecil]') && r.html.includes('[gambar: x]')); assert.ok(r.warnings.includes('gambar:2')); // sebaris + yang ditolak callback tetap dihitung
  const lama = markdownToNote('![a](b.png)'); assert.equal(lama.html, '<div>[gambar: a]</div>'); assert.ok(lama.warnings.includes('gambar:1'));
});

test('rencana: alamat dicocokkan ke gambar yang ada (folder relatif, ../, %20, nama saja); http/data/mutlak tidak; nama kembar tidak ditebak', () => {
  const md = '# A\n\n![1](gambar/satu.webp)\n\n![2](../gambar/dua%20x.jpg)\n\n![3](tiga.PNG)\n\n![4](https://x.id/e.png)\n\n![5](data:image/png;base64,AAAA)\n\n![6](/sdcard/f.png)\n\n![7](kembar.png)';
  const imgs = [ent('gambar/satu.webp'), ent('gambar/dua x.jpg'), ent('foto/tiga.png'), ent('a/kembar.png'), ent('b/kembar.png')];
  const p = planMarkdownImport([{ name: 'folder/a.md', text: md }], [], imgs);
  assert.equal(p.items.length, 1); assert.equal(p.imageCount, 3); assert.equal(p.items[0].imgs.length, 3);
  assert.deepEqual(p.items[0].imgs.map((i) => i.entry.name), ['gambar/satu.webp', 'gambar/dua x.jpg', 'foto/tiga.png']);
  assert.equal((p.items[0].html.match(/<!--mdimg:\d+-->/g) || []).length, 3); assert.equal(p.warnings.gambar, 4);
  assert.match(importSummary(p), /3 gambar ikut \(dikecilkan dulu ke kualitas Hemat\)/); assert.match(importSummary(p), /4 gambar tidak ikut/);
  const tanpa = planMarkdownImport([{ name: 'a.md', text: md }]); assert.equal(tanpa.imageCount, 0); assert.equal(tanpa.warnings.gambar, 7); assert.ok(!/<!--mdimg/.test(tanpa.items[0].html));
});

test('rencana: batas 10 gambar per catatan, 100 per impor, sumber > 30 MB; satu berkas dipakai dua catatan dihitung sekali', () => {
  const baris = (n) => Array.from({ length: n }, (_, i) => '![](g' + i + '.png)').join('\n\n');
  const imgs = Array.from({ length: 150 }, (_, i) => ent('g' + i + '.png'));
  const a = planMarkdownImport([{ name: 'a.md', text: baris(13) }], [], imgs);
  assert.equal(a.items[0].imgs.length, MAX_IMAGES_PER_NOTE); assert.equal(a.imageLimit, 3); assert.equal(a.warnings.gambar, 3); assert.match(importSummary(a), /maksimal 10 gambar per catatan dan 100 per impor/);
  const banyak = Array.from({ length: 12 }, (_, i) => ({ name: 'n' + i + '.md', text: Array.from({ length: 10 }, (_, k) => '![](g' + (i * 10 + k) + '.png)').join('\n\n') }));
  const b = planMarkdownImport(banyak, [], imgs); assert.equal(b.imageCount, IMPOR_MAX_IMAGES); assert.equal(b.imageLimit, 20);
  const dua = planMarkdownImport([{ name: 'x.md', text: '![](g0.png)' }, { name: 'y.md', text: '![](g0.png)' }], [], imgs); assert.equal(dua.imageCount, 1); assert.equal(dua.items[0].imgs[0].entry, dua.items[1].imgs[0].entry);
  const besar = planMarkdownImport([{ name: 'z.md', text: '![](h.png)\n\n![](k.png)' }], [], [ent('h.png', 31 * 1024 * 1024), ent('k.png', 5)]);
  assert.equal(besar.imageCount, 1); assert.equal(besar.imageBig, 1); assert.match(importSummary(besar), /lebih dari 30 MB/);
  assert.ok(isImageName('a.JPG') && isImageName('a.jpeg') && !isImageName('a.gif') && !isImageName('a.md') && IMPOR_IMAGE_PRESET === 'hemat');
});

test('materializeImages: figure sah (parseRefs), kualitas Hemat, satu berkas dikecilkan sekali, gagal = penanda teks, data aplikasi tidak disentuh', async () => {
  const imgs = [ent('a.png'), ent('b.jpg'), ent('rusak.png')];
  const plan = planMarkdownImport([{ name: 'x.md', text: 'Awal\n\n![Foto <A>](a.png)\n\n![](b.jpg)\n\n![bad "q"](rusak.png)' }, { name: 'y.md', text: '![](a.png)' }], [], imgs);
  const calls = { read: [], compress: [], write: [], prog: [] }; let k = 0;
  const r = await materializeImages(plan, {
    read: async (e) => { calls.read.push(e.name); return new Uint8Array([9, 9]); },
    compress: async (file, preset) => { calls.compress.push([file.name, file.type, preset]); if (file.name === 'rusak.png') throw new Error('Gambar tidak bisa dibuka.'); return { blob: new Blob([file.name]), w: 800, h: 600, b: 4000, x: 'webp' }; },
    write: async (ref, blob) => { calls.write.push(ref.id + '.' + ref.x); }, newId: () => 'gambar' + String(++k).padStart(8, '0'), onProgress: (n, t) => calls.prog.push(n + '/' + t),
  });
  assert.deepEqual(calls.read, ['a.png', 'b.jpg', 'rusak.png']); assert.deepEqual(calls.compress.map((c) => c[0] + ':' + c[1] + ':' + c[2]), ['a.png:image/png:hemat', 'b.jpg:image/jpeg:hemat', 'rusak.png:image/png:hemat']);
  assert.equal(r.done, 2); assert.equal(r.refs.length, 2); assert.equal(r.failed.length, 1); assert.deepEqual(r.failed[0], { name: 'rusak.png', reason: 'Gambar tidak bisa dibuka.' }); assert.deepEqual(calls.prog, ['1/3', '2/3', '3/3']);
  const h1 = r.plan.items[0].html, h2 = r.plan.items[1].html;
  assert.equal(parseRefs(h1).length, 2); assert.equal(parseRefs(h2).length, 1); assert.equal(parseRefs(h1)[0].id, parseRefs(h2)[0].id); // a.png dipakai bersama
  assert.ok(h1.includes('<div>[gambar: bad &quot;q&quot;]</div>') && !/<!--mdimg/.test(h1 + h2)); assert.equal(calls.write.length, 2);
  assert.ok(plan.items[0].html.includes('<!--mdimg:0-->')); // rencana asli tidak berubah
  const d = { settings: { labels: [] }, notes: [], priv: [] }; commitMarkdownImport(d, r.plan, deps0);
  assert.equal(parseRefs(d.notes[0].html).length, 2); assert.equal(d.priv.length, 0);
});

test('bolak-balik: ekspor ZIP dengan gambar -> baca ZIP -> impor -> figure terhubung ke berkas baru (pengecil palsu)', async () => {
  const ID = 'abcdefghij1234567890';
  const src = { settings: { labels: [] }, notes: [{ id: '1', title: 'Foto', html: '<div>Lihat</div><figure class="ki" data-kimg="' + ID + '" data-w="10" data-h="10" data-b="100" data-x="jpg"></figure><p><br></p><div>Selesai</div>' }], priv: [] };
  const plan0 = planMarkdownExport(src, { images: true }, new Date(2026, 10, 22)), store = {};
  const FS = { writeFile: async (o) => { store[o.path] = base64ToBytes(o.data); return { uri: 'u' }; }, appendFile: async () => {}, readFile: async () => ({ data: Buffer.from('JPEGDATA').toString('base64') }), deleteFile: async () => {} };
  await writeMarkdownZipToCache(FS, plan0, mdZipName(new Date(2026, 10, 22)), new Date(2026, 10, 22));
  const blob = new Blob([store[mdZipName(new Date(2026, 10, 22))]]), idx = await readZipIndex(blob), files = [], imgs = [];
  for (const e of idx) { if (isImageName(e.name)) imgs.push({ name: e.name, size: e.size, read: () => readZipEntry(blob, e) }); else files.push({ name: e.name, text: utf8.decode(await readZipEntry(blob, e)) }); }
  assert.equal(imgs.length, 1); assert.equal(imgs[0].name, 'gambar/' + ID + '.jpg');
  const p = planMarkdownImport(files, [], imgs); assert.equal(p.imageCount, 1); assert.equal(p.items[0].imgs.length, 1);
  const w = []; const r = await materializeImages(p, { read: (e) => e.read(), compress: async (f) => ({ blob: new Blob([f]), w: 640, h: 480, b: 123, x: 'webp' }), write: async (ref) => w.push(ref), newId: () => 'baru' + 'x'.repeat(12) });
  const refs = parseRefs(r.plan.items[0].html); assert.equal(refs.length, 1); assert.equal(refs[0].id, 'baru' + 'x'.repeat(12)); assert.equal(refs[0].x, 'webp'); assert.equal(w.length, 1);
  assert.ok(r.plan.items[0].html.indexOf('Lihat') < r.plan.items[0].html.indexOf('data-kimg') && r.plan.items[0].html.indexOf('data-kimg') < r.plan.items[0].html.indexOf('Selesai'));
});

test('pemasangan: UI memuat gambar-app MALAS, terima tipe gambar, memberi tahu bila penyimpanan gambar tidak ada; mesin tetap tanpa DOM; versi tidak berubah', () => {
  const ui = rd('src/js/impor-md-ui.js');
  assert.ok(ui.includes("import('./gambar-app.js')") && !/^import .*gambar-app/m.test(ui));
  assert.ok(ui.includes('.png,.jpg,.jpeg,.webp') && ui.includes('materializeImages') && ui.includes('penyimpanan gambar tidak tersedia') && ui.includes('Memproses gambar'));
  assert.ok(/imgs\.push\(\{ name: f\.name/.test(ui) && /isImageName\(e\.name\)/.test(ui));
  assert.ok(!/\b(document|window|localStorage|fetch|XMLHttpRequest)\b/.test(rd('src/js/impor-md.js').replace(/\/\/.*$/gm, '')));
  assert.ok(!/gambar\.js/.test(rd('src/js/impor-md.js').replace(/cadangan-gambar\.js/g, '')));
  assert.equal(JSON.parse(rd('package.json')).version, '0.3.121'); assert.ok(rd('package.json').includes('tests/rev399.test.mjs'));
});
