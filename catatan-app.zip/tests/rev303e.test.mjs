// Rev 303e / v0.3.121: ringkasan kotak centang "3 dari 5 tercentang" (mesin murni + pemasangan di info bar). SCHEMA 22, CSS, Worker, native tidak berubah.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as K from '../src/js/lembar-kotak.js';
import * as V from '../src/js/lembar-validasi.js';
import * as L from '../src/js/lembar.js';
let n = 0; const test = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mk = () => {
  const sh = L.newSheet({ id: 'k', name: 'Tugas' }), tab = sh.tabs[0], put = (r, c, v) => L.setCell(tab, tab.rows[r].id, tab.cols[c].id, v);
  for (let i = 0; i < 6; i++) put(i, 0, { v: 'T' + i });
  put(0, 1, { v: true }); put(1, 1, { v: false }); put(2, 1, { v: true }); put(3, 1, { v: 'TRUE' });
  tab.checks = V.cleanChecks([{ id: 'v1abc', c: tab.cols[1].id, k: 'box', rg: { r1: tab.rows[0].id, r2: tab.rows[4].id, c2: tab.cols[1].id } }], tab.cols, tab.rows);
  return { tab, rects: tab.checks.map((ck) => V.checkRect(tab, ck)), boxAt: (i, j) => V.checkAt(tab, i, j) && V.checkAt(tab, i, j).k === 'box', raw: (i, j) => { const c = tab.rows[i].cells[tab.cols[j].id]; return c ? c.v : undefined; } };
};
test('satu sel kotak dipilih = ringkasan SELURUH rentang aturannya (3 dari 5)', () => {
  const { rects, boxAt, raw } = mk(); const cells = K.boxSelCells({ r1: 1, r2: 1, c1: 1, c2: 1 }, rects, boxAt);
  assert.equal(cells.length, 5); const t = K.boxTally(cells, raw); assert.deepEqual(t, { done: 3, total: 5 }); assert.equal(K.boxTallyText(t), '3 dari 5 tercentang');
});
test('seleksi banyak sel = hanya kotak di dalam seleksi; sel di luar rentang tidak dihitung', () => {
  const { rects, boxAt, raw } = mk(); const cells = K.boxSelCells({ r1: 0, r2: 1, c1: 0, c2: 1 }, rects, boxAt);
  assert.equal(cells.length, 2); assert.equal(K.boxTallyText(K.boxTally(cells, raw)), '1 dari 2 tercentang');
  assert.equal(K.boxSelCells({ r1: 0, r2: 5, c1: 0, c2: 0 }, rects, boxAt).length, 0); // kolom A bukan kotak
});
test('sel biasa (bukan kotak) yang dipilih sendirian = tanpa ringkasan; teks kosong', () => {
  const { rects, boxAt, raw } = mk(); const cells = K.boxSelCells({ r1: 5, r2: 5, c1: 1, c2: 1 }, rects, boxAt);
  assert.equal(cells.length, 0); assert.equal(K.boxTallyText(K.boxTally(cells, raw)), ''); assert.equal(K.boxTallyText(null), '');
});
test('seluruh kolom/lembar dipilih: aman (tanpa loop liar) dan tidak ganda untuk aturan kembar', () => {
  const { tab, rects, boxAt, raw } = mk(); const dup = [rects[0], rects[0]];
  assert.equal(K.boxSelCells({ r1: 0, r2: 5, c1: 0, c2: 1 }, dup, boxAt).length, 5);
  assert.equal(K.boxSelCells({ r1: 0, r2: 99999, c1: 0, c2: 99 }, rects, boxAt, 10).length <= 10, true);
  assert.equal(K.boxSelCells(null, rects, boxAt).length, 0); assert.equal(K.boxSelCells({ r1: 0, r2: 0, c1: 1, c2: 1 }, null, boxAt).length, 0); assert.ok(tab && raw);
});
test('pemasangan: lembar-ui.js memanggil paintBoxInfo dari paintBar; modul awal tidak mengimpor lembar-kotak.js', () => {
  const ui = src('src/js/lembar-ui.js'); assert.match(ui, /import \{ isBox, boxState, nextBoxValue, boxTally, boxSelCells, boxTallyText \} from '\.\/lembar-kotak\.js'/);
  assert.match(ui, /const paintBoxInfo = \(\) =>/); assert.match(ui, /paintBoxInfo\(\); const pc =/);
  for (const f of ['main', 'startup', 'notes', 'settings', 'storage', 'lembar-pintu', 'lembar']) assert.ok(!src('src/js/' + f + '.js').includes('lembar-kotak'), f);
  assert.ok(!/^import /m.test(src('src/js/lembar-kotak.js')));
});
test('tidak ada perubahan skema/versi: SCHEMA 22, versi 0.3.121', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/);
});
console.log(n + ' tes rev303e ok');
