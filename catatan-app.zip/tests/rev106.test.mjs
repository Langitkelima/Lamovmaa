// Rev 106: lonceng baris kotak centang didesain ulang (lencana bulat) + perbaikan Simpan pengingat pada waktu custom yang tidak valid.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { checkChoice, MIN_LEAD_MS } from '../src/js/ingatkan.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('Rev 106: waktu custom kurang dari 1 menit ditolak oleh checkChoice (penyebab Simpan tampak mati)', () => {
  const now = Date.parse('2026-11-08T12:01:30');
  assert.equal(checkChoice(Date.parse('2026-11-08T12:02:00'), 'none', now).ok, false);
  assert.equal(checkChoice(Date.parse('2026-11-08T12:03:00'), 'none', now).ok, true);
  assert.equal(MIN_LEAD_MS, 60000);
});
test('Rev 106: lembar menampilkan galat di dalam lembar, Simpan nonaktif bila tidak valid, min datetime-local diperlebar', () => {
  const nt = src('src/js/notes.js');
  assert.ok(nt.includes('MIN_LEAD_MS + 60000'));
  assert.ok(nt.includes("sum.classList.toggle('warn', bad)"));
  assert.ok(nt.includes('bSave.disabled = !pick || !chk.ok'));
  assert.ok(nt.includes("dt.addEventListener('change', onDt)"));
  assert.ok(nt.includes('if (!chk.ok) { refresh(true); toast(chk.reason); return; }'));
  assert.match(src('src/css/styles.css'), /\.rm-sum\.warn\{/);
});
test('Rev 106: CSS lonceng lencana 32px, kosong = cincin + plus, aktif = gradasi + titik emas; toast tidak diubah', () => {
  const css = src('src/css/styles.css');
  assert.match(css, /--bell-idle:url\("data:image\/svg\+xml/);
  assert.match(css, /width:32px;height:32px;margin:-2px -1px 0 auto;border-radius:50%/);
  assert.match(css, /linear-gradient\(145deg,var\(--ac\),#8B6CF0\)/);
  assert.match(css, /\.toast\{[^}]*z-index:8/);
  assert.ok(src('src/js/notes.js').includes('const BELL_W = 44;'), 'area ketuk tidak berubah');
});
test('Rev 106: versi 0.3.121', () => {
  assert.equal(JSON.parse(src('package.json')).version, '0.3.121');
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
