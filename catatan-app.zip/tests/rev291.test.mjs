// Rev 291 / T5b: kelompok templat "Admin" bagian 2 (Rekap bulanan, Nilai dan rapor, Peminjaman aset, Laporan penjualan, Kontak dan pencarian): nilai kunci dihitung mesin rumus sungguhan.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as T from '../src/js/lembar-templat.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import { chartList } from '../src/js/lembar-grafik.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN);
const src = (f) => readFileSync(new URL('../' + f, import.meta.url), 'utf8');
const NOW = new Date(2026, 10, 14, 12, 0, 0).getTime();
const IDS = ['admin-rekap', 'admin-rapor', 'admin-aset', 'admin-jual', 'admin-kontak'];
const mk = (id) => T.makeFromTemplate(id, { now: NOW });
const first = (id) => { const tab = mk(id).sheet.tabs[0]; return { tab, d: makeDisplay(tab, { now: NOW }) }; };
test('Rev 291: lima templat Admin ada, nama <= 30, keterangan, Panduan terakhir, failed 0, muat batas, tanpa galat rumus, bulat-balik', () => {
  const ids = T.templateList().map((t) => t.id); for (const id of IDS) assert.ok(ids.includes(id), id); assert.equal(new Set(ids).size, ids.length);
  for (const id of IDS) {
    const t = T.templateList().find((x) => x.id === id); assert.ok(t.name.startsWith('Admin · ') && t.name.length <= 30 && t.desc.length >= 20 && t.desc.length <= 100, id);
    const r = mk(id); assert.ok(r, id); assert.equal(r.failed, 0, id); assert.ok(L.fitsLimit(r.sheet)); const tabs = r.sheet.tabs;
    assert.equal(tabs[tabs.length - 1].name, 'Panduan', id); assert.ok(tabs.length <= 5);
    for (const tab of tabs) { const d = makeDisplay(tab, { now: NOW }); for (let i = 0; i < tab.rows.length; i++) for (let j = 0; j < tab.cols.length; j++) assert.doesNotMatch(String(d.text(i, j)), /^#/, id + ' ' + L.cellAddr(j, i)); }
    assert.equal(JSON.stringify(L.cleanSheet(JSON.parse(JSON.stringify(r.sheet)))), JSON.stringify(r.sheet), id);
  }
});
test('Rev 291: Rekap bulanan = jumlah per bulan benar, total 15.710.000, diagram kolom; berubah saat jumlah diganti', () => {
  const { tab, d } = first('admin-rekap');
  assert.deepEqual(Array.from({ length: 12 }, (_, i) => d.raw(i + 1, 8)), [4650000, 800000, 750000, 280000, 350000, 900000, 1500000, 460000, 320000, 500000, 4200000, 1000000]);
  assert.equal(d.raw(13, 8), 15710000); assert.equal(d.raw(1, 2), 1); assert.equal(d.raw(14, 2), 12); assert.equal(tab.rules.length, 1); assert.deepEqual(chartList(tab).map((c) => c.kind), ['column']);
  L.setCell(tab, tab.rows[1].id, tab.cols[4].id, { v: 50000 }); const d2 = makeDisplay(tab, { now: NOW }); assert.equal(d2.raw(1, 8), 50000 + 450000); assert.equal(d2.raw(13, 8), 15710000 - 4200000 + 50000);
});
test('Rev 291: Nilai dan rapor = rata-rata, peringkat 1-8, predikat, rekap kelas 80,5 / 94,3 / 65 / 8 / 6 / 2; aturan warna, diagram', () => {
  const { tab, d } = first('admin-rapor');
  assert.deepEqual(Array.from({ length: 8 }, (_, i) => d.raw(i + 1, 5)), [85, 69, 94.3, 65, 87.7, 80, 92, 71]); assert.deepEqual(Array.from({ length: 8 }, (_, i) => d.raw(i + 1, 6)), [4, 7, 1, 8, 3, 5, 2, 6]);
  assert.deepEqual(Array.from({ length: 8 }, (_, i) => d.raw(i + 1, 7)), ['B', 'D', 'A', 'D', 'B', 'B', 'A', 'C']);
  assert.deepEqual([1, 2, 3, 4, 5, 6].map((i) => d.raw(i, 10)), [80.5, 94.3, 65, 8, 6, 2]); assert.equal(tab.rules.length, 2); assert.deepEqual(chartList(tab).map((c) => c.kind), ['column']);
  L.setCell(tab, tab.rows[4].id, tab.cols[2].id, { v: 100 }); const d2 = makeDisplay(tab, { now: NOW }); assert.equal(d2.raw(4, 5), 78.3); assert.equal(d2.raw(4, 6), 6); assert.equal(d2.raw(4, 7), 'C'); assert.equal(d2.raw(5, 10), 7); assert.equal(d2.raw(6, 10), 1);
});
test('Rev 291: Peminjaman aset = sisa hari dari TODAY (-2, 2, kosong, 4, 0, kosong, -1, 5), rekap 6/2/8 dan terlambat 2; dropdown dan donat', () => {
  const { tab, d } = first('admin-aset');
  assert.deepEqual(Array.from({ length: 8 }, (_, i) => d.raw(i + 1, 6)), [-2, 2, '', 4, 0, '', -1, 5]); assert.deepEqual([1, 2, 3, 5].map((i) => d.raw(i, 9)), [6, 2, 8, 2]);
  assert.equal(tab.checks.length, 1); assert.equal(tab.rules.length, 2); assert.deepEqual(chartList(tab).map((c) => c.kind), ['donut']);
  L.setCell(tab, tab.rows[1].id, tab.cols[5].id, { v: 'Kembali' }); const d2 = makeDisplay(tab, { now: NOW }); assert.equal(d2.raw(1, 6), ''); assert.equal(d2.raw(1, 9), 5); assert.equal(d2.raw(2, 9), 3); assert.equal(d2.raw(5, 9), 1);
  const d3 = makeDisplay(tab, { now: NOW + 3 * 86400000 }); assert.equal(d3.raw(2, 6), -1); assert.equal(d3.raw(5, 9), 3); // tiga hari kemudian: Proyektor, Kunci, Speaker sudah lewat tempo (Mic dan Tablet belum)
});
test('Rev 291: Laporan penjualan = total per produk 575/540/540/450 rb, per sales 790/509/806 rb, total 2.105.000, SUMIFS 250.000; bar + donat, dua dropdown', () => {
  const { tab, d } = first('admin-jual');
  assert.deepEqual([1, 2, 3, 4].map((i) => d.raw(i, 9)), [575000, 540000, 540000, 450000]); assert.deepEqual([1, 2, 3].map((i) => d.raw(i, 12)), [790000, 509000, 806000]);
  assert.deepEqual([7, 8, 9, 10, 11].map((i) => d.raw(i, 9)), [2105000, 12, 175417, 250000, 250000]); assert.equal(tab.checks.length, 2); assert.deepEqual(chartList(tab).map((c) => c.kind).sort(), ['bar', 'donut']);
  L.setCell(tab, tab.rows[1].id, tab.cols[4].id, { v: 20 }); const d2 = makeDisplay(tab, { now: NOW }); assert.equal(d2.raw(1, 6), 500000); assert.equal(d2.raw(1, 9), 825000); assert.equal(d2.raw(1, 12), 1040000); assert.equal(d2.raw(11, 9), 500000);
});
test('Rev 291: Kontak = pencarian nama mengisi jabatan, telepon (0 di depan tetap), email, urutan, jumlah; nama tak ada = Tidak ditemukan; validasi email', () => {
  const { tab, d } = first('admin-kontak');
  assert.deepEqual([2, 3, 4, 5, 6].map((i) => d.raw(i, 7)), ['Kepala Bagian', '081200000002', 'budi@contoh.id', 2, 8]); assert.deepEqual(tab.checks.map((c) => c.k), ['email']);
  L.setCell(tab, tab.rows[1].id, tab.cols[7].id, { v: 'gita maharani' }); const d2 = makeDisplay(tab, { now: NOW }); assert.equal(d2.raw(2, 7), 'Resepsionis'); assert.equal(d2.raw(5, 7), 7);
  L.setCell(tab, tab.rows[1].id, tab.cols[7].id, { v: 'Zzz' }); const d3 = makeDisplay(tab, { now: NOW }); assert.equal(d3.raw(2, 7), 'Tidak ditemukan'); assert.equal(d3.raw(5, 7), '-');
});
test('Rev 291: modul data murni; hanya fungsi yang ada; urutan templat; mesin dan settings tidak menyebut berkas data', () => {
  const s = src('src/js/templat-admin-lanjut.js'); assert.doesNotMatch(s, /import |localStorage|document\.|window\.|eval\(|new Function/);
  const ada = new Set([...src('src/js/rumus.js').matchAll(/^\s{2}([A-Z][A-Z0-9]+): \{ min:/gm)].map((m) => m[1]));
  const used = new Set([...s.matchAll(/'(=[^']*)'/g)].flatMap((m) => [...m[1].matchAll(/\b([A-Z]{2,})\(/g)].map((x) => x[1]))); assert.ok(used.size >= 10); for (const f of used) assert.ok(ada.has(f), f);
  const ids = T.templateList().map((t) => t.id); assert.equal(ids.length, 35); assert.deepEqual(ids.slice(15, 20), IDS); assert.deepEqual(ids.slice(-10, -6), ['anggaran', 'bagi', 'jadwal', 'nilai']);
  for (const f of ['settings', 'lembar', 'lembar-ui', 'main']) assert.doesNotMatch(src('src/js/' + f + '.js'), /templat-admin-lanjut/, f);
});
