import assert from 'node:assert/strict';
import { parseNoteHtml, layoutDoc } from '../src/js/export.js';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok - ' + name); };
t('Rev 30: parser membaca data-fs pada span', () => {
 const b = parseNoteHtml('<p>Normal <span data-fs="150" style="font-size:150%">besar</span> akhir</p>');
 const runs = b.flatMap(x => x.runs || []);
 assert.equal(runs.find(x => x.t === 'besar').fs,150);
 assert.equal(runs.find(x => x.t === 'Normal ').fs,100);
});
t('Rev 30: layout ekspor memperbesar ukuran segmen', () => {
 const blocks = parseNoteHtml('<p><span data-fs="200" style="font-size:200%">Besar</span> normal</p>');
 const o = { width:500,padX:20,size:16,titleSize:20,measure:(s,{size})=>s.length*size*.5 };
 const lines = layoutDoc({title:'',blocks},o).filter(x=>x.kind==='text');
 assert.equal(lines[0].segs[0].size,32);
 assert.equal(lines[0].segs[1].size,16);
 assert.equal(lines[0].lh,Math.round(32*1.45));
});
console.log(`${n} tes ekspor ukuran huruf lulus`);
