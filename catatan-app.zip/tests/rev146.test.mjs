// Rev 146 / U9b-2b: UI warna bersyarat lembar kerja (item Warna bersyarat di lembar Lainnya + warna tampil di grid). Model/mesin = Rev 145.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as R from '../src/js/lembar-aturan.js';
import * as L from '../src/js/lembar.js';
import { makeDisplay } from '../src/js/lembar-tampil.js';
import * as S from '../src/js/storage.js';
import { a1ToStored } from '../src/js/rumus.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const ui = src('src/js/lembar-ui.js');
const mk = (vals) => { const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0]; vals.forEach((v, r) => { if (v !== undefined && !(typeof v === 'string' && v[0] === '=')) L.setCell(tab, tab.rows[r].id, tab.cols[0].id, { v }); }); vals.forEach((v, r) => { if (typeof v === 'string' && v[0] === '=') { const k = a1ToStored(v, tab); assert.ok(k.ok, v); L.setCell(tab, tab.rows[r].id, tab.cols[1].id, { fx: k.fx }); } }); return { sh, tab }; };

test('kabel UI: lembar-ui mengimpor mesin aturan, item warna ada di openMore, rc dihitung SEKALI per (tab, ver) bukan per sel', () => {
  assert.match(ui, /import \{ ruleColors, ruleText, MAX_RULES \} from '\.\/lembar-aturan\.js'/);
  assert.match(ui, /item\('warna', 'Warna bersyarat'/);
  const m = ui.slice(ui.indexOf('const openMore'), ui.indexOf('bM.addEventListener'));
  assert.ok(m.indexOf("item('warna'") < m.indexOf("item('impor'") && m.indexOf("item('impor'") < m.indexOf("item('csv'")); // Rev 264: kelompok Olah data lalu Impor & ekspor
  assert.equal((ui.match(/ruleColors\(/g) || []).length, 1, 'ruleColors dipanggil di satu tempat (getRC)');
  const g = ui.slice(ui.indexOf('const getRC'), ui.indexOf('const drawRows'));
  assert.match(g, /tab\.id \+ '\|' \+ ver/); assert.match(g, /NO_RC/);
  const d = ui.slice(ui.indexOf('const drawRows'), ui.indexOf('const paintBar'));
  assert.match(d, /const cc = getCalc\(\), rc = getRC\(cc\)/); assert.match(d, /rc\.size && !\(fxd && fxd\.err\)/);
  assert.ok(d.indexOf('rc.get(') > d.indexOf('el.style.left'), 'warna bersyarat dipasang sesudah gaya sel');
});

test('kabel UI: satu langkah Urungkan per perubahan aturan, snapshot SEBELUM berubah, hanya bila berhasil; batas ukuran memulihkan', () => {
  const o = ui.slice(ui.indexOf('const openRules'), ui.indexOf('// --- Rev 148 / U9b-3b'));
  const a = o.slice(o.indexOf('const apply = '), o.indexOf('const paintList'));
  assert.ok(a.indexOf('const snap = ser()') < a.indexOf('L.setRules(') && a.indexOf('L.setRules(') < a.indexOf('hist.push(snap)'));
  assert.match(a, /if \(!L\.setRules\(tab, next\)\) return false/); assert.match(a, /fitsLimit\(sheet\)\) \{ restore\(snap\)/);
  assert.equal((o.match(/hist\.push\(/g) || []).length, 1, 'semua perubahan aturan lewat apply()');
  assert.match(o, /MAX_RULES/); assert.match(o, /if \(!sel\) \{ t(?:Ok|Warn|Err|Info)\('Pilih sel dulu\.'\)/);
});

test('perilaku: aturan yang dibuat dialog (bentuk rule) menghasilkan warna di sel yang tepat, memakai HASIL rumus', () => {
  const { sh, tab } = mk([5, 12, undefined, 'x', '=A1*10']);
  const rule = { id: '', c: tab.cols[0].id, op: 'gt', a: 10, bg: '#FECACA' }, ruleB = { id: '', c: tab.cols[1].id, op: 'gt', a: 10, bg: '#BBF7D0' };
  assert.equal(L.setRules(tab, [rule, ruleB]), true);
  const d = makeDisplay(tab), rc = R.ruleColors(tab, d.raw);
  assert.deepEqual([...rc.keys()].sort(), ['1,0', '4,1']); // A: hanya 12 (5, kosong, teks tidak); B: HASIL rumus A1*10 = 50
  assert.equal(rc.get('4,1').bg, '#BBF7D0');
  assert.ok(L.fitsLimit(sh));
});

test('perilaku: aturan eq teks dari kolom isian, scale, hapus satu aturan, batas MAX_RULES, hapus kolom membuang aturannya', () => {
  const { tab } = mk(['Lunas', 'lunas', 'Belum', 3]);
  assert.equal(L.setRules(tab, [{ id: '', c: tab.cols[0].id, op: 'eq', a: 'LUNAS', fg: '#16A34A' }]), true);
  assert.deepEqual([...R.ruleColors(tab, makeDisplay(tab).raw).keys()].sort(), ['0,0', '1,0']);
  const id = tab.rules[0].id; assert.ok(id);
  assert.equal(L.setRules(tab, tab.rules.filter((x) => x.id !== id)), true); assert.equal(tab.rules, undefined);
  const many = Array.from({ length: R.MAX_RULES + 3 }, () => ({ id: '', c: tab.cols[0].id, op: 'gt', a: 1, bg: '#FDE68A' }));
  L.setRules(tab, many); assert.equal(tab.rules.length, R.MAX_RULES);
  L.setRules(tab, [{ id: '', c: tab.cols[0].id, op: 'scale', lo: '#fecaca', hi: '#bbf7d0' }]);
  assert.equal(R.ruleColors(tab, makeDisplay(tab).raw).size, 1); // hanya angka 3
  assert.equal(R.ruleText(tab.rules[0], 'A'), 'Kolom A: skala warna');
});

test('simpan/muat: aturan ikut tersimpan lewat sheet dan bertahan lewat salinan JSON (cadangan)', () => {
  const { sh, tab } = mk([1, 2, 3]);
  L.setRules(tab, [{ id: '', c: tab.cols[0].id, op: 'between', a: 2, b: 1, bg: '#BFDBFE' }]);
  const back = JSON.parse(JSON.stringify(sh)); const clean = L.cleanSheet ? L.cleanSheet(back) : back;
  assert.deepEqual(clean.tabs[0].rules.map((r) => [r.op, r.a, r.b]), [['between', 1, 2]]);
  assert.equal(S.SCHEMA, 22);
});

test('Rev 146: CSS dialog ada, SCHEMA 14 tetap, versi 0.3.121, tes terdaftar, dependensi tetap', () => {
  const css = src('src/css/styles.css'); for (const k of ['.lz-rules .lz-rrow', '.lz-rules [hidden]{display:none!important}', '.lz-rules .lz-pc[aria-pressed=true]']) assert.ok(css.includes(k), k);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.ok(pk.scripts.test.includes('tests/rev146.test.mjs')); assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.doesNotMatch(src('src/js/lembar-alat.js'), /lembar-aturan/);
});
