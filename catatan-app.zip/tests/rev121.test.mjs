// Rev 121 / U7a-2c-3: audit lembar kerja di cadangan JSON/ZIP, pulihkan, Catatan Privat, Tempat sampah
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { emptyData, exportJSON, importJSON, normalize } from '../src/js/storage.js'; import { replaceData, sheetCount } from '../src/js/logic.js';
import * as L from '../src/js/lembar.js'; import { buildZip, utf8 } from '../src/js/zip.js'; import { readBackupFile, ZIP_JSON } from '../src/js/cadangan-gambar.js';
const src = (f) => readFileSync(new URL('../src/' + f, import.meta.url), 'utf8');
const mkData = () => {
  const d = emptyData(), sh = L.newSheet({ name: 'Anggaran' }), t = sh.tabs[0];
  L.setCell(t, t.rows[0].id, t.cols[0].id, { v: 'Total' }); L.setCell(t, t.rows[1].id, t.cols[2].id, { v: 12.5, s: { b: true, i: true, bg: '#FDE68A', fg: '#DC2626', ha: 'end' } });
  L.setColWidth(t, t.cols[0].id, 180); L.addTab(sh); L.renameTab(sh, sh.tabs[1].id, 'Gaji'); d.sheets[sh.id] = sh; return { d, sh };
};
test('BUG DITEMUKAN: replaceData menyalin sheets (dulu terlewat); cadangan lama tanpa sheets = {}', () => {
  const { d, sh } = mkData(), target = emptyData(); target.sheets = { lama: { id: 'lama' } };
  replaceData(target, normalize(JSON.parse(exportJSON(d)))); assert.deepEqual(Object.keys(target.sheets), [sh.id]); assert.deepEqual(target.sheets[sh.id], sh);
  const old = emptyData(); delete old.sheets; const t2 = emptyData(); t2.sheets = { x: 1 }; replaceData(t2, normalize(JSON.parse(JSON.stringify({ ...old, version: 10 })))); assert.deepEqual(t2.sheets, {});
  const t3 = emptyData(); replaceData(t3, { habits: [], tasks: [], notes: [], priv: [], trash: [], settings: {}, sheets: [1, 2] }); assert.deepEqual(t3.sheets, {}); // bentuk rusak
  assert.equal(sheetCount({ sheets: { a: 1, b: 2 } }), 2); assert.equal(sheetCount(null), 0); assert.equal(sheetCount({ sheets: [1] }), 0);
});
test('cadangan JSON: ekspor -> impor mempertahankan lembar kerja utuh (nilai, gaya, lebar kolom, tab)', () => {
  const { d, sh } = mkData(), r = importJSON(exportJSON(d)); assert.ok(r.ok); assert.deepEqual(r.data.sheets[sh.id], sh);
  const t = r.data.sheets[sh.id].tabs[0]; assert.equal(t.cols[0].w, 180); assert.deepEqual(L.cellAt(t, 1, 2), { v: 12.5, s: { b: true, i: true, bg: '#FDE68A', fg: '#DC2626', ha: 'end' } }); assert.equal(r.data.sheets[sh.id].tabs[1].name, 'Gaji');
});
test('cadangan ZIP: data.json di dalam ZIP membawa lembar kerja dan dibaca kembali', async () => {
  const { d, sh } = mkData(), zip = buildZip([{ name: ZIP_JSON, data: utf8.encode(exportJSON(d)) }]);
  const rb = await readBackupFile(new Blob([zip])); assert.equal(rb.kind, 'zip'); const r = importJSON(rb.text); assert.ok(r.ok); assert.deepEqual(r.data.sheets[sh.id], sh);
});
test('batas: lembar tepat di batas ukuran lolos pembersihan; lembar rusak/lewat batas dibuang tanpa menjatuhkan yang lain; maks 50', () => {
  const big = L.newSheet({ name: 'Besar' }), t = big.tabs[0]; L.addRows(t, 470);
  outer: for (let r = 0; r < t.rows.length; r++) for (let c = 0; c < 26; c++) { L.setCell(t, t.rows[r].id, t.cols[c].id, { v: 'x'.repeat(40) + r + c, s: { b: true } }); if (!L.fitsLimit(big)) { L.setCell(t, t.rows[r].id, t.cols[c].id, { v: null, s: { b: null } }); break outer; } }
  assert.ok(L.fitsLimit(big)); assert.ok(L.sheetBytes(big) > L.MAX_BYTES - 500); assert.ok(L.cleanSheet(JSON.parse(JSON.stringify(big))), 'lembar di batas tidak boleh hilang saat dimuat');
  const { d, sh } = mkData(); d.sheets[big.id] = big; d.sheets.bad = { id: 'bad', tabs: 'x' }; d.sheets.s999 = { id: 'zzzz', tabs: [] };
  const r = importJSON(exportJSON(d)); assert.deepEqual(Object.keys(r.data.sheets).sort(), [big.id, sh.id].sort(), 'yang rusak dibuang, yang sah tetap');
  const many = emptyData(); for (let i = 0; i < 60; i++) { const s = L.newSheet({ id: 's' + String(1000 + i), name: 'N' + i }); many.sheets[s.id] = s; }
  assert.equal(Object.keys(importJSON(exportJSON(many)).data.sheets).length, L.MAX_SHEETS);
});
test('Privat dan Sampah (keputusan): lembar kerja tidak bercampur dengan catatan privat/sampah; hapus lembar = permanen dengan konfirmasi', () => {
  const { d, sh } = mkData(); d.priv.push({ id: 'p1', title: 'rahasia', html: '<p>x</p>' }); const r = importJSON(exportJSON(d));
  assert.equal(r.data.priv.length, 1); assert.equal(r.data.trash.length, 0); assert.ok(!('sheets' in r.data.priv[0]));
  const st = src('js/settings.js'); const del = st.slice(st.indexOf('onDelete: (sh) =>'), st.indexOf('onDelete: (sh) =>') + 200);
  assert.match(del, /delete data\.sheets\[sh\.id\]/); assert.ok(!/trash\.push/.test(del)); assert.match(src('js/lembar-ui.js'), /dan semua isinya dihapus permanen\. Tidak bisa dikembalikan\./);
  assert.ok(!sh.priv);
});
test('kontrak kode: dialog Pulihkan menyebut jumlah lembar kerja (cadangan vs HP ini); replaceData menyalin sheets; versi 0.3.121', () => {
  const st = src('js/settings.js'); assert.ok(st.includes('sheetCount(r.data)') && st.includes('sheetCount(ctx.data)') && st.includes('${shText}'));
  assert.match(src('js/logic.js'), /target\.sheets = src\.sheets &&/);
  assert.match(readFileSync(new URL('../package.json', import.meta.url), 'utf8'), /"version": "0\.3\.121"/); assert.match(st, /Notes Kelimaa v0\.3\.121/);
});
