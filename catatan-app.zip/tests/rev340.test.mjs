// Rev 340 / PART I6: menu cepat `/` di editor catatan (tampilan; mesin = ketik-pemicu.js). Perintah memakai jalur Sisipkan/Langit yang sama.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
globalThis.document = { createElement: () => ({ setAttribute() {}, addEventListener() {}, append() {}, className: '' }), createTextNode: (t) => ({ nodeType: 3, data: t }) };
const { slashFor } = await import('../src/js/ketik-ui.js');
const IDS = ['bullet', 'numbered', 'todo', 'table', 'quote', 'date', 'mood', 'countdown', 'sheet'];
const has = (id) => IDS.includes(id);

test('slashFor: `/` sendiri menawarkan semua perintah yang dimiliki aplikasi (Judul tidak ikut)', () => {
  const r = slashFor('/', has);
  assert.ok(r); assert.equal(r.query, '');
  assert.deepEqual(r.items.map((c) => c.id), IDS);
});
test('slashFor: disaring saat mengetik (`/tab`), awalan kata dulu, spasi nbsp sebelum `/` diterima', () => {
  assert.deepEqual(slashFor('/tab', has).items.map((c) => c.id), ['table']);
  assert.deepEqual(slashFor('halo /tgl', has).items.map((c) => c.id), ['date']);
  assert.deepEqual(slashFor('halo\u00a0/tgl', has).items.map((c) => c.id), ['date'], 'nbsp dianggap spasi');
  assert.equal(slashFor('/judul', has), null, 'Judul tidak dimiliki aplikasi, jadi tidak ditawarkan');
});
test('slashFor: bukan pemicu = null (URL, pecahan, tanpa kecocokan, spasi sesudah perintah, bukan teks)', () => {
  for (const l of ['http://x', '1/2', 'a/b', '/tab ', '/zzzz', '/12', '', 'tanpa garis miring']) assert.equal(slashFor(l, has), null, JSON.stringify(l));
  assert.equal(slashFor(null, has), null); assert.equal(slashFor(7, has), null);
});
test('slashFor: tanpa fungsi has = semua perintah mesin (termasuk Judul); has menyaring', () => {
  assert.ok(slashFor('/judul'));
  assert.equal(slashFor('/', () => false), null);
});
test('sumber ketik-ui.js: kapsul tidak mencuri fokus, hapus `/perintah` lalu env.slash.run, IME boleh menyusun, dibersihkan saat destroy', () => {
  const k = read('src/js/ketik-ui.js');
  assert.match(k, /env\.slash\.run\(id\)/); assert.match(k, /execCommand\('delete'\)/);
  assert.match(k, /onpointerdown: stop, onmousedown: stop, onclick: \(\) => pick\(c\.id\)/);
  assert.match(k, /if \(composing && !isSl(?: && !isWk)?\) return null/ /* Rev 343: menu `[[` juga boleh tampil saat IME menyusun */, 'hanya menu `/` yang tampil saat IME menyusun');
  assert.match(k, /if \(e && e\.isComposing\) \{ check\(\); return; \}/);
  assert.match(k, /removeEventListener\('keydown', onKey\)[^]*?menu\.remove\(\)/);
  assert.match(k, /r\.query\.length \+ 1/, 'tepat `/` + perintah yang dihapus');
  assert.ok(!/import\s.*notes\.js/.test(k), 'modul tampilan tidak mengimpor notes.js');
});
test('sumber notes.js: perintah slash = jalur yang sudah ada; gerbang `/` murah; modul tetap malas; Catatan Privat tidak ikut', () => {
  const n = read('src/js/notes.js');
  assert.match(n, /const SLASH_IDS = \['bullet', 'numbered', 'todo', 'table', 'quote', 'date', 'mood', 'countdown', 'sheet'\]/);
  assert.match(n, /else runInsert\(id\);/); assert.match(n, /insertTodo\(ed, ed\.contains\(at\) \? at : ed\)/);
  assert.match(n, /pasangKetik\(\{ ed, flushHist, tags, slash(?:, remind)?(?:, wiki)? \}\)/ /* Rev 343: + wiki */);
  assert.match(n, /c === '\/' \? !\(sl\.anchorOffset < 2/);
  assert.ok(!/^import .*ketik-ui/m.test(n), 'ketik-ui.js tetap dimuat malas');
  assert.match(n, /if \(!isP\) \{ \/\/ Rev 337/, 'blok ketikan hanya di catatan biasa');
});
test('mesin: setiap id SLASH_COMMANDS yang ditawarkan aplikasi punya jalur di runInsert/slash.run', () => {
  const n = read('src/js/notes.js');
  for (const id of ['quote', 'table', 'date', 'mood', 'countdown', 'sheet']) assert.match(n, new RegExp("kind === '" + id + "'"), id);
  assert.match(n, /insertUnorderedList/); assert.match(n, /insertOrderedList/);
});
test('CSS: kapsul menu cepat ada, tanpa hex/rgba (aturan rev323/rev326) dan [hidden] menyembunyikan', () => {
  const c = read('src/css/styles.css');
  const i = c.indexOf('/* Rev 340 / I6'); assert.ok(i > 0);
  const blok = c.slice(i);
  assert.ok(!/#[0-9a-fA-F]{3,8}\b|rgba?\(/.test(blok));
  assert.match(blok, /\.kq-row\[hidden\]\{display:none\}/); assert.match(blok, /min-height:44px/);
});
