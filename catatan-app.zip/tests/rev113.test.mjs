// Rev 113 / U6e: audit bagian lipat (Undo/Ulangi, cadangan, Privat, Sampah, salin, mode Baca, pengingat baris centang di isi lipat).
// Perilaku nyata dicek di Chromium 360x800 saat revisi dibuat (skrip sementara, tidak ikut zip); tes Node ini mengunci perbaikan dan kontrak kode.
// Temuan utama: riwayat Urungkan/Ulangi menyimpan atribut sementara data-rem (lonceng baris), sehingga Ulangi tidak pernah jalan di catatan yang punya baris berpengingat.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHistory } from '../src/js/undo.js';
import { normalize, importJSON, exportJSON } from '../src/js/storage.js';
import { duplicateNote } from '../src/js/logic.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const notes = src('src/js/notes.js');

const FOLD = '<div class="fold" data-o="1"><div class="fh">J</div><div class="fb"><div class="todo" data-cid="abcd1234"><input type="checkbox"> susu</div><p>dua</p></div></div><p>luar</p>';
const REM = (at) => ({ abcd1234: { at, repeat: 'none', sticky: false } });
const strip = (h) => h.replace(/ data-rem="[^"]*"/g, '');

test('Rev 113: riwayat tanpa data-rem: Ulangi tetap hidup setelah Urungkan walau pengamat lonceng menambah data-rem sesudah render', () => {
  const orig = FOLD, moved = FOLD.replace('<p>dua</p>', '') + '<p>dua</p>';
  const withRem = (h) => h.replace('data-cid="abcd1234"', 'data-cid="abcd1234" data-rem="1"');
  const hist = createHistory({ html: strip(withRem(orig)) });
  assert.equal(hist.push({ html: strip(withRem(moved)) }), true);
  const st = hist.undo(); assert.equal(st.html, orig);
  hist.setTop({ html: strip(withRem(orig)) }); // applyHist: setTop dengan bentuk bersih
  // doRedo -> flushHist: isi editor (kini bergelar data-rem lagi) dinormalkan, sama dengan puncak, jadi TIDAK menutup jalur Ulangi
  assert.equal(hist.push({ html: strip(withRem(orig)) }), false);
  assert.equal(hist.canRedo(), true);
  assert.equal(hist.redo().html, moved);
});
test('Rev 113: kebalikannya (bug lama): tanpa normalisasi, data-rem membuat push menghapus jalur Ulangi', () => {
  const withRem = (h) => h.replace('data-cid="abcd1234"', 'data-cid="abcd1234" data-rem="1"');
  const hist = createHistory({ html: FOLD });
  hist.push({ html: FOLD + '<p>x</p>' }); hist.undo(); hist.setTop({ html: FOLD });
  assert.equal(hist.push({ html: withRem(FOLD) }), true); // dianggap ketikan baru
  assert.equal(hist.canRedo(), false);
});
test('Rev 113: notes.js memakai histHtml di tiga tempat (awal riwayat, flushHist, applyHist) dan tidak lagi memasukkan ed.innerHTML mentah ke riwayat', () => {
  assert.match(notes, /const histHtml = \(\) => ed\.innerHTML\.replace\(\/ data-rem="\[\^"\]\*"\/g, ''\);/);
  assert.match(notes, /createHistory\(\{ html: histHtml\(\), caret: null \}\)/);
  assert.match(notes, /hist\.push\(\{ html: histHtml\(\), caret: caretAt\(\) \}\)/);
  assert.match(notes, /hist\.setTop\(\{ html: histHtml\(\) \}\)/);
  assert.doesNotMatch(notes, /hist\.push\(\{ html: ed\.innerHTML/);
  assert.doesNotMatch(notes, /hist\.setTop\(\{ html: ed\.innerHTML/);
  assert.doesNotMatch(notes, /createHistory\(\{ html: ed\.innerHTML/);
});
test('Rev 113: cadangan (ekspor lalu impor) mempertahankan bagian lipat dan pengingat baris centang di dalam isi lipat', () => {
  const at = Date.now() + 86400000;
  const d = normalize({ notes: [{ id: 'n1', title: 'T', text: 't', html: FOLD, updated: 1, cbRem: REM(at) }] });
  const r = importJSON(exportJSON(d)); assert.equal(r.ok, true);
  const n = r.data.notes[0];
  assert.ok(n.html.includes('class="fold"') && n.html.includes('data-cid="abcd1234"'));
  assert.equal(n.cbRem.abcd1234.at, at);
});
test('Rev 113: pengingat ke cid yang sudah tidak ada di HTML dipangkas, dan cid di dalam .fb dianggap ada', () => {
  const at = Date.now() + 86400000;
  const keep = normalize({ notes: [{ id: 'a', html: FOLD, cbRem: REM(at) }] }).notes[0];
  assert.ok(keep.cbRem && keep.cbRem.abcd1234);
  const drop = normalize({ notes: [{ id: 'b', html: '<p>polos</p>', cbRem: REM(at) }] }).notes[0];
  assert.equal(drop.cbRem, undefined);
});
test('Rev 113: Catatan Privat tidak pernah menyimpan cbRem walau isinya bagian lipat berisi kotak centang', () => {
  const d = normalize({ priv: [{ id: 'p', html: FOLD, cbRem: REM(Date.now() + 1e8) }] });
  assert.equal(d.priv[0].cbRem, undefined); assert.ok(d.priv[0].html.includes('class="fold"'));
});
test('Rev 113: Tempat sampah menyimpan catatan berbagian lipat beserta cbRem (Pulihkan menjadwalkan ulang)', () => {
  const at = Date.now() + 86400000;
  const d = normalize({ trash: [{ kind: 'note', at: 1, item: { id: 'n1', html: FOLD, cbRem: REM(at) } }] });
  const it = d.trash[0].item; assert.equal(it.cbRem.abcd1234.at, at); assert.ok(it.html.includes('class="fold"'));
});
test('Rev 113: salinan catatan membawa bagian lipat tetapi TIDAK mewarisi pengingat (cbRem hanya milik asli)', () => {
  const c = duplicateNote({ id: 'n1', title: 'T', html: FOLD, cbRem: REM(Date.now() + 1e8) }, { id: 'n2', now: 5 });
  assert.ok(c.html.includes('class="fold"')); assert.equal(c.cbRem, undefined); assert.equal(c.title, 'Salinan T');
});
test('Rev 113: kontrak mode Baca/Privat tetap: bilah lipat disembunyikan di Baca, foldUi hanya di mode edit, lonceng mati di Privat', () => {
  assert.match(notes, /editorMode === 'edit' && node \? foldMoveContext\(node, ed\) : null/);
  assert.match(notes, /if \(isP \|\| !alive\) return; \/\/ Privat: tanpa lonceng/);
  assert.match(src('src/css/styles.css'), /\.fs\.ed-baca \.chipbar\{display:none!important\}/);
});
test('Rev 113: versi 0.3.121, SCHEMA 10, native dan dependensi tidak berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json'));
  assert.equal(pk.version, '0.3.121');
  assert.deepEqual(Object.keys(pk.dependencies).sort(), ['@capacitor/android', '@capacitor/core', '@capacitor/filesystem', '@capacitor/share']);
  assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.ok(pk.scripts.test.includes('node tests/rev113.test.mjs'));
});
