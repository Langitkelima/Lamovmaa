// Rev 358: format otomatis `- ` (strip + spasi) di awal baris = daftar bullet (gaya WhatsApp). Mesin = ketik-pemicu.js, tampilan = ketik-ui.js.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { detectTrigger, TRIGGER_KINDS } from '../src/js/ketik-pemicu.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
globalThis.document = { createElement: () => ({ setAttribute() {}, addEventListener() {}, append() {}, className: '' }), createTextNode: (t) => ({ nodeType: 3, data: t }) };
const { fmtFor } = await import('../src/js/ketik-ui.js');

test('detectTrigger: `- ` sebagai isi baris = bullet; jenis terdaftar', () => {
  const r = detectTrigger('- ', { ctx: 'note' });
  assert.deepEqual([r.kind, r.start, r.end, r.raw], ['bullet', 0, 2, '- ']);
  assert.ok(TRIGGER_KINDS.includes('bullet'));
  assert.equal(detectTrigger('- ', { ctx: 'note', only: ['numbered'] }), null, 'hormati daftar only');
});
test('detectTrigger: bukan pemicu bila ada teks lain, strip lain, atau konteks bukan catatan', () => {
  for (const s of ['-', '--', '-- ', 'a - ', 'a- ', '- a', '-  ', ' - ', '– ', '— ', '* ', '+ ', '-\n- ', '5 - ']) {
    const r = detectTrigger(s, { ctx: 'note' });
    assert.ok(!r || r.kind !== 'bullet', JSON.stringify(s));
  }
  assert.equal(detectTrigger('- ', { ctx: 'private' }), null); assert.equal(detectTrigger('- ', { ctx: 'cell' }), null);
});
test('pemicu lama tidak berubah: `[] ` dan `1. ` tetap, prioritas tidak bentrok', () => {
  assert.equal(detectTrigger('[] ', { ctx: 'note' }).kind, 'checkbox'); assert.equal(detectTrigger('1. ', { ctx: 'note' }).kind, 'numbered');
  assert.equal(detectTrigger('12-3=', { ctx: 'note' }).kind, 'calc'); assert.equal(detectTrigger('#kerja ', { ctx: 'note' }).kind, 'tag');
});
test('fmtFor: `- ` (spasi biasa dan nbsp) sebagai satu-satunya isi blok = bullet', () => {
  assert.equal(fmtFor('- ', '- '), 'bullet'); assert.equal(fmtFor('- ', '- '), 'bullet', 'nbsp dari papan ketik');
  for (const [l, b] of [['- ', '- teks'], ['a - ', 'a - '], ['-', '-'], ['- ', '- \nbaris lain'], ['-- ', '-- ']]) assert.equal(fmtFor(l, b), null, JSON.stringify([l, b]));
  assert.equal(fmtFor('[] ', '[] '), 'checkbox'); assert.equal(fmtFor('1. ', '1. '), 'numbered');
});
test('sumber ketik-ui.js: bullet memakai insertUnorderedList (terapkan, cadangan, Backspace) dan teks cadangan `-`', () => {
  const k = src('src/js/ketik-ui.js');
  assert.match(k, /execCommand\(f\.kind === 'bullet' \? 'insertUnorderedList' : 'insertOrderedList'\)/);
  assert.match(k, /execCommand\(l\.kind === 'bullet' \? 'insertUnorderedList' : 'insertOrderedList'\)/);
  assert.match(k, /f\.kind === 'bullet' \? '-\\u00a0' : '1\.\\u00a0'/); assert.match(k, /l\.kind === 'bullet' \? '-\\u00a0' : '1\.\\u00a0'/);
  assert.ok(!/import\(/.test(k), 'tanpa pemuat baru');
});
test('sumber notes.js: gerbang malas menerima `-` hanya di awal simpul teks; Privat tetap tanpa modul', () => {
  const n = src('src/js/notes.js');
  assert.ok(n.includes('/(\\[\\]|1\\.|^-)[ \\u00a0]$/.test(nd.data.slice(0, sl.anchorOffset))'));
  const i = n.indexOf('Rev 337 / I4 + Rev 338'); assert.match(n.slice(i - 40, i), /if \(!isP\)/);
});
test('panduan ketikan memuat contoh `- ` dan terkunci ke pemicu bullet', async () => {
  const { PANDUAN } = await import('../src/js/panduan-ketik.js');
  const p = PANDUAN.find((x) => x.kind === 'bullet'); assert.ok(p); assert.equal(p.ketik, '- ');
  assert.equal(detectTrigger(p.ketik, { ctx: 'note' }).kind, 'bullet');
});
test('versi 0.3.121 dan SCHEMA 22 tidak berubah; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA = 22/);
  assert.match(pk.scripts.test, /node tests\/rev358\.test\.mjs/);
});
