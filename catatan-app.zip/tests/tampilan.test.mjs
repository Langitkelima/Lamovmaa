// Tes Rev 24A: tampilan daftar catatan petak/baris (settings.notesView, SCHEMA 7).
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as S from '../src/js/storage.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const note = (id) => ({ id, title: 'J' + id, text: 't', html: '', col: '', pin: false, updated: 1 });

await t('SCHEMA 7: data v6 tanpa notesView dimigrasi, bawaan baris (sama dengan tampilan lama), catatan utuh', () => {
  const v6 = { version: 6, habits: [], tasks: [], notes: [note('a'), note('b')], priv: [note('p')], trash: [], settings: { days: [1], theme: 'dark' } };
  const d = S.normalize(v6);
  assert.equal(S.SCHEMA, 22);
  assert.equal(d.settings.notesView, 'list');
  assert.equal(d.notes.length, 2); assert.equal(d.priv.length, 1);
});
await t('emptyData: bawaan baris', () => assert.equal(S.emptyData().settings.notesView, 'list'));
await t('nilai petak dipertahankan; nilai aneh kembali ke baris', () => {
  const mk = (v) => S.normalize({ version: 7, settings: { notesView: v } }).settings.notesView;
  assert.equal(mk('grid'), 'grid'); assert.equal(mk('list'), 'list');
  for (const bad of ['xx', 5, null, {}, [], true, 'GRID']) assert.equal(mk(bad), 'list');
});
await t('petak bertahan lewat simpan/muat dan ekspor/impor cadangan', () => {
  const st = new Map(); const store = { getItem: (k) => st.get(k) ?? null, setItem: (k, v) => st.set(k, v) };
  const d = S.emptyData(); d.settings.notesView = 'grid'; d.notes = [note('a')];
  assert.equal(S.save(d, store).ok, true);
  assert.equal(S.load(store).settings.notesView, 'grid');
  const r = S.importJSON(S.exportJSON(d));
  assert.equal(r.ok, true);
});
await t('cadangan SCHEMA 6 lama tetap bisa dipulihkan', () => {
  const old = JSON.stringify({ version: 6, habits: [], tasks: [], notes: [note('x')], priv: [], trash: [], settings: { days: [1], theme: 'dark' } });
  const r = S.importJSON(old);
  assert.equal(r.ok, true);
});
await t('kode: pengalih ada di daftar Catatan dan Privat, menyebut mode tujuan, tersimpan lewat persist', () => {
  const s = src('../src/js/notes.js');
  assert.match(s, /notesView/); assert.match(s, /Tampilan petak/); assert.match(s, /Tampilan baris/);
  assert.match(s, /class: 'qrow'/); assert.match(s, /ctx\.persist\(\)/);
  assert.match(s, /'ngrid'/);
});
await t('CSS: mode petak dua kolom, kartu tetap utuh (pin/warna/label tidak disembunyikan)', () => {
  const c = src('../src/css/styles.css');
  assert.match(c, /\.ngrid\{display:grid;grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
  assert.doesNotMatch(c, /\.ngrid[^{]*\.(pinb|lbs|edt)[^{]*\{[^}]*display:none/);
});
await t('versi 0.3.2 sama di package.json dan layar Lainnya', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.match(src('../src/js/settings.js'), /Notes Kelimaa v0\.3\.121/);
});
console.log(n + ' tes lulus (tampilan)');
