// Rev 377 / PART AL1: native mode ALARM berdering (jembatan scheduleAlarm, mode di jadwal, setAlarmClock, AlarmRinger, AlarmActivity, Tunda/Matikan, izin + manifest).
// Tes ini memeriksa TEKS sumber Java dan manifest, ditambah kompilasi terhadap STUB Android lewat tools/cek_java_native.mjs bila kompiler Java ada.
// BUKAN bukti alarm berdering di Android nyata (hanya uji HP yang membuktikan).
import test from 'node:test'; import assert from 'node:assert/strict';
import { readFileSync, existsSync, mkdtempSync, mkdirSync, writeFileSync } from 'node:fs'; import { tmpdir } from 'node:os'; import { join } from 'node:path'; import { spawnSync } from 'node:child_process';
import * as N from '../scripts/apply-native.mjs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8'); const PKG = 'com.kelimaa.notes';
const balanced = (s, a, b) => (s.match(new RegExp('\\' + a, 'g')) || []).length === (s.match(new RegExp('\\' + b, 'g')) || []).length;

test('jembatan: scheduleAlarm + dua method izin ditambah; scheduleNotification 5 argumen TIDAK berubah', () => {
  const m = N.mainActivitySource(PKG);
  assert.ok(m.includes('public String scheduleNotification(String id, String title, String message, long delayMs, long repeatMs)'));
  assert.ok(m.includes('public String scheduleAlarm(String id, String title, String message, long delayMs, long repeatMs)') && m.includes('ReminderScheduler.schedule(MainActivity.this, id, title, message, delayMs, repeatMs, "alarm")'));
  assert.ok(m.includes('public boolean canUseFullScreenAlarm()') && m.includes('canUseFullScreenIntent()') && m.includes('SDK_INT < 34'));
  assert.ok(m.includes('public void openFullScreenAlarmSettings()') && m.includes('android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT'));
  assert.equal((m.match(/public String scheduleNotification\(/g) || []).length, 1, 'tidak ada overload JavascriptInterface (Android tidak andal memilih overload)');
});
test('penjadwal: mode disimpan, overload lama = notif, alarm pakai setAlarmClock, Tunda memakai id snz: satu kali jalan', () => {
  const a = N.reminderSchedulerSource(PKG);
  assert.ok(a.includes('long delay,long repeat) throws Exception { return schedule(c,id,title,message,delay,repeat,"notif"); }'));
  assert.ok(a.includes('x.put("mode","alarm".equals(mode)?"alarm":"notif")') && a.includes('i.putExtra("mode",x.optString("mode","notif"))'));
  assert.ok(a.includes('am.setAlarmClock(new AlarmManager.AlarmClockInfo(at,show),pi)') && a.includes('jatuh ke alarm biasa'));
  assert.ok(a.includes('setExactAndAllowWhileIdle') && a.includes('setAndAllowWhileIdle') && a.includes('cancelAll(Context c)'), 'jalur notifikasi lama utuh');
  assert.ok(a.includes('static void snooze(Context c,String id,String title,String message,int minutes)') && a.includes('"snz:"+base') && a.includes('0L,"alarm"'));
});
test('penerima: mode alarm -> AlarmRinger.ring lalu fired; jalur notifikasi biasa utuh', () => {
  const r = N.reminderReceiverSource(PKG);
  assert.ok(r.includes('if("alarm".equals(i.getStringExtra("mode"))) { AlarmRinger.ring(c,id,title,message); ReminderScheduler.fired(c,id,repeat); return; }'));
  assert.ok(r.indexOf('AlarmRinger.ring') < r.indexOf('NotificationChannel(channel,"Pengingat"') && r.includes('kelimaa_reminders') && r.includes('IMPORTANCE_DEFAULT'));
});
test('AlarmRinger: saluran Alarm (HIGH, nada alarm, getar) + jejak (LOW, diam); bunyi berulang; layar penuh; Tunda 10; batas 2 menit; TANPA deleteIntent', () => {
  const g = N.alarmRingerSource(PKG);
  assert.ok(g.includes('CH_ALARM="kelimaa_alarm"') && g.includes('CH_TRACE="kelimaa_alarm_jejak"') && g.includes('IMPORTANCE_HIGH') && g.includes('IMPORTANCE_LOW'));
  assert.ok(g.includes('TYPE_ALARM') && g.includes('USAGE_ALARM') && g.includes('setVibrationPattern') && g.includes('STREAM_ALARM'));
  assert.ok(g.includes('FLAG_INSISTENT') && g.includes('setFullScreenIntent(scr,true)') && g.includes('CATEGORY_ALARM'));
  assert.ok(g.includes('SNOOZE_MIN=10') && g.includes('RING_MS=120000L') && g.includes('setTimeoutAfter(RING_MS)'));
  assert.ok(g.includes('"Tunda "+snoozeMin(c)+" mnt"') && g.includes('"Matikan"') && g.includes('ACT_SNOOZE') && g.includes('ACT_STOP'));
  assert.ok(!g.includes('setDeleteIntent'), 'DISENGAJA: batas waktu bisa memicu deleteIntent dan menghapus jejak');
  assert.ok(g.includes('nm.notify(traceId(id),tb.build()); nm.notify(ringId(id),n)') && g.includes('POST_NOTIFICATIONS'));
  assert.ok(g.includes('static void stop(') && g.includes('nm.cancel(ringId(id)); nm.cancel(traceId(id))') && g.includes('ReminderScheduler.snooze(c,id,title,message,snoozeMin(c))'));
});
test('AlarmActivity + AlarmActionReceiver: di atas layar kunci, dua tombol, aksi Tunda/Matikan', () => {
  const v = N.alarmActivitySource(PKG), x = N.alarmActionReceiverSource(PKG);
  assert.ok(v.includes('setShowWhenLocked(true)') && v.includes('setTurnScreenOn(true)') && v.includes('FLAG_SHOW_WHEN_LOCKED') && v.includes('FLAG_KEEP_SCREEN_ON'));
  assert.ok(v.includes('"Tunda "+AlarmRinger.snoozeMin(this)+" menit"') && v.includes('"Matikan"') && v.includes('AlarmRinger.snooze(self,id,title,message)') && v.includes('AlarmRinger.stop(self,id)'));
  assert.ok(x.includes('AlarmRinger.ACT_SNOOZE.equals(i.getAction())') && x.includes('AlarmRinger.stop(c,id)'));
});
test('semua sumber Java: kurung kurawal, siku, dan biasa seimbang; paket benar', () => {
  for (const [n, f] of Object.entries({ ReminderScheduler: N.reminderSchedulerSource, ReminderReceiver: N.reminderReceiverSource, ReminderBootReceiver: N.reminderBootReceiverSource, AlarmRinger: N.alarmRingerSource, AlarmActionReceiver: N.alarmActionReceiverSource, AlarmActivity: N.alarmActivitySource })) {
    const s = f(PKG); assert.ok(s.startsWith('package ' + PKG + ';'), n); assert.ok(balanced(s, '{', '}') && balanced(s, '(', ')'), n);
    assert.ok(!s.includes('${') && !s.includes('`'), n + ': sisa templat JS');
  }
});
test('manifest: izin layar penuh + getar, AlarmActivity (di atas layar kunci) dan AlarmActionReceiver; idempoten; komponen lama utuh', () => {
  const m = '<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="x"><activity android:name=".MainActivity" /></application></manifest>';
  const a = N.ensureReminderManifest(m), b = N.ensureReminderManifest(a); assert.equal(a, b);
  for (const p of ['POST_NOTIFICATIONS', 'RECEIVE_BOOT_COMPLETED', 'SCHEDULE_EXACT_ALARM', 'USE_FULL_SCREEN_INTENT', 'VIBRATE']) assert.equal((a.match(new RegExp('android.permission.' + p + '"', 'g')) || []).length, 1, p);
  assert.ok(a.includes('.AlarmActivity') && a.includes('android:showWhenLocked="true"') && a.includes('android:turnScreenOn="true"') && a.includes('android:exported="false"') && a.includes('.AlarmActionReceiver'));
  assert.ok(a.includes('.ReminderReceiver') && a.includes('.ReminderBootReceiver') && a.includes('BOOT_COMPLETED'));
  // manifest dari build yang sudah punya komponen lama tetap mendapat komponen alarm
  const lama = '<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application><receiver android:name=".ReminderReceiver" /></application></manifest>';
  assert.ok(N.ensureReminderManifest(lama).includes('.AlarmActivity'));
});
test('applyNative menulis tiga berkas Java baru (proyek Android tiruan)', () => {
  const d = mkdtempSync(join(tmpdir(), 'an377-')), j = join(d, 'app/src/main/java/com/kelimaa/notes'); mkdirSync(j, { recursive: true });
  writeFileSync(join(j, 'MainActivity.java'), 'package com.kelimaa.notes;\npublic class MainActivity {}\n'); writeFileSync(join(d, 'app/src/main/AndroidManifest.xml'), '<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="x"></application></manifest>');
  const log = console.log; console.log = () => {}; let r; try { r = N.applyNative(d); } finally { console.log = log; }
  assert.equal(r.reminders, true);
  for (const f of ['ReminderScheduler', 'ReminderReceiver', 'ReminderBootReceiver', 'AlarmRinger', 'AlarmActionReceiver', 'AlarmActivity']) assert.ok(existsSync(join(j, f + '.java')), f);
  assert.ok(readFileSync(join(d, 'app/src/main/AndroidManifest.xml'), 'utf8').includes('.AlarmActivity'));
});
test('pemeriksa Java: kompilasi terhadap stub Android lulus (dilewati bila kompiler Java tidak ada)', (t) => {
  const mod = spawnSync('java', ['--list-modules'], { encoding: 'utf8' });
  if (mod.status !== 0 || !/jdk\.compiler/.test(mod.stdout)) { t.skip('jdk.compiler tidak tersedia'); return; }
  const r = spawnSync('node', ['tools/cek_java_native.mjs'], { cwd: new URL('..', import.meta.url).pathname, encoding: 'utf8' });
  assert.equal(r.status, 0, r.stdout + r.stderr); assert.match(r.stdout, /dikompilasi terhadap stub Android/);
});
test('tanpa perubahan data/JS: SCHEMA 22, versi 0.3.121; JS belum memakai scheduleAlarm (itu AL2); Worker tidak disentuh; dokumen Rev 377', () => {
  assert.ok(/SCHEMA = 22/.test(src('src/js/storage.js'))); assert.ok(/"version": "0\.3\.121"/.test(src('package.json')));
  assert.ok(src('package.json').includes('tests/rev377.test.mjs'));
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) { const d = src(f); assert.ok(d.includes('**Rev 377 / v0.3.121'), f); }
  assert.ok(src('PROMPT_SERAH_TERIMA.md').includes('**38.9 STATUS (Rev 377)'));
});
