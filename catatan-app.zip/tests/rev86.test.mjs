import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const notes = read('../src/js/notes.js');
const css = read('../src/css/styles.css');

test('Rev 86: kartu hitung mundur punya status lokal dan akses keyboard', () => {
  assert.match(notes, /data-kb-state', days === 0 \? 'today' : days < 0 \? 'past' : 'upcoming'/);
  assert.match(notes, /setAttribute\('role', 'button'\)/);
  assert.match(notes, /setAttribute\('tabindex', '0'\)/);
  assert.match(notes, /\['Enter', ' '\]\.includes\(e\.key\)/);
});

test('Rev 86: dialog menyediakan pratinjau langsung dari data input yang tervalidasi', () => {
  assert.match(notes, /cd-live-preview/);
  assert.match(notes, /refreshPreview\(\)/);
  assert.match(notes, /cleanCountdownTitle\(titleInput\.value\)/);
  assert.match(notes, /isValidDateISO\(dateInput\.value\)/);
});

test('Rev 86: kontrol waktu disembunyikan saat nonaktif dan muncul saat dipilih', () => {
  assert.match(notes, /class: 'cd-form-row cd-time-row', hidden: !currentTime/);
  assert.match(notes, /timeRow\.hidden = !withTime\.checked/);
  assert.match(css, /\.cd-time-row\[hidden\]\{display:none!important\}/);
});

test('Rev 86: status hari-H dan lewat punya pembeda visual, fokus terlihat', () => {
  assert.match(css, /data-kb-state="today"/);
  assert.match(css, /data-kb-state="past"/);
  assert.match(css, /\.kb-countdown-block:focus-visible/);
});
