// Rev 382 / PART AL3b-4: Two Pockets 4B = sakelar "Alarm berdering" di panel Atur jadwal + chip ringkasan alarm. Tes Node: teks sumber + mesin.
import test from 'node:test'; import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { cleanCfg, isDefaultCfg } from '../src/js/twopockets.js';
import { planAlarms, setItemCfg } from '../src/js/tp-alarm.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('settings.js: sakelar Alarm berdering di panel Atur jadwal, simpan lewat setItemCfg, dialog izin dimuat MALAS', () => {
  const s = src('src/js/settings.js');
  assert.ok(!/^import .* from '\.\/alarm-ui\.js'/m.test(s)); assert.equal((s.match(/import\('\.\/alarm-ui\.js'\)/g) || []).length, 1);
  assert.ok(s.includes("let mode = cur.mode === 'alarm' ? 'alarm' : 'notif'") && s.includes("'Alarm berdering'") && s.includes('almSw, lateSw'));
  assert.ok(s.includes("mode: mode === 'alarm' ? 'alarm' : undefined"));
  assert.ok(s.includes('A.alarmUnsupported()') && s.includes('A.askFullScreen()'));
});
test('settings.js: chip ringkasan memakai ikon jam alarm hanya bila mode alarm', () => {
  const s = src('src/js/settings.js');
  assert.ok(s.includes("if (c.mode === 'alarm') sum.append(h('span', { class: 'tpchip alm' }, ico(PATH.alarm), 'Alarm berdering'))"));
});
test('mesin: mode alarm bertahan lewat cleanCfg/isDefaultCfg/setItemCfg dan sampai ke rencana alarm', () => {
  assert.equal(cleanCfg({ on: true, mode: 'alarm' }).mode, 'alarm');
  assert.ok(!('mode' in cleanCfg({ on: true, mode: 'notif' })) && !('mode' in cleanCfg({ on: true })));
  assert.equal(isDefaultCfg(cleanCfg({ mode: 'alarm' })), false); assert.equal(isDefaultCfg(cleanCfg({})), true);
  const mem = {}; const store = { getItem: (k) => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: (k) => { delete mem[k]; } };
  assert.ok(setItemCfg('sv1', { on: true, hour: 8, min: 0, before: [0], late: true, mode: 'alarm' }, { store }).ok);
  assert.match(mem.kelimaa_twopockets_alarmcfg, /"mode":"alarm"/);
  assert.ok(setItemCfg('sv1', { on: true, hour: 8, min: 0, before: [0], late: true, mode: undefined }, { store }).ok);
  assert.ok(!mem.kelimaa_twopockets_alarmcfg || !/alarm"/.test(mem.kelimaa_twopockets_alarmcfg.replace(/kelimaa|alarmcfg/g, '')) || !/"mode"/.test(mem.kelimaa_twopockets_alarmcfg), 'mode dibuang saat sakelar dimatikan');
  const now = Date.UTC(2026, 10, 21, 0, 0, 0); const d = new Date(now + 5 * 86400000).toISOString().slice(0, 10);
  const plan = planAlarms([{ id: 'sv1', name: 'Servis', status: 'segera', nextDue: d, dueDate: d }], now, { sv1: cleanCfg({ on: true, before: [0, 3], mode: 'alarm' }) });
  assert.ok(plan.length > 0 && plan.every((p) => p.mode === 'alarm'));
});
test('CSS: chip alarm Two Pockets memakai variabel tema; kurung seimbang', () => {
  const css = src('src/css/styles.css'); const b = css.slice(css.indexOf('Rev 382 / AL3b-4'));
  for (const k of ['.tpchip.alm{', '.tpchip.alm svg{', '.tpopt.tpalm{']) assert.ok(b.includes(k), k);
  assert.ok(!/#[0-9a-fA-F]{6}/.test(b)); let d = 0; for (const ch of css) { if (ch === '{') d++; if (ch === '}') d--; } assert.equal(d, 0);
});
test('tanpa perubahan SCHEMA/versi/native; tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(src('src/js/storage.js'), /SCHEMA\s*=\s*22/); assert.ok(pk.scripts.test.includes('tests/rev382.test.mjs'));
});
