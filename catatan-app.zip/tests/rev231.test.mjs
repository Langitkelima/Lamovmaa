// Rev 231 / Tahap 6a: Worker aksi `research` (Gemini native + google_search). Semua tes memakai fetch PALSU; bentuk jawaban = bentuk dari dokumentasi resmi (groundingMetadata), BUKAN bukti dari server nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const T = W._t, src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const kv = () => { const m = new Map(); return { m, get: async (k) => (m.has(k) ? m.get(k) : null), put: async (k, v) => { m.set(k, v); } }; };
const GK = 'gm-FAKE-0123456789-tes', SK = 'sk-FAKE-0123456789-tes';
const env0 = (x = {}) => ({ PASS_RAMA: 'rama-secret-12', KV: kv(), GEMINI_KEY: GK, ...x });
const NOW = Date.UTC(2026, 10, 12, 5, 0, 0);
const post = (b) => new Request('https://w.example/', { method: 'POST', body: JSON.stringify(b) });
const req = (o = {}) => ({ key: 'rama-secret-12', action: 'research', messages: [{ role: 'user', content: 'Siapa juara Euro 2024?' }], ...o });
const okJson = (o) => ({ ok: true, status: 200, json: async () => o });
const bad = (status, o) => ({ ok: false, status, json: async () => o });
const GOOD = { candidates: [{ content: { role: 'model', parts: [{ text: 'Spanyol juara Euro 2024.' }] }, finishReason: 'STOP', groundingMetadata: { webSearchQueries: ['UEFA Euro 2024 winner', 'who won euro 2024'], groundingChunks: [{ web: { uri: 'https://vertexaisearch.cloud.google.com/grounding-api-redirect/AAA', title: 'uefa.com' } }, { web: { uri: 'https://vertexaisearch.cloud.google.com/grounding-api-redirect/BBB', title: 'aljazeera.com' } }, { web: { uri: 'https://vertexaisearch.cloud.google.com/grounding-api-redirect/AAA', title: 'dobel' } }] } }], usageMetadata: { promptTokenCount: 9, candidatesTokenCount: 6 } };
async function run(env, b, fn = () => okJson(GOOD)) { const calls = []; const orig = globalThis.fetch; globalThis.fetch = async (url, init) => { calls.push({ url, init }); return fn(url, init, calls.length); }; try { const r = await T.handle(post(b), env, NOW); const j = await r.json(); return { calls, status: r.status, j, raw: JSON.stringify(j) }; } finally { globalThis.fetch = orig; } }

test('research: jawaban + sumber unik + kueri; grounded true; kunci/passcode tak bocor', async () => {
  const r = await run(env0(), req()); assert.equal(r.status, 200); assert.equal(r.j.ok, true); assert.equal(r.j.text, 'Spanyol juara Euro 2024.'); assert.equal(r.j.grounded, true);
  assert.deepEqual(r.j.sources.map((x) => x.title), ['uefa.com', 'aljazeera.com']); assert.deepEqual(r.j.queries, ['UEFA Euro 2024 winner', 'who won euro 2024']);
  assert.equal(r.j.provider, 'gemini'); assert.equal(r.j.model, 'gemini-3.5-flash'); assert.deepEqual(r.j.usage, { in: 9, out: 6 }); assert.equal(r.j.used, 1);
  assert.ok(!r.raw.includes(GK) && !r.raw.includes('rama-secret-12'));
});
test('research: permintaan ke endpoint NATIVE dengan google_search dan header x-goog-api-key (bukan Bearer, bukan /openai/)', async () => {
  const r = await run(env0(), req()), c = r.calls[0], b = JSON.parse(c.init.body);
  assert.equal(c.url, 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent'); assert.equal(c.init.headers['x-goog-api-key'], GK); assert.equal(c.init.headers.Authorization, undefined);
  assert.deepEqual(b.tools, [{ google_search: {} }]); assert.deepEqual(b.contents, [{ role: 'user', parts: [{ text: 'Siapa juara Euro 2024?' }] }]); assert.ok(b.systemInstruction.parts[0].text.includes('jangan mengarang'));
  assert.ok(!c.url.includes('/openai/'));
});
test('research: riwayat assistant dipetakan ke role model; model dari aplikasi / MODEL_GEMINI dipakai dan divalidasi', async () => {
  const msgs = [{ role: 'user', content: 'a' }, { role: 'assistant', content: 'b' }, { role: 'user', content: 'c' }];
  const r = await run(env0({ MODEL_GEMINI: 'gemini-3.5-flash-lite' }), req({ messages: msgs })); assert.deepEqual(JSON.parse(r.calls[0].init.body).contents.map((x) => x.role), ['user', 'model', 'user']); assert.ok(r.calls[0].url.includes('gemini-3.5-flash-lite:'));
  const r2 = await run(env0(), req({ model: 'gemini-3.6-flash' })); assert.ok(r2.calls[0].url.includes('gemini-3.6-flash:'));
  const r3 = await run(env0(), req({ model: '../x?y' })); assert.equal(r3.status, 400); assert.equal(r3.calls.length, 0);
});
test('research: jawaban tanpa sumber = grounded false (aplikasi memberi label belum terverifikasi); sumber non-https dibuang', async () => {
  const r = await run(env0(), req(), () => okJson({ candidates: [{ content: { parts: [{ text: 'Mungkin begitu.' }] }, groundingMetadata: { groundingChunks: [{ web: { uri: 'http://x.example/a', title: 't' } }, { web: { uri: 'javascript:alert(1)', title: 'j' } }, { nope: 1 }] } }] }));
  assert.equal(r.j.ok, true); assert.equal(r.j.grounded, false); assert.deepEqual(r.j.sources, []); assert.deepEqual(r.j.queries, []);
  const r2 = await run(env0(), req(), () => okJson({ candidates: [{ content: { parts: [{ text: 'tanpa metadata' }] } }] })); assert.equal(r2.j.grounded, false);
});
test('parseResearch: bagian thought dilewati, maks. 10 sumber / 5 kueri, judul dibersihkan', () => {
  const chunks = Array.from({ length: 14 }, (_, i) => ({ web: { uri: 'https://s.example/' + i, title: i ? 'T' + i : 'A\nB' } }));
  const p = T.parseResearch({ candidates: [{ content: { parts: [{ text: 'rahasia', thought: true }, { text: 'jawab' }] }, groundingMetadata: { groundingChunks: chunks, webSearchQueries: ['a', 'b', 'c', 'd', 'e', 'f', ' '] } }] });
  assert.equal(p.text, 'jawab'); assert.equal(p.sources.length, 10); assert.equal(p.sources[0].title, 'A B'); assert.equal(p.queries.length, 5);
  for (const x of [null, undefined, 5, 'x', {}, [], { candidates: [] }]) { const q = T.parseResearch(x); assert.equal(q.text, ''); assert.deepEqual(q.sources, []); }
});
test('research: tanpa GEMINI_KEY = 503 jelas dan tidak memanggil jaringan; kunci jalur lain TIDAK dipakai', async () => {
  const r = await run(env0({ GEMINI_KEY: undefined, SAKELAR_KEY: SK }), req()); assert.equal(r.status, 503); assert.match(r.j.error, /GEMINI_KEY/); assert.equal(r.calls.length, 0); assert.ok(!r.raw.includes(SK));
});
test('research: pesan tidak sah = 400; passcode salah = 401; tanpa KV (batas) = 503; batas harian = 429; tanpa batas jalan tanpa KV', async () => {
  assert.equal((await run(env0(), req({ messages: [] }))).status, 400); assert.equal((await run(env0(), req({ key: 'salah-salah-1' }))).status, 401);
  const nk = await run(env0({ KV: undefined }), req()); assert.equal(nk.status, 503); assert.equal(nk.calls.length, 0);
  const e = env0(); e.KV.m.set('use:rama:' + T.dayKey(NOW), '5'); const lim = await run(e, req({ limit: 5 })); assert.equal(lim.status, 429); assert.equal(lim.calls.length, 0);
  const free = await run(env0({ KV: undefined }), req({ limit: 0 })); assert.equal(free.status, 200);
});
test('research: galat sementara dicoba ulang lalu model cadangan; galat 400/403/429 diterjemahkan tanpa membocorkan kunci', async () => {
  let n = 0; const r = await run(env0({ RETRY_MS: [1] }), req(), () => (++n < 3 ? bad(503, { error: { message: 'overloaded' } }) : okJson(GOOD)));
  assert.equal(r.status, 200); assert.equal(r.calls.length, 3); assert.ok(r.calls[2].url.includes('gemini-3.5-flash-lite:')); assert.equal(r.j.fallbackFrom, 'gemini-3.5-flash');
  const f = await run(env0(), req(), () => bad(403, { error: { message: 'key ' + GK } })); assert.equal(f.status, 502); assert.match(f.j.error, /GEMINI_KEY/); assert.ok(!f.raw.includes(GK));
  const t = await run(env0(), req(), () => bad(429, { error: { message: 'quota' } })); assert.equal(t.status, 503);
  const em = await run(env0(), req(), () => okJson({ candidates: [{ content: { parts: [] }, finishReason: 'SAFETY' }] })); assert.equal(em.status, 502); assert.match(em.j.error, /SAFETY/);
});
test('chat tetap utuh: tidak memakai endpoint native dan tidak mengirim alat pencarian', async () => {
  const calls = []; const orig = globalThis.fetch; globalThis.fetch = async (url, init) => { calls.push({ url, init }); return okJson({ choices: [{ message: { content: 'Baik!' }, finish_reason: 'stop' }], usage: {} }); };
  try { const r = await T.handle(post({ key: 'rama-secret-12', action: 'chat', task: 'chat.general', messages: [{ role: 'user', content: 'Halo' }] }), env0(), NOW); assert.equal(r.status, 200); } finally { globalThis.fetch = orig; }
  assert.ok(calls[0].url.endsWith('/chat/completions')); assert.ok(!calls[0].init.body.includes('google_search'));
});
test('worker.mjs: sumber verifikasi dicatat, riset hanya Gemini, tes terdaftar; berkas worker di zip = di backend', () => {
  const w = src('backend/cloudflare/worker.mjs'); assert.match(w, /Rev 231/); assert.match(w, /12 Nov 2026/); assert.match(w, /BELUM dibuktikan dengan server nyata/); assert.doesNotMatch(w, /AIza|sk-[A-Za-z0-9]{12}/);
  assert.match(JSON.parse(src('package.json')).scripts.test, /node tests\/rev231\.test\.mjs/);
});
