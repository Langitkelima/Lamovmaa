// Rev 393 / PART SM1: pratinjau varian pemilih mode alarm per sub-tugas, DOKUMEN SAJA. Kode aplikasi tidak berubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('banner Rev 393 paling atas (di atas Rev 392), PART SM1, VARIAN A/B/C, BELUM ADA KODE, menunggu pilihan', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) {
    const d = rd(f); assert.ok(/^\*\*Rev (?:39\d|4[0-3]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 393 /') < d.indexOf('**Rev 392 /'), f);
    const b = d.slice(d.indexOf('**Rev 393 /'), d.indexOf('**Rev 392 /')); for (const k of ['PART SM1', 'VARIAN A', 'VARIAN B', 'VARIAN C', 'BELUM ADA KODE', 'BERFUNGSI-BELUM-DIUJI', 'MENUNGGU PILIHAN']) assert.ok(b.includes(k), f + ' ' + k);
  }
  const d = rd('PROMPT_SERAH_TERIMA.md'); assert.ok(d.indexOf('**38.18 STATUS (Rev 393)') > d.indexOf('**38.17 CHECKPOINT PART SM'));
});
test('kode TIDAK berubah: SCHEMA 22, versi 0.3.121, main.js masih satu rmode, tidak ada penanda Rev 393 di src/ (Rev 394 mengubah perilaku, lihat rev394)', () => {
  assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/); assert.equal(JSON.parse(rd('package.json')).version, '0.3.121');
  assert.ok(rd('src/js/main.js').includes('let rmode ='));
  for (const f of fs.readdirSync(new URL('../src/js/', import.meta.url))) if (f.endsWith('.js')) assert.ok(!rd('src/js/' + f).includes('Rev 393'), f);
});
test('tes terdaftar (rantai && node) sesudah rev392; README < 12000', () => {
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.includes('&& node tests/rev393.test.mjs') && t.indexOf('rev392.test.mjs') < t.indexOf('rev393.test.mjs')); assert.ok(rd('README.md').length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */);
});
