// Rev 235 / Tahap 7b: tampilan Project Studio (daftar, buat, detail, tautkan, lepas, hapus + Urungkan). DOM tiruan kecil; tanpa peramban.
import test from 'node:test'; import assert from 'node:assert/strict'; import { readFileSync } from 'node:fs';
import { staticGraph } from '../scripts/preload.mjs';
class N { constructor(t) { this.nodeType = t; this.kids = []; this.parent = null; } append(...k) { for (const c of k) { c.parent = this; this.kids.push(c); } } }
class El extends N {
  constructor(tag) { super(1); this.tag = tag; this.attrs = {}; this.handlers = {}; this.className = ''; this.value = ''; const self = this; const set = new Set(); this.classList = { toggle(c, on) { if (on) set.add(c); else set.delete(c); self.className = [...set].join(' '); } }; }
  setAttribute(k, v) { this.attrs[k] = v; } addEventListener(e, f) { (this.handlers[e] = this.handlers[e] || []).push(f); }
  remove() { if (this.parent) this.parent.kids = this.parent.kids.filter((x) => x !== this); } focus() {}
  set textContent(v) { this.kids = [new T(v)]; }
}
class T extends N { constructor(t) { super(3); this.text = t; } }
globalThis.document = { createElement: (t) => new El(t), createTextNode: (t) => new T(t), createElementNS: (ns, t) => new El(t), querySelector: () => null, body: new El('body') };
globalThis.setTimeout = (f) => 0;
const { viewProyek } = await import('../src/js/proyek-ui.js');
const S = await import('../src/js/storage.js');
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const txt = (e) => (e.nodeType === 3 ? e.text : e.kids.map(txt).join(''));
const all = (e, out = []) => { out.push(e); if (e.kids) e.kids.forEach((k) => all(k, out)); return out; };
const flat = (v) => [v].flat(Infinity);
const find = (v, pred) => flat(v).flatMap((r) => all(r)).find((e) => e.nodeType === 1 && pred(e));
const btn = (v, label) => find(v, (e) => e.tag === 'button' && txt(e) === label);
const click = (e) => { assert.ok(e, 'tombol tidak ditemukan'); (e.handlers.click || []).forEach((f) => f({ preventDefault() {} })); };
const overlays = () => document.body.kids.filter((o) => /dlgov/.test(o.className));
const mk = () => {
  const data = S.emptyData(); data.tasks = [{ id: 't1', title: 'CAT DINDING', done: true, scope: 'hari' }, { id: 't2', title: 'BELI KERAN', done: false, scope: 'minggu' }];
  data.notes = [{ id: 'n1', title: 'Daftar bahan', html: '' }, { id: 'n2', title: '', html: '' }]; data.priv = [{ id: 'pv', title: 'RAHASIA', html: '' }];
  const ctx = { data, ui: { moreView: 'proyek', projectId: '' }, persist: () => { ctx.saved++; }, render: () => { ctx.renders++; }, saved: 0, renders: 0 };
  return ctx;
};
const reset = () => { document.body.kids = []; };

test('daftar kosong: pesan kosong, tombol buat, filter 3 status; buat proyek lewat dialog', () => {
  reset(); const ctx = mk(); let v = viewProyek(ctx);
  assert.match(txt(flat(v)[0]), /Belum ada proyek\./); assert.ok(btn(v, '+ Proyek baru')); assert.ok(btn(v, 'Aktif 0') && btn(v, 'Selesai 0') && btn(v, 'Arsip 0'));
  click(btn(v, '+ Proyek baru')); const ov = overlays()[0]; assert.ok(ov, 'dialog muncul');
  click(btn(ov, 'Buat')); assert.equal(ctx.data.projects.length, 0); // nama kosong ditolak
  const inp = find(ov, (e) => e.tag === 'input'); inp.value = '  Renovasi dapur ';
  click(btn(ov, 'Buat')); assert.equal(ctx.data.projects.length, 1); assert.equal(ctx.data.projects[0].name, 'RENOVASI DAPUR');
  assert.equal(ctx.ui.projectId, ctx.data.projects[0].id); assert.ok(ctx.saved >= 1 && ctx.renders >= 1); assert.equal(overlays().length, 0, 'dialog tertutup');
  v = viewProyek(ctx); assert.match(txt(flat(v)[0]), /RENOVASI DAPUR|Tugas \(0\)/);
});
test('detail: tautkan tugas lewat pemilih; kemajuan dihitung; Catatan Privat tidak pernah jadi pilihan', () => {
  reset(); const ctx = mk(); ctx.data.projects = [{ id: 'p1', name: 'Proyek', desc: '', status: 'aktif', at: 1, tasks: [], notes: [] }]; ctx.ui.projectId = 'p1';
  let v = viewProyek(ctx); assert.match(txt(flat(v)[0]), /Tugas \(0\)/);
  click(btn(v, '+ Tautkan tugas')); let ov = overlays()[0]; const opts = all(ov).filter((e) => e.tag === 'button' && /pjo/.test(e.className));
  assert.equal(opts.length, 2); click(opts[0]); click(opts[1]); const ok = btn(ov, 'Tautkan 2'); assert.ok(ok); click(ok);
  assert.deepEqual(ctx.data.projects[0].tasks.sort(), ['t1', 't2']); assert.equal(overlays().length, 0, 'dialog pemilih tertutup');
  v = viewProyek(ctx); const t = txt(flat(v)[0]); assert.match(t, /Tugas \(2\)/); assert.match(t, /1 dari 2 tugas selesai/); assert.match(t, /50%/);
  reset(); click(btn(v, '+ Tautkan catatan')); ov = overlays()[0]; const labels = all(ov).filter((e) => e.tag === 'b').map(txt);
  assert.deepEqual(labels, ['Daftar bahan', 'Tanpa judul']); assert.ok(!txt(ov).includes('RAHASIA'));
});
test('batas 100 tautan di pemilih; semua sudah tertaut = pemberitahuan, tanpa dialog', () => {
  reset(); const ctx = mk(); ctx.data.projects = [{ id: 'p1', name: 'P', desc: '', status: 'aktif', at: 1, tasks: ['t1', 't2'], notes: [] }]; ctx.ui.projectId = 'p1';
  const v = viewProyek(ctx); click(btn(v, '+ Tautkan tugas')); assert.equal(overlays().length, 0, 'tidak ada dialog bila semua tugas sudah tertaut');
});
test('lepas tautan (tugas tetap ada); ganti status; nama kosong ditolak; tenggat', () => {
  reset(); const ctx = mk(); ctx.data.projects = [{ id: 'p1', name: 'P', desc: '', status: 'aktif', at: 1, tasks: ['t1'], notes: ['n1'] }]; ctx.ui.projectId = 'p1';
  let v = viewProyek(ctx); click(find(v, (e) => /Lepas tautan CAT DINDING/.test(e.attrs['aria-label'] || '')));
  assert.deepEqual(ctx.data.projects[0].tasks, []); assert.equal(ctx.data.tasks.length, 2);
  v = viewProyek(ctx); click(btn(v, 'Selesai')); assert.equal(ctx.data.projects[0].status, 'selesai');
  const nm = find(v, (e) => e.tag === 'input' && e.attrs['aria-label'] === 'Nama proyek'); nm.value = '   '; nm.handlers.change.forEach((f) => f()); assert.equal(ctx.data.projects[0].name, 'P'); assert.equal(nm.value, 'P');
  nm.value = ' Baru '; nm.handlers.change.forEach((f) => f()); assert.equal(ctx.data.projects[0].name, 'BARU');
  const due = find(v, (e) => e.attrs['aria-label'] === 'Tenggat proyek'); due.value = '2026-12-31'; due.handlers.change.forEach((f) => f()); assert.ok(ctx.data.projects[0].due > 0);
  due.value = ''; due.handlers.change.forEach((f) => f()); assert.ok(!('due' in ctx.data.projects[0]));
});
test('hapus proyek: konfirmasi, tugas/catatan utuh, Urungkan memulihkan di posisi semula', () => {
  reset(); const ctx = mk(); ctx.data.projects = [{ id: 'a', name: 'A', desc: '', status: 'aktif', at: 1, tasks: ['t1'], notes: [] }, { id: 'b', name: 'B', desc: '', status: 'aktif', at: 2, tasks: [], notes: [] }]; ctx.ui.projectId = 'a';
  const v = viewProyek(ctx); click(btn(v, 'Hapus proyek')); const ov = overlays()[0]; assert.ok(ov); assert.equal(ctx.data.projects.length, 2, 'belum terhapus sebelum konfirmasi');
  click(btn(ov, 'Hapus')); assert.deepEqual(ctx.data.projects.map((p) => p.id), ['b']); assert.equal(ctx.ui.projectId, ''); assert.equal(ctx.data.tasks.length, 2);
  const toast = document.body.kids.find((o) => /toast/.test(o.className)); click(find(toast, (e) => e.tag === 'button'));
  assert.deepEqual(ctx.data.projects.map((p) => p.id), ['a', 'b']); assert.deepEqual(ctx.data.projects[0].tasks, ['t1']);
});
test('proyek yang sudah hilang: projectId dibersihkan, kembali ke daftar', () => {
  reset(); const ctx = mk(); ctx.ui.projectId = 'hilang'; const v = viewProyek(ctx); assert.equal(ctx.ui.projectId, ''); assert.ok(btn(v, '+ Proyek baru'));
});
test('struktur: UI dimuat MALAS (tidak ada di graf statis), pintu di Setelan, tombol Kembali HP, CSS, tes terdaftar, versi 0.3.121', () => {
  const g = staticGraph('js/main.js'); assert.ok(!g.includes('js/proyek-ui.js') && !g.includes('js/proyek-alat.js'));
  const st = src('src/js/settings.js'); assert.match(st, /import\('\.\/proyek-ui\.js'\)/); assert.doesNotMatch(st, /^import .*proyek-ui/m);
  assert.match(st, /ui\.moreView === 'proyek'\) return viewProyek\(ctx\)/); assert.match(st, /row\(PATH\.proyek, 'v', 'Proyek'/);
  assert.match(src('src/js/main.js'), /moreView === 'proyek' && ui\.projectId\) \{ ui\.projectId = ''/);
  const ui = src('src/js/proyek-ui.js'); assert.doesNotMatch(ui, /innerHTML|\.priv\b|\.trash\b|localStorage|fetch\(/);
  const css = src('src/css/styles.css'); for (const c of ['.pjc{', '.pjseg{', '.pjhero{', '.pjo.on']) assert.ok(css.includes(c), c);
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.match(pk.scripts.test, /node tests\/rev235\.test\.mjs/); assert.equal(S.SCHEMA, 22);
});
