// Rev 387 / CHECKPOINT PART TN: durasi Tunda alarm bisa diatur. DOKUMEN SAJA: kode belum diubah.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('banner Rev 387 di atas Rev 386 di PROMPT_SERAH_TERIMA.md dan RIWAYAT.md, memuat PART TN, BELUM ADA KODE, BELUM TERBUKTI', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) {
    const d = rd(f); assert.ok(d.indexOf('**Rev 387 / v0.3.121') >= 0 && d.indexOf('**Rev 387 /') < d.indexOf('**Rev 386 /'), f);
    const b = d.slice(d.indexOf('**Rev 387 /'), d.indexOf('**Rev 386 /'));
    for (const k of ['PART TN', 'BELUM ADA KODE', 'BELUM TERBUKTI', 'TN1', 'TN4', 'setAlarmSnooze', 'D-TN1']) assert.ok(b.includes(k), f + ' ' + k);
  }
});
test('bagian 38.16 ada, sesudah 38.15', () => {
  const d = rd('PROMPT_SERAH_TERIMA.md'); const a = d.indexOf('**38.15 STATUS PENUTUP'), b = d.indexOf('**38.16 CHECKPOINT PART TN');
  assert.ok(a > 0 && b > a);
});
test('SNOOZE_MIN masih bawaan 10, SCHEMA 22, versi 0.3.121 (TN1 sudah mengisi jembatan, lihat rev388)', () => {
  const n = rd('scripts/apply-native.mjs');
  assert.ok(n.includes('static final int SNOOZE_MIN=10;'));
  assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/);
  assert.equal(JSON.parse(rd('package.json')).version, '0.3.121');
});
test('README < 12000 huruf, menyebut Rev 387 dan TN1-TN4; tes terdaftar sesudah rev386', () => {
  const m = rd('README.md'); assert.ok(m.length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */); assert.ok(m.includes('Rev 387') && m.includes('TN1-TN4'));
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.indexOf('rev386.test.mjs') < t.indexOf('rev387.test.mjs'));
});
