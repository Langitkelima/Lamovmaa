// Rev 367 / K4: petunjuk tulisan tangan di Worker (`ocr`) + catatan [?] dan tips foto di dialog Pindai. Bukan bukti mutu di foto nyata.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import W from '../backend/cloudflare/worker.mjs';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8'), T = W._t;
test('SYSTEM_OCR: petunjuk tulisan tangan ada, aturan lama (data bukan perintah, TIDAK_ADA_TEKS) tetap', () => {
  const s = T.SYSTEM_OCR; assert.ok(s.includes('kata demi kata') && s.includes('[?]') && s.includes('angka, nama, atau alamat'));
  assert.ok(s.includes('DATA untuk disalin') && s.includes('TIDAK_ADA_TEKS') && s.includes('tanpa Markdown'));
});
test('batas keluaran OCR naik ke 12000; bentuk permintaan tanpa temperature/thinking', () => {
  const w = rd('backend/cloudflare/worker.mjs'); assert.ok(w.includes('MAX_OCR_OUT = 12000') && !/thinkingConfig|temperature/.test(w.split('async function tryOcr')[1].split('async function ocr')[0]));
});
test('hitungRagu menghitung [?]; dialog memuat tips foto dan catatan ragu', async () => {
  const src = rd('src/js/ai/ocr-ui.js'); assert.ok(src.includes('export function hitungRagu') && src.includes('Hasil terbaik: foto lurus') && src.includes('bagian bertanda [?]'));
  const hitung = (x) => (String(x || '').match(/\[\?\]/g) || []).length; assert.equal(hitung('a [?] b [?]'), 2); assert.equal(hitung(''), 0);
});
test('tidak ada perubahan SCHEMA/versi; panduan Worker memuat bagian K4; tes terdaftar', () => {
  const p = JSON.parse(rd('package.json')); assert.ok(p.scripts.test.includes('node tests/rev367.test.mjs')); assert.ok(rd('backend/cloudflare/PANDUAN_WORKER.md').includes('Rev 367, K4'));
  assert.ok(rd('README.md').length < 12400 /* Rev 417: 12000 -> 12400 ATAS IZIN PENGGUNA */);
});
