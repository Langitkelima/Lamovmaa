// Tes Rev 35: tombol header besar, panah menu + animasi muntah-tarik, seleksi mode Baca hanya isi.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css'), ui = src('../src/js/ui.js');

t('Rev 35: tombol menu memakai ikon panah bawah (bukan titik tiga) dan berputar ke atas saat terbuka', () => {
  assert.ok(ui.includes('chevDown:'));
  assert.match(nt, /class: 'ghost hmore'[^\n]*icoMenu\(\)/);
  assert.ok(css.includes('.fsh .ghost.hmore[aria-expanded=true] .mh1{transform:translateY(5px) rotate(45deg)}')); // Rev 310a: panah bawah diganti tiga garis jadi silang (B1)
});
t('Rev 35: target sentuh header besar (Kembali, centang, panah >= 44px)', () => {
  const m = css.slice(css.indexOf('Rev 35: tombol header'));
  assert.ok(m.includes('.fsh>.ghost:first-child{width:50px;height:50px}'));
  assert.ok(m.includes('.fsh .hmode{width:46px;height:46px}'));
  assert.ok(m.includes('.fsh .ghost.hmore{width:48px;height:48px'));
  assert.ok(m.includes('.fsh .hmode{width:44px;height:44px}')); // ukuran terkecil (layar sempit) tetap >= 44px
});
t('Rev 35: menu panah memakai animasi muntah (buka) dan tarik (tutup) hanya transform/opacity, menghormati reduced-motion', () => {
  for (const k of ['function spitMenu', 'function dismissMenu', 'menuBusy', 'redMotion()', 'canAnim()']) assert.ok(nt.includes(k), k);
  assert.ok(nt.includes("onclick: (e) => { if (e.target === menuOv) dismissMenu(); }"));
  assert.ok(!nt.includes("moreBtn.animate("), 'Rev 46: denyut skala tombol panah dihapus (pemicu kedip)');
  assert.ok(css.includes('@keyframes menuin{from{opacity:0}to{opacity:1}}'));
});
t('Rev 35: mode Baca menjepit seleksi ke dalam isi catatan dan melepas pendengar saat editor ditutup', () => {
  for (const k of ['const clampReadSel', "editorMode !== 'baca'", 'r.intersectsNode(ed)', 'nr.setStart(ed, 0)', 'nr.setEnd(ed, ed.childNodes.length)']) assert.ok(nt.includes(k), k);
  assert.ok(nt.includes("document.addEventListener('selectionchange', clampReadSel)"));
  assert.ok(nt.includes("document.removeEventListener('selectionchange', clampReadSel)"));
  assert.ok(css.includes('.fs.ed-baca .fsb>:not(.ed2),.fs.ed-baca .fsh,.fs.ed-baca .dock{user-select:none'));
  assert.ok(css.includes('.fs.ed-baca .ttl{user-select:none'));
});
console.log(n + ' tes lulus (Rev 35 header + seleksi Baca)');
