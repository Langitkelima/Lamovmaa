// Rev 137 / U8b-4: pratinjau KARTU daftar Catatan menampilkan isi sel lembar kerja (hasil rumus + format), dihitung saat kartu digambar.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as L from '../src/js/lembar.js';
import { a1ToStored } from '../src/js/rumus.js';
import { sheetCardText, notePreviewText, CARD_PREVIEW_MAX } from '../src/js/lembar-pulau.js';
import { setEngine as __setEngine } from '../src/js/lembar-mesin.js'; import * as __MESIN from '../src/js/rumus.js'; __setEngine(__MESIN); // Rev 192b: mesin rumus dimuat belakangan di aplikasi; tes ini memerlukannya langsung
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
function sample() {
  const sh = L.newSheet({ id: 'sabc123', name: 'Anggaran' }); const t = sh.tabs[0];
  L.setCell(t, 'r1', 'cA', { v: 'Kopi susu' }); L.setCell(t, 'r1', 'cB', { v: 1250000, s: { nf: { k: 'currency', c: 'IDR', d: 0 } } });
  L.setCell(t, 'r2', 'cA', { v: 'Pajak' }); L.setCell(t, 'r2', 'cB', { fx: a1ToStored('=B1*0,11', t).fx, s: { nf: { k: 'currency', c: 'IDR', d: 0 } } });
  return sh;
}
const ISL = (id) => '<div class="ksheet" contenteditable="false" data-sheet="' + id + '"></div>';
test('sheetCardText: hasil rumus + format, baris dipisah "; ", kosong/null aman', () => {
  assert.equal(sheetCardText(sample()), 'Kopi susu Rp 1.250.000; Pajak Rp 137.500');
  assert.equal(sheetCardText(null), ''); assert.equal(sheetCardText(L.newSheet({ id: 'sempty1' })), '');
});
test('sheetCardText: memakai tab pertama yang berisi, dipotong dengan …', () => {
  const sh = L.newSheet({ id: 'stab0001' }); L.addTab(sh, 'Dua'); L.setCell(sh.tabs[1], 'r1', 'cA', { v: 'di-tab-dua' });
  assert.equal(sheetCardText(sh), 'di-tab-dua');
  const big = L.newSheet({ id: 'sbig9999' }); for (let i = 1; i <= 30; i++) L.setCell(big.tabs[0], 'r' + i, 'cA', { v: 'x'.repeat(50) });
  const t = sheetCardText(big); assert.ok(t.length <= CARD_PREVIEW_MAX); assert.ok(t.endsWith('…'));
});
test('notePreviewText: baris "Lembar kerja: Nama" diganti nama terbaru + isi; teks lain utuh', () => {
  const sh = sample(); sh.name = 'Anggaran Baru';
  const n = { text: 'Belanja\nLembar kerja: Anggaran\nSelesai', html: '<p>Belanja</p>' + ISL('sabc123') + '<p>Selesai</p>' };
  assert.equal(notePreviewText(n, (id) => (id === 'sabc123' ? sh : null)), 'Belanja\nLembar kerja: Anggaran Baru — Kopi susu Rp 1.250.000; Pajak Rp 137.500\nSelesai');
});
test('notePreviewText: dua pulau berurutan; lembar hilang dibiarkan; lembar kosong = hanya nama', () => {
  const sh = sample(), kosong = L.newSheet({ id: 'skosong1', name: 'Kosong' });
  const get = (id) => ({ sabc123: sh, skosong1: kosong }[id] || null);
  const n = { text: 'Lembar kerja: Anggaran\nLembar kerja: Kosong\nLembar kerja: Hilang', html: ISL('sabc123') + ISL('skosong1') + ISL('shilang1') };
  assert.equal(notePreviewText(n, get), 'Lembar kerja: Anggaran — Kopi susu Rp 1.250.000; Pajak Rp 137.500\nLembar kerja: Kosong\nLembar kerja: Hilang');
});
test('notePreviewText: aman bila tanpa pulau, jumlah tidak cocok, atau pengambil galat', () => {
  const boom = () => { throw new Error('x'); };
  assert.equal(notePreviewText({ text: 'biasa', html: '<p>biasa</p>' }, boom), 'biasa');
  assert.equal(notePreviewText({ text: 'Lembar kerja: ketikan sendiri', html: '<p>x</p>' }, boom), 'Lembar kerja: ketikan sendiri');
  const salah = { text: 'Lembar kerja: a\nLembar kerja: b', html: ISL('sabc123') }; assert.equal(notePreviewText(salah, () => sample()), salah.text);
  const n = { text: 'Lembar kerja: Anggaran', html: ISL('sabc123') }; assert.equal(notePreviewText(n, boom), n.text);
  assert.equal(notePreviewText(null), ''); assert.equal(notePreviewText({}), '');
});
test('kabel: kartu memakai notePreviewText; n.text yang disimpan tetap ringkasan lama (tidak berisi sel)', () => {
  const n = src('src/js/notes.js');
  assert.match(n, /h\('p', \{\}, notePreviewText\(n\)\)/); assert.match(n, /islandText\(sheetById\(b\.getAttribute\('data-sheet'\) \|\| ''\)\)/);
  assert.doesNotMatch(src('src/js/logic.js'), /lembar-pulau|lembar-tampil|rumus\.js/);
});
test('Rev 137: versi 0.3.121, SCHEMA 13 tetap, tes terdaftar', () => {
  const pk = JSON.parse(src('package.json')); assert.equal(pk.version, '0.3.121'); assert.ok(src('src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
  assert.match(src('src/js/storage.js'), /SCHEMA = 22;/); assert.ok(pk.scripts.test.includes('tests/rev137.test.mjs'));
});
