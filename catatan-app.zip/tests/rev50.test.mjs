// Rev 50: pindah posisi gambar (tahan lalu seret ke antara blok; tombol naik/turun sebagai jalur cadangan). Rev 48/49 diarsipkan oleh pengguna.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as G from '../src/js/gambar.js';
let n = 0;
const t = (name, fn) => { fn(); n++; console.log('ok -', name); };
const src = (p) => readFileSync(new URL(p, import.meta.url), 'utf8');
const nt = src('../src/js/notes.js'), css = src('../src/css/styles.css'), ui = src('../src/js/ui.js');

t('dropIndex: sisip setelah semua blok yang titik tengahnya di atas jari (0..n)', () => {
  const r = [{ top: 0, bottom: 20 }, { top: 30, bottom: 50 }, { top: 60, bottom: 80 }];
  assert.equal(G.dropIndex(r, -5), 0); assert.equal(G.dropIndex(r, 5), 0);
  assert.equal(G.dropIndex(r, 15), 1); assert.equal(G.dropIndex(r, 45), 2);
  assert.equal(G.dropIndex(r, 75), 3); assert.equal(G.dropIndex(r, 999), 3);
});
t('dropIndex: masukan aneh tidak melempar (daftar kosong, bukan array, y bukan angka)', () => {
  assert.equal(G.dropIndex([], 10), 0); assert.equal(G.dropIndex(null, 10), 0);
  assert.equal(G.dropIndex([{ top: 0, bottom: 10 }], NaN), 1); assert.equal(G.dropIndex([{}], 10), 0);
});
t('scrollStep: naik di tepi atas, turun di tepi bawah, diam di tengah, makin dekat tepi makin cepat', () => {
  assert.equal(G.scrollStep(400, 100, 700), 0);
  assert.ok(G.scrollStep(110, 100, 700) < 0 && G.scrollStep(690, 100, 700) > 0);
  assert.ok(Math.abs(G.scrollStep(100, 100, 700)) > Math.abs(G.scrollStep(140, 100, 700)));
  assert.equal(G.scrollStep(0, 100, 700), -14); assert.equal(G.scrollStep(900, 100, 700), 14); // dijepit di kecepatan maksimum
  assert.equal(G.scrollStep(NaN, 100, 700), 0); assert.equal(G.scrollStep(50, 700, 100), 0);
});
t('konstanta gestur: tahan 450 ms; geser lebih dari 10 px sebelum terangkat = menggulir', () => {
  assert.equal(G.LONG_PRESS_MS, 450); assert.equal(G.MOVE_SLOP, 10); assert.ok(G.AUTOSCROLL_EDGE > 0);
});
t('notes.js: tahan-seret hanya di mode Edit, bukan Catatan Privat, dan timer dibatalkan bila jari bergeser (supaya gulir tetap jalan)', () => {
  assert.ok(/editorMode !== 'edit' \|\| isP/.test(nt.slice(nt.indexOf("ed.addEventListener('pointerdown', (e) => {\n    const fig"))));
  assert.ok(nt.includes('setTimeout(mvStart, G.LONG_PRESS_MS)'));
  assert.ok(nt.includes('Math.hypot(e.clientX - mv.x, e.clientY - mv.y) > G.MOVE_SLOP) endMove()'));
});
t('notes.js: gambar TERKUNCI ditolak (toast), tombol naik/turun ikut disembunyikan saat terkunci', () => {
  assert.ok(nt.includes("if (figLocked(fig)) { endMove(); infoKey('gbrKunci', 'dipindahkan'); return; }"));
  assert.ok(css.includes('.img-tools.locked .img-row.r1')); // baris 1 (berisi naik/turun) tersembunyi saat terkunci
  assert.ok(/tapBtn\(imgUp, \(fig\) => stepMove\(fig, -1\)\)/.test(nt) && /tapBtn\(imgDn, \(fig\) => stepMove\(fig, 1\)\)/.test(nt)); // tapBtn menolak gambar terkunci
});
t('notes.js: gambar dibawa bersama baris kosong di bawahnya, sasaran hanya blok tingkat atas, dan selalu ada baris untuk mengetik di bawah gambar terakhir', () => {
  assert.ok(nt.includes('const moveUnit = (fig)'));
  assert.ok(nt.includes('[...ed.childNodes].filter('));
  assert.ok(nt.includes("ed.lastChild.tagName === 'FIGURE'"));
});
t('notes.js: tiap pemindahan = satu langkah Undo (riwayat sebelum dan sesudah), lalu simpan otomatis', () => {
  const s = nt.slice(nt.indexOf('const doMove = (fig, ref)'), nt.indexOf('const stepMove'));
  assert.ok(s.includes('flushHist();') && s.split('flushHist();').length === 3 && s.includes('auto();'));
});
t('notes.js: gulir layar ditahan selama menyeret (touchmove tidak pasif), dan semua pendengar dibersihkan saat selesai/batal/editor ditutup/ganti ke Baca', () => {
  assert.ok(nt.includes("window.addEventListener('touchmove', mvTouchBlock, { capture: true, passive: false })"));
  assert.ok(nt.includes("window.removeEventListener('touchmove', mvTouchBlock, true)"));
  assert.ok(nt.includes('const cleanup = () => { alive = false; closeViewer(); closeMenu(); try { endMove(); } catch (_) {}'));
  assert.ok(nt.includes("if (next === 'baca') { clearImgSel(); endMove();"));
  assert.ok(nt.includes("window.addEventListener('pointercancel', mvCancel, true)"));
});
t('CSS dan ikon: gambar tidak bisa diseleksi/diseret bawaan, tampilan terangkat + garis sasaran, tanpa style inline untuk keadaan', () => {
  assert.ok(css.includes('-webkit-touch-callout:none'));
  assert.ok(css.includes('.ed2 figure.ki.moving'));
  assert.ok(css.includes('.img-drop{position:fixed'));
  assert.ok(ui.includes('moveUp:') && ui.includes('moveDown:'));
  assert.ok(nt.includes("ed.addEventListener('contextmenu'") && nt.includes("ed.addEventListener('dragstart'"));
});
t('tanpa perubahan data: SCHEMA 8 sejak Rev 60, tanpa atribut baru di sanitize, tanpa native/plugin', () => {
  assert.ok(src('../src/js/storage.js').includes('SCHEMA = 22'));
  assert.ok(!/data-mv|data-pos/.test(nt));
  assert.ok(!/dropIndex|moveUnit/.test(src('../scripts/apply-native.mjs')));
});
t('versi 0.3.2 selaras di package.json dan layar Setelan', () => {
  assert.equal(JSON.parse(src('../package.json')).version, '0.3.121');
  assert.ok(src('../src/js/settings.js').includes('Notes Kelimaa v0.3.121'));
});
console.log(n + ' tes lulus (Rev 50)');
