// Rev 218 / v0.3.121: Writing Studio di editor (3b): penjagaan struktur.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('notes.js: tombol Tulis AI hanya di editor biasa (bukan Privat), dimuat malas, hook kecil', () => {
  const n = src('src/js/notes.js');
  assert.doesNotMatch(n, /insertBtn\('ai'/); /* Rev 360: tombol Tulis AI DIPINDAH dari bilah ke kapsul tahan-✦ (DISENGAJA) */ assert.match(n, /const showAiChip = \(\) => \{\s*\n\s*if \(isP \|\| editorMode !== 'edit'/);
  assert.match(n, /kind === 'ai' && !isP\) openWriteAI\(\)/);
  assert.match(n, /const openWriteAI = \(\) => \{\s*\n\s*if \(isP\) \{ return; \}/);
  assert.match(n, /import\('\.\/ai\/tulisui\.js'\)/); assert.doesNotMatch(n, /^import .*\/ai\//m);
});
test('tulisui.js: hasil lewat node teks, penerapan hanya lewat tombol Ganti/Sisipkan, tolak blok/tabel/gambar', () => {
  const u = src('src/js/ai/tulisui.js');
  assert.doesNotMatch(u, /innerHTML|insertAdjacentHTML|localStorage|\.priv/);
  assert.match(u, /out\.textContent = r\.text/); assert.match(u, /bReplace\.onclick = \(\) => apply\('ganti'\)/); assert.match(u, /bInsert\.onclick = \(\) => apply\('sisip'\)/);
  assert.match(u, /querySelector\(BLOCK_SEL \+ ',table,img,\.ksheet,\.fold,\.todo,input'\)/);
  assert.match(u, /class: 'btn line', onclick: close \}, 'Batal'/); // tombol Kembali HP menutup lewat .dlgb button.line
  assert.ok(u.indexOf('flushHist();') < u.indexOf('rr.deleteContents()')); // satu langkah Urungkan sebelum mengubah
});
test('main.js dan startup.js tetap tanpa impor modul AI', () => {
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\//); assert.doesNotMatch(src('src/js/startup.js'), /\/ai\//);
});
