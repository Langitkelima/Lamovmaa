// Rev 221 / v0.3.121: Context Engine (logika murni) + sambungan ke chat. Bawaan MATI; priv/trash tidak pernah dibaca.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { CTX_KEY, CTX_SOURCES, CTX_TOTAL_MAX, normPerms, loadPerms, savePerms, anyOn, buildContext, attachContext } from '../src/js/ai/konteks.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const mem = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };
const data = { tasks: [{ id: 'a', title: 'Bayar listrik', done: false, due: '2026-11-15', pri: 1 }, { id: 'b', title: 'Sudah beres', done: true }, { id: 'c', title: 'Cuci\nmobil', done: false, due: 'besok' }], notes: [{ id: 'n1', title: 'Resep', text: 'RAHASIA ISI', updated: 1 }, { id: 'n2', title: 'Ide', text: 'x', updated: 9 }], priv: [{ id: 'p', title: 'PRIVAT-JUDUL', text: 'PRIVAT-ISI' }], trash: [{ id: 't', title: 'SAMPAH-JUDUL' }] };
test('izin: bawaan MATI, per ID (Rev 308a), bentuk lama dibaca KOSONG, disimpan di kunci terpisah', () => {
  assert.deepEqual(normPerms(null), { v: 2, tugas: [], proyek: [] }); assert.deepEqual(normPerms({ tugas: true, catatan: true, proyek: true }), { v: 2, tugas: [], proyek: [] });
  const st = mem(); assert.equal(anyOn(loadPerms(st)), false); assert.equal(savePerms({ v: 2, tugas: ['a'], x: ['z'] }, st).ok, true);
  assert.deepEqual(loadPerms(st), { v: 2, tugas: ['a'], proyek: [] }); assert.ok(st.getItem(CTX_KEY)); assert.equal(CTX_KEY, 'kelimaa_ai_ctx');
});
test('buildContext: tidak ada yang dipilih = kosong; hanya tugas terpilih yang belum selesai; catatan bukan sumber lagi', () => {
  assert.equal(buildContext(data, {}).text, ''); assert.equal(buildContext(data, { v: 2, tugas: [], proyek: [] }).text, '');
  const t = buildContext(data, { v: 2, tugas: ['a', 'b', 'c'] }); assert.match(t.text, /Bayar listrik, tenggat 2026-11-15, ditandai penting/); assert.doesNotMatch(t.text, /Sudah beres/); assert.match(t.text, /- Cuci mobil$/m); assert.doesNotMatch(t.text, /besok/);
  assert.equal(buildContext(data, { catatan: true }).text, ''); assert.doesNotMatch(buildContext(data, { v: 2, tugas: ['a'], catatan: ['n1'] }).text, /Resep|Ide|RAHASIA ISI/);
  assert.deepEqual(buildContext(data, { v: 2, tugas: ['a'] }).parts.map((p) => p.id), ['tugas']);
});
test('Catatan Privat dan sampah TIDAK PERNAH ikut, bahkan saat semua menyala', () => {
  const all = buildContext(data, { v: 2, tugas: ['a', 'b', 'c', 'p', 't'], proyek: ['p'] }).text; assert.doesNotMatch(all, /PRIVAT|SAMPAH/);
  const k = src('src/js/ai/konteks.js'); assert.doesNotMatch(k, /\.priv\b|\.trash\b|innerHTML|document\.|window\./);
});
test('batas: total <= CTX_TOTAL_MAX, judul panjang dipotong, data aneh tidak melempar', () => {
  const big = { tasks: Array.from({ length: 50 }, (_, i) => ({ id: 'i' + i, title: 'T'.repeat(200) + i, done: false })), notes: [] };
  const r = buildContext(big, { v: 2, tugas: big.tasks.map((t) => t.id) }); assert.ok(r.text.length <= CTX_TOTAL_MAX); assert.ok(r.text.split('\n').filter((l) => l.startsWith('- ')).length <= 15);
  for (const bad of [null, undefined, {}, { tasks: 'x', notes: 5 }, { tasks: [null, 3, {}], notes: [null] }]) assert.equal(buildContext(bad, { v: 2, tugas: ['a', 'i1'], proyek: ['p'] }).text, '');
});
test('attachContext: tempel di pesan terakhir, riwayat asli utuh, dipangkas ke batas, dilewati bila tak ada ruang', () => {
  const msgs = [{ role: 'user', content: 'halo' }, { role: 'assistant', content: 'hai' }, { role: 'user', content: 'tanya' }];
  const a = attachContext(msgs, 'KONTEKS'); assert.equal(a.used, true); assert.equal(a.messages.length, 3); assert.equal(a.messages[2].content, 'KONTEKS\n\n---\ntanya'); assert.equal(msgs[2].content, 'tanya');
  assert.equal(attachContext(msgs, '').used, false); assert.equal(attachContext([], 'K').used, false);
  const full = [{ role: 'user', content: 'x'.repeat(3900) }]; assert.equal(attachContext(full, 'K'.repeat(500)).used, false);
  const part = [{ role: 'user', content: 'x'.repeat(3500) }]; const p = attachContext(part, 'K '.repeat(400)); assert.equal(p.used, true); assert.ok(p.messages[0].content.length <= 4000);
});
test('obrolan.js: konteks ditempel hanya lewat attachContext + izin, ada pratinjau, tetap malas', () => {
  const o = src('src/js/ai/obrolan.js');
  assert.match(o, /attachContext\(buildMessages\(riwayat, c\.value\), cx\.text\)/); assert.match(o, /Lihat data yang dikirim/); assert.match(o, /Data aplikasi untuk AI/); assert.match(o, /loadPerms\(\)/);
  assert.doesNotMatch(src('src/js/main.js'), /\/ai\//); assert.equal(CTX_SOURCES.length, 2);
});
