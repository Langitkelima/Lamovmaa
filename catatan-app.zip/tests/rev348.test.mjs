// Rev 348 / PART R3: pemicu `!` + lembar Ingatkan untuk item bullet/bernomor (li). Kabel sumber; perilaku Chromium diaudit di R6.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { remindFor } from '../src/js/ketik-ui.js';
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('R3: ketik-ui.js: pemicu remind mengenali .todo DAN li; teks pemicu tetap di baris', () => {
  const s = read('src/js/ketik-ui.js');
  assert.match(s, /const row = el\.closest\('\.todo,li'\);\n\s+const rm = row && ed\.contains\(row\) \? remindFor\(line\) : null;/);
  assert.doesNotMatch(s, /el\.closest\('\.todo'\);\n\s+const rm/);
});
test('R3: remindFor (murni) tidak peduli jenis baris: `!besok 9` dikenali sebagai pengingat', () => {
  const r = remindFor('beli susu !besok 9', Date.UTC(2026, 10, 19, 1, 0));
  assert.ok(r, 'terdeteksi'); assert.equal(r.hasTime, true); assert.ok(r.when > 0);
});
test('R3: notes.js: ownCid memeriksa li juga; teks lembar = teks item tanpa sub-daftar; gerbang pemuat modul memuat li', () => {
  const s = read('src/js/notes.js');
  assert.match(s, /ed\.querySelector\('\.todo\[data-cid="' \+ c \+ '"\],li\[data-cid="' \+ c \+ '"\]'\) === row \? c : ''/);
  assert.match(s, /row\.tagName === 'LI' \? \[\.\.\.row\.childNodes\]\.filter\(\(c\) => c\.nodeType === 3 \|\| \(c\.nodeType === 1 && c\.tagName !== 'UL' && c\.tagName !== 'OL'\)\)/);
  assert.match(s, /row\.tagName === 'LI' \? 'Item daftar' : 'Baris kotak centang'/);
  assert.match(s, /nd\.parentElement\.closest\('\.todo,li'\)\)/);
});
test('R3: doSave tetap memasang data-cid lewat setAttribute pada baris apa pun (lonceng li menyusul di R4, Rev 349)', () => {
  const s = read('src/js/notes.js');
  assert.match(s, /ed\.querySelectorAll\('\.todo(?:,li\[data-cid\](?:,li\[data-rem\])?)?'\)\.forEach\(\(row\) => \{(?: \/\/[^\n]*)?\n\s+(?:const cr = [^\n]*?; )?const want = rowBell/); // Rev 383: sejak Rev 380 baris ini diawali `const cr = ...;` (mode alarm), jadi dibuat opsional
  assert.match(s, /row\.setAttribute\('data-cid', cid\);/);
});
