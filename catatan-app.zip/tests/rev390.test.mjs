// Rev 390 / PART TN3: UI pemilih lama Tunda alarm di Setelan (5/10/15/30 menit). Perilaku HP belum diuji.
import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import { SNOOZE_CHOICES } from '../src/js/logic.js';
const rd = (p) => fs.readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('Setelan: kartu "Tunda alarm" memakai SNOOZE_CHOICES, aria-pressed, dan memanggil applySnooze + persist', () => {
  const st = rd('src/js/settings.js');
  assert.ok(st.includes("import { SNOOZE_CHOICES } from './logic.js';"));
  assert.ok(st.includes('SNOOZE_CHOICES.map(snzBtn)'));
  const k0 = st.indexOf('const snzBtn'); const b = st.slice(k0, st.indexOf('const dayBtn', k0));
  for (const k of ["s.snoozeMin === m", "aria-pressed", "ctx.persist()", "applySnooze(m)", "tOk(", "tInfo("]) assert.ok(b.includes(k), k);
  assert.deepEqual(SNOOZE_CHOICES, [5, 10, 15, 30]);
});
test('kartu diletakkan sesudah kartu hari kerja dan sebelum daftar baris; label dan keterangan ada', () => {
  const st = rd('src/js/settings.js');
  const a = st.indexOf("class: 'daycard'"), b = st.indexOf('daycard snzcard'), c = st.indexOf("h('div', { class: 'mzlist' }");
  assert.ok(a > 0 && b > a && c > b);
  assert.ok(st.includes("'Tunda alarm'") && st.includes('Bawaan 10 menit'));
});
test('ketuk pilihan yang sama tidak berbuat apa-apa; APK lama diberi tahu lewat toast informasi (bukan galat)', () => {
  const st = rd('src/js/settings.js');
  assert.ok(st.includes('if (s.snoozeMin === m) return;'));
  assert.ok(st.includes('Berlaku setelah APK terbaru terpasang.'));
});
test('CSS: hanya satu aturan kecil bertema, tanpa warna mentah; anggaran CSS 270 KB utuh', () => {
  const css = rd('src/css/styles.css'); const i = css.indexOf('Rev 390 / TN3'); assert.ok(i > 0);
  const blk = css.slice(i); assert.ok(!/#[0-9a-fA-F]{3,6}\b/.test(blk));
  assert.ok(css.length < 270 * 1024);
});
test('SCHEMA tetap 22, native dan Worker tidak diubah', () => {
  assert.match(rd('src/js/storage.js'), /export const SCHEMA = 22;/);
});
test('banner Rev 390 paling atas (di atas Rev 389), memuat PART TN3, BELUM TERBUKTI, BERFUNGSI-BELUM-DIUJI; tes terdaftar sesudah rev389', () => {
  for (const f of ['PROMPT_SERAH_TERIMA.md', 'RIWAYAT.md']) {
    const d = rd(f); assert.ok(/^\*\*Rev (?:39\d|4[0-3]\d) \/ v0\.3\.121/.test(d) && d.indexOf('**Rev 390 /') < d.indexOf('**Rev 389 /'), f);
    const b = d.slice(d.indexOf('**Rev 390 /'), d.indexOf('**Rev 389 /')); for (const k of ['PART TN3', 'BELUM TERBUKTI', 'BERFUNGSI-BELUM-DIUJI', 'snoozeMin']) assert.ok(b.includes(k), f + ' ' + k);
  }
  const t = JSON.parse(rd('package.json')).scripts.test; assert.ok(t.indexOf('rev389.test.mjs') < t.indexOf('rev390.test.mjs'));
});
