// Rev 366 / K9: tes membaca RIWAYAT.md dan PROMPT_SERAH_TERIMA.md DITAMBAH arsipnya (ARSIP/*.md), karena entri lama dipindah ke arsip.
// Dimuat lewat `node --import ./tests/_arsip.mjs`. Hanya mengubah hasil readFileSync untuk dua berkas itu (di akar repo).
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url'; import { syncBuiltinESMExports } from 'node:module';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), orig = fs.readFileSync;
const MAP = { 'RIWAYAT.md': 'ARSIP/RIWAYAT_ARSIP.md', 'PROMPT_SERAH_TERIMA.md': 'ARSIP/PROMPT_SERAH_TERIMA_ARSIP.md' };
fs.readFileSync = function (p, o) {
  let f = null; try { f = p instanceof URL ? fileURLToPath(p) : typeof p === 'string' ? path.resolve(p) : null; } catch (e) { f = null; }
  const rel = f && path.dirname(f) === root ? path.basename(f) : null;
  const r = orig.apply(this, arguments);
  if (!rel || !MAP[rel] || typeof r !== 'string') return r;
  return r + '\n' + orig.call(fs, path.join(root, MAP[rel]), 'utf8');
};
syncBuiltinESMExports();
