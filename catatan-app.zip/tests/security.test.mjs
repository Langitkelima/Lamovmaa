import assert from 'node:assert/strict';
import * as P from '../src/js/security.js';

let n = 0;
const t = async (name, fn) => { await fn(); n++; console.log('ok -', name); };

await t('validatePin: hanya 4 sampai 6 angka', () => {
  for (const ok of ['1234', '123456', '0000']) assert.equal(P.validatePin(ok).ok, true);
  for (const bad of ['123', '1234567', 'abcd', '12 34', '', null, '12.4']) assert.equal(P.validatePin(bad).ok, false);
});
await t('hashPin: PIN dan garam sama -> hash sama; beda -> beda', async () => {
  const s = P.newSalt();
  const a = await P.hashPin('1234', s), b = await P.hashPin('1234', s);
  assert.equal(a, b); assert.equal(a.length, 64);
  assert.notEqual(a, await P.hashPin('1235', s));
  assert.notEqual(a, await P.hashPin('1234', P.newSalt()));
});
await t('newSalt: 32 karakter hex dan acak', () => {
  const a = P.newSalt(), b = P.newSalt();
  assert.match(a, /^[0-9a-f]{32}$/); assert.notEqual(a, b);
});
await t('verifyPin: benar true, salah false; hash tidak memuat PIN asli', async () => {
  const s = P.newSalt(), h = await P.hashPin('4821', s);
  assert.equal(await P.verifyPin('4821', s, h), true);
  assert.equal(await P.verifyPin('4822', s, h), false);
  assert.equal(h.includes('4821'), false);
});
await t('failState: kunci muncul tiap 5 kali salah dan berlipat, maksimal 15 menit', () => {
  let f = 0; const now = 1000;
  for (let i = 1; i <= 4; i++) { const r = P.failState(f, now); assert.equal(r.lockUntil, 0); f = r.fails; }
  let r = P.failState(f, now); assert.equal(r.fails, 5); assert.equal(r.lockUntil, now + 30000);
  f = r.fails; for (let i = 6; i <= 9; i++) f = P.failState(f, now).fails;
  r = P.failState(f, now); assert.equal(r.fails, 10); assert.equal(r.lockUntil, now + 60000);
  r = P.failState(98, now); assert.equal(r.fails, 99); assert.equal(r.lockUntil, 0);
  r = P.failState(94, now); assert.equal(r.fails, 95); assert.equal(r.lockUntil, now + 900000);
});
await t('lockRemaining: hitung mundur dan tidak negatif', () => {
  assert.equal(P.lockRemaining(31000, 1000), 30);
  assert.equal(P.lockRemaining(500, 1000), 0);
  assert.equal(P.lockRemaining(undefined, 1000), 0);
});
console.log(`\n${n} tes keamanan lulus`);

// ---- Papan angka PIN ----
{
  const { pinKey } = await import('../src/js/security.js');
  const eq = (a, b, m) => { if (a !== b) throw new Error(`GAGAL: ${m} (dapat "${a}", harap "${b}")`); };
  eq(pinKey('', '1'), '1', 'angka pertama masuk');
  eq(pinKey('12', 'del'), '1', 'hapus satu angka');
  eq(pinKey('', 'del'), '', 'hapus pada PIN kosong aman');
  eq(pinKey('123456', '7'), '123456', 'maksimal 6 angka');
  eq(pinKey('12', 'x'), '12', 'tombol selain angka diabaikan');
  eq(pinKey(undefined, '5'), '5', 'nilai kosong dianggap teks kosong');
  console.log('ok - pinKey: tambah, hapus, batas 6, input aneh diabaikan');
}
