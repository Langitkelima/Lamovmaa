// Rev 142 / U9a-3a: Cari dan ganti di lembar Lainnya (dialog; Berikutnya; Ganti semua = satu langkah Urungkan).
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { replaceMessage } from '../src/js/lembar-ui.js';
import * as L from '../src/js/lembar.js';
import * as A from '../src/js/lembar-alat.js';
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
test('replaceMessage: hasil, tidak ada, dan laporan sel dilewati', () => {
  assert.equal(replaceMessage({ cells: 2, replaced: 3 }), '3 kali diganti di 2 sel.');
  assert.equal(replaceMessage({ cells: 0, replaced: 0 }), 'Tidak ada yang diganti.');
  assert.equal(replaceMessage({ cells: 1, replaced: 1, skippedFormula: 2, skippedFormat: 1 }), '1 kali diganti di 1 sel. 2 sel berumus dilewati, 1 sel berformat dilewati.');
  assert.equal(replaceMessage(null), 'Tidak ada yang diganti.');
});
test('jalur data: cari tanpa beda huruf, seluruh isi sel, ganti tidak menyentuh rumus', () => {
  const sh = L.newSheet({ name: 'T' }), tab = sh.tabs[0];
  const set = (r, c, p) => L.setCell(tab, tab.rows[r].id, tab.cols[c].id, p);
  set(0, 0, { v: 'Kopi susu' }); set(1, 0, { v: 'kopi' }); set(2, 0, { v: 'Teh' }); set(3, 1, { v: 5 }); set(4, 1, { fx: undefined, v: 'x' });
  assert.equal(A.findAll(tab, 'KOPI').length, 2); assert.equal(A.findAll(tab, 'kopi', { whole: true }).length, 1); assert.equal(A.findAll(tab, 'KOPI', { matchCase: true }).length, 0);
  const res = A.replaceAll(tab, 'kopi', 'Teh'); assert.equal(res.cells, 2); assert.equal(tab.rows[0].cells[tab.cols[0].id].v, 'Teh susu'); assert.equal(A.findAll(tab, '').length, 0);
});
test('penjaga kode: item Cari dan ganti, snapshot sebelum ganti, Kembali HP, tanpa penyimpanan di UI', () => {
  const u = src('src/js/lembar-ui.js');
  assert.match(u, /import \{ sortTab, tabToDelimited, usedRange, findAll, replaceAll(?:, seriesPlan, fillSeries(?:, importDelimited, parseDelimited, detectDelimiter)?)? \} from '\.\/lembar-alat\.js'/);
  assert.match(u, /item\('cari', 'Cari dan ganti', 'di seluruh tab ini', openFind\)/);
  assert.match(u, /const snap = ser\(\), res = replaceAll\(tab, q\.value, rp\.value, opts\(\)\);\n      if \(res\.cells\) \{/);
  assert.match(u, /class: 'ov dlgov lz-more lz-find'/); assert.doesNotMatch(u, /localStorage|sessionStorage|\beval\s*\(/);
  for (const nope of []) assert.ok(!u.includes(nope), nope + ' belum boleh ada'); // Rev 149: item filter kini ada
});
