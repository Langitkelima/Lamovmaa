# Notes Kelimaa

**Versi sumber 0.3.121 · Rev 430 · SCHEMA 22** · ID paket `com.kelimaa.notes` · label rilis: **KANDIDAT RILIS** (belum FINAL)

Aplikasi catatan dan ceklis tugas Android berbasis HTML/CSS/JavaScript (modul ES, tanpa bundler), dibungkus Capacitor 8. Data disimpan di perangkat dan aplikasi tetap jalan penuh tanpa internet. Fitur **Kelimaa AI** bersifat opsional: aplikasi hanya bicara dengan Worker Cloudflare milik sendiri, kunci penyedia AI tidak pernah ada di APK.

## Dokumen di ZIP ini

| Berkas | Fungsi |
| --- | --- |
| `PROMPT_SERAH_TERIMA.md` | Panduan utama untuk AI yang melanjutkan: aturan kerja, arsitektur, keputusan tetap, status, rencana. Entri terbaru ada di bagian paling atas. |
| `RIWAYAT.md` | Catatan lengkap tiap revisi: penyebab, perubahan, tes, dan apa yang belum terbukti. Entri terbaru di paling atas. |
| `UJI_HP_RILIS.md` | Daftar uji di HP (bagian A, B, C, E, F). Lapor dengan format: nomor + aman/janggal + keterangan. |
| `backend/cloudflare/` | `worker.mjs` (ditempel di Cloudflare) dan `PANDUAN_WORKER.md` (langkah untuk pemula). |
| `README.md` | Ringkasan ini. |

**Untuk melanjutkan di percakapan atau AI baru, cukup kirim `catatan-app.zip` ini.** AI wajib membaca `PROMPT_SERAH_TERIMA.md` dan `RIWAYAT.md` dari dalam ZIP sebelum mengubah kode.

## Status terkini

| Bagian | Isi | Status |
| --- | --- | --- |
| Catatan dan Tugas | editor kaya, tabel, kotak centang + pengingat, bagian lipat, gambar, Catatan Privat (PIN/sidik jari), cadangan dan pulihkan, ekspor TXT/MD/PDF/JPG | teruji di HP |
| Blok sisipan | suasana hati, tanggal, waktu, hitung mundur, kutipan | teruji di HP |
| Lembar kerja | rumus, format angka, warna bersyarat, validasi, gabung sel, diagram, 35 templat (termasuk 5 templat Centang), kotak centang di sel, salin/tempel rentang | teruji di HP |
| Paket Performa (P1 sampai P8) | buka lebih cepat, muat malas, gambar judul WebP, daftar periksa rilis | teruji di HP |
| Kelimaa AI (Rev 200 sampai 245) | chat, jalur dan model otomatis, ruang percakapan, simpan hasil ke catatan/tugas/pengingat/lembar kerja, Tulis AI di editor, Creative Studio, data aplikasi untuk AI (izin per sumber), Cari di web + sumber, Proyek, Insight mingguan, batas harian/bulanan, plafon server | dinyatakan aman oleh pengguna (12 Nov 2026, tanpa rincian per butir) |
| Tabel di balasan AI (Rev 246) | tabel Markdown tampil sebagai tabel bergulir, bisa disimpan jadi tabel catatan; Worker perlu ditempel ulang | **BERFUNGSI-BELUM-DIUJI di HP** (lihat `UJI_HP_RILIS.md` bagian F) |

Arti label: **teruji di HP** = pengguna sudah melapor aman. **BERFUNGSI-BELUM-DIUJI** = tes Node lulus, tetapi belum dicoba di HP. `npm test` dan `npm run build` **bukan** bukti APK sudah dibangun atau diuji di HP.

Hasil terakhir (Rev 405): semua tes lulus (2727 `ok`), build berhasil, audit ukuran "aman" (JS di bawah 1560 KB, Rev 415), audit Chromium kartu K1, layar kartu K2, dan kartu bergambar/lembar kerja K5 lulus, **bukan** uji HP.

## Jadwal ke depan

0. **Rev 417-420 (Paket SY = sinkronisasi HP-laptop lewat web; 417 checkpoint, 418 aksi `sync` di Worker, 419 mesin `sync.js` di aplikasi, 420 penghubung jaringan + penjalan `sync-jalan.js` (SY3a); hanya tes Node, belum ada UI/pemanggil):** versi web bisa edit, konflik = terbaru menang + salinan \"(konflik)\", Catatan Privat tidak ikut. Berikutnya SY3b (UI, pratinjau varian dulu) lalu SY3c (otomatis). Rincian: `PROMPT_SERAH_TERIMA.md`.
0. **Rev 396-405 (Paket Markdown + Kartu; Rev 401 = K2 layar "Gambar kartu" di menu Bagikan, Rev 402 = K3 pemilih warna bebas + riwayat, Rev 403 = K4 kirim WhatsApp + simpan galeri (native), Rev 405 = K5 penutup: audit kartu bergambar/lembar kerja + dokumen; paket selesai di kode, BERFUNGSI-BELUM-DIUJI):** M1 mesin Markdown, M2 Ekspor Markdown ke ZIP, M3 Impor Markdown, M4 gambar ikut diimpor (Rev 399 juga memperbaiki sintaks `impor-md-ui.js`), **K1 mesin kartu bagikan tanpa UI (Rev 400, `src/js/kartu.js`)**. Uji HP: **CA**, **CB**. Anggaran JS naik atas izin pengguna di Rev 401 (`jsMaks` 1540 KB). Tidak ada jadwal wajib berikutnya; menunggu uji HP CA, CB, CC.
0. **Rev 387-389:** Durasi Tunda alarm bisa diatur (global 5/10/15/30 menit, bawaan 10), TN1-TN4 = Rev 388-391; TN1 (Android) dan TN2 (JS) dikodekan, belum diuji HP; lihat `PROMPT_SERAH_TERIMA.md` 38.16.
0. **Rev 379-382, Rev 383, Rev 383b, Rev 384, Rev 385-386 (Paket Alarm berdering AL3b-AL6, selesai di kode, BERFUNGSI-BELUM-DIUJI):** layar alarm native 3G, pemilih Notifikasi/Alarm di baris centang, hitung mundur, tugas, sub-tugas, catatan, dan Two Pockets; audit Chromium AL4; toast APK lama di atas layar. Uji HP: bagian **BX**. Cek Java: `tools/cek_java_native.mjs`.
0. **Rev 374 (selesai di kode, OJ5):** dialog Pindai punya tombol manual **Coba jalur lain: <jalur>** (tanpa pindah otomatis, Worker tidak berubah); Rev 373: warna seleksi teks kustom. Uji HP: **BW**.
0. **Rev 362-364 (selesai di kode):** ketik `*teks* ` tebal dan `_teks_ ` miring gaya WhatsApp; Backspace sekali membatalkan. Anggaran naik atas izin pengguna. Uji HP: **BR**, **BS**, **BT**.
0. **Rev 360 (selesai di kode):** TAHAN ✦ di editor catatan memunculkan kapsul **Tulis AI**. Uji HP: **BQ**.
0. **Rev 358 (selesai di kode):** ketik `- ` di awal baris jadi bullet; Backspace sekali membatalkan. Uji HP: **BP**.
0. **Rev 339-344 + Rev 345 (selesai di kode, Paket Ketikan Tersembunyi):** format otomatis `[] ` / `1. ` (Rev 339), menu cepat `/` dan `!besok 9` (340-341), `[[` tautan antarcatatan (343), Panduan ketikan cepat di Setelan (344), audit penutup (345). Uji HP: bagian **BI-BM**. Rincian di `RIWAYAT.md`.
1. **Rev 309a-c (selesai):** Riwayat token AI: pencatat (`ai/riwayat-token.js`; 30 hari / maks. 200 entri, isi balasan tidak disimpan), tab Riwayat token di dialog Data aplikasi untuk AI (kartu, grafik 7 hari, log per hari, Hapus riwayat), audit Chromium akhir + daftar uji HP bagian **AP**. `jsMaks` 1320 KB dan `cssMaks` 242 KB atas izin pengguna. Hasil uji Node + Chromium, **bukan** bukti APK.
1. **Rev 306c (selesai di kode):** lampiran catatan di chat AI kini MENEMPEL untuk pertanyaan lanjutan (isi dibaca ulang dari catatan tiap kirim) sampai dilepas (x di chip), Obrolan baru/ganti/hapus riwayat, atau layar chat ditutup; keterangan di bawah balasan menyebut perkiraan token per pesan. Tanpa CSS/Worker baru. Paket 306 tuntas; tes `rev306c` (8), audit Chromium terang+gelap diperbarui. Uji HP: bagian AO butir 6 dan 11-14. Hasil uji Node + Chromium, **bukan** bukti APK.
2. **Rev 305 (selesai di kode):** 5 templat lembar kerja baru "Centang · ..." (Daftar tugas, Daftar belanja, Hadir dan upah, Tagihan dan denda, Persiapan acara): kotak centang dicampur rumus (COUNTIF/SUMIF/IF/COUNTIFS membaca TRUE/FALSE). Total 35 templat. Uji HP: bagian AN. Hanya tes Node, **bukan** bukti APK.
2. **Rev 303d (selesai di kode):** kotak centang tampil ☑/☐ di pratinjau pulau, kartu daftar, dan ekspor TXT/MD/PDF/JPG (salin TSV tetap TRUE/FALSE). Tanpa CSS baru. Uji HP: bagian AK. Berikutnya **303e**: ringkasan "3 dari 5 tercentang" (+ salin aturan antar rentang), lalu 303f audit akhir. Hanya tes Node, **bukan** bukti APK.
2. **Rev 303c (selesai di kode):** desain baru kotak centang di sel lembar kerja: kotak bersudut bulat digambar CSS (bukan glyph ☐☑), centang bertopeng SVG berwarna `--onac`, ikut tema terang dan gelap, animasi ketuk singkat. Batas CSS dinaikkan 232 -> 234 KB atas izin pengguna (sisa tinggal sekitar 490 byte). Uji HP: bagian AJ. Berikutnya **303d** (dulu disebut 303c): salin/tempel, ekspor, pratinjau, pencarian, ringkasan "3 dari 5 tercentang". Hasil uji Chromium, **bukan** bukti APK.
2. **Rev 303b (selesai di kode):** UI kotak centang sel (Menu sel > Dropdown > Kotak centang). Uji HP: bagian AI.
4. **Rev 303a (selesai di kode, tanpa UI):** model + mesin kotak centang sel. Hanya tes Node.
5. **Rev 302c (selesai di kode):** penutup Paket 302 (petunjuk Bekukan + audit akhir); hasil Chromium, **bukan** bukti APK.
6. **Rev 302b (selesai di kode):** Bekukan lewat Menu sel. Uji HP: bagian AH.
7. **Rev 302a (selesai di kode):** kolom beku lewat sticky, ditolak bila terlalu lebar. Uji HP: bagian AG.
8. **Rev 301c (selesai di kode):** audit Chromium dialog Olah catatan (301a-b: mesin dan UI). Uji HP: bagian AF.
9. **Rev 301b (selesai di kode):** ketuk Tulis AI TANPA blok teks = dialog Olah catatan (Ringkas, Usul judul, Rapikan) dengan pratinjau, Terapkan, dan Urungkan. Uji HP: bagian AF. Rev 301a = mesinnya (`ai/catatan.js`). Berikutnya Rev 301c (audit + penutup).
10. **Rev 300a-300c (selesai di kode):** Bekukan baris dan kolom di lembar kerja (Lainnya > Tampilan). Uji HP: bagian AD dan AE.
11. **Rev 249-299 (selesai di kode):** Paket Seleksi gaya Google Sheets, panel warna, Validasi data (rentang, warna per pilihan, mode Tolak, kriteria), Menu sel, 30 templat lembar kerja, Setelan baru, tombol Aa. Rincian per revisi ada di `RIWAYAT.md`; daftar uji HP per bagian ada di `UJI_HP_RILIS.md`.
12. **Rev 246 (selesai di kode):** tabel Markdown di balasan AI. Langkah Anda: tempel ulang `backend/cloudflare/worker.mjs` di Cloudflare (sekali), pasang APK baru, lalu uji bagian F (7 butir).
13. **Tidak ada pekerjaan wajib.** Kandidat opsional (hanya bila diminta): plafon bulanan di server (saat ini hanya harian, `HARD_DAILY_LIMIT`), kotak centang di sel lembar kerja, daftar pilihan dari tab lain, label **FINAL** setelah semua bagian uji HP aman, dan penandatanganan rilis tetap (D2, ditunda sesuai pilihan pengguna).

## Kelimaa AI dalam satu paragraf

Aplikasi mengirim permintaan ke Worker Cloudflare (alamat + passcode diisi di Setelan > KELIMAA AI). Worker memegang kunci penyedia dan memilih jalur serta model menurut jenis pekerjaan. Catatan Privat tidak pernah ikut dikirim; data aplikasi (tugas, judul catatan, proyek) hanya ikut bila sumbernya dinyalakan; AI tidak mengubah data tanpa konfirmasi dan tombol Urungkan. Panduan pemasangan: `backend/cloudflare/PANDUAN_WORKER.md`.

## Struktur utama

```text
src/
  index.html, css/styles.css
  js/                 modul aplikasi (js/ai/ = Kelimaa AI)
  img/                logo judul dan logo dialog keluar
backend/cloudflare/   worker.mjs + PANDUAN_WORKER.md
tests/*.test.mjs      397 berkas tes otomatis
scripts/              build web dan pembentuk proyek native Android
resources/android/    ikon aplikasi dan notifikasi
tools/                alat ukur dan pembuat aset ikon
assets/               aset sumber
package.json, capacitor.config.json
PROMPT_SERAH_TERIMA.md, RIWAYAT.md, UJI_HP_RILIS.md, README.md
```

`catatan-app.zip` sengaja berisi sumber dan alat proyek, bukan hasil build sementara. Folder `node_modules/`, `www/`, dan `android/` tidak disertakan; workflow GitHub membuat lingkungan build-nya sendiri.

## Tes dan build lokal

Dengan Node.js terpasang, dari folder hasil ekstrak:

```bash
npm test
npm run build
```

`npm test` menjalankan tes logika, keamanan, UI, integrasi, dan regresi. `npm run build` menyalin `src/` ke `www/`. Hasilnya belum merupakan APK.

## Build APK dari HP melalui GitHub

1. Buka repositori GitHub **Private** yang dipakai untuk Notes Kelimaa.
2. Ganti berkas `catatan-app.zip` di repositori dengan ZIP terbaru ini (nama harus persis `catatan-app.zip`), lalu commit.
3. Buka **Actions**, jalankan workflow **Build APK (dari ZIP)**.
4. Setelah selesai, unduh artefak `app-debug`, ekstrak ZIP artefaknya, lalu pasang APK.
6. **Ekspor cadangan dulu** sebelum mencopot aplikasi lama. Pemasangan debug baru dapat mengharuskan aplikasi lama dicopot, dan pencopotan menghapus data. Setelah memasang APK baru, pulihkan cadangan.
6. Periksa nomor versi di Setelan untuk memastikan APK yang terpasang sesuai.

Cadangan otomatis Android dimatikan (`allowBackup=false`), jadi ekspor cadangan manual di aplikasi adalah satu-satunya cara menyelamatkan data.

Workflow berada di repositori GitHub dan membaca `catatan-app.zip`; ZIP ini tidak menyertakan salinan workflow.

## Catatan penting

- Jangan menghapus modul atau mengubah keputusan arsitektur hanya karena tampak tidak dipakai. Periksa jalur impor, pemanggilan dinamis, tes, dan aturan serah-terima dulu.
- Jangan menyebut APK sudah dibangun atau diuji di HP hanya berdasarkan `npm test` atau `npm run build`.
- Setiap kali `worker.mjs` berubah, Worker di Cloudflare harus ditempel ulang; aplikasi saja tidak cukup.
- Kunci API dan passcode tidak boleh dikirim lewat chat dan tidak boleh ditanam di APK.
