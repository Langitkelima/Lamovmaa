// Menyalin ikon aplikasi (resources/android/res) ke proyek Android yang dibuat `npx cap add android`,
// lalu memasang kode native kecil (scripts/apply-native.mjs). Jalankan SETELAH `cap add android`.
// Jika folder Android belum ada, hanya memberi peringatan (build tidak dibatalkan).
import { existsSync, cpSync, readdirSync } from 'node:fs';
import { applyNative } from './apply-native.mjs';
const dest = 'android/app/src/main/res';
if (!existsSync(dest)) { console.warn('Folder ' + dest + ' belum ada; ikon tidak disalin.'); process.exit(0); }
cpSync('resources/android/res', dest, { recursive: true });
console.log('Ikon disalin ke ' + dest);
console.log('mipmap-xxxhdpi:', readdirSync(dest + '/mipmap-xxxhdpi').join(', '));
applyNative();
