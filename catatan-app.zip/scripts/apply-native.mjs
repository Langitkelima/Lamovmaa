// Memasang kode native kecil ke proyek Android hasil `npx cap add android` (dijalankan oleh apply-icons.mjs,
// jadi workflow tidak perlu diubah):
//  1. MainActivity.java: objek window.KelimaaNative untuk JavaScript aplikasi.
//       exit()      = tutup aplikasi TOTAL (tugas dihapus dari daftar terbaru, lalu proses dimatikan; tidak jalan di latar belakang)
//       openUrl(u)  = buka tautan http/https di peramban HP
//       takeShared() = (Rev 20) ambil teks yang dikirim aplikasi lain lewat Bagikan Android (JSON; dikosongkan setelah diambil)
//  2. Izin INTERNET di AndroidManifest bila belum ada (untuk pratinjau tautan).
//  (Rev 403) KartuShare.java + KelimaaNative.saveImageToGallery / sendImageToWhatsApp untuk kartu bagikan.
//  3. (Rev 20) Filter Bagikan teks (ACTION_SEND + text/plain) di activity utama, supaya "Notes Kelimaa" muncul di daftar Bagikan.
// Jika file yang dicari tidak ada, hanya memberi peringatan (build tidak dibatalkan).
import { existsSync, readFileSync, writeFileSync, readdirSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

export function mainActivitySource(pkg) {
  return `package ${pkg};

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.Gravity;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;
import org.json.JSONObject;

public class MainActivity extends BridgeActivity {

  /** Jembatan untuk JavaScript aplikasi: window.KelimaaNative */
  public class KelimaaBridge {
    @JavascriptInterface
    public void exit() {
      runOnUiThread(new Runnable() {
        @Override
        public void run() { closeAppTotal(); }
      });
    }

    @JavascriptInterface
    public void setBars(final String bg, final boolean darkBg) {
      runOnUiThread(new Runnable() {
        @Override
        public void run() {
          try { int c = Color.parseColor(bg); applyBars(c, darkBg); getSharedPreferences("kelimaa_bars", MODE_PRIVATE).edit().putInt("bg", c).putBoolean("dark", darkBg).apply(); } catch (Exception e) { Log.w("KelimaaNative", "setBars gagal", e); }
        }
      });
    }

    /** Rev 54: gradasi tepi atas/bawah halaman (daftar warna #RRGGBB dipisah koma, kiri ke kanan) untuk di belakang bar status/navigasi. */
    @JavascriptInterface
    public void setBarEdges(final String top, final String bottom) {
      runOnUiThread(new Runnable() {
        @Override
        public void run() {
          try {
            int[] t = parseColorList(top);
            int[] b = parseColorList(bottom);
            if (t == null || b == null) return;
            edgeTop = t; edgeBottom = b;
            getSharedPreferences("kelimaa_bars", MODE_PRIVATE).edit().putString("etop", top).putString("ebot", bottom).apply();
            applyEdges();
          } catch (Exception e) { Log.w("KelimaaNative", "setBarEdges gagal", e); }
        }
      });
    }

    /** Rev 20: JS menarik teks Bagikan yang menunggu (JSON {text, subject, reject}), lalu dikosongkan. Kosong = tidak ada. */
    @JavascriptInterface
    public String takeShared() {
      try {
        synchronized (SHARE_LOCK) {
          String p = sharedPayload;
          sharedPayload = null;
          return p == null ? "" : p;
        }
      } catch (Exception e) {
        return "";
      }
    }

    // Rev 21: API AndroidAPI untuk menjadwalkan notifikasi lokal.
    @JavascriptInterface
    public String scheduleNotification(String id, String title, String message, long delayMs, long repeatMs) {
      try {
        final String result = ReminderScheduler.schedule(MainActivity.this, id, title, message, delayMs, repeatMs);
        if ("inexact_alarm".equals(result)) runOnUiThread(new Runnable() { @Override public void run() {
          try { if (getBridge()!=null && getBridge().getWebView()!=null) getBridge().getWebView().evaluateJavascript("(function(){try{if(window.onAndroidEvent)window.onAndroidEvent('scheduledNotificationResult',{warning:'inexact_alarm'})}catch(e){}})()", null); } catch(Exception ignore) { }
        }});
        return result;
      } catch (Exception e) { Log.w("KelimaaNative", "scheduleNotification gagal", e); return "error"; }
    }

    @JavascriptInterface
    public void cancelScheduledNotification(String id) {
      try { ReminderScheduler.cancel(MainActivity.this, id); }
      catch (Exception e) { Log.w("KelimaaNative", "cancelScheduledNotification gagal", e); }
    }

    @JavascriptInterface
    public void cancelAllScheduledNotifications() {
      try { ReminderScheduler.cancelAll(MainActivity.this); }
      catch (Exception e) { Log.w("KelimaaNative", "cancelAllScheduledNotifications gagal", e); }
    }

    @JavascriptInterface
    public boolean canScheduleExactAlarms() {
      try { return android.os.Build.VERSION.SDK_INT < 31 || ((android.app.AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms(); }
      catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public void openExactAlarmSettings() {
      try {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
          Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()));
          i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        }
      } catch (Exception e) { Log.w("KelimaaNative", "openExactAlarmSettings gagal", e); }
    }

    // Rev 377 (AL1): mode ALARM berdering. scheduleNotification (notifikasi biasa) di atas TIDAK diubah.
    @JavascriptInterface
    public String scheduleAlarm(String id, String title, String message, long delayMs, long repeatMs) {
      try { return ReminderScheduler.schedule(MainActivity.this, id, title, message, delayMs, repeatMs, "alarm"); }
      catch (Exception e) { Log.w("KelimaaNative", "scheduleAlarm gagal", e); return "error"; }
    }

    @JavascriptInterface
    public boolean canUseFullScreenAlarm() {
      try { return android.os.Build.VERSION.SDK_INT < 34 || ((android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE)).canUseFullScreenIntent(); }
      catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public void openFullScreenAlarmSettings() {
      try {
        if (android.os.Build.VERSION.SDK_INT >= 34) {
          Intent i = new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:" + getPackageName()));
          i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        }
      } catch (Exception e) { Log.w("KelimaaNative", "openFullScreenAlarmSettings gagal", e); }
    }

    // Rev 379 (AL3b-1): tema aplikasi untuk layar alarm ('light' | 'dark' | 'auto'); disimpan di SharedPreferences, dibaca AlarmActivity.
    @JavascriptInterface
    public void setAlarmTheme(String theme) {
      try {
        String t = "dark".equals(theme) || "light".equals(theme) ? theme : "auto";
        getSharedPreferences("kelimaa_alarm_ui", 0).edit().putString("theme", t).apply();
      } catch (Exception e) { Log.w("KelimaaNative", "setAlarmTheme gagal", e); }
    }

    // Rev 388 (TN1): lama Tunda alarm (menit: 5, 10, 15, 30; selain itu menjadi 10); disimpan di SharedPreferences, dibaca AlarmRinger saat alarm berbunyi.
    @JavascriptInterface
    public void setAlarmSnooze(int minutes) {
      try {
        getSharedPreferences("kelimaa_alarm_ui", 0).edit().putInt("snooze", AlarmRinger.cleanSnooze(minutes)).apply();
      } catch (Exception e) { Log.w("KelimaaNative", "setAlarmSnooze gagal", e); }
    }

    // Rev 403 (K4): kartu bagikan. Simpan ke galeri (Pictures/NotesKelimaa) dan kirim ke WhatsApp; semua kerja ada di KartuShare. Hasil: "ok" / "tidak_didukung" / "tidak_ada" / "error".
    @JavascriptInterface
    public String saveImageToGallery(String b64, String name) {
      try { return KartuShare.saveToGallery(MainActivity.this, b64, name); }
      catch (Throwable e) { Log.w("KelimaaNative", "saveImageToGallery gagal", e); return "error"; }
    }

    @JavascriptInterface
    public String sendImageToWhatsApp(String fileUri) {
      try { return KartuShare.sendToWhatsApp(MainActivity.this, fileUri); }
      catch (Throwable e) { Log.w("KelimaaNative", "sendImageToWhatsApp gagal", e); return "error"; }
    }

    @JavascriptInterface
    public void requestNotificationPermission() {
      try { runOnUiThread(new Runnable() { @Override public void run() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
          requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 402);
      }}); } catch (Exception e) { Log.w("KelimaaNative", "requestNotificationPermission gagal", e); }
    }

    @JavascriptInterface
    public String takeReminder() {
      try { synchronized (REMINDER_LOCK) { String p = reminderPayload; reminderPayload = null; return p == null ? "" : p; } }
      catch (Exception e) { return ""; }
    }

    @JavascriptInterface
    public void openUrl(final String url) {
      runOnUiThread(new Runnable() {
        @Override
        public void run() {
          try {
            Uri uri = Uri.parse(url);
            String scheme = uri.getScheme();
            if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) {
              return;
            }
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
          } catch (Exception e) {
            Log.w("KelimaaNative", "openUrl gagal", e);
          }
        }
      });
    }
  }

  // Pembunuh proses yang tertunda. Disimpan statis supaya bisa DIBATALKAN bila aplikasi dibuka lagi sebelum jedanya habis
  // (tanpa ini, membuka ulang dalam ~1 detik setelah menutup membuat aplikasi langsung tertutup sendiri).
  private static final Handler KILL_HANDLER = new Handler(Looper.getMainLooper());
  private static Runnable killTask = null;

  /** Tutup aplikasi TOTAL: tugas dihapus dari daftar terbaru, lalu proses dimatikan setelah jeda singkat. */
  private void closeAppTotal() {
    finishAndRemoveTask();
    // Jeda singkat agar penyimpanan WebView sempat menulis ke disk.
    if (killTask != null) KILL_HANDLER.removeCallbacks(killTask);
    killTask = new Runnable() {
      @Override
      public void run() {
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
      }
    };
    KILL_HANDLER.postDelayed(killTask, 1200);
  }

  // ---- Rev 21: notifikasi diketuk -> JavaScript menarik ID sumber ----
  private static final Object REMINDER_LOCK = new Object();
  private static String reminderPayload = null;
  private void captureReminder(Intent it) {
    try { if (it == null) return; String id = it.getStringExtra("kelimaa_reminder_id"); if (id != null && !id.trim().isEmpty()) synchronized (REMINDER_LOCK) { reminderPayload = id; } }
    catch (Exception e) { Log.w("KelimaaNative", "captureReminder gagal", e); }
  }

  // ---- Rev 20: terima teks dari Bagikan Android ----
  // Teks disimpan statis sampai JavaScript mengambilnya (takeShared). Jalur tarik, bukan dorong: saat buka dingin JS belum tentu siap.
  private static final Object SHARE_LOCK = new Object();
  private static String sharedPayload = null;

  /** Baca Intent Bagikan (ACTION_SEND teks). Semua dibungkus try/catch: gagal = aplikasi tetap terbuka normal tanpa catatan baru. */
  private void captureShare(Intent it) {
    try {
      if (it == null || !Intent.ACTION_SEND.equals(it.getAction())) return;
      // Dibuka ulang dari daftar aplikasi terbaru: Android memutar ulang Intent lama, jangan diproses dua kali.
      if ((it.getFlags() & Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0) return;
      CharSequence t = it.getCharSequenceExtra(Intent.EXTRA_TEXT);
      CharSequence s = it.getCharSequenceExtra(Intent.EXTRA_SUBJECT);
      String text = t == null ? "" : t.toString();
      String subject = s == null ? "" : s.toString();
      if (text.length() > 100000) text = text.substring(0, 100000); // pagar kasar; JS yang memotong ke batas catatan
      if (subject.length() > 1000) subject = subject.substring(0, 1000);
      JSONObject o = new JSONObject();
      o.put("text", text);
      o.put("subject", subject);
      o.put("reject", text.trim().length() == 0); // mis. hanya gambar/berkas: JS memberi tahu pengguna
      synchronized (SHARE_LOCK) { sharedPayload = o.toString(); }
    } catch (Exception e) {
      Log.w("KelimaaNative", "captureShare gagal", e);
    }
  }

  /** Aplikasi sudah terbuka lalu pengguna memakai Bagikan lagi (launchMode singleTask): Intent baru masuk di sini. */
  @Override
  protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    try {
      setIntent(intent);
      captureShare(intent);
      captureReminder(intent);
      boolean waiting;
      synchronized (SHARE_LOCK) { waiting = sharedPayload != null; }
      if (getBridge() != null && getBridge().getWebView() != null) {
        try { getBridge().getWebView().evaluateJavascript("(function(){try{if(window.__kelimaaReminderOpened)window.__kelimaaReminderOpened()}catch(e){}})()", null); } catch (Exception ignore) { }
      }
      if (waiting && getBridge() != null && getBridge().getWebView() != null) {
        getBridge().getWebView().evaluateJavascript(
            "(function(){try{if(window.__kelimaaShared)window.__kelimaaShared()}catch(e){}})()", null);
      }
    } catch (Exception e) {
      Log.w("KelimaaNative", "onNewIntent gagal", e);
    }
  }

  private int[] edgeTop = null;
  private int[] edgeBottom = null;
  private int baseBarColor = 0xFF0B1120;

  /** "#RRGGBB,#RRGGBB,..." menjadi larik warna (minimal 2); salah format = null. */
  private int[] parseColorList(String csv) {
    try {
      if (csv == null) return null;
      String[] p = csv.split(",");
      if (p.length < 2 || p.length > 12) return null;
      int[] out = new int[p.length];
      for (int i = 0; i < p.length; i++) out[i] = Color.parseColor(p[i].trim());
      return out;
    } catch (Exception e) {
      return null;
    }
  }

  /** Rev 54: bar status/navigasi tembus pandang; yang terlihat di belakangnya = gradasi tepi halaman (jalur mundur: warna rata dari applyBars). */
  private void applyEdges() {
    try {
      if (edgeTop == null || edgeBottom == null) return;
      GradientDrawable top = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, edgeTop);
      GradientDrawable bot = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, edgeBottom);
      LayerDrawable ld = new LayerDrawable(new Drawable[] { new ColorDrawable(baseBarColor), top, bot });
      int h = (int) (160 * getResources().getDisplayMetrics().density);
      ld.setLayerGravity(1, Gravity.TOP);
      ld.setLayerHeight(1, h);
      ld.setLayerGravity(2, Gravity.BOTTOM);
      ld.setLayerHeight(2, h);
      getWindow().setBackgroundDrawable(ld);
      View content = findViewById(android.R.id.content);
      if (content != null) content.setBackgroundColor(Color.TRANSPARENT);
      getWindow().setStatusBarColor(Color.TRANSPARENT);
      getWindow().setNavigationBarColor(Color.TRANSPARENT);
    } catch (Exception e) {
      Log.w("KelimaaNative", "applyEdges gagal, memakai warna rata", e);
    }
  }

  /** Warna latar di belakang bar status/navigasi + warna ikonnya, mengikuti tema aplikasi. */
  private void applyBars(final int color, final boolean darkBg) {
    try {
      getWindow().setBackgroundDrawable(new ColorDrawable(color));
      // Bar status dan bar navigasi memakai warna tema (bukan abu-abu bawaan tema Android) dan tanpa lapisan gelap otomatis.
      getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
      getWindow().setStatusBarColor(color);
      getWindow().setNavigationBarColor(color);
      if (Build.VERSION.SDK_INT >= 29) {
        getWindow().setNavigationBarContrastEnforced(false);
        getWindow().setStatusBarContrastEnforced(false);
      }
      View content = findViewById(android.R.id.content);
      if (content != null) content.setBackgroundColor(color);
      WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
      if (c != null) {
        c.setAppearanceLightStatusBars(!darkBg);
        c.setAppearanceLightNavigationBars(!darkBg);
      }
      baseBarColor = color;
      applyEdges();
    } catch (Exception e) {
      Log.w("KelimaaNative", "applyBars gagal", e);
    }
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    // Aplikasi dibuka lagi sebelum proses lama sempat dimatikan: batalkan pembunuhan tertunda.
    if (killTask != null) { KILL_HANDLER.removeCallbacks(killTask); killTask = null; }
    super.onCreate(savedInstanceState);
    if (getBridge() != null && getBridge().getWebView() != null) {
      KelimaaBridge bridge = new KelimaaBridge();
      getBridge().getWebView().addJavascriptInterface(bridge, "KelimaaNative");
      getBridge().getWebView().addJavascriptInterface(bridge, "AndroidAPI");
    }
    // Izin notifikasi diminta saat pengguna memasang pengingat pertama, bukan saat aplikasi baru dibuka.
    // Rev 20: dibuka dingin lewat Bagikan. savedInstanceState != null = Activity dibuat ulang (putar layar dsb.), bukan Bagikan baru.
    if (savedInstanceState == null) { captureShare(getIntent()); captureReminder(getIntent()); }
    // Tombol Kembali HP dan gestur geser: tanya JavaScript dulu (tutup dialog/editor/submenu).
    // Bila JavaScript membalas "exit" (sudah di layar utama), aplikasi ditutup total TANPA dialog.
    getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
      @Override
      public void handleOnBackPressed() {
        try {
          getBridge().getWebView().evaluateJavascript(
              "(function(){try{return window.__kelimaaBack?window.__kelimaaBack():'exit'}catch(e){return 'exit'}})()",
              new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String v) {
                  // Hanya "handled" yang berarti JS sudah menanganinya; selain itu (exit, null, halaman macet) = tutup,
                  // supaya tombol Kembali tidak pernah mati di HP mana pun.
                  if (v == null || !v.contains("handled")) closeAppTotal();
                }
              });
        } catch (Exception e) {
          closeAppTotal();
        }
      }
    });
    // Ruang aman otomatis di SEMUA HP: aplikasi sendiri yang menghitung tinggi bar status, bar navigasi/gestur,
    // takik kamera, dan keyboard, lalu memberi jarak itu sekali saja di tingkat jendela. WebView menerima area
    // yang sudah bersih, jadi CSS tidak perlu menebak (tidak ada hitungan ganda).
    try {
      WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
      final View content = findViewById(android.R.id.content);
      ViewCompat.setOnApplyWindowInsetsListener(content, new OnApplyWindowInsetsListener() {
        @Override
        public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
          Insets b = insets.getInsets(WindowInsetsCompat.Type.systemBars()
              | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
          v.setPadding(b.left, b.top, b.right, b.bottom);
          return WindowInsetsCompat.CONSUMED;
        }
      });
      ViewCompat.requestApplyInsets(content);
    } catch (Exception e) {
      Log.w("KelimaaNative", "inset gagal, memakai bawaan sistem", e);
      try { WindowCompat.setDecorFitsSystemWindows(getWindow(), true); } catch (Exception ignore) { }
    }
    // Warna awal sebelum JavaScript jalan (mencegah kilat putih): ikut mode gelap/terang sistem.
    boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    // Pakai warna tema terakhir yang tersimpan (pilihan tema di aplikasi bisa beda dari mode sistem), supaya tidak ada kilat terang.
    try {
      android.content.SharedPreferences sp = getSharedPreferences("kelimaa_bars", MODE_PRIVATE);
      try { edgeTop = parseColorList(sp.getString("etop", null)); edgeBottom = parseColorList(sp.getString("ebot", null)); } catch (Exception ignore) { }
      if (sp.contains("bg")) applyBars(sp.getInt("bg", 0xFF0B1120), sp.getBoolean("dark", true));
      else applyBars(night ? 0xFF0B1120 : 0xFFEDF2F9, night);
    } catch (Exception e) {
      Log.w("KelimaaNative", "warna awal gagal", e);
      applyBars(night ? 0xFF0B1120 : 0xFFEDF2F9, night);
    }
  }
}
`;
}


export function reminderSchedulerSource(pkg) { return `package ${pkg};
import android.app.AlarmManager; import android.app.PendingIntent; import android.content.Context; import android.content.Intent; import android.os.Build; import android.util.Log; import org.json.JSONArray; import org.json.JSONObject;
public final class ReminderScheduler {
  private static final String PREF="kelimaa_reminders", KEY="items";
  private ReminderScheduler() {}
  static JSONObject all(Context c) { try { return new JSONObject(c.getSharedPreferences(PREF,0).getString(KEY,"{}")); } catch(Exception e) { return new JSONObject(); } }
  static void putAll(Context c, JSONObject o) { try { c.getSharedPreferences(PREF,0).edit().putString(KEY,o.toString()).apply(); } catch(Exception e) { Log.w("KelimaaReminder","save gagal",e); } }
  static String schedule(Context c,String id,String title,String message,long delay,long repeat) throws Exception { return schedule(c,id,title,message,delay,repeat,"notif"); }
  static String schedule(Context c,String id,String title,String message,long delay,long repeat,String mode) throws Exception {
    if(id==null || id.trim().isEmpty()) return "error";
    if(Build.VERSION.SDK_INT>=24 && !((android.app.NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).areNotificationsEnabled()) return "permission_denied";
    long at=System.currentTimeMillis()+Math.max(1000L,delay);
    JSONObject o=all(c); JSONObject x=new JSONObject(); x.put("id",id); x.put("title",title==null?"Pengingat":title); x.put("message",message==null?"":message); x.put("at",at); x.put("repeat",Math.max(0L,repeat)); x.put("mode","alarm".equals(mode)?"alarm":"notif"); o.put(id,x); putAll(c,o);
    return scheduleAt(c,x) ? "exact" : "inexact_alarm";
  }
  static boolean scheduleAt(Context c,JSONObject x) throws Exception {
    String id=x.getString("id"); Intent i=new Intent(c,ReminderReceiver.class); i.putExtra("id",id); i.putExtra("title",x.optString("title","Pengingat")); i.putExtra("message",x.optString("message","")); i.putExtra("repeat",x.optLong("repeat",0)); i.putExtra("mode",x.optString("mode","notif"));
    PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); long at=x.optLong("at",System.currentTimeMillis()+1000); boolean exact=Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms();
    if("alarm".equals(x.optString("mode","notif"))) { try { Intent open=new Intent(c,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP); PendingIntent show=PendingIntent.getActivity(c,("show:"+id).hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE); am.setAlarmClock(new AlarmManager.AlarmClockInfo(at,show),pi); return true; } catch(Exception ae) { Log.w("KelimaaReminder","setAlarmClock gagal, jatuh ke alarm biasa",ae); } }
    if(exact) { if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.setExact(AlarmManager.RTC_WAKEUP,at,pi); }
    else { if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi); }
    return exact;
  }
  static void cancel(Context c,String id) { try { JSONObject o=all(c); o.remove(id); putAll(c,o); Intent i=new Intent(c,ReminderReceiver.class); PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE); if(pi!=null) { ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi); pi.cancel(); } } catch(Exception e) { Log.w("KelimaaReminder","cancel gagal",e); } }
  static void cancelAll(Context c) { try { JSONObject o=all(c); JSONArray names=o.names(); if(names!=null) for(int n=0;n<names.length();n++){ String id=names.getString(n); Intent i=new Intent(c,ReminderReceiver.class); PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE); if(pi!=null){ ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi); pi.cancel(); } } putAll(c,new JSONObject()); } catch(Exception e) { Log.w("KelimaaReminder","cancelAll gagal",e); } }
  static void fired(Context c,String id,long repeat) { try { JSONObject o=all(c); JSONObject x=o.optJSONObject(id); if(x==null) return; if(repeat>0) { long next=x.optLong("at",System.currentTimeMillis())+repeat, now=System.currentTimeMillis(); if(next<=now) next += ((now-next)/repeat+1)*repeat; x.put("at",next); putAll(c,o); scheduleAt(c,x); } else { o.remove(id); putAll(c,o); } } catch(Exception e) { Log.w("KelimaaReminder","reschedule gagal",e); } }
  static void snooze(Context c,String id,String title,String message,int minutes) { try { String base=id.startsWith("snz:")?id.substring(4):id; schedule(c,"snz:"+base,title,message,minutes*60000L,0L,"alarm"); } catch(Exception e) { Log.w("KelimaaReminder","tunda gagal",e); } }
  static void restore(Context c) { try { JSONObject o=all(c); JSONArray names=o.names(); if(names==null) return; long now=System.currentTimeMillis(); for(int n=0;n<names.length();n++){ String id=names.getString(n); JSONObject x=o.optJSONObject(id); if(x==null) continue; long at=x.optLong("at",0), rep=x.optLong("repeat",0); if(at<=now && rep>0){ at += ((now-at)/rep+1)*rep; x.put("at",at); } if(at<=now){ o.remove(id); continue; } scheduleAt(c,x); } putAll(c,o); } catch(Exception e) { Log.w("KelimaaReminder","restore gagal",e); } }
}
`; }
export function reminderReceiverSource(pkg) { return `package ${pkg};
import android.Manifest; import android.app.Notification; import android.app.NotificationChannel; import android.app.NotificationManager; import android.app.PendingIntent; import android.content.BroadcastReceiver; import android.content.Context; import android.content.Intent; import android.content.pm.PackageManager; import android.os.Build; import android.util.Log;
public class ReminderReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c,Intent i) { try {
    String id=i.getStringExtra("id"), title=i.getStringExtra("title"), message=i.getStringExtra("message"); long repeat=i.getLongExtra("repeat",0);
    if(id==null) return;
    if("alarm".equals(i.getStringExtra("mode"))) { AlarmRinger.ring(c,id,title,message); ReminderScheduler.fired(c,id,repeat); return; }
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); String channel="kelimaa_reminders";
    if(Build.VERSION.SDK_INT>=26 && nm.getNotificationChannel(channel)==null) nm.createNotificationChannel(new NotificationChannel(channel,"Pengingat",NotificationManager.IMPORTANCE_DEFAULT));
    Intent open=new Intent(c,MainActivity.class); open.putExtra("kelimaa_reminder_id",id); open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent content=PendingIntent.getActivity(c,id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
    int icon=0; try { icon=c.getResources().getIdentifier("ic_stat_kelimaa","drawable",c.getPackageName()); } catch(Exception ie) { icon=0; }
    b.setSmallIcon(icon!=0?icon:android.R.drawable.ic_popup_reminder); try { b.setColor(0xFF6B8EEB); } catch(Exception ce) { /* warna aksen opsional */ }
    b.setContentTitle(title==null?"Pengingat":title).setContentText(message==null?"":message).setAutoCancel(true).setContentIntent(content);
    if(Build.VERSION.SDK_INT<26) b.setPriority(Notification.PRIORITY_DEFAULT);
    if(Build.VERSION.SDK_INT<33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED) nm.notify(id.hashCode(),b.build());
    ReminderScheduler.fired(c,id,repeat);
  } catch(Exception e) { Log.w("KelimaaReminder","notifikasi gagal",e); } }
}
`; }
export function reminderBootReceiverSource(pkg) { return `package ${pkg};
import android.content.BroadcastReceiver; import android.content.Context; import android.content.Intent; import android.util.Log;
public class ReminderBootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i) { try { if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()) || "android.intent.action.MY_PACKAGE_REPLACED".equals(i.getAction())) ReminderScheduler.restore(c); } catch(Exception e) { Log.w("KelimaaReminder","restore boot gagal",e); } } }
`; }
export function alarmRingerSource(pkg) { return `package ${pkg};
import android.app.Notification; import android.app.NotificationChannel; import android.app.NotificationManager; import android.app.PendingIntent; import android.content.Context; import android.content.Intent; import android.media.AudioAttributes; import android.media.AudioManager; import android.media.RingtoneManager; import android.net.Uri; import android.os.Build; import android.util.Log;
// Rev 377 (AL1): alarm berdering = notifikasi saluran Alarm (nada alarm HP, getar, bunyi berulang lewat FLAG_INSISTENT) + layar penuh (AlarmActivity) + Tunda/Matikan.
// Selain itu satu notifikasi "jejak" yang diam dan TETAP ada sesudah bunyi berhenti sendiri (sekitar 2 menit) atau terlewat.
public final class AlarmRinger {
  static final String CH_ALARM="kelimaa_alarm", CH_TRACE="kelimaa_alarm_jejak", ACT_SNOOZE="kelimaa.alarm.SNOOZE", ACT_STOP="kelimaa.alarm.STOP";
  static final int SNOOZE_MIN=10; static final long RING_MS=120000L; static final String PREFS="kelimaa_alarm_ui", KEY_SNOOZE="snooze";
  // Rev 388 (TN1): lama Tunda dibaca saat alarm berbunyi (SharedPreferences, diisi jembatan setAlarmSnooze); hanya 5, 10, 15, 30 menit; selain itu = bawaan 10.
  static int cleanSnooze(int m) { return (m==5||m==10||m==15||m==30)?m:SNOOZE_MIN; }
  static int snoozeMin(Context c) { try { return cleanSnooze(c.getSharedPreferences(PREFS,0).getInt(KEY_SNOOZE,SNOOZE_MIN)); } catch(Exception e) { return SNOOZE_MIN; } }
  private AlarmRinger() {}
  static int ringId(String id) { return ("ring:"+id).hashCode(); }
  static int traceId(String id) { return ("jejak:"+id).hashCode(); }
  static void channels(NotificationManager nm) {
    if(Build.VERSION.SDK_INT<26) return;
    if(nm.getNotificationChannel(CH_ALARM)==null) {
      NotificationChannel ch=new NotificationChannel(CH_ALARM,"Alarm",NotificationManager.IMPORTANCE_HIGH);
      Uri tone=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM); if(tone==null) tone=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
      ch.setSound(tone,new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
      ch.enableVibration(true); ch.setVibrationPattern(new long[]{0,600,400,600,400,600}); ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
      nm.createNotificationChannel(ch);
    }
    if(nm.getNotificationChannel(CH_TRACE)==null) {
      NotificationChannel ch=new NotificationChannel(CH_TRACE,"Jejak alarm",NotificationManager.IMPORTANCE_LOW);
      ch.setSound(null,null); ch.enableVibration(false); nm.createNotificationChannel(ch);
    }
  }
  static PendingIntent action(Context c,String act,String id,String title,String message) {
    Intent i=new Intent(c,AlarmActionReceiver.class); i.setAction(act); i.putExtra("id",id); i.putExtra("title",title); i.putExtra("message",message);
    return PendingIntent.getBroadcast(c,(act+id).hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }
  static PendingIntent screen(Context c,String id,String title,String message) {
    Intent i=new Intent(c,AlarmActivity.class); i.putExtra("id",id); i.putExtra("title",title); i.putExtra("message",message); i.putExtra("t0",System.currentTimeMillis()); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    return PendingIntent.getActivity(c,("layar:"+id).hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }
  static int icon(Context c) { int icon=0; try { icon=c.getResources().getIdentifier("ic_stat_kelimaa","drawable",c.getPackageName()); } catch(Exception e) { icon=0; } return icon!=0?icon:android.R.drawable.ic_popup_reminder; }
  static void ring(Context c,String id,String title,String message) { try {
    NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); channels(nm);
    String t=title==null?"Alarm":title, m=message==null?"":message;
    Intent open=new Intent(c,MainActivity.class); open.putExtra("kelimaa_reminder_id",id); open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent openPi=PendingIntent.getActivity(c,id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    Notification.Builder tb=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH_TRACE):new Notification.Builder(c);
    tb.setSmallIcon(icon(c)).setContentTitle(t).setContentText(m).setAutoCancel(true).setContentIntent(openPi);
    if(Build.VERSION.SDK_INT<26) tb.setPriority(Notification.PRIORITY_LOW);
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH_ALARM):new Notification.Builder(c);
    PendingIntent scr=screen(c,id,t,m);
    b.setSmallIcon(icon(c)).setContentTitle(t).setContentText(m).setCategory(Notification.CATEGORY_ALARM).setOngoing(true).setAutoCancel(false).setContentIntent(scr).setFullScreenIntent(scr,true);
    b.addAction(android.R.drawable.ic_popup_reminder,"Tunda "+snoozeMin(c)+" mnt",action(c,ACT_SNOOZE,id,t,m));
    b.addAction(android.R.drawable.ic_menu_close_clear_cancel,"Matikan",action(c,ACT_STOP,id,t,m));
    if(Build.VERSION.SDK_INT>=26) b.setTimeoutAfter(RING_MS);
    else { b.setPriority(Notification.PRIORITY_MAX); b.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),AudioManager.STREAM_ALARM); b.setVibrate(new long[]{0,600,400,600,400,600}); }
    Notification n=b.build(); n.flags |= Notification.FLAG_INSISTENT;
    boolean allowed=Build.VERSION.SDK_INT<33 || c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED;
    if(allowed) { nm.notify(traceId(id),tb.build()); nm.notify(ringId(id),n); }
  } catch(Exception e) { Log.w("KelimaaAlarm","alarm gagal",e); } }
  static void stop(Context c,String id) { try { NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); nm.cancel(ringId(id)); nm.cancel(traceId(id)); } catch(Exception e) { Log.w("KelimaaAlarm","matikan gagal",e); } }
  static void snooze(Context c,String id,String title,String message) { stop(c,id); ReminderScheduler.snooze(c,id,title,message,snoozeMin(c)); }
}
`; }
export function alarmActionReceiverSource(pkg) { return `package ${pkg};
import android.content.BroadcastReceiver; import android.content.Context; import android.content.Intent; import android.util.Log;
public class AlarmActionReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i) { try {
  String id=i.getStringExtra("id"); if(id==null) return;
  if(AlarmRinger.ACT_SNOOZE.equals(i.getAction())) AlarmRinger.snooze(c,id,i.getStringExtra("title"),i.getStringExtra("message")); else AlarmRinger.stop(c,id);
} catch(Exception e) { Log.w("KelimaaAlarm","aksi alarm gagal",e); } } }
`; }
export function alarmActivitySource(pkg) { return `package ${pkg};
import android.app.Activity; import android.content.Context; import android.content.Intent; import android.content.res.Configuration; import android.graphics.Canvas; import android.graphics.Paint; import android.graphics.RectF; import android.graphics.Typeface; import android.graphics.drawable.GradientDrawable; import android.os.Build; import android.os.Bundle; import android.os.Handler; import android.os.Looper; import android.provider.Settings; import android.view.Gravity; import android.view.View; import android.view.WindowManager; import android.widget.Button; import android.widget.FrameLayout; import android.widget.LinearLayout; import android.widget.TextView; import java.text.SimpleDateFormat; import java.util.Date; import java.util.Locale;
// Rev 377 (AL1) + Rev 379 (AL3b-1): layar alarm penuh di atas layar kunci. Rancangan 3G: ikut tema aplikasi (terang/gelap/otomatis lewat jembatan setAlarmTheme),
// cincin sisa waktu bunyi, judul HURUF KAPITAL, tombol Matikan (utama) dan Tunda. Digambar dari kode (tanpa berkas layout).
public class AlarmActivity extends Activity {
  static final String PREFS="kelimaa_alarm_ui", KEY_THEME="theme";
  private final Handler handler=new Handler(Looper.getMainLooper());
  private Runnable tick; private RingView ring; private TextView left, dotLabel; private View dot; private long t0; private boolean reduce=false, dotOn=true;
  static final class RingView extends View {
    private final Paint track=new Paint(), arc=new Paint(); private final RectF box=new RectF(); private float frac=1f; private final float w;
    RingView(Context c,int trackColor,int arcColor,float d) { super(c); w=9f*d;
      track.setAntiAlias(true); track.setStyle(Paint.Style.STROKE); track.setStrokeWidth(w); track.setColor(trackColor);
      arc.setAntiAlias(true); arc.setStyle(Paint.Style.STROKE); arc.setStrokeWidth(w); arc.setStrokeCap(Paint.Cap.ROUND); arc.setColor(arcColor); }
    void setFrac(float f) { frac=f<0f?0f:(f>1f?1f:f); invalidate(); }
    @Override protected void onDraw(Canvas c) { float h=w/2f; box.set(h,h,getWidth()-h,getHeight()-h); c.drawArc(box,-90f,360f,false,track); if(frac>0f) c.drawArc(box,-90f,360f*frac,false,arc); }
  }
  @Override protected void onCreate(Bundle b) { super.onCreate(b);
    if(Build.VERSION.SDK_INT>=27) { setShowWhenLocked(true); setTurnScreenOn(true); }
    else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    show(getIntent());
  }
  @Override protected void onNewIntent(Intent in) { super.onNewIntent(in); setIntent(in); show(in); }
  @Override protected void onDestroy() { super.onDestroy(); if(tick!=null) handler.removeCallbacks(tick); }
  private boolean night() {
    String t="auto"; try { t=getSharedPreferences(PREFS,0).getString(KEY_THEME,"auto"); } catch(Exception e) { t="auto"; }
    if("dark".equals(t)) return true; if("light".equals(t)) return false;
    return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
  }
  private void round(View v,int color,float radius) { GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); v.setBackground(g); }
  private Button button(String text,int bg,int fg,float d) { Button x=new Button(this); x.setText(text); x.setTextSize(17); x.setAllCaps(false); x.setTextColor(fg); x.setTypeface(Typeface.DEFAULT_BOLD); x.setPadding((int)(16*d),(int)(18*d),(int)(16*d),(int)(18*d)); round(x,bg,16*d); return x; }
  private void show(Intent in) {
    final String id=in.getStringExtra("id"), title=in.getStringExtra("title"), message=in.getStringExtra("message"); final Activity self=this;
    t0=in.getLongExtra("t0",0L); if(t0<=0L) t0=System.currentTimeMillis();
    if(tick!=null) handler.removeCallbacks(tick);
    try { reduce=Settings.Global.getFloat(getContentResolver(),Settings.Global.ANIMATOR_DURATION_SCALE,1f)==0f; } catch(Exception e) { reduce=false; }
    boolean dk=night();
    final int bg=dk?0xFF0B1120:0xFFEDF2F9, ink=dk?0xFFE4EAF6:0xFF1E2A3D, mut=dk?0xFF8D9AB5:0xFF4A5A76, ac=dk?0xFF7C9CF0:0xFF6B8EEB, acs=dk?0xFF1A2845:0xFFE1E9FB, acText=dk?0xFF9DB6F5:0xFF3F63C4, onac=dk?0xFF0B1120:0xFF0F1B3A, track=dk?0xFF202C45:0xFFD8E2EF, red=dk?0xFFFF8FA3:0xFFB3243F;
    float d=getResources().getDisplayMetrics().density; int pad=(int)(24*d);
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setBackgroundColor(bg); root.setPadding(pad,pad,pad,pad); root.setFitsSystemWindows(true);
    LinearLayout status=new LinearLayout(this); status.setOrientation(LinearLayout.HORIZONTAL); status.setGravity(Gravity.CENTER);
    dot=new View(this); round(dot,red,6*d); dotLabel=new TextView(this); dotLabel.setText("Alarm berdering"); dotLabel.setTextSize(13); dotLabel.setTextColor(mut); dotLabel.setPadding((int)(8*d),0,0,0);
    status.addView(dot,new LinearLayout.LayoutParams((int)(12*d),(int)(12*d))); status.addView(dotLabel);
    int rs=(int)(216*d);
    FrameLayout box=new FrameLayout(this); ring=new RingView(this,track,ac,d);
    box.addView(ring,new FrameLayout.LayoutParams(rs,rs,Gravity.CENTER));
    LinearLayout mid=new LinearLayout(this); mid.setOrientation(LinearLayout.VERTICAL); mid.setGravity(Gravity.CENTER);
    TextView clock=new TextView(this); clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date())); clock.setTextSize(56); clock.setTypeface(Typeface.create("sans-serif-light",0)); clock.setIncludeFontPadding(false); clock.setTextColor(ink); clock.setGravity(Gravity.CENTER);
    left=new TextView(this); left.setTextSize(13); left.setPadding(0,(int)(4*d),0,0); left.setTextColor(mut); left.setGravity(Gravity.CENTER);
    mid.addView(clock); mid.addView(left);
    box.addView(mid,new FrameLayout.LayoutParams(rs,rs,Gravity.CENTER));
    String shown=(title==null||title.length()==0?"Alarm":title).toUpperCase(new Locale("id","ID"));
    TextView t=new TextView(this); t.setText(shown); t.setTextSize(22); t.setTextColor(ink); t.setTypeface(Typeface.DEFAULT_BOLD); t.setGravity(Gravity.CENTER); t.setPadding(0,(int)(32*d),0,(int)(6*d));
    TextView m=new TextView(this); m.setText(message==null?"":message); m.setTextSize(15); m.setTextColor(mut); m.setGravity(Gravity.CENTER); m.setPadding(0,0,0,(int)(32*d));
    Button stop=button("Matikan",ac,onac,d), snooze=button("Tunda "+AlarmRinger.snoozeMin(this)+" menit",acs,acText,d);
    stop.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(id!=null) AlarmRinger.stop(self,id); finish(); } });
    snooze.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { if(id!=null) AlarmRinger.snooze(self,id,title,message); finish(); } });
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT); lp.topMargin=(int)(12*d);
    LinearLayout.LayoutParams lpTop=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT); lpTop.bottomMargin=(int)(20*d);
    LinearLayout.LayoutParams lpBox=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT); lpBox.gravity=Gravity.CENTER_HORIZONTAL;
    root.addView(status,lpTop); root.addView(box,lpBox); root.addView(t); root.addView(m); root.addView(stop,lp); root.addView(snooze,lp);
    setContentView(root);
    tick=new Runnable() { @Override public void run() {
      long rem=AlarmRinger.RING_MS-(System.currentTimeMillis()-t0);
      if(rem<=0L) { ring.setFrac(0f); left.setText("bunyi berhenti"); dot.setAlpha(0.25f); dotLabel.setText("Alarm selesai berbunyi"); return; }
      ring.setFrac((float)rem/(float)AlarmRinger.RING_MS);
      long s=(rem+999L)/1000L; left.setText("berdering "+(s/60L)+":"+(s%60L<10L?"0":"")+(s%60L)+" lagi");
      if(!reduce) { dotOn=!dotOn; dot.setAlpha(dotOn?1f:0.25f); }
      handler.postDelayed(this,1000L);
    } };
    tick.run();
  }
}
`; }
// Rev 403 (K4): simpan kartu ke galeri lewat MediaStore (Android 10+ tanpa izin) dan kirim langsung ke WhatsApp lewat FileProvider bawaan Capacitor (cache aplikasi saja).
export function kartuShareSource(pkg) { return `package ${pkg};

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

public final class KartuShare {
  private KartuShare() {}

  /** Nama berkas aman untuk MediaStore: huruf, angka, titik, minus, garis bawah; selain itu jadi garis bawah. */
  static String safeName(String name) {
    String n = name == null ? "" : name;
    StringBuilder b = new StringBuilder();
    for (int i = 0; i < n.length() && b.length() < 80; i++) {
      char ch = n.charAt(i);
      b.append(Character.isLetterOrDigit(ch) || ch == '.' || ch == '-' || ch == '_' ? ch : '_');
    }
    String r = b.toString();
    if (!r.endsWith(".jpg")) r = (r.length() == 0 ? "kartu" : r) + ".jpg";
    return r;
  }

  /** JPEG (base64) ke galeri, folder Pictures/NotesKelimaa. "ok" / "tidak_didukung" (Android 9 ke bawah) / "error". */
  public static String saveToGallery(Context c, String b64, String name) {
    try {
      if (Build.VERSION.SDK_INT < 29) return "tidak_didukung";
      byte[] data = Base64.decode(b64, Base64.DEFAULT);
      if (data == null || data.length < 4) return "error";
      ContentValues v = new ContentValues();
      v.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName(name));
      v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
      v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/NotesKelimaa");
      v.put(MediaStore.MediaColumns.IS_PENDING, 1);
      Uri u = c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
      if (u == null) return "error";
      try {
        OutputStream o = c.getContentResolver().openOutputStream(u);
        if (o == null) throw new IOException("tanpa aliran");
        try { o.write(data); } finally { o.close(); }
      } catch (Exception e) {
        try { c.getContentResolver().delete(u, null, null); } catch (Exception ignore) { }
        return "error";
      }
      ContentValues d = new ContentValues();
      d.put(MediaStore.MediaColumns.IS_PENDING, 0);
      c.getContentResolver().update(u, d, null, null);
      return "ok";
    } catch (Exception e) { return "error"; }
  }

  /** Kirim satu JPEG di CACHE aplikasi ke WhatsApp (lalu WhatsApp Business). "ok" / "tidak_ada" / "error". Berkas di luar cache ditolak. */
  public static String sendToWhatsApp(Activity a, String fileUri) {
    try {
      String path = Uri.parse(fileUri).getPath();
      if (path == null) return "error";
      File f = new File(path);
      File cache = a.getCacheDir();
      if (cache == null || !f.isFile() || !f.getCanonicalPath().startsWith(cache.getCanonicalPath() + File.separator)) return "error";
      Uri u = FileProvider.getUriForFile(a, a.getPackageName() + ".fileprovider", f);
      String[] paket = { "com.whatsapp", "com.whatsapp.w4b" };
      for (int i = 0; i < paket.length; i++) {
        try {
          Intent it = new Intent(Intent.ACTION_SEND);
          it.setType("image/jpeg");
          it.putExtra(Intent.EXTRA_STREAM, u);
          it.setPackage(paket[i]);
          it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
          a.startActivity(it);
          return "ok";
        } catch (ActivityNotFoundException e) { /* coba paket berikutnya */ }
      }
      return "tidak_ada";
    } catch (Exception e) { return "error"; }
  }
}
`; }

export function ensureReminderManifest(xml) {
  let out=xml;
  const perms=['android.permission.POST_NOTIFICATIONS','android.permission.RECEIVE_BOOT_COMPLETED','android.permission.SCHEDULE_EXACT_ALARM','android.permission.USE_FULL_SCREEN_INTENT','android.permission.VIBRATE'];
  for(const p of perms) if(!new RegExp('android:name="'+p+'"').test(out)) out=out.replace(/<application\b/, '    <uses-permission android:name="'+p+'" />\n    <application');
  if(!/ReminderReceiver/.test(out)) out=out.replace(/<application\b[^>]*>/, m=>m+'\n        <receiver android:name=".ReminderReceiver" android:enabled="true" android:exported="false" />\n        <receiver android:name=".ReminderBootReceiver" android:enabled="true" android:exported="false"><intent-filter><action android:name="android.intent.action.BOOT_COMPLETED" /><action android:name="android.intent.action.MY_PACKAGE_REPLACED" /></intent-filter></receiver>');
  if(!/AlarmActivity/.test(out)) out=out.replace(/<application\b[^>]*>/, m=>m+'\n        <receiver android:name=".AlarmActionReceiver" android:enabled="true" android:exported="false" />\n        <activity android:name=".AlarmActivity" android:exported="false" android:showWhenLocked="true" android:turnScreenOn="true" android:excludeFromRecents="true" android:launchMode="singleTask" android:taskAffinity="" android:theme="@android:style/Theme.DeviceDefault.NoActionBar" />');
  return out;
}

export function ensureInternetPermission(xml) {
  if (/android\.permission\.INTERNET/.test(xml)) return xml;
  const tag = '<uses-permission android:name="android.permission.INTERNET" />';
  return /<application\b/.test(xml) ? xml.replace(/<application\b/, tag + '\n    <application') : xml;
}

// Rev 244 (audit keamanan): matikan Pencadangan otomatis Android (Google/adb) supaya passcode Worker dan data catatan tidak tersalin keluar HP. Satu-satunya cadangan = ekspor manual di aplikasi. Idempoten.
export function ensureNoBackup(xml) {
  return xml.replace(/<application\b[^>]*>/, (tag) => /android:allowBackup=/.test(tag)
    ? tag.replace(/android:allowBackup="[^"]*"/, 'android:allowBackup="false"')
    : tag.replace(/<application\b/, '<application android:allowBackup="false"'));
}
// Keyboard harus mengecilkan layar (bukan menutupi bilah format): pastikan activity memakai adjustResize.
export function ensureAdjustResize(xml) {
  if (/android:windowSoftInputMode=/.test(xml)) return xml.replace(/android:windowSoftInputMode="[^"]*"/, 'android:windowSoftInputMode="adjustResize"');
  return xml.replace(/<activity\b/, '<activity android:windowSoftInputMode="adjustResize"');
}

// Rev 20: "Bagikan ke Notes Kelimaa". Filter ACTION_SEND + text/plain dipasang di activity utama (yang punya LAUNCHER), sebagai
// <intent-filter> TERPISAH dari filter MAIN/LAUNCHER. Idempoten (build ulang tidak menggandakan). Activity utama juga harus
// android:exported (wajib di Android 12 ke atas bila punya intent-filter). launchMode tidak diubah bila sudah ada; bila tidak ada
// diberi singleTask (bawaan template Capacitor), supaya Bagikan saat aplikasi terbuka masuk lewat onNewIntent, bukan membuka salinan kedua.
export const SHARE_FILTER_XML = '            <intent-filter>\n                <action android:name="android.intent.action.SEND" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <data android:mimeType="text/plain" />\n            </intent-filter>\n';
export function hasShareFilter(xml) { return /android\.intent\.action\.SEND"/.test(xml); }
export function ensureShareIntentFilter(xml) {
  if (hasShareFilter(xml)) return xml;
  const re = /<activity\b[^>]*?(?:\/>|>[\s\S]*?<\/activity>)/g;
  let m;
  while ((m = re.exec(xml))) {
    const block = m[0];
    if (!/android\.intent\.category\.LAUNCHER/.test(block) || /\/>$/.test(block)) continue;
    const open = /^<activity\b[^>]*>/.exec(block)[0];
    let fixed = open;
    if (!/android:exported=/.test(fixed)) fixed = fixed.replace(/^<activity\b/, '<activity android:exported="true"');
    if (!/android:launchMode=/.test(fixed)) fixed = fixed.replace(/^<activity\b/, '<activity android:launchMode="singleTask"');
    const end = block.lastIndexOf('</activity>');
    const nb = fixed + block.slice(open.length, end).replace(/\s*$/, '\n') + SHARE_FILTER_XML + '        ' + block.slice(end);
    return xml.slice(0, m.index) + nb + xml.slice(m.index + block.length);
  }
  return xml;
}

// Layar pembuka: tema bawaan Capacitor memakai latar krem/putih (gambar splash) sehingga ada kilat terang sebelum
// tampilan gelap muncul. Latar diganti satu warna navy (@color/kelimaa_launch_bg) di tema pembuka dan tema utama.
// Latar pembuka tidak bisa mengikuti pilihan tema di dalam aplikasi (Android menggambarnya sebelum aplikasi jalan).
export const LAUNCH_COLOR_XML = '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="kelimaa_launch_bg">#0B1120</color>\n</resources>\n';

export function patchLaunchStyles(xml) {
  const names = ['AppTheme.NoActionBarLaunch', 'AppTheme.NoActionBar'];
  let out = xml;
  for (const name of names) {
    const re = new RegExp('(<style\\s+name="' + name.replace(/\./g, '\\.') + '"[^>]*?parent="([^"]*)"[^>]*>)([\\s\\S]*?)(</style>)');
    out = out.replace(re, (all, open, parent, body, close) => {
      const clean = body.replace(/\s*<item\s+name="(?:android:background|android:windowBackground|windowSplashScreenBackground)">[^<]*<\/item>/g, '');
      let add = '\n        <item name="android:background">@color/kelimaa_launch_bg</item>\n        <item name="android:windowBackground">@color/kelimaa_launch_bg</item>';
      if (/SplashScreen/.test(parent)) add += '\n        <item name="windowSplashScreenBackground">@color/kelimaa_launch_bg</item>';
      return open + add + clean + close;
    });
  }
  return out;
}

export function findFile(dir, name) {
  if (!existsSync(dir)) return '';
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) { const f = findFile(p, name); if (f) return f; }
    else if (e.name === name) return p;
  }
  return '';
}

export function applyNative(androidDir = 'android') {
  const res = { activity: false, manifest: false, share: false, reminders: false };
  const src = join(androidDir, 'app', 'src', 'main');
  const act = findFile(join(src, 'java'), 'MainActivity.java');
  if (!act) console.warn('MainActivity.java tidak ditemukan; tombol Keluar total dan buka tautan tidak dipasang.');
  else {
    const m = readFileSync(act, 'utf8').match(/^\s*package\s+([\w.]+)\s*;/m);
    if (!m) console.warn('Baris package di MainActivity.java tidak terbaca; dilewati.');
    else { writeFileSync(act, mainActivitySource(m[1])); res.activity = true; console.log('MainActivity.java dipasang (' + m[1] + ')'); }
  }
  // Rev 10e: patch styles.xml (latar pembuka navy, Rev 10d) DIMATIKAN; dicurigai membuat aplikasi tutup sendiri saat dibuka. Fungsi patchLaunchStyles dibiarkan (tes), tidak dipanggil.
  if (act) {
    const pkg = readFileSync(act, 'utf8').match(/^\s*package\s+([\w.]+)\s*;/m)?.[1];
    if (pkg) { const dir = join(src, 'java', ...pkg.split('.')); mkdirSync(dir, { recursive: true });
      writeFileSync(join(dir, 'ReminderScheduler.java'), reminderSchedulerSource(pkg));
      writeFileSync(join(dir, 'ReminderReceiver.java'), reminderReceiverSource(pkg));
      writeFileSync(join(dir, 'ReminderBootReceiver.java'), reminderBootReceiverSource(pkg)); res.reminders = true;
      writeFileSync(join(dir, 'AlarmRinger.java'), alarmRingerSource(pkg));
      writeFileSync(join(dir, 'AlarmActionReceiver.java'), alarmActionReceiverSource(pkg));
      writeFileSync(join(dir, 'AlarmActivity.java'), alarmActivitySource(pkg));
      writeFileSync(join(dir, 'KartuShare.java'), kartuShareSource(pkg));
    }
  }
  const mf = join(src, 'AndroidManifest.xml');
  if (!existsSync(mf)) console.warn('AndroidManifest.xml tidak ditemukan; izin INTERNET tidak diperiksa.');
  else {
    const before = readFileSync(mf, 'utf8'), after = (res.reminders ? ensureReminderManifest(before) : before); const finalXml = ensureNoBackup(ensureShareIntentFilter(ensureAdjustResize(ensureInternetPermission(after))));
    if (finalXml !== before) writeFileSync(mf, finalXml);
    res.manifest = /android\.permission\.INTERNET/.test(finalXml);
    res.share = hasShareFilter(finalXml);
    res.noBackup = /<application\b[^>]*android:allowBackup="false"/.test(finalXml);
    console.log('Pencadangan otomatis Android: ' + (res.noBackup ? 'DIMATIKAN (allowBackup=false)' : 'TIDAK berhasil dimatikan'));
    console.log('Izin INTERNET: ' + (res.manifest ? 'ada' : 'TIDAK ADA'));
    console.log('Filter Bagikan teks: ' + (res.share ? 'ada' : 'TIDAK TERPASANG (activity utama tidak ditemukan; "Bagikan ke Notes Kelimaa" tidak muncul, aplikasi tetap normal)'));
    console.log('launchMode: ' + ((/android:launchMode="([^"]*)"/.exec(finalXml) || [])[1] || 'tidak diatur'));
    console.log('Native pengingat: ' + (res.reminders ? 'kelas Java + receiver dipasang' : 'TIDAK TERPASANG'));
  }
  return res;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) applyNative();
