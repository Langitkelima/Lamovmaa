// Menyalin src/ ke www/ (folder yang dibaca Capacitor). Tanpa bundler.
import { rmSync, cpSync, readFileSync, writeFileSync } from 'node:fs';
import { staticGraph, injectPreload } from './preload.mjs';
import { minifyCss } from './minify.mjs';
rmSync('www', { recursive: true, force: true });
cpSync('src', 'www', { recursive: true });
// Rev 191 / P1: sisipkan <link rel="modulepreload"> (graf impor statis dari js/main.js) HANYA di www/index.html.
// Gagal = abaikan (salinan polos tetap jalan; build tidak boleh gagal karena ini).
try {
  const files = staticGraph('js/main.js');
  writeFileSync('www/index.html', injectPreload(readFileSync('www/index.html', 'utf8'), files));
  console.log('modulepreload: ' + files.length + ' modul disisipkan ke www/index.html');
} catch (e) { console.warn('modulepreload dilewati: ' + (e && e.message)); }
// Rev 204: perkecil CSS di www/ saja (gagal = pakai salinan polos).
try {
  const raw = readFileSync('www/css/styles.css', 'utf8'), min = minifyCss(raw);
  writeFileSync('www/css/styles.css', min);
  console.log('minify CSS: ' + raw.length + ' -> ' + min.length + ' byte');
} catch (e) { console.warn('minify CSS dilewati: ' + (e && e.message)); }
console.log('Build web selesai: src/ -> www/');
