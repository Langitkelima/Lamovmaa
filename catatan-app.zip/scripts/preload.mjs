// Rev 191 (P1): daftar modul JS yang dimuat saat buka (graf impor STATIS dari js/main.js) + penyisip <link rel="modulepreload">.
// Dipakai scripts/build.mjs hanya pada salinan www/index.html; src/index.html tidak diubah. Tanpa dependensi.
// Impor dinamis (import('./x.js')) TIDAK ikut: itulah modul yang sengaja dimuat belakangan (lazy loading, P2).
import { readFileSync } from 'node:fs';
import { join, posix } from 'node:path';

const STATIC_RE = /(?:^|[\n;])\s*(?:import|export)\s[^;'"]*?from\s*['"](\.[^'"]+)['"]|(?:^|[\n;])\s*import\s*['"](\.[^'"]+)['"]/g;

// Daftar jalur relatif terhadap src/ (mis. 'js/main.js'), urutan kedalaman-dulu dari titik masuk. read(path) -> teks.
export function staticGraph(entry = 'js/main.js', read = (p) => readFileSync(join('src', p), 'utf8')) {
  const seen = new Set(), order = [];
  const walk = (file) => {
    if (seen.has(file)) return;
    seen.add(file); order.push(file);
    const src = read(file);
    for (const m of src.matchAll(STATIC_RE)) {
      const spec = m[1] || m[2];
      walk(posix.normalize(posix.join(posix.dirname(file), spec)));
    }
  };
  walk(entry);
  return order;
}

// Sisipkan tautan modulepreload tepat sebelum </head>. Idempoten: pemanggilan kedua tidak menggandakan.
export function injectPreload(html, files) {
  if (html.includes('data-kelimaa-preload')) return html;
  const tags = files.map((f) => `<link rel="modulepreload" href="${f}" data-kelimaa-preload>`).join('\n');
  return html.includes('</head>') ? html.replace('</head>', tags + '\n</head>') : html;
}
