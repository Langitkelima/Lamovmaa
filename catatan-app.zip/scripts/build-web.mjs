// Rev 424 / SY4a: build VERSI WEB (PWA) untuk laptop/peramban. Hasil di www-web/ (BUKAN www/, jadi APK tidak berubah).
// Alur: jalankan scripts/build.mjs (src/ -> www/), salin ke www-web/, lalu tambahkan HANYA di www-web/index.html:
// manifest, ikon, warna tema, dan pendaftaran service worker. src/ dan www/ tidak disentuh. Tanpa dependensi.
import { execFileSync } from 'node:child_process';
import { rmSync, cpSync, readFileSync, writeFileSync, readdirSync, statSync, mkdirSync } from 'node:fs';
import { join, posix } from 'node:path';
import { createHash } from 'node:crypto';

export function daftarBerkas(dir, base = dir) {
  const out = [];
  for (const nama of readdirSync(dir).sort()) {
    const p = join(dir, nama);
    if (statSync(p).isDirectory()) out.push(...daftarBerkas(p, base));
    else out.push(p.slice(base.length + 1).split('\\').join('/'));
  }
  return out;
}

export function manifestWeb() {
  return {
    name: 'Notes Kelimaa', short_name: 'Notes', description: 'Catatan dan ceklis tugas',
    start_url: './', scope: './', display: 'standalone', orientation: 'any',
    background_color: '#EDF2F9', theme_color: '#EDF2F9', lang: 'id',
    icons: [
      { src: 'ikon/ikon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: 'ikon/ikon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: 'ikon/ikon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  };
}

// Service worker: simpan cangkang aplikasi (semua berkas www-web kecuali sw.js) supaya terbuka tanpa internet.
// Hanya permintaan GET se-asal yang ditangani; permintaan ke Worker (asal lain) TIDAK disentuh. Tanpa skipWaiting:
// versi baru aktif setelah semua tab ditutup, supaya modul lama dan baru tidak tercampur.
export function tulisSw(versi, berkas) {
  return `// Dibuat otomatis oleh scripts/build-web.mjs (Rev 424). Jangan diubah tangan.
const VERSI = ${JSON.stringify(versi)};
const CACHE = 'notes-kelimaa-' + VERSI;
const BERKAS = ${JSON.stringify(berkas)};
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(BERKAS))); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith('notes-kelimaa-') && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url);
  if (u.origin !== self.location.origin) return;
  e.respondWith(caches.open(CACHE).then(async (c) => {
    const hit = await c.match(r, { ignoreSearch: true });
    if (hit) return hit;
    try { return await fetch(r); }
    catch (err) { if (r.mode === 'navigate') { const idx = await c.match('index.html'); if (idx) return idx; } throw err; }
  }));
});
`;
}

export function sisipkanPwa(html) {
  if (html.includes('data-kelimaa-pwa')) return html;
  const kepala = '<link rel="manifest" href="manifest.webmanifest" data-kelimaa-pwa>\n<meta name="theme-color" content="#EDF2F9">\n<link rel="stylesheet" href="laptop.css">\n<link rel="icon" type="image/png" href="ikon/ikon-192.png">\n<link rel="apple-touch-icon" href="ikon/ikon-192.png">\n';
  const badan = '<script src=\"laptop.js\" defer></script>\n<script>if("serviceWorker"in navigator&&location.protocol!=="file:"){addEventListener("load",function(){navigator.serviceWorker.register("sw.js").catch(function(){})})}</script>\n';
  return html.replace('</head>', kepala + '</head>').replace('</body>', badan + '</body>');
}

export const HEADERS = `/sw.js
  Cache-Control: no-cache
/manifest.webmanifest
  Cache-Control: no-cache
/index.html
  Cache-Control: no-cache
/*
  X-Content-Type-Options: nosniff
  Referrer-Policy: no-referrer
`;

export function bangunWeb() {
  execFileSync(process.execPath, ['scripts/build.mjs'], { stdio: 'inherit' });
  rmSync('www-web', { recursive: true, force: true });
  cpSync('www', 'www-web', { recursive: true });
  mkdirSync('www-web/ikon', { recursive: true });
  cpSync('web/ikon', 'www-web/ikon', { recursive: true });
  cpSync('web/laptop.css', 'www-web/laptop.css');
  cpSync('web/laptop.js', 'www-web/laptop.js');
  writeFileSync('www-web/manifest.webmanifest', JSON.stringify(manifestWeb(), null, 2));
  writeFileSync('www-web/index.html', sisipkanPwa(readFileSync('www-web/index.html', 'utf8')));
  writeFileSync('www-web/_headers', HEADERS);
  const semua = daftarBerkas('www-web').filter((f) => f !== 'sw.js' && f !== '_headers');
  const h = createHash('sha256');
  for (const f of semua) { h.update(f); h.update(readFileSync(join('www-web', f))); }
  const versi = h.digest('hex').slice(0, 12);
  // "./" dan "index.html" sama-sama disimpan: navigasi ke akar dan ke berkas.
  const daftar = ['./', ...semua];
  writeFileSync('www-web/sw.js', tulisSw(versi, daftar));
  console.log('Build web selesai: www-web/ (' + semua.length + ' berkas, versi cache ' + versi + ')');
  return { versi, berkas: semua };
}

if (import.meta.url === new URL(process.argv[1], 'file://').href || process.argv[1].endsWith('build-web.mjs')) bangunWeb();
