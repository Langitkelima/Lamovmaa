// Rev 204: minifikasi CSS aman untuk salinan www/ (sumber src/ tidak diubah).
// Hanya membuang (1) komentar /* */ dan (2) spasi/baris baru yang tidak bermakna: lipatan menjadi satu spasi,
// lalu spasi di sekitar { } ; , dibuang. Isi string ("...", '...') tidak disentuh. Tidak ada penulisan ulang nilai.
export function minifyCss(css) {
  let out = '', i = 0, q = null, pendingSpace = false;
  const n = css.length;
  const punct = '{};,';
  const push = (c) => {
    if (pendingSpace) {
      const prev = out[out.length - 1];
      if (prev !== undefined && !punct.includes(prev) && !punct.includes(c)) out += ' ';
      pendingSpace = false;
    }
    out += c;
  };
  while (i < n) {
    const c = css[i];
    if (q) {
      out += c;
      if (c === '\\' && i + 1 < n) { out += css[i + 1]; i++; }
      else if (c === q) q = null;
      i++; continue;
    }
    if (c === '/' && css[i + 1] === '*') {
      const e = css.indexOf('*/', i + 2);
      if (e < 0) throw new Error('komentar CSS tidak ditutup');
      pendingSpace = pendingSpace || false; i = e + 2;
      // komentar di tengah token = pemisah (satu spasi), seperti perilaku peramban
      if (out && !punct.includes(out[out.length - 1])) pendingSpace = true;
      continue;
    }
    if (c === '"' || c === "'") { push(c); q = c; i++; continue; }
    if (c === ' ' || c === '\n' || c === '\r' || c === '\t' || c === '\f') { pendingSpace = true; i++; continue; }
    push(c); i++;
  }
  if (q) throw new Error('string CSS tidak ditutup');
  return out.trim();
}
