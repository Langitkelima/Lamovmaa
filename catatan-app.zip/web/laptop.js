/* Rev 425 / SY4b: pendamping tata letak laptop (HANYA versi web). Memasang body[data-lap] + body[data-tab],
   menggambar merek dan rak label di sidebar (menyalin chip label bawaan, klik diteruskan ke chip asli),
   dan pintasan Ctrl+K. Tidak mengubah data atau kode aplikasi. */
(function () {
  var mq = matchMedia('(min-width:1000px) and (hover:hover) and (pointer:fine)');
  var brand = null, labs = null, sig = '', raf = 0;
  function ensure() {
    if (brand) return;
    brand = document.createElement('div'); brand.id = 'lap-brand'; brand.innerHTML = '<i>\u2726</i><b>Kelimaa</b>'; document.body.appendChild(brand);
    labs = document.createElement('div'); labs.id = 'lap-labels'; document.body.appendChild(labs);
  }
  function chipsNow() {
    var out = [], els = document.querySelectorAll('#app>main .chips .chp');
    for (var i = 0; i < els.length; i++) out.push(els[i]);
    return out;
  }
  function update() {
    raf = 0;
    var b = document.body;
    if (!mq.matches) { delete b.dataset.lap; delete b.dataset.tab; delete b.dataset.pane; if (labs) labs.classList.remove('on'); sig = ''; return; }
    ensure(); b.dataset.lap = '1';
    var nb = document.querySelector('#app>nav button.on'), tab = nb ? (nb.dataset.tab || '') : '';
    if (b.dataset.tab !== tab) b.dataset.tab = tab;
    var pane = (tab === 'catatan' || tab === 'privat') && !!document.querySelector('#app>main .selhost');
    if (pane !== (b.dataset.pane === '1')) { if (pane) b.dataset.pane = '1'; else delete b.dataset.pane; }
    var ttl = document.querySelector('.fs .ttl'), want = ttl ? (ttl.value.trim() || 'Tanpa judul') : null;
    var cards = document.querySelectorAll('#app>main .card'), idx = -1, cur = -1;
    cards.forEach(function (cd, i) {
      var bt = cd.querySelector('b');
      if (idx < 0 && want !== null && bt && bt.textContent === want) idx = i;
      if (cur < 0 && cd.classList.contains('lap-open')) cur = i;
    });
    if (want !== null && idx < 0) idx = cur; /* judul baru belum tersimpan: pertahankan sorotan */
    cards.forEach(function (cd, i) { var on = i === idx; if (cd.classList.contains('lap-open') !== on) cd.classList.toggle('lap-open', on); });
    var chips = (tab === 'catatan' || tab === 'privat') ? chipsNow() : [];
    var s = tab + '|' + chips.map(function (c) { return c.textContent + (c.classList.contains('on') ? '*' : ''); }).join('|');
    if (s === sig) return; sig = s;
    labs.textContent = '';
    if (!chips.length) { labs.classList.remove('on'); return; }
    var h = document.createElement('h6'); h.textContent = 'Label'; labs.appendChild(h);
    chips.forEach(function (c, i) {
      var t = c.textContent, m = /^(.*?)\s*\((\d+)\)$/.exec(t);
      var bt = document.createElement('button'); bt.type = 'button';
      bt.className = (c.classList.contains('on') ? 'on ' : '') + (i === 0 ? 'all' : '');
      var d = document.createElement('i'), n = document.createElement('span'); n.textContent = m ? m[1] : t;
      bt.appendChild(d); bt.appendChild(n);
      if (m) { var k = document.createElement('small'); k.textContent = m[2]; bt.appendChild(k); }
      bt.addEventListener('click', function () { c.click(); });
      labs.appendChild(bt);
    });
    labs.classList.add('on');
  }
  function plan() { if (!raf) raf = requestAnimationFrame(update); }
  function start() {
    var app = document.getElementById('app'); if (!app) return;
    new MutationObserver(plan).observe(app, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    new MutationObserver(plan).observe(document.body, { childList: true });
    if (mq.addEventListener) mq.addEventListener('change', plan);
    addEventListener('keydown', function (e) {
      if (!mq.matches || !(e.ctrlKey || e.metaKey) || (e.key !== 'k' && e.key !== 'K')) return;
      var q = document.querySelector('#app>main input[type=search]'); if (q) { e.preventDefault(); q.focus(); q.select(); }
    });
    document.addEventListener('input', function (e) { if (e.target && e.target.classList && e.target.classList.contains('ttl')) plan(); }, true);
    plan();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
