// Rev 318 / U1: bagian lebar kolom tabel yang TIDAK perlu ada di jalur buka (dimuat malas oleh UI U2). Mesin dasar (clampW, parseWidths, formatWidths,
// normalizeTableWidths) ada di tabel.js karena dipakai sanitize. Belum dipanggil UI.
import { COL_W_COLS, COL_W_MIN, COL_W_MAX, parseWidths, formatWidths, clampW, colCount, applyTableWidths } from './tabel.js';
export { applyTableWidths }; // Rev 319: inti ada di tabel.js (dipanggil sanitize); diekspor ulang di sini

// Operasi daftar lebar (tidak mengubah daftar asli): seret, tambah kolom, hapus kolom.
export function setWidthAt(list, i, px, cols) { const a = parseWidths(formatWidths(list), cols); if (i >= 0 && i < a.length) a[i] = clampW(px); return a; }
export function insertWidthAt(list, i, cols) { const a = parseWidths(formatWidths(list), cols - 1); a.splice(Math.max(0, Math.min(a.length, i)), 0, 0); return a.slice(0, COL_W_COLS); }
export function removeWidthAt(list, i, cols) { const a = parseWidths(formatWidths(list), cols + 1); if (i >= 0 && i < a.length) a.splice(i, 1); return a; }

// Bagian DOM (hanya atribut/gaya; tidak menyentuh isi sel).
export const readTableWidths = (table) => parseWidths(table.getAttribute('data-w') || '', colCount(table));
export function writeTableWidths(table, list) {
  const s = formatWidths(list);
  if (s) table.setAttribute('data-w', s); else table.removeAttribute('data-w');
  applyTableWidths(table);
}
// Rev 319 / U2a: lebar hasil seret = lebar awal + geser jari, dijepit 56-320 (clampW sendiri menganggap <= 0 sebagai otomatis, jadi dijepit dulu di sini).
export const dragWidth = (w0, dx) => Math.round(Math.max(COL_W_MIN, Math.min(COL_W_MAX, Number(w0) + Number(dx) || COL_W_MIN)));
// Tambah/hapus kolom di tabel yang punya data-w: lebar kolom lain tidak bergeser. oldCols = jumlah kolom SEBELUM aksi; i = indeks kolom baru / yang dihapus.
export function shiftWidthList(list, op, i, oldCols) { return op === 'ins' ? insertWidthAt(list, i, oldCols + 1) : removeWidthAt(list, i, oldCols - 1); }
export function shiftTableWidths(table, op, i, oldCols) {
  const old = parseWidths(table.getAttribute('data-w') || '', oldCols);
  if (old.some((n) => n > 0)) writeTableWidths(table, shiftWidthList(old, op, i, oldCols));
}
