// Rev 33: fungsi murni untuk membuat struktur tabel dasar. Tanpa DOM dan tanpa penyimpanan.
export const TABLE_MIN_ROWS = 2;
export const TABLE_MAX_ROWS = 8;
export const TABLE_MIN_COLS = 2;
export const TABLE_MAX_COLS = 6;
// Rev 40: kotak pilihan di dialog "Ukuran tabel" hanya 6 kolom x 5 baris (muat di layar HP tanpa tergulir).
// Baris/kolom tambahan tetap bisa ditambah lewat menu tabel (batas TABLE_MAX_ROWS di atas tidak berubah).
export const TABLE_PICK_ROWS = 5;

const clampInt = (v, min, max, fallback) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.trunc(n))) : fallback;
};

export function tableSize(rows, cols) {
  return {
    rows: clampInt(rows, TABLE_MIN_ROWS, TABLE_MAX_ROWS, 3),
    cols: clampInt(cols, TABLE_MIN_COLS, TABLE_MAX_COLS, 3),
  };
}

export function createTableHTML(rows = 3, cols = 3, headerRow = true) {
  const size = tableSize(rows, cols);
  const body = [];
  for (let r = 0; r < size.rows; r++) {
    const cells = [];
    for (let c = 0; c < size.cols; c++) {
      const tag = headerRow && r === 0 ? 'th' : 'td';
      cells.push(`<${tag}><br></${tag}>`);
    }
    body.push(`<tr>${cells.join('')}</tr>`);
  }
  return `<div class="tbl-wrap"><table><tbody>${body.join('')}</tbody></table></div>`;
}

export function tableCellCount(rows, cols) {
  const size = tableSize(rows, cols);
  return size.rows * size.cols;
}

// Rev 318 / U1: lebar kolom tabel (D2). <table data-w="140,0,200"> = px per kolom, 0 = otomatis. Hanya bagian kecil untuk sanitize di sini
// (jalur buka dibatasi tes rev192/rev193); seret, tulis, dan terapkan ke sel ada di tabel-lebar.js (lazy, dipakai UI U2).
export const COL_W_MIN = 56, COL_W_MAX = 320, COL_W_COLS = 8;
export const COL_W_RE = /^(?:0|[1-9]\d{1,2})(?:,(?:0|[1-9]\d{1,2})){0,7}$/;
export function clampW(v) { const n = Math.round(Number(v)); return Number.isFinite(n) && n > 0 ? Math.max(COL_W_MIN, Math.min(COL_W_MAX, n)) : 0; }
export function parseWidths(text, cols) {
  const c = Math.max(0, Math.min(COL_W_COLS, Math.trunc(Number(cols)) || 0)), raw = typeof text === 'string' && COL_W_RE.test(text) ? text.split(',') : [];
  return Array.from({ length: c }, (_, i) => clampW(raw[i]));
}
export function formatWidths(list) { const a = (Array.isArray(list) ? list : []).slice(0, COL_W_COLS).map(clampW); return a.some((n) => n > 0) ? a.join(',') : ''; }
export const colCount = (table) => [...table.rows].filter((r) => !r.classList.contains('tt')).reduce((m, r) => Math.max(m, r.cells.length), 0);
// Rev 319: gaya lebar sel dari data-w (sanitize membuang gaya itu, jadi dipasang ulang tiap sanitize).
export function applyTableWidths(table) {
  const w = parseWidths(table.getAttribute('data-w') || '', colCount(table));
  for (const r of table.rows) [...r.cells].forEach((c, i) => { for (const k of ['width', 'min-width', 'max-width']) { if (w[i]) c.style.setProperty(k, w[i] + 'px'); else c.style.removeProperty(k); } if (!c.getAttribute('style')) c.removeAttribute('style'); });
}
export function normalizeTableWidths(table) { const s = formatWidths(parseWidths(table.getAttribute('data-w') || '', colCount(table))); if (s) table.setAttribute('data-w', s); else table.removeAttribute('data-w'); applyTableWidths(table); }
