// Rev 397 / PART M2: dialog Ekspor Markdown (dimuat MALAS dari Setelan). Tiga sakelar: label, gambar, Catatan Privat (mati bawaan).
// Yang menolak wajib menjelaskan alasannya: tidak ada catatan, Catatan Privat terkunci, gambar hanya di aplikasi HP.
import { h, tOk, tInfo, tErr } from './ui.js';
import { isNative, nativePlugin } from './native.js';
import { planMarkdownExport, buildMarkdownZipBytes, writeMarkdownZipToCache, mdZipName, MD_ZIP_MAX_NOTES } from './ekspor-md.js';
import { uniqueRefs } from './cadangan-gambar.js';

const msgOf = (e) => String((e && e.message) || e || 'gagal').slice(0, 120);

export async function runMarkdownExport(ctx, opts, deps = {}) {
  const plan = planMarkdownExport(ctx.data, opts, deps.now);
  if (!plan.files.length) return { ok: false, msg: 'Tidak ada catatan yang bisa diekspor (catatan kosong dilewati).' };
  if (plan.files.length > MD_ZIP_MAX_NOTES) return { ok: false, msg: 'Terlalu banyak catatan untuk satu ZIP (' + plan.files.length + '). Batas ' + MD_ZIP_MAX_NOTES + '.' };
  const name = mdZipName(deps.now);
  const native = deps.native === undefined ? isNative() : deps.native;
  if (native) {
    const FS = deps.FS || nativePlugin('Filesystem'), SH = deps.SH || nativePlugin('Share');
    const z = await writeMarkdownZipToCache(FS, plan, name, deps.now);
    await SH.share({ title: 'Catatan Markdown', files: [z.uri], dialogTitle: 'Simpan ekspor Markdown' });
    setTimeout(() => { FS.deleteFile({ path: name, directory: 'CACHE' }).catch(() => {}); }, 120000);
    return { ok: true, plan, missing: z.missing.length, included: z.included, name };
  }
  const url = URL.createObjectURL(new Blob([buildMarkdownZipBytes(plan, deps.now)], { type: 'application/zip' }));
  const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  return { ok: true, plan, missing: 0, included: 0, name };
}

export function bukaEksporMd(ctx) {
  const native = isNative(), unlocked = !!(ctx.ui && ctx.ui.unlocked);
  const nImg = native ? uniqueRefs({ notes: ctx.data.notes }).length : 0;
  const st = { labels: true, images: nImg > 0, priv: false };
  const ov = h('div', { class: 'ov dlgov' });
  const sw = (key, title, sub, off) => {
    const el = h('button', { type: 'button', class: 'am-sw', role: 'switch', 'aria-checked': String(!!st[key] && !off), disabled: off ? 'true' : null },
      h('span', { class: 'am-swt' }, h('b', {}, title), h('small', {}, sub)), h('span', { class: 'am-tg', 'aria-hidden': 'true' }));
    el.addEventListener('click', () => { if (off) return; st[key] = !st[key]; el.setAttribute('aria-checked', String(st[key])); sum(); });
    return el;
  };
  const info = h('p', { class: 'sub' }), bYes = h('button', { type: 'button', class: 'btn' }, 'Ekspor ZIP');
  const sum = () => { const p = planMarkdownExport(ctx.data, st); info.textContent = p.files.length + ' catatan' + (st.images && p.imageRefs.length ? ', ' + p.imageRefs.length + ' gambar' : '') + (p.counts.kosong ? ' (' + p.counts.kosong + ' kosong dilewati)' : '') + (p.counts.lembar ? '. ' + p.counts.lembar + ' catatan memuat lembar kerja yang tidak ikut diekspor' : '') + '.'; };
  const close = () => ov.remove();
  const bNo = h('button', { type: 'button', class: 'btn line', onclick: close }, 'Batal');
  bYes.onclick = async () => {
    bYes.disabled = true; tInfo('Menyiapkan ZIP Markdown...');
    try {
      const r = await runMarkdownExport(ctx, st);
      if (!r.ok) { tInfo(r.msg); bYes.disabled = false; return; }
      close();
      if (r.missing) tInfo(r.missing + ' gambar tidak ditemukan di HP, jadi tidak ikut.'); else tOk(r.plan.files.length + ' catatan diekspor.');
    } catch (e) { bYes.disabled = false; if (!/cancel/i.test(msgOf(e))) { console.error('ekspor markdown gagal:', e); tErr('Gagal mengekspor: ' + msgOf(e)); } }
  };
  ov.append(h('div', { class: 'sheet dlg' }, h('h3', {}, 'Ekspor Markdown'),
    h('p', { class: 'sub' }, 'Satu berkas .md per catatan dalam satu ZIP, bisa dibuka di aplikasi catatan lain. Berkas tidak dienkripsi.'),
    sw('labels', 'Sertakan label', 'Nama label ditulis di bagian atas tiap berkas.'),
    sw('images', 'Sertakan gambar', native ? (nImg ? nImg + ' gambar masuk folder gambar di ZIP.' : 'Tidak ada gambar di catatan.') : 'Hanya di aplikasi HP.', !native || !nImg),
    sw('priv', 'Catatan Privat', unlocked ? 'Masuk folder privat di ZIP. Hati-hati menyimpannya.' : 'Buka kunci Catatan Privat dulu agar bisa dipilih.', !unlocked),
    info, h('div', { class: 'dlgb' }, bNo, bYes)));
  document.body.append(ov); sum();
}
