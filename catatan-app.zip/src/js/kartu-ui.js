// Rev 401 / K2: layar "Gambar kartu" (dimuat MALAS dari menu Bagikan). Pratinjau + 4 warna bawaan + Bagikan / Simpan.
// Rev 403 / K4: tombol "Kirim ke WhatsApp" (langsung ke WhatsApp, hanya di aplikasi dengan jembatan baru) dan "Simpan ke galeri" (album NotesKelimaa; jatuh ke Dokumen bila galeri tidak bisa).
// Rev 402 / K3: chip "Lainnya" membuka pemilih warna bebas (kotak + pita rona + kode hex) dan deretan riwayat warna terakhir. WhatsApp dan galeri = K4. Catatan Privat tidak punya tombol Bagikan sama sekali (bagian 5), jadi tidak pernah sampai ke sini.
import { h, tOk, tWarn, tErr } from './ui.js';
import { WARNA_KARTU, temaKartu, renderKartu } from './kartu.js';
import { shareFileName } from './export.js';
import { setSheetsSource } from './lembar-pulau.js';
import { loadEngine, sheetsHaveFx } from './lembar-mesin.js';
import { sendFiles, loadShareImages, bisaGaleri, bisaWhatsApp, simpanGaleri, kirimWhatsApp } from './share.js';

const NAMA = { biru: 'Biru', hijau: 'Hijau', gelap: 'Gelap', polos: 'Polos' };
const msgOf = (e) => String((e && e.message) || e || 'gagal').slice(0, 140);
let lastWarna = 'biru'; // diingat selama aplikasi terbuka (nama bawaan atau #rrggbb)
// Rev 402 / K3: pembantu warna MURNI (diuji di Node) + riwayat warna kustom (localStorage, hanya kemudahan; gagal baca/tulis = tanpa riwayat).
export const RIWAYAT_KEY = 'kelimaa.kartu.riwayat', RIWAYAT_MAX = 8;
export function normHex(x) { let t = String(x == null ? '' : x).trim().toLowerCase(); if (/^[0-9a-f]{6}$/.test(t)) t = '#' + t; return /^#[0-9a-f]{6}$/.test(t) ? t : null; }
export function hsvToHex(hh, s, v) {
  const f = (n) => { const k = (n + hh / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
  return '#' + [f(5), f(3), f(1)].map((c) => Math.round(c * 255).toString(16).padStart(2, '0')).join('');
}
export function hexToHsv(hex) {
  const t = normHex(hex) || '#dbe9fb', r = parseInt(t.slice(1, 3), 16) / 255, g = parseInt(t.slice(3, 5), 16) / 255, b = parseInt(t.slice(5, 7), 16) / 255;
  const mx = Math.max(r, g, b), d = mx - Math.min(r, g, b); let hh = 0;
  if (d) hh = mx === r ? ((g - b) / d + 6) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [hh * 60, mx ? d / mx : 0, mx];
}
export const tambahRiwayat = (list, hex) => { const n = normHex(hex); return n ? [n, ...list.filter((x) => x !== n)].slice(0, RIWAYAT_MAX) : list.slice(0, RIWAYAT_MAX); };
export function bacaRiwayat(st = globalThis.localStorage) { try { const a = JSON.parse(st.getItem(RIWAYAT_KEY) || '[]'); return Array.isArray(a) ? a.map(normHex).filter(Boolean).slice(0, RIWAYAT_MAX) : []; } catch (_) { return []; } }
export function simpanRiwayat(list, st = globalThis.localStorage) { try { st.setItem(RIWAYAT_KEY, JSON.stringify(list.slice(0, RIWAYAT_MAX))); } catch (_) { /* tanpa riwayat */ } }

export async function bukaKartu(ctx, n) {
  setSheetsSource(() => ctx.data.sheets); // lembar kerja di catatan ikut tergambar
  if (!(n.title || n.text || n.html)) { tWarn('Catatan masih kosong.'); return; }
  let busy = false, tok = 0, last = null, warna = WARNA_KARTU[lastWarna] ? lastWarna : (normHex(lastWarna) || 'biru'), images = null, catatan = '';
  const ov = h('div', { class: 'ov pickov shareov kartuov', onclick: (e) => { if (e.target === ov) tutup(); } });
  const alive = () => ov.isConnected;
  const tutup = () => { if (busy) return; tok++; clearTimeout(tm); selesai(); ov.remove(); }; // warna kustom yang terakhir dipakai masuk riwayat saat layar ditutup (juga setelah Bagikan/Simpan berhasil)
  const info = h('p', { class: 'sub', role: 'status' }, 'Membuat kartu...');
  const img = h('img', { class: 'kartu-img', alt: 'Pratinjau kartu' });
  let url = '';
  const lepas = () => { if (url) { URL.revokeObjectURL(url); url = ''; } };
  img.addEventListener('load', lepas); // gambar sudah didekode: alamat sementara tidak perlu ditahan
  const bBagi = h('button', { type: 'button', class: 'btn', onclick: () => kirim('share') }, 'Bagikan');
  const bSimpan = h('button', { type: 'button', class: 'btn line', onclick: () => kirim('save') }, bisaGaleri() ? 'Simpan ke galeri' : 'Simpan');
  const bWa = bisaWhatsApp() ? h('button', { type: 'button', class: 'btn kartu-wa', onclick: () => kirim('wa') }, 'Kirim ke WhatsApp') : null;
  const segar = () => { bBagi.disabled = bSimpan.disabled = busy || !last; if (bWa) bWa.disabled = busy || !last; };
  const chips = h('div', { class: 'kartu-warna', role: 'radiogroup', 'aria-label': 'Warna kartu' });
  let hsv = hexToHsv(temaKartu(warna).bg), riwayat = bacaRiwayat(), tm = 0;
  const bgNow = () => temaKartu(warna).bg;
  const ganti = (w, dariHsv) => { warna = lastWarna = w; if (!dariHsv) hsv = hexToHsv(bgNow()); paint(); clearTimeout(tm); tm = setTimeout(buat, dariHsv ? 120 : 0); };
  const selesai = () => { if (!WARNA_KARTU[warna]) { riwayat = tambahRiwayat(riwayat, warna); simpanRiwayat(riwayat); paintRiw(); } };
  const lain = h('button', { type: 'button', role: 'radio', class: 'kartu-chip kartu-lain', 'data-w': 'lain', 'aria-expanded': 'false', onclick: () => { if (busy) return; const buka = pick.hidden; pick.hidden = !buka; ov.classList.toggle('kpick', buka); lain.setAttribute('aria-expanded', String(buka)); if (buka && WARNA_KARTU[warna]) ganti(hsvToHex(...hsv), true); paint(); } }, 'Lainnya');
  for (const k of Object.keys(WARNA_KARTU)) {
    const t = temaKartu(k);
    chips.append(h('button', { type: 'button', role: 'radio', class: 'kartu-chip', 'data-w': k, style: 'background:' + t.bg + ';color:' + t.ink, onclick: () => { if (busy || warna === k) return; ganti(k); } }, NAMA[k]));
  }
  chips.append(lain);
  // pemilih warna bebas: kotak (kejenuhan x kecerahan) + pita rona + kode hex
  const knobSv = h('i', { class: 'kartu-knob' }), knobHue = h('i', { class: 'kartu-knob' });
  const sv = h('div', { class: 'kartu-sv', 'aria-label': 'Kecerahan dan kejenuhan warna' }, knobSv), hue = h('div', { class: 'kartu-hue', 'aria-label': 'Rona warna' }, knobHue);
  const hex = h('input', { class: 'kartu-hex', type: 'text', maxlength: '7', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Kode warna hex' });
  const seret = (el, fn) => {
    const pos = (e) => { const r = el.getBoundingClientRect(); fn(Math.min(1, Math.max(0, (e.clientX - r.left) / (r.width || 1))), Math.min(1, Math.max(0, (e.clientY - r.top) / (r.height || 1)))); };
    el.addEventListener('pointerdown', (e) => { if (busy) return; e.preventDefault(); el.setPointerCapture(e.pointerId); pos(e); });
    el.addEventListener('pointermove', (e) => { if (el.hasPointerCapture(e.pointerId)) pos(e); });
    const akhir = (e) => { if (el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId); };
    el.addEventListener('pointerup', akhir); el.addEventListener('pointercancel', akhir);
  };
  seret(sv, (x, y) => { hsv = [hsv[0], x, 1 - y]; ganti(hsvToHex(...hsv), true); });
  seret(hue, (x) => { hsv = [x * 359.99, hsv[1] || 0.5, hsv[2] || 0.9]; ganti(hsvToHex(...hsv), true); });
  hex.addEventListener('change', () => { const n = normHex(hex.value); if (!n) { tWarn('Kode warna harus 6 huruf atau angka, contoh #F2C94C.'); hex.value = bgNow().toUpperCase(); return; } ganti(n); });
  const pick = h('div', { class: 'kartu-pick', hidden: 'true' }, sv, h('div', { class: 'kartu-pickl' }, 'Rona'), hue, h('label', { class: 'kartu-pickl kartu-hexrow' }, h('span', {}, 'Kode warna'), hex));
  const riw = h('div', { class: 'kartu-riw', role: 'group', 'aria-label': 'Warna terakhir dipakai' });
  function paintRiw() {
    riw.replaceChildren(); riw.hidden = !riwayat.length; if (!riwayat.length) return;
    riw.append(h('span', { class: 'kartu-pickl' }, 'Terakhir dipakai'));
    for (const c of riwayat) riw.append(h('button', { type: 'button', class: 'kartu-dot', 'aria-label': 'Warna ' + c.toUpperCase(), 'data-c': c, 'aria-pressed': String(c === warna), style: 'background:' + c, onclick: () => { if (busy) return; ganti(c); } }));
  }
  function paint() {
    const custom = !WARNA_KARTU[warna];
    chips.querySelectorAll('button').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.w === 'lain' ? custom : b.dataset.w === warna)));
    sv.style.backgroundColor = hsvToHex(hsv[0], 1, 1); knobSv.style.left = hsv[1] * 100 + '%'; knobSv.style.top = (1 - hsv[2]) * 100 + '%'; knobSv.style.background = bgNow();
    knobHue.style.left = hsv[0] / 360 * 100 + '%'; knobHue.style.background = hsvToHex(hsv[0], 1, 1);
    if (document.activeElement !== hex) hex.value = bgNow().toUpperCase();
    riw.querySelectorAll('.kartu-dot').forEach((d) => d.setAttribute('aria-pressed', String(d.dataset.c === bgNow())));
  }
  paintRiw(); paint();

  async function buat() {
    const my = ++tok; last = null; segar(); info.textContent = 'Membuat kartu...';
    try {
      if (sheetsHaveFx(ctx.data.sheets)) await loadEngine(); // hasil rumus harus lengkap
      if (images === null) { try { images = await loadShareImages(n); } catch (e) { images = false; catatan = ' Gambar di catatan tidak ikut karena tidak bisa dimuat.'; } }
      const r = await renderKartu(n, { warna, images: images || null });
      if (my !== tok || !alive()) return;
      lepas(); url = URL.createObjectURL(new Blob([r.bytes], { type: 'image/jpeg' })); img.src = url; last = r;
      info.textContent = (r.cut ? 'Catatan panjang: bagian akhirnya dipotong, selengkapnya ada di catatan.' : 'Kartu siap dikirim.') + catatan;
    } catch (e) {
      if (my !== tok || !alive()) return;
      console.error('kartu gagal:', e); info.textContent = 'Kartu gagal dibuat: ' + msgOf(e);
    }
    segar();
  }

  async function kirim(mode) {
    if (busy || !last) return; busy = true; const bytes = last.bytes; bBagi.disabled = bSimpan.disabled = true; if (bWa) bWa.disabled = true;
    const now = new Date(), hm = String(now.getHours()).padStart(2, '0') + String(now.getMinutes()).padStart(2, '0');
    const nama = shareFileName(n.title, 'jpg', now).replace(/-(\d{8})\.jpg$/, (m, d) => '-' + d + (mode === 'save' ? '-' + hm : '') + '-kartu.jpg');
    const f = { name: nama, mime: 'image/jpeg', bytes };
    try {
      if (mode === 'save') {
        const r = await simpanGaleri(f); busy = false; tutup();
        if (r.galeri) tOk('Tersimpan di ' + r.where + '.');
        else if (/^Diunduh/.test(r.where)) tOk(r.where + ': ' + nama);
        else tOk('Tersimpan di ' + r.where + '/' + nama + (r.alasan ? ' (galeri tidak tersedia di HP ini).' : ''));
      } else if (mode === 'wa') { await kirimWhatsApp(f); busy = false; if (alive()) tutup(); }
      else { await sendFiles([f], n.title); busy = false; if (alive()) tutup(); }
    } catch (e) {
      busy = false; if (alive()) segar();
      if (!/cancel/i.test(msgOf(e))) { console.error('kirim kartu gagal:', e); tErr(mode === 'wa' ? msgOf(e) : 'Gagal ' + (mode === 'save' ? 'menyimpan' : 'membagikan') + ' kartu: ' + msgOf(e)); }
    }
  }

  ov.append(h('div', { class: 'sheet', role: 'dialog', 'aria-label': 'Gambar kartu' },
    h('h3', {}, 'Gambar kartu'), h('div', { class: 'kartu-pv' }, img), chips, pick, riw, info,
    ...(bWa ? [bWa] : []), h('div', { class: 'kartu-aksi' }, bBagi, bSimpan),
    h('button', { type: 'button', class: 'btn line kartu-tutup', onclick: tutup }, 'Tutup')));
  document.body.append(ov); segar(); buat();
}
