// Rev 380 / AL3b-2: pemilih mode pengingat (rancangan 1B: dua kartu dengan keterangan) + dialog izin layar penuh + peringatan APK lama.
// Modul MALAS (dimuat lewat import() saat lembar Ingatkan saya dibuka), jadi tidak menambah modul statis. Tanpa data sendiri: pemanggil menyimpan mode lewat aturan masing-masing.
import { h, ico, tWarnAtas, dlg } from './ui.js';
import { cleanMode, fullScreenAllowed, openFullScreenSettings, canScheduleAlarm } from './logic.js';

export const BELL_PATH = 'M6 17h12l-1.5-2V10a4.5 4.5 0 0 0-9 0v5zM10 20a2 2 0 0 0 4 0';
export const CLOCK_PATH = 'M12 20a7 7 0 100-14 7 7 0 000 14zM12 9.5V13l2.5 1.5M4 6l3-2.5M20 6l-3-2.5';
export const MODE_CARDS = [
  { id: 'notif', title: 'Notifikasi', hint: 'Muncul diam-diam di bilah atas', path: BELL_PATH },
  { id: 'alarm', title: 'Alarm', hint: 'Berdering seperti jam alarm sampai dimatikan', path: CLOCK_PATH },
];
export const modeApi = () => globalThis.AndroidAPI || globalThis.KelimaaNative || null;
export const modeIconPath = (mode) => (cleanMode(mode) === 'alarm' ? CLOCK_PATH : BELL_PATH);

// Dialog izin layar penuh: hanya bila jembatan memastikan izin BELUM ada (false). null (peramban/APK lama) = tidak menampilkan apa-apa.
export function askFullScreen(a = modeApi()) {
  if (fullScreenAllowed(a) !== false) return false;
  dlg({ title: 'Izinkan layar penuh', msg: 'Agar alarm tampil di layar kunci, aktifkan \u201cNotifikasi layar penuh\u201d untuk Notes Kelimaa. Tanpa izin, alarm tetap berbunyi sebagai notifikasi.', yes: 'Buka pengaturan', ok: () => { openFullScreenSettings(a); } });
  return true;
}
// APK lama tanpa scheduleAlarm: mode alarm jatuh ke notifikasi biasa. Hanya bila jembatan ADA tetapi belum mendukung.
export function alarmUnsupported(a = modeApi()) { return !!a && !canScheduleAlarm(a); }

// Pemilih dua kartu. onChange(mode) dipanggil sesudah pilihan berubah. Mengembalikan { el, get, set }.
export function modePicker({ mode = 'notif', onChange = null, a = modeApi() } = {}) {
  let cur = cleanMode(mode);
  const btns = MODE_CARDS.map((c) => h('button', { type: 'button', class: 'am-card', role: 'radio', 'aria-checked': 'false', 'data-mode': c.id, onclick: () => pick(c.id, true) },
    h('b', {}, ico(c.path), c.title), h('small', {}, c.hint)));
  const paint = () => btns.forEach((b) => b.setAttribute('aria-checked', String(b.getAttribute('data-mode') === cur)));
  const pick = (m, user) => {
    const changed = m !== cur; cur = m; paint();
    if (changed && onChange) onChange(cur);
    if (user && changed && cur === 'alarm') { if (alarmUnsupported(a)) tWarnAtas('Versi aplikasi ini belum mendukung alarm berdering. Pengingat berbunyi sebagai notifikasi biasa.'); else askFullScreen(a); }
  };
  paint();
  const el = h('div', { class: 'am-wrap' }, h('div', { class: 'rm-seglab' }, 'Cara mengingatkan'), h('div', { class: 'am-cards', role: 'radiogroup', 'aria-label': 'Cara mengingatkan' }, ...btns));
  return { el, get: () => cur, set: (m) => { cur = cleanMode(m); paint(); } };
}

// Rev 394 / SM3 (varian B dipilih pengguna): sakelar satu baris "Alarm berdering" untuk pengingat SATU sub-tugas. onChange(mode) sesudah berubah.
export function modeSwitch({ mode = 'notif', onChange = null, a = modeApi() } = {}) {
  let cur = cleanMode(mode);
  const el = h('button', { type: 'button', class: 'am-sw', role: 'switch', 'aria-checked': 'false', 'aria-label': 'Alarm berdering' },
    h('span', { class: 'am-swi' }, ico(CLOCK_PATH)), h('span', { class: 'am-swt' }, h('b', {}, 'Alarm berdering'), h('small', {}, 'Berdering sampai dimatikan.')), h('span', { class: 'am-tg', 'aria-hidden': 'true' }));
  const paint = () => el.setAttribute('aria-checked', String(cur === 'alarm'));
  el.addEventListener('click', () => {
    cur = cur === 'alarm' ? 'notif' : 'alarm'; paint(); if (onChange) onChange(cur);
    if (cur === 'alarm') { if (alarmUnsupported(a)) tWarnAtas('Versi aplikasi ini belum mendukung alarm berdering. Pengingat berbunyi sebagai notifikasi biasa.'); else askFullScreen(a); }
  });
  paint();
  return { el, get: () => cur, set: (m) => { cur = cleanMode(m); paint(); } };
}
