// Layar Catatan: daftar, geser untuk hapus, dan editor layar penuh.
import { h, ico, icoMenu, PATH, toast, dlg, judul, infoPast, infoKey, tOk, tWarn, tErr, tInfo } from './ui.js';
import { swbgEl, arahGeser, arahTampil } from './ui.js';
import { insertTodoLines, insertTodo, healTodoRow, healTodoStructure, healListCids, boxOf, isTodoBlank, newTodoRow, todoToPlain, mergeNextTodo, caretLeftOfBox, caretAfterBox } from './todo.js';
import { createHistory } from './undo.js';
import { syncBars } from './native.js';
import { createTableHTML, tableSize, TABLE_MIN_ROWS, TABLE_PICK_ROWS, TABLE_MIN_COLS, TABLE_MAX_COLS, COL_W_RE, normalizeTableWidths } from './tabel.js';
import { refreshTotals, setColumnTotal, totalFuncOf, totalLabel, isTotalRow, dataRowsOf } from './tabel-total.js';
import { createChipBar, TABLE_CHIPS, withSheetChip, TABLE_EDIT_MAX_ROWS, TABLE_EDIT_MAX_COLS, tableDims, tableLimits, addTableRow, addTableCol, deleteTableRow, deleteTableCol, toggleHeader, headerFlags, nextAlign, alignLabel, scopeLabel, FOLD_IN_CHIPS, FOLD_OUT_CHIPS } from './bilah-chip.js';
import { applyFontScale, clampFontScale, flattenFontScale, FONT_LEVELS, FONT_LEVEL_NAMES, nearestFontLevel } from './ukuran.js';
import { openShare } from './share.js';
import * as PL from './pilih.js';
import { fetchPreview, openExternal } from './links.js';
import { scheduleReminder, cancelReminder, fromLocalInput, toLocalInput } from './reminders.js';
import { newCid, CID_RE, rowsFromHtml, blocksFromHtml, cidsInHtml, presetsFor, bellState, ruleIsLive, describeRule, checkChoice, MIN_LEAD_MS, setCbRule, clearCbRule, nextOccurrences, REPEATS, REPEAT_LABELS, REPEAT_HINTS, MAX_CB_PER_NOTE, newBid, bidsInHtml, BID_PATTERN, cdOptions, setCdRule, clearCdRule, cdLiveCount, CD_MAX_BLOCKS, setCdMode } from './ingatkan.js';
import { cancelNoteAlarms, cancelRowAlarms, cancelCdAlarms, syncNoteAlarms, reconcileNoteAlarms, noteHasRem } from './cb-alarm.js';
import { healAllFolds, makeFold, toggleFold, isFold, isFoldOpen, arrowHit, headOf, openToBody, bodyRowOf, isPlainRow, isBlankBlock, foldHead, endOfHead, exitFoldFromBody, unfoldToParagraph, mergeFirstRowIntoHead, foldMoveContext, moveBlockIntoFold, moveBlockOutOfFold } from './lipat.js';
import * as G from './gambar.js';
import { imageFS, compressImage, writeImage, hydrateImages, readImageBlob, markImagesUnavailable } from './gambar-app.js';
import { openViewer, closeViewer } from './penampil.js';
import { registerBlock, hydrateBlocks, stripBlockTools } from './blok.js';
import { countSheetRefs, sheetUsage } from './lembar-siklus.js';
import * as LZ from './lembar-pulau.js'; // Rev 122 / U7b-1: pulau pratinjau lembar kerja di catatan (lewat perantara; bukan langsung ke model)
import { getEngine, loadEngine, onEngine } from './lembar-mesin.js'; // Rev 192b / P2b: mesin rumus dimuat belakangan
import { openSheet as openLembar } from './lembar-pintu.js'; // Rev 192 / P2a: Promise; modul layar lembar dimuat saat dibuka
import { matrixFromTable, sheetFromMatrix, setSheetsSource, renderIsland, refreshIslands, stripIsland, islandText, sheetById, noteSheetSearchText, notePreviewText } from './lembar-pulau.js';
import { localDateISO, isValidDateISO, formatDateID } from './tanggal.js';
import { localTimeHM, isValidTimeHM, formatTimeID } from './waktu.js';
import { addLocalDays, cleanCountdownTitle, countdownDays, countdownLabel, countdownDateLine, countdownBadge } from './hitung-mundur.js';
import { HEX, removeLabel, normalizeHex, contrast, hsvToHex, hexToHsv, SUGGEST_LIGHT, SUGGEST_DARK, filterNotes, sortNotes, addRecent, newId, formatEdited, noteSignature, validateLabel, toggleId, noteLabels, labelCounts, extractUrls, urlAtOffset, modeFor, hostOf, safeImageUrl, cleanLinks, linkedNotes, backlinks, toggleLink, linkCandidates, addDuplicate, withMode, parseCheckLine } from './logic.js';

const OK = new Set(['B', 'I', 'S', 'STRIKE', 'U', 'STRONG', 'EM', 'UL', 'OL', 'LI', 'DIV', 'P', 'BLOCKQUOTE', 'BR', 'SPAN', 'SMALL', 'FONT', 'INPUT', 'TABLE', 'TBODY', 'TR', 'TD', 'TH', 'FIGURE']);

// Rev C-2: blok Suasana hati. Judul dan sorotan wajah SELALU diturunkan dari data-mood-value (tidak dipercaya dari HTML tersimpan).
export const MOOD_LABELS = ['Sangat buruk', 'Kurang baik', 'Biasa saja', 'Baik', 'Sangat baik'];
export function syncMood(block) {
  const raw = Number(block.getAttribute('data-mood-value'));
  const v = Number.isInteger(raw) && raw >= 0 && raw <= 4 ? raw : 4;
  block.setAttribute('data-mood-value', String(v));
  if (!/^(small|normal|large)$/.test(block.getAttribute('data-mood-size') || '')) block.setAttribute('data-mood-size', 'normal');
  const title = block.querySelector('.mood-title'); if (title) title.textContent = MOOD_LABELS[v];
  block.querySelectorAll('.mood-face').forEach((f) => {
    const fv = Number(f.getAttribute('data-mood-value'));
    f.classList.toggle('selected', fv === v);
    if (f.textContent) f.textContent = ''; // Rev D: wajah digambar CSS; emoji lama dari catatan tersimpan dibuang agar tidak dobel
    if (MOOD_LABELS[fv]) f.setAttribute('aria-label', MOOD_LABELS[fv]);
  });
}

// U2a: Suasana hati menjadi jenis pertama pada registri blok pulau.
registerBlock({ type: 'mood', selector: '.mood-block', render: syncMood, strip: (el) => el.querySelectorAll('.mood-tools').forEach((tool) => tool.remove()), toText: (el) => { const v = Number(el.getAttribute('data-mood-value')); return 'Suasana hati: ' + (MOOD_LABELS[v] || MOOD_LABELS[4]); } });

// Rev 89: blok sisipan tidak boleh memuat blok lain. Catatan yang sempat rusak (blok masuk ke dalam teks Tanggal/Waktu)
// diperbaiki otomatis: blok bersarang dikeluarkan ke sesudah induknya dan sisa teks yang terbelah dibuang.
const BLOCK_SEL = '.kb-date-block,.kb-time-block,.kb-countdown-block,.mood-block,.lk-card';
function ejectNestedBlocks(block) {
  let after = block;
  for (const n of [...block.querySelectorAll(BLOCK_SEL)]) {
    if (!n.parentElement || n.parentElement.closest(BLOCK_SEL) !== block) continue;
    after.after(n); after = n;
  }
}
// Rev 83 / U3a: blok Tanggal menyimpan tanggal lokal tetap (bukan tanggal dinamis saat dibuka).
export function syncDateBlock(block) {
  ejectNestedBlocks(block);
  const raw = block.getAttribute('data-kb-date') || '';
  const value = isValidDateISO(raw) ? raw : localDateISO();
  block.setAttribute('data-kb-date', value);
  block.setAttribute('contenteditable', 'false');
  let label = block.querySelector('.kb-date-value');
  if (!label) { label = document.createElement('span'); label.className = 'kb-date-value'; block.append(label); }
  label.textContent = formatDateID(value);
  block.replaceChildren(label);
}
registerBlock({ type: 'date', selector: '.kb-date-block', render: syncDateBlock, toText: (el) => 'Tanggal: ' + formatDateID(el.getAttribute('data-kb-date') || '') });

// Rev 84 / U3b: blok Waktu menyimpan jam-menit lokal saat disisipkan (nilai tetap).
export function syncTimeBlock(block) {
  ejectNestedBlocks(block);
  const raw = block.getAttribute('data-kb-time') || '';
  const value = isValidTimeHM(raw) ? raw : localTimeHM();
  block.setAttribute('data-kb-time', value);
  block.setAttribute('contenteditable', 'false');
  let label = block.querySelector('.kb-time-value');
  if (!label) { label = document.createElement('span'); label.className = 'kb-time-value'; block.append(label); }
  label.textContent = formatTimeID(value);
  block.replaceChildren(label);
}
registerBlock({ type: 'time', selector: '.kb-time-block', render: syncTimeBlock, toText: (el) => 'Waktu: ' + formatTimeID(el.getAttribute('data-kb-time') || '') });

// Rev 85 / U3c: kartu Hitung Mundur; tanggal dan waktu disimpan sebagai nilai lokal tetap.
export function syncCountdownBlock(block, now = new Date()) {
  const rawDate = block.getAttribute('data-kb-date');
  const date = isValidDateISO(rawDate || '') ? rawDate : addLocalDays(now, 7);
  const rawTime = block.getAttribute('data-kb-time') || '';
  const time = isValidTimeHM(rawTime) ? rawTime : '';
  const title = cleanCountdownTitle(block.getAttribute('data-kb-title') || '');
  block.setAttribute('data-kb-date', date);
  block.setAttribute('data-kb-title', title);
  if (time) block.setAttribute('data-kb-time', time); else block.removeAttribute('data-kb-time');
  block.setAttribute('contenteditable', 'false');
  block.setAttribute('role', 'button');
  block.setAttribute('tabindex', '0');
  const days = countdownDays(date, now);
  block.setAttribute('data-kb-state', days === 0 ? 'today' : days < 0 ? 'past' : 'upcoming');
  const badge = countdownBadge(date);
  let month = block.querySelector('.kb-cd-month'); if (!month) { month = document.createElement('span'); month.className = 'kb-cd-month'; }
  let day = block.querySelector('.kb-cd-day'); if (!day) { day = document.createElement('strong'); day.className = 'kb-cd-day'; }
  month.textContent = badge.month; day.textContent = badge.day;
  let badgeEl = block.querySelector('.kb-cd-badge'); if (!badgeEl) { badgeEl = document.createElement('span'); badgeEl.className = 'kb-cd-badge'; }
  badgeEl.replaceChildren(month, day);
  let copy = block.querySelector('.kb-cd-copy'); if (!copy) { copy = document.createElement('span'); copy.className = 'kb-cd-copy'; }
  let titleEl = block.querySelector('.kb-cd-title'); if (!titleEl) { titleEl = document.createElement('strong'); titleEl.className = 'kb-cd-title'; }
  titleEl.textContent = title || 'Apa yang Anda nantikan?';
  let remaining = block.querySelector('.kb-cd-remaining'); if (!remaining) { remaining = document.createElement('strong'); remaining.className = 'kb-cd-remaining'; }
  remaining.textContent = countdownLabel(date, now);
  let dateEl = block.querySelector('.kb-cd-date'); if (!dateEl) { dateEl = document.createElement('small'); dateEl.className = 'kb-cd-date'; }
  dateEl.textContent = countdownDateLine(date, time);
  copy.replaceChildren(titleEl, remaining, dateEl);
  block.replaceChildren(badgeEl, copy);
  block.setAttribute('aria-label', `Hitung mundur ${title || 'tanpa judul'}, ${countdownLabel(date, now)}`);
  return { date, time, title, days };
}
registerBlock({ type: 'cd', selector: '.kb-countdown-block', render: syncCountdownBlock, toText: (el) => { const v = syncCountdownBlock(el); return `Hitung mundur: ${v.title || 'Tanpa judul'}, ${countdownDateLine(v.date, v.time)} (${countdownLabel(v.date)})`; } });
// Rev 122 / U7b-1: Lembar kerja = pulau pratinjau (HTML hanya menyimpan data-sheet; isi sel di data.sheets).
// Rev 323 / L2: Kartu tautan = cangkang kosong (data-u wajib; tampilan dibuat MALAS oleh linkcard-ui.js). Aturan atribut = linkCardAttrOk di linkcard.js (tes rev323 membandingkan keduanya).
const LK_CT = /[\u0000-\u001f\u007f]/;
const lkU = (v) => { if (v.length > 2000 || /\s/.test(v) || LK_CT.test(v) || !/^https?:\/\//i.test(v)) return false; try { const p = new URL(v); return !p.username && !p.password && /^[^.]+(\.[^.]+)*\.[a-z]{2,}$/i.test(p.hostname) && p.href.length <= 2000; } catch (_) { return false; } };
const lkOk = (k, v) => (k === 'class' ? v === 'lk-card' : k === 'contenteditable' ? v === 'false' : k === 'data-u' ? lkU(v) : k === 'data-t' ? v.length <= 140 && !LK_CT.test(v) : k === 'data-s' ? v.length <= 60 && !LK_CT.test(v) : k === 'data-i' ? v.length <= 2000 && safeImageUrl(v) !== '' : k === 'data-a' ? /^[lcr]$/.test(v) : false);
registerBlock({ type: 'lk', selector: '.lk-card', render: (el) => { if (!el.firstChild) import('./linkcard-ui.js').then((m) => m.renderCard(el), () => {}); }, strip: (el) => el.replaceChildren(), toText: (el) => 'Tautan: ' + (el.getAttribute('data-t') ? el.getAttribute('data-t') + ' - ' : '') + (el.getAttribute('data-u') || '') });
registerBlock({ type: 'sheet', selector: '.ksheet', render: renderIsland, strip: stripIsland, toText: (el) => islandText(sheetById(el.getAttribute('data-sheet') || '')) });

let current = null;
let trail = []; // jejak id catatan yang ditinggalkan saat pindah lewat chip "Catatan terkait" (Kembali = ke catatan sebelumnya)
const failedLinks = new Set(); // tautan yang gagal dimuat pada sesi ini (tidak diulang terus-menerus)
if (typeof window !== 'undefined') window.addEventListener('online', () => failedLinks.clear());
const TCOL = ['#D63A55', '#E08A2E', '#3F8F6B', '#3B6FD6', '#8A5CD6', '#6B6275'];

// Membersihkan HTML catatan: hanya tag dan atribut format yang aman.
export function sanitize(html) {
  const t = document.createElement('template'); t.innerHTML = html;
  stripBlockTools(t.content); // seluruh alat blok bersifat sementara; jangan pernah ikut tersimpan/cadangan/ekspor
  (function walk(n, inCell = false) {
    for (const c of [...n.childNodes]) {
      if (c.nodeType === 3) continue;
      if (c.nodeType !== 1 || !OK.has(c.tagName)) { c.remove(); continue; }
      const cell = inCell || c.tagName === 'TD' || c.tagName === 'TH';
      // Rev 33: sel di tabel hanya teks/format inline; cegah struktur bersarang yang merusak tabel.
      if (inCell && ['TABLE', 'TBODY', 'TR', 'TD', 'TH', 'UL', 'OL', 'LI', 'INPUT'].includes(c.tagName)) { c.remove(); continue; }
      if (c.tagName === 'INPUT' && c.getAttribute('type') !== 'checkbox') { c.remove(); continue; }
      const lk = c.tagName === 'DIV' && c.getAttribute('class') === 'lk-card'; // Rev 323 / L2
      for (const a of [...c.attributes]) {
        const k = a.name, v = a.value;
        const cleanStyle = v.replace(/ /g, '');
        const safeStyle = cleanStyle.split(';').filter(Boolean).every((part) => /^color:#?[0-9a-zA-Z(),.%]+$/.test(part) || /^font-size:(?:[7-9]\d|1\d\d|2[0-4]\d|250)%$/.test(part));
        const ok = (k === 'style' && safeStyle)
          || (k === 'data-fs' && /^(?:[7-9]\d|1\d\d|2[0-4]\d|250)$/.test(v))
          || (k === 'color' && /^#?[0-9a-fA-F]{3,6}$/.test(v))
          || (k === 'class' && (v === 'todo' || ((['DIV','SPAN','STRONG'].includes(c.tagName) && ['tbl-wrap','mood-block','mood-head','mood-faces','mood-face','mood-menu','mood-title','kb-date-block','kb-date-value','kb-time-block','kb-time-value','kb-countdown-block','kb-cd-badge','kb-cd-month','kb-cd-day','kb-cd-copy','kb-cd-title','kb-cd-remaining','kb-cd-date'].includes(v)) || (c.tagName === 'SMALL' && v === 'kb-cd-date') || (c.tagName === 'TR' && v === 'tt') || (c.tagName === 'DIV' && ['fold', 'fh', 'fb'].includes(v))) || (c.tagName === 'SPAN' && v === 'mood-face selected') || (c.tagName === 'FIGURE' && v === 'ki')))
          || (c.tagName === 'DIV' && k === 'contenteditable' && v === 'false' && (c.classList.contains('mood-block') || c.classList.contains('kb-date-block') || c.classList.contains('kb-time-block') || c.classList.contains('kb-countdown-block')))
          || (c.tagName === 'DIV' && k === 'class' && v === 'ksheet') // Rev 122 / U7b-1
          || (c.tagName === 'SPAN' && (k === 'class' ? v === 'nl' : c.classList.contains('nl') && (k === 'contenteditable' ? v === 'false' : k === 'data-nid' && /^[\w-]{4,40}$/.test(v)))) // Rev 343 / I2: tautan [[
          || (c.tagName === 'DIV' && k === 'contenteditable' && v === 'false' && c.classList.contains('ksheet'))
          || (c.tagName === 'DIV' && k === 'data-sheet' && LZ.isSheetId(v) && c.classList.contains('ksheet'))
          || (c.tagName === 'DIV' && k === 'data-mood-size' && /^(small|normal|large)$/.test(v))
          || (c.tagName === 'DIV' && k === 'data-kb-size' && /^(small|normal|large)$/.test(v) && (c.classList.contains('kb-date-block') || c.classList.contains('kb-time-block')))
          || (c.tagName === 'DIV' && k === 'data-kb-date' && isValidDateISO(v))
          || (c.tagName === 'DIV' && k === 'data-kb-time' && isValidTimeHM(v))
          || (c.tagName === 'DIV' && k === 'data-kb-title' && v.length <= 80 && !/[\u0000-\u001f\u007f]/.test(v))
          || (['DIV','SPAN'].includes(c.tagName) && k === 'data-mood-value' && /^[0-4]$/.test(v))
          || (c.tagName === 'SPAN' && k === 'data-mood-action' && v === 'menu')
          || (c.tagName === 'FIGURE' && k === 'contenteditable' && v === 'false')
          || (c.tagName === 'FIGURE' && k === 'data-kimg' && G.ID_RE.test(v))
          || (c.tagName === 'FIGURE' && k === 'data-w' && /^[1-9]\d{0,4}$/.test(v))
          || (c.tagName === 'FIGURE' && k === 'data-h' && /^[1-9]\d{0,4}$/.test(v))
          || (c.tagName === 'FIGURE' && k === 'data-b' && /^\d{1,10}$/.test(v))
          || (c.tagName === 'FIGURE' && k === 'data-x' && /^(webp|jpg|png)$/.test(v))
          || (c.tagName === 'FIGURE' && k === 'data-s' && /^(?:[2-9][05]|100)$/.test(v))
          || (c.tagName === 'FIGURE' && k === 'data-a' && /^[lcr]$/.test(v))
          || (c.tagName === 'FIGURE' && k === 'data-l' && v === '1')
          || (c.tagName === 'FIGURE' && k === 'data-f' && v === '1')
          || (k === 'data-cid' && CID_RE.test(v) && ((c.tagName === 'DIV' && c.classList.contains('todo')) || (c.tagName === 'LI' && !!c.parentElement && /^(UL|OL)$/.test(c.parentElement.tagName)))) // Rev 102 / U5b + Rev 347 / R2: id baris centang dan item bullet/bernomor untuk pengingat (note.cbRem)
          || (c.tagName === 'DIV' && k === 'data-kb-id' && BID_PATTERN.test(v) && c.classList.contains('kb-countdown-block')) // Rev 104 / U5d: id kartu hitung mundur untuk pengingat (note.cdRem)
          || (lk && lkOk(k, v)) // Rev 323 / L2: kartu tautan
          || (c.tagName === 'DIV' && k === 'data-o' && v === '1' && c.classList.contains('fold')) // Rev 109 / U6a: bagian lipat terbuka (tertutup = tanpa atribut)
          || (c.tagName === 'TABLE' && k === 'data-w' && COL_W_RE.test(v)) // Rev 318 / U1: lebar kolom tabel (angka px dipisah koma, 0 = otomatis)
          || (c.tagName === 'TD' && k === 'data-f' && /^(?:sum|avg|cnt|min|max)$/.test(v)) // Rev 99: fungsi Total kolom (hanya di sel baris tr.tt; dicek ulang di refreshTotals)
          || (c.tagName === 'TD' && k === 'contenteditable' && v === 'false' && !!c.parentElement && c.parentElement.classList.contains('tt'))
          || ((c.tagName === 'TD' || c.tagName === 'TH') && k === 'data-a' && /^[cr]$/.test(v)) // Rev 76: rata teks sel (kiri = bawaan, tanpa atribut)
          || (c.tagName === 'INPUT' && (k === 'type' || k === 'checked'));
        if (!ok) c.removeAttribute(k);
      }
      walk(c, cell);
    }
  })(t.content);
  t.content.querySelectorAll('.mood-block').forEach((el) => syncMood(el)); // jangan teruskan indeks forEach sebagai parameter kedua (now)
  t.content.querySelectorAll('.kb-date-block').forEach((el) => syncDateBlock(el)); // jangan teruskan indeks forEach sebagai parameter kedua (now)
  t.content.querySelectorAll('.kb-time-block').forEach((el) => syncTimeBlock(el)); // jangan teruskan indeks forEach sebagai parameter kedua (now)
  t.content.querySelectorAll('.lk-card').forEach((el) => { if (!lkU(el.getAttribute('data-u') || '')) el.remove(); else { el.replaceChildren(); el.removeAttribute('style'); el.setAttribute('contenteditable', 'false'); } }); // Rev 323 / L2: kartu tanpa alamat sah dibuang, isi tampilan tidak pernah disimpan
  t.content.querySelectorAll('span.nl:not([data-nid])').forEach((el) => el.replaceWith(el.textContent)); // I2: tautan tanpa id = teks biasa
  t.content.querySelectorAll('.kb-countdown-block').forEach((el) => syncCountdownBlock(el)); // jangan teruskan indeks forEach sebagai parameter kedua (now)
  t.content.querySelectorAll('table[data-w]').forEach((tb) => normalizeTableWidths(tb)); // Rev 318 / U1: dijepit 56-320 dan disesuaikan jumlah kolom
  t.content.querySelectorAll('table').forEach((tb) => refreshTotals(tb)); // Rev 99 / U4d: nilai baris Total selalu dihitung ulang, hanya data-f yang dipercaya
  // Rev 102 / U5b: data-cid hanya sah di div.todo; cid kembar (salin/tempel baris) diberi cid BARU dan TIDAK mewarisi pengingat (cbRem hanya menunjuk cid asli).
  const seenCid = new Set();
  t.content.querySelectorAll('[data-cid]').forEach((el) => {
    const isLi = el.tagName === 'LI';
    if (!isLi && (el.tagName !== 'DIV' || !el.classList.contains('todo'))) { el.removeAttribute('data-cid'); return; }
    const cid = el.getAttribute('data-cid');
    if (!seenCid.has(cid)) { seenCid.add(cid); return; }
    if (isLi) { el.removeAttribute('data-cid'); return; } // R2: li kembar tidak mewarisi pengingat dan tidak diberi cid baru
    const fresh = newCid([...seenCid, ...[...t.content.querySelectorAll('[data-cid]')].map((x) => x.getAttribute('data-cid'))]);
    seenCid.add(fresh); el.setAttribute('data-cid', fresh);
  });
  // Rev 104 / U5d: bid kembar (kartu hitung mundur disalin/ditempel) = bid BARU tanpa pengingat (cdRem hanya menunjuk bid asli; yang PERTAMA menurut urutan dokumen tetap asli).
  const seenBid = new Set();
  t.content.querySelectorAll('.kb-countdown-block[data-kb-id]').forEach((el) => {
    const bid = el.getAttribute('data-kb-id');
    if (!seenBid.has(bid)) { seenBid.add(bid); return; }
    const fresh = newBid([...seenBid, ...[...t.content.querySelectorAll('[data-kb-id]')].map((x) => x.getAttribute('data-kb-id'))]);
    seenBid.add(fresh); el.setAttribute('data-kb-id', fresh);
  });
  // Rev 109 / U6a: struktur bagian lipat dipulihkan (di sel tabel/kutipan/daftar/bersarang diratakan; blok terlarang di isi dipindah keluar); .fh/.fb yatim kehilangan kelasnya.
  healAllFolds(t.content, t.content.ownerDocument);
  t.content.querySelectorAll('div.fh,div.fb').forEach((el) => { if (!el.parentElement || !el.parentElement.classList.contains('fold')) el.removeAttribute('class'); });
  t.content.querySelectorAll('.todo').forEach((row) => healTodoStructure(row, t.content.ownerDocument)); // Rev 107/108: teks di kiri kotak dipindah ke kanan; baris centang yatim (tanpa kotak) diberi kotak; kotak ganda dibuang (catatan lama ikut sembuh)
  flattenFontScale(t.content);
  return t.innerHTML;
}

// Teks polos untuk pratinjau daftar dan pencarian: blok Suasana hati diringkas jadi satu baris, bukan deretan wajah dan tombol.
export function notePlain(ed) {
  // Rev 110 / U6b: isi bagian lipat yang TERTUTUP disembunyikan CSS sehingga innerText melewatinya; dibuka sebentar lalu dikembalikan (observer lonceng hanya mengamati data-cid/checked).
  const shut = [...ed.querySelectorAll('div.fold:not([data-o="1"])')];
  shut.forEach((f) => f.setAttribute('data-o', '1'));
  let txt = '';
  try { txt = ed.innerText || ''; } finally { shut.forEach((f) => f.removeAttribute('data-o')); }
  ed.querySelectorAll('.mood-block').forEach((b) => {
    const raw = b.innerText || ''; const v = Number(b.getAttribute('data-mood-value'));
    const short = 'Suasana hati: ' + (MOOD_LABELS[v] || MOOD_LABELS[4]);
    if (raw && txt.includes(raw)) txt = txt.replace(raw, short); else txt += '\n' + short;
  });
  ed.querySelectorAll('.kb-date-block').forEach((b) => {
    const raw = b.innerText || ''; const short = 'Tanggal: ' + formatDateID(b.getAttribute('data-kb-date') || '');
    if (raw && txt.includes(raw)) txt = txt.replace(raw, short); else txt += '\n' + short;
  });
  ed.querySelectorAll('.kb-time-block').forEach((b) => {
    const raw = b.innerText || ''; const short = 'Waktu: ' + formatTimeID(b.getAttribute('data-kb-time') || '');
    if (raw && txt.includes(raw)) txt = txt.replace(raw, short); else txt += '\n' + short;
  });
  ed.querySelectorAll('.kb-countdown-block').forEach((b) => {
    const raw = b.innerText || ''; const v = syncCountdownBlock(b); const short = `Hitung mundur: ${v.title || 'Tanpa judul'}, ${countdownDateLine(v.date, v.time)} (${countdownLabel(v.date)})`;
    if (raw && txt.includes(raw)) txt = txt.replace(raw, short); else txt += '\n' + short;
  });
  ed.querySelectorAll('.lk-card').forEach((b) => { // Rev 325 / L4: kartu tautan diringkas "Tautan: judul - alamat" (sama dengan cardPlain; ikut pencarian + pratinjau daftar)
    const raw = b.innerText || ''; const t = (b.getAttribute('data-t') || '').trim(); const short = 'Tautan: ' + (t ? t + ' - ' : '') + (b.getAttribute('data-u') || '');
    if (raw && txt.includes(raw)) txt = txt.replace(raw, short); else txt += '\n' + short;
  });
  ed.querySelectorAll('.ksheet').forEach((b) => { // Rev 123 / U7b-2: pulau lembar kerja diringkas jadi satu baris (bukan deretan huruf kolom dan angka sel)
    const raw = b.innerText || ''; const short = islandText(sheetById(b.getAttribute('data-sheet') || ''));
    if (raw && txt.includes(raw)) txt = txt.replace(raw, short); else txt += '\n' + short;
  });
  return txt.replace(/\n{3,}/g, '\n\n').trim();
}

function removeNote(ctx, n) {
  cancelReminder('note', n.id);
  cancelNoteAlarms(n); // Rev 102 / U5b: pengingat kotak centang + hitung mundur ikut dibatalkan
  const { data } = ctx; const i = data.notes.indexOf(n); if (i < 0) return;
  data.notes.splice(i, 1);
  data.trash.push({ kind: 'note', item: n, at: Date.now() });
  ctx.persist(); ctx.render();
  tOk('Catatan dipindah ke tempat sampah', () => {
    const j = data.trash.findIndex((x) => x.item === n);
    if (j >= 0) data.trash.splice(j, 1);
    data.notes.splice(Math.min(i, data.notes.length), 0, n);
    if (n.reminder) scheduleReminder('note', n);
    syncNoteAlarms(n); // Rev 102 / U5b: Urungkan hapus = jadwal ulang
    ctx.persist();
  }, ctx.render);
}

function confirmDeletePriv(ctx, n, closeEd) {
  const { data } = ctx;
  const no = closeEd ? () => {} : () => ctx.render();
  dlg({ title: 'Hapus catatan privat?', msg: `\u201c${n.title || 'Tanpa judul'}\u201d akan dihapus. Langkah 1 dari 2.`, yes: 'Lanjut', no,
    ok: () => dlg({ title: 'Yakin dihapus permanen?', msg: 'Tidak masuk tempat sampah dan tidak bisa dikembalikan. Langkah 2 dari 2.', yes: 'Hapus permanen', red: true, reverse: true, no,
      ok: () => {
        if (closeEd) closeEd();
        const i = data.priv.indexOf(n); if (i >= 0) data.priv.splice(i, 1);
        ctx.persist(); ctx.render(); tOk('Catatan privat dihapus permanen');
      } }) });
}

export function closeEditor(kind) {
  trail = [];
  if (current && (!kind || current.kind === kind)) current.close();
}
// Rev 193 / P3: simpan SEKARANG ketikan yang masih menunggu simpan otomatis (dipanggil main.js saat aplikasi ke latar belakang / pagehide). Aman dipanggil kapan saja.
export function flushEditor() { try { if (current && current.flush) current.flush(); } catch (e) { console.error('flush gagal:', e); } }
// Tombol Kembali HP: bila menu ⋮ editor sedang terbuka, tutup menunya saja (Rev 25). true jika ada menu yang ditutup.
export function closeEditorMenu() {
  return !!(current && current.menu && current.menu());
}
// Tombol Kembali HP saat editor terbuka: simpan, tutup, dan segarkan daftar. true jika ada editor yang ditutup.
export function backEditor() {
  if (!current) return false;
  current.back();
  return true;
}

// Gambar kecil pratinjau; jika gagal dimuat (mis. offline) diganti ikon tautan.
function linkIcon(cls) { return h('div', { class: cls }, ico(PATH.link)); }
function thumb(url, cls, phCls) {
  const src = safeImageUrl(url);
  if (!src) return linkIcon(phCls);
  return h('img', { class: cls, src, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer', onerror: (e) => e.target.replaceWith(linkIcon(phCls)) });
}
// Baris tautan pertama di kartu daftar: gambar kecil + judul (atau alamat situs).
function linkRow(n) {
  const u = extractUrls(n.text, 1)[0]; if (!u) return null;
  const pv = n.prev && n.prev[u];
  return h('div', { class: 'lk' }, thumb(pv && pv.i, 'lki', 'lkph'), h('span', { class: 'lkt' }, (pv && pv.t) || hostOf(u)));
}

// Mode pilih daftar (Rev 26): tekan lama kartu = masuk; hasilnya larik id. Logika murni ada di pilih.js.
const selState = { kind: '', ids: [], anchor: '' }; // anchor = kartu terakhir yang dipilih (ujung awal rentang)
let selRefresh = null, selMenuEl = null;
export function closeSelectMenu() {
  if (!selMenuEl) return false;
  const was = selMenuEl.isConnected; selMenuEl.remove(); selMenuEl = null; return was;
}
// Keluar dari mode pilih (tombol Kembali, ✕, pindah tab). true bila memang sedang dalam mode pilih.
export function exitSelect() {
  const was = selState.ids.length > 0; closeSelectMenu();
  selState.ids = []; selState.kind = ''; selState.anchor = '';
  if (was && selRefresh) { try { selRefresh(); } catch (_) {} }
  return was;
}

function card(ctx, n, kind, sel) {
  const t = contrast(n.col);
  const pinBtn = kind === 'priv' ? null : h('button', { type: 'button', class: 'cbd pinb', 'aria-label': n.pin ? 'Lepas sematan' : 'Sematkan', 'aria-pressed': String(!!n.pin), onclick: (e) => { e.stopPropagation(); n.pin = !n.pin; ctx.persist(); ctx.render(); } }, ico(PATH.pin));
  if (pinBtn && n.pin) pinBtn.classList.add('pinned');
  const favBtn = kind === 'priv' ? null : h('button', { type: 'button', class: 'cbd favb' + (n.favorite ? ' favorite' : ''), 'aria-label': n.favorite ? 'Hapus dari favorit' : 'Tambahkan ke favorit', 'aria-pressed': String(!!n.favorite), onclick: (e) => { e.stopPropagation(); n.favorite = !n.favorite; ctx.persist(); ctx.render(); toast(n.favorite ? 'Ditambahkan ke Favorit' : 'Dihapus dari Favorit'); } }, ico(PATH.star));
  // Penanda info di kartu (Rev 25b): terhubung ke catatan lain / ada pengingat. Hanya informasi, tidak bisa diketuk.
  const linked = kind !== 'priv' && (linkedNotes(n, ctx.data.notes).length > 0 || backlinks(ctx.data.notes, n.id).length > 0);
  const info = [linked ? h('span', { class: 'cbd', role: 'img', 'aria-label': 'Terhubung dengan catatan lain' }, ico(PATH.link)) : null,
    n.reminder ? h('span', { class: 'cbd' + (n.reminder.mode === 'alarm' ? ' alm' : ''), role: 'img', 'aria-label': n.reminder.mode === 'alarm' ? 'Alarm berdering' : 'Ada pengingat' }, ico(PATH.alarm)) : null].filter(Boolean);
  const labs = noteLabels(n, ctx.data.settings.labels);
  const imageCount = kind === 'priv' ? 0 : G.parseRefs(n.html || '').length;
  const el = h('div', { class: 'card', style: '--nb:' + (info.length + (pinBtn ? 1 : 0) + (favBtn ? 1 : 0)) + ';--nbtn:' + ((pinBtn ? 1 : 0) + (favBtn ? 1 : 0)) }, h('b', {}, n.title || 'Tanpa judul'), pinBtn, favBtn, n.text ? [h('hr', { class: 'dv' }), h('p', {}, notePreviewText(n))] : null, // Rev 137 / U8b-4: kartu menampilkan isi lembar kerja yang disisipkan
    imageCount ? h('small', { class: 'imeta' }, 'gambar ×' + imageCount) : null,
    linkRow(n),
    labs.length ? h('div', { class: 'lbs' }, labs.slice(0, 3).map((l) => h('span', { class: 'lab' }, l.name)), labs.length > 3 ? h('span', { class: 'lab' }, '+' + (labs.length - 3)) : null) : null,
    info.length ? h('div', { class: 'cin' }, info) : null,
    n.updated ? h('small', { class: 'edt' }, 'Diedit: ' + formatEdited(n.updated)) : null);
  if (t) {
    el.style.background = n.col; el.style.color = t.ink;
    el.style.setProperty('--ink', t.ink); el.style.setProperty('--mut', t.mut); el.style.setProperty('--ln', t.ln);
  }
  const wrap = h('div', { class: 'sw' + (sel.ids.includes(n.id) ? ' sel' : '') }, swbgEl(), el);
  wrap.dataset.id = n.id;
  let x0 = null, y0 = 0, dx = 0, moved = false, lpT = 0, lpDone = false;
  const lpStop = () => { clearTimeout(lpT); lpT = 0; };
  // Rev 26: tekan lama (±450 ms) masuk mode pilih. Gerak > 8 px atau pointercancel = gulir, bukan tekan lama.
  el.addEventListener('contextmenu', (e) => e.preventDefault());
  el.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button')) return;
    x0 = e.clientX; y0 = e.clientY; dx = 0; moved = false; lpDone = false; el.style.transition = 'none';
    lpStop(); lpT = setTimeout(() => { lpT = 0; if (x0 === null) return; lpDone = true; x0 = null; el.style.transform = ''; sel.press(n.id); }, 450);
  });
  el.addEventListener('pointermove', (e) => {
    if (x0 === null) return;
    if (Math.abs(e.clientX - x0) > 8 || Math.abs(e.clientY - y0) > 8) lpStop();
    if (sel.ids.length) return; // saat mode pilih tidak ada geser-hapus
    dx = e.clientX - x0; // Rev 198: ke kiri DAN ke kanan
    const arah = arahTampil(dx); if (arah) moved = true; wrap.dataset.dir = arah; el.style.transform = `translateX(${arah ? dx : 0}px)`;
  });
  const end = () => {
    lpStop();
    if (x0 === null) return; x0 = null; el.style.transition = 'transform .2s';
    if (sel.ids.length) { el.style.transform = ''; return; }
    const arah = arahGeser(dx); // Rev 198: 'kiri' / 'kanan' / ''
    if (arah && kind === 'priv') { el.style.transform = ''; confirmDeletePriv(ctx, n); }
    else if (arah) { el.style.transform = `translateX(${arah === 'kiri' ? -110 : 110}%)`; setTimeout(() => removeNote(ctx, n), 180); } else el.style.transform = '';
    if (!arah) setTimeout(() => { if (x0 === null) delete wrap.dataset.dir; }, 220);
  };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  el.addEventListener('click', () => {
    if (lpDone) { lpDone = false; return; } // click yang menyusul tekan lama ditelan
    if (moved) { moved = false; return; }
    if (sel.ids.length) { sel.tap(n.id); return; }
    openEditor(ctx, n.id, kind);
  });
  return wrap;
}

export function viewNoteList(ctx, kind = 'note') {
  const { data, ui } = ctx; const isP = kind === 'priv'; const qk = isP ? 'qp' : 'q';
  const allArr = isP ? data.priv : data.notes;
  const favoritesRoom = !isP && !!ui.favoritesRoom;
  const arr = favoritesRoom ? allArr.filter((x) => x.favorite === true) : allArr;
  const lf = isP ? 'lfp' : 'lf';
  if (selState.kind && selState.kind !== kind) { selState.ids = []; selState.kind = ''; }
  selState.ids = selState.ids.filter((id) => arr.some((x) => x.id === id)); if (!selState.ids.length) selState.kind = '';
  const used = labelCounts(arr);
  const labs = data.settings.labels.filter((l) => used[l.id]);
  if (ui[lf] && !used[ui[lf]]) ui[lf] = ''; // label yang sudah tidak dipakai: kembali ke "Semua"
  const chip = (text, id) => h('button', { type: 'button', class: 'chp' + ((ui[lf] || '') === id ? ' on' : ''), 'aria-pressed': String((ui[lf] || '') === id), onclick: () => { exitSelect(); ui[lf] = id; ctx.render(); } }, text);
  const chips = labs.length ? h('div', { class: 'chips', role: 'group', 'aria-label': 'Saring berdasarkan label' }, chip('Semua', ''), labs.map((l) => chip(l.name + ' (' + used[l.id] + ')', l.id))) : null;
  const box = h('div');
  const top = h('div', { class: 'selhost' });

  // ---- Mode pilih (Rev 26) ----
  const chosen = () => arr.filter((x) => selState.ids.includes(x.id));
  const done = () => { exitSelect(); ctx.render(); };
  const stamp = (list, now) => { for (const x of list) x.updated = now; };
  const sel = {
    get ids() { return selState.kind === kind ? selState.ids : []; },
    // Gaya ZArchiver (Rev 408): tekan lama pertama = pilih satu kartu. Di dalam mode pilih, tekan lama kartu lain =
    // pilih SEMUA kartu dari kartu terakhir yang dipilih/diketuk (anchor) sampai kartu itu. Tanpa seret dan tanpa gulir.
    press(id) {
      if (!sel.ids.length) { selState.kind = kind; selState.ids = [id]; selState.anchor = id; }
      else if (selState.ids.includes(id)) selState.anchor = id;
      else {
        const a = selState.ids.includes(selState.anchor) ? selState.anchor : selState.ids[selState.ids.length - 1];
        const order = [...box.querySelectorAll('.sw')].map((w) => w.dataset.id);
        selState.ids = PL.dragSelection(selState.ids, order, a, id); selState.anchor = id;
      }
      refresh();
    },
    tap(id) {
      const was = selState.ids.includes(id);
      selState.ids = PL.toggle(selState.ids, id);
      if (!was) selState.anchor = id; else if (selState.anchor === id) selState.anchor = selState.ids[selState.ids.length - 1] || '';
      if (!selState.ids.length) { selState.kind = ''; selState.anchor = ''; } refresh();
    },
  };
  function refresh() {
    for (const w of box.querySelectorAll('.sw')) w.classList.toggle('sel', selState.ids.includes(w.dataset.id));
    top.replaceChildren(selState.ids.length ? bar() : qrow);
    top.classList.toggle('on', selState.ids.length > 0);
  }
  selRefresh = refresh;
  const sbtn = (path, label, fn, cls = '') => h('button', { type: 'button', class: 'ghost sbt' + (cls ? ' ' + cls : ''), 'aria-label': label, title: label, onclick: fn }, ico(path));
  function bar() {
    const k = selState.ids.length;
    return h('div', { class: 'selbar', role: 'toolbar', 'aria-label': 'Mode pilih' },
      sbtn(PATH.close, 'Keluar dari mode pilih', () => exitSelect()),
      h('span', { class: 'selcnt', 'aria-live': 'polite' }, String(k)),
      h('span', { class: 'selsp' }),
      isP ? null : sbtn(PATH.pin, PL.allPinned(arr, selState.ids) ? 'Lepas sematan' : 'Sematkan', () => {
        const to = PL.nextPinState(arr, selState.ids); for (const x of chosen()) x.pin = to;
        ctx.persist(); done(); toast(to ? 'Disematkan' : 'Sematan dilepas');
      }, PL.allPinned(arr, selState.ids) ? 'on' : ''),
      sbtn(PATH.palette, 'Ubah warna', () => openColorSheet()),
      sbtn(PATH.tag, 'Label', () => openLabelSheet()),
      h('button', { type: 'button', class: 'ghost sbt', 'aria-label': 'Menu lainnya', 'aria-haspopup': 'menu', onclick: (e) => openSelMenu(e.currentTarget) }, ico(PATH.more)));
  }
  function sheetOv(title, ...kids) {
    const ov = h('div', { class: 'ov pickov', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    ov.append(h('div', { class: 'sheet pick', role: 'dialog', 'aria-label': title }, h('h3', {}, title), ...kids));
    document.body.append(ov); return ov;
  }
  function openColorSheet() {
    closeSelectMenu();
    const k = selState.ids.length; let ov;
    const apply = (hex) => {
      PL.applyColor(arr, selState.ids, hex); stamp(chosen(), Date.now());
      if (hex) data.settings.recent = addRecent(data.settings.recent, hex);
      ctx.persist(); ov.remove(); done(); toast(hex ? 'Warna diubah (' + k + ' catatan)' : 'Warna dihapus (' + k + ' catatan)');
    };
    const sw = (hex, name) => h('button', { type: 'button', class: 'csw', style: 'background:' + hex, 'aria-label': name, title: name, onclick: () => apply(hex) });
    const rec = (data.settings.recent || []).filter((c) => HEX.test(c));
    ov = sheetOv('Warna untuk ' + k + ' catatan',
      h('button', { type: 'button', class: 'btn line', onclick: () => apply('') }, 'Tanpa warna'),
      rec.length ? [h('div', { class: 'relh' }, 'Terakhir dipakai'), h('div', { class: 'cswg' }, rec.map((c) => sw(c, c)))] : null,
      h('div', { class: 'relh' }, 'Saran lembut'), h('div', { class: 'cswg' }, SUGGEST_LIGHT.map(([c, nm]) => sw(c, nm))),
      h('div', { class: 'relh' }, 'Saran pekat'), h('div', { class: 'cswg' }, SUGGEST_DARK.map(([c, nm]) => sw(c, nm))),
      h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal'));
  }
  function openLabelSheet() {
    closeSelectMenu();
    const lst = h('div', { class: 'prl' }); let ov;
    const fill = () => {
      const all = data.settings.labels;
      lst.replaceChildren(...(all.length ? all.map((l) => {
        const st = PL.labelState(arr, selState.ids, l.id);
        return h('button', { type: 'button', class: 'prow' + (st === 'all' ? ' on' : ''), 'aria-pressed': st === 'all' ? 'true' : st === 'some' ? 'mixed' : 'false',
          onclick: () => { PL.applyLabel(arr, selState.ids, l.id); stamp(chosen(), Date.now()); ctx.persist(); fill(); } },
          h('span', { class: 'ckb', 'aria-hidden': 'true' }, st === 'all' ? '✓' : st === 'some' ? '–' : ''),
          h('span', { class: 'prt' }, h('b', {}, l.name)));
      }) : [h('div', { class: 'empty' }, 'Belum ada label. Buat dulu di Lainnya > Label catatan.')]));
    };
    ov = sheetOv('Label untuk ' + selState.ids.length + ' catatan', lst, h('button', { type: 'button', class: 'btn', onclick: () => { ov.remove(); done(); } }, 'Selesai'));
    fill();
  }
  function bulkCopy() {
    const list = PL.copyOrder(sortNotes(arr), selState.ids); const now = Date.now();
    let lost = 0; list.forEach((x, i) => { const c = addDuplicate(data, kind, x, { id: newId(), now: now + i }); lost += Math.max(0, countSheetRefs(x.html || '') - countSheetRefs(c.html || '')); });
    ctx.persist(); done(); toast((list.length === 1 ? 'Salinan dibuat' : list.length + ' salinan dibuat') + (lost > 0 ? ' (' + lost + ' lembar kerja tidak ikut disalin)' : ''));
  }
  function bulkDelete() {
    const list = chosen(), k = list.length;
    if (isP) {
      const no = () => {};
      dlg({ title: 'Hapus ' + k + ' catatan privat?', msg: k + ' catatan akan dihapus. Langkah 1 dari 2.', yes: 'Lanjut', no,
        ok: () => dlg({ title: 'Yakin dihapus permanen?', msg: 'Tidak masuk tempat sampah dan tidak bisa dikembalikan. Langkah 2 dari 2.', yes: 'Hapus permanen', red: true, reverse: true, no,
          ok: () => { for (const x of list) { const i = data.priv.indexOf(x); if (i >= 0) data.priv.splice(i, 1); } ctx.persist(); done(); toast(k + ' catatan privat dihapus permanen'); } }) });
      return;
    }
    const at = Date.now();
    const rec = list.map((x) => ({ n: x, i: data.notes.indexOf(x) })).filter((r) => r.i >= 0).sort((a, b) => a.i - b.i);
    for (const r of [...rec].reverse()) { data.notes.splice(r.i, 1); cancelReminder('note', r.n.id); cancelNoteAlarms(r.n); data.trash.push({ kind: 'note', item: r.n, at }); }
    ctx.persist(); done();
    toast(rec.length === 1 ? 'Catatan dipindah ke tempat sampah' : rec.length + ' catatan dipindah ke tempat sampah', () => {
      for (const r of rec) { const j = data.trash.findIndex((x) => x.item === r.n); if (j >= 0) data.trash.splice(j, 1); data.notes.splice(Math.min(r.i, data.notes.length), 0, r.n); if (r.n.reminder) scheduleReminder('note', r.n); syncNoteAlarms(r.n); }
      ctx.persist();
    }, ctx.render);
  }
  function openSelMenu(btn) {
    if (closeSelectMenu()) return;
    const only = chosen()[0];
    const mk = (icon, text, fn, cls = '') => h('button', { type: 'button', role: 'menuitem', class: 'mi' + (cls ? ' ' + cls : ''), onclick: () => { closeSelectMenu(); fn(); } }, ico(icon), h('span', {}, text));
    const menu = h('div', { class: 'menu', role: 'menu', 'aria-label': 'Menu pilihan' },
      mk(PATH.copy, 'Buat salinan', bulkCopy),
      PL.canShare(selState.ids, kind) && only ? mk(PATH.share, 'Bagikan', () => { const x = only; exitSelect(); openShare(ctx, x); }) : null,
      h('div', { class: 'mdv', role: 'separator' }),
      mk(PATH.bin, 'Hapus', bulkDelete, 'red'));
    selMenuEl = h('div', { class: 'menuov', onclick: (e) => { if (e.target === selMenuEl) closeSelectMenu(); } }, menu);
    const app = document.querySelector('#app'); app.append(selMenuEl);
    try { const r = btn.getBoundingClientRect(), a = app.getBoundingClientRect(); menu.style.top = Math.round(r.bottom - a.top + 6) + 'px'; } catch (_) {}
  }

  const fill = () => {
    setSheetsSource(() => data.sheets); // Rev 135 / U8b-2: pencarian ikut isi lembar kerja di dalam catatan
    const l = sortNotes(filterNotes(arr, ui[qk], ui[lf] || '', (n) => noteSheetSearchText(n.html)));
    const grid = data.settings.notesView === 'grid';
    box.className = grid && l.length ? 'ngrid' : '';
    box.replaceChildren(...(l.length ? l.map((n) => card(ctx, n, kind, sel)) : [h('div', { class: 'empty' },
      arr.length ? 'Tidak ditemukan. Coba kata kunci lain.' : favoritesRoom ? 'Belum ada catatan favorit. Ketuk ikon bintang pada kartu catatan untuk menyimpannya di sini.' : isP ? 'Belum ada catatan privat. Ketuk + untuk menulis.' : 'Belum ada catatan. Ketuk + untuk mulai menulis.')]));
  };
  const q = h('input', { class: 'in', type: 'search', placeholder: 'Cari catatan', 'aria-label': 'Cari catatan', oninput: (e) => { ui[qk] = e.target.value; fill(); } });
  q.value = ui[qk]; fill();
  // Pengalih tampilan: tombol di samping kolom cari; ikon dan label menyebut mode TUJUAN.
  const toGrid = data.settings.notesView !== 'grid';
  const vbtn = h('button', { type: 'button', class: 'ghost vsw', 'aria-label': toGrid ? 'Tampilan petak' : 'Tampilan baris', title: toGrid ? 'Tampilan petak' : 'Tampilan baris', onclick: () => { data.settings.notesView = toGrid ? 'grid' : 'list'; ctx.persist(); ctx.render(); } }, ico(toGrid ? PATH.grid : PATH.rows));
  const qrow = h('div', { class: 'qrow' }, q, vbtn);
  top.append(selState.ids.length ? bar() : qrow); top.classList.toggle('on', selState.ids.length > 0);
  selRefresh = refresh;
  const heading = isP ? judul('privat') : h('div', { class: 'notes-heading' }, favoritesRoom ? h('h1', { class: 'fav-title' }, ico(PATH.star), h('span', {}, 'Favorit')) : judul('catatan'), h('button', { type: 'button', class: 'fav-room-btn' + (favoritesRoom ? ' active' : ''), 'aria-pressed': String(favoritesRoom), onclick: () => { exitSelect(); ui.favoritesRoom = !favoritesRoom; ui.q = ''; ui.lf = ''; ctx.render(); } }, ico(favoritesRoom ? PATH.back : PATH.star), h('span', {}, favoritesRoom ? 'Catatan' : 'Favorit')));
  return [heading, top, chips, box];
}
export const viewNotes = (ctx) => viewNoteList(ctx, 'note');

export function openEditor(ctx, id, kind = 'note', keepTrail = false, quiet = false) {
  if (!keepTrail) trail = [];
  const { data } = ctx; const isP = kind === 'priv'; const list = isP ? data.priv : data.notes;
  let n = id ? list.find((x) => x.id === id) : null;
  const isNew = !n;
  if (!n) n = { id: newId(), title: '', text: '', html: '', col: '', pin: false, updated: Date.now() };
  const rawBodyHtml = String(n.html || '');
  const htmlBodyText = rawBodyHtml.replace(/<br\s*\/?\s*>/gi, ' ').replace(/<[^>]*>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').trim();
  const hasBody = !!String(n.text || '').trim() || !!htmlBodyText || /<(?:input|table|figure)\b/i.test(rawBodyHtml);
  const initialMode = modeFor({ isNew, isEmpty: !hasBody, fromShare: quiet, fromRelated: keepTrail });
  const vv = window.visualViewport;
  let tm = 0, lt = 0, pm = false, rng = null, alive = true;
  let dirty = false; // Rev 193 / P3: ada ketikan yang belum disimpan (simpan otomatis tertunda 400 ms); dipakai flush saat aplikasi ke latar belakang
  let labelsAll = data.settings.labels; // let: removeLabel mengganti array-nya
  const pending = new Set();

  // Status simpan (Rev 25c): titik berkedip. Hijau = sudah tersimpan, merah = belum (sedang menunggu simpan otomatis).
  const svt = h('span', { class: 'sdot ok', role: 'status', 'aria-label': 'Tersimpan' });
  const setSv = (ok) => { svt.className = 'sdot ' + (ok ? 'ok' : 'wait'); svt.setAttribute('aria-label', ok ? 'Tersimpan' : 'Belum tersimpan'); };
  const edt = h('small', { class: 'edt' });
  const hlab = h('div', { class: 'hlab' }); // chip label di header (Rev 25): hanya tampil bila catatan punya label
  let menuOv = null, dupToast = null;
  const lpv = h('div', { class: 'lpv' });
  const rel = isP ? null : h('div', { class: 'rel' });
  const lerr = h('p', { class: 'err', role: 'alert' });
  const lnew = h('input', { class: 'in', maxlength: '20', placeholder: 'Label baru, mis. Kerja', 'aria-label': 'Nama label baru', enterkeyhint: 'done' });
  const ladd = h('button', { type: 'button', class: 'btn line cpb' }, 'Tambah');
  const lchips = h('div', { class: 'lbs' });
  // Rev 36: panel label punya tombol Oke (tutup), tombol hapus (mode hapus), dan kolom tambah hanya muncul setelah ketuk chip +.
  let lAdding = false, lDel = false;
  const lhint = h('div', { class: 'cpl' }, 'Ketuk label untuk memasang atau melepas');
  const lokBtn = h('button', { type: 'button', class: 'btn lpok', onclick: () => closeLp() }, 'Oke');
  const ldelBtn = h('button', { type: 'button', class: 'ghost lpdel', 'aria-label': 'Hapus label', 'aria-pressed': 'false', onclick: () => { lDel = !lDel; lAdding = false; labUi(); } }, ico(PATH.bin));
  const lrow = h('div', { class: 'cpr', style: 'display:none' }, lnew, ladd);
  const lp = h('div', { class: 'lp', style: 'display:none' }, h('div', { class: 'lph' }, lhint, ldelBtn, lokBtn), lchips, lrow, lerr);
  const tt = h('input', { class: 'ttl', placeholder: 'Judul', 'aria-label': 'Judul catatan' }); tt.value = n.title;
  const remAt = h('input', { class: 'in', type: 'datetime-local', 'aria-label': 'Waktu pengingat catatan' });
  remAt.value = n.reminder ? toLocalInput(n.reminder.at) : '';
  const remRepeat = h('select', { class: 'in', 'aria-label': 'Pengulangan pengingat catatan' }, h('option', { value: 'once' }, 'Sekali'), h('option', { value: 'daily' }, 'Setiap hari'));
  remRepeat.value = n.reminder && n.reminder.repeat === 'daily' ? 'daily' : 'once';
  const remHint = h('small', { class: 'remhint', 'aria-live': 'polite' }, remRepeat.value === 'daily' ? 'Pengingat berulang setiap hari.' : 'Pengingat hanya sekali.');
  // Rev 381 / AL3b-3: mode pengingat catatan (alarm-ui.js dimuat malas ke dalam slot; gagal memuat = tanpa pemilih, mode lama dipertahankan). Hanya 'alarm' yang disimpan.
  let nMode = n.reminder && n.reminder.mode === 'alarm' ? 'alarm' : 'notif';
  const modeSlot = h('div', { class: 'am-slot' });
  if (!isP) import('./alarm-ui.js').then((A) => { modeSlot.append(A.modePicker({ mode: nMode, onChange: (m) => { nMode = m; auto(); } }).el); }, () => {});
  remRepeat.addEventListener('change', () => { remHint.textContent = remRepeat.value === 'daily' ? 'Pengingat berulang setiap hari.' : 'Pengingat hanya sekali.'; });
  // Pengingat (Rev 25b): tidak lagi di badan catatan. Panel muncul di dock lewat menu ⋮ > Pengingat atau ketuk ikon alarm di header.
  const remUi = () => { if (remMark) remMark.style.display = remAt.value && fromLocalInput(remAt.value) ? '' : 'none'; };
  const remClear = h('button', { type: 'button', class: 'btn line cpb', onclick: () => { remAt.value = ''; remRepeat.value = 'once'; remRepeat.dispatchEvent(new Event('change')); remAt.dispatchEvent(new Event('change')); } }, 'Hapus pengingat');
  const remDone = h('button', { type: 'button', class: 'btn line cpb', onclick: () => closeRp() }, 'Selesai');
  const rp = isP ? null : h('div', { class: 'rp', style: 'display:none' }, h('div', { class: 'cpl' }, '⏰ Pengingat (opsional)'), remAt, remRepeat, remHint, modeSlot, h('div', { class: 'cpr' }, remClear, remDone));
  const ed = h('div', { class: 'ed2', contenteditable: 'true', inputmode: 'text', autocapitalize: 'sentences', spellcheck: 'true', role: 'textbox', 'aria-label': 'Isi catatan', 'data-ph': 'Mulai menulis...', ...(isP ? { 'data-priv': '' } : {}) });
  setSheetsSource(() => ctx.data.sheets); // Rev 122 / U7b-1
  if (n.html) ed.innerHTML = sanitize(n.html);
  hydrateBlocks(ed);
  if (!getEngine() && ed.querySelector('.ksheet')) onEngine(() => { if (ed.isConnected) refreshIslands(ed); }); // Rev 192b: pulau berumus digambar ulang begitu mesin rumus tiba
  const imageInput = h('input', { type: 'file', accept: 'image/*', multiple: 'multiple', 'aria-label': 'Pilih gambar', style: 'display:none' });
  const imageUrls = new Set(); let stopImageObserver = null, stopBellObs = null, imageBusy = false, imageInsertRange = null;
  const pal = h('div', { class: 'pal' });
  const cerr = h('p', { class: 'err', role: 'alert' });
  // Roda warna (hue = sudut, saturasi = jarak dari tengah) + penggeser terang-gelap + kode hex.
  const WS = 240;
  const wheel = h('canvas', { class: 'wheel', width: String(WS), height: String(WS), role: 'img', 'aria-label': 'Roda warna. Seret untuk memilih warna.' });
  const wmark = h('div', { class: 'wmark' });
  const wwrap = h('div', { class: 'wwrap' }, wheel, wmark);
  const vsl = h('input', { type: 'range', class: 'vsl', min: '0', max: '100', step: '1', 'aria-label': 'Terang atau gelap' });
  const cprev = h('span', { class: 'cpv', 'aria-hidden': 'true' });
  const sug = h('div', { class: 'sug' });
  let hsv = hexToHsv(n.col) || { h: 210, s: 0.3, v: 0.95 };
  const chex = h('input', { class: 'in cpi', maxlength: '7', placeholder: '#RRGGBB', 'aria-label': 'Kode hex warna', autocapitalize: 'characters' });
  const crec = h('div', { class: 'cps' });
  // Penanda info di sebelah ⋮ (Rev 25): hanya informasi, tidak bisa diketuk. Muncul/hilang sendiri mengikuti status.
  const pinMark = h('span', { class: 'hb hpin', role: 'img', 'aria-label': 'Disematkan', style: 'display:none' }, ico(PATH.pin));
  const linkMark = isP ? null : h('button', { type: 'button', class: 'hb', 'aria-label': 'Catatan ini terhubung. Ketuk untuk melihat', style: 'display:none', onclick: () => { try { rel.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_) { rel.scrollIntoView(); } } }, ico(PATH.link));
  const remMark = isP ? null : h('button', { type: 'button', class: 'hb', 'aria-label': 'Ada pengingat. Ketuk untuk mengubah', style: 'display:none', onclick: () => openRp() }, ico(PATH.alarm));
  const marks = h('div', { class: 'hmk' }, hlab, linkMark, remMark, pinMark);
  const modeBtn = h('button', { type: 'button', class: 'ghost hmode', 'aria-label': 'Beralih ke mode Edit', title: 'Mode Edit' }, ico(PATH.edit));
  const moreBtn = h('button', { type: 'button', class: 'ghost hmore', 'aria-label': 'Menu catatan', 'aria-haspopup': 'menu', 'aria-expanded': 'false', onclick: () => (menuOv && menuOv.isConnected ? dismissMenu() : openMenu()) }, icoMenu());
  const fb = (attrs, ...kids) => h('button', { type: 'button', ...attrs }, ...kids);
  // Rev 81 / U2d: ikon SVG konsisten untuk tombol sisip di bilah Langit.
  // Ikon harus dibuat di namespace SVG (h() memakai createElement HTML, sehingga <svg>/<path> tidak tergambar).
  const svgEl = (tag, attrs = {}, ...kids) => {
    const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    for (const c of kids) e.append(c);
    return e;
  };
  // Ikon bilah Langit (gaya Kaca gradasi): satu jalur per ikon, garis 2.2 mengikuti warna tema, dibungkus kotak .tile.
  const BAR_ICONS = {
    bold: 'M7 4.5h5.5a3.5 3.5 0 010 7H7zM7 11.5h6.5a3.5 3.5 0 010 7H7z',
    italic: 'M10 4.5h7M7 19.5h7M14.5 4.5l-5 15',
    underline: 'M7 4.5v7a5 5 0 0010 0v-7M5 20h14',
    strike: 'M4.5 12h15M16.3 7.4c-.6-1.5-2.2-2.4-4.1-2.4-2.3 0-3.9 1.2-3.9 2.9 0 1.3.9 2.2 2.6 2.8M7.7 16.6c.7 1.6 2.3 2.5 4.5 2.5 2.5 0 4.1-1.3 4.1-3.1 0-.8-.3-1.5-.9-2',
    bullet: 'M9.5 6.5H20M9.5 12H20M9.5 17.5H20M4.6 6.5h.01M4.6 12h.01M4.6 17.5h.01',
    number: 'M3.8 9.2L6.2 7V17.5M4.8 17.5H7.6M9.8 9.6a2.5 2.5 0 015 0c0 2.2-5 5.3-5 7.9h5.2M17 8.8a2.4 2.4 0 014.6.8c0 1.3-1 2.2-2.6 2.3 1.7 0 2.9 1 2.9 2.6a2.8 2.8 0 01-5.3 1.2',
    check: 'M5.5 4h13A1.5 1.5 0 0120 5.5v13a1.5 1.5 0 01-1.5 1.5h-13A1.5 1.5 0 014 18.5v-13A1.5 1.5 0 015.5 4zM8.3 12.2l2.5 2.5 4.9-5.2',
    color: 'M6.5 15.5L12 4l5.5 11.5M8.4 11.7h7.2',
    size: 'M2.8 18L8 6l5.2 12M4.9 13.7h6.2M14.8 18l2.6-6 2.6 6M15.8 16.2h3.2',
    date: 'M6.5 5h11A2.5 2.5 0 0120 7.5v10a2.5 2.5 0 01-2.5 2.5h-11A2.5 2.5 0 014 17.5v-10A2.5 2.5 0 016.5 5zM8 3v4M16 3v4M4 10h16M8 14h2M14 14h2M8 17h2',
    time: 'M12 3.5a8.5 8.5 0 100 17 8.5 8.5 0 000-17zM12 7.5V12l3.2 2',
    countdown: 'M6.5 5h11A2.5 2.5 0 0120 7.5v10a2.5 2.5 0 01-2.5 2.5h-11A2.5 2.5 0 014 17.5v-10A2.5 2.5 0 016.5 5zM8 3v4M16 3v4M4 10h16M8 14h3M8 17h5M17 13.5V16l1.8 1',
    mood: 'M12 3.5a8.5 8.5 0 100 17 8.5 8.5 0 000-17zM8.6 14c.9 1.5 2 2.2 3.4 2.2s2.5-.7 3.4-2.2M9 9.6h.01M15 9.6h.01',
    quote: 'M10.5 11H6.8A2.8 2.8 0 014 8.2V7.8A2.8 2.8 0 016.8 5H10zM20 11h-3.7a2.8 2.8 0 01-2.8-2.8V7.8A2.8 2.8 0 0116.3 5H20zM4 11v1.5A5.5 5.5 0 009.5 18M13.5 18A5.5 5.5 0 0019 12.5V11',
    fold: 'M6 8.5l3.5 3.5L6 15.5M13 9h7M13 15h7M4 5h16M4 19h16',
    table: 'M6 5h12a2 2 0 012 2v10a2 2 0 01-2 2H6a2 2 0 01-2-2V7a2 2 0 012-2zM4 10h16M4 14.5h16M10 5v14M15 5v14',
    link: 'M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1',
    image: 'M6 4.5h12A2.5 2.5 0 0120.5 7v10a2.5 2.5 0 01-2.5 2.5H6A2.5 2.5 0 013.5 17V7A2.5 2.5 0 016 4.5zM9 8.2a1.5 1.5 0 100 3 1.5 1.5 0 000-3zM5 17l4.5-4.5 3 3 2.5-2.5 4 4',
    ocr: 'M4 8V6.5A2.5 2.5 0 016.5 4H8M16 4h1.5A2.5 2.5 0 0120 6.5V8M20 16v1.5a2.5 2.5 0 01-2.5 2.5H16M8 20H6.5A2.5 2.5 0 014 17.5V16M8 9.5h8M8 12.5h8M8 15.5h5',
    ai: 'M12 2.5c.7 5.4 4.1 8.8 9.5 9.5-5.4.7-8.8 4.1-9.5 9.5-.7-5.4-4.1-8.8-9.5-9.5 5.4-.7 8.8-4.1 9.5-9.5z',
    sheet: 'M6.5 4.5h11A2.5 2.5 0 0120 7v10a2.5 2.5 0 01-2.5 2.5h-11A2.5 2.5 0 014 17V7a2.5 2.5 0 012.5-2.5zM4 9.5h16M9 9.5v10M12.5 13h4M12.5 16.5h4'
  };
  const insertIcon = (kind) => svgEl('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true', focusable: 'false', class: 'ins-ico' },
    ...[svgEl('path', { d: BAR_ICONS[kind] }), kind === 'color' ? svgEl('path', { d: 'M5 20h14', class: 'ac' }) : null].filter(Boolean));
  const tile = (kind) => h('span', { class: 'tile' }, insertIcon(kind));
  // Rev 88: semua isi menu Sisipkan jadi tombol langsung di bilah Langit (panel Sisipkan dihapus).
  const insertBtn = (kind, label) => fb({ 'data-insert': kind, class: 'fmt', 'aria-label': `Sisipkan ${label}` }, tile(kind), h('small', {}, label));
  // Rev 27A: bilah tertutup = Undo | ✦ | Redo. Ketuk ✦ = panel format terbuka (✦ pindah ke kiri jadi tombol tutup, Undo/Redo disembunyikan).
  // Tanpa animasi di 27A (animasi sedot-muntah = Rev 27B). Tombol format tetap data-cmd yang sama, jadi handler lama tidak berubah.
  const bar = h('div', { class: 'fbar' },
    fb({ 'data-cmd': 'undo', 'aria-label': 'Urungkan', class: 'dis uh', 'aria-disabled': 'true' }, ico(PATH.undo)),
    fb({ 'data-cmd': 'star', class: 'star', 'aria-label': 'Buka pengaturan teks', 'aria-expanded': 'false' }, ico(PATH.star)),
    fb({ 'data-cmd': 'redo', 'aria-label': 'Ulangi', class: 'dis uh', 'aria-disabled': 'true' }, ico(PATH.redo)),
    fb({ 'data-cmd': 'bold', 'aria-label': 'Tebal', class: 'fmt' }, tile('bold'), h('small', {}, 'Tebal')),
    fb({ 'data-cmd': 'italic', 'aria-label': 'Miring', class: 'fmt' }, tile('italic'), h('small', {}, 'Miring')),
    fb({ 'data-cmd': 'underline', 'aria-label': 'Garis bawah', class: 'fmt' }, tile('underline'), h('small', {}, 'Garis')),
    fb({ 'data-cmd': 'strikeThrough', 'aria-label': 'Coret', class: 'fmt' }, tile('strike'), h('small', {}, 'Coret')),
    fb({ 'data-cmd': 'insertUnorderedList', 'aria-label': 'Poin', class: 'fmt' }, tile('bullet'), h('small', {}, 'Poin')),
    fb({ 'data-cmd': 'insertOrderedList', 'aria-label': 'Nomor', class: 'fmt' }, tile('number'), h('small', {}, 'Nomor')),
    fb({ 'data-cmd': 'todo', 'aria-label': 'Kotak centang', class: 'fmt' }, tile('check'), h('small', {}, 'Centang')),
    fb({ 'data-pal': 'txt', 'aria-label': 'Warna teks', class: 'fmt' }, tile('color'), h('small', {}, 'Warna')),
    fb({ 'data-cmd': 'font-size', 'aria-label': 'Ukuran huruf', class: 'fmt fs-btn' }, tile('size'), h('small', {}, 'Ukuran')),
    insertBtn('date', 'Tanggal'), insertBtn('time', 'Waktu'), insertBtn('countdown', 'Hitung mundur'), insertBtn('mood', 'Suasana hati'),
    insertBtn('quote', 'Kutipan'), insertBtn('fold', 'Bagian lipat'), insertBtn('table', 'Tabel'), insertBtn('link', 'Tautan'), ...(isP ? [] : [insertBtn('image', 'Gambar')]), ...(isP ? [] : [insertBtn('sheet', 'Lembar kerja')]), ...(isP ? [] : [insertBtn('ocr', 'Pindai')])); // Rev 218: Writing Studio (tidak di Catatan Privat) // Rev 122: Lembar kerja tidak untuk Privat
  const starBtn = bar.querySelector('[data-cmd="star"]');
  const moodFaces = ['', '', '', '', '']; // Rev D: wajah digambar lewat CSS per data-mood-value (bukan emoji)
  const moodLabels = MOOD_LABELS;
  const closePanels = () => { closeLp(); closeRp(); if (cp.style.display === 'block') closeCp(); pm = false; pal.replaceChildren(); };
  const closeMoodTools = () => { ed.querySelectorAll('.mood-tools').forEach((x) => x.remove()); };
  // Rev 88: satu jalur untuk semua blok sisipan (Suasana hati, Tanggal, Waktu, Hitung mundur): tidak di dalam sel tabel,
  // di dalam daftar/kutipan ditaruh sesudah blok tingkat atas, lalu kursor pindah ke paragraf kosong sesudah blok.
  const placeBlock = (block, range, label) => {
    const anchor = range ? range.startContainer : null;
    const anchorEl = anchor && (anchor.nodeType === 1 ? anchor : anchor.parentElement);
    if (anchorEl && anchorEl.closest('td,th')) { infoKey('dlmTabel', label); return false; }
    const tail = document.createElement('p'); tail.append(document.createElement('br'));
    let top = anchorEl; while (top && top.parentElement && top.parentElement !== ed) top = top.parentElement;
    const insideFold = !!(top && top !== ed && isFold(top)); // Rev 109 / U6a: bagian lipat tidak bersarang; sisip sesudahnya
    // Paragraf/judul tingkat atas tidak boleh memuat div blok: taruh sesudahnya (paragraf kosong diganti blok).
    const flowTop = top && top !== ed && /^(P|H[1-6])$/.test(top.tagName);
    // Rev 89: kursor/seleksi di dalam blok sisipan lain (Tanggal, Waktu, Hitung mundur, Suasana hati): taruh sesudah blok itu, jangan membelah isinya.
    const insideBlock = top && top !== ed && top.matches && top.matches(BLOCK_SEL);
    if (insideBlock) top.after(block, tail);
    else if (flowTop && !top.textContent.trim() && !top.querySelector('img,table')) top.replaceWith(block, tail);
    else if ((flowTop || insideFold || (anchorEl && anchorEl.closest('li,blockquote,ul,ol'))) && top && top !== ed) top.after(block, tail);
    else if (range && ed.contains(anchor) && anchor !== ed) { const r = range.cloneRange(); if (!r.collapsed) r.deleteContents(); r.insertNode(block); block.after(tail); }
    else ed.append(block, tail);
    const caret = document.createRange(); caret.setStart(tail, 0); caret.collapse(true);
    const sel = getSelection(); sel.removeAllRanges(); sel.addRange(caret); rng = caret.cloneRange();
    return true;
  };
  const caretRange = () => { const sel = getSelection(); return sel && sel.rangeCount && ed.contains(sel.anchorNode) ? sel.getRangeAt(0).cloneRange() : null; };
  const afterInsert = (block, select = true) => {
    flushHist(); auto();
    try { block.scrollIntoView({ block: 'nearest' }); } catch (_) { /* tidak penting */ }
  };
  const insertMood = () => {
    flushHist(); restore();
    const block = document.createElement('div'); block.className = 'mood-block'; block.contentEditable = 'false';
    block.dataset.moodSize = 'normal'; block.dataset.moodValue = '4';
    const head = document.createElement('div'); head.className = 'mood-head';
    const title = document.createElement('strong'); title.className = 'mood-title';
    const menu = document.createElement('span'); menu.className = 'mood-menu'; menu.dataset.moodAction = 'menu'; menu.setAttribute('role', 'button'); menu.setAttribute('aria-label', 'Pengaturan blok suasana hati'); menu.textContent = '⋮';
    head.append(title, menu);
    const faces = document.createElement('div'); faces.className = 'mood-faces';
    moodFaces.forEach((face, i) => { const item = document.createElement('span'); item.className = 'mood-face'; item.dataset.moodValue = String(i); item.textContent = face; item.setAttribute('role', 'button'); item.setAttribute('aria-label', moodLabels[i]); faces.append(item); });
    block.append(head, faces); syncMood(block);
    if (placeBlock(block, caretRange(), 'Suasana hati')) afterInsert(block, false);
  };
  const insertDate = () => {
    flushHist(); restore();
    const block = document.createElement('div'); block.className = 'kb-date-block';
    block.dataset.kbDate = localDateISO(); syncDateBlock(block);
    if (placeBlock(block, caretRange(), 'Tanggal')) afterInsert(block);
  };
  const insertTime = () => {
    flushHist(); restore();
    const block = document.createElement('div'); block.className = 'kb-time-block';
    block.dataset.kbTime = localTimeHM(); syncTimeBlock(block);
    if (placeBlock(block, caretRange(), 'Waktu')) afterInsert(block);
  };
  // Rev 122 / U7b-1: Lembar kerja baru disimpan di data.sheets; di catatan hanya pulau pratinjau (data-sheet). Tidak untuk Catatan Privat.
  const insertSheet = () => {
    if (isP) { return; } // (ditulis berkurung: tes rev82 mengunci bahwa kode Suasana hati tidak memakai penjaga isP)
    if (editorMode !== 'edit') { tWarn('Beralih ke mode Edit dulu.'); return; }
    const sheets = ctx.data.sheets || (ctx.data.sheets = {}); const ids = Object.keys(sheets);
    if (ids.length >= LZ.MAX_SHEETS) { infoKey('maks', 'lembar kerja', LZ.MAX_SHEETS, 'Hapus lembar kerja yang tidak dipakai di Setelan > Lembar kerja.'); return; }
    flushHist(); restore();
    const sh = LZ.newSheet({ name: 'Lembar kerja ' + (ids.length + 1) });
    while (sheets[sh.id]) sh.id = 's' + Math.random().toString(36).slice(2, 8);
    const block = document.createElement('div'); block.className = 'ksheet'; block.setAttribute('data-sheet', sh.id);
    if (!placeBlock(block, caretRange(), 'Lembar kerja')) return;
    sheets[sh.id] = sh; renderIsland(block); ctx.persist(); afterInsert(block);
  };
  // Rev 323 / L2: Sisipkan > Tautan (dialog + kartu di linkcard-ui.js, dimuat malas). Di Catatan Privat kartu hanya lokal (tanpa internet).
  const openLinkDialog = () => {
    if (editorMode !== 'edit') { tWarn('Beralih ke mode Edit dulu.'); return; }
    flushHist(); restore();
    const savedRange = caretRange() || (rng ? rng.cloneRange() : null);
    import('./linkcard-ui.js').then((m) => m.openLinkDialog({ ed, kind: isP ? 'priv' : 'note', place: (el) => placeBlock(el, savedRange, 'Tautan'), done: afterInsert, save: auto, toast }), () => tErr('Dialog tautan gagal dibuka.'));
  };
  // Rev 218 / Tahap 3b: Writing Studio (logika di ai/tulisui.js, dimuat malas). Tidak untuk Catatan Privat.
  const openWriteAI = () => {
    if (isP) { return; }
    if (editorMode !== 'edit') { tWarn('Beralih ke mode Edit dulu.'); return; }
    restore();
    import('./ai/tulisui.js').then((m) => m.mulaiTulis({ r: caretRange(), ed, BLOCK_SEL, flushHist, auto, setRng: (x) => { rng = x; }, tt, upd, refresh: refreshImages }), () => tErr('Writing Studio gagal dibuka.'));
  };
  const openOcr = () => { // Rev 354 / O3a: Pindai teks dari foto (tidak di Catatan Privat; modul MALAS)
    if (isP) { return; }
    if (editorMode !== 'edit') { tWarn('Beralih ke mode Edit dulu.'); return; }
    restore();
    import('./ai/ocr-ui.js').then((m) => m.mulaiOcr({ ctx, r: caretRange(), ed, flushHist, auto, setRng: (x) => { rng = x; } }), () => tErr('Pindai teks gagal dibuka.'));
  };
  const openIsland = (blk) => {
    const sh = sheetById(blk.getAttribute('data-sheet') || '');
    if (!sh) { tWarn('Lembar kerja ini sudah tidak ada.'); return; }
    try { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); } catch (_) { /* keyboard tidak wajib turun */ }
    try {
      openLembar({ sheet: sh, onChange: () => ctx.persist(), onClose: () => refreshIslands(ed), usedIn: (sheetUsage(ctx.data)[sh.id] || 0),
        onDelete: (s) => { delete ctx.data.sheets[s.id]; ctx.persist(); refreshIslands(ed); tOk('Lembar kerja dihapus.'); } }).catch(() => tErr('Lembar kerja gagal dibuka.'));
    } catch (_) { tErr('Lembar kerja gagal dibuka.'); }
  };
  // Rev 109 / U6a: bagian lipat (judul + isi). Kursor langsung di judul; status terbuka/tutup tersimpan di data-o.
  const insertFold = () => {
    flushHist(); restore();
    const block = makeFold(document, '', true);
    if (!placeBlock(block, caretRange(), 'Bagian lipat')) return;
    const r = document.createRange(); r.selectNodeContents(block.firstElementChild); r.collapse(true);
    const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); rng = r.cloneRange();
    afterInsert(block);
  };
  const foldToggle = (fold) => {
    flushHist();
    const opened = toggleFold(fold);
    const sel = getSelection(); const fb = fold.querySelector(':scope > .fb');
    if (!opened && sel && sel.rangeCount && fb && fb.contains(sel.anchorNode) && !o.classList.contains('ed-baca')) { // isi yang tersembunyi tidak boleh memegang kursor
      const r = document.createRange(); r.selectNodeContents(fold.firstElementChild); r.collapse(false); sel.removeAllRanges(); sel.addRange(r); rng = r.cloneRange();
    }
    flushHist(); auto();
  };

  const openCountdownEditor = (block = null) => {
    const creating = !block;
    if (editorMode !== 'edit') { tWarn('Beralih ke mode Edit dulu.'); return; }
    if (!block) { flushHist(); restore(); }
    const selAtOpen = getSelection();
    const savedRange = !block && selAtOpen && selAtOpen.rangeCount && ed.contains(selAtOpen.anchorNode) ? selAtOpen.getRangeAt(0).cloneRange() : (!block && rng ? rng.cloneRange() : null);
    const currentDate = block?.dataset.kbDate || addLocalDays(new Date(), 7);
    const currentTime = block?.dataset.kbTime || '';
    const titleInput = h('input', { class: 'in cd-field', type: 'text', maxlength: '80', placeholder: 'Apa yang Anda nantikan?', value: block?.dataset.kbTitle || '', 'aria-label': 'Nama acara' });
    const dateInput = h('input', { class: 'in cd-field', type: 'date', value: currentDate, required: true, 'aria-label': 'Tanggal tujuan' });
    const withTime = h('input', { type: 'checkbox', checked: !!currentTime, 'aria-label': 'Tambahkan waktu' });
    const timeInput = h('input', { class: 'in cd-field', type: 'time', value: currentTime || '09:00', disabled: !currentTime, 'aria-label': 'Waktu tujuan' });
    const timeRow = h('label', { class: 'cd-form-row cd-time-row', hidden: !currentTime }, h('span', {}, 'Waktu tujuan'), timeInput);
    const preview = h('div', { class: 'cd-live-preview', 'aria-live': 'polite' }, h('span', { class: 'cd-preview-caption' }, 'Pratinjau kartu'), h('div', { class: 'cd-preview-card' }));
    const previewCard = preview.querySelector('.cd-preview-card');
    const refreshPreview = () => {
      const d = isValidDateISO(dateInput.value) ? dateInput.value : currentDate;
      const t = withTime.checked && isValidTimeHM(timeInput.value) ? timeInput.value : '';
      const sample = document.createElement('div'); sample.className = 'kb-countdown-block';
      sample.dataset.kbDate = d; sample.dataset.kbTime = t; sample.dataset.kbTitle = cleanCountdownTitle(titleInput.value);
      syncCountdownBlock(sample); previewCard.replaceChildren(sample);
    };
    withTime.addEventListener('change', () => { timeInput.disabled = !withTime.checked; timeRow.hidden = !withTime.checked; if (withTime.checked && !timeInput.value) timeInput.value = '09:00'; refreshPreview(); });
    [titleInput, dateInput, timeInput].forEach((input) => input.addEventListener('input', refreshPreview));
    const ov = h('div', { class: 'ov dlgov cd-dialog', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const cancel = h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal');
    const save = h('button', { type: 'button', class: 'btn', onclick: () => {
      if (!isValidDateISO(dateInput.value)) { tWarn('Pilih tanggal yang valid.'); return; }
      if (withTime.checked && !isValidTimeHM(timeInput.value)) { tWarn('Pilih waktu yang valid.'); return; }
      flushHist();
      if (creating) {
        const fresh = document.createElement('div'); fresh.className = 'kb-countdown-block';
        if (!placeBlock(fresh, savedRange, 'Hitung mundur')) { ov.remove(); return; }
        block = fresh;
      }
      block.dataset.kbDate = dateInput.value;
      block.dataset.kbTitle = cleanCountdownTitle(titleInput.value);
      if (withTime.checked) block.dataset.kbTime = timeInput.value; else delete block.dataset.kbTime;
      syncCountdownBlock(block); ov.remove(); afterInsert(block);
    } }, block ? 'Simpan' : 'Sisipkan');
    const field = (label, control) => h('label', { class: 'cd-form-row' }, h('span', {}, label), control);
    ov.append(h('div', { class: 'sheet dlg cd-dialog-card' }, h('h3', {}, block ? 'Ubah hitung mundur' : 'Hitung mundur'), h('p', { class: 'sub' }, 'Tentukan momen yang ingin kamu nantikan.'), field('Nama acara', titleInput), field('Tanggal tujuan', dateInput), h('label', { class: 'cd-time-toggle' }, withTime, h('span', {}, 'Tambahkan waktu')), timeRow, preview, h('div', { class: 'dlgb rev' }, cancel, save), block ? h('button', { type: 'button', class: 'btn line cd-del', onclick: () => {
      flushHist(); block.remove();
      if (!ed.children.length) { const p = document.createElement('p'); p.append(document.createElement('br')); ed.append(p); }
      ov.remove(); flushHist(); auto();
    } }, 'Hapus hitung mundur') : null));
    document.body.append(ov);
    refreshPreview();
    try { titleInput.focus(); } catch (_) {}
  };

  // Rev 103 / U5c: lonceng "Ingatkan saya" di baris kotak centang. Lonceng = pseudo-elemen CSS (::after) pada .todo, TIDAK ada di HTML tersimpan.
  // Keadaannya lewat atribut SEMENTARA data-rem pada baris (dibuang oleh sanitize, jadi tidak ikut tersimpan/cadangan/ekspor). Ketukan dikenali dari koordinat di tepi kanan baris.
  // Data pengingat ada di n.cbRem (bukan di HTML); jadwal alarm SELALU lewat cb-alarm.js (save() -> reconcileNoteAlarms).
  const BELL_W = 44;
  const cidOk = (c) => !!c && CID_RE.test(c);
  // cid milik baris ini; '' bila belum punya, tidak sah, atau KEMBAR (salinan/tempel: hanya baris pertama menurut urutan dokumen yang memilikinya, seperti sanitize)
  const ownCid = (row) => {
    const c = row.getAttribute('data-cid'); if (!cidOk(c)) return '';
    return ed.querySelector('.todo[data-cid="' + c + '"],li[data-cid="' + c + '"]') === row ? c : ''; // Rev 348 / R3: item li ikut (yang PERTAMA menurut urutan dokumen memilikinya)
  };
  const rowDone = (row) => { const i = row.querySelector('input[type="checkbox"]'); return !!(i && i.checked); };
  const rowBell = (row, now = Date.now()) => { const c = ownCid(row); return bellState(c && n.cbRem ? n.cbRem[c] : null, rowDone(row), now); };
  const syncBells = () => {
    if (isP || !alive) return; // Privat: tanpa lonceng
    const now = Date.now();
    ed.querySelectorAll('.todo,li[data-cid],li[data-rem]').forEach((row) => { // Rev 349 / R4: item li ber-cid ikut; li ber-data-rem tanpa cid (Enter menyalin atribut) dibersihkan
      const cr = n.cbRem && ownCid(row) ? n.cbRem[ownCid(row)] : null; const want = rowBell(row, now) === 'on' ? (cr && cr.mode === 'alarm' ? '2' : '1') : null; // Rev 380: '2' = jam alarm
      if ((row.getAttribute('data-rem') || null) !== want) { if (want) row.setAttribute('data-rem', want); else row.removeAttribute('data-rem'); }
    });
  };
  const bellHit = (e) => {
    if (isP || o.classList.contains('ed-baca')) { return null; } // Rev 105 / U5e: mode Baca = lonceng tidak bisa diketuk (isi tidak berubah)
    const row = e.target && e.target.closest ? e.target.closest('.todo,li') : null;
    if (!row || !ed.contains(row) || rowBell(row) === 'off') return null;
    const r = row.getBoundingClientRect();
    if (row.tagName === 'LI' && (!row.hasAttribute('data-rem') || e.clientY > r.top + BELL_W)) return null; // R4: li hanya bila berlonceng (berpengingat) dan ketukan di zona lonceng kanan-atas; tanpa lonceng kosong
    return e.clientX >= r.right - BELL_W && e.clientX <= r.right + 2 ? row : null;
  };
  // Rev 380 / AL3b-2: pemilih mode (alarm-ui.js, dimuat malas). Gagal memuat = lembar tetap terbuka tanpa pemilih (mode lama dipertahankan).
  const openRemindSheet = (row, presetAt) => { import('./alarm-ui.js').then((A) => openRemindSheetNow(row, presetAt, A), () => openRemindSheetNow(row, presetAt, null)); };
  const openRemindSheetNow = (row, presetAt, A) => { // Rev 341 / I8: presetAt (ms, opsional) = waktu terisi dari `!jam 9`; tetap lewat checkChoice di lembar (lampau/terlalu dekat = pesan + Simpan nonaktif)
    if (isP || !row || !row.isConnected) return;
    document.querySelectorAll('.ov.rm-ov').forEach((x) => x.remove());
    try { if (ed.contains(document.activeElement)) ed.blur(); } catch (_) {} // keyboard turun supaya lembar tidak tertutup
    const now0 = Date.now();
    const cid0 = ownCid(row);
    const oldRule = cid0 && n.cbRem ? n.cbRem[cid0] : null;
    const live = oldRule && ruleIsLive(oldRule, now0) ? oldRule : null;
    const presets = presetsFor(now0);
    const tomorrow = presets.find((p) => p.id === 'tomorrow');
    let repeat = live ? live.repeat : 'none';
    let mode = live && live.mode === 'alarm' ? 'alarm' : 'notif'; // Rev 380: hanya 'alarm' yang disimpan
    const mp = A ? A.modePicker({ mode, onChange: (m) => { mode = m; } }) : null;
    let pick = null; // { id, at }
    if (live) { const [nx] = nextOccurrences(live, now0, 1); const at = live.at > now0 ? live.at : (nx || live.at); const pre = presets.find((p) => p.at === at); pick = { id: pre ? pre.id : 'custom', at }; }
    if (Number.isFinite(presetAt) && presetAt > 0) { const pre = presets.find((p) => p.at === presetAt); pick = { id: pre ? pre.id : 'custom', at: presetAt }; }
    const rowText = (row.tagName === 'LI' ? [...row.childNodes].filter((c) => c.nodeType === 3 || (c.nodeType === 1 && c.tagName !== 'UL' && c.tagName !== 'OL')).map((c) => c.textContent).join('') : (row.textContent || '')).replace(/\s+/g, ' ').trim(); // R3: teks item li tanpa sub-daftar
    const ov = h('div', { class: 'ov dlgov rm-ov', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const sum = h('p', { class: 'rm-sum', 'aria-live': 'polite' });
    const dt = h('input', { class: 'in rm-dt', type: 'datetime-local', min: toLocalInput(now0 + MIN_LEAD_MS + 60000), 'aria-label': 'Tanggal dan waktu pengingat' });
    const dtRow = h('div', { class: 'rm-dtrow', hidden: true }, dt);
    const optEls = presets.map((p) => h('button', { type: 'button', class: 'rm-opt', role: 'radio', 'aria-checked': 'false', 'data-id': p.id, onclick: () => { pick = { id: p.id, at: p.at }; refresh(); } }, h('span', { class: 'rm-dot', 'aria-hidden': 'true' }), h('span', { class: 'rm-lab' }, p.label)));
    const customOpt = h('button', { type: 'button', class: 'rm-opt', role: 'radio', 'aria-checked': 'false', 'data-id': 'custom', onclick: () => { if (!pick || pick.id !== 'custom') pick = { id: 'custom', at: fromLocalInput(dt.value) || (tomorrow ? tomorrow.at : 0) }; refresh(); } }, h('span', { class: 'rm-dot', 'aria-hidden': 'true' }), h('span', { class: 'rm-lab' }, 'Pilih tanggal dan waktu'));
    const onDt = () => { if (pick && pick.id === 'custom') { pick.at = fromLocalInput(dt.value); refresh(true); } };
    dt.addEventListener('input', onDt); dt.addEventListener('change', onDt); // Rev 106: picker Android kadang hanya memicu change
    const segEls = REPEATS.map((r) => h('button', { type: 'button', class: 'rm-seg', 'data-r': r, 'aria-pressed': 'false', onclick: () => { repeat = r; refresh(); } }, REPEAT_LABELS[r]));
    const bSave = h('button', { type: 'button', class: 'btn', onclick: () => doSave() }, 'Simpan pengingat');
    const bCancel = h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal');
    const refresh = (typing = false) => {
      for (const b of [...optEls, customOpt]) b.setAttribute('aria-checked', String(!!pick && b.getAttribute('data-id') === pick.id));
      for (const b of segEls) b.setAttribute('aria-pressed', String(b.getAttribute('data-r') === repeat));
      const isCustom = !!pick && pick.id === 'custom';
      dtRow.hidden = !isCustom;
      if (isCustom && !typing) dt.value = toLocalInput(pick.at);
      // Rev 106: pilihan yang tidak lolos checkChoice (mis. custom 12.02 saat sekarang 12.01) dulu ditolak diam-diam (toast tertutup lembar). Kini pesan tampil di lembar dan Simpan nonaktif sampai waktunya valid.
      const chk = pick ? checkChoice(pick.at, repeat, Date.now()) : { ok: false };
      const bad = !!pick && !chk.ok;
      bSave.disabled = !pick || !chk.ok;
      sum.classList.toggle('warn', bad);
      sum.textContent = bad ? (pick.at && pick.at <= Date.now() + MIN_LEAD_MS ? 'Waktu itu sudah lewat atau terlalu dekat. Pilih minimal 2 menit dari sekarang.' : chk.reason) : pick && pick.at ? 'Diingatkan: ' + describeRule({ at: pick.at, repeat }, Date.now()) : 'Pilih kapan kamu mau diingatkan.';
    };
    const doSave = () => {
      const at = pick ? pick.at : 0;
      const chk = checkChoice(at, repeat, Date.now());
      if (!chk.ok) { refresh(true); toast(chk.reason); return; }
      if (!row.isConnected) { ov.remove(); return; }
      flushHist();
      let cid = ownCid(row);
      if (!cid) cid = newCid([...cidsInHtml(ed.innerHTML), ...Object.keys(n.cbRem || {})]);
      if (!setCbRule(n, cid, { at, repeat, sticky: false, mode })) { infoKey('maks', 'pengingat baris di catatan ini', MAX_CB_PER_NOTE, 'Hapus pengingat baris yang sudah tidak perlu.'); return; }
      row.setAttribute('data-cid', cid);
      ov.remove(); syncBells(); flushHist(); clearTimeout(tm); save();
      toast('Pengingat diatur: ' + describeRule(n.cbRem[cid], Date.now()));
    };
    const doDelete = () => {
      const cid = ownCid(row);
      if (cid) delete remStash.cb[cid];
      if (cid && n.cbRem && n.cbRem[cid]) { cancelRowAlarms(n, cid); clearCbRule(n, cid); } // batalkan alarm SEBELUM aturan hilang (save() hanya membatalkan ID dari aturan yang masih ada)
      if (cid && row.isConnected) row.removeAttribute('data-cid');
      ov.remove(); flushHist(); syncBells(); clearTimeout(tm); save();
      tOk('Pengingat dihapus.');
    };
    const bDel = live ? h('button', { type: 'button', class: 'rm-del', onclick: () => doDelete() }, 'Hapus pengingat') : null;
    ov.append(h('div', { class: 'sheet rm-sheet', role: 'dialog', 'aria-label': 'Ingatkan saya' },
      h('h3', {}, 'Ingatkan saya'),
      h('p', { class: 'sub rm-row' }, rowText ? rowText.slice(0, 80) : row.tagName === 'LI' ? 'Item daftar' : 'Baris kotak centang'),
      h('div', { class: 'rm-opts', role: 'radiogroup', 'aria-label': 'Kapan' }, ...optEls, customOpt),
      dtRow,
      h('div', { class: 'rm-seglab' }, 'Ulangi'),
      h('div', { class: 'rm-segs', role: 'group', 'aria-label': 'Ulangi' }, ...segEls),
      mp ? mp.el : null,
      sum,
      bDel,
      h('div', { class: 'dlgb rm-foot' }, bCancel, bSave)));
    document.body.append(ov);
    refresh();
  };
  // Rev 104 / U5d: pengingat kartu Hitung mundur. Data di n.cdRem[bid] (daftar \"hari sebelum\"); bid = atribut data-kb-id di kartu, diberi LAZY saat Simpan pertama.
  // Waktu bunyi SELALU dihitung dari tanggal+jam kartu (planCdAlarms), jadi mengubah tanggal/jam kartu menjadwalkan ulang otomatis lewat save() -> reconcileNoteAlarms.
  // Jadwal alarm SELALU lewat cb-alarm.js (jangan memanggil jembatan native langsung dari sini). Catatan Privat tanpa pengingat.
  const ownBid = (blk) => { const b = blk.getAttribute('data-kb-id'); if (!b || !BID_PATTERN.test(b)) return ''; return ed.querySelector('.kb-countdown-block[data-kb-id=\"' + b + '\"]') === blk ? b : ''; };
  const cdInfo = (blk) => ({ date: blk.getAttribute('data-kb-date') || '', time: blk.getAttribute('data-kb-time') || '', title: blk.getAttribute('data-kb-title') || '' });
  const cdChipText = (blk) => { const b = ownBid(blk); const c = b && n.cdRem ? cdLiveCount(n.cdRem[b], cdInfo(blk)) : 0; const al = b && n.cdMode && n.cdMode[b] === 'alarm'; return c ? (al ? '\u23F0 ' : '\u{1F514} ') + c + ' pengingat' : '\u{1F514} Ingatkan saya'; };
  const openCdRemindSheet = (blk) => { import('./alarm-ui.js').then((A) => openCdRemindSheetNow(blk, A), () => openCdRemindSheetNow(blk, null)); };
  const openCdRemindSheetNow = (blk, A) => {
    if (isP || !blk || !blk.isConnected) return;
    document.querySelectorAll('.ov.rm-ov').forEach((x) => x.remove());
    try { if (ed.contains(document.activeElement)) ed.blur(); } catch (_) {} // keyboard turun supaya lembar tidak tertutup
    const now0 = Date.now(); const opts = cdOptions(cdInfo(blk), now0);
    const bid0 = ownBid(blk); const oldList = bid0 && n.cdRem && n.cdRem[bid0] ? n.cdRem[bid0] : [];
    if (!opts.length) { tWarn('Pilih tanggal yang valid dulu.'); return; }
    if (!opts.some((o) => o.ok) && !oldList.length) { infoKey('kartuDekat'); return; }
    let cdm = bid0 && n.cdMode && n.cdMode[bid0] === 'alarm' ? 'alarm' : 'notif'; // Rev 380
    const mp = A ? A.modePicker({ mode: cdm, onChange: (m) => { cdm = m; } }) : null;
    const chosen = new Set(oldList.filter((d) => opts.some((o) => o.beforeDays === d && o.ok)));
    const ov = h('div', { class: 'ov dlgov rm-ov', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const sum = h('p', { class: 'rm-sum', 'aria-live': 'polite' });
    const optEls = opts.map((o) => h('button', { type: 'button', class: 'rm-opt rm-chk', role: 'checkbox', 'aria-checked': 'false', 'data-d': String(o.beforeDays), disabled: !o.ok, onclick: () => { if (!o.ok) return; if (chosen.has(o.beforeDays)) chosen.delete(o.beforeDays); else chosen.add(o.beforeDays); refresh(); } }, h('span', { class: 'rm-dot', 'aria-hidden': 'true' }), h('span', { class: 'rm-lab' }, o.label + ' \u00b7 ' + (o.ok ? o.when : 'sudah lewat'))));
    const bSave = h('button', { type: 'button', class: 'btn', onclick: () => doSave() }, 'Simpan pengingat');
    const bCancel = h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal');
    const refresh = () => {
      optEls.forEach((b, i) => b.setAttribute('aria-checked', String(chosen.has(opts[i].beforeDays))));
      bSave.disabled = !chosen.size;
      const picked = opts.filter((o) => chosen.has(o.beforeDays));
      sum.textContent = picked.length ? 'Berbunyi ' + picked.length + ' kali: ' + picked.map((o) => o.when).join(', ') : 'Pilih minimal satu waktu pengingat.';
    };
    const doSave = () => {
      const list = [...chosen].sort((a, b) => a - b);
      if (!list.length) { tWarn('Pilih minimal satu waktu pengingat.'); return; }
      if (!blk.isConnected) { ov.remove(); return; }
      flushHist();
      let bid = ownBid(blk);
      if (!bid) bid = newBid([...bidsInHtml(ed.innerHTML), ...Object.keys(n.cdRem || {})]);
      if (!setCdRule(n, bid, list)) { infoKey('maks', 'kartu berpengingat di catatan ini', CD_MAX_BLOCKS, 'Matikan pengingat di kartu lain dulu.'); return; }
      if (mp) setCdMode(n, bid, cdm); // Rev 380: setCdMode butuh cdRem[bid] (sudah ada setelah setCdRule)
      blk.setAttribute('data-kb-id', bid);
      ov.remove(); flushHist(); clearTimeout(tm); save();
      toast('Pengingat diatur: ' + list.length + ' waktu.');
    };
    const doDelete = () => {
      const bid = ownBid(blk);
      if (bid) delete remStash.cd[bid];
      if (bid && n.cdRem && n.cdRem[bid]) { cancelCdAlarms(n, bid); clearCdRule(n, bid); } // batalkan alarm SEBELUM aturan hilang (save() hanya membatalkan ID dari aturan yang masih ada)
      if (bid && blk.isConnected) blk.removeAttribute('data-kb-id');
      ov.remove(); flushHist(); clearTimeout(tm); save();
      tOk('Pengingat dihapus.');
    };
    const bDel = oldList.length ? h('button', { type: 'button', class: 'rm-del', onclick: () => doDelete() }, 'Hapus pengingat') : null;
    const v0 = cdInfo(blk);
    ov.append(h('div', { class: 'sheet rm-sheet', role: 'dialog', 'aria-label': 'Ingatkan saya' },
      h('h3', {}, 'Ingatkan saya'),
      h('p', { class: 'sub rm-row' }, (v0.title || 'Hitung mundur').slice(0, 80)),
      h('div', { class: 'rm-opts', role: 'group', 'aria-label': 'Kapan' }, ...optEls),
      mp ? mp.el : null,
      sum,
      bDel,
      h('div', { class: 'dlgb rm-foot' }, bCancel, bSave)));
    document.body.append(ov);
    refresh();
  };
  // Rev 109 / U6a: ketuk panah di judul bagian lipat = buka/tutup (juga di mode Baca); kursor/keyboard tidak berpindah.
  ed.addEventListener('pointerdown', (e) => { const f = arrowHit(e, ed); if (f) { e.preventDefault(); f.classList.add('pr'); setTimeout(() => f.classList.remove('pr'), 220); } });
  ed.addEventListener('click', (e) => { const f = arrowHit(e, ed); if (f) { e.preventDefault(); foldToggle(f); } });
  if (!isP) {
    ed.addEventListener('pointerdown', (e) => { if (bellHit(e)) e.preventDefault(); }); // jangan memindahkan kursor / membuka keyboard saat lonceng diketuk
    ed.addEventListener('click', (e) => { const row = bellHit(e); if (row) { e.preventDefault(); openRemindSheet(row); } });
    syncBells();
    if (typeof MutationObserver !== 'undefined') {
      let bellRaf = 0;
      const bellObs = new MutationObserver(() => { if (bellRaf) return; bellRaf = requestAnimationFrame(() => { bellRaf = 0; if (alive) syncBells(); }); });
      bellObs.observe(ed, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-cid', 'checked'] });
      stopBellObs = () => bellObs.disconnect();
    }
  }

  // Rev D: Kutipan bisa dimatikan lagi. Ketuk Kutipan di dalam kutipan = kembali ke teks biasa; Backspace di awal kutipan juga melepasnya.
  const quoteOf = (node) => { const el = node && (node.nodeType === 1 ? node : node.parentElement); return el && ed.contains(el) ? el.closest('blockquote') : null; };
  const unwrapQuote = (q) => {
    const sel = getSelection();
    const keep = sel && sel.rangeCount ? [sel.anchorNode, sel.anchorOffset, sel.focusNode, sel.focusOffset] : null;
    const kids = [...q.childNodes];
    const hasBlock = kids.some((k) => k.nodeType === 1 && /^(P|DIV|UL|OL|TABLE|FIGURE|BLOCKQUOTE)$/.test(k.tagName));
    let first;
    if (hasBlock) { first = kids[0]; kids.forEach((k) => q.before(k)); q.remove(); }
    else { const d = document.createElement('div'); kids.forEach((k) => d.append(k)); if (!d.firstChild) d.append(document.createElement('br')); q.replaceWith(d); first = d; }
    try {
      if (keep && keep[0] && ed.contains(keep[0]) && keep[0] !== ed) sel.setBaseAndExtent(keep[0], keep[1], keep[2], keep[3]);
      else if (first) { const r = document.createRange(); r.selectNodeContents(first); r.collapse(true); sel.removeAllRanges(); sel.addRange(r); }
    } catch (_) { /* seleksi tidak kritis */ }
  };
  const toggleQuote = () => {
    flushHist(); restore();
    const sel = getSelection();
    const q = sel && sel.rangeCount ? quoteOf(sel.anchorNode) : null;
    if (q) { unwrapQuote(q); rng = null; } else { document.execCommand('formatBlock', false, 'blockquote'); reSel(); }
    flushHist(); upd(); auto();
  };

  const fsBtn = bar.querySelector('[data-cmd="font-size"]');
  let fsCapsule = null, fsRange = null, fsDragging = false, fsStartHtml = '';
  const closeFs = () => { if (fsCapsule) fsCapsule.remove(); fsCapsule = null; fsDragging = false; fsBtn.classList.remove('on'); };
  const openFs = () => {
    snap();
    if (!rng || rng.collapsed) { tWarn('Blok teksnya dulu'); return; }
    closeFs(); fsRange = rng.cloneRange(); fsBtn.classList.add('on');
    const idxNow = () => { const n = fsRange && fsRange.startContainer.parentElement?.closest('[data-fs]'); return nearestFontLevel(n?.dataset.fs || 100); };
    const track = h('div', { class: 'fss-track', role: 'slider', tabindex: '0', 'aria-label': 'Ukuran huruf', 'aria-valuemin': '0', 'aria-valuemax': '3' });
    const fill = h('div', { class: 'fss-fill' }), marker = h('div', { class: 'fss-marker' });
    FONT_LEVELS.forEach((_, i) => track.append(h('i', { class: 'fss-dot', style: 'left:' + (i * 100 / 3) + '%' })));
    track.append(fill, marker);
    const value = h('b', { class: 'fss-value' }, '');
    fsCapsule = h('div', { class: 'fs-capsule', role: 'group', 'aria-label': 'Atur ukuran huruf' }, h('b', { class: 'fss-aa' }, 'Aa'), track, value);
    const position = () => { const r = bar.getBoundingClientRect(); fsCapsule.style.left = Math.max(8, Math.min(innerWidth - 270, r.left + r.width / 2 - 135)) + 'px'; fsCapsule.style.bottom = Math.max(70, innerHeight - r.top + 8) + 'px'; };
    const paint = (i) => { const k = Math.max(0, Math.min(3, i)); fill.style.width = (k * 100 / 3) + '%'; marker.style.left = (k * 100 / 3) + '%'; value.textContent = FONT_LEVEL_NAMES[k]; track.setAttribute('aria-valuenow', String(k)); track.setAttribute('aria-valuetext', FONT_LEVEL_NAMES[k]); return k; };
    let liveIdx = paint(idxNow());
    // Hanya menerapkan bila titiknya berpindah (tidak membungkus ulang teks pada tiap geseran piksel).
    const setIdx = (k) => {
      k = paint(k); if (k === liveIdx) return; liveIdx = k;
      const next = applyFontScale(ed, fsRange, FONT_LEVELS[k]);
      if (next) { fsRange = next.cloneRange(); rng = next.cloneRange(); upd(); auto(); }
    };
    const apply = (e) => { const r = track.getBoundingClientRect(), ratio = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)); setIdx(Math.round(ratio * 3)); };
    track.addEventListener('pointerdown', (e) => { e.preventDefault(); flushHist(); fsDragging = true; fsStartHtml = ed.innerHTML; track.setPointerCapture?.(e.pointerId); apply(e); });
    track.addEventListener('pointermove', (e) => { if (fsDragging) { e.preventDefault(); apply(e); } });
    const endDrag = () => { if (!fsDragging) return; fsDragging = false; if (ed.innerHTML !== fsStartHtml) flushHist(); };
    track.addEventListener('pointerup', endDrag); track.addEventListener('pointercancel', endDrag);
    track.addEventListener('keydown', (e) => { if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); flushHist(); fsStartHtml = ed.innerHTML; setIdx(liveIdx + (e.key === 'ArrowRight' ? 1 : -1)); if (ed.innerHTML !== fsStartHtml) flushHist(); } });
    document.body.append(fsCapsule); position();
    setTimeout(() => document.addEventListener('pointerdown', outsideFs, true), 0);
  };
  const outsideFs = (e) => { if (fsCapsule && !fsCapsule.contains(e.target) && !fsBtn.contains(e.target)) { document.removeEventListener('pointerdown', outsideFs, true); closeFs(); } };
  // Rev 30b: dipicu dari bindBar (pointerdown/ketuk). Listener 'click' dulu tidak pernah jalan karena touchstart bilah memakai preventDefault.
  const toggleFs = () => { if (fsCapsule) { document.removeEventListener('pointerdown', outsideFs, true); closeFs(); } else openFs(); };
  // Rev 27B: animasi sedot-muntah (Web Animations API; hanya transform + opacity). Ketukan saat animasi berjalan diabaikan.
  const redMotion = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (_) { return false; } };
  const canAnim = () => typeof starBtn.animate === 'function';
  let fmtBusy = false;
  const ctr = (r) => ({ x: r.left + r.width / 2, y: r.top + r.height / 2 });
  const fly = (el, from, to, opt) => el.animate([from, to], { fill: 'both', easing: 'cubic-bezier(.3,.7,.3,1)', ...opt });
  const fmtState = (open) => {
    bar.classList.toggle('open', open); bar.scrollLeft = 0; if (!open) closeFs(); starBtn.setAttribute('aria-expanded', String(open));
    starBtn.setAttribute('aria-label', open ? 'Tutup pengaturan teks' : 'Buka pengaturan teks');
    if (!open) { pm = false; pal.replaceChildren(); if (cp.style.display === 'block') closeCp(); }
  };
  const SUCK = { transform: 'translate(0,0) scale(1)', opacity: 1 };
  const setFmt = (open) => {
    if (fmtBusy || bar.classList.contains('open') === open) return;
    const sides = [...bar.querySelectorAll('button.uh')], fmts = [...bar.querySelectorAll('button.fmt')];
    if (!canAnim()) { fmtState(open); return; }
    if (redMotion()) { fmtState(open); try { bar.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 100 }); } catch (_) {} return; }
    fmtBusy = true; const all = [];
    const fin = (list) => Promise.all(list.map((x) => x.finished.catch(() => {})));
    const to = (el, c) => { const r = ctr(el.getBoundingClientRect()); return 'translate(' + Math.round(c.x - r.x) + 'px,' + Math.round(c.y - r.y) + 'px) scale(.35)'; };
    try {
      if (open) {
        // 1) sedot: Undo/Redo meluncur ke pusat bintang, bintang berdenyut
        const c = ctr(starBtn.getBoundingClientRect()), oldS = starBtn.getBoundingClientRect();
        const a1 = sides.map((el) => fly(el, SUCK, { transform: to(el, c), opacity: 0 }, { duration: 170 })); all.push(...a1);
        all.push(starBtn.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.3)' }, { transform: 'scale(1)' }], { duration: 170 }));
        fin(a1).then(() => {
          // 2) geser: tata letak terbuka, bintang meluncur dari tengah ke kiri
          fmtState(true); all.forEach((x) => x.cancel()); all.length = 0;
          const ns = starBtn.getBoundingClientRect(), nc = ctr(ns);
          all.push(starBtn.animate([{ transform: 'translateX(' + Math.round(c.x - nc.x) + 'px)' }, { transform: 'none' }], { duration: 220, easing: 'cubic-bezier(.3,.7,.3,1)' }));
          // 3) muntah: item keluar dari bintang, berurutan kiri ke kanan
          const a3 = fmts.map((el, i) => fly(el, { transform: to(el, nc), opacity: 0 }, SUCK, { duration: 200, delay: 40 + i * 25, fill: 'backwards' })); all.push(...a3);
          return fin(all);
        }).then(() => { all.forEach((x) => x.cancel()); fmtBusy = false; });
      } else {
        // 1) sedot: item tersedot ke bintang (berurutan), bintang berdenyut
        const c = ctr(starBtn.getBoundingClientRect());
        const a1 = fmts.map((el, i) => fly(el, SUCK, { transform: to(el, c), opacity: 0 }, { duration: 160, delay: (fmts.length - 1 - i) * 15 })); all.push(...a1);
        all.push(starBtn.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.25)' }, { transform: 'scale(1)' }], { duration: 200, delay: 100 }));
        fin(a1).then(() => {
          // 2) tutup: tata letak tertutup, bintang kembali ke tengah, Undo/Redo keluar dari bintang
          fmtState(false); all.forEach((x) => x.cancel()); all.length = 0;
          const nc = ctr(starBtn.getBoundingClientRect());
          all.push(starBtn.animate([{ transform: 'translateX(' + Math.round(c.x - nc.x) + 'px)' }, { transform: 'none' }], { duration: 220, easing: 'cubic-bezier(.3,.7,.3,1)' }));
          const a2 = sides.map((el) => fly(el, { transform: to(el, nc), opacity: 0 }, SUCK, { duration: 200, delay: 60, fill: 'backwards' })); all.push(...a2);
          return fin(all);
        }).then(() => { all.forEach((x) => x.cancel()); fmtBusy = false; });
      }
    } catch (err) { console.error('animasi bilah gagal:', err); all.forEach((x) => { try { x.cancel(); } catch (_) {} }); fmtState(open); fmtBusy = false; }
  };
  const capply = h('button', { type: 'button', class: 'btn line cpb' }, 'Pakai');
  const cnone = h('button', { type: 'button', class: 'btn line' }, 'Tanpa warna');
  const cp = h('div', { class: 'cp', style: 'display:none' },
    wwrap, h('div', { class: 'vrow' }, h('span', { class: 'cpl' }, 'Gelap'), vsl, h('span', { class: 'cpl' }, 'Terang')),
    h('div', { class: 'cpr' }, cprev, chex, capply), cerr,
    sug, h('div', { class: 'cpl' }, 'Terakhir dipakai'), crec, cnone);
  const head = h('div', { class: 'fsh' },
    h('button', { type: 'button', class: 'ghost', 'aria-label': 'Kembali', onclick: () => done() }, ico(PATH.back)),
    h('div', { class: 'hmid' }, h('div', { class: 'stp' }, svt, edt)), marks, modeBtn, moreBtn); // Rev 29 menambah tombol mode Baca/Edit tepat di kiri ⋮ (di antara marks dan moreBtn)
  const body = h('div', { class: 'fsb' }, tt, h('div', { class: 'ln2' }), rel, ed, lpv);
  // Rev 29b: tombol pensil besar (FAB) di pojok kanan bawah, hanya tampil di mode Baca; di Edit tombol mode di header (centang) tetap dipakai.
  const editFab = h('button', { type: 'button', class: 'fab efab', 'aria-label': 'Edit catatan', title: 'Edit catatan', onclick: () => setMode('edit') }, ico(PATH.edit));
  // Rev C: panel Sisipkan ditempatkan sebelum bilah; struktur lama Rev 76: h('div', { class: 'dock' }, lp, rp, cp, pal, bar) tetap menjadi acuan urutan panel.
  const o = h('div', { class: 'fs' }, head, body, h('div', { class: 'dock' }, lp, rp, cp, pal, bar), editFab);
  if (isP) o.classList.add('nobell'); // Rev 103: Catatan Privat tidak pernah punya pengingat baris (judul tidak boleh bocor ke notifikasi)
  // Rev 97 / U4b: menu ▦ (Rev 76) DIHAPUS; semua alat tabel kini chip di bilah chip (bilah-chip.js).
  let activeTable = null, activeCell = null;
  // Rev 96 / U4a: bilah chip kontekstual tabel, dipasang tepat di atas bilah bawah (di dalam .dock). Dipasang lewat DOM agar urutan
  // h('div', { class: 'dock' }, lp, rp, cp, pal, bar) di atas tidak berubah.
  const chipBar = createChipBar(h, { label: 'Alat tabel', onAction: (id) => tableChip(id), ico }); // Rev 181c: chip tabel = dok ikon atas + label bawah
  chipBar.setPages(TABLE_CHIPS);
  if (!isP) chipBar.setPages(withSheetChip(TABLE_CHIPS)); // Rev 124 / U7b-3: chip Ubah jadi lembar kerja (bukan di Catatan Privat)
  o.querySelector('.dock').insertBefore(chipBar.el, bar);
  // Rev 112 / U6d: bilah chip bagian lipat (satu chip sesuai konteks kursor), dipasang di samping bilah chip tabel; keduanya tidak pernah tampil bersamaan
  // (sel tabel tidak bisa berada di dalam/di bawah bagian lipat sebagai blok yang boleh dipindah). Kelas .chips (bilah bawah dipudarkan) dipakai bersama.
  const foldBar = createChipBar(h, { label: 'Alat bagian lipat', onAction: (id) => foldChip(id) });
  foldBar.setPages(FOLD_OUT_CHIPS);
  let foldKind = 'out', foldCtx = null;
  o.querySelector('.dock').insertBefore(foldBar.el, bar);
  // Rev 76: pilihan bagian tabel (hanya penanda sementara data-sel di DOM; sanitize() membuangnya, jadi tidak pernah tersimpan/diekspor)
  let selScope = 'cell', selCell = null;
  const clearSel = () => { try { ed.querySelectorAll('[data-sel]').forEach((x) => x.removeAttribute('data-sel')); } catch (_) {} };
  const scopeCells = () => {
    if (!activeTable || !activeCell) return [];
    const row = activeCell.closest('tr'); if (!row) return [activeCell];
    const idx = [...row.cells].indexOf(activeCell);
    if (selScope === 'row') return [...row.cells];
    if (selScope === 'col') return [...activeTable.rows].map((r) => r.cells[idx]).filter(Boolean);
    if (selScope === 'all') return [...activeTable.rows].flatMap((r) => [...r.cells]);
    return [activeCell];
  };
  const markSel = () => { clearSel(); if (selScope !== 'cell') scopeCells().forEach((c) => c.setAttribute('data-sel', '1')); };
  const resetSel = () => { selScope = 'cell'; selCell = null; clearSel(); };

  // Rev 46: ketuk gambar = PILIH (bukan hapus). Pegangan seret di pojok kanan-bawah + tombol - / + / Hapus mengatur ukuran tampil.
  // Semua kontrol ada di lapisan melayang di luar isi catatan; yang tersimpan hanya atribut data-s (persen lebar, kelipatan 5).
  const imgPct = h('span', { class: 'img-pct', 'aria-live': 'polite' }, '100%');
  const imgMinus = h('button', { type: 'button', class: 'img-b', 'aria-label': 'Perkecil gambar' }, '\u2212');
  const imgPlus = h('button', { type: 'button', class: 'img-b', 'aria-label': 'Perbesar gambar' }, '+');
  const imgFull = h('button', { type: 'button', class: 'img-b wide', 'aria-label': 'Lebar penuh' }, 'Penuh');
  const imgDel = h('button', { type: 'button', class: 'img-b red', 'aria-label': 'Hapus gambar' }, ico(PATH.bin));
  // Rev 47: rata kiri/tengah/kanan (data-a) dan kunci (data-l). Terkunci = ukuran, rata, dan hapus dinonaktifkan; hanya tombol kunci yang aktif.
  const imgAl = { l: h('button', { type: 'button', class: 'img-b al', 'aria-label': 'Rata kiri' }, ico(PATH.alignL)), c: h('button', { type: 'button', class: 'img-b al', 'aria-label': 'Rata tengah' }, ico(PATH.alignC)), r: h('button', { type: 'button', class: 'img-b al', 'aria-label': 'Rata kanan' }, ico(PATH.alignR)) };
  // Rev 48: pilihan per gambar. data-f="1" = teks mengalir di samping (hanya bila rata kiri/kanan dan ukuran 20-70%); tanpa atribut = gambar berdiri sendiri.
  const imgFlow = h('button', { type: 'button', class: 'img-b wide fl', 'aria-label': 'Teks di samping gambar' }, ico(PATH.flow), h('span', {}, ''));
  const imgLock = h('button', { type: 'button', class: 'img-b lk', 'aria-label': 'Kunci gambar' }, ico(PATH.unlock));
  // Rev 50: naik/turun satu blok (jalur cadangan yang mudah dari tahan-seret) + garis sasaran saat menyeret.
  const imgUp = h('button', { type: 'button', class: 'img-b mv', 'aria-label': 'Pindah ke atas' }, ico(PATH.moveUp));
  const imgDn = h('button', { type: 'button', class: 'img-b mv', 'aria-label': 'Pindah ke bawah' }, ico(PATH.moveDown));
  const imgView = h('button', { type: 'button', class: 'img-b wide fl vw', 'aria-label': 'Lihat layar penuh' }, ico(PATH.expand), h('span', {}, 'Lihat')); // Rev 60 (G4)
  const imgDrop = h('div', { class: 'img-drop', style: 'display:none' });
  const imgBar = h('div', { class: 'img-bar', role: 'toolbar', 'aria-label': 'Atur gambar' },
    h('div', { class: 'img-row r1' }, imgMinus, imgPct, imgPlus, imgFull, imgUp, imgDn),
    h('div', { class: 'img-row r2' }, imgAl.l, imgAl.c, imgAl.r, imgLock, imgDel),
    h('div', { class: 'img-row r3' }, imgFlow, imgView));
  const imgGrip = h('div', { class: 'img-grip', 'aria-label': 'Seret untuk mengubah ukuran', role: 'slider' });
  const imgFrame = h('div', { class: 'img-frame' }, imgGrip);
  const imgTools = h('div', { class: 'img-tools', style: 'display:none' }, imgFrame, imgBar, imgDrop);
  let imgSel = null, imgDrag = null;
  const imgScale = (fig) => G.scaleOf(fig.getAttribute('data-s'));
  const placeImageTools = () => {
    if (!imgSel) return;
    if (!imgSel.isConnected || !ed.contains(imgSel)) { clearImgSel(); return; }
    const r = imgSel.getBoundingClientRect();
    const top = head.getBoundingClientRect().bottom, dock = bar.parentElement.getBoundingClientRect().top;
    const gone = r.bottom < top + 8 || r.top > dock - 8;
    imgTools.style.visibility = gone ? 'hidden' : 'visible';
    if (gone) return;
    imgFrame.style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
    imgPct.textContent = imgScale(imgSel) + '%';
    syncImgUi();
    const bh = imgBar.offsetHeight || 44, below = r.bottom + 10;
    const y = below + bh > dock - 4 ? Math.max(top + 4, r.top - bh - 10) : below;
    const bw = imgBar.offsetWidth || 230;
    imgBar.style.left = Math.max(8, Math.min(innerWidth - bw - 8, r.left + r.width / 2 - bw / 2)) + 'px';
    imgBar.style.top = Math.max(top + 4, Math.min(y, dock - bh - 4)) + 'px';
  };
  const figLocked = (fig) => G.isLocked(fig.getAttribute('data-l'));
  const syncImgUi = () => {
    if (!imgSel) return;
    const lk = figLocked(imgSel), a = G.alignOf(imgSel.getAttribute('data-a'));
    imgTools.classList.toggle('locked', lk);
    imgLock.replaceChildren(ico(lk ? PATH.lock : PATH.unlock));
    imgLock.setAttribute('aria-label', lk ? 'Buka kunci gambar' : 'Kunci gambar'); imgLock.setAttribute('aria-pressed', lk ? 'true' : 'false');
    const fl = imgSel.getAttribute('data-f') === '1';
    imgFlow.classList.toggle('on', fl); imgFlow.setAttribute('aria-pressed', fl ? 'true' : 'false'); imgFlow.lastChild.textContent = fl ? 'Teks di samping: Aktif' : 'Teks di samping: Mati';
    for (const k of G.ALIGNS) { imgAl[k].classList.toggle('on', k === a); imgAl[k].setAttribute('aria-pressed', k === a ? 'true' : 'false'); }
  };
  function clearImgSel() { imgSel = null; imgDrag = null; imgTools.style.display = 'none'; }
  const selectImage = (fig) => {
    if (o.contains(document.activeElement)) { try { document.activeElement.blur(); } catch (_) {} } // keyboard turun agar gambar dan alat terlihat
    imgSel = fig; imgTools.style.display = 'block'; imgTools.style.visibility = 'visible';
    try { fig.scrollIntoView({ block: 'nearest' }); } catch (_) {}
    placeImageTools(); requestAnimationFrame(placeImageTools);
  };
  const setImgScale = (fig, v, commit) => {
    const next = G.normalizeScale(v); if (imgScale(fig) === next && !commit) return;
    fig.setAttribute('data-s', String(next)); placeImageTools();
  };
  const commitImgScale = () => { if (!imgSel) return; flushHist(); auto(); };
  const tapBtn = (b, fn, allowLocked) => b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); if (imgSel && (allowLocked || !figLocked(imgSel))) fn(imgSel); });
  tapBtn(imgMinus, (fig) => { flushHist(); setImgScale(fig, G.stepScale(fig.getAttribute('data-s'), -1), true); commitImgScale(); });
  tapBtn(imgPlus, (fig) => { flushHist(); setImgScale(fig, G.stepScale(fig.getAttribute('data-s'), 1), true); commitImgScale(); });
  tapBtn(imgFull, (fig) => { flushHist(); setImgScale(fig, 100, true); commitImgScale(); });
  tapBtn(imgDel, (fig) => {
    const before = ed.innerHTML; flushHist(); const next = fig.nextElementSibling; clearImgSel(); fig.remove();
    if (next && next.tagName === 'P' && !next.textContent.trim() && !next.querySelector('img,figure,table')) next.remove();
    flushHist(); auto(); tOk('Gambar dihapus', () => { ed.innerHTML = sanitize(before); flushHist(); auto(); refreshImages(); });
  });
  for (const k of G.ALIGNS) tapBtn(imgAl[k], (fig) => {
    if (G.alignOf(fig.getAttribute('data-a')) === k) return;
    flushHist(); if (k === G.ALIGN_DEFAULT) fig.removeAttribute('data-a'); else fig.setAttribute('data-a', k);
    placeImageTools(); flushHist(); auto();
  });
  tapBtn(imgFlow, (fig) => {
    flushHist();
    if (fig.getAttribute('data-f') === '1') { fig.removeAttribute('data-f'); tInfo('Gambar berdiri sendiri'); }
    else {
      fig.setAttribute('data-f', '1');
      if (G.alignOf(fig.getAttribute('data-a')) === 'c') fig.setAttribute('data-a', 'l'); // teks hanya bisa di samping gambar rata kiri/kanan
      if (imgScale(fig) > 70) fig.setAttribute('data-s', '50'); // gambar lebar tidak menyisakan ruang untuk teks
      tInfo('Teks mengalir di samping gambar');
    }
    placeImageTools(); flushHist(); auto();
  });
  tapBtn(imgLock, (fig) => {
    flushHist(); if (figLocked(fig)) fig.removeAttribute('data-l'); else fig.setAttribute('data-l', '1');
    placeImageTools(); flushHist(); auto();
    toast(figLocked(fig) ? 'Gambar dikunci' : 'Kunci dibuka');
  }, true);
  // ---- Rev 50: pindah posisi gambar. Satuan pindah = gambar + baris kosong pengetikan di bawahnya (bila ada). Sasaran hanya di antara blok tingkat atas
  // (tidak masuk ke daftar/tabel). Terkunci = tidak bisa dipindah. Setiap pemindahan = satu langkah Undo.
  const moveUnit = (fig) => { const sp = fig.nextElementSibling; return sp && sp.tagName === 'P' && !sp.textContent.trim() && !sp.querySelector('img,figure,table,input') ? [fig, sp] : [fig]; };
  const blockNodes = (unit) => [...ed.childNodes].filter((c) => !unit.includes(c) && (c.nodeType === 1 || (c.nodeType === 3 && c.textContent.trim())));
  const rectOf = (c) => { if (c.nodeType === 1) return c.getBoundingClientRect(); const r = document.createRange(); r.selectNode(c); return r.getBoundingClientRect(); };
  const doMove = (fig, ref) => {
    const unit = moveUnit(fig);
    if (unit[unit.length - 1].nextSibling === ref) return false; // sudah di situ
    flushHist();
    for (const n of unit) ed.insertBefore(n, ref);
    if (ed.lastChild && ed.lastChild.nodeType === 1 && ed.lastChild.tagName === 'FIGURE') { const p = document.createElement('p'); p.append(document.createElement('br')); ed.append(p); } // selalu ada baris untuk mengetik di bawah gambar terakhir
    flushHist(); auto(); placeImageTools();
    try { fig.scrollIntoView({ block: 'nearest' }); } catch (_) {}
    requestAnimationFrame(placeImageTools);
    return true;
  };
  const stepMove = (fig, dir) => {
    const unit = moveUnit(fig), blocks = blockNodes(unit);
    const pos = blocks.filter((b) => (b.compareDocumentPosition(fig) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0).length;
    const to = pos + dir;
    if (to < 0 || to > blocks.length) { toast(dir < 0 ? 'Sudah di paling atas.' : 'Sudah di paling bawah.'); return; }
    doMove(fig, blocks[to] || null);
  };
  tapBtn(imgUp, (fig) => stepMove(fig, -1));
  tapBtn(imgDn, (fig) => stepMove(fig, 1));
  let mv = null;
  const mvTouchBlock = (e) => { if (e.cancelable) e.preventDefault(); };
  const mvCalc = () => { const unit = moveUnit(mv.fig), blocks = blockNodes(unit), rects = blocks.map(rectOf); return { blocks, rects, idx: G.dropIndex(rects, mv.y) }; };
  const mvShow = () => {
    const d = mvCalc(), er = ed.getBoundingClientRect();
    const y = d.rects.length ? (d.idx < d.rects.length ? d.rects[d.idx].top : d.rects[d.rects.length - 1].bottom) : er.top;
    imgDrop.style.cssText = `display:block;left:${er.left + 4}px;top:${Math.round(y) - 2}px;width:${Math.max(0, er.width - 8)}px`;
    mv.d = d;
  };
  function endMove() {
    if (!mv) return;
    clearTimeout(mv.timer); cancelAnimationFrame(mv.raf);
    window.removeEventListener('pointermove', mvMove, true); window.removeEventListener('pointerup', mvUp, true); window.removeEventListener('pointercancel', mvCancel, true);
    window.removeEventListener('touchmove', mvTouchBlock, true);
    if (mv.active) { mv.fig.classList.remove('moving'); imgTools.classList.remove('moving'); imgDrop.style.display = 'none'; }
    mv = null;
  }
  const mvLoop = () => {
    if (!mv || !mv.active) return;
    const top = head.getBoundingClientRect().bottom, dock = bar.parentElement.getBoundingClientRect().top;
    const st = G.scrollStep(mv.y, top, dock);
    if (st) { body.scrollTop += st; mvShow(); }
    mv.raf = requestAnimationFrame(mvLoop);
  };
  const mvStart = () => {
    if (!mv) return;
    const fig = mv.fig;
    if (!fig.isConnected || !ed.contains(fig)) { endMove(); return; }
    if (figLocked(fig)) { endMove(); infoKey('gbrKunci', 'dipindahkan'); return; }
    mv.active = true;
    try { const sel = getSelection(); if (sel) sel.removeAllRanges(); } catch (_) {}
    selectImage(fig); fig.classList.add('moving'); imgTools.classList.add('moving');
    window.addEventListener('touchmove', mvTouchBlock, { capture: true, passive: false }); // tahan gulir layar selama menyeret
    try { if (navigator.vibrate) navigator.vibrate(12); } catch (_) {}
    mvShow(); mv.raf = requestAnimationFrame(mvLoop);
  };
  function mvMove(e) {
    if (!mv || e.pointerId !== mv.id) return;
    if (!mv.active) { if (Math.hypot(e.clientX - mv.x, e.clientY - mv.y) > G.MOVE_SLOP) endMove(); return; } // menggulir, bukan memindah
    mv.y = e.clientY; if (e.cancelable) e.preventDefault(); mvShow();
  }
  function mvUp(e) {
    if (!mv || e.pointerId !== mv.id) return;
    if (!mv.active) { endMove(); return; }
    const fig = mv.fig, d = mv.d || mvCalc(); endMove();
    if (fig.isConnected && ed.contains(fig)) doMove(fig, d.blocks[d.idx] || null);
  }
  function mvCancel(e) { if (mv && e.pointerId === mv.id) endMove(); }
  ed.addEventListener('pointerdown', (e) => {
    const fig = e.target.closest && e.target.closest('figure.ki');
    if (!fig || editorMode !== 'edit' || isP || (e.pointerType === 'mouse' && e.button !== 0)) return;
    endMove();
    mv = { id: e.pointerId, x: e.clientX, y: e.clientY, fig, active: false, timer: setTimeout(mvStart, G.LONG_PRESS_MS), raf: 0, d: null };
    window.addEventListener('pointermove', mvMove, true); window.addEventListener('pointerup', mvUp, true); window.addEventListener('pointercancel', mvCancel, true);
  });
  ed.addEventListener('contextmenu', (e) => { if (e.target.closest && e.target.closest('figure.ki')) e.preventDefault(); }); // menu tahan-lama bawaan Android tidak boleh menutupi gestur
  ed.addEventListener('dragstart', (e) => { if (e.target.closest && e.target.closest('figure.ki')) e.preventDefault(); });
  imgGrip.addEventListener('pointerdown', (e) => {
    if (!imgSel || figLocked(imgSel)) return; e.preventDefault(); e.stopPropagation();
    const cs = getComputedStyle(ed), full = ed.clientWidth - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0);
    flushHist();
    imgDrag = { id: e.pointerId, x: e.clientX, startPx: imgSel.getBoundingClientRect().width, full, moved: false };
    try { imgGrip.setPointerCapture(e.pointerId); } catch (_) {}
  });
  imgGrip.addEventListener('pointermove', (e) => {
    if (!imgDrag || e.pointerId !== imgDrag.id || !imgSel) return;
    const dx = (e.clientX - imgDrag.x) * 2; // gambar rata tengah: tarik satu sisi menggeser dua sisi
    if (Math.abs(dx) > 2) imgDrag.moved = true;
    setImgScale(imgSel, G.scaleFromDrag(imgDrag.startPx, dx, imgDrag.full), false);
  });
  const endGrip = (e) => { if (!imgDrag || (e && e.pointerId !== imgDrag.id)) return; const moved = imgDrag.moved; imgDrag = null; try { imgGrip.releasePointerCapture(e.pointerId); } catch (_) {} if (moved) commitImgScale(); };
  imgGrip.addEventListener('pointerup', endGrip); imgGrip.addEventListener('pointercancel', endGrip);

  const tint = () => {
    const t = contrast(n.col); o.style.background = t ? n.col : ''; o.classList.toggle('skybg', !t); // Rev 37: tanpa warna = latar langit
    syncBars(t ? n.col : null); // Rev 55: bar status/navigasi ikut warna catatan
    for (const el of [head, body]) el.style.cssText = t ? `--ink:${t.ink};--mut:${t.mut};--ln:${t.ln};color:${t.ink}` : '';
  };
  const fit = () => { if (vv) { o.style.height = vv.height + 'px'; o.style.top = vv.offsetTop + 'px'; } };
  const pinUi = () => { pinMark.style.display = n.pin ? '' : 'none'; };
  // "Terakhir diedit" hanya berubah jika isi/judul/warna/label benar-benar berubah (membuka lalu menutup tidak dihitung).
  let last = noteSignature(n.title, sanitize(ed.innerHTML), n.col, n.labels, n.links);
  let lastReminderKey = JSON.stringify([n.reminder || null, n.title]);
  // Rev 105 / U5e: Urungkan/Ulangi. Undo menghapus baris/kartu -> save() memangkas aturannya; Ulangi mengembalikan HTML-nya, jadi aturan ikut dikembalikan dari simpanan sesi ini.
  // Simpanan hanya ada selama editor terbuka (tidak disimpan). Hapus pengingat lewat lembar membuang simpanannya (hapus sengaja tidak boleh hidup lagi karena Ulangi).
  const remStash = { cb: {}, cd: {} };
  const stashRem = () => {
    if (isP) return;
    const cids = new Set(cidsInHtml(n.html)), bids = new Set(bidsInHtml(n.html));
    for (const k of Object.keys(n.cbRem || {})) if (!cids.has(k)) remStash.cb[k] = n.cbRem[k];
    for (const k of Object.keys(n.cdRem || {})) if (!bids.has(k)) remStash.cd[k] = n.cdRem[k];
    for (const k of Object.keys(remStash.cb)) if (cids.has(k) && !(n.cbRem && n.cbRem[k])) { setCbRule(n, k, remStash.cb[k]); delete remStash.cb[k]; }
    for (const k of Object.keys(remStash.cd)) if (bids.has(k) && !(n.cdRem && n.cdRem[k])) { setCdRule(n, k, remStash.cd[k]); delete remStash.cd[k]; }
  };
  const remKey = () => JSON.stringify([n.title, n.cbRem || null, n.cdRem || null, rowsFromHtml(n.html), blocksFromHtml(n.html)]); // Rev 102 / U5b: berubah bila judul, aturan, teks/centang baris, atau kartu hitung mundur berubah
  let lastRemKey = isP ? '' : remKey();
  const edtUi = () => { edt.textContent = (n.title || n.text) && n.updated ? 'Diedit ' + formatEdited(n.updated) : 'Catatan baru'; };
  const save = () => {
    dirty = false;
    n.title = tt.value.trim(); n.text = notePlain(ed); n.html = sanitize(ed.innerHTML);
    const sg = noteSignature(n.title, n.html, n.col, n.labels, n.links);
    if (sg !== last) { n.updated = Date.now(); last = sg; }
    const at = fromLocalInput(remAt.value);
    if (at && at <= Date.now() && remRepeat.value !== 'daily') { remAt.value = ''; infoPast(at, '', 'Kolom pengingat dikosongkan karena belum ada waktu yang sah.'); }
    if (at && (at > Date.now() || remRepeat.value === 'daily')) n.reminder = withMode({ at, repeat: remRepeat.value === 'daily' ? 'daily' : 'once' }, nMode); else delete n.reminder;
    if ((n.title || n.text || n.html || n.reminder) && list.indexOf(n) < 0) list.push(n);
    const reminderKey = JSON.stringify([n.reminder || null, n.title]);
    if (!isP && lastReminderKey !== reminderKey) {
      const result = scheduleReminder('note', n);
      if (result.warning === 'inexact_alarm') dlg({ title: 'Pengingat mungkin terlambat', msg: 'Izin Alarm & pengingat tepat belum aktif. Pengingat tetap dijadwalkan, tetapi bisa terlambat.', yes: 'Buka pengaturan', ok: () => { try { globalThis.AndroidAPI?.openExactAlarmSettings?.(); } catch (_) {} } });
      else if (!result.ok && !result.skipped) infoKey(result.reason === 'permission' ? 'izin' : 'jadwal');
      lastReminderKey = reminderKey;
    }
    stashRem();
    if (!isP) { // Rev 102 / U5b: pangkas cbRem/cdRem ke baris/kartu yang masih ada, lalu jadwal ulang hanya bila ada yang relevan berubah
      const rk = remKey();
      if (rk !== lastRemKey) {
        lastRemKey = rk;
        if (noteHasRem(n)) { const rr = reconcileNoteAlarms(n); lastRemKey = remKey(); if (rr.results.some((x) => x.reason === 'permission')) infoKey('izin'); }
      }
    }
    syncBells(); // Rev 105 / U5e: aturan bisa baru dipulihkan (Urungkan/Ulangi) atau dipangkas; lonceng baris mengikuti
    remUi(); ctx.persist(); setSv(true); edtUi();
  };
  const auto = () => { dirty = true; setSv(false); clearTimeout(tm); tm = setTimeout(save, 400); clearTimeout(lt); lt = setTimeout(syncLinks, 1200); };

  // Rev 33: tabel dasar. Alat tabel (Rev 97: chip) berada di luar HTML yang disimpan.
  // Rev 319: pegangan seret lebar kolom (modul malas)
  let colRs = null, colRsLoading = false, tblW = null;
  const ensureColRs = () => {
    if (colRs || colRsLoading) return; colRsLoading = true;
    import('./tabel-seret.js').then((m) => {
      if (!alive) return;
      tblW = m; colRs = m.createColResizer({ h, bounds: () => ({ top: head.getBoundingClientRect().bottom, bottom: dockTop() ?? innerHeight }), onStart: flushHist, onCommit: () => { flushHist(); auto(); } });
      o.append(colRs.el); tableUi();
    }).catch(() => { colRsLoading = false; });
  };
  let placeRaf = 0;
  const placeSoon = () => { if (placeRaf) return; placeRaf = requestAnimationFrame(() => { placeRaf = 0; placeImageTools(); if (colRs) colRs.place(); }); };
  const tableUi = () => {
    const sl = getSelection();
    const node = sl && sl.rangeCount ? sl.anchorNode : null;
    const el = node && (node.nodeType === 1 ? node : node.parentElement);
    let cell = el && ed.contains(el) ? el.closest('td,th') : null;
    const table = cell && cell.closest('table');
    if (cell && isTotalRow(cell.closest('tr'))) { // sel Total tidak bisa disunting: alat tabel bekerja pada baris data terakhir di kolom yang sama
      const dr = dataRowsOf(table), ci = [...cell.parentElement.cells].indexOf(cell), lr = dr[dr.length - 1];
      cell = lr ? lr.cells[Math.min(ci, lr.cells.length - 1)] || null : null;
    }
    if (editorMode !== 'edit' || !table || !ed.contains(table)) {
      activeTable = activeCell = null; resetSel();
      chipBar.hide(); if (!foldBar.isShown()) o.classList.remove('chips');
      if (colRs) colRs.hide();
      return;
    }
    activeTable = table; activeCell = cell;
    ensureColRs(); if (colRs) { colRs.show(table); requestAnimationFrame(placeSoon); } // Rev 319
    // Rev 96 / U4a: bilah chip tampil saat kursor di sel; bilah bawah dipudarkan (kelas .chips). Saat baru muncul, tinggi editor menyusut,
    // jadi sel aktif digulir ke tempat terlihat. Chip struktur dinonaktifkan di batas 50 baris / 8 kolom (tambah) dan 2 x 2 (hapus).
    const dims = tableDims(table), lim = tableLimits(dims.rows, dims.cols);
    const chipsNew = chipBar.show(); o.classList.add('chips');
    if (chipsNew) requestAnimationFrame(() => { try { if (activeCell) activeCell.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (_) {} });
    if (cell !== selCell) { if (selScope !== 'cell') { selScope = 'cell'; clearSel(); } selCell = cell; } // pindah sel = pilihan kembali ke "Sel"
    const hf = headerFlags(table);
    const tf = totalFuncOf(table, [...cell.parentElement.cells].indexOf(cell));
    // Rev 97 / U4b: keadaan chip: header menyala = hitam, perataan menampilkan nilai sel aktif, Pilih menampilkan bagian yang dipilih.
    chipBar.setState({
      'row-below': { disabled: !lim.addRow }, 'row-above': { disabled: !lim.addRow },
      'col-before': { disabled: !lim.addCol }, 'col-after': { disabled: !lim.addCol },
      'hdr-row': { active: hf.row }, 'hdr-col': { active: hf.col },
      'align': { label: alignLabel(cell.getAttribute('data-a')) },
      'total': { label: tf ? 'Total: ' + totalLabel(tf) + ' ⌄' : 'Total ⌄', active: !!tf },
      'tot-none': { active: !tf }, 'tot-sum': { active: tf === 'sum' }, 'tot-avg': { active: tf === 'avg' }, 'tot-cnt': { active: tf === 'cnt' }, 'tot-min': { active: tf === 'min' }, 'tot-max': { active: tf === 'max' },
      'row-del': { disabled: !lim.delRow }, 'col-del': { disabled: !lim.delCol },
      'pick': { label: scopeLabel(selScope), active: selScope !== 'cell' },
      'sel-cell': { active: selScope === 'cell' }, 'sel-row': { active: selScope === 'row' },
      'sel-col': { active: selScope === 'col' }, 'sel-all': { active: selScope === 'all' },
    });
  };
  // Rev 96 / U4a: kursor dipindah ke sel yang baru dibuat (seleksi eksplisit; tidak membuka keyboard bila editor sedang tidak fokus).
  const caretIntoCell = (cell) => {
    try {
      const r = document.createRange(); r.selectNodeContents(cell); r.collapse(true);
      const sl = getSelection(); sl.removeAllRanges(); sl.addRange(r);
      cell.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    } catch (_) {}
  };
  // Rev 96 / U4a + Rev 97 / U4b: semua aksi chip tabel. Satu aksi = satu langkah Undo (flushHist sebelum dan sesudah).
  // Menyentuh isi tabel selalu lewat fungsi di bilah-chip.js; sel yang diganti (TD <-> TH) diganti oleh sel setara, jadi kursor dipulihkan ke sel itu.
  const undoTo = (before) => () => { ed.innerHTML = sanitize(before); flushHist(); auto(); };
  // Toast bawaan berada di dasar layar dan akan menutupi bilah chip; di sini diangkat tepat di atas dock supaya chip tetap bisa diketuk.
  // `top` = batas atas dock yang dipakai; hitung SEBELUM bilah chip disembunyikan (Hapus tabel), kalau tidak toast jatuh persis di bawah jari
  // dan ketukan susulan (ghost click) menekan "Urungkan" seketika.
  const dockTop = () => { try { return o.querySelector('.dock').getBoundingClientRect().top; } catch (_) { return null; } };
  const chipToast = (msg, undo, after, top = dockTop()) => {
    toast(msg, undo, after);
    try { const t = document.getElementById('toast'); if (t && top !== null) t.style.bottom = Math.max(8, document.documentElement.clientHeight - top + 8) + 'px'; } catch (_) {}
  };
  const tableChip = (id) => {
    if (editorMode !== 'edit' || !activeTable || !activeCell) return;
    const table = activeTable, cell = activeCell, row = cell.closest('tr');
    if (!row) return;
    const colIndex = Math.max(0, [...row.cells].indexOf(cell)), rowIndex = row.rowIndex;
    const d = tableDims(table), lim = tableLimits(d.rows, d.cols);
    // Pilih ⌄: hanya menandai sel (penanda sementara, tidak disimpan); tidak mengubah isi, jadi tanpa langkah Undo.
    if (id === 'sel-cell' || id === 'sel-row' || id === 'sel-col' || id === 'sel-all') {
      selScope = id.slice(4); selCell = cell; markSel(); tableUi(); return;
    }
    if (id === 'align') {
      const next = nextAlign(cell.getAttribute('data-a')), cells = scopeCells();
      clearSel(); flushHist();
      for (const c of cells) { if (next === 'l') c.removeAttribute('data-a'); else c.setAttribute('data-a', next); }
      flushHist(); auto(); selCell = cell;
      if (selScope !== 'cell') markSel();
      tableUi(); // umpan balik = label chip Perataan + sel terpilih tersorot (tanpa toast agar tidak menutupi chip)
      return;
    }
    if (id.startsWith('tot-')) { // Rev 99 / U4d: Total kolom aktif (Tanpa total / Jumlah / Rata-rata / Hitung / Min / Maks); 1 aksi = 1 langkah Undo
      resetSel(); flushHist();
      const tc = setColumnTotal(table, colIndex, id.slice(4));
      flushHist(); auto();
      const nr = table.rows[rowIndex], nc = nr && nr.cells[Math.min(colIndex, nr.cells.length - 1)];
      if (nc && !isTotalRow(nr)) caretIntoCell(nc);
      if (tc) { try { tc.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (_) {} }
      tableUi();
      return;
    }
    if (id === 'hdr-row' || id === 'hdr-col') {
      resetSel(); flushHist();
      toggleHeader(table, id === 'hdr-row' ? 'row' : 'col');
      flushHist(); auto();
      const nr = table.rows[rowIndex], nc = nr && nr.cells[Math.min(colIndex, nr.cells.length - 1)];
      if (nc) caretIntoCell(nc);
      tableUi(); // umpan balik = chip header hitam bila menyala
      return;
    }
    if (id === 'row-del' || id === 'col-del') {
      if (id === 'row-del' && !lim.delRow) { chipToast('Tabel harus memiliki minimal 2 baris.'); return; }
      if (id === 'col-del' && !lim.delCol) { chipToast('Tabel harus memiliki minimal 2 kolom.'); return; }
      const before = ed.innerHTML;
      resetSel(); flushHist();
      const wAttr = id === 'col-del' ? table.getAttribute('data-w') : null;
      const target = id === 'row-del' ? deleteTableRow(table, row, colIndex) : deleteTableCol(table, cell);
      if (target && wAttr && tblW) tblW.shiftTableWidths(table, 'del', colIndex, d.cols); // Rev 319
      flushHist(); auto();
      if (target) caretIntoCell(target);
      tableUi();
      chipToast(id === 'row-del' ? 'Baris dihapus.' : 'Kolom dihapus.', undoTo(before), () => tableUi());
      return;
    }
    if (id === 'to-sheet') { // Rev 124 / U7b-3: tabel catatan diganti pulau lembar kerja baru; 1 langkah Undo (toast Urungkan juga membuang lembar barunya)
      if (isP) return;
      if (!getEngine()) { loadEngine().then(() => tableChip(id), () => chipToast('Lembar kerja gagal disiapkan.')); return; } // Rev 192b: baris Total jadi rumus hidup = butuh mesin rumus
      const sheets = ctx.data.sheets || (ctx.data.sheets = {}), ids = Object.keys(sheets);
      if (ids.length >= LZ.MAX_SHEETS) { chipToast('Maksimal ' + LZ.MAX_SHEETS + ' lembar kerja.'); return; }
      const sh = sheetFromMatrix(matrixFromTable(table), { name: 'Lembar kerja ' + (ids.length + 1) });
      if (!sh) { chipToast('Tabel ini tidak bisa diubah jadi lembar kerja.'); return; }
      while (sheets[sh.id]) sh.id = 's' + Math.random().toString(36).slice(2, 8);
      const before = ed.innerHTML, wrap = table.closest('.tbl-wrap') || table, top = dockTop();
      const block = document.createElement('div'); block.className = 'ksheet'; block.setAttribute('data-sheet', sh.id);
      resetSel(); flushHist(); wrap.replaceWith(block); activeTable = activeCell = null; sheets[sh.id] = sh; renderIsland(block);
      flushHist(); auto(); ctx.persist();
      chipBar.hide(); o.classList.remove('chips'); tableUi();
      chipToast('Tabel diubah jadi lembar kerja', () => { delete ctx.data.sheets[sh.id]; ctx.persist(); undoTo(before)(); }, () => tableUi(), top);
      return;
    }
    if (id === 'tbl-del') {
      const before = ed.innerHTML, wrap = table.closest('.tbl-wrap') || table;
      const near = wrap.nextElementSibling || wrap.previousElementSibling, top = dockTop();
      resetSel(); flushHist(); wrap.remove(); activeTable = activeCell = null;
      flushHist(); auto();
      chipBar.hide(); o.classList.remove('chips');
      if (near) caretIntoCell(near);
      tableUi(); chipToast('Tabel dihapus', undoTo(before), () => tableUi(), top);
      return;
    }
    // ＋ Baris di bawah/atas dan ＋ Kolom sebelumnya/sesudahnya (U4a)
    const isRow = id === 'row-below' || id === 'row-above';
    if (!isRow && id !== 'col-before' && id !== 'col-after') return;
    if (isRow && !lim.addRow) { chipToast('Maksimal ' + TABLE_EDIT_MAX_ROWS + ' baris per tabel.'); return; }
    if (!isRow && !lim.addCol) { chipToast('Maksimal ' + TABLE_EDIT_MAX_COLS + ' kolom per tabel.'); return; }
    resetSel(); flushHist();
    let target = null;
    if (isRow) { const nr = addTableRow(table, row, id === 'row-below' ? 'below' : 'above'); target = nr && nr.cells[Math.min(colIndex, nr.cells.length - 1)]; }
    else {
      const wAttr = table.getAttribute('data-w');
      target = addTableCol(table, cell, id === 'col-after' ? 'after' : 'before');
      if (target && wAttr && tblW) tblW.shiftTableWidths(table, 'ins', id === 'col-after' ? colIndex + 1 : colIndex, d.cols); // Rev 319
    }
    flushHist(); auto();
    if (target) caretIntoCell(target);
    tableUi();
  };
  const openTableDialog = () => {
    if (editorMode !== 'edit') { tWarn('Beralih ke mode Edit dulu.'); return; }
    snap();
    const sel = getSelection();
    const node = sel && sel.rangeCount ? sel.anchorNode : null;
    const el = node && (node.nodeType === 1 ? node : node.parentElement);
    if (el && ed.contains(el) && el.closest('td,th')) { infoKey('dlmTabel', 'Tabel'); return; }
    let rows = 3, cols = 3, headOn = true, dragging = false;
    const selAtOpen = getSelection();
    const savedRange = selAtOpen && selAtOpen.rangeCount && ed.contains(selAtOpen.anchorNode) ? selAtOpen.getRangeAt(0).cloneRange() : (rng ? rng.cloneRange() : null);
    const label = h('b', { class: 'tbl-size-label', 'aria-live': 'polite' }, '3 × 3');
    const grid = h('div', { class: 'tbl-grid', role: 'grid', 'aria-label': 'Pilih ukuran tabel' });
    const cells = [];
    for (let r = 1; r <= TABLE_PICK_ROWS; r++) for (let c = 1; c <= TABLE_MAX_COLS; c++) {
      const cell = h('button', { type: 'button', class: 'tbl-grid-cell' + (r < TABLE_MIN_ROWS || c < TABLE_MIN_COLS ? ' off' : ''), disabled: r < TABLE_MIN_ROWS || c < TABLE_MIN_COLS, role: 'gridcell', 'aria-label': `${r} baris, ${c} kolom`, 'data-r': String(r), 'data-c': String(c) });
      cells.push(cell); grid.append(cell);
    }
    const headToggle = h('button', { type: 'button', class: 'tbl-head-toggle on', 'aria-pressed': 'true' }, '✓  Baris judul');
    const update = (r, c) => { const z = tableSize(r, c); rows = z.rows; cols = z.cols; label.textContent = `${cols} × ${rows}`; for (const x of cells) x.classList.toggle('on', Number(x.dataset.r) <= rows && Number(x.dataset.c) <= cols); };
    const pick = (e) => { const hit = document.elementFromPoint?.(e.clientX, e.clientY); const b = (hit && hit.closest('[data-r][data-c]')) || e.target.closest?.('[data-r][data-c]'); if (b && !b.disabled) update(Number(b.dataset.r), Number(b.dataset.c)); };
    grid.addEventListener('pointerdown', (e) => { e.preventDefault(); dragging = true; grid.setPointerCapture?.(e.pointerId); pick(e); });
    grid.addEventListener('pointermove', (e) => { if (dragging) pick(e); });
    const end = () => { dragging = false; }; grid.addEventListener('pointerup', end); grid.addEventListener('pointercancel', end);
    grid.addEventListener('click', pick);
    headToggle.addEventListener('click', () => { headOn = !headOn; headToggle.classList.toggle('on', headOn); headToggle.setAttribute('aria-pressed', String(headOn)); headToggle.textContent = (headOn ? '✓  ' : '□  ') + 'Baris judul'; });
    const ov = h('div', { class: 'ov dlgov tbl-dialog', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const cancel = h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal');
    const insert = h('button', { type: 'button', class: 'btn', onclick: () => {
      ov.remove(); const z = tableSize(rows, cols); snap(); flushHist();
      const currentSel = getSelection();
      let r = currentSel.rangeCount && ed.contains(currentSel.anchorNode) ? currentSel.getRangeAt(0).cloneRange() : (savedRange ? savedRange.cloneRange() : null);
      if (!r || !ed.contains(r.startContainer)) { r = document.createRange(); r.selectNodeContents(ed); r.collapse(false); }
      if (!r.collapsed) r.deleteContents();
      const wrap = document.createElement('div'); wrap.innerHTML = createTableHTML(z.rows, z.cols, headOn); const block = wrap.firstElementChild;
      const after = document.createElement('p'); after.append(document.createElement('br'));
      const start = r.startContainer.nodeType === 1 ? r.startContainer : r.startContainer.parentElement;
      const host = start && start.closest('p,div,li');
      if (host && ed.contains(host) && host !== ed && !host.closest('.tbl-wrap')) {
        const tailRange = document.createRange(); tailRange.selectNodeContents(host);
        try { tailRange.setStart(r.startContainer, r.startOffset); const tail = tailRange.extractContents(); if (tail.childNodes.length) after.replaceChildren(tail); } catch (_) {}
        if (!host.textContent.trim() && !host.querySelector('br,input')) host.append(document.createElement('br'));
        host.after(block, after);
      } else { r.insertNode(block); block.after(after); }
      ed.focus();
      const firstCell = block.querySelector('td,th');
      if (firstCell) { const cr = document.createRange(); cr.selectNodeContents(firstCell); cr.collapse(false); const ss = getSelection(); ss.removeAllRanges(); ss.addRange(cr); }
      flushHist(); auto(); tableUi();
    } }, 'Sisipkan');
    ov.append(h('div', { class: 'sheet dlg tbl-dialog-card' }, h('h3', {}, 'Ukuran tabel'), label, grid, headToggle, h('div', { class: 'dlgb rev' }, cancel, insert)));
    document.body.append(ov); update(3, 3);
    // Rev 40: fokus pindah ke dialog, jadi keyboard langsung turun (posisi kursor sudah disimpan di savedRange).
    try { const ae = document.activeElement; if (ae && ae !== document.body && typeof ae.blur === 'function') ae.blur(); } catch (_) {}
  };
  // Label: baris label di bawah judul + panel pilih/tambah label.
  const labUi = () => {
    const mine = noteLabels(n, labelsAll);
    const shown = mine.slice(0, 1), rest = mine.length - shown.length;
    hlab.replaceChildren(...[
      ...shown.map((l) => h('button', { type: 'button', class: 'lab', 'aria-label': 'Label ' + l.name, onclick: () => openLp() }, l.name)),
      rest > 0 ? h('button', { type: 'button', class: 'lab', 'aria-label': rest + ' label lainnya', onclick: () => openLp() }, '+' + rest) : null].filter(Boolean));
    lhint.textContent = lDel ? 'Ketuk label yang mau dihapus' : 'Ketuk label untuk memasang atau melepas';
    ldelBtn.setAttribute('aria-pressed', String(lDel)); ldelBtn.classList.toggle('on', lDel);
    lrow.style.display = lAdding && !lDel ? '' : 'none';
    const chips = labelsAll.map((l) => {
      const on = (n.labels || []).includes(l.id);
      if (lDel) return h('button', { type: 'button', class: 'lab del', 'aria-label': 'Hapus label ' + l.name, onclick: () => delLabel(l) }, '✕ ' + l.name);
      return h('button', { type: 'button', class: 'lab' + (on ? ' on' : ''), 'aria-pressed': String(on), onclick: () => { n.labels = toggleId(n.labels, l.id); labUi(); auto(); } }, (on ? '✓ ' : '') + l.name);
    });
    if (!lDel) chips.push(h('button', { type: 'button', class: 'lab add', 'aria-label': 'Tambah label baru', 'aria-expanded': String(lAdding), onclick: () => { lAdding = !lAdding; labUi(); if (lAdding) { try { lnew.focus(); } catch (_) {} } } }, '+'));
    else if (!labelsAll.length) chips.push(h('span', { class: 'svt' }, 'Belum ada label.'));
    lchips.replaceChildren(...chips);
  };
  const addLabel = () => {
    const v = validateLabel(lnew.value, labelsAll);
    if (!v.ok) { lerr.textContent = v.msg; return; }
    const l = { id: newId(), name: v.value };
    labelsAll.push(l); n.labels = toggleId(n.labels, l.id);
    lnew.value = ''; lerr.textContent = ''; lAdding = false; labUi(); auto();
  };
  const delLabel = (l) => {
    const has = (x) => Array.isArray(x.labels) && x.labels.includes(l.id);
    const use = data.notes.filter(has).length + data.priv.filter(has).length;
    dlg({ title: 'Hapus label?', msg: `Label \u201c${l.name}\u201d dicopot dari ${use} catatan. Catatannya tidak ikut terhapus.`, yes: 'Hapus label', red: true,
      ok: () => {
        removeLabel(data, l.id); labelsAll = data.settings.labels;
        if (Array.isArray(n.labels)) n.labels = n.labels.filter((x) => x !== l.id);
        ctx.persist(); ctx.render(); labUi(); auto(); tOk('Label dihapus.');
      } });
  };
  const openRp = () => { if (!rp) return; if (cp.style.display === 'block') closeCp(); closeLp(); pal.replaceChildren(); pm = false; if (o.contains(document.activeElement)) document.activeElement.blur(); rp.style.display = 'block'; };
  const closeRp = () => { if (rp) rp.style.display = 'none'; };
  const openLp = () => { closeRp(); if (cp.style.display === 'block') closeCp(); pal.replaceChildren(); pm = false; labUi(); lp.style.display = 'block'; };
  const closeLp = () => { const was = lp.style.display === 'block'; lp.style.display = 'none'; lerr.textContent = ''; lAdding = false; lDel = false; lrow.style.display = 'none'; return was; };

  // Hubungan antarcatatan (Rev 18): chip catatan terkait + "Disebut di" (dihitung dari catatan lain) + pemilih.
  const goNote = (id) => {
    if (!data.notes.some((x) => x.id === id)) return;
    save(); if (list.includes(n)) trail.push(n.id);
    closeNow(); openEditor(ctx, id, 'note', true);
  };
  const relChip = (x) => h('button', { type: 'button', class: 'lab rl', 'aria-label': 'Buka catatan ' + (x.title || 'Tanpa judul'), onclick: () => goNote(x.id) }, x.title || 'Tanpa judul');
  if (!isP) ed.addEventListener('click', (e) => { // Rev 343 / I2: ketuk tautan [[ = buka catatan tujuan
    const l = e.target.closest && e.target.closest('span.nl'); if (!l) return; e.preventDefault();
    if (data.notes.some((x) => x.id === l.getAttribute('data-nid'))) goNote(l.getAttribute('data-nid'));
    else { l.setAttribute('data-nx', ''); tWarn('Catatan tujuan tidak ada (dihapus atau di tempat sampah).'); }
  });
  // Bagian "Catatan terkait" hanya tampil bila catatan punya hubungan; "Disebut di" hanya bila ada hubungan balik (Rev 25).
  // Menghubungkan pertama kali lewat menu ⋮ > Hubungkan catatan.
  const relUi = () => {
    if (!rel) return;
    const out = linkedNotes(n, data.notes), inn = backlinks(data.notes, n.id);
    rel.style.display = out.length || inn.length ? '' : 'none';
    if (linkMark) linkMark.style.display = out.length || inn.length ? '' : 'none';
    rel.replaceChildren(...[
      out.length ? [h('div', { class: 'lbs', role: 'group', 'aria-label': 'Catatan terkait' }, [...out.map(relChip), h('button', { type: 'button', class: 'lab add', 'aria-label': 'Ubah hubungan catatan', onclick: () => openPicker() }, '+')])] : null,
      inn.length ? [h('div', { class: 'relh' }, 'Disebut di'), h('div', { class: 'lbs' }, inn.map(relChip))] : null,
    ].flat().filter(Boolean)); // replaceChildren tidak meratakan array: tanpa .flat() muncul teks "[object HTMLDivElement]"
  };
  function openPicker() {
    if (!rel) return;
    if (o.contains(document.activeElement)) document.activeElement.blur();
    const q = h('input', { class: 'in', type: 'search', placeholder: 'Cari catatan', 'aria-label': 'Cari catatan untuk dihubungkan' });
    const err = h('p', { class: 'err', role: 'alert' });
    const lst = h('div', { class: 'prl' });
    const ov = h('div', { class: 'ov pickov', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const fill = () => {
      const on = new Set(cleanLinks(n));
      const c = linkCandidates(data.notes, n.id, q.value);
      lst.replaceChildren(...(c.length ? c.map((x) => h('button', { type: 'button', class: 'prow' + (on.has(x.id) ? ' on' : ''), 'aria-pressed': String(on.has(x.id)),
        onclick: () => {
          const r = toggleLink(n, x.id);
          if (!r.ok) { err.textContent = r.msg; return; }
          err.textContent = ''; n.links = r.ids; fill(); relUi(); auto();
        } },
        h('span', { class: 'ckb', 'aria-hidden': 'true' }, on.has(x.id) ? '✓' : ''),
        h('span', { class: 'prt' }, h('b', {}, x.title || 'Tanpa judul'), x.text ? h('small', {}, x.text) : null)))
        : [h('div', { class: 'empty' }, data.notes.some((x) => x.id !== n.id) ? 'Tidak ditemukan. Coba kata kunci lain.' : 'Belum ada catatan lain untuk dihubungkan.')]));
    };
    q.addEventListener('input', fill);
    ov.append(h('div', { class: 'sheet pick', role: 'dialog', 'aria-label': 'Hubungkan catatan' },
      h('h3', {}, 'Hubungkan catatan'), q, err, lst,
      h('button', { type: 'button', class: 'btn', onclick: () => ov.remove() }, 'Selesai')));
    document.body.append(ov); fill();
  }

  // Menu ⋮ (Rev 25): kartu melayang di dalam editor (ikut tinggi layar yang terlihat, jadi tidak tertutup keyboard atau keluar layar).
  // Tiap item hanya memicu aksi yang SUDAH ada; menu ditutup dulu, baru aksinya jalan.
  const menuKey = (e) => { if (e.key === 'Escape') dismissMenu(); };
  let menuBusy = false;
  // Rev 46: selama animasi menu panah, kedip bintang latar DIJEDA (dua lapis bintang beranimasi opacity ikut menggambar ulang di belakang tombol = kedap-kedip, DUGAAN).
  const skyHold = (on) => { try { o.classList.toggle('anim-hold', !!on); document.documentElement.classList.toggle('anim-hold', !!on); } catch (_) {} };
  const closeMenu = () => {
    menuBusy = false; skyHold(false);
    document.removeEventListener('keydown', menuKey);
    moreBtn.setAttribute('aria-expanded', 'false');
    if (!menuOv) return false;
    const was = menuOv.isConnected; menuOv.remove(); menuOv = null;
    return was;
  };
  const mi = (icon, text, fn, cls = '') => h('button', { type: 'button', role: 'menuitem', class: 'mi' + (cls ? ' ' + cls : ''), onclick: () => { closeMenu(); fn(); } }, ico(icon), h('span', {}, text));
  function openMenu() {
    if (menuOv && menuOv.isConnected) return;
    if (o.contains(document.activeElement)) document.activeElement.blur(); // tutup keyboard agar menu lega
    const items = [
      mi(PATH.tag, 'Label', () => openLp()),
      mi(PATH.palette, 'Ubah warna', () => openCp()),
      isP ? null : mi(PATH.alarm, remAt.value ? 'Ubah pengingat' : 'Pengingat', () => openRp()),
      isP ? null : mi(PATH.link, 'Hubungkan catatan', () => openPicker()),
      isP ? null : mi(PATH.star, n.favorite ? 'Hapus dari Favorit' : 'Tambahkan ke Favorit', () => { n.favorite = !n.favorite; save(); toast(n.favorite ? 'Ditambahkan ke Favorit' : 'Dihapus dari Favorit'); }),
      isP ? null : mi(PATH.pin, n.pin ? 'Lepas sematan' : 'Sematkan', () => { n.pin = !n.pin; pinUi(); save(); }),
      isP ? null : mi(PATH.share, 'Bagikan', () => { save(); openShare(ctx, n); }),
      mi(PATH.copy, 'Buat salinan', () => doDuplicate()),
      h('div', { class: 'mdv', role: 'separator' }),
      mi(PATH.bin, 'Hapus', () => del(), 'red'),
    ].filter(Boolean);
    menuOv = h('div', { class: 'menuov', onclick: (e) => { if (e.target === menuOv) dismissMenu(); } },
      h('div', { class: 'menu', role: 'menu', 'aria-label': 'Menu catatan' }, items));
    o.append(menuOv); moreBtn.setAttribute('aria-expanded', 'true');
    document.addEventListener('keydown', menuKey);
    spitMenu(menuOv);
  }
  // Rev 35: animasi muntah-tarik ala Langit untuk menu panah. Buka = item keluar dari tombol panah berurutan; tutup (ketuk panah/luar menu) = item tersedot kembali.
  // Hanya transform + opacity. Tutup lewat tombol Kembali HP / pilih item tetap langsung (closeMenu).
  function menuItems(ov) { return [...ov.querySelectorAll('.menu > .mi')]; }
  function spitMenu(ov) {
    if (!canAnim() || redMotion()) return;
    const card = ov.querySelector('.menu'), items = menuItems(ov); if (!card || !items.length) return;
    menuBusy = true; skyHold(true); card.style.overflow = 'visible';
    try {
      const c = ctr(moreBtn.getBoundingClientRect());
      const to = (el) => { const r = ctr(el.getBoundingClientRect()); return 'translate(' + Math.round(c.x - r.x) + 'px,' + Math.round(c.y - r.y) + 'px) scale(.35)'; };
      const anims = items.map((el, i) => { const t = to(el); return el.animate([{ transform: t, opacity: 0 }, { transform: t, opacity: 0, offset: .3 }, SUCK], { duration: 230, delay: 20 + i * 28, fill: 'backwards', easing: 'cubic-bezier(.3,.7,.3,1)' }); });
      Promise.all(anims.map((x) => x.finished.catch(() => {}))).then(() => { anims.forEach((x) => { try { x.cancel(); } catch (_) {} }); if (card.isConnected) card.style.overflow = ''; menuBusy = false; skyHold(false); });
    } catch (err) { console.error('animasi menu gagal:', err); card.style.overflow = ''; menuBusy = false; skyHold(false); }
  }
  function dismissMenu() {
    if (menuBusy) return;
    const ov = menuOv; if (!ov || !ov.isConnected) return;
    if (!canAnim() || redMotion()) { closeMenu(); return; }
    const card = ov.querySelector('.menu'), items = menuItems(ov);
    if (!card || !items.length) { closeMenu(); return; }
    menuBusy = true; skyHold(true); card.style.overflow = 'visible'; moreBtn.setAttribute('aria-expanded', 'false'); // panah langsung berputar kembali ke bawah
    try {
      const c = ctr(moreBtn.getBoundingClientRect());
      const to = (el) => { const r = ctr(el.getBoundingClientRect()); return 'translate(' + Math.round(c.x - r.x) + 'px,' + Math.round(c.y - r.y) + 'px) scale(.35)'; };
      const n = items.length;
      const anims = items.map((el, i) => el.animate([SUCK, { opacity: 0, offset: .65 }, { transform: to(el), opacity: 0 }], { duration: 190, delay: (n - 1 - i) * 18, fill: 'both', easing: 'cubic-bezier(.3,.7,.3,1)' }));
      anims.push(card.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 150, delay: 120, fill: 'both' }));
      Promise.all(anims.map((x) => x.finished.catch(() => {}))).then(() => { menuBusy = false; skyHold(false); if (menuOv === ov) closeMenu(); else ov.remove(); });
    } catch (err) { console.error('animasi tutup menu gagal:', err); menuBusy = false; skyHold(false); closeMenu(); }
  }
  // Buat salinan (Rev 25, butir 10): simpan dulu isi editor, salin dari data tersimpan, editor asli tetap terbuka.
  // Salinan Catatan Privat masuk ke daftar Privat (tidak pernah ke daftar biasa).
  function doDuplicate() {
    save();
    if (!list.includes(n)) { tWarn('Catatan masih kosong, belum ada yang disalin.'); return; }
    const copy = addDuplicate(data, isP ? 'priv' : 'note', n, { id: newId(), now: Date.now() });
    ctx.persist(); ctx.render();
    const lost = countSheetRefs(n.html || '') - countSheetRefs(copy.html || ''); // Rev 125 / U7b-4
    toast('Salinan dibuat' + (lost > 0 ? ' (' + lost + ' lembar kerja tidak ikut disalin)' : ''), () => {
      if (alive) closeNow(); else if (current) return; // editor lain sudah terbuka: jangan menumpuk
      openEditor(ctx, copy.id, kind);
    }, null, 'Buka');
    dupToast = document.getElementById('toast');
  }

  // Pratinjau tautan: kartu gambar + judul di bawah isi catatan. Memuat dari internet bila ada; gagal = tampil alamat saja.
  // Rev 325 / L4 (D5 hibrid): URL yang sudah menjadi kartu tautan tidak dobel di kotak pratinjau bawah isi. linkcard.js dimuat MALAS hanya bila ada kartu;
  // selama belum termuat hasilnya null (tampilan dan n.prev dibiarkan, tidak dihapus).
  let lkSkip = null;
  const linkUrls = () => {
    const all = extractUrls(ed.innerText, 12), cs = ed.querySelectorAll('.lk-card');
    if (!cs.length) return all.slice(0, 3);
    if (!lkSkip) { import('./linkcard.js').then((m) => { lkSkip = m.skipCardUrls; if (alive) syncLinks(); }, () => { lkSkip = (u) => u; if (alive) syncLinks(); }); return null; }
    return lkSkip(all, [...cs].map((c) => ({ u: c.getAttribute('data-u') }))).slice(0, 3);
  };
  const renderLinks = () => {
    const urls = linkUrls(); if (!urls) return;
    lpv.replaceChildren(...urls.map((u) => {
      const pv = n.prev && n.prev[u];
      const sub = pending.has(u) ? 'Memuat pratinjau...' : hostOf(u);
      return h('button', { type: 'button', class: 'lpc', 'aria-label': 'Buka tautan ' + hostOf(u), onclick: () => { if (!openExternal(u)) tWarn('Tidak bisa membuka tautan.'); } },
        pv && safeImageUrl(pv.i) ? thumb(pv.i, 'lpi', 'lph') : linkIcon('lph'),
        h('div', { class: 'lpt' }, h('b', {}, (pv && pv.t) || hostOf(u)), h('small', {}, (pv && pv.s && pv.t ? pv.s + ' · ' : '') + sub)));
    }));
  };
  function syncLinks() {
    if (isP) { delete n.prev; renderLinks(); return; } // Rev 321b: Catatan Privat tidak pernah mengambil pratinjau dari internet
    const urls = linkUrls(); if (!urls) return;
    if (n.prev) for (const k of Object.keys(n.prev)) if (!urls.includes(k)) delete n.prev[k];
    for (const u of urls) {
      if ((n.prev && n.prev[u]) || pending.has(u) || failedLinks.has(u)) continue;
      pending.add(u);
      fetchPreview(u).then((pv) => {
        if (!n.prev) n.prev = {};
        n.prev[u] = pv; ctx.persist();
      }).catch((e) => { failedLinks.add(u); console.error('pratinjau tautan gagal:', e); })
        .finally(() => { pending.delete(u); if (alive) renderLinks(); });
    }
    renderLinks();
  }
  // Blok teks diingat agar tidak hilang saat tombol format disentuh.
  const snap = () => { const s = getSelection(); if (s.rangeCount && ed.contains(s.anchorNode)) { const r = s.getRangeAt(0); if (!r.collapsed) rng = r.cloneRange(); } };
  const reSel = () => { if (rng) { const s = getSelection(); s.removeAllRanges(); s.addRange(rng); } };
  const restore = () => { ed.focus(); reSel(); };
  // Urungkan (Rev 23c): riwayat salinan isi editor (lihat undo.js). Judul tidak ikut; hanya isi catatan.
  const caretAt = () => {
    const sl = getSelection();
    if (!sl.rangeCount || !ed.contains(sl.anchorNode)) return null;
    try { const r = document.createRange(); r.selectNodeContents(ed); r.setEnd(sl.anchorNode, sl.anchorOffset); return r.toString().length; } catch (err) { console.error('posisi kursor gagal:', err); return null; }
  };
  const putCaret = (pos) => {
    try {
      const sl = getSelection(); const r = document.createRange();
      const w = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let left = Number.isFinite(pos) ? pos : Infinity, node, hit = false;
      while ((node = w.nextNode())) { if (left <= node.length) { r.setStart(node, left); hit = true; break; } left -= node.length; }
      if (!hit) { r.selectNodeContents(ed); r.collapse(false); } else r.collapse(true);
      sl.removeAllRanges(); sl.addRange(r);
    } catch (err) { console.error('menaruh kursor gagal:', err); }
  };
  // Rev 113 / U6e: atribut SEMENTARA data-rem (lonceng baris, ditambah syncBells SESUDAH render) tidak boleh masuk riwayat: kalau ikut, isi sesudah Urungkan berbeda dari simpanan teratas, flushHist di doRedo menganggapnya ketikan baru dan menutup jalur Ulangi.
  const histHtml = () => ed.innerHTML.replace(/ data-rem="[^"]*"/g, '');
  const hist = createHistory({ html: histHtml(), caret: null });
  let ht = null;
  let okHtml = ed.innerHTML; // keadaan sah terakhir (untuk penjaga gambar terkunci, Rev 47)
  const undoBtn = bar.querySelector('[data-cmd="undo"]');
  const redoBtn = bar.querySelector('[data-cmd="redo"]');
  const undoUi = () => {
    for (const [b, can] of [[undoBtn, hist.canUndo()], [redoBtn, hist.canRedo()]]) { b.classList.toggle('dis', !can); b.setAttribute('aria-disabled', can ? 'false' : 'true'); }
  };
  const flushHist = () => { okHtml = ed.innerHTML; clearTimeout(ht); ht = null; hist.push({ html: histHtml(), caret: caretAt() }); undoUi(); };
  const markHist = () => { clearTimeout(ht); ht = setTimeout(flushHist, 600); }; // ketikan berurutan dihitung satu langkah
  const applyHist = (st) => {
    ed.innerHTML = sanitize(st.html);
    hydrateBlocks(ed); // renderer blok dipulihkan juga setelah Undo/Redo, bukan hanya saat catatan dibuka
    if (typeof refreshImages === 'function') refreshImages();
    hist.setTop({ html: histHtml() }); // samakan dengan bentuk setelah sanitize agar jalur Ulangi tidak terhapus tanpa sengaja
    undoUi();
    if (document.activeElement === ed) putCaret(st.caret); // keyboard tidak dibuka paksa bila sedang tertutup
    upd(); auto();
  };
  const doUndo = () => {
    flushHist(); // ketikan yang belum dicatat dicatat dulu, supaya ikut bisa diurungkan
    const st = hist.undo(); undoUi();
    if (st) applyHist(st);
  };
  const doRedo = () => {
    flushHist(); // ketikan baru yang belum dicatat menutup jalur Ulangi (null di bawah)
    const st = hist.redo(); undoUi();
    if (st) applyHist(st);
  };
  const upd = () => {
    const s = getSelection();
    if (s.rangeCount && ed.contains(s.anchorNode)) { const r = s.getRangeAt(0); if (!r.collapsed) rng = r.cloneRange(); }
    for (const c of ['bold', 'italic', 'underline', 'strikeThrough', 'insertUnorderedList', 'insertOrderedList']) {
      const b = bar.querySelector(`[data-cmd="${c}"]`); if (b) b.classList.toggle('on', document.queryCommandState(c));
    }
  };
  // Saat keyboard terbuka, buang jarak aman bawah agar bilah format menempel rapat di atas keyboard.
  // Keyboard dianggap terbuka hanya jika kolom isian aktif DAN tinggi layar yang terlihat menyusut jauh (bukan sekadar fokus tersisa
  // setelah keyboard ditutup, yang membuat bilah menabrak tombol navigasi HP).
  const kbOpen = () => { const H = (window.screen && window.screen.height) || 0, vh = vv ? vv.height : window.innerHeight; return H > 0 && vh < H * 0.78; };
  const kbUi = () => o.classList.toggle('kb', o.contains(document.activeElement) && kbOpen());
  o.addEventListener('focusin', () => { kbUi(); setTimeout(kbUi, 350); });
  o.addEventListener('focusout', () => setTimeout(kbUi, 0));
  const countdownRefresh = setInterval(() => { if (!alive || document.hidden) return; ed.querySelectorAll('.kb-countdown-block').forEach((b) => syncCountdownBlock(b)); }, 60_000);
  const cleanup = () => { alive = false; closeViewer(); closeMenu(); try { endMove(); } catch (_) {} skyHold(false); try { document.documentElement.classList.remove('ed-open'); } catch (_) {} if (stopImageObserver) stopImageObserver(); if (stopBellObs) stopBellObs(); document.querySelectorAll('.ov.rm-ov').forEach((x) => x.remove()); for (const u of imageUrls) URL.revokeObjectURL(u); imageUrls.clear(); imageInput.remove(); closeFs();  imgTools.remove(); try { if (colRs) colRs.el.remove(); } catch (_) {} document.removeEventListener('pointerdown', outsideFs, true); document.removeEventListener('selectionchange', clampReadSel); if (isP && dupToast && dupToast.isConnected) dupToast.remove(); /* tombol Buka salinan privat tidak boleh hidup setelah editor ditutup */ document.querySelectorAll('.ov.pickov').forEach((x) => x.remove()); clearTimeout(tm); clearTimeout(lt); clearTimeout(ht); document.removeEventListener('selectionchange', keepCaretRight); document.removeEventListener('selectionchange', upd); document.removeEventListener('selectionchange', selChanged); if (vv) { vv.removeEventListener('resize', fit); vv.removeEventListener('scroll', fit); vv.removeEventListener('resize', kbUi); }  clearInterval(countdownRefresh); try { removeEventListener('resize', placeSoon); if (vv) { vv.removeEventListener('resize', placeSoon); vv.removeEventListener('scroll', placeSoon); } } catch (_) {} /* Rev 195 / P5: pendengar yang dulu tertinggal (menahan seluruh editor di RAM) */ try { syncBars(); } catch (_) {} };
  const closeNow = () => { save(); cleanup(); o.remove(); current = null; };
  // Kembali: bila catatan ini dibuka lewat chip terkait, kembali ke catatan sebelumnya (bukan ke daftar).
  const done = () => {
    closeNow();
    const p = trail.pop();
    if (p && data.notes.some((x) => x.id === p)) openEditor(ctx, p, 'note', true); else trail = [];
    ctx.render();
  };
  const del = () => {
    trail = [];
    if (isP) { if (!list.includes(n)) { done(); return; } save(); confirmDeletePriv(ctx, n, closeNow); return; }
    closeNow(); if (data.notes.includes(n)) removeNote(ctx, n); else ctx.render();
  };

  // Roda warna digambar piksel demi piksel; v (terang) mengubah kecerahan seluruh roda.
  const drawWheel = () => {
    const ctx2 = wheel.getContext('2d'); if (!ctx2) return;
    const img = ctx2.createImageData(WS, WS), R = WS / 2, v = hsv.v;
    for (let y = 0; y < WS; y++) for (let x = 0; x < WS; x++) {
      const dx = x + 0.5 - R, dy = y + 0.5 - R, d = Math.hypot(dx, dy), i = (y * WS + x) * 4;
      if (d > R) continue; // di luar lingkaran: transparan
      const hh = ((Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360) / 60, sat = d / R;
      const c = v * sat, xx = c * (1 - Math.abs(hh % 2 - 1)), m = v - c;
      const [r, g, b] = hh < 1 ? [c, xx, 0] : hh < 2 ? [xx, c, 0] : hh < 3 ? [0, c, xx] : hh < 4 ? [0, xx, c] : hh < 5 ? [xx, 0, c] : [c, 0, xx];
      img.data[i] = (r + m) * 255; img.data[i + 1] = (g + m) * 255; img.data[i + 2] = (b + m) * 255; img.data[i + 3] = d > R - 1 ? 200 : 255;
    }
    ctx2.putImageData(img, 0, 0);
  };
  const moveMark = () => {
    const a = hsv.h * Math.PI / 180, r = hsv.s * 50;
    wmark.style.left = (50 + Math.cos(a) * r) + '%'; wmark.style.top = (50 + Math.sin(a) * r) + '%';
    wmark.style.background = hsvToHex(hsv.h, hsv.s, hsv.v);
  };
  const updSlider = () => { vsl.value = String(Math.round(hsv.v * 100)); vsl.style.background = `linear-gradient(90deg,#000,${hsvToHex(hsv.h, hsv.s, 1)})`; };
  const wheelUi = () => { drawWheel(); moveMark(); updSlider(); };

  const recUi = () => {
    const r = data.settings.recent.filter((c) => HEX.test(c));
    crec.replaceChildren(...(r.length ? r.map((c) => {
      const b = h('button', { type: 'button', 'aria-label': 'Warna ' + c, title: c, class: c === n.col ? 'on' : '', onclick: () => setCol(c, true) });
      b.style.background = c; return b;
    }) : [h('span', { class: 'svt' }, 'Belum ada')]));
  };
  // Saran warna: kelompok yang cocok dengan tema yang sedang dipakai tampil di atas.
  const darkNow = () => {
    const t = document.documentElement.getAttribute('data-theme');
    return t === 'dark' || (t !== 'light' && typeof matchMedia === 'function' && matchMedia('(prefers-color-scheme: dark)').matches);
  };
  const sugUi = () => {
    const grp = (title, list) => [h('div', { class: 'cpl' }, title), h('div', { class: 'cps' }, list.map(([c, nm]) => {
      const b = h('button', { type: 'button', 'aria-label': nm + ' ' + c, title: nm, class: c.toLowerCase() === n.col ? 'on' : '', onclick: () => setCol(c.toLowerCase(), true) });
      b.style.background = c; return b;
    }))];
    const L = grp('Saran lembut (serasi tema terang)', SUGGEST_LIGHT), D = grp('Saran pekat (serasi tema gelap)', SUGGEST_DARK);
    sug.replaceChildren(...(darkNow() ? [...D, ...L] : [...L, ...D]));
  };
  const syncCp = (fromWheel) => {
    chex.value = n.col || ''; cerr.textContent = '';
    cprev.style.background = n.col || 'transparent';
    if (!fromWheel) { const hv = hexToHsv(n.col); if (hv) hsv = hv; wheelUi(); }
    recUi(); sugUi();
  };
  const setCol = (hex, remember, fromWheel) => {
    n.col = hex; tint();
    if (remember && hex) data.settings.recent = addRecent(data.settings.recent, hex);
    syncCp(fromWheel); auto();
  };
  const openCp = () => {
    closeLp(); closeRp(); pal.replaceChildren(); pm = false;
    if (o.contains(document.activeElement)) document.activeElement.blur(); // tutup keyboard agar roda warna lega
    syncCp(); cp.style.display = 'block';
  };
  const closeCp = () => { if (n.col) { data.settings.recent = addRecent(data.settings.recent, n.col); ctx.persist(); } cp.style.display = 'none'; };

  // Mode Baca/Edit (Rev 29): mode hanya hidup selama editor terbuka; isi tetap memakai HTML yang sama.
  let editorMode = 'edit';
  const modeUi = () => {
    const baca = editorMode === 'baca';
    modeBtn.replaceChildren(ico(baca ? PATH.edit : PATH.tugas));
    modeBtn.setAttribute('aria-label', baca ? 'Beralih ke mode Edit' : 'Selesai mengedit, beralih ke mode Baca');
    modeBtn.setAttribute('title', baca ? 'Mode Edit' : 'Selesai mengedit');
    modeBtn.setAttribute('aria-pressed', String(!baca));
  };
  // Fokus editor dipusatkan di satu jalur. Fokus pertama tetap sinkron dengan ketukan pengguna;
  // satu RAF setelahnya membantu WebView menempatkan kursor setelah contentEditable/layout berubah.
  const focusEditorAtEnd = () => {
    try { ed.focus({ preventScroll: true }); } catch (_) { try { ed.focus(); } catch (err) { console.error('fokus editor gagal:', err); } }
    const place = () => {
      if (!alive || editorMode !== 'edit') return;
      if (document.activeElement !== ed) {
        try { ed.focus({ preventScroll: true }); } catch (_) { try { ed.focus(); } catch (err) { console.error('fokus ulang editor gagal:', err); } }
      }
      putCaret(Infinity);
    };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(place); else setTimeout(place, 0);
  };
  const setMode = (next, initial = false) => {
    if (next !== 'baca' && next !== 'edit') return;
    if (!initial && editorMode === next) return;
    if (!initial && next === 'baca') {
      if (fmtBusy) { tWarn('Tunggu sebentar sampai animasi Langit selesai.'); return; }
      clearTimeout(tm); tm = 0;
      save();
      fmtState(false); // tutup panel format teks tanpa animasi; bilah akan disembunyikan di mode Baca
      if (o.contains(document.activeElement)) document.activeElement.blur();
    }
    editorMode = next;
    if (next === 'baca') { clearImgSel(); endMove(); activeTable = activeCell = null; resetSel(); }
    const baca = next === 'baca';
    if (baca) { closeMoodTools(); }
    if (baca) { chipBar.hide(); foldBar.hide(); foldCtx = null; o.classList.remove('chips'); } // Rev 96 / U4a: bilah chip tabel ikut disembunyikan di mode Baca
    tt.readOnly = baca;
    ed.contentEditable = baca ? 'false' : 'true';
    o.classList.toggle('ed-baca', baca);
    modeUi();
    if (!initial && !baca) {
      focusEditorAtEnd(); // fokus langsung dari ketukan pengguna, lalu pastikan kursor stabil setelah layout berubah
    }
  };
  modeBtn.addEventListener('click', () => setMode(editorMode === 'baca' ? 'edit' : 'baca'));

  // Rev 35: di mode Baca, "Pilih semua" (dan seret gagang seleksi) hanya boleh mengenai ISI catatan, sama seperti di mode Edit.
  // Penyebabnya: isi tidak lagi contenteditable, jadi Android memilih seluruh halaman (judul ikut). Seleksi dijepit ke dalam .ed2.
  const clampReadSel = () => {
    if (!alive || editorMode !== 'baca') return;
    const sel = document.getSelection(); if (!sel || !sel.rangeCount) return;
    const r = sel.getRangeAt(0); if (r.collapsed) return;
    if (!r.intersectsNode(ed)) { sel.removeAllRanges(); return; }
    const box = document.createRange(); box.selectNodeContents(ed);
    const before = r.compareBoundaryPoints(Range.START_TO_START, box) < 0;
    const after = r.compareBoundaryPoints(Range.END_TO_END, box) > 0;
    if (!before && !after) return;
    const nr = r.cloneRange();
    if (before) nr.setStart(ed, 0);
    if (after) nr.setEnd(ed, ed.childNodes.length);
    sel.removeAllRanges(); sel.addRange(nr);
  };
  document.addEventListener('selectionchange', clampReadSel);

  // URL teks biasa di isi bisa dibuka hanya dalam mode Baca; seleksi teks tetap bebas untuk disalin.
  const openReadLink = (e) => {
    if (editorMode !== 'baca' || (e.target.nodeType === 1 && e.target.closest('input,button'))) return;
    const selected = getSelection(); if (selected && !selected.isCollapsed) return;
    let r = null;
    try { r = document.caretRangeFromPoint?.(e.clientX, e.clientY) || null; } catch (_) {}
    let node = r && r.startContainer, offset = r && r.startOffset;
    if (!node) {
      try {
        const pos = document.caretPositionFromPoint?.(e.clientX, e.clientY);
        if (pos) { node = pos.offsetNode; offset = pos.offset; }
      } catch (_) {}
    }
    if (!node || !ed.contains(node)) return;
    try {
      const before = document.createRange(); before.selectNodeContents(ed); before.setEnd(node, offset);
      const url = urlAtOffset(ed.textContent || '', before.toString().length);
      if (url) { e.preventDefault(); if (!openExternal(url)) tWarn('Tidak bisa membuka tautan.'); }
    } catch (err) { console.error('membaca posisi tautan gagal:', err); }
  };
  ed.addEventListener('click', openReadLink);
  ed.addEventListener('click', () => setTimeout(tableUi, 0));
  ed.addEventListener('keyup', tableUi);
  ed.addEventListener('pointerup', () => setTimeout(tableUi, 0));

  // Seret di roda: sudut = hue, jarak dari tengah = saturasi.
  const pickWheel = (e) => {
    const r = wheel.getBoundingClientRect(), R = r.width / 2;
    const dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R);
    hsv.h = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360; hsv.s = Math.min(1, Math.hypot(dx, dy) / R);
    moveMark(); updSlider(); setCol(hsvToHex(hsv.h, hsv.s, hsv.v), false, true);
  };
  let wdrag = false;
  wheel.addEventListener('pointerdown', (e) => { e.preventDefault(); wdrag = true; try { wheel.setPointerCapture(e.pointerId); } catch (err) { console.error('setPointerCapture gagal:', err); } pickWheel(e); });
  wheel.addEventListener('pointermove', (e) => { if (wdrag) { e.preventDefault(); pickWheel(e); } });
  const wend = () => { if (!wdrag) return; wdrag = false; if (n.col) { data.settings.recent = addRecent(data.settings.recent, n.col); recUi(); } };
  wheel.addEventListener('pointerup', wend); wheel.addEventListener('pointercancel', wend);
  vsl.addEventListener('input', () => { hsv.v = Number(vsl.value) / 100; drawWheel(); moveMark(); updSlider(); setCol(hsvToHex(hsv.h, hsv.s, hsv.v), false, true); });
  vsl.addEventListener('change', () => { if (n.col) { data.settings.recent = addRecent(data.settings.recent, n.col); recUi(); } });

  // Garis bawah (perbaikan Rev 27B): dibungkus sendiri dengan <u> per potongan teks terblok (tidak bergantung execCommand('underline'),
  // yang di HP pengguna tidak memberi garis). Mengembalikan false bila tidak bisa ditangani (mis. tanpa blok teks) agar jatuh ke execCommand.
  const underlineSel = () => {
    try {
      const sl = getSelection(); if (!sl.rangeCount) return false;
      const r = sl.getRangeAt(0); if (r.collapsed || !ed.contains(r.commonAncestorContainer)) return false;
      let sc = r.startContainer, ec = r.endContainer; const so = r.startOffset, eo = r.endOffset;
      if (sc.nodeType !== 3 || ec.nodeType !== 3) return false;
      if (eo < ec.length) ec.splitText(eo);
      if (so > 0) { const nw = sc.splitText(so); if (sc === ec) ec = nw; sc = nw; }
      const nodes = []; const w = document.createTreeWalker(ed, NodeFilter.SHOW_TEXT); let on = false, nd;
      while ((nd = w.nextNode())) { if (nd === sc) on = true; if (on && nd.length) nodes.push(nd); if (nd === ec) break; }
      if (!nodes.length) return false;
      const inU = (x) => { const u = x.parentElement && x.parentElement.closest('u'); return u && ed.contains(u) ? u : null; };
      if (nodes.every((x) => inU(x))) {
        const us = [...new Set(nodes.map(inU))];
        const set = new Set(nodes);
        if (!us.every((u) => { const t = document.createTreeWalker(u, NodeFilter.SHOW_TEXT); let q; while ((q = t.nextNode())) if (q.length && !set.has(q)) return false; return true; })) return false; // sebagian saja: biar execCommand yang menangani
        for (const u of us) { while (u.firstChild) u.parentNode.insertBefore(u.firstChild, u); u.remove(); }
      } else {
        for (const x of nodes) { if (inU(x)) continue; const u = document.createElement('u'); x.parentNode.insertBefore(u, x); u.appendChild(x); }
      }
      const nr = document.createRange(); nr.setStart(nodes[0], 0); nr.setEnd(nodes[nodes.length - 1], nodes[nodes.length - 1].length);
      sl.removeAllRanges(); sl.addRange(nr); rng = nr.cloneRange();
      return true;
    } catch (err) { console.error('garis bawah gagal:', err); return false; }
  };
  const bind = (el, fn) => {
    el.addEventListener('mousedown', (e) => e.preventDefault());
    el.addEventListener('touchstart', (e) => e.preventDefault(), { passive: false });
    // Aksi dijalankan saat jari MENYENTUH (pointerdown), bukan saat dilepas: pada pointerup, Android sering
    // membatalkan sentuhan (pointercancel) ketika ada blok teks aktif, sehingga tombol terasa "susah ditekan".
    el.addEventListener('pointerdown', (e) => { const b = e.target.closest('button'); if (!b) return; snap(); fn(b); });
  };
  // Rev 30b: bilah Langit bisa digeser ke samping. Tombol Undo/Bintang/Redo tetap bereaksi saat disentuh;
  // tombol format baru bereaksi saat jari diangkat DAN tidak bergeser (geser = menggulir bilah, bukan menekan tombol).
  // Gulir dibuat sendiri (touchstart tetap di-preventDefault supaya blok teks tidak lepas), lengkap dengan luncuran kecil.
  // Rev 360 / H2: kapsul "Tulis AI" di atas ✦ (di dalam .dock). Ketuk = openWriteAI() yang sama; tutup: ketuk di luar, 4 detik, ketuk bilah.
  let aiChip = null, aiChipT = 0;
  const hideAiChip = () => { clearTimeout(aiChipT); if (aiChip) { aiChip.remove(); aiChip = null; } };
  const showAiChip = () => {
    if (isP || editorMode !== 'edit' || aiChip) return;
    try { if (navigator.vibrate) navigator.vibrate(10); } catch (_) { /* getar hanya bonus */ }
    const dock = bar.parentElement, br = starBtn.getBoundingClientRect(), dr = dock.getBoundingClientRect();
    aiChip = h('button', { type: 'button', class: 'aichip', 'aria-label': 'Tulis AI' }, insertIcon('ai'), 'Tulis AI');
    aiChip.style.left = Math.max(6, Math.min(br.left - dr.left + br.width / 2 - 55, dr.width - 116)) + 'px';
    aiChip.addEventListener('mousedown', (e) => e.preventDefault());
    aiChip.addEventListener('touchstart', (e) => e.preventDefault(), { passive: false });
    aiChip.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); hideAiChip(); openWriteAI(); });
    dock.append(aiChip); aiChipT = setTimeout(hideAiChip, 4000);
  };
  ed.addEventListener('pointerdown', hideAiChip);
  const bindBar = (fn) => {
    bar.addEventListener('mousedown', (e) => e.preventDefault());
    bar.addEventListener('touchstart', (e) => e.preventDefault(), { passive: false });
    let st = null, raf = 0;
    const fire = (b) => { snap(); fn(b); };
    // Rev 360 / H1: di catatan biasa, TAHAN ✦ (~450 ms) memunculkan kapsul Tulis AI; ketuk biasa bereaksi saat jari diangkat. Undo/Redo tetap saat disentuh.
    let sh = null;
    const shEnd = (e, tap) => { if (!sh || e.pointerId !== sh.id) return; const s1 = sh; sh = null; clearTimeout(s1.t); if (tap && !s1.done) fire(starBtn); };
    bar.addEventListener('pointermove', (e) => { if (sh && e.pointerId === sh.id && Math.hypot(e.clientX - sh.x, e.clientY - sh.y) > 8) shEnd(e, false); });
    bar.addEventListener('pointerup', (e) => shEnd(e, true));
    bar.addEventListener('pointercancel', (e) => shEnd(e, false));
    bar.addEventListener('contextmenu', (e) => e.preventDefault());
    bar.addEventListener('pointerdown', (e) => {
      cancelAnimationFrame(raf); raf = 0; hideAiChip();
      const b = e.target.closest('button');
      if (b === starBtn && !isP) { snap(); sh = { id: e.pointerId, x: e.clientX, y: e.clientY, done: false, t: setTimeout(() => { if (sh) { sh.done = true; showAiChip(); } }, 450) }; return; }
      if (b && !b.classList.contains('fmt')) { st = null; fire(b); return; }
      if (b) snap();
      st = { id: e.pointerId, x: e.clientX, left: bar.scrollLeft, b, drag: false, pts: [{ x: e.clientX, t: e.timeStamp }] };
      try { bar.setPointerCapture(e.pointerId); } catch (_) {}
    });
    bar.addEventListener('pointermove', (e) => {
      if (!st || e.pointerId !== st.id) return;
      const dx = e.clientX - st.x;
      if (!st.drag && Math.abs(dx) > 8) { st.drag = true; }
      if (!st.drag) return;
      bar.scrollLeft = st.left - dx;
      st.pts.push({ x: e.clientX, t: e.timeStamp });
      while (st.pts.length > 2 && e.timeStamp - st.pts[0].t > 100) st.pts.shift();
    });
    const end = (e) => {
      if (!st || e.pointerId !== st.id) return;
      const s0 = st; st = null;
      try { bar.releasePointerCapture(e.pointerId); } catch (_) {}
      if (s0.drag) {
        // Luncuran halus berbasis waktu (bukan per-frame): kecepatan px/ms dari 100 ms terakhir, meredam eksponensial.
        const p0 = s0.pts[0], p1 = s0.pts[s0.pts.length - 1];
        let v = e.timeStamp - p1.t > 80 || p1.t === p0.t ? 0 : (p0.x - p1.x) / (p1.t - p0.t);
        if (Math.abs(v) < 0.05) return;
        let last = 0;
        const step = (t) => {
          const dt = last ? Math.min(34, t - last) : 16; last = t;
          const before = bar.scrollLeft; bar.scrollLeft = before + v * dt;
          v *= Math.exp(-dt / 240);
          if (Math.abs(v) < 0.02 || bar.scrollLeft === before) { raf = 0; return; }
          raf = requestAnimationFrame(step);
        };
        raf = requestAnimationFrame(step);
        return;
      }
      if (s0.b) fire(s0.b);
    };
    bar.addEventListener('pointerup', end);
    bar.addEventListener('pointercancel', end);
  };
  const refreshImages = () => { if (stopImageObserver) stopImageObserver(); if (isP) return; try { stopImageObserver = hydrateImages(ed, imageFS(), imageUrls, () => {}); } catch (_) { try { markImagesUnavailable(ed); } catch (_e) {} } };
  const insertImages = async (files) => {
    if (isP || !alive || imageBusy || !files.length) return;
    const refs = G.parseRefs(ed.innerHTML), cap = G.canAddImages(refs.length, files.length);
    if (!cap.ok) { infoKey('maks', 'gambar di catatan ini', 10, 'Hapus gambar yang tidak dipakai, lalu tambah lagi.'); return; }
    const chosen = files.slice(0, cap.allowed); if (cap.msg) toast(cap.msg);
    imageBusy = true; const btn = bar.querySelector('[data-cmd="insert-image"]'); if (btn) btn.disabled = true;
    let FS, added = 0;
    try {
      FS = imageFS();
      const sel = getSelection(); let range = imageInsertRange ? imageInsertRange.cloneRange() : (sel && sel.rangeCount && ed.contains(sel.anchorNode) ? sel.getRangeAt(0).cloneRange() : null);
      flushHist();
      for (let i = 0; i < chosen.length; i++) {
        if (!alive) break;
        toast('Memproses ' + (i + 1) + ' dari ' + chosen.length);
        const packed = await compressImage(chosen[i], data.settings.imageQuality || G.DEFAULT_PRESET); // Rev 60: kualitas dari Setelan > Gambar (hanya gambar baru)
        if (!alive) break;
        const ref = { id: G.newImageId(), w: packed.w, h: packed.h, b: packed.b, x: packed.x };
        await writeImage(FS, ref, packed.blob);
        if (!alive) break;
        const html = G.buildFigure(ref); if (!html) throw new Error('Rujukan gambar tidak valid.');
        const temp = document.createElement('template'); temp.innerHTML = html;
        const fig = temp.content.firstElementChild, spacer = fig.nextElementSibling;
        if (!range || !ed.contains(range.startContainer)) { range = document.createRange(); range.selectNodeContents(ed); range.collapse(false); }
        range.deleteContents(); range.insertNode(spacer); range.insertNode(fig);
        range = document.createRange(); range.setStartAfter(spacer); range.collapse(true);
        sel.removeAllRanges(); sel.addRange(range); rng = range.cloneRange(); added++;
      }
      if (alive) { flushHist(); auto(); refreshImages(); if (added) toast(added + ' gambar ditambahkan'); }
      const usage = G.usageOf(G.refsOfData(data)); if (usage.bytes > G.WARN_TOTAL_BYTES) toast('Penyimpanan gambar sudah melewati 200 MB. Pertimbangkan ekspor cadangan.', 0, 0, undefined, 'warn');
    } catch (e) {
      if (alive && added) { flushHist(); auto(); refreshImages(); }
      infoKey('gbrGagal', added);
    }
    finally { imageBusy = false; if (btn) btn.disabled = false; imageInput.value = ''; }
  };
  imageInput.addEventListener('change', () => insertImages([...(imageInput.files || [])]));
  // Rev 46: ketuk gambar (mode Edit) memilihnya dan memunculkan alat ukuran. TIDAK lagi menghapus.
  // Rev 60 (G4): penampil layar penuh. Mode Baca: ketuk gambar langsung membukanya. Mode Edit: ketuk = pilih, lalu tombol "Lihat" di bar gambar.
  const viewImage = (fig) => {
    const figs = [...ed.querySelectorAll('figure.ki[data-kimg]')];
    const items = figs.map((f) => ({ id: f.dataset.kimg, x: f.dataset.x || 'webp', w: Number(f.dataset.w) || 1, h: Number(f.dataset.h) || 1 }));
    const at = Math.max(0, figs.indexOf(fig));
    try { openViewer({ items, index: at, load: (r) => readImageBlob(imageFS(), r) }); } catch (_) { tWarn('Gambar tidak bisa dibuka.'); }
  };
  ed.addEventListener('click', (e) => {
    const fig = e.target.closest && e.target.closest('figure.ki'); if (!fig || isP) return;
    if (editorMode !== 'edit') { e.preventDefault(); if (fig.dataset.loaded === '1' || fig.querySelector('img')) viewImage(fig); return; }
    e.preventDefault(); selectImage(fig);
  });
  tapBtn(imgView, (fig) => viewImage(fig), true); // tetap bisa dipakai pada gambar terkunci
  ed.addEventListener('pointerdown', (e) => { if (imgSel && !(e.target.closest && e.target.closest('figure.ki'))) clearImgSel(); });
  // Rev 122 / U7b-1: ketuk pulau lembar kerja = buka layar penuh (juga di mode Baca); "Hapus dari catatan" hanya melepas pulau (satu langkah Urungkan).
  ed.addEventListener('click', (e) => {
    const blk = e.target.closest && e.target.closest('.ksheet'); if (!blk || !ed.contains(blk)) return;
    e.preventDefault();
    if (e.target.closest('.ks-del')) {
      if (o.classList.contains('ed-baca')) return;
      flushHist(); blk.remove(); if (!ed.children.length) { const p = document.createElement('p'); p.append(document.createElement('br')); ed.append(p); }
      flushHist(); auto(); tOk('Dilepas dari catatan. Lembar kerjanya masih ada di Setelan > Lembar kerja.'); return;
    }
    openIsland(blk);
  });
  ed.addEventListener('keydown', (e) => { const blk = e.target.closest && e.target.closest('.ksheet'); if (!blk || !['Enter', ' '].includes(e.key)) return; e.preventDefault(); openIsland(blk); });
  // Rev 89: ketuk kartu Hitung mundur = baris alat (Ubah / Hapus) seperti Tanggal/Waktu, bukan langsung dialog ubah.
  ed.addEventListener('keydown', (e) => {
    const card = e.target.closest && e.target.closest('.kb-countdown-block');
    if (!card || !['Enter', ' '].includes(e.key)) return;
    e.preventDefault(); e.stopImmediatePropagation(); kbTools(card);
  });

  // Kontrol blok Suasana hati: ketukan diproses saat jari diangkat dan fokus/seleksi editor tidak ikut berpindah,
  // jadi satu ketukan cukup (tidak perlu ditahan). DUGAAN penyebab "harus ditahan" di Rev C: ketukan ditelan seleksi/fokus editor.
  const moodTarget = (e) => (e.target && e.target.closest ? e.target.closest('.mood-menu,.mood-face,.mood-tools,.kb-date-block,.kb-time-block,.kb-countdown-block,.lk-card') : null);
  // Rev 89: ketuk blok Tanggal/Waktu = baris alat (Kecil/Normal/Besar/Hapus) tepat di bawah blok; ketuk lagi = tutup.
  // Baris alat berada di luar blok dan bertanda data-kb-tool, jadi dibuang saat simpan/cadangan/ekspor (stripBlockTools).
  const kbTools = (blk) => {
    if (o.classList.contains('ed-baca')) return; // mode Baca: blok tidak bisa diubah
    const open = blk.nextElementSibling && blk.nextElementSibling.classList.contains('kb-tools');
    closeMoodTools();
    if (open) return;
    const tools = document.createElement('div'); tools.className = 'mood-tools kb-tools'; tools.contentEditable = 'false'; tools.setAttribute('data-kb-tool', '');
    const isCd = blk.classList.contains('kb-countdown-block');
    const cur = /^(small|large)$/.test(blk.dataset.kbSize || '') ? blk.dataset.kbSize : 'normal';
    (isCd ? (isP ? [['edit', 'Ubah'], ['delete', 'Hapus']] : [['edit', 'Ubah'], ['remind', cdChipText(blk)], ['delete', 'Hapus']]) : [['small', 'Kecil'], ['normal', 'Normal'], ['large', 'Besar'], ['delete', 'Hapus']]).forEach(([v, label]) => {
      const b = document.createElement('button'); b.type = 'button'; b.dataset.act = v; b.textContent = label;
      if (!isCd && v === cur) b.classList.add('on'); if (v === 'delete') b.classList.add('del');
      b.addEventListener('click', (ev) => {
        ev.preventDefault(); ev.stopPropagation();
        closeMoodTools();
        if (v === 'edit') { openCountdownEditor(blk); return; }
        if (v === 'remind') { openCdRemindSheet(blk); return; }
        flushHist();
        if (v === 'delete') { blk.remove(); if (!ed.children.length) { const p = document.createElement('p'); p.append(document.createElement('br')); ed.append(p); } }
        else blk.dataset.kbSize = v;
        flushHist(); auto();
      });
      tools.append(b);
    });
    blk.after(tools);
  };
  ed.addEventListener('pointerdown', (e) => { if (moodTarget(e)) e.preventDefault(); });
  ed.addEventListener('mousedown', (e) => { if (moodTarget(e)) e.preventDefault(); });
  ed.addEventListener('click', (e) => {
    const lkc = e.target.closest('.lk-card'); // Rev 324 / L3: ketuk kartu tautan (mode Edit, bukan panahnya) = bilah kartu; modul dimuat malas
    if (lkc && !o.classList.contains('ed-baca') && !e.target.closest('.lk-go')) { e.preventDefault(); import('./linkcard-ui.js').then((m) => m.toggleCardTools(lkc, { ed, flush: flushHist, save: auto, close: closeMoodTools }), () => {}); return; }
    const kbBlock = e.target.closest('.kb-date-block,.kb-time-block,.kb-countdown-block');
    if (kbBlock) { e.preventDefault(); kbTools(kbBlock); return; }
    const block = e.target.closest('.mood-block');
    if (!block) { if (!e.target.closest('.kb-tools')) closeMoodTools(); return; }
    if (o.classList.contains('ed-baca')) return; // mode Baca: blok tidak bisa diubah
    const face = e.target.closest('.mood-face');
    if (face && face.parentElement.classList.contains('mood-faces')) {
      e.preventDefault(); closeMoodTools(); flushHist();
      block.dataset.moodValue = String(Number(face.dataset.moodValue)); syncMood(block);
      flushHist(); auto(); return;
    }
    const tool = e.target.closest('.mood-tools button');
    if (tool) {
      e.preventDefault(); flushHist();
      if (tool.dataset.act === 'delete') block.remove(); else block.dataset.moodSize = tool.dataset.act;
      closeMoodTools(); flushHist(); auto(); return;
    }
    if (e.target.closest('[data-mood-action="menu"]')) {
      e.preventDefault();
      if (block.querySelector('.mood-tools')) { closeMoodTools(); return; }
      closeMoodTools();
      const tools = document.createElement('div'); tools.className = 'mood-tools'; tools.contentEditable = 'false';
      const cur = block.dataset.moodSize;
      [['small', 'Kecil'], ['normal', 'Normal'], ['large', 'Besar'], ['delete', 'Hapus']].forEach(([v, label]) => {
        const b = document.createElement('button'); b.type = 'button'; b.dataset.act = v; b.textContent = label;
        if (v === cur) b.classList.add('on'); if (v === 'delete') b.classList.add('del'); tools.append(b);
      });
      block.querySelector('.mood-head').after(tools); // baris di dalam alur (bukan melayang), jadi tidak menutupi wajah
    }
  });
  o.addEventListener('pointerdown', (e) => { if (!e.target.closest || !e.target.closest('.mood-block,.kb-date-block,.kb-time-block,.kb-countdown-block,.kb-tools,.lk-card')) closeMoodTools(); }, true);
  const runInsert = (kind) => {
    closePanels();
    if (kind === 'mood') insertMood();
    else if (kind === 'date') insertDate();
    else if (kind === 'time') insertTime();
    else if (kind === 'countdown') openCountdownEditor();
    else if (kind === 'quote') toggleQuote();
    else if (kind === 'fold') insertFold();
    else if (kind === 'table') openTableDialog();
    else if (kind === 'link') openLinkDialog();
    else if (kind === 'sheet' && !isP) insertSheet();
    else if (kind === 'ai' && !isP) openWriteAI();
    else if (kind === 'ocr' && !isP) openOcr();
    else if (kind === 'image' && !isP) { imageInsertRange = caretRange(); imageInput.click(); }
  };
  bindBar((b) => {
    if (b.dataset.insert) { runInsert(b.dataset.insert); return; }
    if (b.dataset.pal) {
      if (cp.style.display === 'block') closeCp();
      closeLp();
      if (pm) { pm = false; pal.replaceChildren(); return; }
      pm = true;
      pal.replaceChildren(...TCOL.map((c) => { const x = h('button', { type: 'button', 'data-cmd': 'col', 'data-v': c, 'aria-label': 'Warna teks ' + c }); x.style.background = c; return x; }),
        h('button', { type: 'button', 'data-cmd': 'removeFormat', 'aria-label': 'Reset format' }, 'Reset'));
      return;
    }
    const c = b.dataset.cmd; if (!c) return;
    if (c === 'star') { setFmt(!bar.classList.contains('open')); return; }
    if (c === 'font-size') { toggleFs(); return; }
    if (c === 'undo') { doUndo(); return; }
    if (c === 'redo') { doRedo(); return; }
    const selectedNode = getSelection().anchorNode;
    const selectedEl = selectedNode && (selectedNode.nodeType === 1 ? selectedNode : selectedNode.parentElement);
    const inTableCell = selectedEl && ed.contains(selectedEl) && selectedEl.closest('td,th');
    if (inTableCell && ['todo', 'insertUnorderedList', 'insertOrderedList'].includes(c)) { infoKey('dlmTabel', 'Daftar dan kotak centang'); return; }
    flushHist(); // catat keadaan sebelum diubah tombol format
    if (c === 'todo' && rng) rng.collapse(false);
    restore();
    if (c === 'formatBlock' && b.dataset.value === 'blockquote') {
      document.execCommand('formatBlock', false, 'blockquote');
    } else if (c === 'todo') {
      const sel = getSelection(); const at = sel.rangeCount ? sel.getRangeAt(0).endContainer : ed;
      const row = insertTodo(ed, ed.contains(at) ? at : ed);
      const r = document.createRange(); r.selectNodeContents(row); r.collapse(false); sel.removeAllRanges(); sel.addRange(r);
    } else if (c === 'underline' && underlineSel()) { /* ditangani sendiri */ } else document.execCommand(c);
    if (c === 'todo') rng = null; else reSel();
    flushHist(); upd(); auto();
  });
  bind(pal, (b) => {
    restore();
    flushHist();
    if (b.dataset.cmd === 'col') document.execCommand('foreColor', false, b.dataset.v); else document.execCommand('removeFormat');
    reSel(); flushHist(); upd(); auto();
  });

  tt.addEventListener('input', auto);
  if (!isP) { remAt.addEventListener('change', () => { remUi(); auto(); }); remRepeat.addEventListener('change', auto); }
  tt.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); ed.focus(); } });
  // Rev 47: gambar terkunci tidak boleh hilang lewat Backspace/Hapus/potong. Bila hilang, keadaan terakhir yang sah dipulihkan.
  const lockedIds = (html) => { const m = String(html).match(/<figure\b[^>]*>/g) || []; return m.filter((x) => /\bdata-l="1"/.test(x)).map((x) => (x.match(/data-kimg="([A-Za-z0-9]+)"/) || [])[1]).filter(Boolean); };
  ed.addEventListener('input', () => { // Rev 99 / U4d: sel diedit = hitung ulang baris Total tabel itu
    try {
      const sl = getSelection(), nd = sl && sl.rangeCount ? sl.anchorNode : null, el = nd && (nd.nodeType === 1 ? nd : nd.parentElement), tb = el && ed.contains(el) ? el.closest('table') : null;
      if (tb && tb.querySelector('tr.tt')) refreshTotals(tb);
    } catch (_) {}
  });
  ed.addEventListener('input', () => {
    if (!isP && okHtml) {
      const want = lockedIds(okHtml);
      if (want.length) { const now = lockedIds(ed.innerHTML); if (want.some((id) => !now.includes(id))) { ed.innerHTML = sanitize(okHtml); rng = null; refreshImages(); clearImgSel(); infoKey('gbrKunci', 'dihapus'); return; } }
    }
    okHtml = ed.innerHTML;
  });
  // Rev 108: Enter / Backspace / Delete di baris kotak centang ditangani sendiri (bukan bawaan Chrome yang menyalin <div class="todo"> tanpa kotak).
  // Enter = baris centang baru (belum dicentang, tanpa pengingat) di bawahnya; Enter di baris kosong = keluar dari daftar centang;
  // Backspace di awal teks = jadi baris biasa (kotak dibuang); Delete di akhir baris = gabung dengan baris centang berikutnya.
  // Saat IME sedang menyusun kata semuanya dilewati; sisanya dipulihkan oleh healTodos setelah event input.
  let composing = false;
  ed.addEventListener('compositionstart', () => { composing = true; });
  ed.addEventListener('compositionend', () => { composing = false; });
  const setCaretAt = (node, off) => { const sl = getSelection(); const r = document.createRange(); r.setStart(node, off); r.collapse(true); sl.removeAllRanges(); sl.addRange(r); };
  const caretAtPlainStart = (row) => { let c = row.firstChild; while (c && c.nodeType === 1 && c.tagName !== 'BR' && c.firstChild) c = c.firstChild; if (c && c.nodeType === 3) setCaretAt(c, 0); else setCaretAt(row, 0); };
  const textBetween = (fromNode, fromOff, toNode, toOff) => { const r = document.createRange(); r.setStart(fromNode, fromOff); r.setEnd(toNode, toOff); return r.toString().replace(/[\s\u00a0\u200b]/g, ''); };
  // Rev 109 / U6a: Enter di judul bagian lipat = buka dan pindah ke isi pertama (Enter di isi, Backspace, Delete = U6c).
  ed.addEventListener('beforeinput', (e) => {
    if (o.classList.contains('ed-baca') || e.isComposing || composing) return;
    if (e.inputType !== 'insertParagraph' && e.inputType !== 'insertLineBreak') return;
    const sl = getSelection(); if (!sl || !sl.rangeCount || !sl.isCollapsed) return;
    const fh = headOf(sl.anchorNode, ed); if (!fh) return;
    e.preventDefault(); flushHist();
    const first = openToBody(fh.parentElement, document);
    const r = document.createRange(); r.selectNodeContents(first); r.collapse(true); sl.removeAllRanges(); sl.addRange(r); rng = null;
    ed.dispatchEvent(new Event('input', { bubbles: true }));
  });
  ed.addEventListener('beforeinput', (e) => {
    if (o.classList.contains('ed-baca') || e.isComposing || composing) return;
    const t = e.inputType;
    const isEnter = t === 'insertParagraph' || t === 'insertLineBreak';
    const isBack = t === 'deleteContentBackward' || t === 'deleteWordBackward' || t === 'deleteSoftLineBackward';
    const isFwd = t === 'deleteContentForward';
    if (!isEnter && !isBack && !isFwd) return;
    const sl = getSelection(); if (!sl || !sl.rangeCount || !sl.isCollapsed) return;
    const nd = sl.anchorNode; if (!nd || !ed.contains(nd)) return;
    const el = nd.nodeType === 1 ? nd : nd.parentElement; const row = el && el.closest ? el.closest('.todo') : null;
    if (!row || row === ed || !ed.contains(row) || !boxOf(row)) return; // baris yatim ditangani healTodos
    const off = sl.anchorOffset;
    const fire = () => { rng = null; ed.dispatchEvent(new Event('input', { bubbles: true })); };
    if (isEnter) {
      e.preventDefault();
      if (isTodoBlank(row)) { todoToPlain(row, document); caretAtPlainStart(row); fire(); return; } // Enter di baris kosong = selesai daftar
      const hasBefore = textBetween(row, 0, nd, off).length > 0;
      if (!hasBefore) { row.before(newTodoRow(document)); fire(); return; } // kursor di awal teks: baris kosong baru di ATAS, teks tidak ikut pindah
      const tail = document.createRange(); tail.setStart(nd, off); tail.setEndAfter(row.lastChild);
      const frag = tail.extractContents();
      const nr = newTodoRow(document);
      if (frag.childNodes.length && !isTodoBlank({ firstChild: frag.firstChild })) nr.append(frag);
      const cb = boxOf(row); if (cb && isTodoBlank(row) && !(cb.nextSibling && cb.nextSibling.nodeType === 3)) row.append('\u00a0');
      row.after(nr);
      const tg = caretAfterBox(nr); if (tg) setCaretAt(tg.node, tg.offset);
      try { nr.scrollIntoView({ block: 'nearest' }); } catch (_) {}
      fire(); return;
    }
    if (isBack) {
      if (textBetween(row, 0, nd, off).length > 0) return; // ada teks di kiri kursor: hapus huruf seperti biasa
      e.preventDefault(); todoToPlain(row, document); caretAtPlainStart(row); fire(); return;
    }
    if (isFwd) {
      const endR = document.createRange(); endR.setStart(nd, off); endR.setEndAfter(row.lastChild);
      if (endR.toString().replace(/[\s\u00a0\u200b]/g, '').length) return;
      const nx = row.nextElementSibling; if (!nx || !nx.classList.contains('todo') || !boxOf(nx)) return;
      e.preventDefault(); mergeNextTodo(row, nx); try { setCaretAt(nd, off); } catch (_) {} fire();
    }
  });
  // Rev 111 / U6c: Enter / Backspace / Delete lengkap di bagian lipat (pola sama dengan kotak centang; IME dilewati; dipasang SESUDAH pengendali
  // kotak centang dan Enter-di-judul U6a, jadi yang sudah ditangani mereka (defaultPrevented) dilewati).
  // Judul: Backspace di awal = bagian lipat jadi paragraf (isi ikut keluar); Delete di akhir = isi pertama digabung ke judul.
  // Isi: Enter di baris kosong TERAKHIR = keluar ke paragraf sesudah bagian lipat; Backspace di awal isi pertama = kursor ke akhir judul.
  // Pengaman data: Backspace di awal paragraf tepat sesudah bagian lipat TERTUTUP dan Delete di akhir judul bagian lipat tertutup
  // ditahan (bawaan Chromium menghapus isi tersembunyi); kursor dipindah ke akhir judul.
  ed.addEventListener('beforeinput', (e) => {
    if (e.defaultPrevented || o.classList.contains('ed-baca') || e.isComposing || composing) return;
    const t = e.inputType;
    const isEnter = t === 'insertParagraph' || t === 'insertLineBreak';
    const isBack = t === 'deleteContentBackward' || t === 'deleteWordBackward' || t === 'deleteSoftLineBackward';
    const isFwd = t === 'deleteContentForward';
    if (!isEnter && !isBack && !isFwd) return;
    const sl = getSelection(); if (!sl || !sl.rangeCount || !sl.isCollapsed) return;
    const nd = sl.anchorNode; if (!nd || !ed.contains(nd)) return;
    const off = sl.anchorOffset;
    const apply = (c) => { // kursor dulu, lalu simpan satu langkah Undo tersendiri
      if (c) { try { setCaretAt(c.node, c.offset); } catch (_) {} }
      rng = null; ed.dispatchEvent(new Event('input', { bubbles: true })); flushHist();
    };
    const toHeadEnd = (fold) => { const hd = foldHead(fold); if (hd) { const c = endOfHead(hd); setCaretAt(c.node, c.offset); rng = null; } };
    const fh = headOf(nd, ed);
    if (fh) {
      const fold = fh.parentElement;
      if (isBack && !textBetween(fh, 0, nd, off).length) { e.preventDefault(); flushHist(); apply(unfoldToParagraph(fold, document)); return; }
      if (isFwd) {
        const endR = document.createRange(); endR.setStart(nd, off); endR.setEnd(fh, fh.childNodes.length);
        if (endR.toString().replace(/[\s\u00a0\u200b]/g, '').length) return; // masih ada teks di kanan kursor: hapus huruf seperti biasa
        e.preventDefault(); flushHist();
        const c = mergeFirstRowIntoHead(fold, document);
        if (c) apply(c);
      }
      return;
    }
    const br = bodyRowOf(nd, ed);
    if (br) {
      if (!isPlainRow(br.row)) return; // kotak centang/daftar/kutipan punya aturan sendiri
      if (isEnter && isBlankBlock(br.row) && br.row === br.fb.lastElementChild) {
        e.preventDefault(); flushHist();
        const c = exitFoldFromBody(br.fold, br.row, document);
        if (c) { apply(c); try { c.node.scrollIntoView({ block: 'nearest' }); } catch (_) {} }
        return;
      }
      if (isBack && br.row === br.fb.firstElementChild && !textBetween(br.row, 0, nd, off).length) {
        e.preventDefault(); toHeadEnd(br.fold);
      }
      return;
    }
    if (isBack) { // blok biasa tepat sesudah bagian lipat tertutup
      let blk = nd; while (blk && blk.parentNode !== ed) blk = blk.parentNode;
      const pv = blk && blk.nodeType === 1 ? blk.previousElementSibling : null;
      if (pv && isFold(pv) && !isFoldOpen(pv) && isPlainRow(blk) && !textBetween(blk, 0, nd, off).length) {
        e.preventDefault(); toHeadEnd(pv);
      }
    }
  });
  ed.addEventListener('input', () => { healTodos(); if (!ed.innerText.trim() && !ed.querySelector('input,li')) ed.innerHTML = ''; markHist(); auto(); });
  if (!isP) { // Rev 337 / I4 + Rev 338 / I3 + Rev 339 / I7: hitung cepat `12*3=`, label cepat `#kerja `, format otomatis `[] ` / `1. ` / `- `; modul tampilan dimuat MALAS sesudah ketikan pemicu pertama (bukan di Catatan Privat, bukan mode Baca)
    let kt = null, ktLoad = false;
    const findLabel = (t) => labelsAll.find((l) => l.name.toLowerCase() === t.toLowerCase());
    const tags = {
      state: (t) => { const l = findLabel(t); return !l ? 'new' : (n.labels || []).includes(l.id) ? 'on' : 'has'; },
      apply: (t) => {
        const ex = findLabel(t);
        if (ex) { if ((n.labels || []).includes(ex.id)) return { ok: true, msg: 'Label \u201c' + ex.name + '\u201d sudah terpasang.' }; n.labels = toggleId(n.labels, ex.id); labUi(); auto(); return { ok: true, msg: 'Label \u201c' + ex.name + '\u201d dipasang.', undo: () => { n.labels = (n.labels || []).filter((x) => x !== ex.id); labUi(); auto(); } }; }
        const v = validateLabel(t, labelsAll); if (!v.ok) return { ok: false, msg: v.msg };
        const l = { id: newId(), name: v.value }; labelsAll.push(l); n.labels = toggleId(n.labels, l.id); labUi(); auto();
        return { ok: true, msg: 'Label baru \u201c' + l.name + '\u201d dibuat dan dipasang.', undo: () => { removeLabel(data, l.id); labelsAll = data.settings.labels; n.labels = (n.labels || []).filter((x) => x !== l.id); ctx.persist(); labUi(); auto(); } };
      },
    };
    // Rev 340 / I6: menu cepat `/`. Perintahnya SAMA dengan tombol bilah Langit (tidak ada jalur sisip baru); `Judul` belum ada di aplikasi, jadi tidak ditawarkan.
    const remind = { open: (row, at) => { if (row && row.isConnected && ed.contains(row)) openRemindSheet(row, at); } }; // Rev 341 / I8: hanya baris kotak centang (pengingat per baris, Rev 21/102)
    const wiki = { notes: () => data.notes, selfId: n.id, done: (id) => { const r = toggleLink(n, id); if (r.ok && r.on) { n.links = r.ids; relUi(); } auto(); } }; // I2: hubungan Rev 18 ikut dipasang
    const SLASH_IDS = ['bullet', 'numbered', 'todo', 'table', 'quote', 'date', 'mood', 'countdown', 'sheet'];
    const slash = {
      has: (id) => SLASH_IDS.includes(id),
      run: (id) => {
        if (!SLASH_IDS.includes(id)) return;
        rng = caretRange();
        if (id === 'bullet' || id === 'numbered') { flushHist(); restore(); document.execCommand(id === 'bullet' ? 'insertUnorderedList' : 'insertOrderedList'); reSel(); flushHist(); upd(); auto(); }
        else if (id === 'todo') { flushHist(); restore(); const sel = getSelection(); const at = sel.rangeCount ? sel.getRangeAt(0).endContainer : ed; const row = insertTodo(ed, ed.contains(at) ? at : ed); const r = document.createRange(); r.selectNodeContents(row); r.collapse(false); sel.removeAllRanges(); sel.addRange(r); rng = null; flushHist(); upd(); auto(); }
        else runInsert(id); // quote, table, date, mood, countdown, sheet: jalur Sisipkan yang sama
      },
    };
    ed.addEventListener('input', (ev) => {
      if (kt || ktLoad || editorMode !== 'edit') return;
      const sl = getSelection(), nd = sl && sl.rangeCount ? sl.anchorNode : null;
      if (!nd || nd.nodeType !== 3) return;
      const c = nd.data[sl.anchorOffset - 1]; // gerbang murah: `=`, spasi sesudah `#` di simpul yang sama, spasi sesudah `[]` / `1.` (Rev 339 / I7) atau `-` di awal simpul (Rev 358), atau `/` di awal baris/sesudah spasi (Rev 340 / I6)
      const inTodoBang = nd.data.indexOf('!') >= 0 && !!(nd.parentElement && nd.parentElement.closest('.todo,li')); // Rev 341 / I8 + Rev 348 / R3: `!` di baris kotak centang atau item daftar
      const inWiki = c === '[' && nd.data[sl.anchorOffset - 2] === '['; // I2
      const inWa = /[*_][ \u00a0.,;:!?)]$/.test(nd.data.slice(0, sl.anchorOffset)) || c === '*' || c === '_'; // Rev 362 / W2: penutup `*`/`_` + karakter pemicu; Rev 364 / W4: `*`/`_` sendiri juga memuat modul (pemanasan, supaya Enter sesudah penutup tidak balapan dengan pemuatan)
      if (inTodoBang || inWiki || inWa) { /* muat modul */ } else if (c === '/' ? !(sl.anchorOffset < 2 || /[\s\u00a0]/.test(nd.data[sl.anchorOffset - 2])) : c !== '=' && !((c === ' ' || c === '\u00a0') && (nd.data.indexOf('#') >= 0 || /(\[\]|1\.|^-)[ \u00a0]$/.test(nd.data.slice(0, sl.anchorOffset))))) return;
      ktLoad = true;
      import('./ketik-ui.js').then((m) => { if (alive) { kt = m.pasangKetik({ ed, flushHist, tags, slash, remind, wiki }); if (kt) { kt.check(); if (!kt.format()) kt.wa(ev) || kt.wa(null, 'comp'); } } ktLoad = false; }, () => { ktLoad = false; });
    });
  }
  ed.addEventListener('change', (e) => { if (e.target.type === 'checkbox') { e.target.toggleAttribute('checked', e.target.checked); flushHist(); auto(); } });
  ed.addEventListener('paste', (e) => {
    e.preventDefault();
    const txt = (e.clipboardData || window.clipboardData).getData('text/plain');
    // Rev 416: teks bergaya Google Keep ("[ ] a" / "[X] b") yang ditempel di luar tabel jadi baris kotak centang sungguhan.
    const lines = txt.replace(/\r\n?/g, '\n').split('\n').map((l) => { const c = parseCheckLine(l); return c ? { todo: true, done: c.done, text: c.text } : { todo: false, text: l }; });
    const sel = getSelection(), at = sel.rangeCount ? sel.getRangeAt(0).endContainer : null;
    if (lines.some((l) => l.todo) && at && ed.contains(at) && !(at.nodeType === 1 ? at : at.parentElement).closest('td,th')) {
      flushHist();
      const last = insertTodoLines(ed, at, lines);
      if (last) { const r = document.createRange(); r.selectNodeContents(last); r.collapse(false); sel.removeAllRanges(); sel.addRange(r); }
      flushHist(); upd(); auto(); return;
    }
    document.execCommand('insertText', false, txt);
  });
  // Rev 416: geser urutan baris kotak centang lewat gagang (titik-titik) di kiri baris, gaya Google Keep. Gagang = ::before CSS (tidak ada di HTML tersimpan).
  // Sentuhan di gagang tidak menggulir halaman (touchstart dicegah); baris mengikuti jari, baris lain menyingkir, tepi atas/bawah menggulir otomatis.
  const GUT_W = 30;
  const gutHit = (p) => {
    if (o.classList.contains('ed-baca')) return null; // mode Baca = isi tidak berubah
    const row = p.target && p.target.closest ? p.target.closest('.todo') : null;
    if (!row || !ed.contains(row) || !boxOf(row)) return null;
    const r = row.getBoundingClientRect();
    return p.clientX >= r.left - 2 && p.clientX <= r.left + GUT_W ? row : null;
  };
  const scrollerOf = (el) => { for (let a = el.parentElement; a; a = a.parentElement) { const y = getComputedStyle(a).overflowY; if ((y === 'auto' || y === 'scroll') && a.scrollHeight > a.clientHeight) return a; } return document.scrollingElement; };
  let dg = null;
  const dgPlace = () => {
    const r = dg.row; r.style.transform = 'none';
    let nat = r.getBoundingClientRect(); const want = dg.y - dg.grab, mid = want + nat.height / 2;
    for (let p = r.previousElementSibling; p && p.classList.contains('todo'); p = r.previousElementSibling) { const b = p.getBoundingClientRect(); if (mid < b.top + b.height / 2) { r.parentNode.insertBefore(r, p); dg.moved = true; } else break; }
    for (let q = r.nextElementSibling; q && q.classList.contains('todo'); q = r.nextElementSibling) { const b = q.getBoundingClientRect(); if (mid > b.top + b.height / 2) { r.parentNode.insertBefore(r, q.nextSibling); dg.moved = true; } else break; }
    nat = r.getBoundingClientRect(); r.style.transform = 'translateY(' + Math.round(want - nat.top) + 'px)';
  };
  const dgEnd = () => {
    if (!dg) return; const d = dg; dg = null; clearInterval(d.tm);
    try { ed.releasePointerCapture(d.id); } catch (_) {}
    d.row.style.transition = 'transform .18s ease'; d.row.style.transform = 'translateY(0)';
    setTimeout(() => { d.row.classList.remove('kdrag'); d.row.style.transition = ''; d.row.style.transform = ''; }, 190);
    if (d.moved) { flushHist(); upd(); auto(); }
  };
  ed.addEventListener('touchstart', (e) => { if (e.touches.length === 1 && gutHit(e.touches[0])) e.preventDefault(); }, { passive: false });
  ed.addEventListener('pointerdown', (e) => {
    if (dg || (e.pointerType === 'mouse' && e.button !== 0)) return;
    const row = gutHit(e); if (!row) return;
    e.preventDefault(); flushHist();
    try { ed.setPointerCapture(e.pointerId); } catch (_) {}
    dg = { id: e.pointerId, row, grab: e.clientY - row.getBoundingClientRect().top, y: e.clientY, moved: false, tm: 0 };
    row.classList.add('kdrag');
    try { navigator.vibrate && navigator.vibrate(12); } catch (_) {}
    const sc = scrollerOf(ed);
    dg.tm = setInterval(() => { // gulir otomatis di dekat tepi layar
      if (!dg || !sc) return; const top = sc === document.scrollingElement ? 0 : sc.getBoundingClientRect().top, bot = sc === document.scrollingElement ? innerHeight : sc.getBoundingClientRect().bottom;
      const dy = dg.y < top + 70 ? -10 : dg.y > bot - 70 ? 10 : 0; if (dy) { sc.scrollTop += dy; dgPlace(); }
    }, 16);
  });
  ed.addEventListener('pointermove', (e) => { if (dg && e.pointerId === dg.id) { e.preventDefault(); dg.y = e.clientY; dgPlace(); } });
  ed.addEventListener('pointerup', (e) => { if (dg && e.pointerId === dg.id) dgEnd(); });
  ed.addEventListener('pointercancel', (e) => { if (dg && e.pointerId === dg.id) dgEnd(); });
  ed.addEventListener('pointerdown', () => {
    // Jangan buang Range yang sedang terblok: Android dapat mengirim pointerdown saat gagang seleksi disentuh.
    const sl = getSelection();
    if (!sl || sl.isCollapsed || !ed.contains(sl.anchorNode)) rng = null;
  });
  ed.addEventListener('keydown', (e) => {
    rng = null;
    if (e.key === 'Backspace' && !e.isComposing) {
      // Rev D: Backspace di awal kutipan melepas kutipan (kembali ke teks biasa).
      const sb = getSelection();
      if (sb && sb.rangeCount && sb.isCollapsed) {
        const qb = quoteOf(sb.anchorNode);
        if (qb) {
          const r0 = document.createRange(); r0.selectNodeContents(qb); r0.setEnd(sb.anchorNode, sb.anchorOffset);
          if (r0.toString() === '' && !r0.cloneContents().querySelector('img,figure,input,table')) { e.preventDefault(); unwrapQuote(qb); markHist(); auto(); return; }
        }
      }
    }
    // U1/Rev 65: Enter dua kali pada baris kosong di dalam kutipan mengakhiri kutipan.
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
    const sel = getSelection(); if (!sel || !sel.rangeCount || !sel.isCollapsed) return;
    const node = sel.anchorNode; const el = node && (node.nodeType === 1 ? node : node.parentElement);
    const quote = el && ed.contains(el) ? el.closest('blockquote') : null;
    if (!quote) return;
    // Rev D: closest('p,div') bisa menembus sampai kolom editor (juga <div>) sehingga kutipan kosong tidak pernah dianggap kosong; batasi ke dalam kutipan.
    let block = el.closest('p,div'); if (!block || !quote.contains(block)) block = quote;
    if (String(block.textContent || '').trim() || block.querySelector('img,figure,input,table')) return;
    e.preventDefault();
    const out = document.createElement('p'); out.innerHTML = '<br>';
    quote.after(out);
    // Kutipan kosong yang baru saja dibuat tidak ditinggalkan sebagai elemen kosong.
    if (!String(quote.textContent || '').trim() && !quote.querySelector('img,figure,input,table')) quote.remove();
    const r = document.createRange(); r.selectNodeContents(out); r.collapse(true); sel.removeAllRanges(); sel.addRange(r);
    markHist(); auto();
  });
  ed.addEventListener('focus', () => { if (cp.style.display === 'block') closeCp(); closeLp(); closeRp(); });
  ladd.onclick = addLabel;
  lnew.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addLabel(); } });
  chex.addEventListener('input', () => { const hx = normalizeHex(chex.value); if (hx) { cerr.textContent = ''; n.col = hx; tint(); cprev.style.background = hx; const hv = hexToHsv(hx); if (hv) { hsv = hv; wheelUi(); } auto(); } });
  capply.onclick = () => { const hx = normalizeHex(chex.value); if (hx) { setCol(hx, true); closeCp(); } else cerr.textContent = 'Kode hex tidak valid. Contoh: #F4C2C2'; };
  cnone.onclick = () => setCol('', false);

  setMode(initialMode, true);
  o.append(imgTools);
  o.addEventListener('scroll', placeSoon, true); addEventListener('resize', placeSoon); ed.addEventListener('input', placeSoon);
  document.body.append(o, imageInput);
  if (!isP && ed.querySelector('figure.ki')) { try { refreshImages(); } catch (_) {} }
  try { document.documentElement.classList.add('ed-open'); } catch (_) {} // Rev 46: bintang di balik editor berhenti berkedip (tertutup penuh di HP)
  current = { kind, close: closeNow, back: done, menu: () => closeMenu() || closeLp() };
  current.flush = () => { if (dirty && alive) { clearTimeout(tm); save(); } }; // Rev 193 / P3 (baris terpisah: tes lama mengunci baris current = {...})
  tint(); fit(); pinUi(); edtUi(); labUi(); syncLinks(); relUi(); remUi();
  if (vv) { vv.addEventListener('resize', fit); vv.addEventListener('scroll', fit); vv.addEventListener('resize', kbUi); vv.addEventListener('resize', placeSoon); vv.addEventListener('scroll', placeSoon); }
  // Rev 112 / U6d: bilah chip bagian lipat. Tampil hanya saat kursor di baris isi bagian lipat ("Pindahkan keluar dari bagian lipat") atau di blok
  // tepat di bawah bagian lipat yang boleh masuk ("Pindahkan ke dalam bagian lipat"). Tidak tampil di mode Baca, judul bagian lipat, tabel, blok pulau.
  const foldUi = () => {
    const sl = getSelection();
    const node = sl && sl.rangeCount ? sl.anchorNode : null;
    const ctx = editorMode === 'edit' && node ? foldMoveContext(node, ed) : null;
    if (!ctx) { foldCtx = null; if (foldBar.isShown()) { foldBar.hide(); if (!chipBar.isShown()) o.classList.remove('chips'); } return; }
    if (ctx.kind !== foldKind) { foldKind = ctx.kind; foldBar.setPages(ctx.kind === 'in' ? FOLD_IN_CHIPS : FOLD_OUT_CHIPS); }
    foldCtx = ctx;
    const isNew = foldBar.show(); o.classList.add('chips');
    if (isNew) requestAnimationFrame(() => { try { const t = foldCtx && (foldCtx.kind === 'in' ? foldCtx.block : foldCtx.row); if (t) t.scrollIntoView({ block: 'nearest' }); } catch (_) {} });
  };
  // Satu ketukan chip = satu langkah Undo (flushHist sebelum dan sesudah). Konteks dihitung ulang dari kursor saat ini (DOM bisa berubah sejak
  // bilah digambar); yang dipindah SIMPUL ASLI, jadi kursor dipulihkan di simpul + offset yang sama (pemindahan melepas seleksi dari simpul itu).
  const foldChip = (id) => {
    if (editorMode !== 'edit') return;
    const sl = getSelection();
    const node = sl && sl.rangeCount ? sl.anchorNode : null, off = sl && sl.rangeCount ? sl.anchorOffset : 0;
    const cur = node ? foldMoveContext(node, ed) : null;
    if (!cur || (id === 'fold-in') !== (cur.kind === 'in')) { foldUi(); return; }
    flushHist();
    const ok = cur.kind === 'in' ? moveBlockIntoFold(cur.fold, cur.block, document) : moveBlockOutOfFold(cur.fold, cur.row, document);
    if (!ok) { foldUi(); return; }
    try { setCaretAt(node, off); } catch (_) {}
    rng = null;
    flushHist(); auto(); foldUi();
    try { const t = cur.kind === 'in' ? cur.block : cur.row; t.scrollIntoView({ block: 'nearest' }); } catch (_) {}
  };
  const selChanged = () => { upd(); snap(); tableUi(); foldUi(); };
  // Rev 107: kursor tidak boleh berada di kiri kotak centang (ketuk ruang kiri kotak atau panah kiri memindahkannya ke awal teks di kanan kotak).
  const keepCaretRight = () => {
    if (o.classList.contains('ed-baca') || composing) return;
    const sl = getSelection(); if (!sl || !sl.rangeCount || !sl.isCollapsed) return;
    const nd = sl.anchorNode; if (!nd || !ed.contains(nd) || nd === ed) return;
    const el = nd.nodeType === 1 ? nd : nd.parentElement; const row = el && el.closest ? el.closest('.todo') : null;
    if (!row || row === ed || !ed.contains(row) || !caretLeftOfBox(row, nd, sl.anchorOffset)) return;
    const tg = caretAfterBox(row); if (tg) { try { sl.collapse(tg.node, tg.offset); } catch (_) {} }
  };
  const healTodos = () => { // jaring pengaman (tempel, IME, penyimpanan lama, Enter bawaan Chrome): invarian baris centang dipulihkan, kursor dipertahankan
    if (composing) return 0; // jangan menyentuh DOM saat IME sedang menyusun kata
    let moved = 0; const sl = getSelection(); const a = sl && sl.rangeCount && sl.isCollapsed ? { n: sl.anchorNode, o: sl.anchorOffset } : null;
    let rowFixed = null;
    ed.querySelectorAll('.todo').forEach((row) => { const orphan = !boxOf(row); const k = healTodoStructure(row, document); moved += k; if (orphan) { rowFixed = row; row.removeAttribute('data-cid'); } });
    moved += healListCids([...ed.querySelectorAll('li[data-cid],.todo[data-cid]')]); // Rev 347 / R2: cid ganda/li kosong di bullet & bernomor
    if (moved && a && a.n && ed.contains(a.n)) {
      try {
        if (rowFixed && a.n === rowFixed) { const tg = caretAfterBox(rowFixed); if (tg) sl.collapse(tg.node, tg.offset); }
        else sl.collapse(a.n, a.o);
      } catch (_) {}
    }
    return moved;
  };
  document.addEventListener('selectionchange', keepCaretRight);
  document.addEventListener('selectionchange', upd);
  document.addEventListener('selectionchange', selChanged);
  if (initialMode === 'edit') {
    if (!n.title && !n.text) tt.focus();
    else { focusEditorAtEnd(); }
  } // Mode Baca (termasuk dari Bagikan dan chip terkait) sengaja tidak memfokuskan kolom apa pun.
}
