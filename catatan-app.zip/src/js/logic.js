import { stripSheetIslands, countSheetRefs, cloneSheetsForCopy } from './lembar-siklus.js';
// Logika murni (tanpa DOM) agar mudah diuji. Dipakai oleh main.js.
export const DEFAULT_DAYS = [1, 2, 3, 4, 5]; // 0=Min ... 6=Sab

export const SCOPES = [
  { id: 'habit', emoji: '🌱', short: 'Kebiasaan', title: 'KEBIASAAN HARIAN' },
  { id: 'hari', emoji: '☀️', short: 'Fokus', title: 'FOKUS HARI INI' },
  { id: 'minggu', emoji: '🎯', short: 'Target', title: 'TARGET MINGGUAN' },
  { id: 'bulan', emoji: '🌙', short: 'Rencana', title: 'RENCANA BULANAN' },
];

const p2 = (n) => String(n).padStart(2, '0');

export function todayISO(d = new Date()) {
  return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
}
export function dayOfWeek(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d).getDay();
}
export function formatDate(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
}
export function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
export function validateTitle(v) {
  const t = String(v ?? '').trim();
  if (!t) return { ok: false, msg: 'Judul wajib diisi.' };
  if (t.length > 120) return { ok: false, msg: 'Judul maksimal 120 karakter.' };
  return { ok: true, value: t };
}
export function tasksByScope(tasks, scope) {
  return tasks.filter((t) => t.scope === scope);
}
// Penting dulu, lalu tenggat terdekat; tanpa tenggat di paling bawah.
export function sortTasks(list) {
  const key = (t) => t.due || '9999-99-99';
  return [...list].sort((a, b) => ((b.pri || 0) - (a.pri || 0)) || key(a).localeCompare(key(b)));
}
// ---- Sub-tugas (Rev 67, SCHEMA 9) ----
// task.subs = [{id, title, done}], maks. SUB_MAX per tugas. Hanya untuk Fokus/Target/Rencana (bukan Kebiasaan).
// Mencentang semua sub-tugas TIDAK otomatis menyelesaikan tugas induk; hanya tampil progres "2/5".
export const SUB_MAX = 20;
export const canHaveSubs = (scope) => scope === 'hari' || scope === 'minggu' || scope === 'bulan';
// Bersihkan larik sub-tugas dari data lama/cadangan yang diedit tangan. Tidak pernah melempar.
// Rev 68: pengingat per sub-tugas = {at, repeat}; task.remMode = 'subs' berarti alarm ada di tiap sub-tugas (bukan di tugas).
export function cleanSubReminder(r) {
  if (!r || typeof r !== 'object') return null;
  const at = Number(r.at);
  return Number.isFinite(at) && at > 0 ? withMode({ at, repeat: r.repeat === 'daily' ? 'daily' : 'once' }, r.mode) : null; // Rev 378 / AL2
}
export const isSubsMode = (task) => !!task && task.remMode === 'subs' && Array.isArray(task.subs) && task.subs.length > 0;
export function subReminderCount(task) {
  return isSubsMode(task) ? task.subs.filter((s) => s && !s.done && s.reminder).length : 0;
}
export function cleanSubs(v) {
  const out = [], seen = new Set();
  for (const x of Array.isArray(v) ? v : []) {
    if (!x || typeof x !== 'object') continue;
    const title = String(x.title ?? '').trim().slice(0, 120);
    if (!title) continue;
    let id = typeof x.id === 'string' && x.id ? x.id.slice(0, 40) : '';
    if (!id || seen.has(id)) id = newId();
    seen.add(id);
    const sub = { id, title, done: x.done === true };
    const rem = cleanSubReminder(x.reminder); if (rem) sub.reminder = rem; // Rev 68: pengingat per sub-tugas
    out.push(sub);
    if (out.length >= SUB_MAX) break;
  }
  return out;
}
export function subProgress(task) {
  const subs = task && Array.isArray(task.subs) ? task.subs : [];
  const done = subs.filter((s) => s && s.done === true).length;
  return { done, total: subs.length, text: subs.length ? done + '/' + subs.length : '', all: subs.length > 0 && done === subs.length };
}
// Tambah sub-tugas ke larik `subs`. Mengembalikan { ok, subs } atau { ok:false, msg }. Tidak mengubah larik asli.
export function addSub(subs, title) {
  const cur = cleanSubs(subs);
  const t = String(title ?? '').trim();
  if (!t) return { ok: false, msg: 'Isi sub-tugas dulu.' };
  if (t.length > 120) return { ok: false, msg: 'Sub-tugas maksimal 120 karakter.' };
  if (cur.length >= SUB_MAX) return { ok: false, msg: 'Maksimal ' + SUB_MAX + ' sub-tugas per tugas.' };
  return { ok: true, subs: [...cur, { id: newId(), title: t, done: false }] };
}

// Kebiasaan dikosongkan lagi sekali per hari kerja baru.
export function needsReset(lastResetISO, todayStr, days) {
  return lastResetISO !== todayStr && days.includes(dayOfWeek(todayStr));
}
export function resetHabits(habits) {
  return habits.map((h) => ({ ...h, done: false }));
}

// ---- Catatan ----
export const HEX = /^#[0-9a-f]{6}$/;
// Menerima "F4C2C2", "#f4c2c2", "#abc"; mengembalikan "#rrggbb" atau "" jika tidak valid.
export function normalizeHex(v) {
  let s = String(v ?? '').trim().toLowerCase();
  if (s && s[0] !== '#') s = '#' + s;
  if (/^#[0-9a-f]{3}$/.test(s)) s = '#' + s[1] + s[1] + s[2] + s[2] + s[3] + s[3];
  return HEX.test(s) ? s : '';
}
// ---- Warna: kontras otomatis, konversi HSV, saran warna ----
const rgbOf = (hex) => [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)];
const hex2 = (n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');
const toHex = ([r, g, b]) => '#' + hex2(r) + hex2(g) + hex2(b);
// Luminans relatif (WCAG), 0 (hitam) sampai 1 (putih).
export function relLum(hex) {
  hex = String(hex).toLowerCase();
  const [r, g, b] = rgbOf(hex).map((v) => { const c = v / 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrastRatio(a, b) {
  const l1 = relLum(a), l2 = relLum(b);
  return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
}
const mix = (a, b, t) => toHex(rgbOf(a).map((v, i) => v + (rgbOf(b)[i] - v) * t));
const INK_DARK = '#1E2A3D', INK_LIGHT = '#F2F5FB';
// Warna teks dan ikon otomatis: pilih yang kontrasnya lebih tinggi terhadap latar (rasio WCAG, bukan tebakan kecerahan).
// ink = teks/ikon utama, mut = teks kecil (dijaga minimal 4,5 : 1), ln = garis pemisah.
export function contrast(hex) {
  hex = String(hex || '').toLowerCase();
  if (!HEX.test(hex)) return null;
  const dark = contrastRatio(hex, INK_DARK) >= contrastRatio(hex, INK_LIGHT);
  let ink = dark ? INK_DARK : INK_LIGHT;
  // Warna menengah ekstrem: jika kedua tinta lembut kurang dari 4,5 : 1, pakai hitam atau putih murni.
  if (contrastRatio(ink, hex) < 4.5) ink = contrastRatio(hex, '#000000') >= contrastRatio(hex, '#ffffff') ? '#000000' : '#FFFFFF';
  const isDark = ink !== INK_LIGHT && ink !== '#FFFFFF';
  let mut = ink;
  for (const t of [0.3, 0.22, 0.14, 0.08]) { const m = mix(ink, hex, t); if (contrastRatio(m, hex) >= 4.5) { mut = m; break; } }
  return { ink, mut: mut.toUpperCase(), ln: isDark ? 'rgba(0,0,0,.14)' : 'rgba(255,255,255,.2)', dark: isDark };
}
// HSV: h 0..360, s 0..1, v 0..1 <-> "#rrggbb".
export function hsvToHex(h, s, v) {
  const hh = ((h % 360) + 360) % 360 / 60, c = v * s, x = c * (1 - Math.abs(hh % 2 - 1)), m = v - c;
  const [r, g, b] = hh < 1 ? [c, x, 0] : hh < 2 ? [x, c, 0] : hh < 3 ? [0, c, x] : hh < 4 ? [0, x, c] : hh < 5 ? [x, 0, c] : [c, 0, x];
  return toHex([(r + m) * 255, (g + m) * 255, (b + m) * 255]);
}
export function hexToHsv(hex) {
  hex = String(hex || '').toLowerCase();
  if (!HEX.test(hex)) return null;
  const [r, g, b] = rgbOf(hex).map((v) => v / 255);
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let h = 0;
  if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return { h: (h * 60 + 360) % 360, s: mx ? d / mx : 0, v: mx };
}
// Saran warna yang serasi dengan tema biru aplikasi dan tidak menyilaukan.
// Terang: pastel lembut (teks gelap, kontras tinggi). Gelap: pekat redup (teks terang, kontras tinggi).
export const SUGGEST_LIGHT = [
  ['#DCE6F7', 'Biru kabut'], ['#D3E4F1', 'Biru langit'], ['#D5ECE6', 'Mint'], ['#DDEBD3', 'Hijau sage'], ['#EFE8C8', 'Krem kuning'],
  ['#F4DFCB', 'Persik'], ['#F2D6D9', 'Mawar pudar'], ['#E6DAF0', 'Lavender'], ['#E4E0EC', 'Ungu abu'], ['#E3E7EC', 'Abu perak'],
];
export const SUGGEST_DARK = [
  ['#1F2D4A', 'Navy'], ['#243B5C', 'Biru malam'], ['#1F3C46', 'Teal tua'], ['#23402F', 'Hijau hutan'], ['#3E3A25', 'Zaitun'],
  ['#4A3427', 'Cokelat kopi'], ['#4A2C36', 'Marun'], ['#3D2D52', 'Ungu tua'], ['#322F4F', 'Indigo'], ['#2C3340', 'Abu arang'],
];
// labelId (opsional): hanya catatan yang punya label itu.
// extra (opsional, Rev 135 / U8b-2): fungsi (catatan) -> teks tambahan yang ikut dicari (mis. isi lembar kerja); dipanggil hanya bila ada kata kunci dan judul+isi belum cocok.
export function filterNotes(notes, q, labelId = '', extra = null) {
  const s = String(q ?? '').trim().toLowerCase();
  const byLabel = labelId ? notes.filter((n) => Array.isArray(n.labels) && n.labels.includes(labelId)) : [...notes];
  if (!s) return byLabel;
  return byLabel.filter((n) => {
    if (((n.title || '') + ' ' + (n.text || '')).toLowerCase().includes(s)) return true;
    if (typeof extra !== 'function') return false;
    try { return String(extra(n) || '').toLowerCase().includes(s); } catch (_) { return false; }
  });
}
// Disematkan dulu, lalu yang terbaru diubah.
export function sortNotes(list) {
  return [...list].sort((a, b) => ((b.pin ? 1 : 0) - (a.pin ? 1 : 0)) || ((b.updated || 0) - (a.updated || 0)));
}
export function addRecent(list, hex, max = 8) {
  return [hex, ...list.filter((x) => x !== hex)].slice(0, max);
}

// ---- Pengaturan ----
export const DAY_NAMES = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
export const WEEK_ORDER = [1, 2, 3, 4, 5, 6, 0];
export function toggleDay(days, d) {
  const s = days.includes(d) ? days.filter((x) => x !== d) : [...days, d];
  return WEEK_ORDER.filter((x) => s.includes(x));
}
// Kosongkan centang kebiasaan sekali per hari kerja baru. Mengembalikan true jika ada perubahan.
export function applyDailyReset(data, today = todayISO()) {
  if (!needsReset(data.settings.lastReset, today, data.settings.days)) return false;
  logHabitDay(data, data.settings.lastReset); // Rev 238: catat hasil hari yang baru berakhir sebelum dikosongkan
  data.habits = resetHabits(data.habits);
  data.settings.lastReset = today;
  return true;
}
// Rev 238 / Tahap 8b-1 (SCHEMA 20): data tren. Tugas yang diselesaikan mencatat `doneAt` (ms); hasil kebiasaan per hari disimpan di `habitLog` [{d, done, total}] (maks. 60 hari). Tugas lama yang sudah selesai TIDAK diisi ulang.
export const HABIT_LOG_MAX = 60;
export function toggleDone(item, isTask, now = Date.now()) {
  item.done = !item.done;
  if (isTask) { if (item.done) item.doneAt = now; else delete item.doneAt; }
}
export function cleanDoneAt(list) {
  for (const t of list) { if (!t || typeof t !== 'object') continue; const n = Number(t.doneAt); if (t.done === true && Number.isFinite(n) && n > 0) t.doneAt = Math.trunc(n); else delete t.doneAt; }
}
const cnt = (x) => (Number.isInteger(x) && x >= 0 && x <= 999 ? x : -1);
export function cleanHabitLog(v) {
  const by = new Map();
  for (const x of Array.isArray(v) ? v : []) {
    if (!x || typeof x !== 'object' || !/^\d{4}-\d{2}-\d{2}$/.test(String(x.d))) continue;
    const done = cnt(x.done), total = cnt(x.total);
    if (done < 0 || total < 1 || done > total) continue;
    by.set(x.d, { d: x.d, done, total });
  }
  return [...by.values()].sort((a, b) => (a.d < b.d ? -1 : 1)).slice(-HABIT_LOG_MAX);
}
export function logHabitDay(data, iso) {
  const hs = Array.isArray(data.habits) ? data.habits : [];
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(iso)) || !hs.length || hs.length > 999) return false;
  data.habitLog = cleanHabitLog([...(Array.isArray(data.habitLog) ? data.habitLog : []), { d: iso, done: hs.filter((h) => h && h.done === true).length, total: hs.length }]);
  return true;
}
const TRASH_TARGET = { task: 'tasks', habit: 'habits', note: 'notes' };
export function restoreFromTrash(data, index) {
  const x = data.trash[index];
  if (!x || !TRASH_TARGET[x.kind]) return false;
  data.trash.splice(index, 1);
  data[TRASH_TARGET[x.kind]].push(x.item);
  return true;
}
export function backupSummary(d) {
  return { tasks: d.tasks.length, habits: d.habits.length, notes: d.notes.length, priv: d.priv.length };
}
export function backupFileName(d = new Date()) {
  return 'notes-kelimaa-' + todayISO(d) + '.json';
}
export function backupZipName(d = new Date()) {
  return 'notes-kelimaa-' + todayISO(d) + '.zip'; // Rev 44 (G2): dipakai hanya bila ada gambar
}
// Rev 121 / U7a-2c-3: banyak lembar kerja di data (cadangan atau data aktif). Bukan bagian backupSummary supaya bentuk lama tidak berubah.
export function sheetCount(d) { const s = d && d.sheets; return s && typeof s === 'object' && !Array.isArray(s) ? Object.keys(s).length : 0; }
export function replaceData(target, src) {
  for (const k of ['habits', 'tasks', 'notes', 'priv', 'trash']) target[k] = src[k];
  target.settings = src.settings;
  // Rev 121: lembar kerja ikut DIGANTI (sebelumnya terlewat: pulihkan cadangan tidak membawa/mengganti lembar kerja). Cadangan lama tanpa sheets = {}.
  target.sheets = src.sheets && typeof src.sheets === 'object' && !Array.isArray(src.sheets) ? src.sheets : {};
  target.habitLog = cleanHabitLog(src.habitLog); // Rev 295 / 4-2
  target.projects = Array.isArray(src.projects) ? src.projects : []; // Rev 234 / Tahap 7a: proyek ikut diganti saat pulihkan cadangan (cadangan lama tanpa projects = [])
}

// ---- Terakhir diedit ----
const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const jam = (d) => p2(d.getHours()) + '.' + p2(d.getMinutes());
// Teks waktu terakhir diedit, mis. "Baru saja", "5 menit lalu", "Hari ini, 14.30", "Kemarin, 09.05", "25 Okt, 14.30".
export function formatEdited(ts, now = Date.now()) {
  if (!Number.isFinite(ts) || ts <= 0) return '';
  const d = new Date(ts), n = new Date(now);
  const diff = now - ts;
  if (diff < 60000) return 'Baru saja'; // termasuk jam HP yang diubah mundur (diff negatif)
  if (diff < 3600000) return Math.floor(diff / 60000) + ' menit lalu';
  const day = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const gap = Math.round((day(n) - day(d)) / 86400000);
  if (gap === 0) return 'Hari ini, ' + jam(d);
  if (gap === 1) return 'Kemarin, ' + jam(d);
  const tgl = d.getDate() + ' ' + BULAN[d.getMonth()] + (d.getFullYear() === n.getFullYear() ? '' : ' ' + d.getFullYear());
  return tgl + ', ' + jam(d);
}
// Tanda isi catatan; berubah hanya jika judul, isi, warna, atau label berubah (sematan tidak dihitung).
export function noteSignature(title, html, col, labels, links) {
  const base = [title || '', html || '', col || '', [...(labels || [])].sort().join(',')];
  const lk = [...(links || [])].sort().join(',');
  if (lk) base.push(lk); // tanpa hubungan: tanda tangan sama persis seperti sebelum Rev 18
  return base.join('\u0001');
}

// ---- Duplikat catatan (Rev 25, butir 10) ----
// Membuat catatan BARU dari catatan lama tanpa mengubah aslinya. Daftar putih: hanya isi (HTML apa adanya), warna, label, dan
// pratinjau tautan (turunan isi) yang disalin. TIDAK disalin: sematan, pengingat (agar tak ada notifikasi ganda), hubungan
// antarcatatan, dan status sampah. Judul "Salinan ..." hanya bila asli punya judul (catatan tanpa judul tetap tanpa judul).
export const COPY_PREFIX = 'Salinan ';
export function copyTitle(title) {
  const t = String(title ?? '').trim();
  return t ? COPY_PREFIX + t : '';
}
export function duplicateNote(note, { id, now } = {}) {
  const src = note && typeof note === 'object' ? note : {};
  const copy = {
    id: id || newId(), title: copyTitle(src.title), text: String(src.text ?? ''), html: String(src.html ?? ''),
    col: typeof src.col === 'string' ? src.col : '', pin: false, updated: Number.isFinite(now) ? now : Date.now(),
  };
  if (Array.isArray(src.labels) && src.labels.length) copy.labels = [...src.labels];
  if (src.prev && typeof src.prev === 'object') copy.prev = JSON.parse(JSON.stringify(src.prev));
  return copy;
}
// Salinan masuk ke daftar yang SAMA dengan asli: kind 'priv' = Catatan Privat (tidak pernah pindah ke daftar biasa), selain itu catatan biasa.
export function addDuplicate(data, kind, note, opts) {
  const list = kind === 'priv' ? data.priv : data.notes;
  const copy = duplicateNote(note, opts);
  // Rev 125 / U7b-4: pulau lembar kerja di salinan = KLON lembar (bukan berbagi); Catatan Privat tidak boleh memuat pulau.
  if (kind === 'priv') copy.html = stripSheetIslands(copy.html);
  else if (countSheetRefs(copy.html)) { if (!data.sheets || typeof data.sheets !== 'object') data.sheets = {}; copy.html = cloneSheetsForCopy(copy.html, data.sheets).html; }
  list.push(copy);
  return copy;
}

// ---- Label / kategori catatan ----
export const LABEL_NAME_MAX = 20;
export const LABEL_MAX = 20;
export function validateLabel(name, labels, ignoreId = '') {
  const v = String(name ?? '').replace(/\s+/g, ' ').trim();
  if (!v) return { ok: false, msg: 'Nama label wajib diisi.' };
  if (v.length > LABEL_NAME_MAX) return { ok: false, msg: 'Nama label maksimal ' + LABEL_NAME_MAX + ' huruf.' };
  const others = labels.filter((l) => l.id !== ignoreId);
  if (others.some((l) => l.name.toLowerCase() === v.toLowerCase())) return { ok: false, msg: 'Label "' + v + '" sudah ada.' };
  if (!ignoreId && labels.length >= LABEL_MAX) return { ok: false, msg: 'Maksimal ' + LABEL_MAX + ' label. Hapus yang tidak dipakai dulu.' };
  return { ok: true, value: v };
}
export function toggleId(ids, id) {
  const a = Array.isArray(ids) ? ids : [];
  return a.includes(id) ? a.filter((x) => x !== id) : [...a, id];
}
// Label milik catatan, urut sesuai daftar label; id yang labelnya sudah dihapus diabaikan.
export function noteLabels(note, labels) {
  const ids = Array.isArray(note && note.labels) ? note.labels : [];
  return labels.filter((l) => ids.includes(l.id));
}
// Jumlah catatan per label (untuk deretan penyaring).
export function labelCounts(notes) {
  const c = {};
  for (const n of notes) for (const id of (Array.isArray(n.labels) ? n.labels : [])) c[id] = (c[id] || 0) + 1;
  return c;
}
// Pindahkan label ke posisi baru (Rev 24B). Mengubah larik di tempat; urutan larik = urutan chip filter dan pemilih label.
// Mengembalikan true bila urutan benar-benar berubah.
export function moveLabel(labels, id, to) {
  if (!Array.isArray(labels)) return false;
  const from = labels.findIndex((l) => l && l.id === id);
  if (from < 0) return false;
  const dest = Math.max(0, Math.min(labels.length - 1, Math.trunc(Number(to))));
  if (!Number.isFinite(dest) || dest === from) return false;
  const [x] = labels.splice(from, 1); labels.splice(dest, 0, x);
  return true;
}
// Hapus label dari daftar dan dari semua catatan (termasuk privat dan tempat sampah). Mengembalikan jumlah catatan terdampak.
export function removeLabel(data, id) {
  let hit = 0;
  const strip = (n) => { if (n && Array.isArray(n.labels) && n.labels.includes(id)) { n.labels = n.labels.filter((x) => x !== id); hit++; } };
  data.notes.forEach(strip); data.priv.forEach(strip);
  data.trash.forEach((x) => { if (x.kind === 'note') strip(x.item); });
  data.settings.labels = data.settings.labels.filter((l) => l.id !== id);
  return hit;
}

// ---- Tautan dan pratinjau ----
const URL_RE = /(?:https?:\/\/|www\.)[^\s<>"'`]+/gi;
// Mengambil tautan http/https dari teks (maks. max, tanpa duplikat). Tanda baca di ujung dibuang.
// Mode awal editor (Rev 29): bagikan selalu Baca; catatan baru/kosong Edit; catatan berisi Baca.
export function modeFor({ isNew = false, isEmpty = false, fromShare = false, fromRelated = false } = {}) {
  if (fromShare || fromRelated) return 'baca';
  return isNew || isEmpty ? 'edit' : 'baca';
}
export function extractUrls(text, max = 3) {
  const out = [];
  for (const m of String(text ?? '').matchAll(URL_RE)) {
    let u = m[0].replace(/[.,;:!?)\]}>]+$/, '');
    if (/^www\./i.test(u)) u = 'https://' + u;
    if (u.length > 2000) continue;
    let p;
    try { p = new URL(u); } catch (_) { continue; }
    if (p.protocol !== 'https:' && p.protocol !== 'http:') continue;
    if (!/^[^.]+(\.[^.]+)*\.[a-z]{2,}$/i.test(p.hostname)) continue; // harus ada titik dan akhiran huruf
    if (!out.includes(u)) out.push(u);
    if (out.length >= max) break;
  }
  return out;
}
// Mengembalikan URL bila offset teks jatuh di dalam alamat tersebut (untuk ketukan tautan pada mode Baca).
export function urlAtOffset(text, offset) {
  const s = String(text ?? ''), at = Number(offset);
  if (!Number.isFinite(at) || at < 0) return '';
  for (const m of s.matchAll(URL_RE)) {
    const raw = m[0].replace(/[.,;:!?)\]}>]+$/, '');
    if (!raw || at < m.index || at > m.index + raw.length) continue;
    const url = /^www\./i.test(raw) ? 'https://' + raw : raw;
    try {
      const p = new URL(url);
      if ((p.protocol === 'https:' || p.protocol === 'http:') && /^[^.]+(\.[^.]+)*\.[a-z]{2,}$/i.test(p.hostname)) return url;
    } catch (_) {}
  }
  return '';
}
export function hostOf(url) {
  try { return new URL(url).hostname.replace(/^www\./i, ''); } catch (_) { return ''; }
}
// Hanya terima alamat https untuk gambar (aplikasi memblokir http campur).
export function safeImageUrl(u) {
  try { const p = new URL(String(u || '')); return p.protocol === 'https:' ? p.href : ''; } catch (_) { return ''; }
}
const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
function decodeEntities(s) {
  return String(s).replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === '#') {
      const c = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(c) && c > 0 && c < 0x110000 ? String.fromCodePoint(c) : m;
    }
    return ENT[e.toLowerCase()] ?? m;
  });
}
function attrs(tag) {
  const o = {}; const re = /([a-zA-Z:_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))/g; let m;
  while ((m = re.exec(tag))) o[m[1].toLowerCase()] = m[2] ?? m[3] ?? m[4] ?? '';
  return o;
}
// Membaca judul + gambar dari HTML halaman (og:*, twitter:*, <title>). Hanya teks; tidak ada HTML yang dipakai ulang.
export function parsePreview(html, baseUrl) {
  let src = String(html ?? ''); const end = src.search(/<\/head>/i);
  src = end > 0 ? src.slice(0, end) : src.slice(0, 200000);
  const meta = {};
  for (const m of src.matchAll(/<meta\b[^>]*>/gi)) {
    const a = attrs(m[0]); const k = (a.property || a.name || '').toLowerCase();
    if (k && a.content !== undefined && meta[k] === undefined) meta[k] = decodeEntities(a.content).trim();
  }
  const tt = src.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const cut = (s, n) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
  const title = cut(meta['og:title'] || meta['twitter:title'] || (tt ? decodeEntities(tt[1]) : ''), 140);
  const site = cut(meta['og:site_name'], 60);
  let image = '';
  const raw = meta['og:image'] || meta['og:image:url'] || meta['og:image:secure_url'] || meta['twitter:image'] || meta['twitter:image:src'] || '';
  if (raw) { try { image = new URL(raw, baseUrl).href.replace(/^http:\/\//i, 'https://'); } catch (_) { image = ''; } }
  return { t: title, i: safeImageUrl(image), s: site };
}

// ---- Cadangan otomatis (Rev 17) ----
// Aplikasi menyimpan cadangan sendiri saat dibuka dan sudah waktunya. Tidak ada proses latar belakang.
export const BACKUP_MAX = { week: 52, month: 12 };
export const BACKUP_FOLDER_DEFAULT = 'NotesKelimaa';
export const BACKUP_BASE_DIR = { documents: 'DOCUMENTS', app: 'EXTERNAL' }; // nama folder induk plugin Filesystem
export const BACKUP_BASE_NAME = { documents: 'Dokumen', app: 'Folder aplikasi' };
export const BACKUP_KINDS = { auto: 'Otomatis', manual: 'Cadangkan sekarang', share: 'Ekspor lewat Bagikan' };
export const BACKUP_RETRY_MS = 3600000; // setelah gagal, coba lagi paling cepat 1 jam kemudian
export const BACKUP_HISTORY_MAX = 20;

export function emptyBackup() {
  return { on: false, every: 2, unit: 'week', base: 'documents', folder: BACKUP_FOLDER_DEFAULT, lastAt: 0, lastTry: 0, history: [] };
}
// Nama folder buatan pengguna: maks. 3 tingkat dipisah "/", tanpa ".." dan huruf terlarang.
export function cleanFolder(v) {
  const s = String(v == null ? '' : v).trim().replace(/\\/g, '/').replace(/\/+/g, '/').replace(/^\/|\/$/g, '');
  if (!s) return { ok: false, msg: 'Nama folder wajib diisi.' };
  if (s.length > 60) return { ok: false, msg: 'Nama folder terlalu panjang (maks. 60 huruf).' };
  const parts = s.split('/').map((p) => p.trim());
  if (parts.length > 3) return { ok: false, msg: 'Maksimal 3 tingkat folder.' };
  if (parts.some((p) => !p || p === '.' || p === '..' || /^\.+$/.test(p))) return { ok: false, msg: 'Nama folder tidak valid.' };
  if (/[<>:"|?*\u0000-\u001f]/.test(s)) return { ok: false, msg: 'Huruf < > : " | ? * tidak boleh dipakai di nama folder.' };
  return { ok: true, value: parts.join('/') };
}
const num = (x) => (typeof x === 'number' && Number.isFinite(x) && x > 0 ? x : 0);
// Bersihkan pengaturan cadangan dari data lama/cadangan yang diedit tangan. Tidak pernah melempar.
export function normalizeBackup(b) {
  const e = emptyBackup();
  if (!b || typeof b !== 'object') return e;
  e.on = b.on === true;
  e.unit = b.unit === 'month' ? 'month' : 'week';
  const ev = Math.floor(Number(b.every));
  e.every = Number.isFinite(ev) ? Math.min(Math.max(ev, 1), BACKUP_MAX[e.unit]) : e.every;
  e.base = Object.hasOwn(BACKUP_BASE_DIR, b.base) ? b.base : 'documents';
  const f = cleanFolder(b.folder); e.folder = f.ok ? f.value : BACKUP_FOLDER_DEFAULT;
  e.lastAt = num(b.lastAt); e.lastTry = num(b.lastTry);
  e.history = (Array.isArray(b.history) ? b.history : []).filter((x) => x && num(x.at) && Object.hasOwn(BACKUP_KINDS, x.kind))
    .map((x) => ({ at: x.at, kind: x.kind, ok: x.ok === true, where: String(x.where || '').slice(0, 120), msg: String(x.msg || '').slice(0, 120) }))
    .slice(0, BACKUP_HISTORY_MAX);
  return e;
}
// Tambah n minggu/bulan (kalender, aman untuk tanggal 31 dan tahun kabisat).
export function addInterval(ts, n, unit) {
  const d = new Date(ts);
  if (unit === 'month') {
    const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n);
    d.setDate(Math.min(day, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()));
  } else d.setDate(d.getDate() + n * 7);
  return d.getTime();
}
export function nextBackupAt(b) { return b.lastAt ? addInterval(b.lastAt, b.every, b.unit) : 0; }
export function isBackupDue(b, now = Date.now()) {
  if (!b || !b.on || now < nextBackupAt(b)) return false;
  if (b.lastTry > b.lastAt && now >= b.lastTry && now - b.lastTry < BACKUP_RETRY_MS) return false; // baru gagal, jangan mengulang terus
  return true;
}
export function backupAutoName(d = new Date()) { return 'notes-kelimaa-' + todayISO(d) + '-' + p2(d.getHours()) + p2(d.getMinutes()) + '.json'; }
export function backupWhere(b) { return BACKUP_BASE_NAME[b.base] + '/' + b.folder; }
export function backupEveryText(b) { return b.every === 1 ? 'Tiap ' + (b.unit === 'month' ? 'bulan' : 'minggu') : 'Tiap ' + b.every + ' ' + (b.unit === 'month' ? 'bulan' : 'minggu'); }
export function pushBackupHistory(b, entry) {
  b.history.unshift(entry);
  if (b.history.length > BACKUP_HISTORY_MAX) b.history.length = BACKUP_HISTORY_MAX;
}
export function formatBackupDate(ts) {
  const d = new Date(ts);
  return d.getDate() + ' ' + BULAN[d.getMonth()] + ' ' + d.getFullYear() + ', ' + jam(d);
}

// ---- Hubungan antarcatatan (Rev 18) ----
// note.links = daftar id catatan LAIN (hanya catatan biasa; Catatan Privat tidak ikut agar judulnya tidak bocor).
// Hubungan balik ("Disebut di") TIDAK disimpan, selalu dihitung dari catatan lain.
export const LINK_MAX = 20;
// Id hubungan yang bersih: teks, tanpa ganda, bukan diri sendiri, maksimal LINK_MAX; bila valid diberikan, hanya id yang ada di situ.
export function cleanLinks(note, valid) {
  const src = note && Array.isArray(note.links) ? note.links : [];
  const out = [];
  for (const id of src) {
    if (typeof id !== 'string' || !id || id === note.id || out.includes(id)) continue;
    if (valid && !valid.has(id)) continue;
    out.push(id);
    if (out.length >= LINK_MAX) break;
  }
  return out;
}
// Dipanggil saat memuat/mengimpor data: buang hubungan rusak, ke diri sendiri, atau ke catatan yang sudah tidak ada
// (catatan di tempat sampah masih dihitung ada, supaya hubungan kembali saat dipulihkan). Catatan Privat tidak boleh punya hubungan.
export function pruneLinks(data) {
  const obj = (x) => x && typeof x === 'object';
  const trashNotes = data.trash.filter((x) => obj(x) && x.kind === 'note' && obj(x.item)).map((x) => x.item);
  const valid = new Set([...data.notes, ...trashNotes].filter(obj).map((n) => n.id).filter((id) => typeof id === 'string' && id));
  for (const n of [...data.notes, ...trashNotes]) {
    if (!obj(n)) continue;
    const c = cleanLinks(n, valid);
    if (c.length) n.links = c; else delete n.links;
  }
  for (const n of data.priv) if (obj(n)) delete n.links;
}
// Catatan yang dihubungkan dari note (hanya yang masih ada di daftar, urut sesuai pemasangan).
export function linkedNotes(note, notes) {
  const byId = new Map(notes.map((n) => [n.id, n]));
  return cleanLinks(note).map((id) => byId.get(id)).filter(Boolean);
}
// Catatan lain yang menghubungkan ke id ini, yang terbaru diubah dulu.
export function backlinks(notes, id) {
  return sortNotes(notes.filter((n) => n.id !== id && Array.isArray(n.links) && n.links.includes(id)));
}
// Pasang/lepas hubungan ke targetId. Mengembalikan { ok, ids } atau { ok:false, msg }.
export function toggleLink(note, targetId) {
  const cur = cleanLinks(note);
  if (!targetId || targetId === note.id) return { ok: false, msg: 'Catatan tidak bisa dihubungkan ke dirinya sendiri.' };
  if (cur.includes(targetId)) return { ok: true, ids: cur.filter((x) => x !== targetId), on: false };
  if (cur.length >= LINK_MAX) return { ok: false, msg: 'Maksimal ' + LINK_MAX + ' catatan terkait.' };
  return { ok: true, ids: [...cur, targetId], on: true };
}
// Calon yang bisa dihubungkan: semua catatan biasa selain dirinya, disaring kata kunci, terbaru dulu.
export function linkCandidates(notes, selfId, q) {
  return sortNotes(filterNotes(notes.filter((n) => n.id !== selfId), q));
}

// ---- Tempat sampah otomatis kosong (Rev 19) ----
// settings.trashDays: 0 = Mati (bawaan, tidak ada yang hilang tanpa disadari), atau 7 / 30 / 90 hari.
// Umur item dihitung dari trash[].at (saat dipindah ke sampah).
export const TRASH_DAYS_OPTIONS = [0, 7, 30, 90];
const DAY_MS = 86400000;
export function normalizeTrashDays(v) { return TRASH_DAYS_OPTIONS.includes(v) ? v : 0; }
// Rev 60 (G4): kualitas kompres gambar BARU. Nilai tak dikenal = 'seimbang' (bawaan). Kunci harus sama dengan PRESETS di gambar.js (dijaga tes g4).
export const IMAGE_QUALITIES = ['hemat', 'seimbang', 'tajam'];
export function normalizeImageQuality(v) { return IMAGE_QUALITIES.includes(v) ? v : 'seimbang'; }
export function trashDaysText(d) { return d > 0 ? d + ' hari' : 'Mati'; }
// Item yang sudah melewati batas. Item tanpa waktu valid, atau waktunya di masa depan (jam HP diubah mundur), TIDAK pernah dianggap kedaluwarsa.
export function isTrashExpired(x, days, now = Date.now()) {
  if (!days || !x || typeof x !== 'object' || !Number.isFinite(x.at)) return false;
  return x.at <= now - days * DAY_MS;
}
export function countExpiredTrash(data, days, now = Date.now()) {
  return data.trash.filter((x) => isTrashExpired(x, days, now)).length;
}
// Sisa hari sebelum item dihapus otomatis (dibulatkan ke atas, minimal 1); null bila fitur mati atau waktu tidak valid.
export function trashDaysLeft(x, days, now = Date.now()) {
  if (!days || !x || !Number.isFinite(x.at)) return null;
  return Math.max(1, Math.ceil((x.at + days * DAY_MS - now) / DAY_MS));
}
// Buang permanen item yang kedaluwarsa. Mengembalikan jumlah yang dibuang. Hubungan ke catatan yang ikut terbuang dibersihkan langsung.
export function purgeTrash(data, now = Date.now()) {
  const days = normalizeTrashDays(data.settings && data.settings.trashDays);
  if (!days) return 0;
  const before = data.trash.length;
  data.trash = data.trash.filter((x) => !isTrashExpired(x, days, now));
  const n = before - data.trash.length;
  if (n > 0) pruneLinks(data);
  return n;
}

// ---- Terima teks dari Bagikan Android (Rev 20) ----
export const SHARE_IN_MAX = 20000;   // batas huruf isi catatan dari Bagikan (sisanya dipotong, pengguna diberi tahu)
export const SHARE_IN_TITLE_MAX = 120;
const CTRL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
// Membaca muatan JSON dari native (KelimaaNative.takeShared). Mengembalikan:
//   null                                   = tidak ada yang perlu diproses (kosong / bukan JSON)
//   { ok:false, reason:'tolak' }           = tidak ada teks (mis. hanya gambar/berkas dibagikan)
//   { ok:true, title, text, truncated }    = siap dibuat jadi catatan biasa
// Judul = subjek bila ada (satu baris, maks. 120); isi dibersihkan dari karakter kontrol, tab jadi spasi, baris kosong berlebih dirapikan.
export function parseShared(raw) {
  if (typeof raw !== 'string' || !raw.trim()) return null;
  let o; try { o = JSON.parse(raw); } catch (_) { return null; }
  if (!o || typeof o !== 'object') return null;
  let text = typeof o.text === 'string' ? o.text : '';
  text = text.replace(/\r\n?/g, '\n').replace(CTRL, '').replace(/\t/g, '  ').replace(/[ \u00a0]+\n/g, '\n').replace(/\n{4,}/g, '\n\n\n').trim();
  if (o.reject === true || !text) return { ok: false, reason: 'tolak' };
  let truncated = false;
  if (text.length > SHARE_IN_MAX) {
    text = text.slice(0, SHARE_IN_MAX);
    const last = text.charCodeAt(text.length - 1);
    if (last >= 0xd800 && last <= 0xdbff) text = text.slice(0, -1); // jangan memotong pasangan surrogate (emoji)
    text = text.replace(/\s+$/, ''); truncated = true;
  }
  let title = typeof o.subject === 'string' ? o.subject.replace(CTRL, ' ').replace(/\s+/g, ' ').trim().slice(0, SHARE_IN_TITLE_MAX).trim() : '';
  if (title === text.replace(/\s+/g, ' ').trim()) title = ''; // beberapa aplikasi mengisi subjek sama dengan isi (mis. tautan): jangan dobel
  return { ok: true, title, text, truncated };
}
// Rev 416: baris kotak centang gaya Google Keep. "[ ] teks", "[x] teks", "[X] teks", "[] teks", "- [ ] teks", "\u2610 teks", "\u2611 teks". Mengembalikan { done, text } atau null.
const CHK_RE = /^[ \u00a0]*(?:[-*][ \u00a0]+)?(?:\[([ xX]?)\]|(\u2610)|(\u2611|\u2705))[ \u00a0]?(.*)$/;
export function parseCheckLine(line) {
  const m = CHK_RE.exec(String(line ?? ''));
  return m ? { done: !!(m[3] || (m[1] && m[1].trim())), text: m[4] } : null;
}
// Teks biasa -> HTML editor catatan: tiap baris satu <div>, baris kosong <div><br></div>. Karakter HTML di-escape (tidak ada tag dari luar).
// Rev 416: baris "[ ]" / "[X]" jadi baris kotak centang sungguhan (bentuk SAMA dengan insertTodo: <div class="todo"><input type="checkbox">&nbsp;teks</div>).
export function sharedToHtml(text) {
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return String(text ?? '').split('\n').map((l) => {
    const c = parseCheckLine(l);
    if (c) return '<div class="todo"><input type="checkbox"' + (c.done ? ' checked=""' : '') + '>\u00a0' + esc(c.text) + '</div>';
    return l ? '<div>' + esc(l) + '</div>' : '<div><br></div>';
  }).join('');
}

// Rev 71: bentuk bar menu bawah dengan lekukan melengkung (notch) di bawah lingkaran tab aktif. MURNI: hanya menghitung teks path SVG.
// W,H = lebar/tinggi bar (px); i = indeks tab aktif (0-3). Struktur perintah path SAMA untuk semua i, jadi bisa dianimasikan (CSS `d`).
export const NAV_PAD = 26;
export function navShape(W, H, i, o = {}) {
  const pad = o.pad ?? NAV_PAD, rad = o.rad ?? 20, n = o.n ?? 33, cy = o.cy ?? 4, f = o.f ?? 8;
  const tab = (W - 2 * pad) / (o.tabs ?? 4), cx = pad + tab * (i + 0.5);
  const dx = Math.sqrt((n + f) * (n + f) - (f - cy) * (f - cy));
  const px = dx * n / (n + f), py = cy + (f - cy) * n / (n + f);
  const c = Math.max(0, Math.min(rad, cx - dx, W - cx - dx));
  const v = (x) => (Math.round(x * 100) / 100).toString();
  return ['M', v(c), 0, 'L', v(cx - dx), 0,
    'A', f, f, 0, 0, 1, v(cx - px), v(py),
    'A', n, n, 0, 0, 0, v(cx + px), v(py),
    'A', f, f, 0, 0, 1, v(cx + dx), 0,
    'L', v(W - c), 0, 'A', v(c), v(c), 0, 0, 1, v(W), v(c),
    'L', v(W), v(H - c), 'A', v(c), v(c), 0, 0, 1, v(W - c), v(H),
    'L', v(c), v(H), 'A', v(c), v(c), 0, 0, 1, 0, v(H - c),
    'L', 0, v(c), 'A', v(c), v(c), 0, 0, 1, v(c), 0, 'Z'].join(' ');
}


// ---------- Rev 378 / PART AL2: mode pengingat (ada di logic.js agar jumlah modul statis saat buka tetap 53 dan modul mesin pengingat tidak saling impor berlebihan) ----------
// Rev 378 / PART AL2: mode pengingat 'notif' (bawaan) | 'alarm' (berdering seperti jam alarm) + pemilih jembatan native. MURNI (tanpa DOM), dites di Node.
// Aturan: kunci `mode` HANYA ditulis bila 'alarm'; data lama tanpa `mode` = notif, jadi tidak ada data yang berubah bentuk dan SCHEMA tidak naik.
// Jembatan: mode 'alarm' memanggil AndroidAPI.scheduleAlarm bila ada; APK lama (tanpa scheduleAlarm) jatuh ke scheduleNotification dan hasilnya diberi tanda `fellBack`.
export const MODES = ['notif', 'alarm'];
export const cleanMode = (m) => (m === 'alarm' ? 'alarm' : 'notif');
export const isAlarmMode = (x) => !!x && typeof x === 'object' && x.mode === 'alarm';
// Menambah { mode: 'alarm' } ke objek hanya bila perlu (bentuk lama tetap persis sama untuk mode notif).
export const withMode = (obj, mode) => (cleanMode(mode) === 'alarm' ? { ...obj, mode: 'alarm' } : obj);
export function canScheduleAlarm(a) { return !!a && typeof a.scheduleAlarm === 'function'; }
// Memasang satu jadwal lewat jembatan yang sesuai. Mengembalikan { res, via: 'alarm'|'notif', fellBack }; melempar bila jembatan tidak ada (pemanggil sudah membungkus try/catch).
export function pushSchedule(a, id, title, message, delayMs, repeatMs, mode) {
  const wantAlarm = cleanMode(mode) === 'alarm';
  if (wantAlarm && canScheduleAlarm(a)) return { res: a.scheduleAlarm(id, title, message, delayMs, repeatMs), via: 'alarm', fellBack: false };
  return { res: a.scheduleNotification(id, title, message, delayMs, repeatMs), via: 'notif', fellBack: wantAlarm };
}
// Izin layar penuh (Android 14+); jembatan `a` diberikan pemanggil (modul ini murni, tanpa membaca globalThis). true / false; null = tidak bisa ditentukan (APK lama atau peramban).
export function fullScreenAllowed(a) {
  try { return a && typeof a.canUseFullScreenAlarm === 'function' ? !!a.canUseFullScreenAlarm() : null; } catch (_) { return null; }
}
export function openFullScreenSettings(a) {
  try { if (a && typeof a.openFullScreenAlarmSettings === 'function') { a.openFullScreenAlarmSettings(); return true; } } catch (_) { /* abaikan */ }
  return false;
}
// Rev 379 / AL3b-1: tema aplikasi untuk layar alarm native ('light' | 'dark' | 'auto'). Jembatan `a` diberikan pemanggil; APK lama (tanpa setAlarmTheme) = tidak melakukan apa-apa.
export function syncAlarmTheme(a, theme) {
  try { if (a && typeof a.setAlarmTheme === 'function') { a.setAlarmTheme(theme === 'light' || theme === 'dark' ? theme : 'auto'); return true; } } catch (_) { /* abaikan */ }
  return false;
}
// Rev 389 / TN2: lama Tunda alarm (menit). Hanya pilihan ini yang diterima, selain itu bawaan 10 (sama dengan AlarmRinger.cleanSnooze di sisi native).
export const SNOOZE_CHOICES = [5, 10, 15, 30];
export const SNOOZE_DEFAULT = 10;
export function cleanSnooze(v) {
  const n = typeof v === 'string' && /^\s*\d+\s*$/.test(v) ? Number(v) : v;
  return SNOOZE_CHOICES.includes(n) ? n : SNOOZE_DEFAULT;
}
// Kirim lama Tunda ke Android. Jembatan `a` diberikan pemanggil; APK lama (tanpa setAlarmSnooze) = tidak melakukan apa-apa.
export function syncAlarmSnooze(a, minutes) {
  try { if (a && typeof a.setAlarmSnooze === 'function') { a.setAlarmSnooze(cleanSnooze(minutes)); return true; } } catch (_) { /* abaikan */ }
  return false;
}
