// Rev 250 / S1: MODEL SELEKSI gaya Google Sheets untuk lembar kerja (MURNI: tanpa DOM, penyimpanan, native, eval; hanya mengimpor lembar-rentang.js).
// Seleksi hanya hidup di layar (TIDAK disimpan, tidak mengubah data). Belum dipakai UI (S2 = Rev 251).
// selx = { kind: 'cell'|'range'|'row'|'col'|'all', a: {r,c} jangkar, f: {r,c} ujung seret, rect: {r1,c1,r2,c2} }.
// Seleksi PENUH (row/col/all) disimpan sebagai rentang indeks, TIDAK pernah dijadikan daftar sel; batas MAX_RANGE_CELLS (2000) TIDAK berlaku di sini.
// Gabungan sel (merges = [{r1,c1,r2,c2}], mis. mergeList(tab)) yang tersentuh ikut masuk UTUH.
import { inRect, rectRef, rectSig } from './lembar-rentang.js';

export const KINDS = ['cell', 'range', 'row', 'col', 'all'];
const isInt = (v) => Number.isInteger(v) && v >= 0;
const okDims = (d) => !!d && Number.isInteger(d.rows) && Number.isInteger(d.cols) && d.rows >= 1 && d.cols >= 1;
const okPt = (d, p) => !!p && isInt(p.r) && isInt(p.c) && p.r < d.rows && p.c < d.cols;
const overlap = (p, q) => p.r1 <= q.r2 && q.r1 <= p.r2 && p.c1 <= q.c2 && q.c1 <= p.c2;
export const dimsOfTab = (tab) => ({ rows: tab && Array.isArray(tab.rows) ? tab.rows.length : 0, cols: tab && Array.isArray(tab.cols) ? tab.cols.length : 0 });

// Perluas rect sampai semua gabungan yang tersentuh masuk utuh (berantai). Mengembalikan rect baru.
export function growToMerges(rect, merges) {
  const list = Array.isArray(merges) ? merges : []; let rc = { ...rect };
  for (let guard = 0; guard <= list.length; guard++) {
    let grew = false;
    for (const m of list) if (overlap(rc, m) && (m.r1 < rc.r1 || m.r2 > rc.r2 || m.c1 < rc.c1 || m.c2 > rc.c2)) { rc = { r1: Math.min(rc.r1, m.r1), c1: Math.min(rc.c1, m.c1), r2: Math.max(rc.r2, m.r2), c2: Math.max(rc.c2, m.c2) }; grew = true; }
    if (!grew) break;
  }
  return rc;
}
const mk = (kind, a, f, rect) => ({ kind, a: { r: a.r, c: a.c }, f: { r: f.r, c: f.c }, rect });
const one = (rect) => rect.r1 === rect.r2 && rect.c1 === rect.c2;

export function selectCell(dims, r, c, merges = []) {
  if (!okDims(dims) || !okPt(dims, { r, c })) return null;
  const rect = growToMerges({ r1: r, c1: c, r2: r, c2: c }, merges);
  return mk('cell', { r, c }, { r, c }, rect);
}
export function selectRange(dims, a, b, merges = []) {
  if (!okDims(dims) || !okPt(dims, a) || !okPt(dims, b)) return null;
  const rect = growToMerges({ r1: Math.min(a.r, b.r), c1: Math.min(a.c, b.c), r2: Math.max(a.r, b.r), c2: Math.max(a.c, b.c) }, merges);
  return mk(one(rect) ? 'cell' : 'range', a, b, rect);
}
export function selectRow(dims, r, merges = []) {
  if (!okDims(dims) || !okPt(dims, { r, c: 0 })) return null;
  const rect = growToMerges({ r1: r, c1: 0, r2: r, c2: dims.cols - 1 }, merges);
  return mk('row', { r, c: 0 }, { r, c: dims.cols - 1 }, rect);
}
export function selectCol(dims, c, merges = []) {
  if (!okDims(dims) || !okPt(dims, { r: 0, c })) return null;
  const rect = growToMerges({ r1: 0, c1: c, r2: dims.rows - 1, c2: c }, merges);
  return mk('col', { r: 0, c }, { r: dims.rows - 1, c }, rect);
}
export function selectAll(dims) {
  if (!okDims(dims)) return null;
  return mk('all', { r: 0, c: 0 }, { r: dims.rows - 1, c: dims.cols - 1 }, { r1: 0, c1: 0, r2: dims.rows - 1, c2: dims.cols - 1 });
}

// Seret titik ujung: jangkar `a` tetap, ujung pindah ke `focus` {r,c} (sel yang disentuh jari).
// cell/range: rentang jangkar..focus. row: baris jangkar..focus.r (kolom tetap penuh). col: kolom jangkar..focus.c (baris tetap penuh). all: tidak berubah.
export function extend(dims, sx, focus, merges = []) {
  if (!okDims(dims) || !sx || !okPt(dims, focus)) return null;
  if (sx.kind === 'all') return sx;
  if (sx.kind === 'row') { const r1 = Math.min(sx.a.r, focus.r), r2 = Math.max(sx.a.r, focus.r); return mk('row', sx.a, { r: focus.r, c: dims.cols - 1 }, growToMerges({ r1, c1: 0, r2, c2: dims.cols - 1 }, merges)); }
  if (sx.kind === 'col') { const c1 = Math.min(sx.a.c, focus.c), c2 = Math.max(sx.a.c, focus.c); return mk('col', sx.a, { r: dims.rows - 1, c: focus.c }, growToMerges({ r1: 0, c1, r2: dims.rows - 1, c2 }, merges)); }
  return selectRange(dims, sx.a, focus, merges);
}

// Setelah baris/kolom dihapus atau tab berganti ukuran: potong ke ukuran baru; null bila tidak ada yang tersisa.
export function clampSel(dims, sx, merges = []) {
  if (!okDims(dims) || !sx || !sx.rect) return null;
  if (sx.kind === 'all') return selectAll(dims);
  if (sx.kind === 'row') { if (sx.rect.r1 >= dims.rows) return null; const r2 = Math.min(sx.rect.r2, dims.rows - 1); return mk('row', { r: Math.min(sx.a.r, dims.rows - 1), c: 0 }, { r: Math.min(sx.f.r, dims.rows - 1), c: dims.cols - 1 }, growToMerges({ r1: sx.rect.r1, c1: 0, r2, c2: dims.cols - 1 }, merges)); }
  if (sx.kind === 'col') { if (sx.rect.c1 >= dims.cols) return null; const c2 = Math.min(sx.rect.c2, dims.cols - 1); return mk('col', { r: 0, c: Math.min(sx.a.c, dims.cols - 1) }, { r: dims.rows - 1, c: Math.min(sx.f.c, dims.cols - 1) }, growToMerges({ r1: 0, c1: sx.rect.c1, r2: dims.rows - 1, c2 }, merges)); }
  if (sx.rect.r1 >= dims.rows || sx.rect.c1 >= dims.cols) return null;
  const cl = (p) => ({ r: Math.min(p.r, dims.rows - 1), c: Math.min(p.c, dims.cols - 1) });
  return selectRange(dims, cl(sx.a), cl(sx.f), merges);
}

export const isFull = (sx) => !!sx && (sx.kind === 'row' || sx.kind === 'col' || sx.kind === 'all');
export const isSingle = (sx) => !!sx && one(sx.rect);
export const rowCount = (sx) => (sx ? sx.rect.r2 - sx.rect.r1 + 1 : 0);
export const colCount = (sx) => (sx ? sx.rect.c2 - sx.rect.c1 + 1 : 0);
export const cellCount = (sx) => rowCount(sx) * colCount(sx);
export const contains = (sx, r, c) => !!sx && inRect(sx.rect, r, c);
// Alamat gaya Sheets: sel "D4", rentang "D5:E8", kolom penuh "D1:D114", baris penuh "A6:E6", semua "A1:Z114". addr(c, r) = L.cellAddr.
export const refText = (sx, addr) => (sx ? rectRef(sx.rect, addr) : '');
export const sig = (sx) => (sx ? sx.kind + '|' + rectSig(sx.rect) + '|' + sx.a.r + ':' + sx.a.c : '-');

// Keadaan kepala: 'on' = seluruh kolom/baris itu terpilih (biru tua), 'in' = tersentuh seleksi (biru muda), '' = di luar.
// axis 'col' untuk kepala kolom i, 'row' untuk nomor baris i.
export function headState(sx, axis, i, dims) {
  if (!sx || !isInt(i)) return '';
  const rc = sx.rect;
  if (axis === 'col') { if (i < rc.c1 || i > rc.c2) return ''; return rc.r1 === 0 && dims && rc.r2 === dims.rows - 1 ? 'on' : 'in'; }
  if (axis === 'row') { if (i < rc.r1 || i > rc.r2) return ''; return rc.c1 === 0 && dims && rc.c2 === dims.cols - 1 ? 'on' : 'in'; }
  return '';
}

// Rev 253 / S4: kolom/baris mana yang ikut berubah ukuran saat pegangan kepala `i` diseret. Bila kepala itu 'on' (seluruh kolom/baris terpilih) = SEMUA kolom/baris
// terpilih (urut naik); selain itu hanya `i` sendiri. axis 'col' | 'row'. Masukan rusak = [].
export function resizeSet(sx, axis, i, dims) {
  if (!isInt(i) || (axis !== 'col' && axis !== 'row')) return [];
  if (headState(sx, axis, i, dims) !== 'on') return [i];
  const lo = axis === 'col' ? sx.rect.c1 : sx.rect.r1, hi = axis === 'col' ? sx.rect.c2 : sx.rect.r2, a = [];
  for (let k = lo; k <= hi; k++) a.push(k); return a;
}

// Rev 255 / S5b: titik awal TEMPEL. Seleksi lebih dari satu sel (rentang/kolom/baris/semua) = sudut KIRI-ATAS seleksi (seperti Google Sheets), bukan sel jangkar
// (jangkar bisa di kanan-bawah setelah titik kiri-atas diseret, atau baris acak pada kolom penuh). Satu sel / tanpa seleksi = jangkar. Hasil { r, c } atau null.
export function pasteOrigin(sx, anchor) {
  if (sx && sx.rect && !one(sx.rect)) return { r: sx.rect.r1, c: sx.rect.c1 };
  return anchor && isInt(anchor.r) && isInt(anchor.c) ? { r: anchor.r, c: anchor.c } : null;
}

// Sel yang ADA di dalam seleksi (sel kosong tidak dibuat). Generator: tidak membentuk daftar besar. Menghasilkan { r, c, row, col, cell }.
export function* existingCells(tab, sx) {
  if (!tab || !sx || !Array.isArray(tab.rows) || !Array.isArray(tab.cols)) return;
  const rc = sx.rect;
  for (let r = rc.r1; r <= rc.r2 && r < tab.rows.length; r++) {
    const row = tab.rows[r]; if (!row || !row.cells) continue;
    for (let c = rc.c1; c <= rc.c2 && c < tab.cols.length; c++) { const col = tab.cols[c], cell = col ? row.cells[col.id] : undefined; if (cell) yield { r, c, row, col, cell }; }
  }
}
export const countExisting = (tab, sx) => { let n = 0; for (const _ of existingCells(tab, sx)) n++; return n; };
