// Rev 291 / T5b: kelompok templat "Admin" bagian 2 (data murni, tanpa impor): Rekap bulanan, Nilai dan rapor, Peminjaman aset, Laporan penjualan, Kontak dan pencarian. Bentuk: lihat lembar-templat.js.
const RED = { bg: '#FEE2E2', fg: '#991B1B' }, GRN = { bg: '#DCFCE7', fg: '#166534' }, YEL = { bg: '#FEF9C3', fg: '#854D0E' }, BLU = { bg: '#DBEAFE', fg: '#1E40AF' }, PUR = { bg: '#EDE9FE', fg: '#5B21B6' };
const day = (n) => ({ v: { today: n }, nf: 'date' });
const ser = (y, m, d) => Math.floor((Date.UTC(y, m - 1, d) - Date.UTC(1899, 11, 30)) / 86400000); // nomor seri tetap (hasil rekap stabil)
const fixed = (y, m, d) => ({ v: ser(y, m, d), nf: 'date' });
const INP = { s: { bg: '#FEF9C3', fg: '#111827' } }; // kotak isian (kuning muda)
const inp = (v, nf) => ({ v, ...INP, ...(nf ? { nf } : {}) });

// ---- Rekap bulanan: catatan pengeluaran per tanggal, rekap otomatis per bulan, diagram kolom
const BLN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const CATAT = [
  [1, 15, 'Gaji dan operasional', 4200000], [1, 28, 'Listrik', 450000], [2, 10, 'Alat tulis', 300000], [2, 20, 'Internet', 500000], [3, 5, 'Perawatan gedung', 750000],
  [4, 12, 'Konsumsi rapat', 280000], [5, 8, 'Transport dinas', 350000], [6, 18, 'Pelatihan staf', 900000], [7, 22, 'Sewa ruang', 1500000], [8, 17, 'Listrik', 460000],
  [9, 9, 'Alat tulis', 320000], [10, 14, 'Internet', 500000], [11, 3, 'Gaji dan operasional', 4200000], [12, 15, 'Bonus akhir tahun', 1000000],
];
const REKAP = {
  id: 'admin-rekap', name: 'Admin · Rekap bulanan', desc: 'Catat transaksi per tanggal; jumlah per bulan dihitung sendiri (SUMIF) lengkap dengan diagram.',
  tab: 'Rekap', w: [36, 90, 40, 170, 100, 24, 40, 80, 110], head: true, nfc: ['', '', '', '', 'rp', '', '', '', 'rp'],
  rows: [
    ['No', 'Tanggal', 'Bln', 'Keterangan', 'Jumlah', '', 'Bln', 'Bulan', 'Total'],
    ...CATAT.map(([m, d, k, j], i) => {
      const r = i + 2, row = [i + 1, fixed(2026, m, d), '=MONTH(B' + r + ')', k, j, ''];
      if (i < 12) row.push(i + 1, BLN[i], '=SUMIF($C$2:$C$30;G' + r + ';$E$2:$E$30)'); else if (i === 12) row.push('', { v: 'Total', t: true }, { v: '=SUM(I2:I13)', t: true });
      return row;
    }),
  ],
  rules: [{ c: 'E', op: 'scale', lo: '#FFFFFF', hi: '#FCA5A5' }],
  charts: [{ kind: 'column', title: 'Jumlah per bulan', r1: 0, c1: 7, r2: 12, c2: 8, vc: 8 }],
  guide: [
    ['Apa ini?', 'Catatan pengeluaran (atau pemasukan) per tanggal. Tabel kanan menjumlahkannya per bulan, diagram ikut berubah.'],
    ['Cara pakai', 'Isi Tanggal, Keterangan, dan Jumlah di baris kosong (sampai baris 30). Kolom Bln terisi sendiri dari tanggalnya.'],
    ['Tahun lain', 'Rekap menjumlah SEMUA tahun dengan bulan yang sama. Pakai satu lembar untuk satu tahun, salin lembar ini untuk tahun berikutnya.'],
    ['Warna', 'Jumlah besar makin merah. Ubah lewat Lainnya > Warna bersyarat.'],
    ['Mencari', 'Lainnya > Filter baris, mis. Keterangan berisi Listrik. Filter hanya sementara.'],
  ],
};

// ---- Nilai dan rapor: rata-rata, peringkat, predikat, rekap kelas
const NILAI = [['Ani', 85, 80, 90], ['Budi', 70, 65, 72], ['Cici', 95, 92, 96], ['Dedi', 60, 70, 65], ['Eka', 88, 85, 90], ['Fajar', 78, 82, 80], ['Gita', 92, 90, 94], ['Hadi', 75, 70, 68]];
const RAPOR = {
  id: 'admin-rapor', name: 'Admin · Nilai dan rapor', desc: 'Nilai tugas, UTS, UAS jadi rata-rata, peringkat, dan predikat A-D; rekap kelas dan diagram.',
  tab: 'Rapor', w: [36, 100, 60, 60, 60, 80, 70, 70, 24, 130, 80], head: true, nfc: ['', '', 'num', 'num', 'num', 'num1', 'num', '', '', '', ''],
  rows: [
    ['No', 'Nama', 'Tugas', 'UTS', 'UAS', 'Rata-rata', 'Peringkat', 'Predikat', '', 'Rekap kelas', 'Nilai'],
    ...NILAI.map(([n, a, b, c], i) => {
      const r = i + 2, row = [i + 1, n, a, b, c, '=ROUND(AVERAGE(C' + r + ':E' + r + ');1)', '=RANK(F' + r + ';$F$2:$F$30)', '=IF(F' + r + '>=90;"A";IF(F' + r + '>=80;"B";IF(F' + r + '>=70;"C";"D")))', ''];
      const k = [['Rata-rata kelas', '=ROUND(AVERAGE(F2:F30);1)', 'num1'], ['Tertinggi', '=MAX(F2:F30)', 'num1'], ['Terendah', '=MIN(F2:F30)', 'num1'], ['Jumlah siswa', '=COUNT(F2:F30)', 'num'], ['Lulus (70 ke atas)', '=COUNTIF(F2:F30;">=70")', 'num'], ['Belum lulus', '=COUNTIF(F2:F30;"<70")', 'num']][i];
      if (k) row.push(k[0], { v: k[1], nf: k[2] });
      return row;
    }),
  ],
  rules: [{ c: 'F', op: 'lt', a: 70, ...RED }, { c: 'F', op: 'gte', a: 90, ...GRN }],
  charts: [{ kind: 'column', title: 'Rata-rata per siswa', r1: 0, c1: 1, r2: 8, c2: 5, vc: 5 }],
  guide: [
    ['Apa ini?', 'Daftar nilai satu kelas. Rata-rata, peringkat, dan predikat dihitung sendiri dari tiga nilai.'],
    ['Cara pakai', 'Isi Tugas, UTS, dan UAS. Untuk siswa baru isi baris kosong lalu salin rumus Rata-rata, Peringkat, dan Predikat dari baris di atasnya.'],
    ['Predikat', 'A mulai 90, B mulai 80, C mulai 70, di bawahnya D. Ubah batasnya di rumus kolom Predikat.'],
    ['Warna', 'Rata-rata 90 ke atas hijau, di bawah 70 merah. Ubah lewat Lainnya > Warna bersyarat.'],
    ['Urutan', 'Lainnya > Urutkan A-Z atau Z-A pada kolom Rata-rata untuk melihat yang tertinggi.'],
  ],
};

// ---- Peminjaman aset: status dropdown, sisa hari dari TODAY berwarna, rekap
const ASET = [
  ['Laptop Asus', 'Ani', -12, -2, 'Dipinjam'], ['Proyektor', 'Budi', -5, 2, 'Dipinjam'], ['Kamera DSLR', 'Cici', -20, -13, 'Kembali'], ['Mic wireless', 'Dedi', -3, 4, 'Dipinjam'],
  ['Kunci ruang rapat', 'Eka', -1, 0, 'Dipinjam'], ['Tripod', 'Fajar', -30, -23, 'Kembali'], ['Speaker', 'Gita', -8, -1, 'Dipinjam'], ['Tablet', 'Hadi', -2, 5, 'Dipinjam'],
];
const PINJAM = {
  id: 'admin-aset', name: 'Admin · Peminjaman aset', desc: 'Catat barang yang dipinjam; sisa hari dan warna jatuh tempo mengikuti tanggal hari ini.',
  tab: 'Pinjam', w: [36, 130, 90, 90, 90, 90, 70, 24, 110, 70], head: true, nfc: ['', '', '', '', '', '', 'num', '', '', 'num'],
  rows: [
    ['No', 'Aset', 'Peminjam', 'Tgl pinjam', 'Jatuh tempo', 'Status', 'Sisa hari', '', 'Rekap', 'Jumlah'],
    ...ASET.map(([a, p, t1, t2, s], i) => {
      const r = i + 2, row = [i + 1, a, p, day(t1), day(t2), s, '=IF(F' + r + '="Kembali";"";E' + r + '-TODAY())', ''];
      if (i === 0) row.push('Dipinjam', '=COUNTIF($F$2:$F$30;I2)'); else if (i === 1) row.push('Kembali', '=COUNTIF($F$2:$F$30;I3)'); else if (i === 2) row.push({ v: 'Total', t: true }, { v: '=SUM(J2:J3)', t: true });
      else if (i === 4) row.push('Terlambat', '=COUNTIFS($F$2:$F$30;"Dipinjam";$E$2:$E$30;"<"&TODAY())');
      return row;
    }),
  ],
  rules: [{ c: 'G', op: 'lt', a: 0, ...RED }, { c: 'G', op: 'lte', a: 2, ...YEL }],
  checks: [{ k: 'list', rg: 'F2:F30', items: ['Dipinjam', 'Kembali'], cl: { Dipinjam: YEL, Kembali: GRN } }],
  charts: [{ kind: 'donut', title: 'Status aset', r1: 0, c1: 8, r2: 2, c2: 9, vc: 9 }],
  guide: [
    ['Apa ini?', 'Buku peminjaman barang kantor atau sekolah. Sisa hari dihitung dari Jatuh tempo dikurangi tanggal hari ini.'],
    ['Cara pakai', 'Isi baris kosong: aset, peminjam, tanggal, jatuh tempo. Status dipilih dari daftar Dipinjam atau Kembali.'],
    ['Warna sisa hari', 'Minus (lewat tempo) merah, 0 sampai 2 hari kuning. Barang yang sudah Kembali tidak dihitung.'],
    ['Terlambat', 'Jumlah barang berstatus Dipinjam yang jatuh temponya sudah lewat. Ikut berubah setiap hari.'],
    ['Mencari', 'Lainnya > Filter baris, mis. Status sama dengan Dipinjam. Filter hanya sementara.'],
  ],
};

// ---- Laporan penjualan: total per produk dan per sales (SUMIF/SUMIFS), batang + donat
const PROD = ['Kopi', 'Teh', 'Roti', 'Susu'], SALES = ['Ani', 'Budi', 'Cici'];
const JUAL = [
  ['Kopi', 'Ani', 10, 25000], ['Teh', 'Budi', 8, 18000], ['Roti', 'Cici', 20, 12000], ['Susu', 'Ani', 6, 30000], ['Kopi', 'Budi', 5, 25000], ['Teh', 'Cici', 12, 18000],
  ['Roti', 'Ani', 15, 12000], ['Susu', 'Budi', 4, 30000], ['Kopi', 'Cici', 8, 25000], ['Teh', 'Ani', 10, 18000], ['Roti', 'Budi', 10, 12000], ['Susu', 'Cici', 5, 30000],
];
const RINGKAS = [['Total penjualan', '=SUM(G2:G30)', 'rp'], ['Jumlah transaksi', '=COUNT(G2:G30)', 'num'], ['Rata-rata per transaksi', '=ROUND(AVERAGE(G2:G30);0)', 'rp'], ['Transaksi terbesar', '=MAX(G2:G30)', 'rp'], ['Kopi oleh Ani', '=SUMIFS($G$2:$G$30;$C$2:$C$30;"Kopi";$D$2:$D$30;"Ani")', 'rp']];
const PENJUALAN = {
  id: 'admin-jual', name: 'Admin · Laporan penjualan', desc: 'Catat penjualan; total per produk dan per sales dihitung sendiri, ada diagram batang dan donat.',
  tab: 'Penjualan', w: [36, 90, 80, 80, 60, 90, 100, 24, 150, 110, 24, 80, 110], head: true, nfc: ['', '', '', '', 'num', 'rp', 'rp', '', '', 'rp', '', '', 'rp'],
  rows: [
    ['No', 'Tanggal', 'Produk', 'Sales', 'Jumlah', 'Harga', 'Total', '', 'Produk', 'Total', '', 'Sales', 'Total'],
    ...JUAL.map(([p, s, q, h], i) => {
      const r = i + 2, row = [i + 1, day(i - 20), p, s, q, h, '=E' + r + '*F' + r, ''];
      if (i < 4) row.push(PROD[i], '=SUMIF($C$2:$C$30;I' + r + ';$G$2:$G$30)'); else row.push('', '');
      if (i < 3) row.push('', SALES[i], '=SUMIF($D$2:$D$30;L' + r + ';$G$2:$G$30)'); else row.push('', '', '');
      if (i >= 6 && i < 11) { const k = RINGKAS[i - 6]; row[8] = k[0]; row[9] = { v: k[1], nf: k[2] }; }
      return row;
    }),
  ],
  rules: [{ c: 'G', op: 'gte', a: 240000, ...GRN }],
  checks: [{ k: 'list', rg: 'C2:C30', items: PROD, cl: { Kopi: YEL, Teh: GRN, Roti: BLU, Susu: PUR } }, { k: 'list', rg: 'D2:D30', items: SALES, cl: { Ani: BLU, Budi: GRN, Cici: YEL } }],
  charts: [{ kind: 'bar', title: 'Total per produk', r1: 0, c1: 8, r2: 4, c2: 9, vc: 9 }, { kind: 'donut', title: 'Total per sales', r1: 0, c1: 11, r2: 3, c2: 12, vc: 12 }],
  guide: [
    ['Apa ini?', 'Buku penjualan. Total tiap baris = Jumlah x Harga. Tabel kanan menjumlah per produk dan per sales.'],
    ['Cara pakai', 'Isi baris kosong (sampai baris 30). Produk dan Sales dipilih dari daftar berwarna. Total baris dan rekap berubah sendiri.'],
    ['Produk atau sales baru', 'Ganti nama di daftar kanan, lalu ubah pilihan lewat Dropdown (tekan lama sel kolom Produk atau Sales).'],
    ['SUMIFS', 'Baris Kopi oleh Ani menjumlah dengan DUA syarat sekaligus. Ubah kata Kopi dan Ani di rumusnya untuk pasangan lain.'],
    ['Mencari', 'Lainnya > Filter baris, mis. Sales sama dengan Ani. Filter hanya sementara.'],
  ],
};

// ---- Kontak dan pencarian: VLOOKUP/MATCH dari nama yang diketik, validasi email
const ORANG = [
  ['Ani Wulandari', 'Bendahara', '081200000001', 'ani@contoh.id'], ['Budi Santoso', 'Kepala Bagian', '081200000002', 'budi@contoh.id'], ['Cici Lestari', 'Sekretaris', '081200000003', 'cici@contoh.id'],
  ['Dedi Pratama', 'Staf Umum', '081200000004', 'dedi@contoh.id'], ['Eka Putri', 'Staf Keuangan', '081200000005', 'eka@contoh.id'], ['Fajar Nugroho', 'Teknisi', '081200000006', 'fajar@contoh.id'],
  ['Gita Maharani', 'Resepsionis', '081200000007', 'gita@contoh.id'], ['Hadi Kurniawan', 'Satpam', '081200000008', 'hadi@contoh.id'],
];
const CARI = [
  ['Cari nama', inp('Budi Santoso')], ['Jabatan', '=IFERROR(VLOOKUP(H2;$B$2:$E$30;2;0);"Tidak ditemukan")'], ['Telepon', '=IFERROR(VLOOKUP(H2;$B$2:$E$30;3;0);"Tidak ditemukan")'],
  ['Email', '=IFERROR(VLOOKUP(H2;$B$2:$E$30;4;0);"Tidak ditemukan")'], ['Urutan di daftar', '=IFERROR(MATCH(H2;B2:B30;0);"-")'], ['Jumlah kontak', '=COUNTA(B2:B30)'],
];
const KONTAK = {
  id: 'admin-kontak', name: 'Admin · Kontak dan pencarian', desc: 'Buku kontak; ketik satu nama di kotak kuning, jabatan, telepon, dan emailnya muncul sendiri.',
  tab: 'Kontak', w: [36, 130, 130, 110, 190, 24, 130, 190], head: true, nfc: ['', '', '', '', '', '', '', ''],
  rows: [
    ['No', 'Nama', 'Jabatan', 'Telepon', 'Email', '', 'Pencarian', 'Hasil'],
    ...ORANG.map(([n, j, t, e], i) => { const row = [i + 1, n, j, t, e, '']; if (CARI[i]) row.push(CARI[i][0], CARI[i][1]); return row; }),
  ],
  checks: [{ k: 'email', rg: 'E2:E30' }],
  guide: [
    ['Apa ini?', 'Buku kontak sederhana dengan kotak pencarian. Ketik nama di kotak kuning (H2), hasilnya muncul di bawahnya.'],
    ['Cara pakai', 'Tulis nama PERSIS seperti di daftar (huruf besar kecil tidak dibedakan). Tidak ketemu = tulisan Tidak ditemukan.'],
    ['Menambah kontak', 'Isi baris kosong di bawah (sampai baris 30). Pencarian dan hitungan sudah mencakup sampai baris itu.'],
    ['Email', 'Kolom Email diperiksa: isian yang bukan bentuk email diberi tanda merah. Telepon ditulis sebagai teks supaya angka 0 di depan tetap ada.'],
    ['Rumus', 'VLOOKUP mencari nama di kolom Nama lalu mengambil kolom ke-2, 3, atau 4. MATCH memberi nomor barisnya.'],
  ],
};

export const ADMIN2 = [REKAP, RAPOR, PINJAM, PENJUALAN, KONTAK];
