// Layar Lainnya: tampilan, hari kerja, tempat sampah, cadangan.
import { h, ico, PATH, toast, dlg, infoKey, tInfo, tWarn, tWarnAtas, tOk, tErr } from './ui.js';
import { askExit } from './exit.js';
import { toggleDay, applyDailyReset, restoreFromTrash, backupSummary, sheetCount, backupFileName, backupZipName, replaceData, DAY_NAMES, WEEK_ORDER, validateLabel, removeLabel, labelCounts, moveLabel, newId,
  TRASH_DAYS_OPTIONS, trashDaysText, countExpiredTrash, trashDaysLeft, purgeTrash,
  syncAlarmTheme, BACKUP_MAX, BACKUP_BASE_NAME, BACKUP_KINDS, cleanFolder, nextBackupAt, backupWhere, backupEveryText, formatBackupDate, formatEdited, pushBackupHistory } from './logic.js';
import { runBackup, isBusy } from './backup.js';
import { exportJSON, importJSON } from './storage.js';
import { cleanupOrphanImages, scanImages, clearUnusedImages } from './gambar-app.js';
import * as G from './gambar.js';
import * as LZ from './lembar.js';
import { sheetUsage, unusedSheetIds } from './lembar-siklus.js';
import { openSheet, loadTemplates } from './lembar-pintu.js'; // Rev 192 / P2a: layar lembar + daftar templat dimuat saat dibutuhkan
import { uniqueRefs, writeZipToCache, readBackupFile, writeBackupImages, idsMissingFromZip, restoreImagesFromBackupFolder } from './cadangan-gambar.js';
import { isNative, nativePlugin, syncBars } from './native.js';
import { scheduleReminder, cancelAllReminders, syncAllReminders, syncTaskAlarms } from './reminders.js';
import { syncNoteAlarms, syncAllNoteAlarms } from './cb-alarm.js';
import { cleanUrl, cleanKey, loadConn, saveConn, testConnection, loadDueCache, loadAlarmCfg, cleanCfg, BEFORE_CHOICES } from './twopockets.js';
import { refreshDue, setAlarmEnabled, reapplyAlarms, dropDue, disconnect, describeDue, describeBill, describeDebt, debtKey, billKey, billCfgView, describeCfg, setItemCfg, hhmm, dueStatus, localIso, diagnose } from './tp-alarm.js';
import { syncAlarmSnooze } from './logic.js'; // Rev 389 / TN2 (baris terpisah)
import { SNOOZE_CHOICES } from './logic.js'; // Rev 390 / TN3 (baris terpisah)

export function applyTheme(theme) {
  const r = document.documentElement;
  if (theme === 'light' || theme === 'dark') r.setAttribute('data-theme', theme); else r.removeAttribute('data-theme');
  syncBars();
  syncAlarmTheme(globalThis.AndroidAPI || null, theme); // Rev 379: layar alarm native ikut tema aplikasi
}

// Warna seleksi teks kustom (settings.selColor, '' = bawaan tema). Roda warna dimuat malas dari warna-seleksi.js.
const SEL_RE = /^#[0-9a-f]{6}$/i;
// Rev 389 / TN2: kirim lama Tunda alarm (settings.snoozeMin) ke Android. APK lama tanpa setAlarmSnooze = tidak berbuat apa-apa. UI pemilihnya = TN3.
export function applySnooze(minutes) { return syncAlarmSnooze(globalThis.AndroidAPI || null, minutes); }
export function applySelColor(c) {
  const r = document.documentElement;
  if (typeof c === 'string' && SEL_RE.test(c)) {
    const n = [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
    r.setAttribute('data-sel', ''); r.style.setProperty('--sel', c); r.style.setProperty('--selfg', (0.299 * n[0] + 0.587 * n[1] + 0.114 * n[2]) > 150 ? 'rgb(16,22,43)' : 'white');
  } else { r.removeAttribute('data-sel'); r.style.removeProperty('--sel'); r.style.removeProperty('--selfg'); }
}
function onLongPress(el, fn, ms = 600) {
  let t = 0, x0 = 0, y0 = 0;
  const stop = () => { clearTimeout(t); t = 0; };
  el.addEventListener('pointerdown', (e) => { x0 = e.clientX; y0 = e.clientY; stop(); t = setTimeout(() => { t = 0; try { navigator.vibrate && navigator.vibrate(18); } catch (_) {} fn(); }, ms); });
  el.addEventListener('pointermove', (e) => { if (t && Math.hypot(e.clientX - x0, e.clientY - y0) > 10) stop(); });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach((n) => el.addEventListener(n, stop));
  el.addEventListener('contextmenu', (e) => e.preventDefault());
}

const KIND = { task: 'Tugas', habit: 'Kebiasaan', note: 'Catatan' };
const row = (icon, label, value, onclick, tone) => h('button', { type: 'button', class: 'set', onclick }, h('span', { class: 'si' + (tone ? ' tn-' + tone : '') }, ico(icon)), h('span', { class: 'sl' }, label), value ? h('b', {}, value) : null, h('span', { class: 'chev' }, ico(PATH.chev)));

async function exportBackup(ctx) {
  const text = exportJSON(ctx.data), hasImg = isNative() && uniqueRefs(ctx.data).length > 0; // Rev 44 (G2): ada gambar -> ZIP; tanpa gambar -> JSON persis seperti sebelumnya
  const name = hasImg ? backupZipName() : backupFileName();
  try {
    if (isNative()) {
      const FS = nativePlugin('Filesystem'), SH = nativePlugin('Share');
      let r, miss = 0;
      if (hasImg) { tInfo('Menyiapkan cadangan dengan gambar...'); const z = await writeZipToCache(FS, ctx.data, text, name); r = { uri: z.uri }; miss = z.missing.length; }
      else r = await FS.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
      if (miss) toast(miss + ' gambar tidak ditemukan di HP, jadi tidak ikut dicadangkan.');
      await SH.share({ title: 'Cadangan Notes Kelimaa', files: [r.uri], dialogTitle: 'Simpan cadangan' });
      pushBackupHistory(ctx.data.settings.backup, { at: Date.now(), kind: 'share', ok: true, where: 'Menu Bagikan Android', msg: name }); ctx.persist();
      setTimeout(() => { FS.deleteFile({ path: name, directory: 'CACHE' }).catch(() => {}); }, 120000);
    } else {
      const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
      const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    }
  } catch (e) {
    if (!/cancel/i.test(String((e && e.message) || e))) { console.error('ekspor gagal:', e); toast('Gagal membuat cadangan: ' + String((e && e.message) || e).slice(0, 120)); }
  }
}

export function askExport(ctx) {
  const ni = isNative() ? uniqueRefs(ctx.data).length : 0;
  dlg({ title: 'Ekspor cadangan', msg: 'Berkas cadangan memuat SEMUA data, termasuk catatan privat, dan tidak dienkripsi. Simpan di tempat aman dan jangan dibagikan ke orang lain.' + (ni ? ' Karena ada ' + ni + ' gambar, cadangan dibuat sebagai satu berkas ZIP yang sudah membawa gambarnya.' : ''), yes: 'Lanjut ekspor', ok: () => exportBackup(ctx) });
}

export function pickBackup(ctx) {
  // Rev 44 (G2): menerima JSON lama DAN ZIP baru (ZIP = data.json + gambar/*). Jenis dikenali dari isi berkas, bukan nama.
  const inp = h('input', { type: 'file', accept: 'application/json,.json,application/zip,application/x-zip-compressed,.zip' });
  inp.onchange = async () => {
    const f = inp.files && inp.files[0]; if (!f) return;
    let rb;
    try { rb = await readBackupFile(f); } catch (e) { console.error('baca berkas gagal:', e); toast(String((e && e.message) || 'Gagal membaca berkas.').slice(0, 140)); return; }
    const r = importJSON(rb.text);
    if (!r.ok) { toast(r.msg); return; }
    const s = backupSummary(r.data);
    const shNew = sheetCount(r.data), shOld = sheetCount(ctx.data), shText = shNew || shOld ? ` Lembar kerja: cadangan ${shNew}, di HP ini ${shOld} (ikut diganti).` : ''; // Rev 121
    const refCount = uniqueRefs(r.data).length;
    const imgText = rb.kind === 'zip' ? ` Membawa ${rb.images.length} gambar.` : (refCount ? ` Catatan memakai ${refCount} gambar, tetapi berkas JSON tidak membawa gambarnya (aplikasi mencoba mengambilnya dari folder cadangan otomatis; yang tidak ketemu akan kosong).` : '');
    const doRestore = async () => {
      const native = isNative();
      if (rb.kind === 'zip' && rb.images.length) {
        if (!native) { tWarn('Gambar hanya bisa dipulihkan di aplikasi HP.'); return; }
        try { tInfo('Memulihkan gambar...'); await writeBackupImages(nativePlugin('Filesystem'), f, rb.images); }
        catch (e) { console.error('pulihkan gambar gagal:', e); toast('Gagal memulihkan gambar, data TIDAK diganti: ' + String((e && e.message) || e).slice(0, 100)); return; }
      }
      cancelAllReminders(); replaceData(ctx.data, r.data); ctx.ui.unlocked = false; applyDailyReset(ctx.data);
      syncAllReminders(ctx.data); syncAllNoteAlarms(ctx.data); reapplyAlarms(); ctx.persist(); applyTheme(ctx.data.settings.theme); applySelColor(ctx.data.settings.selColor); applySnooze(ctx.data.settings.snoozeMin); ctx.render(); // Rev 57: cancelAllReminders di atas ikut menghapus alarm Two Pockets
      let say = 'Cadangan dipulihkan.';
      if (rb.kind === 'zip') { const miss = idsMissingFromZip(ctx.data, rb.images).length; if (miss) say += ' ' + miss + ' gambar tidak ada di ZIP.'; }
      else if (native && refCount) { try { const g = await restoreImagesFromBackupFolder(nativePlugin('Filesystem'), ctx.data); say += ` Gambar: ${g.restored + g.present} ada, ${g.missing} tidak ketemu.`; } catch (_) { /* terbaik-usaha */ } }
      toast(say);
    };
    dlg({ title: 'Pulihkan cadangan?', msg: `Berisi ${s.tasks} tugas, ${s.habits} kebiasaan, ${s.notes} catatan, ${s.priv} catatan privat.${shText}${imgText} Data di HP ini akan DIGANTI. Langkah 1 dari 2.`, yes: 'Lanjut',
      ok: () => dlg({ title: 'Yakin ganti semua data?', msg: 'Data sekarang hilang dan diganti isi cadangan. Langkah 2 dari 2.', yes: 'Ganti data', red: true, reverse: true,
        ok: () => { doRestore(); } }) });
  };
  inp.click();
}

function viewTrash(ctx) {
  const { data, ui } = ctx; const s = data.settings;
  const items = data.trash.map((x, i) => ({ x, i })).reverse();
  const setDays = (d) => { s.trashDays = d; const purged = purgeTrash(data); ctx.persist(); ctx.render(); if (purged) cleanupOrphanImages(data).catch(() => {}); toast(d ? 'Dihapus otomatis setelah ' + d + ' hari.' : 'Hapus otomatis dimatikan.'); };
  const pick = (d) => {
    if (d === s.trashDays) return;
    const n = countExpiredTrash(data, d);
    if (!n) { setDays(d); return; }
    dlg({ title: 'Ada yang langsung terhapus', msg: n + ' item di tempat sampah sudah lebih lama dari ' + d + ' hari dan akan dihapus permanen sekarang. Tidak bisa dikembalikan.', yes: 'Hapus dan aktifkan', red: true, reverse: true, ok: () => setDays(d) });
  };
  const autoBtn = (d) => h('button', { type: 'button', class: s.trashDays === d ? 'on' : '', 'aria-pressed': String(s.trashDays === d), onclick: () => pick(d) }, d ? d + ' hari' : 'Mati');
  return [
    h('h1', {}, 'Tempat sampah'), h('p', { class: 'sub' }, 'Pulihkan yang terhapus tak sengaja. Catatan privat tidak masuk sini.'),
    h('h2', {}, 'Kosongkan otomatis'),
    h('div', { class: 'pri' }, TRASH_DAYS_OPTIONS.map(autoBtn)),
    h('p', { class: 'sub' }, s.trashDays ? 'Item yang sudah ' + s.trashDays + ' hari di sini dihapus permanen saat aplikasi dibuka. Yang sudah dihapus tidak bisa dikembalikan.' : 'Mati: item tetap di sini sampai kamu mengosongkannya sendiri.'),
    items.length ? items.map(({ x, i }) => h('div', { class: 'row' },
      h('div', { class: 'tx' }, h('b', {}, (x.item && x.item.title) || 'Tanpa judul'), h('small', {}, (KIND[x.kind] || 'Item') + (trashDaysLeft(x, s.trashDays) ? ' \u00b7 dihapus otomatis ' + trashDaysLeft(x, s.trashDays) + ' hari lagi' : ''))),
      h('button', { type: 'button', class: 'btn alt rest', onclick: () => { if (restoreFromTrash(data, i)) { const restored = data.tasks.find((z) => z.id === x.item.id) || data.notes.find((z) => z.id === x.item.id); if (restored && !restored.done) { if (data.tasks.includes(restored)) syncTaskAlarms(restored); else { if (restored.reminder) scheduleReminder('note', restored); syncNoteAlarms(restored); } } ctx.persist(); ctx.render(); tOk('Dipulihkan.'); } } }, 'Pulihkan')))
      : h('div', { class: 'empty' }, 'Tempat sampah kosong.'),
    items.length ? h('button', { type: 'button', class: 'btn line', onclick: () => dlg({ title: 'Kosongkan tempat sampah?', msg: 'Semua item di sini dihapus permanen.', yes: 'Kosongkan', red: true, ok: () => { data.trash = []; ctx.persist(); ctx.render(); cleanupOrphanImages(data).catch(() => {}); } }) }, 'Kosongkan tempat sampah') : null,
    h('button', { type: 'button', class: 'btn line', onclick: () => { ui.moreView = 'main'; ctx.render(); } }, 'Kembali'),
  ];
}

const LB_TONES = ['v', 't', 'i', 'b', 'o', 'r']; // Rev 174: warna aksen bergilir per baris label / kartu lembar kerja (hanya tampilan)
// Kelola label: tambah, ganti nama, hapus. Menghapus label hanya mencopotnya dari catatan, catatannya tetap ada.
function viewLabels(ctx) {
  const { data, ui } = ctx; const labels = data.settings.labels;
  const use = labelCounts([...data.notes, ...data.priv]);
  const err = h('p', { class: 'err', role: 'alert' });
  const inp = h('input', { class: 'in', maxlength: '20', placeholder: 'Label baru, mis. Kerja', 'aria-label': 'Nama label baru', enterkeyhint: 'done' });
  const add = () => {
    const v = validateLabel(inp.value, labels);
    if (!v.ok) { err.textContent = v.msg; return; }
    labels.push({ id: newId(), name: v.value }); ctx.persist(); ctx.render();
  };
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } });
  const list = h('div', { class: 'lbl' });
  const scrollParent = (el) => { for (let p = el.parentElement; p; p = p.parentElement) { const o = getComputedStyle(p).overflowY; if ((o === 'auto' || o === 'scroll') && p.scrollHeight > p.clientHeight) return p; } return document.scrollingElement || document.documentElement; };
  const refocus = (id) => { try { const b = document.querySelector('[data-lh="' + id + '"]'); if (b) b.focus(); } catch (_) { /* abaikan */ } };
  // Geser urutan: HANYA lewat pegangan (touch-action:none di pegangan, gulir halaman tidak terganggu).
  const startDrag = (e, l, rowEl, hb) => {
    if (e.button > 0 || e.isPrimary === false) return;
    e.preventDefault();
    const rows = [...list.children]; const from = rows.indexOf(rowEl); if (from < 0) return;
    const stride = rows.length > 1 ? (rows[1].offsetTop - rows[0].offsetTop) : rowEl.offsetHeight;
    if (!(stride > 0)) return;
    try { hb.setPointerCapture(e.pointerId); } catch (_) { /* abaikan */ }
    const sc = scrollParent(rowEl); const s0 = sc.scrollTop; const y0 = e.clientY;
    let lastY = y0, to = from, alive = true, raf = 0;
    rowEl.classList.add('drag'); rows.forEach((r) => { if (r !== rowEl) r.classList.add('lbr'); });
    const update = () => {
      const dy = lastY - y0 + (sc.scrollTop - s0);
      to = Math.max(0, Math.min(rows.length - 1, Math.round(from + dy / stride)));
      rowEl.style.transform = `translateY(${dy}px)`;
      rows.forEach((r, k) => { if (r === rowEl) return; const sh = from < to && k > from && k <= to ? -stride : from > to && k < from && k >= to ? stride : 0; r.style.transform = sh ? `translateY(${sh}px)` : ''; });
    };
    const tick = () => {
      if (!alive) return;
      const edge = 70;
      if (lastY < edge) sc.scrollTop -= 10; else if (lastY > innerHeight - edge) sc.scrollTop += 10;
      update(); raf = requestAnimationFrame(tick);
    };
    const mv = (ev) => { lastY = ev.clientY; update(); };
    const done = (ev) => {
      if (!alive) return; alive = false; cancelAnimationFrame(raf);
      hb.removeEventListener('pointermove', mv); hb.removeEventListener('pointerup', done); hb.removeEventListener('pointercancel', done);
      try { hb.releasePointerCapture(e.pointerId); } catch (_) { /* abaikan */ }
      if (ev.type === 'pointerup' && moveLabel(labels, l.id, to)) ctx.persist();
      ctx.render();
    };
    hb.addEventListener('pointermove', mv); hb.addEventListener('pointerup', done); hb.addEventListener('pointercancel', done);
    update(); raf = requestAnimationFrame(tick);
  };
  const rowFor = (l, i) => {
    const nm = h('input', { class: 'in lbin', maxlength: '20', value: l.name, 'aria-label': 'Nama label ' + l.name });
    nm.addEventListener('change', () => {
      const v = validateLabel(nm.value, labels, l.id);
      if (!v.ok) { toast(v.msg); nm.value = l.name; return; }
      l.name = v.value; nm.value = v.value; ctx.persist(); tOk('Nama label diganti.');
    });
    const hb = h('button', { type: 'button', class: 'ghost lbh', 'data-lh': l.id, 'aria-label': 'Geser urutan label ' + l.name + '. Pakai panah atas atau bawah untuk memindahkan.',
      onkeydown: (ev) => { const d = ev.key === 'ArrowUp' ? -1 : ev.key === 'ArrowDown' ? 1 : 0; if (!d) return; ev.preventDefault(); if (moveLabel(labels, l.id, i + d)) { ctx.persist(); ctx.render(); refocus(l.id); } } }, ico(PATH.rows));
    const rowEl = h('div', { class: 'row lbrow tn-' + LB_TONES[i % LB_TONES.length] }, hb, nm, h('small', { class: 'lbn' }, (use[l.id] || 0) + ' catatan'),
      h('button', { type: 'button', class: 'ghost lbx', 'aria-label': 'Hapus label ' + l.name, onclick: () => dlg({ title: 'Hapus label?',
        msg: `Label \u201c${l.name}\u201d dicopot dari ${use[l.id] || 0} catatan. Catatannya tidak ikut terhapus.`, yes: 'Hapus label', red: true,
        ok: () => { removeLabel(data, l.id); ctx.persist(); ctx.render(); tOk('Label dihapus.'); } }) }, ico(PATH.bin)));
    hb.addEventListener('pointerdown', (ev) => startDrag(ev, l, rowEl, hb));
    return rowEl;
  };
  return [
    h('h1', {}, 'Label catatan'), h('p', { class: 'sub' }, 'Satu catatan bisa punya beberapa label. Ganti nama dengan mengetuk namanya. Geser pegangan \u2261 untuk mengatur urutan; urutan ini dipakai di deretan penyaring dan pemilih label.'),
    h('div', { class: 'cpr lbadd' }, inp, h('button', { type: 'button', class: 'btn cpb', onclick: add }, 'Tambah')), err,
    labels.length ? (list.append(...labels.map(rowFor)), list) : h('div', { class: 'empty' }, 'Belum ada label.'),
    h('button', { type: 'button', class: 'btn line', onclick: () => { ui.moreView = 'main'; ctx.render(); } }, 'Kembali'),
  ];
}


// Cadangan otomatis (Rev 17): jadwal (minggu/bulan), lokasi (folder induk + nama folder), tombol cadangkan sekarang, riwayat.
function lastOk(b) { return b.lastAt || 0; }
function viewBackup(ctx) {
  const { data, ui } = ctx; const b = data.settings.backup;
  const native = isNative();
  const again = () => ctx.render();
  const save = () => { ctx.persist(); again(); };
  const num = h('input', { class: 'in', style: 'width:92px;margin:0;flex:none', type: 'number', inputmode: 'numeric', min: '1', max: String(BACKUP_MAX[b.unit]), value: String(b.every), 'aria-label': 'Jumlah ' + (b.unit === 'month' ? 'bulan' : 'minggu') });
  // Kolom ketik hanya menyimpan + memperbarui teks (TANPA gambar ulang layar): gambar ulang saat kolom kehilangan fokus
  // bisa menelan ketukan tombol berikutnya di HP.
  const sumEvery = h('p', { class: 'sub' }), sumWhere = h('p', { class: 'sub' });
  const refresh = () => {
    sumEvery.textContent = backupEveryText(b) + ' (maks. ' + BACKUP_MAX[b.unit] + ' ' + (b.unit === 'month' ? 'bulan' : 'minggu') + ').';
    sumWhere.textContent = 'Disimpan ke: ' + backupWhere(b) + '/. ' + (b.base === 'documents'
      ? 'Folder Dokumen biasanya tetap ada walau aplikasi dicopot (belum diuji di HP-mu).'
      : 'Folder aplikasi ikut terhapus saat aplikasi dicopot, jadi tidak cocok untuk update APK.');
  };
  refresh();
  num.addEventListener('change', () => {
    const v = Math.floor(Number(num.value));
    if (Number.isFinite(v)) b.every = Math.min(Math.max(v, 1), BACKUP_MAX[b.unit]);
    num.value = String(b.every); ctx.persist(); refresh();
  });
  const unitBtn = (u, label) => h('button', { type: 'button', class: b.unit === u ? 'on' : '', 'aria-pressed': String(b.unit === u),
    onclick: () => { b.unit = u; b.every = Math.min(b.every, BACKUP_MAX[u]); save(); } }, label);
  const baseBtn = (k) => h('button', { type: 'button', class: b.base === k ? 'on' : '', 'aria-pressed': String(b.base === k), onclick: () => { b.base = k; save(); } }, BACKUP_BASE_NAME[k]);
  const folder = h('input', { class: 'in', maxlength: '60', value: b.folder, 'aria-label': 'Nama folder cadangan', enterkeyhint: 'done' });
  folder.addEventListener('change', () => {
    const v = cleanFolder(folder.value);
    if (!v.ok) { toast(v.msg); folder.value = b.folder; return; }
    b.folder = v.value; folder.value = v.value; ctx.persist(); refresh();
  });
  const turnOn = () => dlg({ title: 'Nyalakan cadangan otomatis?',
    msg: 'Berkas cadangan memuat SEMUA data, termasuk catatan privat, dan tidak dienkripsi. Berkas di ' + backupWhere(b) + ' bisa dibaca aplikasi pengelola berkas. Cadangan pertama dibuat sekarang untuk mencoba lokasinya.', yes: 'Nyalakan',
    ok: async () => {
      b.on = true; ctx.persist();
      const r = await runBackup(ctx, 'manual');
      if (!r.ok) { b.on = false; ctx.persist(); toast('Gagal menyimpan ke ' + backupWhere(b) + ': ' + r.msg); } else toast('Tersimpan di ' + r.where);
      again();
    } });
  const nowBtn = async () => {
    if (isBusy()) return;
    const r = await runBackup(ctx, 'manual');
    toast(r.ok ? 'Tersimpan di ' + r.where : 'Gagal: ' + r.msg); again();
  };
  const next = nextBackupAt(b);
  const hist = b.history.slice(0, 10);
  return [
    h('h1', {}, 'Cadangan otomatis'),
    h('p', { class: 'sub' }, 'Aplikasi menyimpan cadangan sendiri saat dibuka dan sudah waktunya. Kalau aplikasi lama tidak dibuka, cadangan baru dibuat saat dibuka lagi.'),
    native ? null : h('div', { class: 'notice' }, 'Di peramban, cadangan ke folder tidak jalan. Fitur ini hanya aktif di aplikasi HP.'),
    h('div', { class: 'pri' },
      h('button', { type: 'button', class: !b.on ? 'on' : '', 'aria-pressed': String(!b.on), onclick: () => { if (b.on) { b.on = false; save(); } } }, 'Mati'),
      h('button', { type: 'button', class: b.on ? 'on' : '', 'aria-pressed': String(b.on), onclick: () => { if (!b.on) { if (!native) tWarn('Hanya jalan di aplikasi HP.'); else turnOn(); } } }, 'Hidup')),
    h('h2', {}, 'Seberapa sering'),
    h('div', { class: 'cpr' }, num, h('div', { class: 'pri', style: 'flex:1;margin:0' }, unitBtn('week', 'Minggu'), unitBtn('month', 'Bulan'))),
    sumEvery,
    h('h2', {}, 'Lokasi penyimpanan'),
    h('div', { class: 'pri' }, baseBtn('documents'), baseBtn('app')),
    folder,
    sumWhere,
    h('button', { type: 'button', class: 'btn', disabled: native ? false : true, onclick: nowBtn }, 'Cadangkan sekarang'),
    h('h2', {}, 'Riwayat'),
    h('p', { class: 'sub' }, lastOk(b) ? 'Terakhir dicadangkan: ' + formatEdited(lastOk(b)) + ' (' + formatBackupDate(lastOk(b)) + ')' : 'Belum pernah dicadangkan ke folder.'),
    b.on ? h('p', { class: 'sub' }, next && next > Date.now() ? 'Cadangan berikutnya: ' + formatBackupDate(next) : 'Cadangan berikutnya: saat aplikasi dibuka lagi.') : null,
    hist.length ? hist.map((x) => h('div', { class: 'row' },
      h('div', { class: 'tx' }, h('b', {}, (x.ok ? 'Berhasil' : 'Gagal') + ' \u00b7 ' + (BACKUP_KINDS[x.kind] || x.kind)),
        h('small', {}, formatBackupDate(x.at) + ' \u00b7 ' + x.where), x.msg ? h('small', {}, x.msg) : null)))
      : h('div', { class: 'empty' }, 'Belum ada riwayat.'),
    h('button', { type: 'button', class: 'btn line', onclick: () => { ui.moreView = 'main'; ctx.render(); } }, 'Kembali'),
  ];
}

// Rev 64: TWO POCKETS dirombak jadi RUANG sendiri (hanya daftar jatuh tempo + alarm). Sambungan (alamat + passcode) pindah ke
// tombol gerigi di pojok kanan atas ruang itu (layar 'tpconn'). Logika alarm/sambungan TIDAK berubah, hanya tampilan dan rute.
const TP_STEP = { input: 'Isian', ping: 'Langkah 1 \u00b7 Alamat', whoami: 'Langkah 2 \u00b7 Passcode' };
const TP_ST = { terlambat: ['late', 'Terlambat'], segera: ['soon', 'Segera'], aman: ['ok', 'Aman'], belum: ['none', 'Belum terjadwal'] };
const TP_RANK = { terlambat: 0, segera: 1, aman: 2, belum: 3 };
// pindah layar Two Pockets/Sambungan/Setelan lalu gulir ke atas (render() tidak mengembalikan gulir, jadi judul ruang tidak terpotong)
const tpGo = (ctx, view) => { ctx.ui.moreView = view; ctx.render(); const m = document.querySelector('#app > main'); if (m) m.scrollTop = 0; };
let tpForce = false; // setelah Simpan sambungan: muat ulang daftar begitu ruang dibuka
const tpHead = (left, title, right) => h('div', { class: 'tphead' }, left, h('h1', { class: 'tptitle' }, title), right || h('span', { class: 'tpsp', 'aria-hidden': 'true' }));
const tpRound = (icon, label, onclick) => h('button', { type: 'button', class: 'tpround', 'aria-label': label, onclick }, ico(icon));
const stripSt = (s) => String(s).replace(/^(Terlambat|Segera|Aman|Belum terjadwal) \u00b7 /, '').replace(/^./, (c) => c.toUpperCase());
const splitAlarm = (s) => { const i = s.search(/ \u00b7 (alarm|tanpa alarm)/); return i < 0 ? [s, ''] : [s.slice(0, i), s.slice(i + 3).replace(/^./, (c) => c.toUpperCase())]; };

function viewTwoPockets(ctx) {
  const { ui } = ctx; const saved = loadConn();
  const back = tpRound(PATH.back, 'Kembali', () => tpGo(ctx, 'main'));
  const gear = tpRound(PATH.lainnya, 'Pengaturan sambungan', () => tpGo(ctx, 'tpconn'));
  const head = [tpHead(back, 'TWO POCKETS', gear), h('p', { class: 'tpsubt' }, 'Servis, pajak, tagihan & utang')];
  if (!saved) {
    return [...head, h('div', { class: 'tphero tpempty' },
      h('div', { class: 'tpbig' }, ico(PATH.wallet)), h('b', {}, 'Belum tersambung'),
      h('p', {}, 'Sambungkan ke Two Pockets untuk melihat jatuh tempo servis, pajak, tagihan, dan utang/piutang di sini, lengkap dengan alarmnya.'),
      h('button', { type: 'button', class: 'btn', onclick: () => tpGo(ctx, 'tpconn') }, 'Atur sambungan'))];
  }
  // Diperbarui di tempat, tanpa ctx.render() (kolom dan tombol tidak berkedip).
  const stats = h('div', { class: 'tpstats' }); const note = h('span', { class: 'tpupd' }, ''); const list = h('div', { class: 'tplist' });
  const alarmOn = () => { const c = loadDueCache(); return !c || c.alarm; };
  // Rev 72: sakelar utama (satu-satunya tempat menyalakan/mematikan SEMUA alarm). Status dibaca dari kata + warna + posisi sakelar.
  const swEl = () => h('span', { class: 'tpsw', 'aria-hidden': 'true' }, h('i', {}));
  const mSub = h('small', {}, ''); const mSw = swEl();
  const alarmBtn = h('button', { type: 'button', class: 'tpalarm', role: 'switch', 'aria-label': 'Alarm jatuh tempo (semua)', onclick: () => {
    const on = !alarmOn(); const r = setAlarmEnabled(on); paintMaster();
    on && r.alarm.reason === 'permission' ? infoKey('izin', 'Alarm sudah dinyalakan, tetapi belum bisa berbunyi') : toast(on ? 'Alarm dinyalakan.' : 'Alarm dimatikan.');
  } }, h('span', { class: 'tpal-ic' }, ico(PATH.alarm)), h('span', { class: 'tpal-tx' }, h('b', {}, 'Alarm jatuh tempo'), mSub), mSw);
  const paintMaster = () => {
    const on = alarmOn(); alarmBtn.classList.toggle('off', !on); alarmBtn.setAttribute('aria-checked', String(on));
    mSub.textContent = on ? 'Nyala \u00b7 pengingat aktif' : 'Mati \u00b7 tidak ada yang berbunyi';
    list.classList.toggle('gmoff', !on);
  };
  const refLabel = h('span', {}, 'Muat ulang');
  let dueBusy = false;
  const dueBtn = h('button', { type: 'button', class: 'tprefresh', onclick: () => doRefresh() }, ico(PATH.refresh), refLabel);
  async function doRefresh() {
    if (dueBusy) return; dueBusy = true; dueBtn.disabled = true; refLabel.textContent = 'Memuat\u2026';
    try {
      const r = await refreshDue({ force: true }); paint();
      if (!r.ok) toast(r.reason === 'noconn' ? 'Simpan sambungan dulu.' : (r.msg || 'Gagal memuat.'));
      else if (r.alarm && r.alarm.reason === 'permission') infoKey('izin', 'Daftar sudah dimuat, tetapi alarm belum terpasang');
      else if (r.alarm && r.alarm.warning === 'inexact_alarm') infoKey('alarmTepat');
    } catch (e) { infoKey('muatGagal'); }
    dueBusy = false; dueBtn.disabled = false; refLabel.textContent = 'Muat ulang';
  }
  // Satu kartu jatuh tempo. cfgKey = ada sakelar + Atur jadwal (servis/pajak/utang); tagihan juga (sejak Rev 73).
  const chip = (t, cls) => h('span', { class: 'tpchip' + (cls ? ' ' + cls : '') }, t);
  const cfgRow = (e, cfgs) => {
    const [cls, lbl] = TP_ST[e.st] || TP_ST.belum;
    const sum = h('div', { class: 'tpsum' });
    const card = h('div', { class: 'tpcard ' + cls },
      h('div', { class: 'tpc-top' }, h('span', { class: 'tpbadge' }, ico(e.icon)),
        h('div', { class: 'tpc-tx' }, h('b', { class: 'tpc-t' }, e.title), h('span', { class: 'tpc-s' }, e.meta)), h('span', { class: 'tppill' }, lbl)),
      h('div', { class: 'tpc-al' }, h('span', { class: 'tpal-b' }, ico(PATH.alarm)), sum));
    if (!e.cfgKey) { sum.append(h('span', { class: 'tpsum-t' }, e.alarm)); return card; }
    const key = e.cfgKey;
    const curCfg = () => (e.cfgOf ? e.cfgOf(loadAlarmCfg()) : cleanCfg(loadAlarmCfg()[key]));
    const itemSw = h('button', { type: 'button', class: 'tpsw-btn', role: 'switch', 'aria-label': 'Alarm item ini' }, swEl());
    const drawSum = () => {
      const c = curCfg(); sum.textContent = '';
      card.classList.toggle('alarmoff', !c.on); itemSw.setAttribute('aria-checked', String(c.on));
      if (!c.on) { sum.append(h('span', { class: 'tpsum-t' }, 'Alarm mati')); return; }
      sum.append(chip(hhmm(c), 'tm'));
      if (c.mode === 'alarm') sum.append(h('span', { class: 'tpchip alm' }, ico(PATH.alarm), 'Alarm berdering')); // Rev 382 / AL3b-4 (4B): chip alarm berlatar solid + ikon jam alarm
      sum.append(...c.before.map((n) => chip(n === 0 ? 'Hari-H' : 'H-' + n)));
      if (!c.before.length) sum.append(h('span', { class: 'tpsum-t' }, 'tanpa pengingat sebelum'));
      if (c.late) sum.append(chip('Ulang bila terlambat', 'rp'));
      sum.append(chip('Tertahan \u00b7 alarm utama mati', 'hold'));
    };
    itemSw.onclick = () => {
      const c = curCfg(); const r = setItemCfg(key, { ...c, on: !c.on });
      if (!r.ok) { tErr('Gagal menyimpan di HP.'); return; }
      drawSum();
      !c.on && r.alarm && r.alarm.reason === 'permission' ? infoKey('izin', 'Alarm item sudah dinyalakan, tetapi belum bisa berbunyi') : toast(!c.on ? 'Alarm item dinyalakan.' : 'Alarm item dimatikan.');
    };
    card.querySelector('.tpc-al').append(itemSw);
    drawSum();
    const ed = h('div', { class: 'tpcfg' }); ed.hidden = true;
    const atBtn = h('button', { type: 'button', class: 'tpat', 'aria-expanded': 'false', onclick: () => {
      ed.hidden = !ed.hidden; atBtn.setAttribute('aria-expanded', String(!ed.hidden)); card.classList.toggle('open', !ed.hidden);
      if (!ed.hidden) buildEd(); else ed.textContent = '';
    } }, ico(PATH.clock), h('span', {}, 'Atur jadwal'), ico(PATH.chevDown));
    const closeEd = () => { ed.hidden = true; ed.textContent = ''; atBtn.setAttribute('aria-expanded', 'false'); card.classList.remove('open'); };
    const buildEd = () => {
      const cur = curCfg(); let late = cur.late; const sel = new Set(cur.before);
      const time = h('input', { class: 'in', type: 'time', value: hhmm(cur), 'aria-label': 'Jam alarm' });
      const timeFld = h('div', { class: 'tpfld' }, h('span', { class: 'tpfi', 'aria-hidden': 'true' }, ico(PATH.clock)), time, h('span', { class: 'tpfc', 'aria-hidden': 'true' }, ico(PATH.chevDown)));
      const dayBtns = BEFORE_CHOICES.map((n) => { const b = h('button', { type: 'button', class: 'tpday' + (sel.has(n) ? ' on' : ''), 'aria-pressed': String(sel.has(n)), onclick: () => {
        if (sel.has(n)) sel.delete(n); else sel.add(n); b.classList.toggle('on', sel.has(n)); b.setAttribute('aria-pressed', String(sel.has(n)));
      } }, n === 0 ? 'Hari-H' : n + ' hari'); return b; });
      const lateSw = h('button', { type: 'button', class: 'tpopt', role: 'switch', 'aria-checked': String(late), onclick: () => { late = !late; lateSw.setAttribute('aria-checked', String(late)); } },
        h('span', { class: 'tpoi', 'aria-hidden': 'true' }, ico(PATH.refresh)), h('span', { class: 'tpopt-t' }, h('b', {}, 'Ulangi tiap hari'), h('small', {}, e.lateLabel.replace(/^Ingatkan tiap hari /, 'Bila ').replace(/^Bila bila/, 'Bila'))), swEl());
      let mode = cur.mode === 'alarm' ? 'alarm' : 'notif'; // Rev 382 / AL3b-4 (4B): satu mode per item; mati = Notifikasi biasa
      const almSw = h('button', { type: 'button', class: 'tpopt tpalm', role: 'switch', 'aria-checked': String(mode === 'alarm'), onclick: () => {
        mode = mode === 'alarm' ? 'notif' : 'alarm'; almSw.setAttribute('aria-checked', String(mode === 'alarm'));
        if (mode !== 'alarm') return;
        import('./alarm-ui.js').then((A) => { if (mode !== 'alarm') return; if (A.alarmUnsupported()) tWarnAtas('Versi aplikasi ini belum mendukung alarm berdering. Pengingat berbunyi sebagai notifikasi biasa.'); else A.askFullScreen(); }).catch(() => { /* pemilih tetap jalan tanpa dialog izin */ });
      } }, h('span', { class: 'tpoi', 'aria-hidden': 'true' }, ico(PATH.alarm)), h('span', { class: 'tpopt-t' }, h('b', {}, 'Alarm berdering'), h('small', {}, 'Berdering seperti jam alarm sampai dimatikan. Mati = notifikasi biasa.')), swEl());
      const save = h('button', { type: 'button', class: 'btn', onclick: () => {
        const m = /^(\d{1,2}):(\d{2})$/.exec(time.value || '');
        if (!m) { tWarn('Isi jam alarm dulu.'); return; }
        const on = curCfg().on;
        const r = setItemCfg(key, { on, late, before: [...sel], hour: Number(m[1]), min: Number(m[2]), mode: mode === 'alarm' ? 'alarm' : undefined }); // Rev 382 / AL3b-4: mode dari sakelar (cleanCfg hanya menyimpan 'alarm')
        if (!r.ok) { tErr('Gagal menyimpan di HP.'); return; }
        drawSum();
        closeEd();
        r.alarm && r.alarm.reason === 'permission' ? infoKey('izin', 'Jadwal tersimpan, tetapi alarm belum bisa berbunyi') : toast(r.alarm === null ? 'Tersimpan. Alarm utama sedang mati.' : 'Jadwal alarm disimpan.');
      } }, 'Simpan jadwal');
      const cancel = h('button', { type: 'button', class: 'btn line tpcancel', onclick: closeEd }, 'Batal');
      ed.textContent = '';
      ed.append(h('div', { class: 'tplbl' }, 'Jam alarm'), timeFld, h('div', { class: 'tplbl' }, 'Ingatkan sebelum jatuh tempo'),
        h('div', { class: 'tpdays', role: 'group', 'aria-label': 'Hari sebelum jatuh tempo' }, dayBtns), h('div', { class: 'tpopts' }, almSw, lateSw), h('div', { class: 'tpacts' }, cancel, save));
    };
    card.append(atBtn, ed);
    return card;
  };
  const paint = () => {
    const c = loadDueCache(); list.textContent = ''; stats.textContent = '';
    if (!c || !c.fetchedAt) { stats.hidden = true; note.textContent = 'Belum dimuat. Ketuk "Muat ulang".'; return; }
    const cfgs = loadAlarmCfg(); const today = localIso();
    const lateOpt = 'Ingatkan tiap hari bila terlambat';
    const servis = c.items.map((it) => ({ st: dueStatus('item', it, today), icon: it.kind === 'pajak' ? PATH.cal : PATH.tool, cfgKey: it.id, lateLabel: 'Ingatkan tiap hari bila terlambat / km menipis',
      title: (it.kind === 'pajak' ? 'Pajak' : 'Servis') + ' \u00b7 ' + (it.vehicle ? it.vehicle + ' \u00b7 ' : '') + it.name, meta: stripSt(describeDue(it)) }));
    const utang = (c.debts || []).map((d) => ({ st: dueStatus('debt', d, today), icon: PATH.wallet, cfgKey: debtKey(d.id), lateLabel: lateOpt,
      title: (d.kind === 'utang' ? 'Utang ke ' : 'Piutang dari ') + d.person, meta: stripSt(describeDebt(d, today)) }));
    const tagihan = (c.bills || []).map((b) => { const [m] = splitAlarm(stripSt(describeBill(b))); const amount = b.amount ? ' \u00b7 Rp' + Number(b.amount).toLocaleString('id-ID') : '';
      return { st: dueStatus('bill', b, today), icon: PATH.receipt, cfgKey: billKey(b.id), cfgOf: (all) => billCfgView(b, all), lateLabel: lateOpt, title: 'Tagihan \u00b7 ' + b.name, meta: m + amount }; });
    const all = [...servis, ...tagihan, ...utang]; const n = (k) => all.filter((e) => e.st === k).length;
    note.textContent = 'Diperbarui ' + new Date(c.fetchedAt).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    if (!all.length) {
      stats.hidden = true;
      list.append(h('div', { class: 'tphero tpempty' }, h('div', { class: 'tpbig' }, ico(PATH.star)), h('b', {}, 'Semua tenang'),
        h('p', {}, 'Belum ada servis, pajak, tagihan, atau utang/piutang berjatuh tempo di Two Pockets.')));
      return;
    }
    stats.hidden = false;
    [['late', 'Terlambat', n('terlambat')], ['soon', 'Segera', n('segera')], ['ok', 'Aman', n('aman') + n('belum')]].forEach(([k, t, v]) => stats.append(h('div', { class: 'tpstat ' + k }, h('b', {}, String(v)), h('span', {}, t))));
    const group = (title, arr) => {
      if (!arr.length) return;
      list.append(h('div', { class: 'tpsec' }, title, h('i', {}, String(arr.length))));
      arr.slice().sort((a, b) => (TP_RANK[a.st] ?? 3) - (TP_RANK[b.st] ?? 3)).forEach((e) => list.append(cfgRow(e, cfgs)));
    };
    group('Servis & pajak', servis); group('Tagihan', tagihan); group('Utang & piutang', utang);
  };
  paint(); paintMaster();
  const c0 = loadDueCache();
  if (!(c0 && c0.fetchedAt) || tpForce) { tpForce = false; doRefresh(); }
  // Rev 74: tombol master pemeriksaan notifikasi (izin, alarm tepat waktu, alarm utama, jumlah alarm terpasang) + notifikasi tes 10 detik.
  const ckOut = h('div', { class: 'tpck-out' }); ckOut.hidden = true;
  const ckBtn = h('button', { type: 'button', class: 'tpck-btn', onclick: () => {
    const r = diagnose(); ckOut.textContent = ''; ckOut.hidden = false;
    const row = (ok, text, extra) => ckOut.append(h('div', { class: 'tpck ' + (ok === true ? 'ok' : ok === false ? 'bad' : 'warn') }, h('span', { class: 'tpck-m', 'aria-hidden': 'true' }, ok === true ? '\u2713' : ok === false ? '\u2715' : '!'), h('span', { class: 'tpck-t' }, text), ...(extra ? [extra] : [])));
    const when = (t) => new Date(t).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    if (!r.native) row(null, 'Pemeriksaan notifikasi hanya jalan di aplikasi Android.');
    else {
      if (r.notif === 'ok') row(true, 'Notifikasi diizinkan.');
      else if (r.notif === 'denied') row(false, 'Notifikasi untuk Notes dimatikan. Buka Info aplikasi > Notifikasi lalu aktifkan.');
      else row(false, 'Notifikasi tes gagal dipasang.');
      if (r.exact === true) row(true, 'Alarm tepat waktu diizinkan.');
      else if (r.exact === false) row(false, 'Alarm tepat waktu belum diizinkan, alarm bisa telat.', h('button', { type: 'button', class: 'tpck-go', onclick: () => { try { (globalThis.AndroidAPI || globalThis.KelimaaNative).openExactAlarmSettings(); } catch (_) { /* abaikan */ } } }, 'Buka pengaturan'));
    }
    row(r.connected, r.connected ? 'Tersambung ke Two Pockets.' : 'Belum tersambung ke Two Pockets.');
    row(r.fetchedAt ? true : false, r.fetchedAt ? 'Daftar terakhir dimuat ' + when(r.fetchedAt) + '.' : 'Daftar belum pernah dimuat. Tekan Muat ulang.');
    row(r.master, r.master ? 'Alarm utama nyala.' : 'Alarm utama mati. Nyalakan sakelar di atas.');
    if (r.master && r.fetchedAt) {
      if (!r.planned) row(null, 'Belum ada alarm yang perlu dipasang (jadwal sudah lewat atau alarm tiap item mati).');
      else if (!r.installed) row(false, r.planned + ' alarm seharusnya ada tetapi belum terpasang. Tekan Muat ulang.');
      else row(true, r.installed + ' alarm terpasang. Berikutnya: ' + when(r.next.at) + ' \u00b7 ' + r.next.title);
    }
    if (r.testAt) ckOut.append(h('p', { class: 'tpck-note' }, 'Notifikasi tes muncul sekitar 10 detik lagi. Kunci layar atau keluar dari Notes supaya jelas terlihat. Kalau tidak muncul padahal semua centang, di HP Xiaomi aktifkan Mulai otomatis dan atur Penghemat baterai ke Tanpa batasan.'));
  } }, h('span', { class: 'tpck-ic' }, ico(PATH.alarm)), h('span', { class: 'tpck-tx' }, h('b', {}, 'Cek semua notifikasi'), h('small', {}, 'Periksa izin dan kirim notifikasi tes 10 detik')));
  return [...head,
    h('div', { class: 'tphero' }, stats, alarmBtn, h('div', { class: 'tpbar' }, note, dueBtn)),
    h('div', { class: 'tpck-wrap' }, ckBtn, ckOut),
    list,
    h('p', { class: 'sub tpfoot' }, 'Sakelar di atas mengatur semua alarm; tiap kartu punya sakelar sendiri. Servis/pajak: jam dan hari dapat diatur per item. Utang/piutang yang punya tanggal jatuh tempo: jam dan hari juga dapat diatur per catatan. Tagihan: mengikuti hari dan jam pengingat yang diatur di Two Pockets. Maksimal 60 alarm gabungan; yang waktunya paling dekat diprioritaskan. Daftar dimuat saat aplikasi dibuka (paling sering tiap 3 jam, perlu internet).'),
  ];
}

// Rev 64: layar Sambungan (alamat web app + passcode + tes). Dibuka dari gerigi di ruang TWO POCKETS.
function viewTpConn(ctx) {
  const { ui } = ctx; const native = isNative(); const saved = loadConn();
  const toRoom = () => tpGo(ctx, 'twopockets');
  const url = h('input', { class: 'in', type: 'url', inputmode: 'url', autocomplete: 'off', autocapitalize: 'none', spellcheck: 'false', placeholder: 'https://script.google.com/macros/s/\u2026/exec', value: saved ? saved.url : '', 'aria-label': 'Alamat web app Two Pockets' });
  const key = h('input', { class: 'in', type: 'password', autocomplete: 'off', placeholder: 'Passcode RAMA atau DESY', value: saved ? saved.key : '', 'aria-label': 'Passcode Two Pockets' });
  const out = h('div', {});
  let busy = false, lastMe = saved ? saved.me : '';
  const show = (res) => {
    out.textContent = '';
    res.steps.forEach((x) => out.append(h('div', { class: 'row' }, h('div', { class: 'tx' }, h('b', {}, (x.ok ? 'Berhasil' : 'Gagal') + ' \u00b7 ' + (TP_STEP[x.id] || x.id)), h('small', {}, x.msg)))));
  };
  // Kolom ketik tidak memicu gambar ulang layar (alasan sama dengan layar Cadangan otomatis).
  const testBtn = h('button', { type: 'button', class: 'btn', onclick: async () => {
    if (busy) return;
    busy = true; testBtn.disabled = true; testBtn.textContent = 'Menguji\u2026'; out.textContent = '';
    try {
      const res = await testConnection({ url: url.value, key: key.value });
      lastMe = res.ok ? res.me : ''; show(res);
    } catch (e) { show({ steps: [{ id: 'input', ok: false, msg: 'Terjadi gangguan saat menguji sambungan. Periksa koneksi, lalu coba lagi.' }] }); }
    busy = false; testBtn.disabled = false; testBtn.textContent = 'Tes sambungan';
  } }, 'Tes sambungan');
  const saveBtn = h('button', { type: 'button', class: 'btn line', onclick: () => {
    const u = cleanUrl(url.value), k = cleanKey(key.value);
    if (!u.ok) { toast(u.msg); return; } if (!k.ok) { toast(k.msg); return; }
    if (saved && (saved.url !== u.value || saved.key !== k.value)) dropDue(); // alamat/passcode berubah: daftar dan alarm lama bukan milik sambungan ini lagi
    const r = saveConn({ url: u.value, key: k.value, me: lastMe, testedAt: lastMe ? Date.now() : 0 });
    toast(r.ok ? 'Sambungan disimpan di HP ini.' : r.msg);
    if (r.ok) { tpForce = true; toRoom(); } // lanjut ke ruang dan muat daftarnya
  } }, 'Simpan sambungan');
  const dropBtn = saved ? h('button', { type: 'button', class: 'btn line', onclick: () => dlg({ title: 'Putuskan Two Pockets?', msg: 'Alamat, passcode, daftar servis/pajak, dan alarmnya dihapus dari HP ini. Isi aplikasi ini tidak berubah.', yes: 'Putuskan',
    ok: () => { disconnect(); tOk('Sambungan dan alarm Two Pockets dihapus.'); toRoom(); } }) }, 'Putuskan sambungan') : null;
  return [
    tpHead(tpRound(PATH.back, 'Kembali', toRoom), 'SAMBUNGAN'),
    h('p', { class: 'tpsubt' }, 'TWO POCKETS'),
    h('p', { class: 'sub' }, 'Opsional. Aplikasi hanya MEMBACA daftar jatuh tempo servis, pajak, tagihan, serta utang/piutang dari Two Pockets, lalu memasang alarm. Tidak ada catatan atau tugas yang dikirim.'),
    h('p', { class: 'sub' }, 'Alamat dan passcode disimpan di HP ini saja dan tidak ikut berkas cadangan. Setelah memulihkan cadangan, isi lagi.'),
    native ? null : h('div', { class: 'notice' }, 'Di peramban, tes ini bisa gagal karena aturan keamanan peramban. Hasil yang benar hanya di aplikasi HP.'),
    h('div', { class: 'tpform' }, h('h2', {}, 'Alamat web app Two Pockets'), url, h('h2', {}, 'Passcode'), key, testBtn, out),
    h('p', { class: 'sub' }, saved ? 'Tersimpan di HP ini' + (saved.me ? ' \u00b7 terakhir terbukti sebagai ' + saved.me : '') + '.' : 'Belum ada sambungan tersimpan.'),
    saveBtn, dropBtn,
    h('button', { type: 'button', class: 'btn line', onclick: toRoom }, 'Kembali'),
  ];
}

// Rev 60 (G4): Setelan > Gambar. Kualitas untuk gambar BARU, pemakaian, dan pembersihan berkas tak terpakai.
function viewImages(ctx) {
  const { data, ui } = ctx; const s = data.settings, native = isNative();
  const q = G.QUALITY_KEYS.includes(s.imageQuality) ? s.imageQuality : G.DEFAULT_PRESET;
  const hint = h('p', { class: 'sub qhint' }, G.qualityHint(q) + (q === G.DEFAULT_PRESET ? ' (bawaan)' : ''));
  const qBtn = (k) => h('button', { type: 'button', class: q === k ? 'on' : '', 'aria-pressed': String(q === k), onclick: () => { if (k === q) return; s.imageQuality = k; ctx.persist(); ctx.render(); toast('Kualitas ' + G.PRESETS[k].name + ' dipakai untuk gambar baru.'); } }, G.PRESETS[k].name);
  const usedUsage = G.usageOf(G.refsOfData(data));
  const vUsed = h('b', {}, usedUsage.count + ' gambar \u00b7 ' + G.formatBytes(usedUsage.bytes));
  const vDisk = h('b', {}, native ? 'Menghitung...' : 'Hanya di aplikasi HP');
  const vFree = h('b', {}, native ? 'Menghitung...' : '-');
  const note = h('p', { class: 'sub' }, '');
  const clear = h('button', { type: 'button', class: 'btn line', disabled: true }, 'Bersihkan gambar tak terpakai');
  let busy = false;
  const refresh = async () => {
    if (!native) return;
    try {
      const sum = await scanImages(data);
      if (!clear.isConnected) return; // layar sudah ditinggalkan
      vDisk.textContent = sum.diskCount + ' berkas \u00b7 ' + G.formatBytes(sum.diskBytes);
      vFree.textContent = sum.orphans.length ? sum.orphans.length + ' berkas \u00b7 ' + G.formatBytes(sum.orphanBytes) : 'Tidak ada';
      clear.disabled = busy || !sum.orphans.length;
      note.textContent = (sum.missing ? sum.missing + ' gambar dipakai catatan tetapi berkasnya tidak ketemu di HP (mungkin hilang setelah pasang ulang; pulihkan dari cadangan ZIP). ' : '') + (G.totalWarning(sum.diskBytes) || '');
    } catch (_) { vDisk.textContent = 'Tidak terbaca'; vFree.textContent = '-'; }
  };
  clear.onclick = () => dlg({ title: 'Bersihkan gambar tak terpakai?', msg: 'Yang dihapus hanya berkas gambar yang tidak dipakai catatan mana pun, termasuk catatan di tempat sampah dan catatan privat. Gambar yang baru ditambahkan kurang dari 5 menit lalu dilewati. Tidak bisa dikembalikan.', yes: 'Bersihkan', red: true,
    ok: async () => {
      busy = true; clear.disabled = true;
      try { const r = await clearUnusedImages(data); toast(r.removed ? r.removed + ' berkas dihapus, ' + G.formatBytes(r.freed) + ' lega.' : 'Tidak ada yang dihapus.'); }
      catch (_) { tErr('Gagal membersihkan gambar.'); }
      busy = false; refresh();
    } });
  setTimeout(refresh, 0);
  return [h('div', { class: 'gambarset' },
    h('h1', {}, 'Gambar'),
    h('p', { class: 'sub' }, 'Gambar di catatan dikecilkan saat ditambahkan, supaya catatan tetap ringan dan cadangan tidak membengkak.'),
    h('h2', {}, 'Kualitas gambar baru'),
    h('div', { class: 'pri', role: 'group', 'aria-label': 'Kualitas gambar baru' }, G.QUALITY_KEYS.map(qBtn)),
    hint,
    h('p', { class: 'sub' }, 'Berlaku untuk gambar yang ditambahkan SESUDAH ini. Gambar lama tidak dikompres ulang.'),
    h('h2', {}, 'Pemakaian'),
    h('div', { class: 'stat' }, h('span', {}, 'Dipakai catatan'), vUsed),
    h('div', { class: 'stat' }, h('span', {}, 'Tersimpan di HP'), vDisk),
    h('div', { class: 'stat' }, h('span', {}, 'Tidak terpakai'), vFree),
    note, clear,
    h('button', { type: 'button', class: 'btn line', onclick: () => { ui.moreView = 'main'; ctx.render(); } }, 'Kembali'))]; // larik, seperti layar Setelan lain (render() meratakan larik)
}

// Rev 115 / U7a-2a: daftar lembar kerja + Buat baru + buka layar penuh (baca saja; edit sel = U7a-2b). Pintu masuk sementara sampai U7b (pulau di catatan).
function viewSheets(ctx) {
  const { data, ui } = ctx; const ids = Object.keys(data.sheets || {}).sort((a, b) => (data.sheets[b].at || 0) - (data.sheets[a].at || 0));
  const open = (id) => { try { openSheet({ sheet: data.sheets[id], usedIn: sheetUsage(data)[id] || 0, onChange: () => ctx.persist(), onDelete: (sh) => { delete data.sheets[sh.id]; ctx.persist(); ctx.render(); tOk('Lembar kerja dihapus.'); }, onClose: () => ctx.render() }).catch(() => tErr('Lembar kerja gagal dibuka.')); } catch (_) { tErr('Lembar kerja gagal dibuka.'); } };
  const create = () => {
    if (ids.length >= LZ.MAX_SHEETS) { infoKey('maks', 'lembar kerja', LZ.MAX_SHEETS, 'Hapus lembar kerja yang tidak dipakai, lalu coba lagi.'); return; }
    const sh = LZ.newSheet({ name: 'Lembar kerja ' + (ids.length + 1) });
    while (data.sheets[sh.id]) sh.id = 's' + Math.random().toString(36).slice(2, 8);
    data.sheets[sh.id] = sh; ctx.persist(); ctx.render(); open(sh.id);
  };
  // Rev 180 / U10d-1: Buat dari templat. Dialog daftar templat (Bahasa Indonesia); memilih satu membuat lembar kerja BARU berisi contoh, lalu membukanya. Tidak menyentuh lembar lain.
  let TPL = null; const makeFromTemplate = (tid) => (TPL ? TPL.makeFromTemplate(tid) : null); // Rev 192 / P2a: modul templat diisi pickTemplate sebelum ada ketukan templat
  const fromTemplate = (tid) => {
    if (ids.length >= LZ.MAX_SHEETS) { infoKey('maks', 'lembar kerja', LZ.MAX_SHEETS, 'Hapus lembar kerja yang tidak dipakai, lalu coba lagi.'); return; }
    const r = makeFromTemplate(tid); if (!r) { tErr('Templat gagal dibuat.'); return; }
    const sh = r.sheet; while (data.sheets[sh.id]) sh.id = 's' + Math.random().toString(36).slice(2, 8);
    data.sheets[sh.id] = sh; ctx.persist(); ctx.render(); open(sh.id);
  };
  const pickTemplate = () => { loadTemplates().then((m) => { TPL = m; showTemplates(m.templateList); }).catch(() => tErr('Templat gagal dimuat.')); };
  const showTemplates = (templateList) => {
    const ov = h('div', { class: 'ov dlgov' });
    const items = templateList().map((t) => h('button', { type: 'button', class: 'tplc', onclick: () => { ov.remove(); fromTemplate(t.id); } },
      h('span', { class: 'tpli', 'aria-hidden': 'true' }, ico(PATH.flow)), h('span', { class: 'tplt' }, h('b', {}, t.name), h('small', {}, t.desc))));
    ov.append(h('div', { class: 'sheet dlg tpldlg' }, h('h3', {}, 'Buat dari templat'), h('p', { class: 'sub' }, 'Lembar kerja baru berisi contoh yang sudah berumus. Ganti isinya sesuai kebutuhanmu.'),
      h('div', { class: 'tpls' }, items), h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal'))));
    document.body.append(ov);
  };
  const use = sheetUsage(data), unused = unusedSheetIds(data); // Rev 125 / U7b-4
  const kb = Math.round(ids.reduce((a, id) => a + LZ.sheetBytes(data.sheets[id]), 0) / 1024);
  const clean = () => dlg({ title: 'Hapus lembar tidak terpakai?', msg: unused.length + ' lembar kerja tidak dipakai di catatan mana pun (termasuk Tempat sampah) dan akan dihapus PERMANEN. Lembar yang dipakai tidak disentuh.', yes: 'Hapus', red: true, reverse: true,
    ok: () => { unused.forEach((id) => { delete data.sheets[id]; }); ctx.persist(); ctx.render(); toast(unused.length + ' lembar kerja dihapus.'); } });
  const items = ids.map((id, i) => { const sh = data.sheets[id]; return h('button', { type: 'button', class: 'lzc tn-' + LB_TONES[i % LB_TONES.length], onclick: () => open(id) },
    h('span', { class: 'lzi' }, ico(PATH.flow)),
    h('span', { class: 'lzt' }, h('span', { class: 'lzn' }, sh.name),
      h('span', { class: 'lzm' }, h('span', { class: 'lzp' }, sh.tabs.length + ' tab'), h('span', { class: 'lzp ' + (use[id] ? 'use' : 'off') }, (use[id] ? 'dipakai di ' + use[id] + ' catatan' : 'tidak dipakai')))),
    h('span', { class: 'lzgo' }, ico(PATH.chev))); });
  const usedN = ids.filter((id) => use[id]).length; const pct = ids.length ? Math.round(usedN / ids.length * 100) : 0; // Rev 174: ringkasan di atas daftar
  const stat = (v, l) => h('div', { class: 'lzs' }, h('b', {}, String(v)), h('span', {}, l));
  return [h('div', { class: 'lembarset' },
    h('h1', {}, 'Lembar kerja'),
    h('p', { class: 'sub' }, 'Ketuk sel untuk memilih, lalu isi lewat kolom di bawah (Enter atau centang untuk menyimpan). Ada tab, lebar kolom yang bisa diseret, gaya sel, dan Urungkan/Ulangi.'),
    ids.length ? h('div', { class: 'lzhero' }, stat(ids.length, 'Lembar'), stat(usedN, 'Dipakai'), stat(kb + ' KB', 'Ukuran'),
      h('div', { class: 'lzbar', role: 'img', 'aria-label': usedN + ' dari ' + ids.length + ' lembar dipakai di catatan' }, h('i', { style: 'width:' + pct + '%' }))) : null,
    ids.length ? h('div', { class: 'lzcards' }, items) : h('div', { class: 'empty' }, 'Belum ada lembar kerja.'),
    ids.length ? h('p', { class: 'cap' }, 'Memakai sekitar ' + kb + ' KB dari ruang simpan aplikasi (dibagi dengan semua catatan).') : null,
    unused.length ? h('button', { type: 'button', class: 'btn line lzclean', onclick: clean }, ico(PATH.bin), 'Hapus ' + unused.length + ' lembar tidak terpakai') : null,
    h('button', { type: 'button', class: 'btn lzadd', onclick: create }, h('span', { class: 'lzplus', 'aria-hidden': 'true' }, '+'), 'Buat lembar kerja baru'),
    h('button', { type: 'button', class: 'btn line lztpl', onclick: pickTemplate }, ico(PATH.flow), 'Buat dari templat'),
    h('button', { type: 'button', class: 'btn line', onclick: () => { ui.moreView = 'main'; ctx.render(); } }, 'Kembali'))];
}

// Rev 201 / Kelimaa AI: layar dimuat MALAS (import()); ubin hanya membaca dua kunci localStorage.
let aiMod = null, aiLoading = false;
export function viewKelimaaAI(ctx) {
  // Rev 215: dipanggil dari tab AI di bilah bawah; layar awal = chat bila sudah tersambung dan menyala, selain itu layar sambungan.
  if (ctx.ui.tab === 'ai' && ctx.ui.moreView !== 'ai' && ctx.ui.moreView !== 'aichat') ctx.ui.moreView = aiReady() ? 'aichat' : 'ai';
  if (aiMod) return ctx.ui.moreView === 'aichat' ? aiMod.viewChat(ctx) : aiMod.viewAI(ctx);
  if (!aiLoading) {
    aiLoading = true;
    import('./ai/layar.js').then((m) => { aiMod = m; aiLoading = false; if (ctx.ui.moreView === 'ai' || ctx.ui.moreView === 'aichat') ctx.render(); },
      () => { aiLoading = false; tErr('Layar Kelimaa AI gagal dibuka.'); if (ctx.ui.moreView === 'ai' || ctx.ui.moreView === 'aichat') { ctx.ui.moreView = 'main'; ctx.render(); } });
  }
  return [h('h1', {}, 'Kelimaa AI'), h('p', { class: 'sub' }, 'Memuat\u2026')];
}
function aiReady() {
  try {
    const c = JSON.parse(localStorage.getItem('kelimaa_ai_conn') || 'null'), g = JSON.parse(localStorage.getItem('kelimaa_ai_cfg') || 'null');
    return !!(c && c.url) && !!(g && g.on === true);
  } catch (_) { return false; }
}

let pjMod = null, pjBusy = false; // Rev 235: layar Proyek dimuat MALAS (import() dinamis)
function viewProyek(ctx) {
  if (pjMod) return pjMod.viewProyek(ctx);
  const done = (ok) => { pjBusy = false; if (ctx.ui.moreView !== 'proyek') return; if (!ok) { tErr('Layar Proyek gagal dibuka.'); ctx.ui.moreView = 'main'; } ctx.render(); };
  if (!pjBusy) { pjBusy = true; import('./proyek-ui.js').then((m) => { pjMod = m; done(true); }, () => done(false)); }
  return [h('h1', {}, 'Proyek'), h('p', { class: 'sub' }, 'Memuat\u2026')];
}

function tpSetCard(ctx, conn) {
  // Rev 410: kartu TWO POCKETS memakai logo lingkaran + hati dan tulisan dari web app Two Pockets (img/tp-logo.png, img/tp-teks.png),
  // titik status hijau berdenyut (tersambung) / merah berkedip (belum), dan ditaruh di bawah kartu Notes Kelimaa.
  const c = conn ? loadDueCache() : null, cnt = { terlambat: 0, segera: 0, aman: 0 };
  if (c && c.fetchedAt) { const t = localIso(); [['item', c.items], ['bill', c.bills], ['debt', c.debts]].forEach(([k, a]) => (a || []).forEach((x) => { const d = dueStatus(k, x, t); cnt[cnt[d] === undefined ? 'aman' : d]++; })); }
  const noSave = { draggable: 'false', style: '-webkit-touch-callout:none;-webkit-user-select:none;user-select:none' };
  return h('button', { type: 'button', class: 'tp2' + (conn ? '' : ' off'), 'aria-label': 'Two Pockets, ' + (conn ? 'tersambung' + (conn.me ? ', ' + conn.me : '') : 'belum tersambung'), onclick: () => tpGo(ctx, 'twopockets') },
    h('span', { class: 'tp2-top' }, h('img', { class: 'tp2-logo', src: 'img/tp-logo.png', alt: '', ...noSave }),
      h('span', { class: 'tp2-tx' }, h('img', { class: 'tp2-word', src: 'img/tp-teks.png', alt: 'Two Pockets', ...noSave }),
        h('span', { class: 'tp2-st' }, h('i', { class: 'tp2-dot', 'aria-hidden': 'true' }), h('span', {}, h('em', {}, conn ? 'Tersambung' : 'Belum tersambung'), conn && conn.me ? ' \u00b7 ' + conn.me : ''))),
      h('span', { class: 'tp2-go' }, ico(PATH.chev))),
    c && c.fetchedAt ? h('span', { class: 'tp2-stats' }, [['l', 'Terlambat'], ['s', 'Segera'], ['a', 'Aman']].map(([k, t]) => h('span', { class: k }, h('b', {}, String(cnt[t.toLowerCase()])), t))) : null);
}

// Rev 412 (S1): layar Sync (Cadangkan / Pulihkan) = modul malas `sync-ui.js`, pola sama dengan layar AI.
let syncMod = null, syncLoading = false;
function viewSyncLazy(ctx) {
  if (syncMod) return syncMod.viewSync(ctx);
  if (!syncLoading) {
    syncLoading = true;
    import('./sync-ui.js').then((m) => { syncMod = m; syncLoading = false; if (ctx.ui.moreView === 'sync') ctx.render(); },
      () => { syncLoading = false; tErr('Layar Sync gagal dibuka.'); if (ctx.ui.moreView === 'sync') { ctx.ui.moreView = 'main'; ctx.render(); } });
  }
  return [h('h1', {}, 'SYNC'), h('div', { class: 'empty' }, 'Memuat...')];
}

export function viewSettings(ctx) {
  const { data, ui } = ctx; const s = data.settings;
  if (ui.moreView === 'trash') return viewTrash(ctx);
  if (ui.moreView === 'labels') return viewLabels(ctx);
  if (ui.moreView === 'backup') return viewBackup(ctx);
  if (ui.moreView === 'twopockets') return viewTwoPockets(ctx);
  if (ui.moreView === 'tpconn') return viewTpConn(ctx);
  if (ui.moreView === 'gambar') return viewImages(ctx);
  if (ui.moreView === 'lembar') return viewSheets(ctx);
  if (ui.moreView === 'proyek') return viewProyek(ctx);
  if (ui.moreView === 'sync') return viewSyncLazy(ctx); // Rev 412 (S1): layar Sync dimuat malas
  const themeBtn = (v, label, icon) => h('button', { type: 'button', class: s.theme === v ? 'on' : '', 'aria-label': label, 'aria-pressed': String(s.theme === v), onclick: () => { s.theme = v; ctx.persist(); applyTheme(v); ctx.render(); } }, ico(icon), h('span', {}, label));
    const snzBtn = (m) => h('button', { type: 'button', class: s.snoozeMin === m ? 'on' : '', 'aria-pressed': String(s.snoozeMin === m), 'aria-label': 'Tunda ' + m + ' menit',
    onclick: () => { if (s.snoozeMin === m) return; s.snoozeMin = m; ctx.persist(); const ok = applySnooze(m); ctx.render(); ok ? tOk('Tunda alarm: ' + m + ' menit.') : tInfo('Tunda ' + m + ' menit tersimpan. Berlaku setelah APK terbaru terpasang.'); } }, m + ' mnt');
  const dayBtn = (d) => h('button', { type: 'button', class: s.days.includes(d) ? 'on' : '', 'aria-pressed': String(s.days.includes(d)),
    onclick: () => { s.days = toggleDay(s.days, d); applyDailyReset(data); ctx.persist(); ctx.render(); } }, DAY_NAMES[d]);
  // Rev 173: Setelan = hero + strip tema + hari kerja + kolase ubin (desain E). Fungsi ubin = baris lama.
  const tile = (cls, icon, tone, label, value, onclick, extra) => h('button', { type: 'button', class: 'mzt ' + cls, onclick },
    h('span', { class: 'si tn-' + tone }, ico(icon)),
    h('span', { class: 'mzl' }, h('b', {}, label), value ? h('small', {}, value) : null, extra || null));
  const bk = s.backup; const conn = loadConn();
  const row = (ic, tn, lb, v, onclick) => h('button', { type: 'button', class: 'mzr', onclick }, h('span', { class: 'si tn-' + tn }, ico(ic)), h('span', { class: 'mzl' }, h('b', {}, lb), h('small', {}, v)), h('span', { class: 'mzc' }, ico(PATH.chev)));
  const stat = (n, lb, onclick) => h('button', { type: 'button', class: 'mzn', onclick }, h('b', {}, String(n)), h('span', {}, lb));
  const go = (v, pid) => () => { ui.moreView = v; if (pid) ui.projectId = ''; ctx.render(); };
  const nLab = s.labels.length, nSheet = Object.keys(data.sheets || {}).length, nProj = (data.projects || []).length, nTrash = data.trash.length;
  return [
    h('h1', {}, 'Setelan'),
    h('div', { class: 'sethero mzhero' }, (() => { const im = h('img', { src: 'img/logo-keluar.png', alt: '', draggable: 'false', style: '-webkit-touch-callout:none;-webkit-user-select:none;user-select:none' }); onLongPress(im, () => import('./warna-seleksi.js').then((m) => m.openSelColorPicker(s.selColor, (c) => { s.selColor = c; applySelColor(c); ctx.persist(); toast(c ? 'Warna seleksi disimpan' : 'Warna seleksi dikembalikan ke bawaan'); }), () => tErr('Roda warna gagal dibuka.'))); return im; })(), h('b', {}, 'Notes Kelimaa'), h('span', {}, 'Made with love, just for someone special 💗'),
      h('div', { class: 'mzstat' },
        stat(nLab, 'label', go('labels')),
        stat(nSheet, 'lembar', go('lembar')),
        stat(nProj, 'proyek', go('proyek', 1)),
        stat(nTrash, 'sampah', go('trash')))),
    tpSetCard(ctx, conn),
    h('div', { class: 'mzg' },
      h('div', { class: 'mzcard mzthema' }, h('span', { class: 'mzh' }, 'Tema'),
        h('div', { class: 'seg3 mzs', role: 'group', 'aria-label': 'Tema' }, themeBtn('auto', 'Otomatis', PATH.auto), themeBtn('light', 'Terang', PATH.sun), themeBtn('dark', 'Gelap', PATH.moon))),
      h('button', { type: 'button', class: 'mzcard mzcad', onclick: go('backup') },
        h('span', { class: 'mzh' }, 'Cadangan otomatis'),
        h('span', { class: 'mzpill ' + (bk.on ? 'on' : 'off') }, bk.on ? backupEveryText(bk) : 'Mati'),
        h('small', { class: 'mzx ' + (bk.lastAt ? 'ok' : 'no') }, bk.lastAt ? 'Terakhir: ' + formatEdited(bk.lastAt) : 'Belum dicadangkan'))),
    h('div', { class: 'mzwrap' }, h('div', { class: 'daycard' },
      h('div', { class: 'pri days', role: 'group', 'aria-label': 'Hari kerja' }, WEEK_ORDER.map(dayBtn)),
      h('p', { class: 'cap' }, 'Kebiasaan Harian hanya ditagih dan dikosongkan lagi di hari yang dinyalakan.'))),
    h('div', { class: 'mzwrap' }, h('div', { class: 'daycard snzcard' }, h('span', { class: 'mzh' }, 'Tunda alarm'),
      h('div', { class: 'pri days', role: 'group', 'aria-label': 'Lama Tunda alarm' }, SNOOZE_CHOICES.map(snzBtn)),
      h('p', { class: 'cap' }, 'Alarm berdering lagi setelah selang ini saat diketuk Tunda. Bawaan 10 menit.'))),
    h('div', { class: 'mzlist' },
      row(PATH.tag, 'v', 'Label catatan', nLab + ' label', go('labels')),
      row(PATH.photo, 't', 'Gambar', G.PRESETS[G.QUALITY_KEYS.includes(s.imageQuality) ? s.imageQuality : G.DEFAULT_PRESET].name, go('gambar')),
      row(PATH.flow, 'i', 'Lembar kerja', nSheet + ' lembar', go('lembar')),
      row(PATH.proyek, 'v', 'Proyek', nProj + ' proyek', go('proyek', 1)),
      row(PATH.star, 't', 'Panduan ketikan cepat', 'Catatan contoh', () => import('./panduan-ketik.js').then((m) => m.bukaPanduan(ctx), () => tErr('Panduan gagal dibuka.'))),
      row(PATH.bin, 'r', 'Tempat sampah', nTrash + ' item' + (s.trashDays ? ' \u00b7 ' + s.trashDays + ' hari' : ''), go('trash')),
      row(PATH.refresh, 'b', 'Sync', 'Cadangkan & pulihkan, tanpa internet', go('sync'))),
    h('div', { class: 'mz' },
      tile('wide quit', PATH.power, 'o', 'Tutup aplikasi', '', () => askExit(ctx))),
    h('p', { class: 'foot' }, '✦ Notes Kelimaa v0.3.121 ✦'),
  ];
}
