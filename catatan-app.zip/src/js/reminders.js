// Rev 21: pengingat berbasis jembatan AndroidAPI (AlarmManager + NotificationManager).
import { parseAlarmId } from './ingatkan.js';
import { cleanMode, pushSchedule, withMode } from './logic.js';
export const DAY_MS = 24 * 60 * 60 * 1000;
export function normalizeReminder(r) {
  if (!r || typeof r !== 'object') return null;
  const at = Number(r.at);
  const repeat = r.repeat === 'daily' ? 'daily' : 'once';
  return Number.isFinite(at) && at > 0 ? withMode({ at, repeat }, r.mode) : null; // Rev 378 / AL2: `mode` hanya ada bila 'alarm'
}
export function nextReminderAt(r, now = Date.now()) {
  const x = normalizeReminder(r); if (!x) return 0;
  if (x.repeat === 'once') return x.at > now ? x.at : 0;
  if (x.at > now) return x.at;
  return x.at + (Math.floor((now - x.at) / DAY_MS) + 1) * DAY_MS;
}
export function reminderId(kind, id) { return `${kind}:${id}`; }
function api() { return globalThis.AndroidAPI || globalThis.KelimaaNative || null; }
export function cancelReminder(kind, itemId) {
  try { const a = api(); if (a && typeof a.cancelScheduledNotification === 'function') a.cancelScheduledNotification(reminderId(kind, itemId)); } catch (e) { console.warn('Pembatalan pengingat gagal', e); }
}
export function scheduleReminder(kind, item, now = Date.now()) {
  const r = normalizeReminder(item && item.reminder); if (!r) { cancelReminder(kind, item && item.id); return { ok: true, skipped: true }; }
  const at = nextReminderAt(r, now);
  if (!at) { cancelReminder(kind, item.id); return { ok: true, expired: true }; }
  const a = api();
  if (!a || typeof a.scheduleNotification !== 'function') return { ok: false, reason: 'unavailable' };
  try {
    const delay = Math.max(1000, at - now);
    const title = (item.title || 'Pengingat Notes Kelimaa').slice(0, 80);
    const message = kind === 'task' ? 'Waktunya mengerjakan tugas.' : 'Ada catatan yang ingin kamu ingat.';
    const { res: result, fellBack } = pushSchedule(a, reminderId(kind, item.id), title, message, delay, r.repeat === 'daily' ? DAY_MS : 0, r.mode);
    const fb = fellBack ? { alarmFallback: true } : {};
    if (result === 'inexact_alarm') return { ok: true, warning: 'inexact_alarm', ...fb };
    if (result === 'permission_denied') { try { a.requestNotificationPermission?.(); } catch (_) {} return { ok: false, reason: 'permission' }; }
    if (result === 'error') return { ok: false, reason: 'native_error' };
    return { ok: true, mode: result || 'scheduled', ...fb };
  } catch (e) { return { ok: false, reason: String(e && e.message || e) }; }
}
// ---- Rev 68: pengingat per sub-tugas. ID native = `sub:<idTugas>:<idSub>`; id dari newId() tidak memuat ':'. ----
export function subReminderKey(taskId, subId) { return taskId + ':' + subId; }
export function cancelSubReminder(taskId, subId) { cancelReminder('sub', subReminderKey(taskId, subId)); }
export function cancelTaskAlarms(task) {
  if (!task) return;
  cancelReminder('task', task.id);
  for (const sb of Array.isArray(task.subs) ? task.subs : []) if (sb && sb.id) cancelSubReminder(task.id, sb.id);
}
export function scheduleSubReminder(task, sub, now = Date.now()) {
  const r = normalizeReminder(sub && sub.reminder);
  if (!r || sub.done) { cancelSubReminder(task.id, sub.id); return { ok: true, skipped: true }; }
  const at = nextReminderAt(r, now);
  if (!at) { cancelSubReminder(task.id, sub.id); return { ok: true, expired: true }; }
  const a = api();
  if (!a || typeof a.scheduleNotification !== 'function') return { ok: false, reason: 'unavailable' };
  try {
    const delay = Math.max(1000, at - now);
    const title = String(sub.title || 'Sub-tugas').slice(0, 80);
    const message = ('Sub-tugas dari: ' + String(task.title || 'tugas')).slice(0, 120);
    const { res: result, fellBack } = pushSchedule(a, reminderId('sub', subReminderKey(task.id, sub.id)), title, message, delay, r.repeat === 'daily' ? DAY_MS : 0, r.mode);
    const fb = fellBack ? { alarmFallback: true } : {};
    if (result === 'inexact_alarm') return { ok: true, warning: 'inexact_alarm', ...fb };
    if (result === 'permission_denied') { try { a.requestNotificationPermission?.(); } catch (_) {} return { ok: false, reason: 'permission' }; }
    if (result === 'error') return { ok: false, reason: 'native_error' };
    return { ok: true, mode: result || 'scheduled', ...fb };
  } catch (e) { return { ok: false, reason: String(e && e.message || e) }; }
}
// Menjadwalkan ulang SEMUA alarm satu tugas sesuai mode (langsung di tugas / di tiap sub-tugas). Alarm yang tidak dipakai dibatalkan.
export function syncTaskAlarms(task, now = Date.now()) {
  const results = [];
  if (!task) return results;
  if (task.done) { cancelTaskAlarms(task); return results; }
  const subsMode = task.remMode === 'subs' && Array.isArray(task.subs) && task.subs.length > 0;
  if (subsMode) {
    cancelReminder('task', task.id);
    for (const sb of task.subs) { const r = scheduleSubReminder(task, sb, now); if (r.expired) delete sb.reminder; results.push(r); }
  } else {
    for (const sb of Array.isArray(task.subs) ? task.subs : []) if (sb && sb.id) cancelSubReminder(task.id, sb.id);
    if (task.reminder) { const r = scheduleReminder('task', task, now); if (r.expired) delete task.reminder; results.push(r); }
    else cancelReminder('task', task.id);
  }
  return results;
}
// Teks pendek untuk chip: "Hari ini 16:00", "Besok 08:00", "8 Nov 16:00", "Tiap hari 08:00", "Terlewat".
const BLN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
export function describeReminder(r, now = Date.now()) {
  const x = normalizeReminder(r); if (!x) return '';
  const d = new Date(x.at), p2 = (n) => String(n).padStart(2, '0');
  const jam = p2(d.getHours()) + ':' + p2(d.getMinutes());
  if (x.repeat === 'daily') return 'Tiap hari ' + jam;
  if (x.at <= now) return 'Terlewat';
  const day = (t) => { const z = new Date(t); z.setHours(0, 0, 0, 0); return z.getTime(); };
  const diff = Math.round((day(x.at) - day(now)) / DAY_MS);
  if (diff === 0) return 'Hari ini ' + jam;
  if (diff === 1) return 'Besok ' + jam;
  return d.getDate() + ' ' + BLN[d.getMonth()] + (d.getFullYear() !== new Date(now).getFullYear() ? ' ' + d.getFullYear() : '') + ' ' + jam;
}
export function cancelAllReminders() {
  try { const a = api(); if (a && typeof a.cancelAllScheduledNotifications === 'function') a.cancelAllScheduledNotifications(); } catch (e) { console.warn('Pembatalan semua pengingat gagal', e); }
}
export function syncAllReminders(data, now = Date.now()) {
  const results = [];
  for (const x of data.tasks || []) {
    if (x.done) { cancelTaskAlarms(x); continue; }
    const hasSubAlarm = Array.isArray(x.subs) && x.subs.some((sb) => sb && sb.reminder);
    if (x.reminder || hasSubAlarm) results.push(...syncTaskAlarms(x, now));
  }
  for (const x of data.notes || []) if (x.reminder) { const r = scheduleReminder('note', x, now); if (r.expired) delete x.reminder; results.push(r); }
  return results;
}
export function toLocalInput(ts) {
  if (!ts) return '';
  const d = new Date(ts - new Date(ts).getTimezoneOffset() * 60000);
  return d.toISOString().slice(0, 16);
}
export function fromLocalInput(value) {
  if (!value) return 0;
  const n = new Date(value).getTime(); return Number.isFinite(n) ? n : 0;
}

export function takeOpenedReminder(root = globalThis) {
  try {
    const a = root.AndroidAPI || root.KelimaaNative;
    return a && typeof a.takeReminder === 'function' ? String(a.takeReminder() || '') : '';
  } catch (_) { return ''; }
}
export function installReminderInbox(ctx, openTask, openNote, openTp) {
  const pull = () => {
    const id = takeOpenedReminder(); if (!id) return false;
    const cut = id.indexOf(':'); if (cut < 1) return false;
    const kind = id.slice(0, cut), itemId = id.slice(cut + 1);
    // Rev 57: alarm jatuh tempo Two Pockets (tp:<id>:<w|d|n>) membuka layar Two Pockets
    if (kind === 'tp' || kind === 'tpb' || kind === 'tpd') { if (typeof openTp !== 'function') return false; openTp(); return true; }
    if (kind === 'task') {
      const item = ctx.data.tasks.find((x) => x.id === itemId && !x.done);
      if (!item) return false;
      openTask(item); return true;
    }
    if (kind === 'sub') { // Rev 68: sub:<idTugas>:<idSub> membuka tugas dengan daftar sub-tugasnya terbuka
      const c2 = itemId.indexOf(':'); if (c2 < 1) return false;
      const item = ctx.data.tasks.find((x) => x.id === itemId.slice(0, c2) && !x.done);
      if (!item) return false;
      openTask(item, itemId.slice(c2 + 1)); return true;
    }
    if (kind === 'note') {
      const item = ctx.data.notes.find((x) => x.id === itemId);
      if (!item) return false;
      openNote(item); return true;
    }
    if (kind === 'cb' || kind === 'cd') { // Rev 102 / U5b: cb:<idCatatan>:<cid>[:mN] dan cd:<idCatatan>:<bid>:<n> membuka catatannya (hanya catatan biasa)
      const pa = parseAlarmId(id); if (!pa) return false;
      const item = ctx.data.notes.find((x) => x.id === pa.noteId);
      if (!item) return false;
      openNote(item); return true;
    }
    return false;
  };
  globalThis.__kelimaaReminderOpened = pull;
  pull();
  return pull;
}
