// Validasi data per tab lembar kerja (MURNI: tanpa DOM, penyimpanan, native, eval; tanpa impor). Rincian bentuk data + sejarah: PROMPT_SERAH_TERIMA.md bagian 29 dan banner Rev 266-271.
// tab.checks = [{ id, c, k, items, rg?, cl?, dd?, mode?, ...kriteria }], maks. 10. k: 'list' (items maks. 20 x 40 huruf) | 'has' 'hasnot' 'same' (v) | 'email' | 'url' | 'num' 'date' (op, a, b).
// rg = { c2, r1?, r2? } (tanpa rg = kolom penuh); cl = warna per pilihan; dd:false = tanpa panah (Rev 276: mode 'tolak' DIHAPUS, data lama dibersihkan; aturan boleh kembar/beririsan). Non-daftar: items:[], dd:false. Kosong selalu sah. Hasil = tampilan/penjaga saja.
export const MAX_CHECKS = 10, MAX_ITEMS = 20, MAX_ITEM_LEN = 40;
const RID = /^[a-z0-9]{4,24}$/;
const norm = (s) => String(s).trim().toLowerCase();

// Teks bebas (satu pilihan per baris, atau dipisah koma / titik koma) -> daftar pilihan bersih. Selalu array (boleh kosong).
export function itemsFromText(text) {
  if (typeof text !== 'string') return [];
  return cleanItems(text.split(/[\n\r,;]+/));
}
export function cleanItems(raw) {
  const out = [], seen = new Set(); if (!Array.isArray(raw)) return out;
  for (const x of raw) {
    if (out.length >= MAX_ITEMS) break;
    if (typeof x !== 'string' && !(typeof x === 'number' && Number.isFinite(x))) continue;
    const t = String(x).trim().slice(0, MAX_ITEM_LEN).trim(); if (!t) continue;
    const k = norm(t); if (seen.has(k)) continue; seen.add(k); out.push(t);
  }
  return out;
}
// --- Rev 270 / V5a: kriteria selain daftar (MURNI) ---
export const KINDS = ['list', 'has', 'hasnot', 'same', 'email', 'url', 'num', 'date', 'box']; // Rev 303a: 'box' = kotak centang (nilai sel boolean true/false; kosong = belum dicentang)
export const NUM_OPS = ['gt', 'ge', 'lt', 'le', 'eq', 'ne', 'bt', 'nb'];
export const DATE_OPS = ['ok', 'eq', 'bf', 'af', 'obf', 'oaf', 'bt', 'nb'];
export const MAX_V_LEN = 60, MAX_SERIAL = 2958465;
const NUM_LABEL = { gt: 'lebih dari', ge: 'lebih dari atau sama dengan', lt: 'kurang dari', le: 'kurang dari atau sama dengan', eq: 'sama dengan', ne: 'tidak sama dengan', bt: 'antara', nb: 'tidak di antara' };
const DATE_LABEL = { ok: 'tanggal yang valid', eq: 'tanggal sama dengan', bf: 'tanggal sebelum', af: 'tanggal setelah', obf: 'tanggal pada atau sebelum', oaf: 'tanggal pada atau setelah', bt: 'tanggal di antara', nb: 'tanggal tidak di antara' };
export const kindLabel = (k, op) => (k === 'list' ? 'Daftar pilihan' : k === 'has' ? 'Teks berisi' : k === 'hasnot' ? 'Teks tidak berisi' : k === 'same' ? 'Teks sama persis' : k === 'email' ? 'Email valid' : k === 'url' ? 'URL valid' : k === 'box' ? 'Kotak centang' : k === 'num' ? 'Angka ' + (NUM_LABEL[op] || '') : k === 'date' ? (DATE_LABEL[op] || 'Tanggal') : '').trim();
// Banyak operan (angka/tanggal) yang dibutuhkan operator: 0, 1, atau 2.
export const operands = (op) => (op === 'ok' ? 0 : op === 'bt' || op === 'nb' ? 2 : 1);
const D0 = Date.UTC(1899, 11, 30), p2 = (n) => (n < 10 ? '0' : '') + n;
// Hari kalender sah -> nomor seri gaya Excel (sama dengan serialOf di rumus.js); selain itu null.
export function serialFromYmd(y, m, d) {
  if (![y, m, d].every(Number.isInteger) || y < 1900 || y > 9999 || m < 1 || m > 12 || d < 1 || d > 31) return null;
  const ms = Date.UTC(y, m - 1, d), dt = new Date(ms); if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
  const n = Math.round((ms - D0) / 86400000); return n >= 1 && n <= MAX_SERIAL ? n : null;
}
// Teks tanggal -> nomor seri atau null. Bentuk sah: dd/mm/yyyy (pemisah / - .), yyyy-mm-dd, atau angka bulat polos 1..2958465 (nomor seri).
export function parseDateText(t) {
  const s = String(t === undefined || t === null ? '' : t).trim(); if (!s) return null;
  let m = /^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/.exec(s); if (m) return serialFromYmd(Number(m[3]), Number(m[2]), Number(m[1]));
  m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s); if (m) return serialFromYmd(Number(m[1]), Number(m[2]), Number(m[3]));
  if (/^\d{1,7}$/.test(s)) { const n = Number(s); return n >= 1 && n <= MAX_SERIAL ? n : null; }
  return null;
}
// Nomor seri -> 'dd/mm/yyyy' (untuk pesan); null di luar rentang.
export function serialText(n) {
  if (typeof n !== 'number' || !Number.isFinite(n) || n < 1 || n > MAX_SERIAL) return null; const d = new Date(D0 + Math.floor(n) * 86400000);
  return p2(d.getUTCDate()) + '/' + p2(d.getUTCMonth() + 1) + '/' + d.getUTCFullYear();
}
// Teks angka -> number|null: 12,5 / 12.5 / 1.234,5 / 25% (=0,25) / Rp 1.500; "1.234" tanpa Rp = desimal (sama dengan tampilan Umum).
export function parseNumText(t) {
  let s = String(t === undefined || t === null ? '' : t).trim(); const cur = /^[-+]?\s*rp\b\.?\s*/i.test(s); s = s.replace(/^([-+]?)\s*rp\.?\s*/i, '$1'); if (!s) return null; // awalan Rp = tampilan Indonesia: titik tunggal pun ribuan
  let pct = false; if (/%$/.test(s)) { pct = true; s = s.slice(0, -1).trim(); }
  let v;
  if (/^[-+]?\d+(,\d+)?$/.test(s) || /^[-+]?\d{1,3}(\.\d{3})+(,\d+)?$/.test(s) && (cur || s.includes(',') || /(\.\d{3}){2,}/.test(s))) v = Number(s.replace(/\./g, '').replace(',', '.'));
  else if (/^[-+]?\d+\.\d+$/.test(s)) v = Number(s);
  else return null;
  if (!Number.isFinite(v)) return null; return pct ? v / 100 : v;
}
const cleanV = (x) => (typeof x === 'string' || (typeof x === 'number' && Number.isFinite(x)) ? String(x).trim().slice(0, MAX_V_LEN).trim() : '');
const numOk = (x) => (typeof x === 'number' && Number.isFinite(x) && Math.abs(x) < 1e15 ? x : null);
const serOk = (x) => (typeof x === 'number' && Number.isInteger(x) && x >= 1 && x <= MAX_SERIAL ? x : null);
// Kriteria non-daftar bersih atau null; bt/nb: a <= b.
function cleanCriteria(raw) {
  const k = raw.k;
  if (k === 'email' || k === 'url' || k === 'box') return { k };
  if (k === 'has' || k === 'hasnot' || k === 'same') { const v = cleanV(raw.v); return v ? { k, v } : null; }
  if (k === 'num' || k === 'date') {
    const ops = k === 'num' ? NUM_OPS : DATE_OPS; if (!ops.includes(raw.op)) return null; const ok = k === 'num' ? numOk : serOk, n = operands(raw.op);
    if (!n) return { k, op: raw.op }; let a = ok(raw.a), b = n === 2 ? ok(raw.b) : null; if (a === null || (n === 2 && b === null)) return null;
    if (n === 2 && a > b) { const t = a; a = b; b = t; } return n === 2 ? { k, op: raw.op, a, b } : { k, op: raw.op, a };
  }
  return null;
}
// Apakah teks/nilai sah menurut kriteria non-daftar? raw (opsional) = nilai mentah sel; bila ANGKA dipakai langsung untuk 'num'/'date' (tanpa menebak dari tampilan).
function okCriteria(ck, t, raw) {
  const k = ck.k;
  if (k === 'has') return norm(t).includes(norm(ck.v)); if (k === 'hasnot') return !norm(t).includes(norm(ck.v));
  if (k === 'same') return String(t).trim() === ck.v;
  if (k === 'box') return typeof raw === 'boolean' || ['true', 'false'].includes(norm(t)); // Rev 303a: hanya TRUE/FALSE (atau kosong, ditangani validate)
  if (k === 'email') { const s = String(t).trim(); return s.length <= 254 && !/\.\./.test(s) && /^[^\s@,;<>()\[\]"]+@[^\s@,;<>()\[\]"]+\.[^\s@,;<>()\[\]"]{2,}$/.test(s) && !/^\.|\.@|@\./.test(s); }
  if (k === 'url') return String(t).trim().length <= 2000 && /^(?:(?:https?|ftp):\/\/)?(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}(?::\d{1,5})?(?:[\/?#]\S*)?$/i.test(String(t).trim());
  if (k === 'num') {
    const x = typeof raw === 'number' && Number.isFinite(raw) ? raw : parseNumText(t); if (x === null) return false;
    switch (ck.op) { case 'gt': return x > ck.a; case 'ge': return x >= ck.a; case 'lt': return x < ck.a; case 'le': return x <= ck.a; case 'eq': return x === ck.a; case 'ne': return x !== ck.a; case 'bt': return x >= ck.a && x <= ck.b; case 'nb': return x < ck.a || x > ck.b; default: return true; }
  }
  if (k === 'date') {
    const x = typeof raw === 'number' && Number.isFinite(raw) ? (raw >= 1 && raw <= MAX_SERIAL ? Math.floor(raw) : null) : parseDateText(t); if (x === null) return false;
    switch (ck.op) { case 'ok': return true; case 'eq': return x === ck.a; case 'bf': return x < ck.a; case 'af': return x > ck.a; case 'obf': return x <= ck.a; case 'oaf': return x >= ck.a; case 'bt': return x >= ck.a && x <= ck.b; case 'nb': return x < ck.a || x > ck.b; default: return true; }
  }
  return true;
}
// Kalimat ringkas kriteria non-daftar (daftar = null).
export function criteriaText(ck) {
  if (!ck || ck.k === 'list') return null;
  if (ck.k === 'has') return 'teks berisi "' + ck.v + '"'; if (ck.k === 'hasnot') return 'teks tidak berisi "' + ck.v + '"'; if (ck.k === 'same') return 'teks "' + ck.v + '" (persis)';
  if (ck.k === 'email') return 'alamat email yang valid'; if (ck.k === 'url') return 'URL yang valid'; if (ck.k === 'box') return 'kotak centang (TRUE atau FALSE)';
  const n = operands(ck.op), val = (x) => (ck.k === 'date' ? serialText(x) : String(x).replace('.', ','));
  const lead = ck.k === 'num' ? 'angka ' + (NUM_LABEL[ck.op] || '') : DATE_LABEL[ck.op] || 'tanggal';
  return n === 0 ? lead : n === 1 ? lead + ' ' + val(ck.a) : lead + ' ' + val(ck.a) + ' dan ' + val(ck.b);
}
const HEX = /^#[0-9A-Fa-f]{6}$/;
const hexOf = (v) => (typeof v === 'string' && HEX.test(v.trim()) ? v.trim().toUpperCase() : '');
// Warna per pilihan: hanya untuk pilihan yang ADA di items, hanya #RRGGBB sah; entri kosong dibuang. Mengembalikan objek (boleh kosong).
export function cleanColors(raw, items) {
  const out = {}; if (!raw || typeof raw !== 'object' || Array.isArray(raw) || !Array.isArray(items)) return out;
  for (const t of items) {
    if (t === '__proto__') continue;
    const v = Object.prototype.hasOwnProperty.call(raw, t) ? raw[t] : null; if (!v || typeof v !== 'object') continue;
    const e = {}, bg = hexOf(v.bg), fg = hexOf(v.fg); if (bg) e.bg = bg; if (fg) e.fg = fg; if (e.bg || e.fg) out[t] = e;
  }
  return out;
}
// Rentang opsional. colIds = Set ID kolom, rowIds = Set ID baris (opsional; tanpa itu batas baris tidak diperiksa), colIndex = Map ID kolom -> indeks (opsional; untuk memastikan c2 tidak di kiri c).
// Mengembalikan { c, rg } (rg null bila sama dengan KOLOM penuh).
function cleanRange(raw, c, colIds, rowIds, colIndex) {
  const g = raw && typeof raw === 'object' ? raw : {};
  let c1 = c, c2 = typeof g.c2 === 'string' && colIds.has(g.c2) ? g.c2 : c;
  if (colIndex && colIndex.has(c1) && colIndex.has(c2) && colIndex.get(c2) < colIndex.get(c1)) { const t = c1; c1 = c2; c2 = t; }
  const ok = (x) => (typeof x === 'string' && (!rowIds || rowIds.has(x)) ? x : null);
  const r1 = ok(g.r1), r2 = ok(g.r2);
  if (c2 === c1 && !r1 && !r2) return { c: c1, rg: null };
  const rg = { c2 }; if (r1) rg.r1 = r1; if (r2) rg.r2 = r2; return { c: c1, rg };
}
// Rev 281 / V6c-1: sumber daftar dari rentang sel {c1,c2,r1,r2} (ID); satu ID hilang = sumber dibuang (items tetap sebagai daftar biasa).
const cleanSrc = (g, colIds, rowIds) => { const o = {}; for (const k of ['c1', 'c2', 'r1', 'r2']) { const v = g && g[k]; if (typeof v !== 'string' || !(k[0] === 'c' ? colIds : rowIds || colIds).has(v)) return null; o[k] = v; } return o; };
// Satu aturan validasi dibersihkan; null bila tidak sah. colIds = Set ID kolom tab (untuk kolom yang hilang dibuang); rowIds/colIndex opsional (lihat cleanRange).
export function cleanCheck(raw, colIds, rowIds, colIndex) {
  if (!raw || typeof raw !== 'object' || !KINDS.includes(raw.k) || typeof raw.c !== 'string' || !colIds || !colIds.has(raw.c)) return null;
  const crit = raw.k === 'list' ? null : cleanCriteria(raw); if (raw.k !== 'list' && !crit) return null; // Rev 270: kriteria non-daftar tidak lengkap = dibuang
  const items = raw.k === 'list' ? cleanItems(raw.items) : [], src = raw.k === 'list' && rowIds ? cleanSrc(raw.src, colIds, rowIds) : null; if (raw.k === 'list' && !items.length && !src) return null;
  const { c, rg } = cleanRange(raw.rg, raw.c, colIds, rowIds, colIndex);
  const out = { id: typeof raw.id === 'string' && RID.test(raw.id) ? raw.id : '', c, ...(crit || { k: 'list' }), items };
  if (rg) out.rg = rg; if (src) out.src = src;
  if (!crit) { const cl = cleanColors(raw.cl, src && raw.cl && typeof raw.cl === 'object' ? Object.keys(raw.cl).filter((t) => t.length <= MAX_ITEM_LEN).slice(0, MAX_ITEMS) : items); if (Object.keys(cl).length) out.cl = cl; }
  if (raw.dd === false || crit) out.dd = false; // non-daftar: tanpa panah pilihan
  return out;
}
// Daftar validasi sebuah tab. cols = tab.cols, rows = tab.rows (opsional). Selalu array; rentang kembar/beririsan BOLEH (Rev 276); ID unik terjamin.
export function cleanChecks(raw, cols, rows) {
  const out = [], seen = new Set(); if (!Array.isArray(raw)) return out;
  const colArr = Array.isArray(cols) ? cols : [], colIds = new Set(colArr.map((c) => c && c.id)), colIndex = new Map(colArr.map((c, i) => [c && c.id, i]));
  const rowIds = Array.isArray(rows) ? new Set(rows.map((r) => r && r.id)) : null;
  for (const x of raw) {
    if (out.length >= MAX_CHECKS) break; const c = cleanCheck(x, colIds, rowIds, colIndex); if (!c) continue;
    if (!c.id || seen.has(c.id)) { let n = out.length + 1, id; do { id = 'v' + n++ + Math.random().toString(36).slice(2, 6); } while (seen.has(id)); c.id = id; }
    seen.add(c.id); out.push(c);
  }
  return out;
}

// --- pemakaian ---
export const checkOf = (tab, colId) => (tab && Array.isArray(tab.checks) ? tab.checks.find((x) => x.c === colId) || null : null);
// Batas rentang aturan sebagai indeks { r1, r2, c1, c2 } (inklusif); null bila kolom hilang.
export function checkRect(tab, check) {
  if (!tab || !check || !Array.isArray(tab.cols) || !Array.isArray(tab.rows)) return null;
  const c1 = tab.cols.findIndex((c) => c.id === check.c); if (c1 < 0) return null;
  const g = check.rg || null; let c2 = g ? tab.cols.findIndex((c) => c.id === g.c2) : c1; if (c2 < 0) c2 = c1; if (c2 < c1) c2 = c1;
  const last = tab.rows.length - 1; if (last < 0) return null;
  let r1 = g && g.r1 ? tab.rows.findIndex((r) => r.id === g.r1) : 0, r2 = g && g.r2 ? tab.rows.findIndex((r) => r.id === g.r2) : last;
  if (r1 < 0) r1 = 0; if (r2 < 0) r2 = last; if (r1 > r2) { const t = r1; r1 = r2; r2 = t; }
  return { r1, r2, c1, c2 };
}
// Aturan PERTAMA yang mencakup sel (baris i, kolom j; indeks) atau null.
export function checkAt(tab, i, j) {
  if (!tab || !Array.isArray(tab.checks)) return null;
  for (const ck of tab.checks) { const rc = checkRect(tab, ck); if (rc && i >= rc.r1 && i <= rc.r2 && j >= rc.c1 && j <= rc.c2) return ck; }
  return null;
}
// Rev 272 / V6a: hapus baris ('r') atau kolom ('c') di TEPI rentang = rentang MENYUSUT ke tetangga di dalamnya (bukan melebar); rentang yang habis = aturan dibuang.
// Panggil SEBELUM baris/kolom dibuang dari tab; hasilnya daftar baru (tab tidak diubah), lalu dibersihkan cleanChecks.
export function trimChecks(tab, axis, id) {
  const r = axis === 'r', list = r ? tab.rows : tab.cols, i = list.findIndex((x) => x.id === id), out = [];
  for (const ck of tab.checks || []) {
    const rc = checkRect(tab, ck), g = ck.rg, lo = rc ? (r ? rc.r1 : rc.c1) : -1, hi = rc ? (r ? rc.r2 : rc.c2) : -1;
    if (!rc || i < lo || i > hi || (r && !(g && (g.r1 || g.r2)))) { out.push(ck); continue; } // di luar rentang, atau baris tak dibatasi
    if (lo === hi) continue;
    const a = list[i === lo ? lo + 1 : lo].id, b = list[i === hi ? hi - 1 : hi].id, x = { ...ck };
    if (r) x.rg = { ...g, ...(g.r1 ? { r1: a } : {}), ...(g.r2 ? { r2: b } : {}) }; else { x.c = a; x.rg = { ...g, c2: b }; }
    out.push(x);
  }
  return out;
}
// Rev 272 / V6a: baris dipindah (urut) = aturan tetap di POSISI (indeks), bukan ikut ID baris. snap = pinChecks(tab) sebelum, unpinChecks(tab, snap) sesudah.
export const pinChecks = (tab) => (tab && Array.isArray(tab.checks) ? tab.checks.map((ck) => (ck.rg && (ck.rg.r1 || ck.rg.r2) ? checkRect(tab, ck) : null)) : null);
export function unpinChecks(tab, snap) {
  if (!snap || !Array.isArray(tab.checks)) return;
  tab.checks.forEach((ck, k) => { const rc = snap[k]; if (rc) { if (ck.rg.r1) ck.rg.r1 = tab.rows[rc.r1].id; if (ck.rg.r2) ck.rg.r2 = tab.rows[rc.r2].id; } });
}
// Warna pilihan { bg?, fg? } untuk teks sel, atau null.
export function colorOf(check, text) {
  if (!check || !check.cl) return null; const m = validate(check, text).match; if (m === null) return null; const e = check.cl[m]; return e ? { ...e } : null;
}
// Salinan aturan dengan warna satu pilihan diubah ('' = hapus).
export function withColor(check, item, bg, fg) {
  if (!check || !check.items.includes(item)) return check;
  const cl = { ...(check.cl || {}) }; const e = { ...(cl[item] || {}) };
  if (bg !== undefined) { if (hexOf(bg)) e.bg = hexOf(bg); else delete e.bg; }
  if (fg !== undefined) { if (hexOf(fg)) e.fg = hexOf(fg); else delete e.fg; }
  if (e.bg || e.fg) cl[item] = e; else delete cl[item];
  const out = { ...check }; if (Object.keys(cl).length) out.cl = cl; else delete out.cl; return out;
}
// Apakah teks sah menurut daftar? Kosong selalu sah; tanpa aturan = sah. Mengembalikan { ok, match } (match = pilihan resmi, huruf besar-kecil sesuai daftar).
export function validate(check, text, raw) {
  if (!check) return { ok: true, match: null };
  const t = text === undefined || text === null ? '' : String(text); if (!t.trim()) return { ok: true, match: null };
  if (check.k && check.k !== 'list') return { ok: okCriteria(check, t, raw), match: null }; // Rev 270: raw = nilai mentah sel (opsional; angka dipakai langsung untuk 'num'/'date')
  if (check.src && !check.items.length) return { ok: true, match: null };
  const k = norm(t), hit = check.items.find((x) => norm(x) === k);
  return hit === undefined ? { ok: false, match: null } : { ok: true, match: hit };
}
// Set "i,j" sel BERISI yang melanggar SALAH SATU aturan yang mencakupnya (Rev 276: semua aturan diperiksa, bukan hanya yang pertama). out.by = Map 'i,j' -> aturan pertama yang dilanggar.
// text(i, j) = teks tampil; rawFn(i, j) = nilai mentah (opsional).
export function invalidCells(tab, text, rawFn) {
  const out = new Set(); out.by = new Map(); const list = tab && Array.isArray(tab.checks) ? tab.checks : []; if (!list.length || typeof text !== 'function') return out;
  for (const ck of list) {
    const rc = checkRect(tab, ck); if (!rc) continue;
    for (let i = rc.r1; i <= rc.r2; i++) for (let j = rc.c1; j <= rc.c2; j++) {
      const key = i + ',' + j; if (out.has(key)) continue;
      let t, rw; try { t = text(i, j); rw = typeof rawFn === 'function' ? rawFn(i, j) : undefined; } catch (_) { t = ''; } if (!validate(ck, t, rw).ok) { out.add(key); out.by.set(key, ck); }
    }
  }
  return out;
}
// Rev 276 / W1: aturan LAIN yang beririsan dengan persegi rc (indeks); skipId = aturan yang sedang diubah.
export const overlapChecks = (tab, rc, skipId) => (tab.checks || []).filter((x) => { const r = checkRect(tab, x); return x.id !== skipId && r && r.r1 <= rc.r2 && rc.r1 <= r.r2 && r.c1 <= rc.c2 && rc.c1 <= r.c2; });
// Rev 273 / V6b: keterangan sel tidak sah (title) sesuai jenis aturan: daftar = 'Tidak ada di daftar pilihan'; kriteria lain = 'Harus: <kriteria>'.
export function invalidTip(check) {
  if (check && check.k && check.k !== 'list') { const t = criteriaText(check); return t ? 'Tidak sesuai aturan: ' + t : 'Tidak sesuai aturan data'; }
  return 'Tidak ada di daftar pilihan';
}
// Rev 274 / V6c (MURNI): sel tidak sah BERIKUTNYA setelah sel terpilih, berputar ke awal. keys = Set 'i,j' (indeks baris data, kolom) dari invalidCells;
// order = urutan baris TAMPIL (array indeks baris data; null = urutan asli; baris yang disaring tidak dihitung); sel = { r, c } atau null (mulai dari awal). Hasil { r, c } atau null.
export function nextInvalid(keys, order, sel) {
  if (!keys || !keys.size) return null;
  const pos = new Map(); if (Array.isArray(order)) order.forEach((r, k) => pos.set(r, k));
  const list = [];
  for (const key of keys) { const [r, c] = key.split(',').map(Number); if (!Number.isInteger(r) || !Number.isInteger(c)) continue; const p = Array.isArray(order) ? pos.get(r) : r; if (p === undefined) continue; list.push({ r, c, p }); }
  if (!list.length) return null;
  list.sort((a, b) => a.p - b.p || a.c - b.c);
  const sp = sel ? (Array.isArray(order) ? pos.get(sel.r) : sel.r) : undefined;
  const hit = sel && sp !== undefined ? list.find((m) => m.p > sp || (m.p === sp && m.c > sel.c)) : list[0];
  const m = hit || list[0]; return { r: m.r, c: m.c };
}
// Pilihan berikutnya/sebelumnya dari nilai sekarang (untuk ketuk-berganti). Nilai tidak ada di daftar = pilihan pertama (maju) / terakhir (mundur).
export function stepItem(check, current, dir = 1) {
  if (!check || !check.items.length) return null; const n = check.items.length, k = norm(current === undefined || current === null ? '' : current);
  const i = check.items.findIndex((x) => norm(x) === k);
  if (i < 0) return dir < 0 ? check.items[n - 1] : check.items[0];
  return check.items[(i + (dir < 0 ? -1 : 1) + n) % n];
}
// Deskripsi singkat untuk daftar di UI (Bahasa Indonesia, nama kolom A, B, ...).
export function checkText(check, colName) {
  if (!check) return ''; const k = colName ? 'Kolom ' + colName + ': ' : '';
  if (check.k && check.k !== 'list') return k + criteriaText(check); // Rev 270
  const shown = check.items.slice(0, 4).join(', '), more = check.items.length > 4 ? ' (+' + (check.items.length - 4) + ')' : '';
  return k + 'pilihan ' + shown + more;
}

// --- Rev 267 / V2+V3 (paket Validasi, bagian 29): pembantu murni untuk editor baru + warna pilihan. Tidak mengubah bentuk data; tanpa SCHEMA baru.
// Palet pilihan (pastel lalu sedang).
export const ITEM_COLORS = ['#FECACA', '#FED7AA', '#FDE68A', '#BBF7D0', '#A7F3D0', '#BAE6FD', '#BFDBFE', '#DDD6FE', '#FBCFE8', '#E5E7EB',
  '#F87171', '#FB923C', '#FACC15', '#4ADE80', '#2DD4BF', '#38BDF8', '#60A5FA', '#A78BFA', '#F472B6', '#9CA3AF'];
const colL = (i) => String.fromCharCode(65 + i);
// Alamat rentang aturan: 'B2:B30', 'B2', 'B:B'.
export function rangeText(tab, check) {
  const rc = checkRect(tab, check); if (!rc) return null; const g = check.rg || null, bounded = !!(g && (g.r1 || g.r2));
  if (!bounded) return colL(rc.c1) + ':' + colL(rc.c2);
  return rc.c1 === rc.c2 && rc.r1 === rc.r2 ? colL(rc.c1) + (rc.r1 + 1) : colL(rc.c1) + (rc.r1 + 1) + ':' + colL(rc.c2) + (rc.r2 + 1);
}
// Teks rentang ('B', 'B2:B30') -> { r1, r2, c1, c2, open } atau null (angka baris harus di kedua ujung).
export function parseRange(text, tab) {
  if (!tab || !Array.isArray(tab.cols) || !Array.isArray(tab.rows) || typeof text !== 'string') return null;
  const m = /^\s*([A-Za-z])(\d{1,3})?\s*(?::\s*([A-Za-z])(\d{1,3})?)?\s*$/.exec(text); if (!m) return null;
  const ca = m[1].toUpperCase().charCodeAt(0) - 65, cb = (m[3] ? m[3].toUpperCase().charCodeAt(0) - 65 : ca);
  const ra = m[2] ? Number(m[2]) - 1 : null, rb = m[3] ? (m[4] ? Number(m[4]) - 1 : null) : ra;
  if ((ra === null) !== (rb === null)) return null; // 'B2:B' tidak jelas
  const c1 = Math.min(ca, cb), c2 = Math.max(ca, cb); if (c2 >= tab.cols.length) return null;
  if (ra === null) return { r1: 0, r2: tab.rows.length - 1, c1, c2, open: true };
  const r1 = Math.min(ra, rb), r2 = Math.max(ra, rb); if (r1 < 0 || r2 >= tab.rows.length) return null;
  return { r1, r2, c1, c2, open: false };
}
// Persegi indeks -> { c, rg } untuk disimpan.
export function partsFromRect(tab, rc, open) {
  const c = tab.cols[rc.c1].id, full = open || (rc.r1 === 0 && rc.r2 === tab.rows.length - 1), rg = {};
  if (rc.c2 !== rc.c1) rg.c2 = tab.cols[rc.c2].id; else if (!full) rg.c2 = c;
  if (!full) { rg.r1 = tab.rows[rc.r1].id; rg.r2 = tab.rows[rc.r2].id; }
  return Object.keys(rg).length ? { c, rg } : { c, rg: null };
}
// Baris editor [{ t, bg, fg }] dari aturan.
export const itemRowsOf = (check) => (check ? check.items.map((t) => { const e = check.cl && check.cl[t] ? check.cl[t] : {}; return { t, bg: e.bg || '', fg: e.fg || '' }; }) : []);
// Baris editor -> { items, cl } bersih.
export function itemsFromRows(rows) {
  const cut = (s) => String(s === undefined || s === null ? '' : s).trim().slice(0, MAX_ITEM_LEN).trim(), arr = Array.isArray(rows) ? rows : [];
  const items = cleanItems(arr.map((r) => cut(r && r.t))), raw = {}, seen = new Set();
  for (const r of arr) { const t = cut(r && r.t); if (!t || seen.has(norm(t))) continue; seen.add(norm(t)); raw[t] = { bg: r.bg, fg: r.fg }; }
  return { items, cl: cleanColors(raw, items) };
}

// Rev 278 / W3: tab.errlog = [{ id, r, c (ID baris/kolom), v, rule: { id, t }, at, st: 'open'|'fixed', fixedAt? }], maks. 200, lama dulu; pemeliharaan: lembar-riwayat.js.
export const MAX_ERRLOG = 200;
const cutS = (s, n) => String(s === undefined || s === null ? '' : s).slice(0, n);
export function cleanErrLog(raw, cols, rows) {
  const out = [], seen = new Set(); if (!Array.isArray(raw)) return out;
  const cs = new Set((Array.isArray(cols) ? cols : []).map((c) => c && c.id)), rs = new Set((Array.isArray(rows) ? rows : []).map((r) => r && r.id));
  for (const e of raw) {
    if (!e || !cs.has(e.c) || !rs.has(e.r) || !Number.isFinite(e.at) || !e.rule || !RID.test(e.rule.id)) continue;
    let id = e.id; if (typeof id !== 'string' || !RID.test(id) || seen.has(id)) do { id = 'e' + out.length + Math.random().toString(36).slice(2, 6); } while (seen.has(id));
    const fx = e.st === 'fixed' && Number.isFinite(e.fixedAt), x = { id, r: e.r, c: e.c, v: cutS(e.v, 40), rule: { id: e.rule.id, t: cutS(e.rule.t, 60) }, at: e.at, st: fx ? 'fixed' : 'open' };
    if (fx) x.fixedAt = e.fixedAt; seen.add(id); out.push(x);
  }
  return out.slice(-MAX_ERRLOG);
}
