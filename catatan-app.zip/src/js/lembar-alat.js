// Rev 139 / U9a-1: ALAT lembar kerja (menu Lainnya) sebagai fungsi MURNI: urutkan kolom, ekspor/impor CSV-TSV, cari dan ganti, isi seri.
// MURNI: tanpa DOM, penyimpanan, native, eval. BELUM dipanggil UI (menu Lainnya = U9a-2). Tidak mengimpor mesin rumus langsung (tes rev127):
// hasil rumus dibaca lewat makeDisplay (lembar-tampil.js), sama seperti ekspor.
// Aturan bersama: fungsi pengubah memakai setCell/aturan lembar.js; sel berumus tidak pernah ditimpa diam-diam; hasilnya selalu laporan {…} supaya UI bisa memberi tahu pengguna.
import { MAX_ROWS, MAX_CELL, STYLE_KEYS, setCell, pinChecks, unpinChecks, pinChartRows, restoreChartRows } from './lembar.js';
import { pinSrc, unpinSrc } from './lembar-sumber.js'; // Rev 283 / V6c-3: sumber daftar pilihan dari rentang tetap di posisinya saat urut
import { makeDisplay, hasFx, hasContent, shiftFormula } from './lembar-tampil.js';
import { getFreeze } from './lembar-beku.js'; // Rev 300a: baris beku (judul tabel) tidak ikut diurutkan (modul malas)
import { mergeList, mergeMap } from './lembar-gabung.js'; // Rev 153 / U10b-2b: alat memperhatikan sel gabungan (modul gabung murni, tanpa impor)

const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

// ------------------------------------------------------------------ urutkan
// Urutan jenis: angka < teks < boolean < galat < kosong. Kosong SELALU di akhir (juga pada Z->A). Teks tanpa membedakan huruf besar/kecil, urut Indonesia; stabil.
const rank = (v) => (v === undefined || v === null || v === '' ? 4 : isNum(v) ? 0 : typeof v === 'string' ? 1 : typeof v === 'boolean' ? 2 : 3);
const collator = (() => { try { return new Intl.Collator('id', { sensitivity: 'base', numeric: true }); } catch (_) { return null; } })();
const cmpText = (a, b) => (collator ? collator.compare(a, b) : a.toLowerCase() < b.toLowerCase() ? -1 : a.toLowerCase() > b.toLowerCase() ? 1 : 0);
function cmpVal(a, b) {
  const ra = rank(a), rb = rank(b); if (ra !== rb) return ra - rb;
  if (ra === 0) return a - b; if (ra === 1) return cmpText(a, b); if (ra === 2) return (a ? 1 : 0) - (b ? 1 : 0); if (ra === 3) return a.e < b.e ? -1 : a.e > b.e ? 1 : 0; return 0;
}

// Baris pertama dianggap judul (dilewati) bila 'auto': sel kolom urut di baris 1 berupa TEKS dan ada baris lain berisi ANGKA di kolom itu, atau seluruh baris 1 yang berisi semuanya teks sedangkan baris 2 punya angka.
export function detectHeader(tab, colIdx, opts = {}) {
  const d = opts.display || makeDisplay(tab, opts); const n = tab.rows.length; if (n < 2) return false;
  const first = d.raw(0, colIdx); if (typeof first !== 'string' || first === '') return false;
  for (let i = 1; i < n; i++) if (isNum(d.raw(i, colIdx))) return true;
  let allText = true, any = false; for (let j = 0; j < tab.cols.length; j++) { const v = d.raw(0, j); if (v === undefined || v === '') continue; any = true; if (typeof v !== 'string') allText = false; }
  if (!(any && allText)) return false;
  for (let j = 0; j < tab.cols.length; j++) for (let i = 1; i < Math.min(n, 4); i++) if (isNum(d.raw(i, j))) return true;
  return false;
}

// sortTab(tab, colIdx, dir, {header: 'auto'|true|false, now}) -> {ok, moved, skipped, header, reason?}
// Mengurutkan BARIS UTUH (sel, gaya, rumus ikut pindah) menurut HASIL tampil kolom colIdx. ID baris tidak berubah, jadi rumus yang menunjuk sel di barisnya sendiri tetap benar;
// rumus yang menunjuk baris LAIN tetap menunjuk baris itu (bukan posisinya). Baris yang kolom urutnya kosong dan seluruhnya kosong tetap di akhir.
export function sortTab(tab, colIdx, dir = 'asc', opts = {}) {
  if (!tab || !Array.isArray(tab.rows) || !Number.isInteger(colIdx) || colIdx < 0 || colIdx >= tab.cols.length) return { ok: false, moved: 0, reason: 'kolom' };
  const d = makeDisplay(tab, opts); const hd = opts.header === undefined || opts.header === 'auto' ? detectHeader(tab, colIdx, { ...opts, display: d }) : !!opts.header;
  const start = Math.max(hd ? 1 : 0, getFreeze(tab).r); const items = [], slots = []; // Rev 300a: baris beku selalu tetap di atas (seperti baris judul)
  // Rev 153 / U10b-2b: baris yang dilintasi gabungan SEPANJANG BARIS (r1 < r2) TETAP di tempatnya (gabungan harus utuh); baris lain diurutkan di antara posisi yang tersisa.
  // Gabungan satu baris (melebar ke samping) ikut pindah bersama barisnya, dan nilai urutnya = isi jangkar.
  const ml = mergeList(tab), mm = ml.length ? mergeMap(tab) : null, fixed = new Set();
  for (const m of ml) if (m.r2 > m.r1) for (let i = m.r1; i <= m.r2; i++) fixed.add(i);
  let fixedRows = 0;
  for (let i = start; i < tab.rows.length; i++) {
    if (fixed.has(i)) { fixedRows++; continue; }
    const m = mm && mm.get(i + ',' + colIdx); items.push({ row: tab.rows[i], v: m ? d.raw(m.r1, m.c1) : d.raw(i, colIdx), i }); slots.push(i);
  }
  if (items.length < 2) return { ok: true, moved: 0, header: hd, skipped: start, fixedRows };
  const sgn = dir === 'desc' ? -1 : 1;
  items.sort((a, b) => { const ra = rank(a.v), rb = rank(b.v); if (ra === 4 || rb === 4) return ra === rb ? a.i - b.i : ra === 4 ? 1 : -1; const c = cmpVal(a.v, b.v) * sgn; return c || a.i - b.i; });
  const pv = pinChecks(tab), ps = pinSrc(tab), pin = pinChartRows(tab); // Rev 176: rentang diagram dijaga tetap pada posisinya (bukan ikut baris yang pindah)
  let moved = 0; items.forEach((it, k) => { if (it.i !== slots[k]) moved++; tab.rows[slots[k]] = it.row; });
  const charts = moved && pin ? (restoreChartRows(tab, pin), pin.length) : 0;
  if (moved) { unpinChecks(tab, pv); unpinSrc(tab, ps); }
  return { ok: true, moved, header: hd, skipped: start, fixedRows, charts };
}

// ------------------------------------------------------------------ CSV / TSV
// Jangkauan isi: baris/kolom terakhir yang punya isi. Teks dikutip bila memuat pemisah, tanda kutip, atau baris baru. Angka memakai titik desimal (seperti tabToTsv); sel berumus = HASIL.
export function usedRange(tab) {
  let lastR = -1, lastC = -1; tab.rows.forEach((r, i) => tab.cols.forEach((c, j) => { if (hasContent(r.cells[c.id])) { lastR = Math.max(lastR, i); lastC = Math.max(lastC, j); } }));
  return { rows: lastR + 1, cols: lastC + 1 };
}
const quote = (s, delim) => (s.includes(delim) || /["\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s);
export function tabToDelimited(tab, delim = ',', opts = {}) {
  const d = makeDisplay(tab, opts); const u = usedRange(tab); const out = [];
  for (let i = 0; i < u.rows; i++) { const row = []; for (let j = 0; j < u.cols; j++) row.push(quote(d.plain(i, j), delim)); out.push(row.join(delim)); }
  return out.join('\r\n');
}
export const tabToCsv = (tab, opts) => tabToDelimited(tab, ',', opts);

// Pengurai CSV/TSV (RFC 4180 secukupnya): tanda kutip ganda, "" = satu tanda kutip, baris baru di dalam kutipan, CRLF/LF/CR. Mengembalikan matriks teks.
export function parseDelimited(text, delim) {
  const s = String(text == null ? '' : text).replace(/^\uFEFF/, ''); const rows = []; let row = [], cur = '', q = false, i = 0, any = false;
  const endCell = () => { row.push(cur); cur = ''; }, endRow = () => { endCell(); rows.push(row); row = []; };
  for (; i < s.length; i++) {
    const ch = s[i]; any = true;
    if (q) { if (ch === '"') { if (s[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; continue; }
    if (ch === '"' && cur === '') q = true;
    else if (ch === delim) endCell();
    else if (ch === '\r') { if (s[i + 1] === '\n') i++; endRow(); }
    else if (ch === '\n') endRow();
    else cur += ch;
  }
  if (any && (cur !== '' || row.length || q)) endRow();
  return rows;
}
// Tebak pemisah dari baris-baris awal di LUAR tanda kutip: tab, titik koma, atau koma (yang paling sering dan konsisten); bawaan koma.
export function detectDelimiter(text) {
  const s = String(text || '').slice(0, 4000); const cand = ['\t', ';', ',']; let best = ',', bestScore = 0;
  for (const dl of cand) {
    const lines = parseDelimited(s, dl).slice(0, 8).filter((r) => r.length); if (!lines.length) continue;
    const w = lines.map((r) => r.length); const mode = w[0]; if (mode < 2) continue; const same = w.filter((x) => x === mode).length;
    const score = same * 100 + mode; if (score > bestScore) { best = dl; bestScore = score; }
  }
  return best;
}

// Teks sel -> nilai: angka murni (titik; koma hanya bila pemisah BUKAN koma), TRUE/FALSE -> boolean; angka berawalan nol ("007"), sangat panjang, atau berawalan '=' tetap TEKS (rumus tidak pernah dibuat dari berkas).
export function cellFromText(t, delim = ',') {
  const s = String(t == null ? '' : t); if (s === '') return undefined; const x = s.trim();
  if (x.length <= 15 && /^-?(0|[1-9]\d*)(\.\d+)?$/.test(x)) return Number(x);
  if (delim !== ',' && x.length <= 15 && /^-?(0|[1-9]\d*),\d+$/.test(x)) return Number(x.replace(',', '.'));
  if (/^true$/i.test(x)) return true; if (/^false$/i.test(x)) return false;
  return s.slice(0, MAX_CELL);
}
// Rev 332 / TD: teks yang akan DIPOTONG oleh cellFromText (lebih dari MAX_CELL, bukan angka/boolean) wajib dilaporkan, tidak diam-diam.
export const textCut = (t, delim = ',') => { const s = String(t == null ? '' : t); return s.length > MAX_CELL && typeof cellFromText(s, delim) === 'string'; };

// importDelimited(tab, text, {delim?, row?, col?, replace?}) -> {ok, rows, cols, written, truncatedRows, truncatedCols, delim}
// replace=true mengosongkan nilai/rumus (gaya dipertahankan) di jangkauan tulis; tanpa replace sel yang ditulis menimpa sel itu saja. Melebihi 26 kolom x 500 baris dipotong dan DILAPORKAN (tidak diam-diam).
export function importDelimited(tab, text, opts = {}) {
  const delim = opts.delim || detectDelimiter(text); const m = parseDelimited(text, delim).filter((r, k, a) => !(r.length === 1 && r[0] === '' && k === a.length - 1));
  if (!m.length) return { ok: false, reason: 'kosong', delim };
  const r0 = Math.max(0, opts.row | 0), c0 = Math.max(0, opts.col | 0);
  const maxR = Math.min(m.length, Math.min(MAX_ROWS, tab.rows.length) - r0), width = Math.max(...m.map((r) => r.length)), maxC = Math.min(width, tab.cols.length - c0);
  if (maxR <= 0 || maxC <= 0) return { ok: false, reason: 'di luar lembar', delim };
  let written = 0, skippedFormula = 0, skippedCovered = 0, truncatedText = 0; const mm = mergeMap(tab).size ? mergeMap(tab) : null; // Rev 153: sel TERTUTUP gabungan tidak pernah ditulis (dilaporkan)
  const covered = (i, j) => { const g = mm && mm.get((r0 + i) + ',' + (c0 + j)); return !!g && !(g.r1 === r0 + i && g.c1 === c0 + j); };
  if (opts.replace) for (let i = 0; i < maxR; i++) for (let j = 0; j < maxC; j++) if (!covered(i, j)) setCell(tab, tab.rows[r0 + i].id, tab.cols[c0 + j].id, { v: null, fx: null });
  for (let i = 0; i < maxR; i++) for (let j = 0; j < maxC; j++) {
    const v = cellFromText(m[i][j], delim); if (v === undefined) continue;
    if (covered(i, j)) { skippedCovered++; continue; }
    { const ex = tab.rows[r0 + i].cells[tab.cols[c0 + j].id]; if (!opts.replace && ex && hasFx(ex)) { skippedFormula++; continue; } } // Rev 144: tempel TIDAK menimpa rumus (dilaporkan)
    if (setCell(tab, tab.rows[r0 + i].id, tab.cols[c0 + j].id, { v })) { written++; if (textCut(m[i][j], delim)) truncatedText++; }
  }
  return { ok: true, rows: maxR, cols: maxC, written, skippedFormula, skippedCovered, truncatedText, truncatedRows: Math.max(0, m.length - maxR), truncatedCols: Math.max(0, width - maxC), delim };
}

// ------------------------------------------------------------------ cari dan ganti
// Mencari di TEKS TAMPIL (hasil rumus dan angka berformat ikut dicari, seperti yang dilihat pengguna). opts: {matchCase, whole, scope:{r1,c1,r2,c2}}.
const norm = (s, mc) => (mc ? s : s.toLowerCase());
export function findAll(tab, query, opts = {}) {
  const q = String(query == null ? '' : query); if (q === '') return []; const d = makeDisplay(tab, opts), out = []; const sc = opts.scope;
  const r1 = sc ? sc.r1 : 0, r2 = sc ? sc.r2 : tab.rows.length - 1, c1 = sc ? sc.c1 : 0, c2 = sc ? sc.c2 : tab.cols.length - 1; const nq = norm(q, opts.matchCase);
  for (let i = Math.max(0, r1); i <= Math.min(tab.rows.length - 1, r2); i++) for (let j = Math.max(0, c1); j <= Math.min(tab.cols.length - 1, c2); j++) {
    if (!d.has(i, j)) continue; const t = norm(d.text(i, j), opts.matchCase); if (opts.whole ? t === nq : t.includes(nq)) out.push({ row: i, col: j });
  }
  return out;
}
// replaceAll(tab, query, repl, opts) -> {replaced, cells, skippedFormula}. Hanya sel BERNILAI (teks atau angka tanpa format); sel berumus dilewati dan dihitung (rumus tidak diubah diam-diam),
// angka berformat dilewati (yang terlihat bukan nilai mentahnya). Hasil ganti pada sel angka yang masih berupa angka murni disimpan kembali sebagai angka.
export function replaceAll(tab, query, repl, opts = {}) {
  const q = String(query == null ? '' : query), r = String(repl == null ? '' : repl); const res = { replaced: 0, cells: 0, skippedFormula: 0, skippedFormat: 0, truncatedText: 0 }; if (q === '') return res;
  const sc = opts.scope; const r1 = sc ? sc.r1 : 0, r2 = sc ? sc.r2 : tab.rows.length - 1, c1 = sc ? sc.c1 : 0, c2 = sc ? sc.c2 : tab.cols.length - 1;
  const esc = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); const re = new RegExp(opts.whole ? '^' + esc + '$' : esc, opts.matchCase ? 'g' : 'gi');
  for (let i = Math.max(0, r1); i <= Math.min(tab.rows.length - 1, r2); i++) for (let j = Math.max(0, c1); j <= Math.min(tab.cols.length - 1, c2); j++) {
    const cell = tab.rows[i].cells[tab.cols[j].id]; if (!cell) continue;
    if (hasFx(cell)) { const probe = String(cell.fx); if (re.test(probe)) res.skippedFormula++; re.lastIndex = 0; continue; }
    if (cell.v === undefined || typeof cell.v === 'boolean') continue;
    if (isNum(cell.v) && cell.s && cell.s.nf) { const d = String(cell.v); if (re.test(d)) res.skippedFormat++; re.lastIndex = 0; continue; }
    const src = typeof cell.v === 'string' ? cell.v : String(cell.v); let n = 0; const out = src.replace(re, () => { n++; return r; });
    re.lastIndex = 0; if (!n || out === src) continue;
    const nv = isNum(cell.v) && /^-?(0|[1-9]\d*)(\.\d+)?$/.test(out.trim()) ? Number(out.trim()) : out.slice(0, MAX_CELL);
    if (setCell(tab, tab.rows[i].id, tab.cols[j].id, { v: nv })) { res.cells++; res.replaced += n; if (typeof nv === 'string' && out.length > MAX_CELL) res.truncatedText++; }
  }
  return res;
}

// ------------------------------------------------------------------ isi seri
// Deteksi pola dari sumber (daftar nilai berurutan): 'linear' (angka, selisih tetap; satu angka = +1 hanya bila step diminta), 'texnum' (teks berakhiran angka: "Minggu 1", "Item 07"), 'copy' (ulangi pola).
export function seriesPlan(values) {
  const v = values.filter((x) => x !== undefined); if (!v.length) return { kind: 'copy' };
  if (v.every(isNum)) {
    if (v.length === 1) return { kind: 'copy-or-inc', step: 1 };
    const st = v[1] - v[0]; if (v.every((x, k) => k === 0 || Math.abs((x - v[k - 1]) - st) < 1e-9)) return { kind: 'linear', step: Number(st.toPrecision(12)) };
    return { kind: 'copy' };
  }
  const re = /^(.*?)(\d+)$/; const ms = v.map((x) => (typeof x === 'string' ? re.exec(x) : null));
  if (ms.every(Boolean) && ms.every((m) => m[1] === ms[0][1])) {
    const ns = ms.map((m) => Number(m[2])), pad = ms[0][2].length > 1 && ms[0][2][0] === '0' ? ms[0][2].length : 0;
    const st = ns.length === 1 ? 1 : ns[1] - ns[0]; if (ns.every((x, k) => k === 0 || x - ns[k - 1] === st)) return { kind: 'texnum', prefix: ms[0][1], step: st, pad, last: ns[ns.length - 1] };
  }
  return { kind: 'copy' };
}
// fillSeries(tab, src, count, {dir:'down'|'right', inc:boolean}) -> {ok, filled, kind, skippedFormula, truncated}
// src = {r1,c1,r2,c2} (jangkauan sumber, nilai MENTAH sel), count = jumlah sel baru sesudah jangkauan (turun/kanan). Sumber satu kolom/baris saja; per lajur terpisah bila sumber lebih lebar.
// Rev 143: sel TUJUAN yang berumus tidak ditimpa (res.skippedTarget). Rev 172: lajur sumber yang memuat sel berumus DILEWATI (skippedFormula), seperti Rev 143; rumus disalin lewat Salin & Tempel. Gaya sumber diulang. Angka tunggal disalin kecuali inc=true (+1).
export function fillSeries(tab, src, count, opts = {}) {
  const down = opts.dir !== 'right'; const n = Math.max(0, count | 0); const res = { ok: false, filled: 0, kind: 'copy', skippedFormula: 0, skippedTarget: 0, skippedCovered: 0, skippedSource: 0, truncated: 0, fxCopied: 0, refLost: 0 };
  if (!src || !(n > 0)) return res; const { r1, c1, r2, c2 } = src; if (r1 < 0 || c1 < 0 || r2 >= tab.rows.length || c2 >= tab.cols.length || r2 < r1 || c2 < c1) return res;
  const lanes = down ? c2 - c1 + 1 : r2 - r1 + 1, len = down ? r2 - r1 + 1 : c2 - c1 + 1; const room = down ? tab.rows.length - 1 - r2 : tab.cols.length - 1 - c2; const k = Math.min(n, room); res.truncated = n - k;
  const mm = mergeMap(tab); const cov = (rr, cc) => { const g = mm.get(rr + ',' + cc); return !!g && !(g.r1 === rr && g.c1 === cc); }; // Rev 153: sel tertutup gabungan
  for (let L = 0; L < lanes; L++) {
    const at = (p) => (down ? tab.rows[r1 + p].cells[tab.cols[c1 + L].id] : tab.rows[r1 + L].cells[tab.cols[c1 + p].id]) || null;
    const cells = []; for (let p = 0; p < len; p++) cells.push(at(p));
    if (cells.some((c, p) => (down ? cov(r1 + p, c1 + L) : cov(r1 + L, c1 + p)))) { res.skippedSource++; continue; } // Rev 153: sumber yang memuat sel tertutup dilewati (nilainya kosong, polanya tidak bisa dipercaya)
    if (cells.some((c) => c && hasFx(c))) { res.skippedFormula++; continue; } // Rev 172: Isi seri KEMBALI ke setelan awal (Rev 143): lajur sumber berumus dilewati dan dilaporkan; menyalin rumus = menu Salin & Tempel
    const vals = cells.map((c) => (c ? c.v : undefined)); let plan = seriesPlan(vals);
    if (plan.kind === 'copy-or-inc') plan = opts.inc ? { kind: 'linear', step: 1 } : { kind: 'copy' }; if (!res.filled) res.kind = plan.kind;
    for (let p = 1; p <= k; p++) {
      const base = (p - 1) % len, srcCell = cells[base]; let v;
      if (plan.kind === 'linear') v = Number((vals[len - 1] + plan.step * p).toPrecision(12));
      else if (plan.kind === 'texnum') { const num = String(Math.max(0, plan.last + plan.step * p)); v = plan.prefix + (plan.pad ? num.padStart(plan.pad, '0') : num); }
      else v = vals[base];
      const rr = down ? r1 + len - 1 + p : r1 + L, cc = down ? c1 + L : c1 + len - 1 + p;
      if (cov(rr, cc)) { res.skippedCovered++; continue; } // Rev 153: sel tujuan tertutup gabungan TIDAK ditulis (posisi deret tetap sejajar, dilaporkan)
      const tgt = tab.rows[rr].cells[tab.cols[cc].id]; if (tgt && hasFx(tgt)) { res.skippedTarget++; continue; } // Rev 143: sel tujuan berumus TIDAK ditimpa (dilaporkan)
      const patch = { v: v === undefined ? null : v }; if (srcCell && srcCell.s) patch.s = { ...srcCell.s };
      if (setCell(tab, tab.rows[rr].id, tab.cols[cc].id, patch)) res.filled++;
    }
  }
  res.ok = true; return res;
}

// ------------------------------------------------------------------ salin / tempel (Rev 171)
// copyCell(tab, r, c, {now}) -> {ok, clip}. clip = potret SATU sel: rumus (fx) atau nilai (v) + gaya (s) + hasil hitung (val, untuk Tempel nilai saja).
// Asal disimpan lewat ID baris/kolom (bukan nomor), jadi baris yang disisipkan sesudah Salin tidak menggeser rujukan.
export function copyCell(tab, r, c, opts = {}) {
  if (!tab || !Array.isArray(tab.rows) || !tab.rows[r] || !tab.cols[c]) return { ok: false };
  const rowId = tab.rows[r].id, colId = tab.cols[c].id, cell = tab.rows[r].cells[colId] || null;
  const clip = { tabId: tab.id, rowId, colId };
  if (cell && hasFx(cell)) clip.fx = cell.fx; else if (cell && cell.v !== undefined) clip.v = cell.v;
  if (cell && cell.s) clip.s = { ...cell.s };
  let val = cell ? cell.v : undefined;
  if (cell && hasFx(cell)) { try { val = makeDisplay(tab, Number.isFinite(opts.now) ? { now: opts.now } : {}).raw(r, c); } catch (_) { val = undefined; } }
  if (isNum(val) || typeof val === 'string' || typeof val === 'boolean') clip.val = val; else if (cell && hasFx(cell) && val !== undefined && val !== null) clip.valErr = true;
  return { ok: true, clip };
}
// pasteClip(tab, clip, r, c, {count, dir:'down'|'right', valuesOnly, keepFx}) -> {ok, pasted, fxPasted, refLost, skippedTarget, skippedCovered, skippedFormula, truncated, blocked}
// Tempel penuh: isi + gaya sel tujuan DIGANTI; rumus ditempel dengan rujukan relatif bergeser ($ tetap, keluar lembar = #REF! dan dilaporkan). Hanya di tab asal (ID baris/kolom berbeda tiap tab): selain itu blocked='tab'.
// Rev 172: opts.mode = 'all' (bawaan) | 'content' (isi/rumus saja, gaya tujuan tidak disentuh) | 'values' (= valuesOnly) | 'style' (gaya saja, isi tujuan tidak disentuh; boleh lintas tab).
// valuesOnly: hanya HASIL hitung sel asal (tanpa rumus), gaya tujuan tidak disentuh; boleh lintas tab; hasil galat = blocked='err'.
// keepFx: sel tujuan berumus tidak ditimpa (dipakai Tempel sederet, sama seperti Isi seri). Sel tertutup gabungan dilewati dan dilaporkan.
export function pasteClip(tab, clip, r, c, opts = {}) {
  const res = { ok: false, pasted: 0, fxPasted: 0, refLost: 0, skippedTarget: 0, skippedCovered: 0, skippedFormula: 0, truncated: 0, blocked: '' };
  if (!clip || !tab || !Array.isArray(tab.rows) || !tab.rows[r] || !tab.cols[c]) return res;
  const mode = opts.mode || (opts.valuesOnly ? 'values' : 'all'); // Rev 172: all = isi/rumus + gaya; content = isi/rumus saja; values = hasil hitung saja; style = gaya saja
  const dir = opts.dir === 'right' ? 'right' : 'down', n = Math.max(1, Math.floor(Number(opts.count)) || 1), valuesOnly = mode === 'values', styleOnly = mode === 'style', withStyle = mode === 'all' || styleOnly, withFx = !valuesOnly && !styleOnly && typeof clip.fx === 'string';
  let r0 = -1, c0 = -1;
  if (withFx) {
    if (clip.tabId !== tab.id) { res.blocked = 'tab'; return res; }
    r0 = tab.rows.findIndex((x) => x.id === clip.rowId); c0 = tab.cols.findIndex((x) => x.id === clip.colId);
    if (r0 < 0 || c0 < 0) { res.blocked = 'origin'; return res; }
  }
  if (valuesOnly && clip.valErr) { res.blocked = 'err'; return res; }
  const room = dir === 'right' ? tab.cols.length - c : tab.rows.length - r, k = Math.min(n, room); res.truncated = n - k;
  const mm = mergeMap(tab);
  for (let p = 0; p < k; p++) {
    const rr = dir === 'right' ? r : r + p, cc = dir === 'right' ? c + p : c;
    const g = mm.get(rr + ',' + cc); if (g && !(g.r1 === rr && g.c1 === cc)) { res.skippedCovered++; continue; }
    const tgt = tab.rows[rr].cells[tab.cols[cc].id]; if (opts.keepFx && !styleOnly && tgt && hasFx(tgt)) { res.skippedTarget++; continue; }
    const patch = {};
    if (styleOnly) { /* hanya gaya */ }
    else if (valuesOnly) patch.v = clip.val === undefined ? null : clip.val;
    else if (withFx) { const sh = shiftFormula(clip.fx, tab, rr - r0, cc - c0); if (!sh) { res.skippedFormula++; continue; } patch.fx = sh.fx; if (sh.lost) res.refLost++; res.fxPasted++; }
    else patch.v = clip.v === undefined ? null : clip.v;
    if (withStyle) { const st = {}; for (const key of STYLE_KEYS) st[key] = null; patch.s = { ...st, ...(clip.s || {}) }; }
    if (setCell(tab, tab.rows[rr].id, tab.cols[cc].id, patch)) res.pasted++;
  }
  res.ok = true; return res;
}

// ------------------------------------------------------------------ salin / tempel RENTANG (Rev 179b)
// copyRange(tab, rect, {now}) -> {ok, clip}. rect = { r1, c1, r2, c2 } (indeks, dari modul pilih rentang). clip.range = true; clip.cells[i][j] = potret satu sel
// (sama bentuknya dengan clip copyCell: tabId/rowId/colId + fx atau v + s + val) atau null untuk sel TERTUTUP gabungan (tidak dilewatkan, jadi Tempel tidak mengosongkan sel tujuan).
// Gabungan sel TIDAK ikut tersalin (hanya isi sel jangkar). Hasil rumus dihitung SEKALI untuk seluruh rentang. Baris yang tersembunyi filter tetap ikut (rentang memakai baris asli).
export function copyRange(tab, rect, opts = {}) {
  if (!tab || !Array.isArray(tab.rows) || !rect) return { ok: false };
  const { r1, c1, r2, c2 } = rect;
  if (![r1, c1, r2, c2].every((v) => Number.isInteger(v) && v >= 0) || r2 < r1 || c2 < c1 || r2 >= tab.rows.length || c2 >= tab.cols.length) return { ok: false };
  let d = null; try { d = makeDisplay(tab, Number.isFinite(opts.now) ? { now: opts.now } : {}); } catch (_) { d = null; }
  const mm = mergeMap(tab), cells = [];
  for (let r = r1; r <= r2; r++) {
    const line = [];
    for (let c = c1; c <= c2; c++) {
      const g = mm.get(r + ',' + c); if (g && !(g.r1 === r && g.c1 === c)) { line.push(null); continue; }
      const rowId = tab.rows[r].id, colId = tab.cols[c].id, cell = tab.rows[r].cells[colId] || null, clip = { tabId: tab.id, rowId, colId };
      if (cell && hasFx(cell)) clip.fx = cell.fx; else if (cell && cell.v !== undefined) clip.v = cell.v;
      if (cell && cell.s) clip.s = { ...cell.s };
      let val = cell ? cell.v : undefined;
      if (cell && hasFx(cell)) { try { val = d ? d.raw(r, c) : undefined; } catch (_) { val = undefined; } }
      if (isNum(val) || typeof val === 'string' || typeof val === 'boolean') clip.val = val; else if (cell && hasFx(cell) && val !== undefined && val !== null) clip.valErr = true;
      line.push(clip);
    }
    cells.push(line);
  }
  return { ok: true, clip: { range: true, tabId: tab.id, rows: r2 - r1 + 1, cols: c2 - c1 + 1, rowIds: tab.rows.slice(r1, r2 + 1).map((x) => x.id), colIds: tab.cols.slice(c1, c2 + 1).map((x) => x.id), cells } };
}
// pasteRange(tab, rclip, r, c, {mode}) -> {ok, pasted, fxPasted, refLost, skippedCovered, skippedFormula, skippedErr, truncated, blocked, rows, cols}
// Menempel di kiri-atas (r, c) sebesar sumber (tanpa mengulang). Tiap sel lewat pasteClip, jadi rumus bergeser menurut posisinya dan sel tujuan berumus DITIMPA (seperti Tempel satu sel).
// mode sama dengan pasteClip: all | content | values | style. Rumus (all/content) hanya di tab asal (blocked='tab'); bila baris/kolom sumber sudah dihapus: blocked='origin' (tidak ada yang berubah).
// Sel di luar lembar dihitung truncated; hasil galat pada Tempel nilai dilewati (skippedErr).
export function pasteRange(tab, rc, r, c, opts = {}) {
  const res = { ok: false, pasted: 0, fxPasted: 0, refLost: 0, skippedCovered: 0, skippedFormula: 0, skippedErr: 0, truncated: 0, blocked: '', rows: 0, cols: 0 };
  if (!rc || !rc.range || !Array.isArray(rc.cells) || !tab || !Array.isArray(tab.rows) || !tab.rows[r] || !tab.cols[c]) return res;
  const mode = opts.mode === 'content' || opts.mode === 'values' || opts.mode === 'style' ? opts.mode : 'all'; res.rows = rc.rows; res.cols = rc.cols;
  if (mode === 'all' || mode === 'content') {
    if (rc.tabId !== tab.id) { res.blocked = 'tab'; return res; }
    const rs = new Set(tab.rows.map((x) => x.id)), cs = new Set(tab.cols.map((x) => x.id));
    if (!(rc.rowIds || []).every((id) => rs.has(id)) || !(rc.colIds || []).every((id) => cs.has(id))) { res.blocked = 'origin'; return res; }
  }
  for (let i = 0; i < rc.cells.length; i++) for (let j = 0; j < (rc.cells[i] || []).length; j++) {
    const cc = rc.cells[i][j]; if (!cc) continue;
    const tr = r + i, tc = c + j; if (tr >= tab.rows.length || tc >= tab.cols.length) { res.truncated++; continue; }
    const p = pasteClip(tab, cc, tr, tc, { mode });
    if (p.blocked === 'err') { res.skippedErr++; continue; }
    res.pasted += p.pasted; res.fxPasted += p.fxPasted; res.refLost += p.refLost; res.skippedCovered += p.skippedCovered; res.skippedFormula += p.skippedFormula;
  }
  res.ok = true; return res;
}
