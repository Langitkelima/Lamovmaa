/**
 * Bagian lipat Notes Kelimaa (Rev 109 / U6a).
 *
 * Struktur yang disimpan di HTML catatan (hanya tiga kelas + satu atribut):
 *   <div class="fold" data-o="1"><div class="fh">judul</div><div class="fb"><p>isi</p></div></div>
 *   data-o="1" = terbuka; tanpa atribut = tertutup.
 * Panah dan placeholder dibuat CSS (tidak ikut tersimpan).
 *
 * Aturan keras:
 * - Bagian lipat hanya sah sebagai anak langsung kolom editor. Di dalam sel tabel, kutipan, daftar,
 *   bagian lipat lain, atau kotak centang ia diratakan (judul jadi paragraf, isi menyusul).
 * - Tepat dua anak: .fh (judul, hanya teks/format inline) lalu .fb (isi).
 * - .fb hanya memuat teks biasa, kotak centang, daftar, dan kutipan. Tabel, gambar, dan blok pulau
 *   (suasana hati, tanggal, waktu, hitung mundur) dipindah ke tepat SESUDAH bagian lipat, urutan tetap.
 * Modul ini tidak menyentuh penyimpanan/native; fungsi menerima elemen dan dokumen dari pemanggil.
 */
const BLOCKY = new Set(['P', 'DIV', 'UL', 'OL', 'LI', 'BLOCKQUOTE', 'TABLE', 'TBODY', 'TR', 'TD', 'TH', 'FIGURE']);
const OUT_OF_BODY = '.mood-block,.kb-date-block,.kb-time-block,.kb-countdown-block,table,.tbl-wrap,figure,.fold,.lk-card';

export const isFold = (el) => !!el && el.nodeType === 1 && el.tagName === 'DIV' && el.classList.contains('fold');
export const isFoldOpen = (el) => isFold(el) && el.getAttribute('data-o') === '1';

const emptyPara = (doc) => { const p = doc.createElement('p'); p.append(doc.createElement('br')); return p; };

/** Bagian lipat baru: judul kosong, satu paragraf kosong di isi. Terbuka agar isi langsung bisa diketik. */
export function makeFold(doc, title = '', open = true) {
  const fold = doc.createElement('div'); fold.className = 'fold';
  if (open) fold.setAttribute('data-o', '1');
  const fh = doc.createElement('div'); fh.className = 'fh';
  if (title) fh.textContent = title; else fh.append(doc.createElement('br'));
  const fb = doc.createElement('div'); fb.className = 'fb'; fb.append(emptyPara(doc));
  fold.append(fh, fb);
  return fold;
}

export function setFoldOpen(fold, open) {
  if (!isFold(fold)) return false;
  if (open) fold.setAttribute('data-o', '1'); else fold.removeAttribute('data-o');
  return true;
}
export function toggleFold(fold) { return setFoldOpen(fold, !isFoldOpen(fold)) ? isFoldOpen(fold) : false; }

/** Judul sebagai teks polos (untuk ekspor/pratinjau), tanpa baris baru. */
export function foldTitle(fold) {
  const fh = isFold(fold) ? [...fold.children].find((c) => c.classList && c.classList.contains('fh')) : null;
  return fh ? (fh.textContent || '').replace(/[\s\u00a0]+/g, ' ').trim() : '';
}

/** Ratakan: judul jadi paragraf, isi menyusul sebagai saudara. Mengembalikan paragraf judul. */
export function flattenFold(fold, doc) {
  const fh = [...fold.children].find((c) => c.classList && c.classList.contains('fh'));
  const fb = [...fold.children].find((c) => c !== fh && c.classList && c.classList.contains('fb'));
  const head = doc.createElement('p');
  if (fh) while (fh.firstChild) head.append(fh.firstChild);
  if (!head.firstChild) head.append(doc.createElement('br'));
  const rest = [];
  if (fb) rest.push(...fb.childNodes);
  for (const c of fold.children) if (c !== fh && c !== fb) rest.push(c);
  fold.replaceWith(head, ...rest);
  return head;
}

/** Judul hanya boleh teks + format inline: elemen blok di dalamnya diganti teksnya. */
function cleanHead(fh, doc) {
  for (const c of [...fh.children]) {
    if (!BLOCKY.has(c.tagName) && c.tagName !== 'INPUT') continue;
    const t = (c.textContent || '').replace(/[\s\u00a0]+/g, ' ');
    c.replaceWith(doc.createTextNode(t + ' '));
  }
  fh.querySelectorAll('input').forEach((x) => x.remove());
  fh.normalize();
  if (fh.lastChild && fh.lastChild.nodeType === 3) fh.lastChild.nodeValue = fh.lastChild.nodeValue.replace(/\s+$/, '');
  // Judul satu baris: <br> hanya penanda judul kosong (tepat satu); bila ada teks, semua <br> dibuang.
  const hasText = (fh.textContent || '').replace(/[\s\u00a0\u200b]/g, '') !== '';
  const brs = [...fh.querySelectorAll('br')];
  if (hasText) brs.forEach((b) => b.remove());
  else { brs.forEach((b) => b.remove()); if (!fh.childNodes.length || !(fh.textContent || '').trim()) { fh.textContent = ''; fh.append(doc.createElement('br')); } }
}

/**
 * Pulihkan struktur satu bagian lipat (dipanggil dari sanitize dan setelah penyuntingan).
 * Mengembalikan 'ok' (tidak berubah), 'healed' (diperbaiki), atau 'flat' (diratakan, elemen sudah tidak ada).
 */
export function healFold(fold, doc) {
  if (!isFold(fold)) return 'ok';
  const parent = fold.parentElement;
  // Sah hanya sebagai anak langsung kolom editor (atau akar sementara sanitize): di tempat lain diratakan.
  if (parent && parent.closest('.fold,td,th,blockquote,li,ul,ol,.todo,table')) { flattenFold(fold, doc); return 'flat'; }
  let changed = false;
  const kids = [...fold.children];
  let fh = kids.find((c) => c.classList.contains('fh'));
  let fb = kids.find((c) => c !== fh && c.classList.contains('fb'));
  if (!fh) { fh = doc.createElement('div'); fh.className = 'fh'; fh.append(doc.createElement('br')); fold.prepend(fh); changed = true; }
  if (!fb) { fb = doc.createElement('div'); fb.className = 'fb'; fold.append(fb); changed = true; }
  if (fold.firstElementChild !== fh) { fold.prepend(fh); changed = true; }
  if (fh.nextElementSibling !== fb) { fh.after(fb); changed = true; }
  // Anak lain (selain .fh/.fb) dan simpul teks lepas masuk ke isi.
  for (const c of [...fold.childNodes]) {
    if (c === fh || c === fb) continue;
    if (c.nodeType === 3 && !c.nodeValue.trim()) { c.remove(); continue; }
    fb.append(c); changed = true;
  }
  const before = fh.innerHTML;
  cleanHead(fh, doc);
  if (fh.innerHTML !== before) changed = true;
  // Isi: tabel, gambar, blok pulau, dan bagian lipat lain dipindah ke sesudah bagian lipat (urutan dijaga).
  let anchor = fold;
  for (const c of [...fb.children]) {
    if (!c.matches(OUT_OF_BODY)) continue;
    anchor.after(c); anchor = c; changed = true;
  }
  // Kolom isi tidak boleh kosong total (tempat mengetik).
  if (!fb.firstChild) { fb.append(emptyPara(doc)); changed = true; }
  // Teks lepas langsung di .fb dibungkus paragraf agar Enter/ketik berperilaku normal.
  for (const c of [...fb.childNodes]) {
    if (c.nodeType === 3) { if (!c.nodeValue.trim()) { c.remove(); continue; } const p = doc.createElement('p'); c.replaceWith(p); p.append(c); changed = true; }
  }
  // Nilai data-o hanya "1".
  const o = fold.getAttribute('data-o');
  if (o !== null && o !== '1') { fold.removeAttribute('data-o'); changed = true; }
  return changed ? 'healed' : 'ok';
}

/** Sembuhkan semua bagian lipat dalam satu akar (dokumen lebih dulu, jadi yang bersarang diratakan dari luar). */
export function healAllFolds(root, doc) {
  let n = 0;
  for (const f of [...root.querySelectorAll('div.fold')]) { if (healFold(f, doc) !== 'ok') n++; }
  return n;
}

/** Bagian lipat yang memuat simpul (atau null). */
export function foldOf(node, ed) {
  const el = node && (node.nodeType === 1 ? node : node.parentElement);
  const f = el && el.closest ? el.closest('.fold') : null;
  return f && ed && ed.contains(f) ? f : null;
}

/** Apakah ketukan di zona panah judul? (kiri `zone` px dari tepi kiri .fh) */
export function arrowHit(e, ed, zone = 44) {
  const t = e && e.target && e.target.closest ? e.target.closest('.fh') : null;
  if (!t || !ed.contains(t) || !isFold(t.parentElement)) return null;
  const r = t.getBoundingClientRect();
  return e.clientX >= r.left - 2 && e.clientX <= r.left + zone ? t.parentElement : null;
}

/** Judul (.fh) yang memuat simpul, hanya bila induknya bagian lipat sah di editor. */
export function headOf(node, ed) {
  const el = node && (node.nodeType === 1 ? node : node.parentElement);
  const fh = el && el.closest ? el.closest('.fh') : null;
  return fh && ed && ed.contains(fh) && isFold(fh.parentElement) ? fh : null;
}

/** Buka bagian lipat dan kembalikan paragraf isi pertama (dibuat bila isi kosong total). */
export function openToBody(fold, doc) {
  setFoldOpen(fold, true);
  let fb = [...fold.children].find((c) => c.classList && c.classList.contains('fb'));
  if (!fb) { fb = doc.createElement('div'); fb.className = 'fb'; fold.append(fb); }
  if (!fb.firstElementChild) fb.append(emptyPara(doc));
  return fb.firstElementChild;
}

// ===== Rev 111 / U6c: Enter / Backspace / Delete di bagian lipat =====
// Temuan Chromium (sebelum U6c): Backspace di awal judul berisi menarik judul ke paragraf sebelumnya (bagian lipat kehilangan .fh);
// Backspace di awal isi pertama menempelkan isi ke judul; Backspace di awal blok SESUDAH bagian lipat tertutup, dan Delete di akhir
// judul bagian lipat tertutup, MENGHAPUS isi tersembunyi (kehilangan data). Fungsi di bawah dipanggil dari pengendali `beforeinput`
// (notes.js) dan hanya memakai API DOM dasar; semuanya mengembalikan titik kursor {node, offset} (atau null = tidak ditangani).
const BLANK_RE = /[\s\u00a0\u200b]/g;
const hasMedia = (el) => !!(el && el.querySelector && el.querySelector('img,figure,input,table'));
/** Blok tanpa teks dan tanpa gambar/tabel/kotak (hanya spasi, nbsp, <br>). */
export const isBlankBlock = (el) => !!el && !hasMedia(el) && !String(el.textContent || '').replace(BLANK_RE, '');
/** Baris biasa: <p> atau <div> TANPA kelas (kotak centang, blok pulau, bagian lipat semuanya punya kelas). */
export const isPlainRow = (el) => !!el && el.nodeType === 1 && (el.tagName === 'P' || (el.tagName === 'DIV' && !el.className));
const partOf = (fold, cls) => [...fold.children].find((c) => c.classList && c.classList.contains(cls)) || null;
export const foldHead = (fold) => partOf(fold, 'fh');
export const foldBody = (fold) => partOf(fold, 'fb');

/** Titik kursor di awal sebuah elemen (awal teks pertama, atau di dalam elemen bila tanpa teks). */
export function caretStartOf(el) {
  let n = el;
  while (n && n.firstChild && !(n.nodeType === 1 && n.tagName === 'BR')) n = n.firstChild;
  return n && n.nodeType === 3 ? { node: n, offset: 0 } : { node: el, offset: 0 };
}
/** Titik kursor di akhir judul (akhir teks terakhir; judul kosong = di dalam .fh). */
export function endOfHead(fh) {
  let n = fh.lastChild;
  while (n && n.nodeType === 1 && n.tagName !== 'BR' && n.lastChild) n = n.lastChild;
  return n && n.nodeType === 3 ? { node: n, offset: n.data.length } : { node: fh, offset: 0 };
}

/** Baris isi (anak langsung .fb) yang memuat simpul: { fold, fb, row } atau null. */
export function bodyRowOf(node, ed) {
  const el = node && (node.nodeType === 1 ? node : node.parentElement);
  const fb = el && el.closest ? el.closest('.fb') : null;
  if (!fb || !ed.contains(fb) || !isFold(fb.parentElement)) return null;
  let row = node;
  while (row && row.parentNode !== fb) row = row.parentNode;
  return row && row.nodeType === 1 ? { fold: fb.parentElement, fb, row } : null;
}

/**
 * Enter di baris isi KOSONG yang terakhir = keluar ke paragraf SESUDAH bagian lipat.
 * Baris kosong itu dibuang, kecuali satu-satunya (isi tidak boleh kosong total, tempat mengetik). Bila tepat sesudah bagian lipat
 * sudah ada paragraf kosong, itu yang dipakai (tidak menumpuk paragraf kosong). Mengembalikan titik kursor, atau null bila bukan kasusnya.
 */
export function exitFoldFromBody(fold, row, doc) {
  const fb = foldBody(fold);
  if (!fb || row.parentNode !== fb || !isPlainRow(row) || !isBlankBlock(row) || row !== fb.lastElementChild) return null;
  if (fb.children.length > 1) row.remove();
  const nx = fold.nextElementSibling;
  let p = nx && isPlainRow(nx) && isBlankBlock(nx) ? nx : null;
  if (!p) { p = doc.createElement('p'); p.append(doc.createElement('br')); fold.after(p); }
  return { node: p, offset: 0 };
}

/**
 * Bagian lipat jadi paragraf biasa (Backspace di awal judul): judul jadi paragraf, isi menyusul sebagai saudara.
 * Bila isi hanya baris kosong, baris itu dibuang (tidak meninggalkan paragraf kosong tambahan). Kursor di awal paragraf judul.
 */
export function unfoldToParagraph(fold, doc) {
  const fb = foldBody(fold);
  if (fb) { const kids = [...fb.children]; if (kids.length && kids.every((k) => isPlainRow(k) && isBlankBlock(k))) kids.forEach((k) => k.remove()); }
  return caretStartOf(flattenFold(fold, doc));
}

/**
 * Delete di akhir judul = isi pertama digabung ke judul (hanya bila bagian lipat terbuka dan baris pertamanya baris biasa).
 * Mengembalikan titik kursor di sambungan, atau null (tidak digabung; pemanggil tetap menahan Delete bawaan).
 */
export function mergeFirstRowIntoHead(fold, doc) {
  const fh = foldHead(fold), fb = foldBody(fold);
  if (!fh || !fb || !isFoldOpen(fold)) return null;
  const row = fb.firstElementChild;
  if (!isPlainRow(row)) return null;
  const at = endOfHead(fh);
  if (!isBlankBlock(row)) for (const c of [...row.childNodes]) { if (c.nodeType === 1 && c.tagName === 'BR') continue; fh.append(c); }
  row.remove();
  if (!fb.firstElementChild) fb.append(emptyPara(doc));
  healFold(fold, doc); // judul tetap satu baris tanpa elemen blok; <br> penanda dibuang bila kini ada teks
  return at;
}

// ===== Rev 112 / U6d: Pindahkan ke dalam / keluar dari bagian lipat =====
// Dipakai bilah chip "Alat bagian lipat" (notes.js). Yang dipindah adalah SIMPUL ASLI (bukan salinan), jadi kotak centang tetap membawa
// data-cid (pengingat tidak putus), blok kutipan/daftar utuh, dan kursor bisa dipulihkan oleh pemanggil dengan simpul yang sama.
const NOT_MOVABLE = OUT_OF_BODY + ',[data-kb-tool],.kb-tools';
/** Blok yang boleh masuk isi bagian lipat: teks, kotak centang, daftar, kutipan. Tabel, gambar, blok pulau, bagian lipat lain TIDAK (aturan U6a). */
export const canMoveIntoFold = (block) => !!block && block.nodeType === 1 && !block.matches(NOT_MOVABLE);

/** Anak langsung editor yang memuat simpul (atau null bila simpul di luar editor / editor sendiri). */
export function topBlockOf(node, ed) {
  let n = node;
  while (n && n.parentNode !== ed) n = n.parentNode;
  return n && n.nodeType === 1 ? n : null;
}

/** Blok tingkat atas yang berada TEPAT di bawah sebuah bagian lipat dan memuat simpul: { fold, block } atau null. */
export function blockBelowFold(node, ed) {
  const block = topBlockOf(node, ed);
  const prev = block ? block.previousElementSibling : null;
  return prev && isFold(prev) && !isFold(block) ? { fold: prev, block } : null;
}

/**
 * Konteks Pindahkan untuk kursor di `node`:
 *  { kind: 'out', fold, row }   kursor di baris isi bagian lipat -> chip "Pindahkan keluar dari bagian lipat"
 *  { kind: 'in', fold, block }  kursor di blok tepat di bawah bagian lipat (dan blok itu boleh masuk) -> chip "Pindahkan ke dalam bagian lipat"
 *  null                         selain itu (judul bagian lipat, tabel, blok pulau, di luar editor): tidak ada chip.
 */
export function foldMoveContext(node, ed) {
  if (!node || !ed || !ed.contains(node)) return null;
  const br = bodyRowOf(node, ed);
  if (br) return { kind: 'out', fold: br.fold, row: br.row };
  const bl = blockBelowFold(node, ed);
  return bl && canMoveIntoFold(bl.block) ? { kind: 'in', fold: bl.fold, block: bl.block } : null;
}

/**
 * Masukkan `block` (harus saudara TEPAT di bawah `fold`) ke akhir isi bagian lipat. Bagian lipat dibuka supaya blok yang dipindah tetap terlihat.
 * Isi yang hanya baris kosong pengganti (tempat mengetik) dibuang bila blok yang masuk berisi, supaya tidak tertinggal baris kosong di atasnya.
 * Mengembalikan true bila dipindah.
 */
export function moveBlockIntoFold(fold, block, doc) {
  const fb = isFold(fold) ? foldBody(fold) : null;
  if (!fb || !canMoveIntoFold(block) || block.previousElementSibling !== fold) return false;
  const kids = [...fb.children];
  if (!isBlankBlock(block) && kids.length && kids.every((k) => isPlainRow(k) && isBlankBlock(k))) kids.forEach((k) => k.remove());
  fb.append(block);
  setFoldOpen(fold, true);
  if (!fb.firstElementChild) fb.append(emptyPara(doc));
  return true;
}

/**
 * Keluarkan `row` (anak langsung isi) ke TEPAT di bawah bagian lipat. Hanya baris itu yang keluar; baris isi lain tetap di tempatnya.
 * Isi tidak pernah kosong total: bila yang keluar baris terakhir, satu paragraf kosong tersisa. Mengembalikan true bila dipindah.
 */
export function moveBlockOutOfFold(fold, row, doc) {
  const fb = isFold(fold) ? foldBody(fold) : null;
  if (!fb || !row || row.parentNode !== fb) return false;
  fold.after(row);
  if (!fb.firstElementChild) fb.append(emptyPara(doc));
  return true;
}
