// Rev 398 / PART M3: impor catatan dari Markdown (.md/.markdown/.txt, atau ZIP berisi berkas itu). Mesin murni: tanpa DOM, tanpa penyimpanan.
// HTML hasil impor WAJIB lewat sanitize() saat disimpan: sanitize dan newId disuntikkan ke commitMarkdownImport (dites dengan pengganti).
// Aturan: semua hasil masuk sebagai catatan BIASA. Berkas dari folder privat/ TIDAK diimpor (tidak menurunkan catatan privat jadi biasa).
import { markdownToNote } from './md-catatan.js';
import { parseNoteHtml, blocksToText } from './export.js';
import { LABEL_MAX, LABEL_NAME_MAX } from './logic.js';
import { buildFigure, newImageId, checkSource, MAX_IMAGES_PER_NOTE } from './cadangan-gambar.js'; // Rev 399 / M4

export const IMPOR_MAX_FILES = 500;
export const IMPOR_MAX_FILE_CHARS = 1000000; // satu berkas
export const IMPOR_MAX_TOTAL_CHARS = 2000000; // seluruh impor sekali jalan (penyimpanan HP terbatas)
export const IMPOR_MAX_IMAGES = 100; // gambar yang ikut dalam sekali impor (sisanya jadi penanda teks)
export const IMPOR_IMAGE_PRESET = 'hemat'; // gambar impor selalu dikecilkan ke kualitas Hemat (maks. 1024 px, sekitar 150 KB)
export const IMAGE_EXTS = ['png', 'jpg', 'jpeg', 'webp'];
export const isImageName = (n) => IMAGE_EXTS.includes(extOf(n));
const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp' };
export const mimeOfName = (n) => MIME[extOf(n)] || '';
const base = (n) => String(n || '').split(/[\\/]/).pop();
const stem = (n) => base(n).replace(/\.[^.]*$/, '');
const extOf = (n) => (/\.([A-Za-z0-9]+)$/.exec(base(n)) || [, ''])[1].toLowerCase();

// files: [{ name, text }] (name boleh berisi folder dari ZIP). existingLabels: [{ id, name }].
// Hasil: { items, skipped: [{ name, reason }], newLabels: [nama], labelsDropped, warnings: { gambar, terpotong, tabel } }
// Rev 399 / M4: parameter ke-3 opsional images = [{ name, size }] (gambar yang ikut dipilih/ada di ZIP). Gambar yang berdiri sendiri di satu baris
// dan alamatnya cocok dengan salah satunya diberi penanda `<!--mdimg:N-->` di html; materializeImages() mengubahnya jadi gambar sungguhan.
// Tanpa images, perilaku sama dengan Rev 398 (gambar jadi penanda teks). Tidak ada gambar yang diunduh dari internet.
export function planMarkdownImport(files, existingLabels = [], images = []) {
  const items = [], skipped = [], warnings = { gambar: 0, terpotong: 0, tabel: 0 };
  const imgIdx = buildImageIndex(images), imgUse = new Set(); let imgTotal = 0, imgLimit = 0, imgBig = 0, imgBad = 0;
  const known = new Map((existingLabels || []).map((l) => [String(l.name).toLowerCase(), l.name]));
  const fresh = new Map(); let labelsDropped = 0, total = 0;
  for (const f of Array.isArray(files) ? files : []) {
    const name = String((f && f.name) || ''), b = base(name), ext = extOf(name);
    if (!b || /^\./.test(b)) continue; // berkas tersembunyi (mis. .DS_Store) diabaikan tanpa dihitung
    if (/(^|[\\/])privat[\\/]/i.test(name)) { skipped.push({ name: b, reason: 'folder privat tidak diimpor ke catatan biasa' }); continue; }
    if (!['md', 'markdown', 'txt'].includes(ext)) { if (/(^|[\\/])gambar[\\/]/i.test(name)) continue; skipped.push({ name: b, reason: 'bukan .md atau .txt' }); continue; }
    const text = String((f && f.text) || '');
    if (!text.trim()) { skipped.push({ name: b, reason: 'kosong' }); continue; }
    if (items.length >= IMPOR_MAX_FILES) { skipped.push({ name: b, reason: 'melebihi batas ' + IMPOR_MAX_FILES + ' catatan sekali impor' }); continue; }
    if (text.length > IMPOR_MAX_FILE_CHARS) { skipped.push({ name: b, reason: 'terlalu besar (maksimal ' + IMPOR_MAX_FILE_CHARS.toLocaleString('id-ID') + ' huruf)' }); continue; }
    if (total + text.length > IMPOR_MAX_TOTAL_CHARS) { skipped.push({ name: b, reason: 'total impor melebihi ' + IMPOR_MAX_TOTAL_CHARS.toLocaleString('id-ID') + ' huruf' }); continue; }
    total += text.length;
    const imgs = []; let perNote = 0;
    const r = markdownToNote(text, imgIdx.size ? { image: (src, alt) => {
      const e = resolveImage(imgIdx, name, src); if (!e) return null;
      if (!checkSource({ type: mimeOfName(e.name), name: e.name, size: e.size }).ok) { if (e.size > 30 * 1024 * 1024) imgBig++; else imgBad++; return null; }
      if (perNote >= MAX_IMAGES_PER_NOTE || (!imgUse.has(e) && imgTotal >= IMPOR_MAX_IMAGES)) { imgLimit++; return null; }
      if (!imgUse.has(e)) { imgUse.add(e); imgTotal++; }
      perNote++; imgs.push({ entry: e, alt }); return '<!--mdimg:' + (imgs.length - 1) + '-->';
    } } : {});
    const title = (r.title || stem(name).replace(/[-_]+/g, ' ')).trim().slice(0, 120);
    const labelNames = [];
    for (const raw of r.labels) {
      const v = String(raw).replace(/\s+/g, ' ').trim().slice(0, LABEL_NAME_MAX).trim(), k = v.toLowerCase();
      if (!v) continue;
      if (known.has(k)) { labelNames.push(known.get(k)); continue; }
      if (fresh.has(k)) { labelNames.push(fresh.get(k)); continue; }
      if (known.size + fresh.size >= LABEL_MAX) { labelsDropped++; continue; }
      fresh.set(k, v); labelNames.push(v);
    }
    for (const w of r.warnings) { if (w.startsWith('gambar:')) warnings.gambar += Number(w.slice(7)) || 0; else if (w === 'terpotong') warnings.terpotong++; else if (w === 'tabel-dipotong') warnings.tabel++; }
    items.push({ name: b, title, html: r.html, labelNames: [...new Set(labelNames)], imgs });
  }
  return { items, skipped, newLabels: [...fresh.values()], labelsDropped, warnings, imageCount: imgUse.size, imageLimit: imgLimit, imageBig: imgBig, imageBad: imgBad };
}

// ---------- Gambar (Rev 399 / M4) ----------
function buildImageIndex(images) {
  const byPath = new Map(), byBase = new Map();
  for (const e of Array.isArray(images) ? images : []) {
    if (!e || !isImageName(e.name)) continue;
    const ent = { name: String(e.name), size: Number(e.size) || 0, src: e };
    byPath.set(normPath(ent.name), ent);
    const k = base(ent.name).toLowerCase(); byBase.set(k, byBase.has(k) ? null : ent); // null = nama kembar, tidak dipakai untuk pencocokan nama saja
  }
  return { size: byPath.size, byPath, byBase };
}
const normPath = (p) => { const out = []; for (const seg of String(p).replace(/\\/g, '/').split('/')) { if (!seg || seg === '.') continue; if (seg === '..') { out.pop(); continue; } out.push(seg); } return out.join('/').toLowerCase(); };
function resolveImage(idx, mdName, src) {
  let u = String(src || '').trim(); if (!u || /^(?:[a-z][a-z0-9+.-]*:|\/\/|\/)/i.test(u)) return null; // http:, data:, file:, alamat mutlak: tidak diunduh
  u = u.replace(/[?#].*$/, ''); try { u = decodeURIComponent(u); } catch (_) { /* biarkan apa adanya */ }
  const dir = String(mdName || '').replace(/\\/g, '/').split('/').slice(0, -1).join('/');
  const hit = idx.byPath.get(normPath((dir ? dir + '/' : '') + u)) || idx.byPath.get(normPath(u));
  return hit || idx.byBase.get(base(u).toLowerCase()) || null; // terakhir: nama berkas saja (pemilih berkas Android tidak membawa folder)
}
const escH = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Mengubah penanda gambar menjadi <figure> sungguhan: baca -> kecilkan (Hemat) -> simpan berkas -> rujukan ringan di HTML.
// deps: { read(entry) -> bytes, compress(file, presetName) -> { blob, w, h, b, x }, write(ref, blob), newId?, onProgress?(n, total) }. Satu gambar diproses satu per satu
// (hemat memori) dan satu berkas yang dirujuk beberapa catatan hanya dikecilkan sekali. Gagal per gambar = jadi penanda teks, impor tetap jalan.
// Mengembalikan { plan (salinan, html sudah diganti), done, failed: [{ name, reason }], refs }. Tidak menyentuh data aplikasi.
export async function materializeImages(plan, deps) {
  const cache = new Map(), failed = [], refs = []; let n = 0; const total = plan.imageCount || 0;
  const items = [];
  for (const it of plan.items) {
    let html = it.html;
    for (let i = 0; i < (it.imgs || []).length; i++) {
      const { entry, alt } = it.imgs[i], key = entry.name; let ref = cache.get(key);
      if (ref === undefined) {
        n++;
        try {
          if (deps.onProgress) deps.onProgress(n, total);
          const bytes = await deps.read(entry.src || entry);
          const file = typeof File === 'function' ? new File([bytes], base(entry.name), { type: mimeOfName(entry.name) }) : new Blob([bytes], { type: mimeOfName(entry.name) });
          const c = await deps.compress(file, IMPOR_IMAGE_PRESET);
          ref = { id: (deps.newId || newImageId)(), w: c.w, h: c.h, b: c.b, x: c.x };
          if (!buildFigure(ref)) throw new Error('rujukan gambar tidak sah');
          await deps.write(ref, c.blob); refs.push(ref);
        } catch (e) { ref = null; failed.push({ name: base(entry.name), reason: String((e && e.message) || e || 'gagal').slice(0, 120) }); }
        cache.set(key, ref);
      }
      const fig = ref ? buildFigure(ref) : '';
      html = html.replace('<!--mdimg:' + i + '-->', fig || '<div>[gambar' + (alt ? ': ' + escH(alt) : '') + ']</div>');
    }
    items.push({ ...it, html, imgs: [] });
  }
  return { plan: { ...plan, items }, done: refs.length, failed, refs }; // done = gambar UNIK yang berhasil
}

// Menambahkan ke data (mengubah data). deps: { sanitize, newId, now }. Selalu catatan biasa (data.notes), tidak pernah data.priv.
export function commitMarkdownImport(data, plan, deps) {
  const labels = data.settings.labels, idOf = new Map(labels.map((l) => [l.name.toLowerCase(), l.id]));
  let labelsAdded = 0;
  for (const nm of plan.newLabels) if (!idOf.has(nm.toLowerCase()) && labels.length < LABEL_MAX) { const l = { id: deps.newId(), name: nm }; labels.push(l); idOf.set(nm.toLowerCase(), l.id); labelsAdded++; }
  const now = Number(deps.now) || Date.now(); let added = 0;
  for (const it of plan.items) {
    const html = deps.sanitize(it.html);
    const text = blocksToText('', parseNoteHtml(html)).trim();
    data.notes.push({ id: deps.newId(), title: it.title, text, html, col: '', pin: false, updated: now + added, labels: it.labelNames.map((n) => idOf.get(n.toLowerCase())).filter(Boolean) });
    added++;
  }
  return { added, labelsAdded };
}

// Ringkasan untuk dialog konfirmasi dan toast.
export function importSummary(plan) {
  const parts = [plan.items.length + ' catatan akan ditambahkan'];
  if (plan.newLabels.length) parts.push(plan.newLabels.length + ' label baru (' + plan.newLabels.slice(0, 5).join(', ') + (plan.newLabels.length > 5 ? ', ...' : '') + ')');
  if (plan.labelsDropped) parts.push(plan.labelsDropped + ' label dilewati karena batas jumlah label');
  if (plan.imageCount) parts.push(plan.imageCount + ' gambar ikut (dikecilkan dulu ke kualitas Hemat)');
  if (plan.warnings.gambar) parts.push(plan.warnings.gambar + ' gambar tidak ikut (diganti penanda teks' + (plan.imageLimit ? '; maksimal ' + MAX_IMAGES_PER_NOTE + ' gambar per catatan dan ' + IMPOR_MAX_IMAGES + ' per impor' : '') + (plan.imageBig ? '; ada yang lebih dari 30 MB' : '') + ')');
  if (plan.warnings.terpotong) parts.push(plan.warnings.terpotong + ' catatan terlalu panjang dan dipotong');
  if (plan.warnings.tabel) parts.push(plan.warnings.tabel + ' tabel dipotong (maksimal 200 baris)');
  let s = parts.join('. ') + '.';
  if (plan.skipped.length) { const by = new Map(); for (const k of plan.skipped) by.set(k.reason, (by.get(k.reason) || 0) + 1); s += ' Dilewati ' + plan.skipped.length + ': ' + [...by].map(([r, n]) => n + ' ' + r).join('; ') + '.'; }
  return s;
}
