// Rev 192b / P2b: JEMBATAN mesin rumus (rumus.js, sekitar 57 KB). Mesin TIDAK lagi ikut dimuat saat aplikasi dibuka:
// ia dimuat lewat import() dinamis hanya bila ada lembar kerja berumus (fx) yang perlu dihitung, atau layar lembar kerja dibuka.
// Modul ini kecil, TANPA impor statis, tidak menyentuh data/DOM/penyimpanan. rumus.js sendiri tetap murni (tanpa impor).
//   getEngine()    -> namespace rumus.js bila sudah dimuat, selain itu null (SINKRON)
//   loadEngine()   -> Promise<namespace> ber-cache; gagal muat = cache dikosongkan supaya bisa dicoba lagi
//   onEngine(cb)   -> cb dipanggil SEKALI begitu mesin siap (langsung bila sudah siap); dipakai untuk menggambar ulang tampilan
//   setEngine(ns)  -> memasang mesin dari luar (dipakai tes dan loadEngine)
let eng = null, loading = null, subs = [];

export const getEngine = () => eng;

export function setEngine(ns) {
  if (!ns || eng) return eng;
  eng = ns;
  const cbs = subs; subs = [];
  cbs.forEach((f) => { try { f(); } catch (_) { /* penonton rusak tidak boleh menahan yang lain */ } });
  return eng;
}

export function loadEngine() {
  if (eng) return Promise.resolve(eng);
  if (!loading) loading = import('./rumus.js').then((m) => setEngine(m), (e) => { loading = null; throw e; });
  return loading;
}

export function onEngine(cb) { if (typeof cb !== 'function') return; if (eng) { try { cb(); } catch (_) { /* diabaikan */ } } else subs.push(cb); }

// Adakah lembar kerja berumus di data? (penjaga: mesin hanya dimuat bila ya)
export function sheetsHaveFx(sheets) {
  try {
    return Object.values(sheets || {}).some((sh) => sh && Array.isArray(sh.tabs) && sh.tabs.some((t) => t && Array.isArray(t.rows) && t.rows.some((r) => r && r.cells && Object.keys(r.cells).some((k) => r.cells[k] && typeof r.cells[k].fx === 'string'))));
  } catch (_) { return false; }
}
