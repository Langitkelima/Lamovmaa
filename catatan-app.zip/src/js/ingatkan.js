// Rev 101 / U5a: mesin "Ingatkan saya" (MURNI: tanpa DOM, tanpa AndroidAPI, tanpa Intl; dites di Node). Belum dipanggil UI.
// Dipakai nanti oleh: lonceng kotak centang (K2b, `note.cbRem`) dan pengingat hitung mundur (K8b, `note.cdRem`).
// Semua waktu = milidetik epoch, dihitung dengan zona waktu LOKAL perangkat (new Date(y, m, d, h, mi)), bukan UTC.
// ID alarm: cb:<idCatatan>:<cid>  (+ :m1..:m12 untuk Bulanan)  dan  cd:<idCatatan>:<bid>:<n hari sebelum>. id dari newId() tidak memuat ':'.

import { cleanMode, withMode } from './logic.js';
export const DAY_MS = 24 * 60 * 60 * 1000;
export const REPEATS = ['none', 'daily', 'weekly', 'monthly'];
export const REPEAT_LABELS = { none: 'Tidak', daily: 'Harian', weekly: 'Mingguan', monthly: 'Bulanan' };
export const MAX_CB_PER_NOTE = 30; // maks. pengingat kotak centang per catatan
export const MONTHLY_COUNT = 12; // Bulanan = 12 kemunculan berikutnya sebagai 12 ID terpisah (native tidak punya ulang bulanan)
export const MAX_PLAN_PER_NOTE = 60; // batas alarm per catatan; bila lebih, yang terdekat dipertahankan
export const MIN_LEAD_MS = 60000; // alarm yang waktunya < 1 menit lagi dianggap sudah lewat
export const CD_BEFORE = [0, 1, 3, 7]; // hitung mundur: hari sebelum (0 = hari-H)
export const CD_MAX_PER_BLOCK = 4;
export const CD_MAX_BLOCKS = 10;
export const CD_DEFAULT_TIME = '09:00';
export const CD_PRESETS = [
  { beforeDays: 0, label: 'Hari-H' },
  { beforeDays: 1, label: '1 hari sebelum' },
  { beforeDays: 3, label: '3 hari sebelum' },
  { beforeDays: 7, label: '7 hari sebelum' },
];
export const CID_RE = /^[a-z0-9]{4,10}$/;
const BID_RE = /^[A-Za-z0-9]{3,24}$/;
const DATE_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

// ---------- aturan satu pengingat kotak centang ----------
// Bentuk tersimpan: { at, repeat: 'none'|'daily'|'weekly'|'monthly', sticky: false }. `sticky` selalu false (K2c dibatalkan pengguna).
export function normalizeCbRule(r) {
  if (!r || typeof r !== 'object') return null;
  const at = Number(r.at);
  if (!Number.isFinite(at) || at <= 0) return null;
  return withMode({ at: Math.trunc(at), repeat: REPEATS.includes(r.repeat) ? r.repeat : 'none', sticky: false }, r.mode); // Rev 378 / AL2: `mode` hanya ada bila 'alarm'
}

// Membersihkan `note.cbRem`: kunci cid valid, aturan valid, hanya cid yang MASIH ADA di catatan (validCids = Set/array/null), maks. 30.
export function cleanCbRem(rem, validCids = null) {
  const out = {};
  if (!rem || typeof rem !== 'object' || Array.isArray(rem)) return out;
  const allow = validCids == null ? null : new Set(validCids);
  let n = 0;
  for (const cid of Object.keys(rem)) {
    if (n >= MAX_CB_PER_NOTE) break;
    if (!CID_RE.test(cid) || (allow && !allow.has(cid))) continue;
    const r = normalizeCbRule(rem[cid]);
    if (r) { out[cid] = r; n++; }
  }
  return out;
}

// cid yang ada di HTML catatan (atribut data-cid pada baris centang). Tanpa DOM, jadi aman di Node.
export function cidsInHtml(html) {
  const out = []; const re = /\bdata-cid="([a-z0-9]{4,10})"/g; let m;
  const s = String(html || '');
  while ((m = re.exec(s))) if (!out.includes(m[1])) out.push(m[1]);
  return out;
}

// cid baru (5-7 karakter acak huruf kecil/angka) yang belum dipakai. rnd bisa disuntik untuk tes.
export function newCid(used = [], rnd = Math.random) {
  const set = new Set(used); const al = 'abcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < 50; i++) {
    let s = ''; const len = 5 + Math.floor(rnd() * 3);
    for (let k = 0; k < len; k++) s += al[Math.floor(rnd() * al.length)];
    if (!set.has(s)) return s;
  }
  return 'c' + Date.now().toString(36).slice(-6);
}

// ---------- tanggal lokal ----------
const at = (y, m0, d, h = 0, mi = 0) => new Date(y, m0, d, h, mi, 0, 0).getTime();
const dim = (y, m0) => new Date(y, m0 + 1, 0).getDate(); // jumlah hari dalam bulan
const addDays = (ts, n) => { const d = new Date(ts); return at(d.getFullYear(), d.getMonth(), d.getDate() + n, d.getHours(), d.getMinutes()); };

// n kemunculan berikutnya (> now) dari aturan {at, repeat}. none: [at] bila belum lewat. daily/weekly: kelipatan hari kalender (aman DST).
// monthly: tanggal yang sama tiap bulan, dijepit ke akhir bulan terpendek (31 Jan -> 28/29 Feb -> 31 Mar), TANPA drift (selalu dihitung dari tanggal awal).
export function nextOccurrences(rule, now, n = 1) {
  const r = normalizeCbRule(rule); const cnt = Math.max(0, Math.min(60, Math.trunc(n)));
  if (!r || !cnt) return [];
  if (r.repeat === 'none') return r.at > now ? [r.at] : [];
  const out = [];
  if (r.repeat === 'daily' || r.repeat === 'weekly') {
    const step = r.repeat === 'daily' ? 1 : 7;
    let k = 0;
    if (r.at <= now) k = Math.max(0, Math.floor((now - r.at) / (step * DAY_MS)) - 1); // loncat dekat, lalu maju satu-satu (koreksi DST)
    let t = addDays(r.at, k * step);
    while (t <= now) t = addDays(t, step);
    for (let i = 0; i < cnt; i++) { out.push(t); t = addDays(t, step); }
    return out;
  }
  const a = new Date(r.at), y0 = a.getFullYear(), m0 = a.getMonth(), d0 = a.getDate(), h = a.getHours(), mi = a.getMinutes();
  for (let k = 0; out.length < cnt && k < 2400; k++) {
    const total = m0 + k, y = y0 + Math.floor(total / 12), m = ((total % 12) + 12) % 12;
    const t = at(y, m, Math.min(d0, dim(y, m)), h, mi);
    if (t > now) out.push(t);
  }
  return out;
}

// ---------- preset lembar "Ingatkan saya" ----------
// "Nanti hari ini 14.00" hanya bila masih di depan; bila tidak, "Nanti malam 20.00" bila masih di depan; bila keduanya lewat, tidak ada preset hari ini.
// "Besok pagi 09.00". "Akhir pekan ini" = Sabtu 09.00; bila hari ini Sabtu/Minggu: "Akhir pekan depan" = Sabtu minggu depan.
export function presetsFor(now) {
  const d = new Date(now), y = d.getFullYear(), m = d.getMonth(), day = d.getDate(), wd = d.getDay(); // 0 = Minggu ... 6 = Sabtu
  const out = [];
  const t14 = at(y, m, day, 14), t20 = at(y, m, day, 20);
  if (t14 > now + MIN_LEAD_MS) out.push({ id: 'later', label: 'Nanti hari ini 14.00', at: t14 });
  else if (t20 > now + MIN_LEAD_MS) out.push({ id: 'evening', label: 'Nanti malam 20.00', at: t20 });
  out.push({ id: 'tomorrow', label: 'Besok pagi 09.00', at: at(y, m, day + 1, 9) });
  const toSat = wd === 6 ? 7 : wd === 0 ? 6 : 6 - wd;
  out.push({ id: 'weekend', label: wd === 0 || wd === 6 ? 'Akhir pekan depan Sab 09.00' : 'Akhir pekan ini Sab 09.00', at: at(y, m, day + toSat, 9) });
  return out;
}

// ---------- ID alarm ----------
export const cbId = (noteId, cid, m = 0) => 'cb:' + noteId + ':' + cid + (m ? ':m' + m : '');
export const cdId = (noteId, bid, beforeDays) => 'cd:' + noteId + ':' + bid + ':' + beforeDays;
// Semua ID yang mungkin dipakai satu pengingat kotak centang (untuk membatalkan tanpa tahu aturan lamanya).
export function allCbIds(noteId, cid) {
  const ids = [cbId(noteId, cid)];
  for (let i = 1; i <= MONTHLY_COUNT; i++) ids.push(cbId(noteId, cid, i));
  return ids;
}
export const allCdIds = (noteId, bid) => CD_BEFORE.map((n) => cdId(noteId, bid, n));
// "cb:<note>:<cid>[:mN]" atau "cd:<note>:<bid>:<n>" -> bagian-bagiannya; selain itu null (untuk ketukan notifikasi).
export function parseAlarmId(id) {
  const p = String(id || '').split(':');
  if (p[0] === 'cb' && (p.length === 3 || (p.length === 4 && /^m([1-9]|1[0-2])$/.test(p[3]))) && p[1] && CID_RE.test(p[2])) return { kind: 'cb', noteId: p[1], cid: p[2] };
  if (p[0] === 'cd' && p.length === 4 && p[1] && BID_RE.test(p[2]) && CD_BEFORE.includes(Number(p[3]))) return { kind: 'cd', noteId: p[1], bid: p[2], beforeDays: Number(p[3]) };
  return null;
}

// ---------- rencana alarm kotak centang ----------
// rows = { [cid]: { text, done } } untuk baris yang MASIH ada di catatan (pemanggil membacanya dari HTML).
// Mengembalikan [{ id, at, title, message, repeatMs }]; at = waktu kemunculan pertama berikutnya; repeatMs = 0 (sekali), 1 hari, atau 7 hari.
// Tidak = sekali; Harian/Mingguan = SATU alarm berulang (native yang mengulang); Bulanan = 12 alarm terpisah (:m1..:m12).
// Baris yang sudah dicentang: pengingat "Tidak" dilewati (centang = selesai) [USULAN]; ulang tetap berjalan sampai dibuang.
export function planCbAlarms(note, rows, now) {
  const out = [];
  if (!note || !note.id) return out;
  const rem = cleanCbRem(note.cbRem, rows ? Object.keys(rows) : []);
  const title = String(note.title || 'Catatan').slice(0, 80);
  for (const cid of Object.keys(rem)) {
    const rule = rem[cid], row = rows[cid] || {};
    if (row.done && rule.repeat === 'none') continue;
    const message = String(row.text || '').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Ada baris yang ingin kamu ingat.';
    if (rule.repeat === 'monthly') {
      nextOccurrences(rule, now + MIN_LEAD_MS, MONTHLY_COUNT).forEach((t, i) => out.push(withMode({ id: cbId(note.id, cid, i + 1), at: t, title, message, repeatMs: 0 }, rule.mode)));
      continue;
    }
    const [t] = nextOccurrences(rule, now + MIN_LEAD_MS, 1);
    if (!t) continue;
    out.push(withMode({ id: cbId(note.id, cid), at: t, title, message, repeatMs: rule.repeat === 'daily' ? DAY_MS : rule.repeat === 'weekly' ? 7 * DAY_MS : 0 }, rule.mode));
  }
  return out.length > MAX_PLAN_PER_NOTE ? out.sort((a, b) => a.at - b.at).slice(0, MAX_PLAN_PER_NOTE) : out;
}

// ---------- hitung mundur ----------
// note.cdRem = { [bid]: [beforeDays, ...] } (bentuk final U5c): hanya beforeDays tersimpan; waktu alarm SELALU dihitung dari tanggal+jam kartu
// (spesifikasi awal menyimpan juga `at`; dibuang karena basi begitu tanggal kartu diubah).
export function cleanCdRem(rem, validBids = null) {
  const out = {};
  if (!rem || typeof rem !== 'object' || Array.isArray(rem)) return out;
  const allow = validBids == null ? null : new Set(validBids);
  let blocks = 0;
  for (const bid of Object.keys(rem)) {
    if (blocks >= CD_MAX_BLOCKS) break;
    if (!BID_RE.test(bid) || (allow && !allow.has(bid)) || !Array.isArray(rem[bid])) continue;
    const list = [];
    for (const v of rem[bid]) { const n = Number(v); if (CD_BEFORE.includes(n) && !list.includes(n) && list.length < CD_MAX_PER_BLOCK) list.push(n); }
    if (list.length) { out[bid] = list.sort((a, b) => a - b); blocks++; }
  }
  return out;
}

// Rev 378 / AL2: mode alarm per kartu hitung mundur, disimpan TERPISAH di `note.cdMode` = { [bid]: 'alarm' } (cdRem tetap daftar angka, bentuk lama utuh).
// Hanya 'alarm' yang disimpan; bid harus sah dan (bila validBids diberikan) masih ada di catatan.
export function cleanCdMode(map, validBids = null) {
  const out = {};
  if (!map || typeof map !== 'object' || Array.isArray(map)) return out;
  const allow = validBids == null ? null : new Set(validBids);
  for (const bid of Object.keys(map)) if (BID_RE.test(bid) && (!allow || allow.has(bid)) && cleanMode(map[bid]) === 'alarm') out[bid] = 'alarm';
  return out;
}

// Waktu (ms) tanggal 'YYYY-MM-DD' jam 'HH:MM' lokal; jam kosong/tidak sah = 09:00. Tanggal tidak sah (mis. 2027-02-30) = 0.
export function dateTimeMs(dateIso, time) {
  const m = DATE_RE.exec(String(dateIso || '')); if (!m) return 0;
  const y = Number(m[1]), mo = Number(m[2]) - 1, d = Number(m[3]);
  const probe = new Date(y, mo, d); if (probe.getFullYear() !== y || probe.getMonth() !== mo || probe.getDate() !== d) return 0;
  const tm = TIME_RE.exec(String(time || '')) || TIME_RE.exec(CD_DEFAULT_TIME);
  return at(y, mo, d, Number(tm[1]), Number(tm[2]));
}

// blocks = { [bid]: { date, time, title } } kartu hitung mundur yang MASIH ada. Alarm lewat/hampir lewat tidak dibuat.
// Pesan: hari-H "<judul>: hari ini."; n hari sebelum "<judul>: n hari lagi."
export function planCdAlarms(note, blocks, now) {
  const out = [];
  if (!note || !note.id) return out;
  const rem = cleanCdRem(note.cdRem, blocks ? Object.keys(blocks) : []);
  const title = String(note.title || 'Catatan').slice(0, 80);
  for (const bid of Object.keys(rem)) {
    const b = blocks[bid] || {};
    const base = dateTimeMs(b.date, b.time); if (!base) continue;
    const name = String(b.title || 'Hitung mundur').replace(/\s+/g, ' ').trim().slice(0, 60);
    for (const n of rem[bid]) {
      const t = addDays(base, -n);
      if (t > now + MIN_LEAD_MS) out.push(withMode({ id: cdId(note.id, bid, n), at: t, title, message: n === 0 ? name + ': hari ini.' : name + ': ' + n + ' hari lagi.', repeatMs: 0 }, note.cdMode && note.cdMode[bid]));
    }
  }
  return out.length > MAX_PLAN_PER_NOTE ? out.sort((a, b) => a.at - b.at).slice(0, MAX_PLAN_PER_NOTE) : out;
}

// ---------- Rev 102 / U5b: membaca HTML catatan (TANPA DOM, aman di Node) ----------
// Dipakai modul glue `cb-alarm.js` dan `normalize()` agar jadwal dihitung dari isi catatan yang tersimpan.
export const BID_PATTERN = BID_RE;
const decodeEnt = (s) => String(s).replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'").replace(/&amp;/g, '&');
const attrOf = (tag, name) => { const m = new RegExp('\\b' + name + '="([^"]*)"').exec(tag); return m ? decodeEnt(m[1]) : ''; };

// bid (id blok hitung mundur, atribut data-kb-id) yang ada di HTML catatan.
export function bidsInHtml(html) {
  const out = []; const re = /\bdata-kb-id="([A-Za-z0-9]{3,24})"/g; let m;
  const s = String(html || '');
  while ((m = re.exec(s))) if (!out.includes(m[1])) out.push(m[1]);
  return out;
}

// { [cid]: { text, done } } untuk baris centang ber-data-cid DAN (Rev 346 / R1) item daftar `li` ber-data-cid (done selalu false). cid kembar: yang PERTAMA menurut urutan dokumen dipakai.
// Teks `li` = teks item itu saja (berhenti di sub-daftar `ul`/`ol` atau `li` berikutnya). Teks dipadatkan (spasi tunggal), tag dibuang.
export function rowsFromHtml(html) {
  const s = String(html || ''), found = []; let m;
  const re = /<div\b([^>]*\bclass="todo"[^>]*)>([\s\S]*?)<\/div>/g;
  while ((m = re.exec(s))) found.push({ at: m.index, tag: m[1], inner: m[2], li: false });
  const rl = /<li\b([^>]*\bdata-cid="[^"]*"[^>]*)>([\s\S]*?)(?=<ul\b|<ol\b|<li\b|<\/li>|$)/g;
  while ((m = rl.exec(s))) found.push({ at: m.index, tag: m[1], inner: m[2], li: true });
  found.sort((a, b) => a.at - b.at);
  const out = {};
  for (const f of found) {
    const cid = attrOf(f.tag, 'data-cid');
    if (!CID_RE.test(cid) || out[cid]) continue;
    const done = !f.li && /<input\b[^>]*\bchecked\b/.test(f.inner);
    out[cid] = { text: decodeEnt(f.inner.replace(/<[^>]*>/g, '')).replace(/\s+/g, ' ').trim(), done };
  }
  return out;
}

// { [bid]: { date, time, title } } untuk kartu hitung mundur ber-data-kb-id. bid kembar: yang PERTAMA dipakai.
export function blocksFromHtml(html) {
  const out = {}; const re = /<div\b([^>]*\bkb-countdown-block[^>]*)>/g; let m;
  const s = String(html || '');
  while ((m = re.exec(s))) {
    const bid = attrOf(m[1], 'data-kb-id');
    if (!BID_RE.test(bid) || out[bid]) continue;
    out[bid] = { date: attrOf(m[1], 'data-kb-date'), time: attrOf(m[1], 'data-kb-time'), title: attrOf(m[1], 'data-kb-title') };
  }
  return out;
}

// Membersihkan pengingat satu catatan terhadap isinya: cbRem hanya untuk cid yang ada, cdRem hanya untuk bid yang ada. Mengembalikan { cbRem, cdRem } (objek kosong bila tidak ada).
export function cleanNoteRem(note) {
  const html = note && note.html;
  const cdRem = cleanCdRem(note && note.cdRem, bidsInHtml(html));
  const cdMode = cleanCdMode(note && note.cdMode, Object.keys(cdRem));
  return { cbRem: cleanCbRem(note && note.cbRem, cidsInHtml(html)), cdRem, ...(Object.keys(cdMode).length ? { cdMode } : {}) }; // Rev 378 / AL2: cdMode hanya ada bila terisi (bentuk lama utuh) dan hanya untuk kartu yang masih punya pengingat
}

// ---------- Rev 103 / U5c: bantu lembar "Ingatkan saya" + lonceng baris centang (MURNI, tanpa DOM/Intl) ----------
const HARI = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const p2 = (n) => String(n).padStart(2, '0');
export const REPEAT_HINTS = { none: 'Sekali saja', daily: 'Setiap hari', weekly: 'Setiap minggu', monthly: 'Setiap bulan' };

// "Sen, 9 Nov 09.00" (tahun hanya bila bukan tahun `now`). Jam memakai titik seperti preset ("14.00").
export function formatRemindAt(ts, now = Date.now()) {
  const d = new Date(ts); if (!Number.isFinite(d.getTime())) return '';
  const yr = d.getFullYear() !== new Date(now).getFullYear() ? ' ' + d.getFullYear() : '';
  return HARI[d.getDay()] + ', ' + d.getDate() + ' ' + BULAN[d.getMonth()] + yr + ' ' + p2(d.getHours()) + '.' + p2(d.getMinutes());
}
// Ringkasan satu aturan: "Sen, 9 Nov 09.00 · Setiap hari". Untuk aturan berulang yang `at`-nya sudah lewat, yang ditampilkan kemunculan BERIKUTNYA.
export function describeRule(rule, now = Date.now()) {
  const r = normalizeCbRule(rule); if (!r) return '';
  const [t] = nextOccurrences(r, now, 1);
  const when = formatRemindAt(t || r.at, now);
  return r.repeat === 'none' ? when : when + ' · ' + REPEAT_HINTS[r.repeat];
}
// Pengingat "hidup" = masih akan berbunyi: berulang selalu hidup; sekali hanya bila waktunya masih di depan (lewat >= 1 menit lalu dianggap selesai).
export function ruleIsLive(rule, now = Date.now()) {
  const r = normalizeCbRule(rule); if (!r) return false;
  return r.repeat !== 'none' || r.at > now + MIN_LEAD_MS;
}
// Keadaan lonceng satu baris: 'on' (ada pengingat yang masih berbunyi), 'idle' (baris aktif tanpa pengingat), 'off' (baris dicentang tanpa pengingat hidup: lonceng disembunyikan).
// Baris dicentang dengan pengingat "Tidak" = alarmnya dihentikan (planCbAlarms melewatinya), jadi dianggap tidak hidup; berulang tetap 'on'.
export function bellState(rule, done, now = Date.now()) {
  const r = normalizeCbRule(rule);
  const live = !!r && ruleIsLive(r, now) && !(done && r.repeat === 'none');
  if (live) return 'on';
  return done ? 'off' : 'idle';
}
// Memeriksa pilihan di lembar sebelum disimpan. at = ms; kembalikan { ok, reason? }.
export function checkChoice(at, repeat, now = Date.now()) {
  if (!Number.isFinite(at) || at <= 0) return { ok: false, reason: 'Pilih tanggal dan waktu dulu.' };
  if (at <= now + MIN_LEAD_MS) return { ok: false, reason: 'Pilih waktu yang masih di depan.' };
  if (!REPEATS.includes(repeat)) return { ok: false, reason: 'Pilih pengulangan yang valid.' };
  return { ok: true };
}
// Menulis/menghapus satu aturan di objek catatan. cid baru ditolak bila catatan sudah punya MAX_CB_PER_NOTE pengingat. Mengembalikan true bila tersimpan.
export function setCbRule(note, cid, rule) {
  if (!note || !CID_RE.test(String(cid))) return false;
  const r = normalizeCbRule(rule); if (!r) return false;
  const rem = note.cbRem && typeof note.cbRem === 'object' ? note.cbRem : {};
  if (!(cid in rem) && Object.keys(rem).length >= MAX_CB_PER_NOTE) return false;
  rem[cid] = r; note.cbRem = rem; return true;
}
export function clearCbRule(note, cid) {
  if (!note || !note.cbRem || !(cid in note.cbRem)) return false;
  delete note.cbRem[cid]; if (!Object.keys(note.cbRem).length) delete note.cbRem; return true;
}

// ---------- Rev 104 / U5d: pengingat kartu Hitung mundur (MURNI, tanpa DOM/Intl) ----------
// bid (id kartu) baru 6-8 karakter huruf kecil/angka yang belum dipakai. Diberikan LAZY: kartu baru dapat bid saat pengingat pertamanya disimpan.
export function newBid(used = [], rnd = Math.random) {
  const set = new Set(used); const al = 'abcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < 50; i++) {
    let s = ''; const len = 6 + Math.floor(rnd() * 3);
    for (let k = 0; k < len; k++) s += al[Math.floor(rnd() * al.length)];
    if (!set.has(s)) return s;
  }
  return 'b' + Date.now().toString(36).slice(-7);
}

// Pilihan di lembar untuk satu kartu { date, time }: tiap preset CD_PRESETS dengan waktu bunyinya, `ok` bila masih di depan (>= 1 menit), `when` = teks waktunya.
// Kartu tanpa tanggal sah = [] (tidak ada yang bisa dijadwalkan). Jam kartu kosong = 09.00 (dateTimeMs).
export function cdOptions(block, now = Date.now()) {
  const base = block ? dateTimeMs(block.date, block.time) : 0;
  if (!base) return [];
  return CD_PRESETS.map((p) => { const t = addDays(base, -p.beforeDays); return { beforeDays: p.beforeDays, label: p.label, at: t, ok: t > now + MIN_LEAD_MS, when: formatRemindAt(t, now) }; });
}
// Menulis satu daftar "hari sebelum" untuk kartu bid. Daftar kosong = hapus. bid baru ditolak bila catatan sudah punya CD_MAX_BLOCKS kartu berpengingat. true bila tersimpan.
export function setCdRule(note, bid, list) {
  if (!note || !BID_RE.test(String(bid))) return false;
  const clean = cleanCdRem({ [bid]: list }, null)[bid];
  if (!clean) return clearCdRule(note, bid);
  const rem = note.cdRem && typeof note.cdRem === 'object' && !Array.isArray(note.cdRem) ? note.cdRem : {};
  if (!(bid in rem) && Object.keys(rem).length >= CD_MAX_BLOCKS) return false;
  rem[bid] = clean; note.cdRem = rem; return true;
}
export function clearCdRule(note, bid) {
  if (!note || !note.cdRem || !(bid in note.cdRem)) return false;
  delete note.cdRem[bid]; if (!Object.keys(note.cdRem).length) delete note.cdRem;
  if (note.cdMode && bid in note.cdMode) { delete note.cdMode[bid]; if (!Object.keys(note.cdMode).length) delete note.cdMode; } // Rev 378 / AL2: mode ikut hilang bersama aturan
  return true;
}
// Rev 378 / AL2: set/hapus mode alarm satu kartu hitung mundur (hanya untuk kartu yang punya pengingat). true bila tersimpan.
export function setCdMode(note, bid, mode) {
  if (!note || !BID_RE.test(String(bid)) || !note.cdRem || !(bid in note.cdRem)) return false;
  const m = note.cdMode && typeof note.cdMode === 'object' && !Array.isArray(note.cdMode) ? note.cdMode : {};
  if (cleanMode(mode) === 'alarm') m[bid] = 'alarm'; else delete m[bid];
  if (Object.keys(m).length) note.cdMode = m; else delete note.cdMode;
  return true;
}
// Jumlah pengingat kartu yang MASIH akan berbunyi (untuk label chip). 0 = chip biasa "Ingatkan saya".
export function cdLiveCount(list, block, now = Date.now()) {
  return cdOptions(block, now).filter((o) => o.ok && Array.isArray(list) && list.includes(o.beforeDays)).length;
}
