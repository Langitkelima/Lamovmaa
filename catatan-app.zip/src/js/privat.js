// Catatan Privat: buat PIN, buka dengan PIN, kunci otomatis.
import { h, ico, PATH, dlg, lockArt, judul, tOk } from './ui.js';
import { validatePin, newSalt, hashPin, verifyPin, failState, lockRemaining, pinKey } from './security.js';
import { viewNoteList, closeEditor } from './notes.js';

export function lockPrivat(ctx) {
  ctx.ui.unlocked = false;
  closeEditor('priv'); ctx.render();
}

const KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'];
const pinPad = (onKey) => h('div', { class: 'pad' }, KEYS.map((k) => (k === ''
  ? h('span', { 'aria-hidden': 'true' })
  : h('button', { type: 'button', class: 'pk', 'aria-label': k === 'del' ? 'Hapus satu angka' : k, onclick: () => onKey(k) }, k === 'del' ? ico(PATH.del) : k))));
const drawDots = (el, n) => el.replaceChildren(...Array.from({ length: Math.max(4, n) }, (_, i) => h('i', { class: i < n ? 'f' : '' })));

function setupView(ctx) {
  const { data, ui } = ctx; const s = data.settings;
  let stage = 1, first = '', cur = '';
  const msg = h('p', { class: 'sub mid' });
  const dots = h('div', { class: 'dots', role: 'img', 'aria-label': 'Angka PIN yang dimasukkan' });
  const err = h('p', { class: 'err mid', role: 'alert' });
  const btn = h('button', { type: 'button', class: 'btn' });
  const refresh = () => {
    msg.textContent = stage === 1 ? 'Buat PIN 4 sampai 6 angka untuk mengunci catatan privatmu.' : 'Ulangi PIN yang sama.';
    btn.textContent = stage === 1 ? 'Lanjut' : 'Simpan PIN'; btn.disabled = cur.length < 4; drawDots(dots, cur.length);
  };
  const press = (k) => { cur = pinKey(cur, k); err.textContent = ''; refresh(); };
  btn.onclick = async () => {
    const v = validatePin(cur); if (!v.ok) { err.textContent = v.msg; return; }
    if (stage === 1) { first = cur; cur = ''; stage = 2; refresh(); return; }
    if (cur !== first) { err.textContent = 'PIN tidak sama. Coba ulangi dari awal.'; stage = 1; first = ''; cur = ''; refresh(); return; }
    try {
      s.pinSalt = newSalt(); s.pinHash = await hashPin(first, s.pinSalt);
      s.pinFails = 0; s.pinLockUntil = 0; ctx.persist(); ui.unlocked = true; ctx.render(); tOk('PIN dibuat.');
    } catch (e) { console.error('buat PIN gagal:', e); s.pinHash = ''; err.textContent = 'Perangkat ini tidak mendukung pembuatan PIN.'; }
  };
  refresh();
  return [judul('privat'), lockArt(), msg, dots, err, pinPad(press), btn];
}

function lockView(ctx) {
  const { data, ui } = ctx; const s = data.settings;
  clearTimeout(ui.waitTimer);
  let cur = '';
  const dots = h('div', { class: 'dots', role: 'img', 'aria-label': 'Angka PIN yang dimasukkan' });
  const err = h('p', { class: 'err mid', role: 'alert' });
  const btn = h('button', { type: 'button', class: 'btn' }, 'Buka');
  const locked = () => lockRemaining(s.pinLockUntil, Date.now()) > 0;
  const sync = () => { drawDots(dots, cur.length); btn.disabled = cur.length < 4 || locked(); };
  const wait = () => {
    const r = lockRemaining(s.pinLockUntil, Date.now());
    if (r > 0) { err.textContent = `Terlalu banyak percobaan. Coba lagi dalam ${r} detik.`; ui.waitTimer = setTimeout(wait, 1000); }
    else if (err.textContent.startsWith('Terlalu')) err.textContent = '';
    sync();
  };
  const press = (k) => { if (locked()) return; cur = pinKey(cur, k); if (!err.textContent.startsWith('Terlalu')) err.textContent = ''; sync(); };
  const unlock = async () => {
    if (locked()) return;
    if (cur.length < 4) { err.textContent = 'Masukkan PIN dulu.'; return; }
    let ok = false;
    try { ok = await verifyPin(cur, s.pinSalt, s.pinHash); } catch (e) { console.error('cek PIN gagal:', e); }
    if (ok) { s.pinFails = 0; s.pinLockUntil = 0; ctx.persist(); ui.unlocked = true; ctx.render(); return; }
    const f = failState(s.pinFails || 0, Date.now()); s.pinFails = f.fails; s.pinLockUntil = f.lockUntil;
    ctx.persist(); cur = ''; err.textContent = 'PIN salah.'; sync(); wait();
  };
  const forgot = () => {
    dlg({ title: 'Lupa PIN?', msg: 'Satu-satunya cara adalah menghapus SEMUA catatan privat dan PIN. Langkah 1 dari 2.', yes: 'Lanjut', no: () => {},
      ok: () => dlg({ title: 'Yakin hapus semuanya?', msg: 'Semua catatan privat hilang permanen dan tidak bisa dikembalikan. Langkah 2 dari 2.', yes: 'Hapus semua', red: true, reverse: true, no: () => {},
        ok: () => { data.priv = []; s.pinHash = ''; s.pinSalt = ''; s.pinFails = 0; s.pinLockUntil = 0; ctx.persist(); ui.unlocked = false; ctx.render(); tOk('Catatan privat dihapus. Buat PIN baru.'); } }) });
  };
  btn.onclick = unlock;
  wait();
  return [judul('privat'), lockArt(), h('p', { class: 'sub mid' }, 'Masukkan PIN untuk membuka catatan privatmu.'),
    dots, err, pinPad(press), btn, h('button', { type: 'button', class: 'linkbtn', onclick: forgot }, 'Lupa PIN?')];
}

export function viewPrivat(ctx) {
  if (!ctx.data.settings.pinHash) return setupView(ctx);
  if (!ctx.ui.unlocked) return lockView(ctx);
  return [...viewNoteList(ctx, 'priv'), h('button', { type: 'button', class: 'btn line', onclick: () => lockPrivat(ctx) }, 'Kunci sekarang')];
}
