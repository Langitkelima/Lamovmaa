// PIN: disimpan sebagai hash (PBKDF2), bukan teks asli. Catatan privat sendiri TIDAK dienkripsi (pilihan pengguna).
export function validatePin(p) {
  return /^\d{4,6}$/.test(String(p ?? '')) ? { ok: true } : { ok: false, msg: 'PIN harus 4 sampai 6 angka.' };
}
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
export function newSalt() {
  const a = new Uint8Array(16); globalThis.crypto.getRandomValues(a); return hex(a);
}
export async function hashPin(pin, saltHex) {
  const key = await globalThis.crypto.subtle.importKey('raw', new TextEncoder().encode(String(pin)), 'PBKDF2', false, ['deriveBits']);
  const salt = Uint8Array.from(saltHex.match(/../g).map((x) => parseInt(x, 16)));
  const bits = await globalThis.crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, key, 256);
  return hex(bits);
}
export async function verifyPin(pin, saltHex, hashHex) {
  return (await hashPin(pin, saltHex)) === hashHex;
}
// Setiap 5 kali salah: kunci sementara 30 dtk, lalu berlipat, maksimal 15 menit.
export function failState(fails, now) {
  const f = fails + 1; let lockUntil = 0;
  if (f % 5 === 0) lockUntil = now + Math.min(30 * 2 ** (f / 5 - 1), 900) * 1000;
  return { fails: f, lockUntil };
}
export function lockRemaining(lockUntil, now) {
  return Math.max(0, Math.ceil(((lockUntil || 0) - now) / 1000));
}

// Papan angka PIN: tambah angka (maks 6) atau hapus satu angka. Mengembalikan teks PIN yang baru.
export function pinKey(cur, key, max = 6) {
  const c = String(cur ?? '');
  if (key === 'del') return c.slice(0, -1);
  return /^\d$/.test(String(key)) && c.length < max ? c + key : c;
}
