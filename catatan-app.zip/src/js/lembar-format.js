// Rev 132 / U8a-5: FORMAT ANGKA sel lembar kerja (nf). MURNI: tanpa DOM, penyimpanan, native, eval. Nilai mentah TIDAK berubah; format hanya saat tampil.
// Bentuk simpan (di gaya sel `s.nf`): {k:'number', d?} | {k:'percent', d} | {k:'currency', c:'IDR', d} | {k:'date', p:'short'}. d = desimal 0..6.
// Tampilan gaya Indonesia: titik = ribuan, koma = desimal. Hanya nilai ANGKA yang diformat; teks, boolean, galat, dan sel kosong tidak disentuh (formatNumber -> null).
export const MAX_DEC = 6;
const D0 = Date.UTC(1899, 11, 30); // nomor seri gaya Excel, sama dengan serialOf di rumus.js

export function cleanNf(x) {
  if (!x || typeof x !== 'object') return undefined;
  const d = Number.isInteger(x.d) && x.d >= 0 && x.d <= MAX_DEC ? x.d : undefined;
  if (x.k === 'number') return d === undefined ? { k: 'number' } : { k: 'number', d };
  if (x.k === 'percent') return { k: 'percent', d: d === undefined ? 0 : d };
  if (x.k === 'currency') return { k: 'currency', c: 'IDR', d: d === undefined ? 0 : d }; // '*' / kode lain = IDR (hanya Rupiah di tahap ini)
  if (x.k === 'date') return { k: 'date', p: 'short' };
  return undefined;
}

export const NF_PRESETS = [
  { id: 'none', label: 'Umum', nf: null },
  { id: 'number', label: 'Angka', nf: { k: 'number' } },
  { id: 'percent', label: 'Persen', nf: { k: 'percent', d: 0 } },
  { id: 'currency', label: 'Rp', nf: { k: 'currency', c: 'IDR', d: 0 } },
  { id: 'date', label: 'Tanggal', nf: { k: 'date', p: 'short' } },
];
export const nfKey = (nf) => { const f = cleanNf(nf); return f ? f.k : 'none'; };
export const nfLabel = (nf) => { const k = nfKey(nf); const p = NF_PRESETS.find((x) => x.id === k); return p ? p.label : 'Umum'; };

// Tambah/kurangi desimal (delta +1/-1). Mengembalikan nf baru; null bila tidak berlaku (Umum, Tanggal). Di batas 0..MAX_DEC hasilnya sama dengan masukan.
export function stepDecimals(nf, delta) {
  const f = cleanNf(nf); if (!f || f.k === 'date') return null;
  const cur = f.d === undefined ? 0 : f.d, d = Math.min(MAX_DEC, Math.max(0, cur + (delta < 0 ? -1 : 1)));
  return cleanNf({ ...f, d });
}

const group = (s) => s.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
function roundTo(x, d) { const r = Number(Math.round(Number(x + 'e' + d)) + 'e-' + d); return Number.isFinite(r) ? r : Number(x.toFixed(d)); } // 1.005 -> 1.01 (bukan 1.00)
function fixed(a, d) { const s = roundTo(a, d).toFixed(d), p = s.split('.'); return group(p[0]) + (p[1] ? ',' + p[1] : ''); }
const p2 = (n) => (n < 10 ? '0' : '') + n;

// Nomor seri -> 'dd/mm/yyyy'. Di luar 1..2958465 (31 Des 9999) = null.
export function formatDate(serial) {
  if (typeof serial !== 'number' || !Number.isFinite(serial) || serial < 1 || serial >= 2958466) return null;
  const d = new Date(D0 + Math.floor(serial) * 86400000);
  return p2(d.getUTCDate()) + '/' + p2(d.getUTCMonth() + 1) + '/' + d.getUTCFullYear();
}

// Teks tampilan untuk satu ANGKA, atau null bila format tidak berlaku (bukan angka, nf rusak/kosong, terlalu besar, bentuk eksponen).
export function formatNumber(v, nf) {
  if (typeof v !== 'number' || !Number.isFinite(v)) return null;
  const f = cleanNf(nf); if (!f) return null;
  if (f.k === 'date') return formatDate(v);
  let a = Math.abs(v); if (f.k === 'percent') a *= 100;
  if (a >= 1e15) return null;
  let body;
  if (f.k === 'number' && f.d === undefined) { const t = String(Number(a.toPrecision(15))); if (/e/i.test(t)) return null; const p = t.split('.'); body = group(p[0]) + (p[1] ? ',' + p[1] : ''); }
  else body = fixed(a, f.d);
  const sign = v < 0 && /[1-9]/.test(body) ? '-' : ''; // -0,001 dibulatkan ke 0 tidak jadi "-0"
  return f.k === 'percent' ? sign + body + '%' : f.k === 'currency' ? sign + 'Rp ' + body : sign + body;
}

// Rev 133 / U8a-5b: ketikan persen. "25%" / "25,5 %" -> {v: 0.25, d: desimal yang diketik}. Di sel BERFORMAT Persen, angka polos >= 1 (mis. 25) dianggap persen (-> 0.25); angka < 1 tetap mentah (0,25 = 25%).
// Selain itu null (diurus parseInput). d dipakai hanya untuk membuat format Persen otomatis pada sel tanpa format.
export function typedPercent(text, nf) {
  const t = String(text == null ? '' : text).trim(), f = cleanNf(nf);
  const m = /^([-+]?\d+(?:[.,](\d+))?)\s*%$/.exec(t);
  if (m && t.length <= 16) return { v: Number((Number(m[1].replace(',', '.')) / 100).toPrecision(15)), d: Math.min(MAX_DEC, m[2] ? m[2].length : 0), explicit: true };
  if (f && f.k === 'percent' && /^[-+]?\d+(?:[.,]\d+)?$/.test(t) && t.length <= 15) { const n = Number(t.replace(',', '.')); if (Math.abs(n) >= 1) return { v: Number((n / 100).toPrecision(15)), d: f.d, explicit: false }; }
  return null;
}

// Rev 140: SINGKATAN NOMINAL saat mengetik di sel. "6e5" -> 600000, "1,5e3" -> 1500, "2e-2" -> 0.02; "5rb"/"5 ribu" -> 5000, "1,5jt"/"2 juta" -> 2000000.
// MURNI. Mengembalikan ANGKA, atau null bila bukan singkatan (teks lain tetap teks). Hanya dipakai untuk ketikan pengguna (parseInput); impor CSV sengaja TIDAK memakainya (cellFromText).
// Penghitungan lewat Number("mantis" + "e" + pangkat) supaya tepat (1,5jt = 1500000, bukan 1500000.0000000002). Batas: <= 24 huruf, pangkat -6..15, |hasil| < 1e15.
const SHORT_E = /^([-+]?\d+(?:[.,]\d+)?)[eE]([-+]?\d{1,2})$/;
const SHORT_ID = /^([-+]?\d+(?:[.,]\d+)?)\s*(rb|ribu|jt|juta)$/i;
export function typedShorthand(text) {
  const t = String(text == null ? '' : text).trim(); if (!t || t.length > 24) return null;
  let m = SHORT_E.exec(t), mant, exp;
  if (m) { mant = m[1]; exp = Number(m[2]); }
  else if ((m = SHORT_ID.exec(t))) { mant = m[1]; exp = /^(rb|ribu)$/i.test(m[2]) ? 3 : 6; }
  else return null;
  if (!Number.isInteger(exp) || exp < -6 || exp > 15) return null;
  const n = Number(mant.replace(',', '.').replace(/^\+/, '') + 'e' + exp);
  return Number.isFinite(n) && Math.abs(n) < 1e15 ? (n === 0 ? 0 : n) : null;
}
