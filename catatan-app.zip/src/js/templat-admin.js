// Rev 290 / T5a: kelompok templat "Admin" bagian 1 (data murni, tanpa impor): Daftar hadir, Surat masuk keluar, Kas kecil, Slip gaji. Bentuk: lihat lembar-templat.js.
const RED = { bg: '#FEE2E2', fg: '#991B1B' }, GRN = { bg: '#DCFCE7', fg: '#166534' }, YEL = { bg: '#FEF9C3', fg: '#854D0E' }, BLU = { bg: '#DBEAFE', fg: '#1E40AF' };
const day = (n) => ({ v: { today: n }, nf: 'date' });
const INP = { s: { bg: '#FEF9C3', fg: '#111827' } }; // kotak isian (kuning muda)
const inp = (v, nf) => ({ v, ...INP, ...(nf ? { nf } : {}) });

// ---- Daftar hadir: Senin-Jumat per orang, rekap per status, donat
const HI = { H: 'Hadir', I: 'Izin', S: 'Sakit', A: 'Alpa' };
const ORANG = [['Ani', 'HHHHH'], ['Budi', 'HHSHH'], ['Cici', 'HIHHH'], ['Dedi', 'AHHHS'], ['Eka', 'HHHHH'], ['Fajar', 'HHAHI'], ['Gita', 'SSHHH'], ['Hadi', 'HHHIH']];
const REKAP = ['Hadir', 'Izin', 'Sakit', 'Alpa'];
const HADIR = {
  id: 'admin-hadir', name: 'Admin · Daftar hadir', desc: 'Absen mingguan dengan dropdown berwarna, persen hadir per orang, rekap dan donat.',
  tab: 'Hadir', w: [36, 100, 70, 70, 70, 70, 70, 60, 70, 24, 90, 70], head: true, nfc: ['', '', '', '', '', '', '', 'num', 'pct', '', '', 'num'],
  rows: [
    ['No', 'Nama', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Hadir', 'Persen', '', 'Rekap', 'Jumlah'],
    ...ORANG.map(([n, p], i) => {
      const r = i + 2, row = [i + 1, n, ...[...p].map((c) => HI[c]), '=COUNTIF(C' + r + ':G' + r + ';"Hadir")', '=IFERROR(H' + r + '/COUNTA(C' + r + ':G' + r + ');0)', ''];
      if (i < 4) row.push(REKAP[i], '=COUNTIF($C$2:$G$30;K' + r + ')'); else if (i === 4) row.push({ v: 'Total', t: true }, { v: '=SUM(L2:L5)', t: true });
      return row;
    }),
  ],
  rules: [{ c: 'I', op: 'lt', a: 0.75, ...RED }, { c: 'I', op: 'gte', a: 0.9, ...GRN }],
  checks: [{ k: 'list', rg: 'C2:G30', items: ['Hadir', 'Izin', 'Sakit', 'Alpa'], cl: { Hadir: GRN, Izin: BLU, Sakit: YEL, Alpa: RED } }],
  charts: [{ kind: 'donut', title: 'Rekap kehadiran', r1: 0, c1: 10, r2: 4, c2: 11, vc: 11 }],
  guide: [
    ['Apa ini?', 'Daftar hadir satu minggu. Tiap sel hari dipilih dari daftar: Hadir, Izin, Sakit, atau Alpa.'],
    ['Cara pakai', 'Ketuk sel hari, lalu pilih statusnya. Kolom Hadir, Persen, dan Rekap berubah sendiri.'],
    ['Warna', 'Tiap status punya warna. Persen 90 ke atas hijau, di bawah 75 merah. Ubah lewat Lainnya > Warna bersyarat.'],
    ['Menambah orang', 'Isi baris kosong di bawah (sampai baris 30). Dropdown dan rumus rekap sudah mencakup sampai baris itu.'],
    ['Minggu berikutnya', 'Salin tab ini lewat tombol tab, lalu kosongkan sel harinya.'],
  ],
};

// ---- Surat masuk keluar: nomor surat otomatis, status dropdown, rekap
const SURAT = [
  ['Masuk', 'Undangan rapat koordinasi', 'Dinas Pendidikan', 'Selesai'], ['Keluar', 'Balasan undangan rapat', 'Dinas Pendidikan', 'Selesai'],
  ['Masuk', 'Permohonan data pegawai', 'BKD Kota', 'Selesai'], ['Masuk', 'Penawaran alat tulis kantor', 'CV Maju Jaya', 'Diproses'],
  ['Keluar', 'Pengajuan anggaran kegiatan', 'Bagian Keuangan', 'Diproses'], ['Masuk', 'Pemberitahuan libur bersama', 'Kementerian', 'Selesai'],
  ['Keluar', 'Surat tugas perjalanan dinas', 'Bapak Budi', 'Selesai'], ['Masuk', 'Tagihan listrik bulan ini', 'PLN', 'Baru'],
  ['Keluar', 'Permohonan perbaikan AC', 'Bagian Umum', 'Diproses'], ['Masuk', 'Undangan seminar nasional', 'Universitas Negeri', 'Baru'],
];
const ST = ['Baru', 'Diproses', 'Selesai'];
const MASUK = {
  id: 'admin-surat', name: 'Admin · Surat masuk keluar', desc: 'Buku surat dengan nomor otomatis, status dropdown berwarna, dan rekap yang cocok difilter.',
  tab: 'Surat', w: [36, 90, 80, 130, 210, 150, 90, 24, 110, 70], head: true, nfc: ['num', '', '', '', '', '', '', '', '', 'num'],
  rows: [
    ['No', 'Tanggal', 'Jenis', 'Nomor surat', 'Perihal', 'Asal / Tujuan', 'Status', '', 'Rekap', 'Jumlah'],
    ...SURAT.map(([j, p, a, s], i) => {
      const r = i + 2, row = [i + 1, day(i - 10), j, '=CONCAT(TEXT(A' + r + ';"000");"/";IF(C' + r + '="Masuk";"SM";"SK");"/";TEXT(MONTH(B' + r + ');"00");"/";YEAR(B' + r + '))', p, a, s, ''];
      const k = [['Baru', 'COUNTIF($G$2:$G$30;I2)'], ['Diproses', 'COUNTIF($G$2:$G$30;I3)'], ['Selesai', 'COUNTIF($G$2:$G$30;I4)'], ['Surat masuk', 'COUNTIF($C$2:$C$30;"Masuk")'], ['Surat keluar', 'COUNTIF($C$2:$C$30;"Keluar")']][i];
      if (k) row.push(k[0], '=' + k[1]); else if (i === 5) row.push({ v: 'Total surat', t: true }, { v: '=COUNTA(A2:A30)', t: true });
      return row;
    }),
  ],
  checks: [{ k: 'list', rg: 'C2:C30', items: ['Masuk', 'Keluar'], cl: { Masuk: BLU, Keluar: YEL } }, { k: 'list', rg: 'G2:G30', items: ST, cl: { Baru: RED, Diproses: YEL, Selesai: GRN } }],
  charts: [{ kind: 'donut', title: 'Status surat', r1: 0, c1: 8, r2: 3, c2: 9, vc: 9 }],
  guide: [
    ['Apa ini?', 'Buku agenda surat masuk dan keluar. Nomor surat dibuat sendiri dari No, Jenis, dan Tanggal.'],
    ['Nomor surat', 'Bentuknya 001/SM/11/2026 (SM = surat masuk, SK = surat keluar). Ubah rumus kolom Nomor kalau format kantormu berbeda.'],
    ['Menambah surat', 'Isi baris kosong di bawah. Untuk No dan nomor surat, ketuk sel terakhir lalu Lainnya > Isi seri > Ke bawah.'],
    ['Mencari surat', 'Lainnya > Filter baris, mis. Status sama dengan Baru, atau Jenis sama dengan Keluar. Filter hanya sementara.'],
    ['Rekap', 'Jumlah per status dan jenis berubah sendiri. Rumusnya sudah mencakup sampai baris 30.'],
  ],
};

// ---- Kas kecil: debet, kredit, saldo berjalan, saldo menipis berwarna, diagram
const KAS = [
  ['Saldo awal', 1000000, ''], ['Beli ATK', '', 85000], ['Konsumsi rapat', '', 150000], ['Isi ulang kas', 500000, ''], ['Transport kurir', '', 45000],
  ['Fotokopi dokumen', '', 60000], ['Air galon', '', 40000], ['Isi ulang kas', 300000, ''], ['Beli perangko', '', 20000], ['Konsumsi tamu', '', 120000],
];
const KASKECIL = {
  id: 'admin-kas', name: 'Admin · Kas kecil', desc: 'Catat kas masuk dan keluar; saldo berjalan otomatis dan berwarna saat menipis.',
  tab: 'Kas kecil', w: [90, 170, 100, 100, 110], head: true, total: 11, nfc: ['', '', 'rp', 'rp', 'rp'],
  rows: [
    ['Tanggal', 'Keterangan', 'Debet (masuk)', 'Kredit (keluar)', 'Saldo'],
    ...KAS.map(([k, d, c], i) => [day(Math.trunc(i * 1.5 - 14)), k, d, c, i ? '=E' + (i + 1) + '+C' + (i + 2) + '-D' + (i + 2) : '=C2-D2']),
    [{ v: 'Total', t: true }, { v: '', t: true }, { v: '=SUM(C2:C11)', t: true }, { v: '=SUM(D2:D11)', t: true }, { v: '=C12-D12', t: true }],
  ],
  rules: [{ c: 'E', op: 'lt', a: 0, ...RED }, { c: 'E', op: 'lt', a: 1000000, ...YEL }],
  charts: [{ kind: 'column', title: 'Saldo kas', r1: 0, c1: 1, r2: 10, c2: 4, vc: 4 }],
  guide: [
    ['Apa ini?', 'Buku kas kecil: uang masuk di Debet, uang keluar di Kredit, Saldo dihitung berjalan.'],
    ['Cara pakai', 'Isi satu transaksi per baris. Uang masuk di Debet, uang keluar di Kredit, sisanya otomatis.'],
    ['Warna saldo', 'Saldo kurang dari 1.000.000 kuning, minus merah. Ubah batasnya lewat Lainnya > Warna bersyarat.'],
    ['Menambah baris', 'Sisipkan baris sebelum baris Total supaya jumlahnya ikut. Lalu salin rumus Saldo dari baris di atasnya.'],
    ['Saldo awal', 'Baris pertama berisi saldo awal di kolom Debet. Ganti angkanya sesuai kasmu.'],
  ],
};

// ---- Slip gaji: kotak kuning = isian; total otomatis
const SLIP = {
  id: 'admin-slip', name: 'Admin · Slip gaji', desc: 'Slip gaji satu karyawan: tunjangan, lembur, potongan persen, dan gaji bersih otomatis.',
  tab: 'Slip gaji', w: [190, 130, 300], head: true, nfc: ['', 'rp', ''],
  rows: [
    ['Komponen', 'Jumlah', 'Keterangan'],
    ['Nama karyawan', inp('Ani Wulandari'), 'Ganti dengan nama karyawan.'],
    ['Periode', inp('November 2026'), 'Bulan dan tahun gaji.'],
    ['Gaji pokok', inp(5000000), 'Gaji tetap per bulan.'],
    ['Tunjangan transport', inp(500000), 'Tunjangan tetap.'],
    ['Tunjangan makan', inp(600000), 'Tunjangan tetap.'],
    ['Jam lembur', inp(10, 'num'), 'Jumlah jam lembur bulan ini.'],
    ['Tarif lembur per jam', inp(30000), 'Upah satu jam lembur.'],
    ['Upah lembur', '=B7*B8', 'Jam lembur dikali tarif.'],
    [{ v: 'Pendapatan kotor', t: true }, { v: '=B4+B5+B6+B9', t: true }, { v: 'Gaji pokok + tunjangan + lembur.', t: true }],
    ['BPJS (persen)', inp(0.03, 'pct'), 'Persen dari gaji pokok.'],
    ['Potongan BPJS', '=B4*B11', 'Gaji pokok dikali persen BPJS.'],
    ['Pajak (persen)', inp(0.05, 'pct'), 'Persen dari pendapatan kotor.'],
    ['Potongan pajak', '=B10*B13', 'Pendapatan kotor dikali persen pajak.'],
    ['Potongan lain', inp(50000), 'Kasbon, iuran, dan sebagainya.'],
    [{ v: 'Total potongan', t: true }, { v: '=B12+B14+B15', t: true }, { v: 'Semua potongan dijumlah.', t: true }],
    [{ v: 'Gaji bersih', t: true }, { v: '=B10-B16', t: true }, { v: 'Yang diterima karyawan.', t: true }],
    ['Tunjangan terbesar', '=MAX(B5:B6)', 'Tunjangan tertinggi (MAX).'],
    ['Tunjangan terkecil', '=MIN(B5:B6)', 'Tunjangan terendah (MIN).'],
  ],
  guide: [
    ['Apa ini?', 'Slip gaji satu orang. Isi kotak kuning, bagian lain dihitung sendiri.'],
    ['Cara pakai', 'Ganti nama, periode, gaji pokok, tunjangan, jam dan tarif lembur, persen, dan potongan lain.'],
    ['Slip karyawan lain', 'Salin lembar ini dari daftar lembar kerja, lalu ganti isian kuningnya.'],
    ['Aturan hitung', 'BPJS dari gaji pokok, pajak dari pendapatan kotor. Ubah rumusnya bila aturan kantormu berbeda.'],
  ],
};

export const ADMIN = [HADIR, MASUK, KASKECIL, SLIP];
