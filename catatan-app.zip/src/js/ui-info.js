// Rev 311a: dialog informasi (satu tombol "Mengerti", opsional satu tombol aksi). Dimuat malas dari ui.js. Bila sudah ada satu terbuka, yang baru antre.
import { h, ico, TONE_ICO } from './ui.js';
const infoQ = [];
export function infoDlg({ title, msg, fix, tone = 'warn', ok = 'Mengerti', act, onAct }) {
  if (document.querySelector('.idlg')) { infoQ.push({ title, msg, fix, tone, ok, act, onAct }); return; }
  const ov = h('div', { class: 'ov dlgov idlg' });
  const close = () => { ov.remove(); const n = infoQ.shift(); if (n) infoDlg(n); };
  const bs = [];
  if (act) bs.push(h('button', { type: 'button', class: 'btn', onclick: () => { close(); if (onAct) onAct(); } }, act));
  bs.push(h('button', { type: 'button', class: 'btn' + (act ? ' line' : ''), 'data-close': '1', onclick: close }, ok));
  ov.append(h('div', { class: 'sheet dlg idl tn-' + tone, role: 'alertdialog' },
    h('div', { class: 'tic big' }, ico(TONE_ICO[tone])), h('h3', {}, title), h('p', { class: 'sub' }, msg),
    fix ? h('p', { class: 'sub fix' }, fix) : null, h('div', { class: 'dlgb' }, bs)));
  document.body.append(ov);
}
export const fmtW = (t) => new Date(t).toLocaleString('id-ID', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
// Dialog "waktu pengingat sudah lewat" dengan nilai konkret (dipakai tugas, sub-tugas, catatan, chat AI).
export function infoPast(t, who, extra) {
  infoDlg({ title: 'Waktu pengingat sudah lewat', msg: (who ? 'Pengingat "' + who + '": ' : '') + 'kamu memilih ' + fmtW(t) + ', padahal sekarang ' + fmtW(Date.now()) + '.', fix: (extra ? extra + ' ' : '') + 'Pilih waktu setelah sekarang, atau ganti pengulangan jadi Setiap hari.' });
}
