// Rev 96 / U4a: bilah chip kontekstual (komponen bersama, rencana 5.5) + operasi tambah baris/kolom tabel.
// Rev 97 / U4b: chip header, perataan, hapus baris/kolom, Pilih ⌄, Hapus tabel (menggantikan menu ▦ Rev 76).
// Bagian atas = fungsi murni (bisa dites di Node). Bagian DOM hanya memakai `document` saat dipanggil, jadi aman diimpor di Node.

import { dataRowsOf, isTotalRow, refreshTotals } from './tabel-total.js';
import { TOTAL_FUNCS } from './tabel-hitung.js';

export const TABLE_EDIT_MIN_ROWS = 2;
export const TABLE_EDIT_MAX_ROWS = 50;
export const TABLE_EDIT_MIN_COLS = 2;
export const TABLE_EDIT_MAX_COLS = 8;

// Batas tambah/hapus untuk tabel berukuran rows x cols.
export function tableLimits(rows, cols) {
  const r = Number(rows) || 0, c = Number(cols) || 0;
  return {
    addRow: r < TABLE_EDIT_MAX_ROWS,
    addCol: c < TABLE_EDIT_MAX_COLS,
    delRow: r > TABLE_EDIT_MIN_ROWS,
    delCol: c > TABLE_EDIT_MIN_COLS,
  };
}

// Indeks sisip: 'below'/'after' = tepat sesudah acuan, 'above'/'before' = tepat sebelum acuan.
export function insertIndex(refIndex, where) {
  const i = Math.max(0, Math.trunc(Number(refIndex)) || 0);
  return where === 'below' || where === 'after' ? i + 1 : i;
}

// Rev 181c: IKON + TEKS TAMPIL untuk chip bergaya dok (ikon di atas, label di bawah). Data murni; ikon hanya dipasang bila pemanggil memberi `ico` (jalur SVG 24x24).
// Chip tanpa ikon (mis. bagian lipat) tetap berupa pil teks lama.
export const CHIP_ICONS = {
  'row-below': 'M4 4h16v8H4zM4 8h16M12 15v6M9 18h6',
  'row-above': 'M4 12h16v8H4zM4 16h16M12 3v6M9 6h6',
  'col-before': 'M12 4h8v16h-8zM16 4v16M3 12h6M6 9v6',
  'col-after': 'M4 4h8v16H4zM8 4v16M15 12h6M18 9v6',
  'hdr-row': 'M4 5h16v14H4zM4 10h16',
  'hdr-col': 'M4 5h16v14H4zM10 5v14',
  align: 'M4 6h16M4 10h10M4 14h16M4 18h10',
  total: 'M17.5 5h-11l6 7-6 7h11',
  'row-del': 'M4 4h16v8H4zM4 8h16M9.5 16.5l5 5M14.5 16.5l-5 5',
  'col-del': 'M4 4h8v16H4zM8 4v16M15.5 9.5l5 5M20.5 9.5l-5 5',
  pick: 'M4 4h6M14 4h6M4 20h6M14 20h6M4 4v6M4 14v6M20 4v6M20 14v6',
  'tbl-del': 'M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13M10 11v6M14 11v6',
  'to-sheet': 'M4 5h16v14H4zM4 10h16M4 15h16M10 5v14',
  __back: 'M15 5l-7 7 7 7',
  'tot-none': 'M12 4a8 8 0 100 16 8 8 0 000-16zM6.5 6.5l11 11',
  'tot-sum': 'M17.5 5h-11l6 7-6 7h11',
  'tot-avg': 'M4 16c3-9 5-9 8 0s5 9 8 0',
  'tot-cnt': 'M5 9h14M5 15h14M10 4L8 20M16 4l-2 16',
  'tot-min': 'M12 5v12M7 12l5 5 5-5',
  'tot-max': 'M12 19V7M7 12l5-5 5 5',
  'sel-cell': 'M6 6h12v12H6z',
  'sel-row': 'M3 9h18v6H3z',
  'sel-col': 'M9 3h6v18H9z',
  'sel-all': 'M4 4h16v16H4zM4 12h16M12 4v16',
};
// Label untuk chip berikon: awalan "＋ " dan akhiran " ⌄" dibuang (ikon dan panah CSS menggantikannya).
export const chipText = (label) => String(label == null ? '' : label).replace(/^\uFF0B\s*/, '').replace(/\s*\u2304\s*$/, '');

// Isi bilah chip untuk tabel (urutan mengikuti K4). U4b menambah chip header, perataan, hapus, Pilih ⌄, Hapus tabel; U4d menambah Total ⌄ (sub-bilah `total`).
// `page` = chip membuka sub-bilah (otomatis dapat chip "‹ Kembali" di depannya). `danger` = chip aksi hapus (warna merah).
export const TABLE_CHIPS = {
  main: [
    { id: 'row-below', label: '＋ Baris bawah' },
    { id: 'row-above', label: '＋ Baris atas' },
    { id: 'col-before', label: '＋ Kolom kiri' },
    { id: 'col-after', label: '＋ Kolom kanan' },
    { id: 'row-del', label: 'Hapus baris', danger: true, sep: 1 },
    { id: 'col-del', label: 'Hapus kolom', danger: true },
    { id: 'hdr-row', label: 'Baris header', sep: 1 },
    { id: 'hdr-col', label: 'Kolom header' },
    { id: 'align', label: 'Perataan: Awal' },
    { id: 'total', label: 'Total ⌄', page: 'total' },
    { id: 'pick', label: 'Pilih ⌄', page: 'pick', sep: 1 },
    { id: 'tbl-del', label: 'Hapus tabel', danger: true, sep: 1 },
  ],
  total: [
    { id: 'tot-none', label: 'Tanpa total' },
    ...TOTAL_FUNCS.map((f) => ({ id: 'tot-' + f.id, label: f.label })),
  ],
  pick: [
    { id: 'sel-cell', label: 'Sel' },
    { id: 'sel-row', label: 'Baris' },
    { id: 'sel-col', label: 'Kolom' },
    { id: 'sel-all', label: 'Semua' },
  ],
};
// Rev 124 / U7b-3: chip "Ubah jadi lembar kerja" SENGAJA di luar TABLE_CHIPS (tes lama mengunci isi TABLE_CHIPS.main). withSheetChip menyisipkannya sebelum chip Hapus tabel (Rev 322: urutan baru, chip hapus tabel tetap paling akhir); tidak dipakai di Catatan Privat.
export const TABLE_SHEET_CHIP = { id: 'to-sheet', label: 'Jadi lembar kerja' };
export function withSheetChip(pages) {
  const main = pages.main.filter((c) => c.id !== TABLE_SHEET_CHIP.id), at = main.findIndex((c) => c.id === 'tbl-del');
  main.splice(at < 0 ? main.length : at, 0, TABLE_SHEET_CHIP);
  return { ...pages, main };
}
// Rev 112 / U6d: bilah chip bagian lipat (hanya satu chip, sesuai konteks kursor; teks polos tanpa simbol agar aman di semua font Android).
export const FOLD_IN_CHIPS = { main: [{ id: 'fold-in', label: 'Pindahkan ke dalam bagian lipat' }] };
export const FOLD_OUT_CHIPS = { main: [{ id: 'fold-out', label: 'Pindahkan keluar dari bagian lipat' }] };
// Perataan (data-a Rev 76): tanpa atribut = kiri/awal. Siklus Awal -> Tengah -> Akhir.
export const ALIGN_CYCLE = ['l', 'c', 'r'];
export const ALIGN_NAMES = { l: 'Awal', c: 'Tengah', r: 'Akhir' };
export const normAlign = (a) => (ALIGN_CYCLE.includes(a) ? a : 'l');
export const nextAlign = (a) => ALIGN_CYCLE[(ALIGN_CYCLE.indexOf(normAlign(a)) + 1) % ALIGN_CYCLE.length];
export const alignLabel = (a) => 'Perataan: ' + ALIGN_NAMES[normAlign(a)];
// Nama bagian yang dipilih (Pilih ⌄) untuk label chip dan toast.
export const SCOPE_NAMES = { cell: 'Sel', row: 'Baris', col: 'Kolom', all: 'Semua' };
export const scopeLabel = (scope) => (scope && scope !== 'cell' && SCOPE_NAMES[scope] ? 'Pilih: ' + SCOPE_NAMES[scope] + ' ⌄' : 'Pilih ⌄');
export const CHIP_BACK_ID = '__back';
export const CHIP_TAP_SLOP = 10; // px: geser lebih jauh dari ini = menggulir bilah, bukan mengetuk chip

// ---------- operasi tabel (DOM) ----------
export function tableDims(table) {
  const rows = dataRowsOf(table); // baris Total (tr.tt) tidak dihitung
  return { rows: rows.length, cols: rows.reduce((m, r) => Math.max(m, r.cells.length), 0) };
}

// Baris judul = baris pertama semuanya TH; kolom judul = sel pertama tiap baris TH.
export function headerFlags(table) {
  const rows = dataRowsOf(table);
  const first = rows[0];
  return {
    row: !!first && first.cells.length > 0 && [...first.cells].every((c) => c.tagName === 'TH'),
    col: rows.length > 0 && rows.every((r) => r.cells[0] && r.cells[0].tagName === 'TH'),
  };
}

const retag = (cell, tag) => {
  const rep = document.createElement(tag);
  for (const a of [...cell.attributes]) rep.setAttribute(a.name, a.value);
  rep.innerHTML = cell.innerHTML;
  cell.replaceWith(rep);
  return rep;
};

// Setelah sisip di tepi, judul harus tetap baris/kolom paling awal: TH hanya untuk baris 0 (bila baris judul) dan kolom 0 (bila kolom judul).
const applyHeaderFlags = (table, flags) => {
  [...table.rows].forEach((row, r) => {
    if (isTotalRow(row)) return;
    [...row.cells].forEach((cell, c) => {
      const want = (flags.row && r === 0) || (flags.col && c === 0) ? 'TH' : 'TD';
      if (cell.tagName !== want) retag(cell, want.toLowerCase());
    });
  });
};

// Tambah satu baris di bawah/atas `refRow`. Rata teks (data-a) mengikuti kolom baris acuan. Mengembalikan baris baru, atau null bila batas tercapai.
export function addTableRow(table, refRow, where) {
  const d = tableDims(table);
  if (!tableLimits(d.rows, d.cols).addRow || !refRow || refRow.parentElement === null) return null;
  const flags = headerFlags(table);
  const row = table.insertRow(insertIndex(refRow.rowIndex, where));
  for (let c = 0; c < d.cols; c++) {
    const cell = document.createElement('td');
    cell.innerHTML = '<br>';
    const a = refRow.cells[c] && refRow.cells[c].getAttribute('data-a');
    if (a) cell.setAttribute('data-a', a);
    row.append(cell);
  }
  applyHeaderFlags(table, flags);
  refreshTotals(table);
  return row;
}

// Tambah satu kolom sebelum/sesudah kolom `refCell`. Mengembalikan sel baru di baris acuan, atau null bila batas tercapai.
export function addTableCol(table, refCell, where) {
  const d = tableDims(table);
  const refRow = refCell && refCell.closest ? refCell.closest('tr') : null;
  if (!tableLimits(d.rows, d.cols).addCol || !refRow) return null;
  const flags = headerFlags(table);
  const colIndex = Math.max(0, [...refRow.cells].indexOf(refCell));
  const at = insertIndex(colIndex, where);
  let made = null;
  for (const row of [...table.rows]) {
    const cell = document.createElement('td');
    cell.innerHTML = '<br>';
    row.insertBefore(cell, row.cells[at] || null);
    if (row === refRow) made = cell;
  }
  applyHeaderFlags(table, flags);
  refreshTotals(table);
  return made ? refRow.cells[Math.min(at, refRow.cells.length - 1)] : null;
}

// Nyalakan/matikan baris header (axis 'row') atau kolom header (axis 'col'): TD <-> TH. Sumbu lain TIDAK berubah (mematikan kolom header
// tidak merusak baris header, dan sebaliknya). Mengembalikan keadaan baru sumbu itu (true = menyala).
export function toggleHeader(table, axis) {
  const flags = headerFlags(table);
  const key = axis === 'row' ? 'row' : 'col';
  flags[key] = !flags[key];
  applyHeaderFlags(table, flags);
  refreshTotals(table); // baris header berubah = baris data berubah
  return flags[key];
}

// Hapus `row`. Bila yang dihapus baris header, tabel tidak lagi punya baris header (baris berikutnya tetap data). Mengembalikan sel fokus
// (baris sesudahnya, atau sebelumnya bila yang dihapus terakhir) pada kolom yang sama, atau null bila di bawah batas minimal.
export function deleteTableRow(table, row, colIndex = 0) {
  const d = tableDims(table);
  if (!tableLimits(d.rows, d.cols).delRow || !row || row.parentElement === null) return null;
  const flags = headerFlags(table);
  const at = row.rowIndex;
  row.remove();
  if (at === 0) flags.row = false;
  applyHeaderFlags(table, flags);
  refreshTotals(table);
  const dr = dataRowsOf(table);
  const near = dr[Math.min(at, dr.length - 1)];
  return near ? near.cells[Math.min(Math.max(0, colIndex), near.cells.length - 1)] || null : null;
}

// Hapus kolom milik `refCell`. Bila yang dihapus kolom header, tabel tidak lagi punya kolom header. Mengembalikan sel fokus di baris yang sama.
export function deleteTableCol(table, refCell) {
  const d = tableDims(table);
  const refRow = refCell && refCell.closest ? refCell.closest('tr') : null;
  if (!tableLimits(d.rows, d.cols).delCol || !refRow) return null;
  const flags = headerFlags(table);
  const at = Math.max(0, [...refRow.cells].indexOf(refCell));
  for (const row of [...table.rows]) { const c = row.cells[at]; if (c) c.remove(); }
  if (at === 0) flags.col = false;
  applyHeaderFlags(table, flags);
  refreshTotals(table);
  return refRow.cells[Math.min(at, refRow.cells.length - 1)] || null;
}

// ---------- komponen bilah chip (DOM) ----------
// h = pembuat elemen dari ui.js (dikirim sebagai argumen agar modul ini tidak bergantung pada ui.js).
// Aturan keras 11: tombol memakai pointer, bukan click. Gerakan menggulir mendatar membatalkan ketukan (pointercancel / geser > CHIP_TAP_SLOP).
export function createChipBar(h, opts = {}) {
  const { label = 'Alat', onAction = () => {}, ico = null } = opts; // Rev 181c: ico(d) -> elemen SVG; tanpa ico = pil teks lama
  const iconOf = (id) => { if (typeof ico !== 'function' || !CHIP_ICONS[id]) return null; const v = ico(CHIP_ICONS[id]); if (v && v.setAttribute) v.setAttribute('aria-hidden', 'true'); return v; };
  const scroller = h('div', { class: 'chips' });
  const el = h('div', { class: 'chipbar', role: 'toolbar', 'aria-label': label, style: 'display:none' }, scroller);
  let pages = { main: [] }, page = 'main', shown = false, tap = null, state = {};

  const list = () => {
    const base = pages[page] || [];
    return page === 'main' ? base : [{ id: CHIP_BACK_ID, label: '‹ Kembali' }, ...base];
  };
  const paint = (b) => {
    const s = state[b.dataset.chip] || {};
    b.classList.toggle('on', !!s.active);
    b.classList.toggle('dis', !!s.disabled);
    if (typeof s.label === 'string') { const t = b.querySelector('.cl') || b, want = t === b ? s.label : chipText(s.label); if (t.textContent !== want) t.textContent = want; }
    b.setAttribute('aria-disabled', String(!!s.disabled));
    if ('active' in s) b.setAttribute('aria-pressed', String(!!s.active)); else b.removeAttribute('aria-pressed');
  };
  const render = () => {
    const kids = []; let tiles = false;
    for (const def of list()) {
      const svg = iconOf(def.id);
      if (def.sep && svg) kids.push(h('span', { class: 'cdv', 'aria-hidden': 'true' })); // Rev 322: garis pemisah antar grup (tambah | hapus | format | pilih | hapus tabel)
      const cls = 'chip' + (svg ? ' tile' : '') + (svg && def.page ? ' pg' : '') + (def.id === CHIP_BACK_ID ? ' back' : '') + (def.danger ? ' danger' : '');
      const attrs = { type: 'button', class: cls, 'data-chip': def.id, tabindex: '-1' };
      const b = svg ? h('button', attrs, svg, h('span', { class: 'cl' }, chipText(def.label))) : h('button', attrs, def.label);
      if (svg) tiles = true;
      paint(b);
      kids.push(b);
    }
    scroller.replaceChildren(...kids);
    scroller.classList.toggle('dock', tiles);
    scroller.scrollLeft = 0;
  };
  const clearTap = () => { if (tap && tap.btn) tap.btn.classList.remove('press'); tap = null; };
  const fire = (id) => {
    if (id === CHIP_BACK_ID) { api.back(); return; }
    const def = list().find((d) => d.id === id);
    if (!def) return;
    if (def.page) { api.openPage(def.page); return; }
    onAction(id, def, { disabled: !!(state[id] && state[id].disabled) });
  };

  // Jangan mencuri fokus/seleksi dari editor (keyboard tidak boleh menutup saat chip ditekan).
  el.addEventListener('mousedown', (e) => e.preventDefault());
  el.addEventListener('pointerdown', (e) => {
    const b = e.target.closest && e.target.closest('.chip');
    if (!b) return;
    e.preventDefault();
    clearTap();
    tap = { id: b.dataset.chip, btn: b, x: e.clientX, y: e.clientY, pid: e.pointerId };
    b.classList.add('press');
  });
  el.addEventListener('pointermove', (e) => {
    if (tap && e.pointerId === tap.pid && Math.hypot(e.clientX - tap.x, e.clientY - tap.y) > CHIP_TAP_SLOP) clearTap();
  });
  el.addEventListener('pointerup', (e) => {
    if (!tap || e.pointerId !== tap.pid) return;
    const t = tap, b = e.target.closest && e.target.closest('.chip');
    const ok = !!b && b.dataset.chip === t.id && Math.hypot(e.clientX - t.x, e.clientY - t.y) <= CHIP_TAP_SLOP;
    clearTap();
    if (ok) fire(t.id);
  });
  el.addEventListener('pointercancel', clearTap);
  // Aktivasi papan ketik/pembaca layar tidak lewat pointer (detail 0); ketukan sentuhan sudah ditangani pointerup.
  el.addEventListener('click', (e) => {
    const b = e.target.closest && e.target.closest('.chip');
    if (b && e.detail === 0) fire(b.dataset.chip);
  });

  const api = {
    el,
    setPages(p) { pages = { main: [], ...p }; page = 'main'; render(); },
    // map id -> { active?, disabled?, label? }; hanya menyentuh atribut tombol yang ada (tidak membangun ulang, jadi gulir dan ketukan tetap aman).
    setState(map) { state = map || {}; scroller.querySelectorAll('.chip').forEach(paint); },
    show() { if (shown) return false; shown = true; el.style.display = 'block'; return true; },
    hide() { if (!shown && page === 'main') return; shown = false; el.style.display = 'none'; clearTap(); if (page !== 'main') { page = 'main'; render(); } },
    isShown: () => shown,
    openPage(id) { if (!pages[id]) return; page = id; render(); },
    back() { page = 'main'; render(); },
    currentPage: () => page,
    chipIds: () => list().map((d) => d.id),
  };
  return api;
}
