// Riwayat Urungkan (Undo) dan Ulangi (Redo) untuk isi editor catatan (Rev 23c, Redo ditambah di Rev 23d). MURNI: tanpa DOM, dites di Node.
// Menyimpan salinan isi (HTML) + posisi kursor (jumlah huruf dari awal). Tidak memakai undo bawaan WebView,
// karena baris kotak centang disisipkan langsung ke DOM (insertTodo) dan itu merusak tumpukan undo bawaan.
export function createHistory(initial, limit = 100, maxChars = 2000000) {
  const first = { html: String((initial && initial.html) || ''), caret: initial && Number.isFinite(initial.caret) ? initial.caret : null };
  const stack = [first];
  const redoStack = [];
  let chars = first.html.length;
  const trim = () => { while (stack.length > 1 && (stack.length > limit || chars > maxChars)) chars -= stack.shift().html.length; };
  return {
    // Catat keadaan baru. Mengembalikan false bila isinya sama dengan yang terakhir (tidak dicatat dua kali).
    push(s) {
      const html = String((s && s.html) || '');
      if (stack[stack.length - 1].html === html) return false;
      stack.push({ html, caret: s && Number.isFinite(s.caret) ? s.caret : null });
      redoStack.length = 0; // perubahan baru menutup jalur Ulangi
      chars += html.length; trim();
      return true;
    },
    // Mundur satu langkah. Mengembalikan keadaan sebelumnya, atau null bila sudah di awal.
    undo() {
      if (stack.length < 2) return null;
      const out = stack.pop(); chars -= out.html.length; redoStack.push(out);
      return stack[stack.length - 1];
    },
    // Maju satu langkah (membatalkan Undo). null bila tidak ada yang bisa diulang.
    redo() {
      if (!redoStack.length) return null;
      const s = redoStack.pop(); stack.push(s); chars += s.html.length; trim();
      return s;
    },
    // Ganti isi langkah terkini tanpa menyentuh jalur Ulangi (dipakai setelah isi editor dipulihkan dan dinormalkan sanitize).
    setTop(s) {
      const html = String((s && s.html) || '');
      const top = stack[stack.length - 1]; chars += html.length - top.html.length; top.html = html;
    },
    canUndo() { return stack.length > 1; },
    canRedo() { return redoStack.length > 0; },
    size() { return stack.length; },
  };
}
