// Rev 396 / PART M1 (Rev 399 / M4: opsi image untuk gambar satu baris): mesin murni catatan <-> Markdown. Tanpa UI, tanpa DOM, tanpa penyimpanan.
// Ekspor memakai parseNoteHtml + blocksToMarkdown yang sudah ada; impor menghasilkan HTML editor
// (div biasa, div.todo, ul/ol, blockquote, tabel) yang tetap harus lewat sanitize() saat disimpan (M3).
import { parseNoteHtml, blocksToMarkdown } from './export.js';

export const MD_MAX = 200000; // batas karakter satu berkas impor; selebihnya dipotong dan dicatat di warnings
const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;' };
const esc = (s) => String(s).replace(/[&<>]/g, (c) => ESC[c]);
const q = (s) => JSON.stringify(String(s));

// ---------- Ekspor ----------
// meta: { labelNames: string[], created: 'YYYY-MM-DD' } (nama label dan tanggal diberikan pemanggil; mesin ini tidak menebak bidang catatan)
export function noteToMarkdown(note, meta = {}) {
  const n = note || {};
  const head = ['---', 'judul: ' + q(String(n.title || '').trim())];
  const names = (meta.labelNames || []).map((x) => String(x).trim()).filter(Boolean);
  if (names.length) head.push('label: [' + names.map(q).join(', ') + ']');
  if (/^\d{4}-\d{2}-\d{2}$/.test(meta.created || '')) head.push('dibuat: ' + meta.created);
  head.push('---', '');
  const body = blocksToMarkdown('', parseNoteHtml(n.html || ''), typeof meta.imageUrl === 'function' ? { imageUrl: meta.imageUrl } : null).replace(/^\s+$/, ''); // Rev 397: imageUrl opsional (ekspor zip membawa gambar)
  return head.join('\n') + body;
}

// ---------- Impor ----------
const unq = (v) => { v = v.trim(); if (v[0] === '"') { try { return String(JSON.parse(v)); } catch (e) { /* jatuh ke bawah */ } } return v.replace(/^['"]|['"]$/g, ''); };
function splitList(v) {
  v = v.trim().replace(/^\[|\]$/g, '');
  const out = []; let cur = '', inQ = '';
  for (const c of v) {
    if (inQ) { cur += c; if (c === inQ) inQ = ''; } else if (c === '"' || c === "'") { inQ = c; cur += c; } else if (c === ',') { out.push(cur); cur = ''; } else cur += c;
  }
  out.push(cur);
  return out.map(unq).map((x) => x.replace(/^#/, '').trim()).filter(Boolean);
}
function frontMatter(lines) {
  const fm = { title: '', labels: [], created: '' };
  if (lines[0] !== '---') return { fm, rest: lines };
  let end = -1; for (let i = 1; i < Math.min(lines.length, 40); i++) if (lines[i] === '---' || lines[i] === '...') { end = i; break; }
  if (end < 0) return { fm, rest: lines };
  let key = '';
  for (const ln of lines.slice(1, end)) {
    const m = /^([A-Za-z_]+):\s*(.*)$/.exec(ln);
    if (m) {
      key = m[1].toLowerCase(); const v = m[2];
      if (key === 'judul' || key === 'title') fm.title = unq(v);
      else if (['label', 'labels', 'tag', 'tags'].includes(key)) fm.labels.push(...(v.trim() ? splitList(v) : []));
      else if (['dibuat', 'created', 'date', 'tanggal'].includes(key)) { const d = /^\d{4}-\d{2}-\d{2}/.exec(unq(v)); if (d) fm.created = d[0]; }
    } else if (/^\s*-\s+/.test(ln) && ['label', 'labels', 'tag', 'tags'].includes(key)) fm.labels.push(...splitList(ln.replace(/^\s*-\s+/, '')));
  }
  fm.labels = [...new Set(fm.labels)].slice(0, 20);
  return { fm, rest: lines.slice(end + 1) };
}

// Format sebaris: \* escape, `kode`, [teks](url), ![gambar](url), **tebal**, *miring*, ~~coret~~.
function inline(src, st) {
  const keep = []; const hold = (s) => '\u0001' + (keep.push(s) - 1) + '\u0002';
  let s = esc(src);
  s = s.replace(/\\([\\`*_~|[\]()#>+\-.!{}])/g, (_, c) => hold(esc(c)));
  s = s.replace(/`([^`]+)`/g, (_, c) => hold(c));
  s = s.replace(/!\[([^\]]*)\]\(([^)]*)\)/g, (_, alt) => { st.images++; return hold(alt.trim() ? '[gambar: ' + alt.trim() + ']' : '[gambar]'); });
  s = s.replace(/\[([^\]]+)\]\(\s*([^)\s]+)[^)]*\)/g, (_, t, u) => hold(t === u ? t : t + ' (' + u + ')'));
  s = s.replace(/(\*\*|__)(?=\S)(.+?)(?<=\S)\1/g, '<b>$2</b>');
  s = s.replace(/~~(?=\S)(.+?)(?<=\S)~~/g, '<s>$1</s>');
  s = s.replace(/\*(?=[^\s*])(.+?)(?<=[^\s*])\*/g, '<i>$1</i>');
  s = s.replace(/(^|[^\w])_(?=[^\s_])(.+?)(?<=[^\s_])_(?![\w])/g, '$1<i>$2</i>');
  return s.replace(/\u0001(\d+)\u0002/g, (_, i) => keep[Number(i)]);
}

const isTableSep = (l) => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(l) && l.includes('-') && (l.includes('|') || /^\s*:?-{3,}/.test(l));
const cells = (l) => l.trim().replace(/^\|/, '').replace(/\|$/, '').split(/(?<!\\)\|/).map((c) => c.trim());

export function markdownToNote(md, opts = {}) {
  const max = opts.max || MD_MAX; const warnings = []; const st = { images: 0 };
  let src = String(md || '').replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').replace(/\t/g, '    ');
  if (src.length > max) { src = src.slice(0, max); warnings.push('terpotong'); }
  const { fm, rest } = frontMatter(src.split('\n'));
  let title = fm.title, lines = rest;
  if (!title) { // judul = baris "# ..." pertama (bila ada sebelum isi lain)
    const i = lines.findIndex((l) => l.trim() !== '');
    if (i >= 0) { const m = /^#\s+(.+?)\s*#*\s*$/.exec(lines[i]); if (m) { title = inline(m[1], { images: 0 }).replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'); lines = lines.slice(i + 1); } }
  }
  title = title.trim().slice(0, 120);
  const out = []; let list = null; let quote = null; let fence = false; let tableSkipped = 0;
  const closeList = () => { if (list) { while (list.stack.length) out.push('</li></' + list.stack.pop().t + '>'); list = null; } };
  const closeQuote = () => { if (quote) { out.push('<blockquote>' + quote.join('<br>') + '</blockquote>'); quote = null; } };
  const flushAll = () => { closeList(); closeQuote(); };
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    if (/^\s*(```|~~~)/.test(raw)) { fence = !fence; flushAll(); continue; }
    if (fence) { if (raw.trim()) out.push('<div>' + esc(raw) + '</div>'); continue; }
    if (!raw.trim()) { flushAll(); continue; }
    if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(raw) && !/^\s*[-*]\s+\S/.test(raw)) { flushAll(); continue; } // garis pemisah dilewati
    const tdm = /^\s*[-*+]\s+\[([ xX])\]\s+(.*)$/.exec(raw);
    if (tdm) { flushAll(); out.push('<div class="todo"><input type="checkbox"' + (tdm[1] === ' ' ? '' : ' checked=""') + '>&nbsp;' + inline(tdm[2], st) + '</div>'); continue; }
    const lm = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/.exec(raw);
    if (lm) {
      closeQuote();
      const t = /\d/.test(lm[2][0]) ? 'ol' : 'ul'; const lvl = Math.min(Math.floor(lm[1].length / 2), list ? list.stack.length : 0, 5);
      if (!list) list = { stack: [] };
      const stk = list.stack;
      while (stk.length > lvl + 1) out.push('</li></' + stk.pop().t + '>');
      if (stk.length === lvl + 1) { if (stk[lvl].t === t) out.push('</li><li>'); else { out.push('</li></' + stk.pop().t + '><' + t + '><li>'); stk.push({ t }); } }
      else { out.push('<' + t + '><li>'); stk.push({ t }); }
      out.push(inline(lm[3], st)); continue;
    }
    if (list) closeList();
    const qm = /^\s*>\s?(.*)$/.exec(raw);
    if (qm) { (quote = quote || []).push(inline(qm[1], st)); continue; }
    closeQuote();
    if (raw.includes('|') && i + 1 < lines.length && isTableSep(lines[i + 1])) { // tabel
      const rows = [cells(raw)]; let j = i + 2;
      while (j < lines.length && lines[j].trim() && lines[j].includes('|')) { rows.push(cells(lines[j])); j++; }
      const cols = Math.min(Math.max(...rows.map((r) => r.length)), 12); if (rows.length > 200) tableSkipped++;
      const cell = (tag, r, c) => '<' + tag + '>' + inline(r[c] || '', st) + '</' + tag + '>';
      out.push('<div class="tbl-wrap"><table><tbody>' + rows.slice(0, 200).map((r, ri) => '<tr>' + Array.from({ length: cols }, (_, c) => cell(ri === 0 ? 'th' : 'td', r, c)).join('') + '</tr>').join('') + '</tbody></table></div>');
      i = j - 1; continue;
    }
    const hm = /^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$/.exec(raw);
    if (hm) { out.push('<div><b>' + inline(hm[1], st).replace(/<\/?b>/g, '') + '</b></div>'); continue; }
    const im = typeof opts.image === 'function' ? /^\s*!\[([^\]]*)\]\(\s*<?([^)\s>]+)>?(?:\s+(?:"[^"]*"|'[^']*'))?\s*\)\s*$/.exec(raw) : null; // Rev 399 / M4: gambar sendirian satu baris; opts.image(src, alt) mengembalikan penanda HTML atau null
    if (im) { const tok = opts.image(im[2], im[1].trim()); if (tok) { out.push(tok); continue; } }
    out.push('<div>' + inline(raw.trim(), st) + '</div>');
  }
  flushAll();
  if (st.images) warnings.push('gambar:' + st.images);
  if (tableSkipped) warnings.push('tabel-dipotong');
  return { title, labels: fm.labels, created: fm.created, html: out.join(''), warnings };
}
