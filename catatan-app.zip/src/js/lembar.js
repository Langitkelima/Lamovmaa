// Rev 114 / U7a-1: model data LEMBAR KERJA (murni, tanpa DOM/penyimpanan/native/eval). Belum ada UI (grid layar penuh = U7a-2).
// Bentuk: data.sheets[id] = { id, name, tabs:[tab], at }. tab = { id, name, nc, nr, cols:[{id, w}], rows:[{id, h?, cells:{[colId]:{v?, s?}}}] } (h = tinggi baris px, opsional, Rev 184a).
// Rujukan sel memakai ID baris/kolom (rX / cX), bukan huruf-angka, supaya sisip/hapus baris-kolom kelak tidak merusak rumus (U8). Layar selalu menampilkan A1.
// Hanya sel berisi disimpan (jarang). Batas: 26 kolom x 500 baris, 5 tab, ~500 KB per lembar kerja, 50 lembar kerja.
import { cleanNf } from './lembar-format.js'; // Rev 132 / U8a-5: format angka sel (murni)
import { cleanMerges, pruneMerges, addMerge, removeMerge } from './lembar-gabung.js'; // Rev 151 / U10b-1: gabung sel per tab (murni)
import { cleanCharts, pruneCharts, addChart, removeChart, chartList, chartRowSnap, chartRowRestore, MAX_CHARTS } from './lembar-grafik.js'; // Rev 158 / U10c-2b: diagram tersimpan per tab (murni)
import { cleanChecks, trimChecks, cleanErrLog } from './lembar-validasi.js'; // Rev 147 / U9b-3a: validasi data pilihan per tab (murni)
export { pinChecks, unpinChecks } from './lembar-validasi.js'; // Rev 272 / V6a: rentang validasi tetap di posisinya saat urut (dipakai sortTab)
import { cleanRules } from './lembar-aturan.js'; // Rev 145 / U9b-2a: aturan warna bersyarat per tab (murni)
import { makeDisplay, hasContent } from './lembar-tampil.js'; // Rev 134 / U8b-1: tabToTsv memakai HASIL rumus + format (murni)
export const MAX_COLS = 26, MAX_ROWS = 500, MAX_TABS = 5, MAX_BYTES = 500000, MAX_SHEETS = 50, MAX_CELL = 2000, MAX_NAME = 30;
export const MAX_FX_LEN = 1000; // Rev 127 (U8a-2): panjang maks. rumus bentuk SIMPAN (ID rujukan lebih panjang dari A1; mesin rumus menolak ketikan > 700)
export const COL_W_MIN = 40, COL_W_MAX = 320, COL_W_DEF = 96, START_ROWS = 30;
// Rev 184a / U10e-1 (SCHEMA 18): TINGGI BARIS BEBAS, model + penyimpanan (tanpa UI). `row.h` = bilangan bulat piksel, OPSIONAL: baris tanpa `h` = ROW_H_DEF.
// TANPA batas atas buatan (pengguna: bebas); hanya pembersih data: bilangan hingga, dibulatkan, minimal ROW_H_MIN (supaya baris tidak hilang), dan ROW_H_SANE sebagai pagar data rusak saja.
export const ROW_H_DEF = 40, ROW_H_MIN = 16, ROW_H_SANE = 1000000;
export function cleanRowH(h) { const n = typeof h === 'number' ? h : (typeof h === 'string' && h.trim() !== '' ? Number(h) : NaN); if (!Number.isFinite(n)) return undefined; const r = Math.min(ROW_H_SANE, Math.max(ROW_H_MIN, Math.round(n))); return r === ROW_H_DEF ? undefined : r; }
export const STYLE_KEYS = ['b', 'i', 'bg', 'fg', 'ha', 'nf']; // tebal, miring, warna isian, warna teks, ratakan, format angka (Rev 132)
const HA = ['start', 'center', 'end'];
const COLORS = /^[a-z]{3,12}$|^#[0-9a-fA-F]{6}$/;
const ID_RE = /^[a-z0-9]{4,24}$/; // lembar kerja dan tab
const COL_ID_RE = /^[cx][A-Za-z0-9]{1,23}$/, ROW_ID_RE = /^r[A-Za-z0-9]{1,23}$/; // kolom cA..cZ / x1.. dan baris r1..

export const isSheetId = (s) => typeof s === 'string' && ID_RE.test(s); // Rev 122 (U7b-1): dipakai sanitize catatan untuk data-sheet
export const colLabel = (i) => (Number.isInteger(i) && i >= 0 && i < MAX_COLS ? String.fromCharCode(65 + i) : '');
export const colIndexOf = (label) => { const s = String(label || '').toUpperCase(); return /^[A-Z]$/.test(s) ? s.charCodeAt(0) - 65 : -1; };
export const cellAddr = (colIdx, rowIdx) => (colLabel(colIdx) && rowIdx >= 0 ? colLabel(colIdx) + (rowIdx + 1) : '');
export function parseAddr(a) { const m = /^([A-Za-z])(\d{1,3})$/.exec(String(a || '').trim()); if (!m) return null; const c = colIndexOf(m[1]), r = Number(m[2]) - 1; return c >= 0 && r >= 0 && r < MAX_ROWS ? { col: c, row: r } : null; }

const clampInt = (x, lo, hi, d) => { const n = Math.round(Number(x)); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : d; };
const cleanName = (x, d) => { const s = String(x == null ? '' : x).replace(/\s+/g, ' ').trim().slice(0, MAX_NAME); return s || d; };
function rid(used, p) { let s; do { s = p + Math.random().toString(36).slice(2, 8); } while (used.has(s)); used.add(s); return s; }

// --- gaya & nilai sel ---
export function cleanStyle(s) {
  const o = {}; if (!s || typeof s !== 'object') return o;
  if (s.b === true) o.b = true; if (s.i === true) o.i = true;
  if (typeof s.bg === 'string' && COLORS.test(s.bg)) o.bg = s.bg; if (typeof s.fg === 'string' && COLORS.test(s.fg)) o.fg = s.fg;
  if (HA.includes(s.ha) && s.ha !== 'start') o.ha = s.ha;
  const nf = cleanNf(s.nf); if (nf) o.nf = nf; // Rev 132: format angka (nilai mentah tidak berubah)
  return o;
}
export function cleanValue(v) {
  if (typeof v === 'number') return Number.isFinite(v) ? v : undefined;
  if (typeof v === 'boolean') return v;
  if (typeof v === 'string') { const t = v.slice(0, MAX_CELL); return t === '' ? undefined : t; }
  return undefined;
}
// Rev 127 / U8a-2: rumus tersimpan = string diawali '=' (bentuk SIMPAN berbasis ID, lihat mesin rumus); HASIL tidak pernah disimpan. Sel berumus tidak punya v.
export function cleanFx(x) { return typeof x === 'string' && x.length >= 2 && x.length <= MAX_FX_LEN && x[0] === '=' ? x : undefined; }
export function cleanCell(c) {
  if (!c || typeof c !== 'object') return null;
  const o = {}; const f = cleanFx(c.fx);
  if (f) o.fx = f; else { const v = cleanValue(c.v); if (v !== undefined) o.v = v; }
  const s = cleanStyle(c.s); if (Object.keys(s).length) o.s = s;
  return Object.keys(o).length ? o : null;
}

// --- pembuatan ---
export function newTab(name = 'Lembar 1', rows = START_ROWS) {
  const used = new Set();
  const cols = []; for (let i = 0; i < MAX_COLS; i++) cols.push({ id: 'c' + colLabel(i), w: COL_W_DEF });
  const n = clampInt(rows, 1, MAX_ROWS, START_ROWS); const rs = [];
  for (let i = 0; i < n; i++) rs.push({ id: 'r' + (i + 1), cells: {} });
  return { id: rid(used, 't'), name: cleanName(name, 'Lembar 1'), nc: 0, nr: n, cols, rows: rs };
}
export function newSheet({ id, name = 'Lembar kerja', now = Date.now() } = {}) {
  return { id: id || rid(new Set(), 's'), name: cleanName(name, 'Lembar kerja'), tabs: [newTab('Lembar 1')], at: Number.isFinite(now) ? now : Date.now() };
}

// --- akses ---
export const rowIndex = (tab, rowId) => tab.rows.findIndex((r) => r.id === rowId);
export const colIndex = (tab, colId) => tab.cols.findIndex((c) => c.id === colId);
export function getCell(tab, rowId, colId) { const r = tab.rows.find((x) => x.id === rowId); return (r && r.cells[colId]) || null; }
export function cellAt(tab, rowIdx, colIdx) { const r = tab.rows[rowIdx], c = tab.cols[colIdx]; return r && c ? r.cells[c.id] || null : null; }

// Ubah satu sel: patch {v?, fx?, s?}; v === '' / null / undefined menghapus nilai (dan rumus: mengisi nilai = menimpa rumus); fx = string '=...' (bentuk simpan) mengganti nilai, fx null menghapus rumus; gaya digabung. Sel yang jadi kosong dibuang (jarang). Mengembalikan true bila berubah.
export function setCell(tab, rowId, colId, patch = {}) {
  const r = tab.rows.find((x) => x.id === rowId); if (!r || colIndex(tab, colId) < 0) return false;
  const before = JSON.stringify(r.cells[colId] || null);
  const cur = r.cells[colId] ? { ...r.cells[colId] } : {};
  if ('v' in patch) { const v = patch.v === null || patch.v === undefined ? undefined : cleanValue(patch.v); delete cur.fx; if (v === undefined) delete cur.v; else cur.v = v; }
  if ('fx' in patch) { const f = cleanFx(patch.fx); if (f) { cur.fx = f; delete cur.v; } else delete cur.fx; }
  if ('s' in patch) { const s = cleanStyle({ ...(cur.s || {}), ...(patch.s || {}) }); for (const k of STYLE_KEYS) if (patch.s && patch.s[k] === null) delete s[k]; if (Object.keys(s).length) cur.s = s; else delete cur.s; }
  const next = cleanCell(cur); if (next) r.cells[colId] = next; else delete r.cells[colId];
  return JSON.stringify(r.cells[colId] || null) !== before;
}

// --- baris dan kolom (ID lama tidak berubah) ---
const usedIds = (list) => new Set(list.map((x) => x.id));
function nextRowId(tab) { tab.nr = Math.max(tab.nr || 0, tab.rows.length); const u = usedIds(tab.rows); let n = tab.nr + 1; while (u.has('r' + n)) n++; tab.nr = n; return 'r' + n; }
export function addRows(tab, n = 10) {
  const k = Math.min(clampInt(n, 0, MAX_ROWS, 0), MAX_ROWS - tab.rows.length); for (let i = 0; i < k; i++) tab.rows.push({ id: nextRowId(tab), cells: {} }); return k;
}
export function insertRow(tab, index) {
  if (tab.rows.length >= MAX_ROWS) return null; const i = clampInt(index, 0, tab.rows.length, tab.rows.length);
  const r = { id: nextRowId(tab), cells: {} }; tab.rows.splice(i, 0, r); fzShift(tab, 'r', i, 1); return r.id;
}
export function deleteRow(tab, rowId) { if (tab.rows.length <= 1) return false; const i = rowIndex(tab, rowId); if (i < 0) return false; const ck = Array.isArray(tab.checks) ? trimChecks(tab, 'r', rowId) : null; tab.rows.splice(i, 1); fzShift(tab, 'r', i, -1); if (ck) { tab.checks = cleanChecks(ck, tab.cols, tab.rows); if (!tab.checks.length) delete tab.checks; } pruneMerges(tab); pruneCharts(tab); return true; }
export const rowHeight = (tab, rowId) => { const r = tab && Array.isArray(tab.rows) ? tab.rows.find((x) => x.id === rowId) : null; return (r && r.h) || ROW_H_DEF; }; // Rev 184a: tinggi baris (px), bawaan 40
export const rowHeightAt = (tab, rowIdx) => { const r = tab && Array.isArray(tab.rows) ? tab.rows[rowIdx] : null; return (r && r.h) || ROW_H_DEF; };
export function setRowHeight(tab, rowId, h) { // Rev 184a: mengembalikan true bila berubah; h kosong/bawaan = hapus `h`; nilai tak sah = ditolak (tidak mengubah apa pun)
  const r = tab.rows.find((x) => x.id === rowId); if (!r) return false;
  if (h === null || h === undefined || h === '') { if (r.h === undefined) return false; delete r.h; return true; }
  const n = typeof h === 'number' ? h : (typeof h === 'string' && h.trim() !== '' ? Number(h) : NaN); if (!Number.isFinite(n)) return false;
  const v = cleanRowH(n); if (v === undefined) { if (r.h === undefined) return false; delete r.h; return true; } if (r.h === v) return false; r.h = v; return true;
}
export function insertCol(tab, index) {
  if (tab.cols.length >= MAX_COLS) return null; const i = clampInt(index, 0, tab.cols.length, tab.cols.length);
  const u = usedIds(tab.cols); let n = (tab.nc || 0) + 1; while (u.has('x' + n)) n++; tab.nc = n; const c = { id: 'x' + n, w: COL_W_DEF }; tab.cols.splice(i, 0, c); fzShift(tab, 'c', i, 1); return c.id;
}
export function deleteCol(tab, colId) {
  if (tab.cols.length <= 1) return false; const i = colIndex(tab, colId); if (i < 0) return false;
  const ck = Array.isArray(tab.checks) ? trimChecks(tab, 'c', colId) : null; tab.cols.splice(i, 1); fzShift(tab, 'c', i, -1); for (const r of tab.rows) delete r.cells[colId]; if (Array.isArray(tab.rules)) { tab.rules = tab.rules.filter((x) => x.c !== colId); if (!tab.rules.length) delete tab.rules; } if (ck) { tab.checks = cleanChecks(ck, tab.cols, tab.rows); if (!tab.checks.length) delete tab.checks; } pruneMerges(tab); pruneCharts(tab); return true;
}
export function setColWidth(tab, colId, w) { const c = tab.cols.find((x) => x.id === colId); if (!c) return false; const n = clampInt(w, COL_W_MIN, COL_W_MAX, c.w); const ch = n !== c.w; c.w = n; return ch; }
// Rev 147 / U9b-3a: ganti SELURUH daftar validasi data tab (dibersihkan; kosong = hapus). Mengembalikan true bila berubah.
export function setChecks(tab, checks) { const before = JSON.stringify(tab.checks || []); const next = cleanChecks(checks, tab.cols, tab.rows); if (next.length) tab.checks = next; else delete tab.checks; return JSON.stringify(tab.checks || []) !== before; }
// Rev 145 / U9b-2a: ganti SELURUH daftar aturan warna bersyarat tab (dibersihkan; kosong = hapus). Mengembalikan true bila berubah.
export function setRules(tab, rules) { const before = JSON.stringify(tab.rules || []); const next = cleanRules(rules, tab.cols); if (next.length) tab.rules = next; else delete tab.rules; return JSON.stringify(tab.rules || []) !== before; }

// Rev 151 / U10b-1: gabung sel (tanpa UI). Argumen = INDEKS baris/kolom; opts.clear = true mengosongkan sel terisi selain jangkar. Hasil { ok, reason?, cleared }.
export const mergeCells = (tab, ri1, ci1, ri2, ci2, opts) => addMerge(tab, ri1, ci1, ri2, ci2, opts);
export const unmergeCell = (tab, ri, ci) => removeMerge(tab, ri, ci);

// Rev 159 / U10c-2c: diagram tersimpan (UI memakai lewat lembar.js; modul grafik tetap hanya diimpor lembar.js). Argumen src = INDEKS; valueCol = indeks kolom nilai.
export { MAX_CHARTS };
export const saveChart = (tab, src, valueCol, set) => addChart(tab, src, valueCol, set);
export const deleteChart = (tab, id) => removeChart(tab, id);
export const listCharts = (tab) => chartList(tab);
export const pinChartRows = (tab) => chartRowSnap(tab); // Rev 176: catat posisi baris sudut diagram sebelum baris dipindah
export const restoreChartRows = (tab, snap) => chartRowRestore(tab, snap); // Rev 176: pasang ulang pada posisi yang sama sesudahnya

// --- tab ---
export function addTab(sheet, name) { if (sheet.tabs.length >= MAX_TABS) return null; const t = newTab(cleanName(name, 'Lembar ' + (sheet.tabs.length + 1))); const u = usedIds(sheet.tabs); while (u.has(t.id)) t.id = 't' + Math.random().toString(36).slice(2, 8); sheet.tabs.push(t); return t.id; }
export function removeTab(sheet, tabId) { if (sheet.tabs.length <= 1) return false; const i = sheet.tabs.findIndex((t) => t.id === tabId); if (i < 0) return false; sheet.tabs.splice(i, 1); return true; }
// Rev 150 / U10a: geser urutan tab satu langkah (dir -1 = ke kiri, +1 = ke kanan). Hanya urutan array yang berubah; ID tab tidak berubah. Mengembalikan true bila bergeser.
export function moveTab(sheet, tabId, dir) { const i = sheet.tabs.findIndex((t) => t.id === tabId); const j = i + (dir < 0 ? -1 : 1); if (i < 0 || j < 0 || j >= sheet.tabs.length) return false; const t = sheet.tabs[i]; sheet.tabs[i] = sheet.tabs[j]; sheet.tabs[j] = t; return true; }
export function renameSheet(sheet, name) { const n = cleanName(name, sheet.name); const ch = n !== sheet.name; sheet.name = n; return ch; }
export function renameTab(sheet, tabId, name) { const t = sheet.tabs.find((x) => x.id === tabId); if (!t) return false; const n = cleanName(name, t.name); const ch = n !== t.name; t.name = n; return ch; }

// --- ukuran dan ekspor ---
export const sheetBytes = (sheet) => { try { return JSON.stringify(sheet, (k, v) => (k === 'errlog' ? undefined : v)).length; } catch (_) { return Infinity; } };
export const fitsLimit = (sheet) => sheetBytes(sheet) <= MAX_BYTES;
// Teks dipisah tab (dasar ekspor TXT/CSV nanti); baris kosong di ekor dan kolom kosong di ekor dibuang.
// Rev 134 / U8b-1: sel berumus = HASIL (bukan rumus, bukan kosong); sel berformat nf = angka terformat; sisanya nilai mentah (desimal titik, boolean TRUE/FALSE seperti sebelumnya).
export function tabToTsv(tab, opts = {}) {
  const d = makeDisplay(tab, opts); let lastR = -1, lastC = -1;
  tab.rows.forEach((r, i) => tab.cols.forEach((c, j) => { if (hasContent(r.cells[c.id])) { lastR = Math.max(lastR, i); lastC = Math.max(lastC, j); } }));
  const out = []; for (let i = 0; i <= lastR; i++) { const row = []; for (let j = 0; j <= lastC; j++) row.push(d.plain(i, j).replace(/[\t\r\n]+/g, ' ')); out.push(row.join('\t')); }
  return out.join('\n');
}

// Rev 300a: tab.fz = { r, c } = jumlah baris/kolom beku (maks. 5/3; sisakan 1 bebas). Alatnya: modul malas.
export const MAX_FZ_ROWS = 5, MAX_FZ_COLS = 3;
const fzn = (x, mx, n) => { const v = Math.floor(Number(x)); return v > 0 ? Math.min(v, mx, n - 1) : 0; };
export function cleanFreeze(raw, rows, cols) { const o = raw && typeof raw === 'object' ? raw : {}; const r = fzn(o.r, MAX_FZ_ROWS, rows.length), c = fzn(o.c, MAX_FZ_COLS, cols.length); return r || c ? { r, c } : null; }
function fzShift(tab, k, i, d) { const f = tab.fz; if (!f) return; if (i < f[k]) f[k] = Math.max(0, f[k] + d); const v = cleanFreeze(f, tab.rows, tab.cols); if (v) tab.fz = v; else delete tab.fz; }

// --- normalisasi (data dari penyimpanan/cadangan yang bisa rusak) ---
export function cleanTab(raw, used = new Set()) {
  if (!raw || typeof raw !== 'object') return null;
  const seenC = new Set(); const cols = [];
  for (const c of Array.isArray(raw.cols) ? raw.cols : []) { if (cols.length >= MAX_COLS) break; if (!c || typeof c.id !== 'string' || !COL_ID_RE.test(c.id) || seenC.has(c.id)) continue; seenC.add(c.id); cols.push({ id: c.id, w: clampInt(c.w, COL_W_MIN, COL_W_MAX, COL_W_DEF) }); }
  if (!cols.length) { for (let i = 0; i < MAX_COLS; i++) cols.push({ id: 'c' + colLabel(i), w: COL_W_DEF }); }
  const seenR = new Set(); const rows = [];
  for (const r of Array.isArray(raw.rows) ? raw.rows : []) {
    if (rows.length >= MAX_ROWS) break; if (!r || typeof r.id !== 'string' || !ROW_ID_RE.test(r.id) || seenR.has(r.id)) continue; seenR.add(r.id);
    const cells = {}; const src = r.cells && typeof r.cells === 'object' && !Array.isArray(r.cells) ? r.cells : {};
    for (const c of cols) { const x = cleanCell(src[c.id]); if (x) cells[c.id] = x; }
    const row = { id: r.id, cells }; const rh = cleanRowH(r.h); if (rh) row.h = rh; // Rev 184a: hanya ada bila dipakai (data lama tetap sama persis)
    rows.push(row);
  }
  if (!rows.length) for (let i = 0; i < START_ROWS; i++) rows.push({ id: 'r' + (i + 1), cells: {} });
  let id = typeof raw.id === 'string' && ID_RE.test(raw.id) && !used.has(raw.id) ? raw.id : rid(used, 't'); used.add(id);
  const tab = { id, name: cleanName(raw.name, 'Lembar 1'), nc: clampInt(raw.nc, 0, 100000, 0), nr: Math.max(clampInt(raw.nr, 0, 100000, 0), rows.length), cols, rows };
  const rules = cleanRules(raw.rules, cols); if (rules.length) tab.rules = rules; // Rev 145: hanya ada bila dipakai (data lama tanpa rules tetap sama persis)
  const checks = cleanChecks(raw.checks, cols, rows); if (checks.length) tab.checks = checks; // Rev 147: hanya ada bila dipakai (data lama tetap sama persis)
  const errlog = cleanErrLog(raw.errlog, cols, rows); if (errlog.length) tab.errlog = errlog; // Rev 278 / W3: riwayat error, hanya ada bila dipakai (data lama tetap sama persis)
  const fz = cleanFreeze(raw.fz, rows, cols); if (fz) tab.fz = fz; // Rev 300a
  const merges = cleanMerges(raw.merges, rows, cols); if (merges.length) tab.merges = merges; // Rev 151: hanya ada bila dipakai (data lama tetap sama persis)
  const charts = cleanCharts(raw.charts, rows, cols); if (charts.length) tab.charts = charts; // Rev 158: hanya ada bila dipakai (data lama tetap sama persis)
  return tab;
}
export function cleanSheet(raw) {
  if (!raw || typeof raw !== 'object' || typeof raw.id !== 'string' || !ID_RE.test(raw.id)) return null;
  const used = new Set(); const tabs = [];
  for (const t of Array.isArray(raw.tabs) ? raw.tabs : []) { if (tabs.length >= MAX_TABS) break; const c = cleanTab(t, used); if (c) tabs.push(c); }
  if (!tabs.length) tabs.push(newTab('Lembar 1'));
  const s = { id: raw.id, name: cleanName(raw.name, 'Lembar kerja'), tabs, at: Number.isFinite(Number(raw.at)) ? Number(raw.at) : 0 };
  return fitsLimit(s) ? s : null; // lembar kerja yang melewati batas ukuran dibuang utuh (tidak dipotong diam-diam)
}
export function cleanSheets(raw) {
  const out = {}; if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out;
  let n = 0; for (const k of Object.keys(raw)) { if (n >= MAX_SHEETS) break; const s = cleanSheet(raw[k]); if (s && s.id === k) { out[k] = s; n++; } }
  return out;
}
