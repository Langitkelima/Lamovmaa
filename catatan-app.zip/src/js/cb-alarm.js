// Rev 102 / U5b: perekat antara mesin murni `ingatkan.js` dan jembatan native (AndroidAPI.scheduleNotification / cancelScheduledNotification).
// Pola sama seperti reminders.js. Hanya CATATAN BIASA (data.notes); Catatan Privat tidak pernah punya jadwal (judulnya tidak boleh bocor ke notifikasi).
// Belum ada UI yang mengisi `cbRem`/`cdRem` (lonceng = U5c, kartu hitung mundur = U5d); modul ini sudah siap dan dites lewat data.
import { pushSchedule } from './logic.js';
import { planCbAlarms, planCdAlarms, allCbIds, allCdIds, cleanNoteRem, rowsFromHtml, blocksFromHtml } from './ingatkan.js';

const api = () => globalThis.AndroidAPI || globalThis.KelimaaNative || null;
const hasRem = (n) => !!n && ((n.cbRem && Object.keys(n.cbRem).length > 0) || (n.cdRem && Object.keys(n.cdRem).length > 0));
export { hasRem as noteHasRem };

function cancelId(id) {
  try { const a = api(); if (a && typeof a.cancelScheduledNotification === 'function') a.cancelScheduledNotification(id); } catch (e) { console.warn('Pembatalan pengingat gagal', e); }
}

// Rev 103 / U5c: membatalkan alarm SATU baris centang (semua ID kemungkinan: sekali/harian/mingguan + :m1..:m12). Wajib dipanggil SEBELUM aturan dihapus dari note.cbRem,
// karena save() hanya membatalkan ID dari aturan yang masih ada.
export function cancelRowAlarms(note, cid) {
  if (!note || !note.id || !cid) return;
  for (const id of allCbIds(note.id, cid)) cancelId(id);
}

// Rev 104 / U5d: membatalkan alarm SATU kartu hitung mundur (semua ID hari-sebelum). Wajib dipanggil SEBELUM aturan dihapus dari note.cdRem (save() hanya membatalkan ID dari aturan yang masih ada).
export function cancelCdAlarms(note, bid) {
  if (!note || !note.id || !bid) return;
  for (const id of allCdIds(note.id, bid)) cancelId(id);
}

// Semua ID yang MUNGKIN dipakai catatan ini (untuk membatalkan tanpa tahu aturan lamanya).
export function noteAlarmIds(note) {
  if (!note || !note.id) return [];
  const ids = [];
  for (const cid of Object.keys(note.cbRem || {})) ids.push(...allCbIds(note.id, cid));
  for (const bid of Object.keys(note.cdRem || {})) ids.push(...allCdIds(note.id, bid));
  return ids;
}

export function cancelNoteAlarms(note) {
  for (const id of noteAlarmIds(note)) cancelId(id);
}

// Menjadwalkan ulang SEMUA alarm kotak centang + hitung mundur satu catatan: batalkan semua kemungkinan ID, lalu pasang rencana baru dari isi tersimpan.
// Mengembalikan daftar hasil seperti scheduleReminder: { ok, warning?, reason? }. Tanpa jembatan native (peramban) = { ok:false, reason:'unavailable' }.
export function syncNoteAlarms(note, now = Date.now()) {
  const results = [];
  if (!note || !note.id) return results;
  cancelNoteAlarms(note);
  if (!hasRem(note)) return results;
  const plan = [...planCbAlarms(note, rowsFromHtml(note.html), now), ...planCdAlarms(note, blocksFromHtml(note.html), now)];
  const a = api();
  for (const p of plan) {
    if (!a || typeof a.scheduleNotification !== 'function') { results.push({ ok: false, reason: 'unavailable' }); continue; }
    try {
      const { res: result, fellBack } = pushSchedule(a, p.id, p.title, p.message, Math.max(1000, p.at - now), p.repeatMs || 0, p.mode);
      if (result === 'inexact_alarm') results.push({ ok: true, warning: 'inexact_alarm', ...(fellBack ? { alarmFallback: true } : {}) });
      else if (result === 'permission_denied') { try { a.requestNotificationPermission?.(); } catch (_) {} results.push({ ok: false, reason: 'permission' }); }
      else if (result === 'error') results.push({ ok: false, reason: 'native_error' });
      else results.push({ ok: true, mode: result || 'scheduled', ...(fellBack ? { alarmFallback: true } : {}) });
    } catch (e) { results.push({ ok: false, reason: String((e && e.message) || e) }); }
  }
  return results;
}

// Setelah isi catatan berubah: pangkas cbRem/cdRem ke cid/bid yang MASIH ada di HTML, batalkan alarm yang yatim, lalu jadwalkan ulang. Mengembalikan true bila ada yang dipangkas.
export function reconcileNoteAlarms(note, now = Date.now()) {
  if (!note) return { pruned: false, results: [] };
  const before = noteAlarmIds(note);
  const clean = cleanNoteRem(note);
  const pruned = JSON.stringify(clean.cbRem) !== JSON.stringify(note.cbRem || {}) || JSON.stringify(clean.cdRem) !== JSON.stringify(note.cdRem || {}) || JSON.stringify(clean.cdMode || {}) !== JSON.stringify(note.cdMode || {});
  if (pruned) {
    for (const id of before) cancelId(id); // yang yatim ikut terbatalkan
    if (Object.keys(clean.cbRem).length) note.cbRem = clean.cbRem; else delete note.cbRem;
    if (Object.keys(clean.cdRem).length) note.cdRem = clean.cdRem; else delete note.cdRem;
    if (clean.cdMode) note.cdMode = clean.cdMode; else delete note.cdMode;
  }
  return { pruned, results: hasRem(note) ? syncNoteAlarms(note, now) : [] };
}

// Dipanggil saat aplikasi dibuka/kembali ke layar dan setelah Pulihkan cadangan: pasang ulang alarm semua catatan biasa yang punya pengingat.
export function syncAllNoteAlarms(data, now = Date.now()) {
  const results = [];
  for (const n of (data && data.notes) || []) if (hasRem(n)) results.push(...syncNoteAlarms(n, now));
  return results;
}
