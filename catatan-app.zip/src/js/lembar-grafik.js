// Rev 158 / U10c-2b: DIAGRAM TERSIMPAN per tab lembar kerja (MURNI: tanpa DOM, penyimpanan, native, eval, dan TANPA mengimpor modul lain).
// Bentuk: tab.charts = [{ id, kind, title, legend, r1, c1, r2, c2, vc }]. Sudut rentang (r1,c1 kiri-atas; r2,c2 kanan-bawah) dan kolom nilai (vc) memakai ID baris/kolom
// seperti tab.merges, jadi menyisipkan baris/kolom di dalam rentang memperbesar rentang dan menghapusnya memperkecil. Kolom label = c1, kolom nilai = vc (di kanan c1, di dalam c1..c2).
// Menghapus baris/kolom yang menjadi sudut atau kolom nilai membuat diagram tidak sah, lalu dibuang (pruneCharts), sama seperti gabungan.
// Maks. MAX_CHARTS per tab. Hanya SIMPAN pengaturan; menggambar tetap tugas lembar-diagram.js (modul ini sengaja tidak mengimpornya: tes rev156/rev157 mengunci pengimpornya).
// TANPA UI (U10c-2c) dan belum dipanggil modul UI mana pun.
export const MAX_CHARTS = 6, MAX_CHART_TITLE = 60;
export const CHART_KINDS_SAVED = ['column', 'bar', 'donut']; // harus sama dengan CHART_KINDS di lembar-diagram.js (dikunci tes)
const ID_RE = /^g[a-z0-9]{3,12}$/;
const at = (arr, id) => { for (let i = 0; i < arr.length; i++) if (arr[i].id === id) return i; return -1; };
const label = (ri, ci) => String.fromCharCode(65 + ci) + (ri + 1);
const cleanTitle = (x) => String(x == null ? '' : x).replace(/\s+/g, ' ').trim().slice(0, MAX_CHART_TITLE);
const cleanKind = (x) => (CHART_KINDS_SAVED.includes(x) ? x : 'column');

// Persegi (indeks) + indeks kolom nilai dari satu entri; null bila ada ID hilang atau susunan kolom tidak sah.
export function chartRect(tab, ch) {
  if (!ch || !tab || !Array.isArray(tab.rows) || !Array.isArray(tab.cols)) return null;
  const a = at(tab.rows, ch.r1), b = at(tab.rows, ch.r2), c = at(tab.cols, ch.c1), d = at(tab.cols, ch.c2), v = at(tab.cols, ch.vc);
  if (a < 0 || b < 0 || c < 0 || d < 0 || v < 0) return null;
  const r1 = Math.min(a, b), r2 = Math.max(a, b), c1 = Math.min(c, d), c2 = Math.max(c, d);
  if (v <= c1 || v > c2) return null; // kolom nilai harus di kanan kolom label dan di dalam rentang
  return { r1, c1, r2, c2, vc: v };
}
const entry = (tab, id, set, r) => ({ id, kind: cleanKind(set && set.kind), title: cleanTitle(set && set.title), legend: !(set && set.legend === false), r1: tab.rows[r.r1].id, c1: tab.cols[r.c1].id, r2: tab.rows[r.r2].id, c2: tab.cols[r.c2].id, vc: tab.cols[r.vc].id });

// Bersihkan daftar mentah terhadap rows/cols: ID diagram sah dan unik, rentang sah, maks. MAX_CHARTS; urutan sudut dinormalkan.
export function cleanCharts(raw, rows, cols) {
  const out = [], seen = new Set(), tab = { rows, cols };
  for (const m of Array.isArray(raw) ? raw : []) {
    if (out.length >= MAX_CHARTS) break;
    if (!m || typeof m !== 'object' || typeof m.id !== 'string' || !ID_RE.test(m.id) || seen.has(m.id)) continue;
    const r = chartRect(tab, m); if (!r) continue;
    seen.add(m.id); out.push(entry(tab, m.id, m, r));
  }
  return out;
}
// Semua diagram yang sah: pengaturan + persegi indeks + indeks kolom nilai (valueCol) + rujukan A1 untuk tampilan. Kosong tanpa biaya bila tab tanpa diagram.
export function chartList(tab) {
  if (!tab || !Array.isArray(tab.charts) || !tab.charts.length) return [];
  const out = [];
  for (const m of tab.charts) {
    const r = chartRect(tab, m); if (!r) continue;
    out.push({ id: m.id, kind: cleanKind(m.kind), title: cleanTitle(m.title), legend: m.legend !== false, src: { r1: r.r1, c1: r.c1, r2: r.r2, c2: r.c2 }, valueCol: r.vc, ref: label(r.r1, r.c1) + ':' + label(r.r2, r.c2) });
  }
  return out;
}
export const getChart = (tab, id) => chartList(tab).find((c) => c.id === id) || null;
const newId = (tab) => { const used = new Set((tab.charts || []).map((c) => c.id)); let s; do { s = 'g' + Math.random().toString(36).slice(2, 8); } while (used.has(s) || !ID_RE.test(s)); return s; };

// Simpan diagram baru. src = {r1,c1,r2,c2} (INDEKS), valueCol = indeks kolom nilai, set = {kind,title,legend}. Hasil { ok, id? , reason?: 'rentang'|'kolom'|'batas' }. Tidak ada yang berubah bila gagal.
export function addChart(tab, src, valueCol, set = {}) {
  if (!tab || !Array.isArray(tab.rows) || !Array.isArray(tab.cols) || !src) return { ok: false, reason: 'rentang' };
  const { r1, c1, r2, c2 } = src;
  if (![r1, c1, r2, c2].every(Number.isInteger) || r1 < 0 || c1 < 0 || r2 < r1 || c2 < c1 || r2 >= tab.rows.length || c2 >= tab.cols.length) return { ok: false, reason: 'rentang' };
  if (!Number.isInteger(valueCol) || valueCol <= c1 || valueCol > c2) return { ok: false, reason: 'kolom' };
  if (Array.isArray(tab.charts) && tab.charts.length >= MAX_CHARTS) return { ok: false, reason: 'batas' };
  const id = newId(tab); if (!Array.isArray(tab.charts)) tab.charts = [];
  tab.charts.push(entry(tab, id, set, { r1, c1, r2, c2, vc: valueCol }));
  return { ok: true, id };
}
// Ubah pengaturan tampilan (jenis, judul, legenda) tanpa mengubah rentang. true bila berubah.
export function updateChart(tab, id, patch = {}) {
  if (!Array.isArray(tab.charts)) return false; const m = tab.charts.find((c) => c.id === id); if (!m) return false;
  const before = JSON.stringify(m);
  if ('kind' in patch) m.kind = cleanKind(patch.kind); if ('title' in patch) m.title = cleanTitle(patch.title); if ('legend' in patch) m.legend = patch.legend !== false;
  return JSON.stringify(m) !== before;
}
export function removeChart(tab, id) {
  if (!Array.isArray(tab.charts)) return false; const i = tab.charts.findIndex((c) => c.id === id); if (i < 0) return false;
  tab.charts.splice(i, 1); if (!tab.charts.length) delete tab.charts; return true;
}
// Buang diagram yang sudah tidak sah (sudut/kolom nilai terhapus). Dipanggil sesudah hapus baris/kolom. true bila berubah.
export function pruneCharts(tab) {
  if (!Array.isArray(tab.charts)) return false;
  const before = JSON.stringify(tab.charts), next = cleanCharts(tab.charts, tab.rows, tab.cols);
  if (next.length) tab.charts = next; else delete tab.charts;
  return JSON.stringify(tab.charts || []) !== (before === '[]' ? '[]' : before);
}

// Rev 176: urut baris tidak boleh menggeser rentang diagram. Sudut rentang memakai ID baris, dan mengurutkan memindahkan baris (ID ikut), jadi tanpa penjagaan
// rentang berubah isi. chartRowSnap mencatat POSISI (indeks) baris sudut tiap diagram sebelum urut; chartRowRestore memasang ulang ID baris pada posisi yang sama sesudahnya.
// Hasilnya rentang tetap A1:B5 yang sama (isinya yang terurut), seperti di Excel. Murni; true bila ada ID yang berubah.
export function chartRowSnap(tab) {
  if (!tab || !Array.isArray(tab.charts) || !tab.charts.length) return null;
  const out = []; for (const m of tab.charts) { const r = chartRect(tab, m); if (r) out.push({ id: m.id, r1: r.r1, r2: r.r2 }); }
  return out.length ? out : null;
}
export function chartRowRestore(tab, snap) {
  if (!snap || !Array.isArray(tab.charts) || !Array.isArray(tab.rows)) return false;
  let changed = false;
  for (const s of snap) {
    const m = tab.charts.find((c) => c.id === s.id), a = tab.rows[s.r1], b = tab.rows[s.r2];
    if (!m || !a || !b) continue;
    if (m.r1 !== a.id || m.r2 !== b.id) { m.r1 = a.id; m.r2 = b.id; changed = true; }
  }
  return changed;
}
