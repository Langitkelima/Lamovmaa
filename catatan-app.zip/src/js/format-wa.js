// Rev 361 / PART W1: MESIN FORMAT GAYA WHATSAPP (murni, tanpa DOM, tanpa impor, tanpa penyimpanan).
// Tebal `*teks*`, miring `_teks_`, gabungan `*_teks_*` / `_*teks*_`. Aturan = PASAL 36.3 di PROMPT_SERAH_TERIMA.md (DUGAAN dari
// perilaku WhatsApp; setiap butir dites di tests/rev361.test.mjs). Satu baris per panggilan; baris baru memutus format.
// Modul ini TIDAK mengubah apa pun: hanya mengembalikan pasangan penanda dan rentang di teks tanpa penanda.
// Dimuat MALAS oleh pemakainya nanti (W2); JANGAN diimpor statis dari jalur buka (anggaran JS buka, tes rev193/rev194).

export const MARKS = { '*': 'tebal', '_': 'miring' };
export const MAX_LINE = 2000; // baris lebih panjang dari ini tidak dipindai (aman untuk ketikan, bukan dokumen)

const isWord = (c) => c !== undefined && /[\p{L}\p{N}]/u.test(c);
const isSpace = (c) => c !== undefined && /\s/u.test(c);
// Karakter sesudah penutup yang diizinkan (aturan 5): akhir baris, spasi, tanda baca, atau penanda lain; BUKAN huruf/angka/penanda sama.
const okAfterClose = (c, ch) => c === undefined || (!isWord(c) && c !== ch);
// Karakter yang, bila diketik sesudah penutup, memicu pengubahan (W2). `*` dan `_` sengaja BUKAN pemicu (36.4).
export const isTriggerChar = (c) => typeof c === 'string' && c.length === 1 && (c === '\u00a0' || /[\s.,;:!?)]/.test(c)) && c !== '\n';

function canOpen(t, i, b, ch) {
  const prev = t[i - 1], next = t[i + 1];
  if (prev !== undefined && (isWord(prev) || prev === ch)) return false;   // aturan 2
  if (next === undefined || i + 1 >= b || isSpace(next) || next === ch) return false; // aturan 3
  return true;
}

function findClose(t, i, b, ch) {
  for (let j = i + 2; j < b; j++) { // j >= i+2: isi tidak kosong (aturan 6)
    if (t[j] !== ch) continue;
    const p = t[j - 1];
    if (isSpace(p) || p === ch) continue;                  // aturan 4 (+ `**`)
    if (!okAfterClose(t[j + 1], ch)) continue;             // aturan 5
    return j;
  }
  return -1;
}

function scan(t, a, b, allowed, out) {
  let i = a;
  while (i < b) {
    const ch = t[i];
    if (allowed.includes(ch) && canOpen(t, i, b, ch)) {
      const j = findClose(t, i, b, ch);
      if (j > 0) {
        out.push({ ch, open: i, close: j });
        scan(t, i + 1, j, allowed.filter((x) => x !== ch), out); // bersarang hanya penanda BERBEDA
        i = j + 1; continue;
      }
    }
    i++;
  }
}

// Pasangan penanda pada satu baris: [{ ch, open, close, tebal, miring }] urut menurut `open`. Penanda tanpa pasangan = teks biasa.
export function findPairs(line) {
  const t = String(line == null ? '' : line);
  if (!t || t.length > MAX_LINE || /[\n\r]/.test(t)) return [];
  if (!t.includes('*') && !t.includes('_')) return [];
  const raw = []; scan(t, 0, t.length, ['*', '_'], raw);
  return raw.sort((x, y) => x.open - y.open).map((p) => ({ ...p, tebal: p.ch === '*', miring: p.ch === '_' }));
}

// Hasil akhir satu baris: { plain, runs } — `plain` = teks TANPA penanda; `runs` = [{ start, end, tebal, miring }] di koordinat `plain`
// (rentang berformat bersambung digabung; teks tanpa format tidak ada di runs).
export function resolveLine(line) {
  const t = String(line == null ? '' : line);
  const pairs = findPairs(t);
  if (!pairs.length) return { plain: t, runs: [] };
  const gone = new Set(); pairs.forEach((p) => { gone.add(p.open); gone.add(p.close); });
  const map = new Array(t.length + 1); let n = 0, plain = '';
  for (let i = 0; i < t.length; i++) { map[i] = n; if (!gone.has(i)) { plain += t[i]; n++; } }
  map[t.length] = n;
  const runs = []; let cur = null;
  for (let k = 0; k < plain.length; k++) {
    let tb = false, mi = false;
    for (const p of pairs) { const s = map[p.open], e = map[p.close]; if (k >= s && k < e) { if (p.tebal) tb = true; else mi = true; } }
    if (!tb && !mi) { cur = null; continue; }
    if (cur && cur.tebal === tb && cur.miring === mi && cur.end === k) cur.end = k + 1;
    else { cur = { start: k, end: k + 1, tebal: tb, miring: mi }; runs.push(cur); }
  }
  return { plain, runs };
}

// Pembantu W2: pasangan yang menutup TEPAT sebelum karakter pemicu yang baru diketik di `cursor - 1` (deret penutup berurutan,
// mis. `*_x_*` + spasi = dua pasangan: `*` di cursor-2 dan `_` di cursor-3). Pembacaan murni; tidak mengubah teks. Tidak ada = [].
export function pairsClosedBefore(line, cursor) {
  const t = String(line == null ? '' : line);
  if (!(cursor >= 2) || cursor > t.length || !isTriggerChar(t[cursor - 1])) return [];
  const all = findPairs(t.slice(0, cursor)), out = [];
  for (let c = cursor - 2; c >= 0; c--) { const p = all.find((x) => x.close === c); if (!p) break; out.push(p); }
  return out;
}
