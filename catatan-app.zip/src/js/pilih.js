// Logika murni mode pilih daftar catatan (Rev 26). Tanpa DOM, dites di Node.
// Pilihan = larik id (urutan ketukan), selalu tanpa duplikat.
export const toggle = (ids, id) => {
  const a = Array.isArray(ids) ? ids : [];
  return a.includes(id) ? a.filter((x) => x !== id) : [...a, id];
};
export const count = (ids) => (Array.isArray(ids) ? ids.length : 0);
const pick = (notes, ids) => { const s = new Set(ids || []); return (notes || []).filter((n) => s.has(n.id)); };
// Sematkan/Lepas: bila SEMUA terpilih sudah tersemat -> lepas semua; selain itu sematkan semua.
export const allPinned = (notes, ids) => { const p = pick(notes, ids); return p.length > 0 && p.every((n) => !!n.pin); };
export const nextPinState = (notes, ids) => !allPinned(notes, ids);
// Bagikan hanya bila tepat 1 terpilih dan bukan Catatan Privat.
export const canShare = (ids, kind) => count(ids) === 1 && kind !== 'priv';
// Label untuk pilihan banyak: 'all' (semua punya), 'some' (sebagian), 'none'.
export function labelState(notes, ids, labelId) {
  const p = pick(notes, ids); if (!p.length) return 'none';
  const has = p.filter((n) => Array.isArray(n.labels) && n.labels.includes(labelId)).length;
  return has === 0 ? 'none' : has === p.length ? 'all' : 'some';
}
// Ketuk satu label: bila semua sudah punya -> lepas dari semua; selain itu tambahkan ke semua.
export function applyLabel(notes, ids, labelId) {
  const rm = labelState(notes, ids, labelId) === 'all';
  for (const n of pick(notes, ids)) {
    const cur = Array.isArray(n.labels) ? n.labels.filter((x) => x !== labelId) : [];
    if (rm) { if (cur.length) n.labels = cur; else delete n.labels; } else n.labels = [...cur, labelId];
  }
  return !rm;
}
export function applyColor(notes, ids, hex) {
  for (const n of pick(notes, ids)) n.col = hex || '';
}
// Urutan salinan: salinan catatan paling atas harus tetap paling atas, jadi diproses dari bawah dengan waktu naik.
export const copyOrder = (sortedNotes, ids) => pick(sortedNotes, ids).reverse();

// Rev 407: seleksi seret. order = id kartu berurutan seperti tampil; a = kartu awal (jangkar), b = kartu di bawah jari.
// Rentang mencakup a..b (naik atau turun) dan SELALU dihitung ulang dari pilihan awal ("base") sehingga menggeser balik menyusutkan rentang.
export function rangeIds(order, a, b) {
  const o = Array.isArray(order) ? order : [];
  const i = o.indexOf(a), j = o.indexOf(b);
  if (i < 0 || j < 0) return [];
  return o.slice(Math.min(i, j), Math.max(i, j) + 1);
}
export function dragSelection(base, order, anchor, cur) {
  const b = Array.isArray(base) ? [...new Set(base)] : [];
  const r = rangeIds(order, anchor, cur);
  return [...b, ...r.filter((id) => !b.includes(id))];
}
