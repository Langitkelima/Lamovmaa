// Rev 323 / PART L2: Sisipkan > Tautan (dialog) + tampilan Kartu tautan inline. Dimuat MALAS dari notes.js (bukan jalur buka).
// Rev 324 / PART L3: gambar kecil (thumbnail, D3 = dari internet saja, gagal/offline = ikon) + bilah kartu (Kiri/Tengah/Kanan, Buka, Lepas tautan, Hapus).
// Kartu di HTML hanya cangkang kosong (lihat kontrak di linkcard.js); isi tampilan dibuat di sini dan TIDAK pernah disimpan (sanitize mengosongkannya).
// L2: ikon + judul + domain + panah, TANPA gambar kecil (thumbnail = L3). Catatan Privat: hanya lokal, tidak mengambil apa pun dari internet (keputusan D6).
import { h, ico, toast as uiToast } from './ui.js';
import { hostOf, safeImageUrl } from './logic.js';
import { fetchPreview, openExternal } from './links.js';
import { LK_ERR, LK_MAX_URL, linkCardUrl, normalizeLinkCard, linkCardAttrs, linkCardFetchAllowed } from './linkcard.js';

const D_LINK = 'M10 14a4 4 0 005.7 0l3-3a4 4 0 00-5.7-5.7l-1 1M14 10a4 4 0 00-5.7 0l-3 3a4 4 0 005.7 5.7l1-1';
const D_GO = 'M8 16L16.5 7.5M9.5 7.5h7v7';

// Alasan penolakan (kode `why` dari linkCardUrl) dalam bahasa biasa + cara memperbaikinya (aturan Rev 311: penolakan wajib berpenjelasan).
export const LK_WHY = {
  kosong: 'Tempel atau ketik alamat web dulu, misalnya https://contoh.com.',
  panjang: 'Alamat terlalu panjang (maksimal ' + LK_MAX_URL + ' huruf). Salin alamat yang lebih pendek dari halaman itu.',
  spasi: 'Alamat tidak boleh mengandung spasi. Hapus spasi atau baris baru di dalamnya.',
  skema: 'Alamat harus diawali https:// atau http://. Alamat lain (misalnya javascript: atau ftp:) tidak diterima demi keamanan.',
  format: 'Bentuk alamat belum dikenali. Periksa lagi ejaannya.',
  akun: 'Alamat yang memuat nama pengguna atau kata sandi (…@…) tidak diterima demi keamanan.',
  host: 'Nama situs belum lengkap. Pakai nama seperti contoh.com (alamat IP dan localhost tidak diterima).',
};

// Rev 325 / L4 (aturan Rev 311): tautan yang gagal dibuka tidak boleh diam; beri tahu apa yang terjadi + cara mengatasinya (toast bernada peringatan).
export function bukaTautan(url) {
  if (openExternal(url)) return true;
  uiToast('Tautan tidak bisa dibuka. Pastikan ada aplikasi peramban di HP dan alamatnya masih sah, lalu coba lagi.', undefined, undefined, undefined, 'warn');
  return false;
}

// Menggambar isi kartu dari atribut (idempoten). Dipanggil oleh registri blok saat catatan dibuka dan oleh dialog.
export function renderCard(el) {
  const u = el.getAttribute('data-u') || ''; if (!u) return;
  wire();
  const host = hostOf(u), t = el.getAttribute('data-t') || '', s = el.getAttribute('data-s') || '';
  const icon = () => h('span', { class: 'lk-ic', 'aria-hidden': 'true' }, ico(D_LINK));
  // Rev 324 / L3: gambar kecil hanya dari alamat https di data-i, TIDAK pernah diminta di Catatan Privat (D6), gagal muat/offline = ikon.
  const img = el.closest && el.closest('[data-priv]') ? '' : safeImageUrl(el.getAttribute('data-i') || '');
  el.replaceChildren(
    img ? h('img', { class: 'lk-th', src: img, alt: '', loading: 'lazy', decoding: 'async', referrerpolicy: 'no-referrer', onerror: (e) => e.target.replaceWith(icon()) }) : icon(),
    h('span', { class: 'lk-tx' }, h('b', { class: 'lk-t' }, t || s || host), h('small', { class: 'lk-h' }, t || s ? host : u.replace(/^https?:\/\/(www\.)?/i, '').replace(/\/$/, ''))), // belum ada judul: baris kecil = alamat singkat (bukan domain dobel)
    h('button', { type: 'button', class: 'lk-go', 'aria-label': 'Buka tautan ' + host, title: 'Buka tautan' }, ico(D_GO)));
}

// Rev 324 / L3: bilah kartu tepat di bawah kartu (ketuk kartu di mode Edit; ketuk lagi = tutup). Kelas mood-tools + kb-tools + data-kb-tool = sama
// dengan alat blok lain, jadi dibuang saat simpan/cadangan/ekspor (stripBlockTools) dan tidak ikut dipindah bagian lipat (NOT_MOVABLE).
// ctx dari notes.js: { ed, flush: flushHist, save: auto, close: closeMoodTools }.
const AL = [['l', 'Kiri'], ['c', 'Tengah'], ['r', 'Kanan']];
export function toggleCardTools(card, { ed, flush, save, close }) {
  if (!card || !card.isConnected) return;
  const open = card.nextElementSibling && card.nextElementSibling.classList.contains('lk-tools');
  close();
  if (open) return;
  const url = card.getAttribute('data-u') || '', a0 = card.getAttribute('data-a');
  const bar = h('div', { class: 'mood-tools kb-tools lk-tools', role: 'group', 'aria-label': 'Alat kartu tautan' });
  bar.setAttribute('contenteditable', 'false'); bar.setAttribute('data-kb-tool', '');
  const mk = (cls, label, fn, extra = {}) => h('button', { type: 'button', class: cls, onclick: (ev) => { ev.preventDefault(); ev.stopPropagation(); fn(); }, ...extra }, label);
  const mark = (v) => bar.querySelectorAll('[data-al]').forEach((b) => { const on = b.getAttribute('data-al') === v; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
  const cur = a0 === 'c' || a0 === 'r' ? a0 : 'l';
  for (const [v, label] of AL) {
    bar.append(mk(v === cur ? 'on' : '', label, () => {
      flush(); if (v === 'l') card.removeAttribute('data-a'); else card.setAttribute('data-a', v);
      mark(v); flush(); save();
    }, { 'data-al': v, 'aria-pressed': v === cur ? 'true' : 'false' }));
  }
  bar.append(
    mk('', 'Buka', () => { close(); bukaTautan(url); }),
    mk('', 'Lepas tautan', () => { // kartu jadi satu baris teks biasa berisi alamatnya (pratinjau lama di bawah isi muncul lagi bila ada internet)
      flush(); const p = document.createElement('p'); p.textContent = url; card.replaceWith(p); close(); flush(); save();
    }),
    mk('del', 'Hapus', () => {
      flush(); card.remove(); close();
      if (!ed.children.length) { const p = document.createElement('p'); p.append(document.createElement('br')); ed.append(p); }
      flush(); save();
    }));
  card.after(bar);
}

// Satu pendengar untuk semua kartu (dipasang sekali, saat modul ini dimuat). Mode Edit: hanya panah yang membuka tautan; mode Baca: seluruh kartu.
let wired = false;
function wire() {
  if (wired || typeof document === 'undefined') return; wired = true;
  document.addEventListener('click', (e) => {
    const card = e.target && e.target.closest ? e.target.closest('.lk-card') : null; if (!card) return;
    if (!card.closest('.ed-baca') && !e.target.closest('.lk-go')) return;
    e.preventDefault(); bukaTautan(card.getAttribute('data-u') || '');
  });
}

// Judul + nama situs + alamat gambar diambil dari internet SESUDAH kartu tampil (hanya catatan biasa). Gagal/offline = kartu tetap dengan domain.
async function fill(el, url, ed, save) {
  try {
    const p = await fetchPreview(url);
    if (!ed.isConnected || !ed.contains(el)) return; // catatan sudah ditutup atau kartu dihapus
    const c = normalizeLinkCard({ u: url, t: p.t, s: p.s, i: p.i });
    if (!c || (!c.t && !c.s && !c.i)) return;
    if (c.t) el.setAttribute('data-t', c.t);
    if (c.i) el.setAttribute('data-i', c.i); // Rev 324 / L3: alamat gambar (https saja); gambarnya sendiri TIDAK disimpan
    if (c.s) el.setAttribute('data-s', c.s);
    renderCard(el); save();
  } catch (_) { /* tanpa internet: kartu tetap tampil dengan domain */ }
}

export function openLinkDialog({ ed, kind, place, done, save, toast }) {
  wire();
  const priv = kind === 'priv';
  const inp = h('input', { class: 'in lk-in', type: 'text', inputmode: 'url', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', placeholder: 'https://contoh.com/halaman', maxlength: String(LK_MAX_URL + 100), 'aria-label': 'Alamat web' });
  const msg = h('p', { class: 'lk-msg', 'aria-live': 'polite' });
  const ok = h('button', { type: 'button', class: 'btn', disabled: true }, 'Sisipkan');
  const close = () => ov.remove();
  const check = () => {
    const r = linkCardUrl(inp.value);
    ok.disabled = !r.ok;
    if (r.ok) { msg.className = 'lk-msg good'; msg.textContent = hostOf(r.url) + (priv ? ' — Catatan Privat: kartu hanya menampilkan domain, tanpa mengambil apa pun dari internet.' : ' — judul halaman diambil otomatis bila ada internet.'); return r; }
    const empty = !inp.value.trim();
    msg.className = 'lk-msg' + (empty ? '' : ' bad');
    msg.textContent = empty ? LK_WHY.kosong : LK_ERR + '. ' + LK_WHY[r.why];
    return r;
  };
  inp.addEventListener('input', check);
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); if (!ok.disabled) ok.click(); } });
  const paste = h('button', { type: 'button', class: 'btn line lk-paste', onclick: async () => {
    try { const t = await navigator.clipboard.readText(); inp.value = String(t || '').trim(); check(); }
    catch (_) { toast('Tidak bisa membaca salinan otomatis. Tahan kolom alamat lalu pilih Tempel.', undefined, undefined, undefined, 'warn'); }
    inp.focus();
  } }, 'Tempel');
  ok.addEventListener('click', () => {
    const r = linkCardUrl(inp.value); if (!r.ok) { check(); return; }
    const el = document.createElement('div'), a = linkCardAttrs({ u: r.url });
    for (const k of Object.keys(a)) el.setAttribute(k, a[k]);
    if (!place(el)) { close(); return; } // di dalam sel tabel: placeBlock sendiri menjelaskan alasannya
    renderCard(el); close(); done(el);
    if (linkCardFetchAllowed(kind)) fill(el, r.url, ed, save);
  });
  const ov = h('div', { class: 'ov dlgov lk-dialog', onclick: (e) => { if (e.target === ov) close(); } },
    h('div', { class: 'sheet dlg lk-dlg', role: 'dialog', 'aria-label': 'Sisipkan tautan' },
      h('h3', {}, 'Tautan'), h('p', { class: 'sub' }, 'Tempel alamat web. Hasilnya berupa kartu di dalam catatan.'),
      h('div', { class: 'lk-row' }, inp, paste), msg,
      h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: close }, 'Batal'), ok)));
  document.body.append(ov); check();
  requestAnimationFrame(() => { try { inp.focus(); } catch (_) { /* fokus tidak wajib */ } });
}
