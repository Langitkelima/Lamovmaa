// Rev 337 / PART I4 + Rev 338 / PART I3: ketikan tersembunyi di editor catatan = TAMPILAN (hitung cepat `12*3=` dan label cepat `#kerja `). Mesinnya sudah ada di ketik-pemicu.js (Rev 336: detectTrigger / evalExpr).
// Cara kerja: ketik `12*3=` -> sebaris saran muncul DI ATAS bilah format (di dalam dock, bukan melayang: papan ketik tidak menutupinya)
// berisi hasil (mis. "36"). Mengetuk saran = hasil disisipkan tepat sesudah `=` (satu langkah Urungkan). Tidak pernah menulis sendiri (D-I2).
// I3: ketik `#kerja` + spasi -> saran "Pasang label kerja" (atau "Buat label kerja" bila belum ada). Mengetuk = label dipasang di catatan ini lewat env.tags
// (notes.js; memakai sistem label yang ada, batas dan pesan sama), teks `#kerja` TETAP di catatan, toast Urungkan melepas label (dan menghapus label yang baru dibuat).
// Rev 339 / I7: `[] ` di awal baris jadi baris kotak centang, `1. ` jadi daftar bernomor (langsung saat spasi diketik, tanpa ketukan); SATU Backspace tepat sesudahnya
// mengembalikan teks pemicu (`[]` / `1.` + spasi). Hanya bila baris itu berisi pemicu saja (tidak ada teks lain di baris/blok, bukan di sel tabel, daftar, kutipan, bagian lipat).
// Rev 340 / I6: ketik `/` di awal baris atau sesudah spasi (+ huruf, mis. `/tab`) -> sebaris kapsul perintah (Daftar, Nomor, Kotak centang, Tabel, Kutipan, Tanggal, Suasana hati, Hitung mundur, Lembar kerja) tampil di dock dan disaring saat mengetik; mengetuk kapsul menghapus `/perintah` lalu memakai perintah Sisipkan/Langit yang SAMA (env.slash.run dari notes.js; tidak ada jalur sisip baru). Perintah yang belum punya jalur di aplikasi (mis. Judul) tidak ditampilkan (env.slash.has).
// Rev 343 / I2: ketik `[[` (+ kata, mis. `[[rap`) -> sebaris kapsul JUDUL CATATAN (catatan biasa lain, disaring menurut judul, terbaru dulu, maks. 8; Catatan Privat tidak pernah ikut karena daftar berasal dari data.notes). Mengetuk kapsul menghapus `[[kata` lalu menyisipkan tautan `<span class="nl" data-nid="id" contenteditable="false">Judul</span>` + spasi, dan memasang hubungan Rev 18 (n.links; lewat env.wiki.done) agar catatan tujuan mendapat "Disebut di". Mengetuk tautan membuka catatan (notes.js).
// Rev 362 / PART W2: tebal `*teks*` dan miring `_teks_` gaya WhatsApp (mesin = format-wa.js). Pemicu = karakter sesudah penutup (spasi, nbsp, . , ; : ! ? )); penanda dihapus, teks jadi <b>/<i> (tag yang sama dengan tombol Tebal/Miring), kursor tetap di posisi mengetik, SATU Backspace tepat sesudahnya mengembalikan teks mentah. Hanya di SATU simpul teks (lintas simpul = W3), bukan IME yang menyusun (W4).
// Rev 364 / PART W4: Enter + penyembuhan. (a) Enter (insertParagraph) di ujung baris tepat sesudah penutup `*x*`/`_x_` memformat dulu (karakter pemicu MAYA, tidak pernah ditulis ke DOM), lalu Enter berjalan biasa; baris BARU tidak boleh mewarisi tebal/miring (Chromium menaruh <b><br></b> di baris baru), jadi dibersihkan sesudah Enter; tanpa Backspace-batal (kursor sudah di baris lain), Urungkan: format = langkah sendiri. (b) IME: pemicu yang tiba lewat compositionend juga diproses. (c) Shift+Enter (insertLineBreak) TIDAK memformat (Chromium menaruh <br><br> di DALAM <b>; sengaja dilewati).
// Hanya editor catatan BIASA: tidak dipasang di Catatan Privat (notes.js tidak memanggil modul ini), tidak muncul di sel tabel, blok,
// gambar, atau saat mode Baca. Dimuat MALAS dari notes.js hanya sesudah ketikan `=` pertama; JANGAN diimpor statis (anggaran JS buka, rev193/rev194).
import { h, tOk, tWarn } from './ui.js';
import { detectTrigger } from './ketik-pemicu.js';
import { pairsClosedBefore, resolveLine, isTriggerChar } from './format-wa.js';
import { newTodoRow, isTodoBlank, caretAfterBox } from './todo.js';

const BLOCK = /^(DIV|P|LI|TD|TH|TR|TABLE|UL|OL|BLOCKQUOTE|H[1-6]|PRE|FIGURE)$/;
const BLOCKED = 'td,th,table,figure,[contenteditable="false"],input,.lk-card,.ksheet,.kb-date-block,.kb-time-block,.kb-countdown-block';

// Teks dari awal baris sampai kursor. Hanya kursor di simpul TEKS (itulah yang dihasilkan ketikan); selain itu null.
// Baris berakhir di <br> atau elemen blok sebelumnya; elemen sebaris (<b>, <span>) ikut dihitung. `root` = elemen editor.
export function lineBefore(root, node, offset) {
  if (!node || node.nodeType !== 3 || typeof node.data !== 'string') return null;
  let out = node.data.slice(0, offset), cur = node;
  for (let guard = 0; guard < 200; guard++) {
    for (let p = cur.previousSibling; p; p = p.previousSibling) {
      if (p.nodeType === 3) out = (p.data || '') + out;
      else if (p.nodeType === 1) { if (p.tagName === 'BR' || BLOCK.test(p.tagName)) return out; out = (p.textContent || '') + out; }
      if (out.length > 4000) return out.slice(-4000);
    }
    const par = cur.parentNode;
    if (!par || par === root || BLOCK.test(par.tagName || '')) return out;
    cur = par;
  }
  return out;
}

// Rev 363 / W3: simpul-simpul teks pada baris dari awal baris sampai `node` (urutan dokumen), cermin lineBefore (teksnya sama persis bila digabung).
export function lineTexts(root, node) {
  const out = [node]; let cur = node;
  const texts = (el) => { const r = [], w = (x) => { for (let c = x.firstChild; c; c = c.nextSibling) { if (c.nodeType === 3) r.push(c); else if (c.nodeType === 1) w(c); } }; w(el); return r; };
  for (let guard = 0; guard < 200; guard++) {
    for (let p = cur.previousSibling; p; p = p.previousSibling) {
      if (p.nodeType === 3) out.unshift(p);
      else if (p.nodeType === 1) { if (p.tagName === 'BR' || BLOCK.test(p.tagName)) return out; out.unshift(...texts(p)); }
      if (out.length > 400) return out;
    }
    const par = cur.parentNode;
    if (!par || par === root || BLOCK.test(par.tagName || '')) return out;
    cur = par;
  }
  return out;
}

// Mengembalikan { value, text, expr } (hasil siap sisip) atau null. Murni terhadap teks: dipakai tes tanpa DOM.
export function calcFor(line) {
  if (typeof line !== 'string' || !line.endsWith('=')) return null;
  const t = detectTrigger(line, { ctx: 'note', only: ['calc'] });
  return t && t.kind === 'calc' ? { value: t.value, text: t.text, expr: t.expr } : null;
}

// Mengembalikan { tag } bila baris berakhir `#tag` + SATU spasi (spasi nbsp dari papan ketik dianggap spasi), selain itu null.
export function tagFor(line) {
  if (typeof line !== 'string') return null;
  const t = detectTrigger(line.replace(/\u00a0/g, ' '), { ctx: 'note', only: ['tag'] });
  return t && t.kind === 'tag' && t.complete ? { tag: t.tag } : null;
}

// Rev 340 / I6: menu cepat `/`. Mengembalikan { query, items } (items = perintah yang lolos saringan DAN dimiliki aplikasi: has(id)) atau null. Murni (dites tanpa DOM).
export function slashFor(line, has) {
  if (typeof line !== 'string') return null;
  const t = detectTrigger(line.replace(/\u00a0/g, ' '), { ctx: 'note', only: ['slash'] });
  if (!t || t.kind !== 'slash') return null;
  const items = (t.items || []).filter((c) => typeof has !== 'function' || has(c.id));
  return items.length ? { query: t.query, items } : null;
}

// Rev 341 / I8: `!jam 9`, `!besok 9`, `!jumat 14.30`, `!15 des` di baris kotak centang. Mengembalikan { when, label, hasTime, raw } atau null. Murni (dites tanpa DOM).
export function remindFor(line, now) {
  if (typeof line !== 'string') return null;
  const t = detectTrigger(line.replace(/\u00a0/g, ' '), { ctx: 'note', only: ['remind'], now });
  return t && t.kind === 'remind' ? { when: t.when, label: t.label, hasTime: t.hasTime, raw: t.raw } : null;
}

// Rev 343 / I2: `[[judul` yang masih terbuka. Mengembalikan { query } atau null. Murni (dites tanpa DOM).
export function wikiFor(line) {
  if (typeof line !== 'string') return null;
  const t = detectTrigger(line.replace(/\u00a0/g, ' '), { ctx: 'note', only: ['wiki'] });
  return t && t.kind === 'wiki' ? { query: t.query } : null;
}
export const WIKI_LIMIT = 8;
// Calon tujuan tautan: catatan BIASA selain diri sendiri yang punya judul, disaring menurut judul (awalan dulu, potongan di tengah menyusul; huruf besar/kecil diabaikan), tiap peringkat terbaru-diubah dulu. Murni.
export function wikiList(notes, selfId, query, limit = WIKI_LIMIT) {
  const q = String(query == null ? '' : query).trim().toLowerCase();
  const byNew = (a, b) => (b.updated || 0) - (a.updated || 0);
  const pre = [], mid = [];
  for (const x of Array.isArray(notes) ? notes : []) {
    if (!x || typeof x.id !== 'string' || x.id === selfId) continue;
    const title = String(x.title || '').trim(); if (!title) continue;
    const lc = title.toLowerCase(), it = { id: x.id, title, updated: x.updated };
    if (!q || lc.startsWith(q)) pre.push(it); else if (lc.includes(q)) mid.push(it);
  }
  return pre.sort(byNew).concat(mid.sort(byNew)).slice(0, limit).map(({ id, title }) => ({ id, title }));
}
const escHtml = (v) => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
// HTML tautan antarcatatan (satu-satunya bentuk yang dikenal sanitize di notes.js). Murni.
export function wikiHtml(id, title) { return '<span class="nl" data-nid="' + escHtml(id) + '" contenteditable="false">' + escHtml(title) + '</span>&nbsp;'; }

// Rev 339 / I7: pemicu format otomatis. line = teks dari awal baris sampai kursor; blokTeks = seluruh teks blok (anak langsung editor) yang memuat kursor.
// Mengembalikan 'checkbox' | 'numbered' | 'bullet' | null. Murni (dites tanpa DOM). Blok harus berisi PEMICU SAJA: teks lain di blok yang sama = tidak diubah.
export function fmtFor(line, blokTeks) {
  if (typeof line !== 'string' || typeof blokTeks !== 'string') return null;
  const t = detectTrigger(line.replace(/\u00a0/g, ' '), { ctx: 'note', only: ['checkbox', 'numbered', 'bullet'] });
  if (!t || (t.kind !== 'checkbox' && t.kind !== 'numbered' && t.kind !== 'bullet')) return null;
  return blokTeks.replace(/[\s\u00a0\u200b]/g, '') === t.raw.trim() ? t.kind : null;
}
const FMT_TAGS = /^(DIV|P|SPAN|B|I|U|S|STRONG|EM|STRIKE|FONT)$/;
// Blok (anak langsung editor) yang boleh diganti: simpul teks, atau elemen polos (tanpa class) yang hanya berisi teks/<br>.
function fmtBlockOk(blk) {
  if (!blk) return false;
  if (blk.nodeType === 3) return true;
  if (blk.nodeType !== 1 || !FMT_TAGS.test(blk.tagName) || blk.className) return false;
  return !blk.querySelector('img,input,table,figure,ul,ol,blockquote,[contenteditable="false"],[class]');
}
const blankText = (el) => !(el && (el.textContent || '').replace(/[\s\u00a0\u200b]/g, ''));

// env: { ed, flushHist, tags?, slash?, remind?, wiki? }. wiki = { notes() -> daftar catatan biasa, selfId, done(id) } (Rev 343 / I2; hanya notes.js). remind = { open(row, atMs) } (Rev 341 / I8). slash = { has(id) -> bool, run(id) } (hanya notes.js; Rev 340 / I6). tags = { state(tag) -> 'on'|'has'|'new', apply(tag) -> { ok, msg, undo? } } (hanya notes.js yang memilikinya). Mengembalikan { check, destroy } atau null bila dock tidak ditemukan.
export function pasangKetik(env) {
  const { ed, flushHist } = env;
  const dock = ed.closest ? (ed.closest('.fs') || document).querySelector('.dock') : null;
  const bar = dock && dock.querySelector('.fbar');
  if (!dock || !bar) return null;
  let cur = null, composing = false, busy = false, spaceTyped = false, last = null; // last = format otomatis terakhir { kind, el } yang masih bisa dibatalkan dengan satu Backspace
  const stop = (e) => e.preventDefault(); // ketuk saran tidak boleh mencuri fokus (papan ketik tetap terbuka, kursor tetap)
  const hasil = h('b', { class: 'kp-v' }), cap = h('small', {}, 'Hasil');
  const btn = h('button', { type: 'button', class: 'kp-btn', onpointerdown: stop, onmousedown: stop, onclick: () => apply() }, cap, hasil);
  const row = h('div', { class: 'kp-row', role: 'status', 'aria-live': 'polite', hidden: '' }, btn);
  dock.insertBefore(row, bar);
  const menu = h('div', { class: 'kq-row', role: 'toolbar', 'aria-label': 'Menu cepat perintah', hidden: '' }); // Rev 340 / I6
  dock.insertBefore(menu, bar);
  let menuKey = '', muted = false;

  const hide = () => { cur = null; if (!row.hidden) row.hidden = true; if (!menu.hidden) { menu.hidden = true; menuKey = ''; } };
  const find = () => {
    if (!ed.isConnected || !ed.isContentEditable || document.activeElement !== ed) return null;
    const sl = getSelection();
    if (!sl || !sl.rangeCount || !sl.isCollapsed) return null;
    const nd = sl.anchorNode, off = sl.anchorOffset;
    if (!nd || nd.nodeType !== 3 || !ed.contains(nd) || off < 1) return null;
    const ch = nd.data[off - 1], isEq = ch === '=', isSp = ch === ' ' || ch === '\u00a0';
    // Rev 340 / I6: `/` atau huruf sesudah `/` di simpul yang sama (menu cepat). Hanya menu `/` yang boleh tampil saat IME menyusun kata (Gboard menyusun huruf sesudah `/`).
    const isSl = !!env.slash && !muted && (ch === '/' || (/[A-Za-z]/.test(ch) && nd.data.lastIndexOf('/', off - 1) >= 0));
    const isBang = !!env.remind && nd.data.lastIndexOf('!', off - 1) >= 0;
    const isWk = !!env.wiki && !muted && nd.data.lastIndexOf('[[', off - 1) >= 0; // Rev 343 / I2: `[[` terbuka di simpul yang sama; IME boleh menyusun (Gboard menyusun kata sesudah `[[`)
    if (composing && !isSl && !isWk) return null;
    if (!isEq && !isSl && !isBang && !isWk && !(isSp && env.tags)) return null; // gerbang murah: `=`, spasi, `/` atau huruf sesudah `/` tepat di kiri kursor; selain itu selesai
    const el = nd.parentElement;
    if (!el || (el.closest && el.closest(BLOCKED))) return null;
    const line = lineBefore(ed, nd, off);
    if (isWk) { const wf = wikiFor(line); if (wf) return { kind: 'wiki', ...wf, node: nd, off }; } // `[[` terbuka menang atas menu `/`, hitung cepat, `!` dan `#` (judul boleh memuat itu semua)
    if (env.remind && nd.data.lastIndexOf('!', off - 1) >= 0) { // Rev 341 / I8 + Rev 348 / R3: baris kotak centang (`.todo`) dan item bullet/bernomor (`li`); teks pemicu TETAP di baris
      const row = el.closest('.todo,li');
      const rm = row && ed.contains(row) ? remindFor(line) : null;
      if (rm) return { kind: 'remind', ...rm, row };
    }
    if (isSl) { const sf = slashFor(line, env.slash.has); return sf ? { kind: 'slash', ...sf, node: nd, off } : null; }
    if (isEq) { const c = calcFor(line); return c ? { kind: 'calc', ...c } : null; }
    const t = tagFor(line); return t ? { kind: 'tag', ...t, st: env.tags.state(t.tag) } : null;
  };
  // Rev 340 / I6: kapsul menu cepat. Dirender ulang hanya bila daftar berubah (selectionchange sering menembak).
  const showMenu = (r) => {
    const key = r.items.map((c) => c.id).join(',');
    if (key !== menuKey) {
      menuKey = key;
      menu.replaceChildren(...r.items.map((c) => h('button', { type: 'button', class: 'kq-btn', 'data-slash': c.id, 'aria-label': 'Sisipkan ' + c.label, onpointerdown: stop, onmousedown: stop, onclick: () => pick(c.id) }, c.label)));
      menu.scrollLeft = 0;
    }
    menu.hidden = false;
  };
  const pick = (id) => {
    const r = find(); // hitung ulang: kursor/ketikan mungkin berubah sejak kapsul tampil
    if (!r || r.kind !== 'slash' || !r.items.some((c) => c.id === id)) { hide(); return; }
    busy = true;
    try {
      const rg = document.createRange(); rg.setStart(r.node, r.off - (r.query.length + 1)); rg.setEnd(r.node, r.off);
      const sl = getSelection(); sl.removeAllRanges(); sl.addRange(rg);
      document.execCommand('delete'); // buang `/perintah`; perintah sesudahnya mencatat riwayatnya sendiri (Urungkan: 1x = perintah, 2x = teks `/perintah` kembali)
      hide();
      env.slash.run(id);
    } finally { busy = false; }
  };
  // Rev 343 / I2: kapsul judul catatan untuk `[[`. Memakai baris `.kq-row` yang sama dengan menu `/`; dirender ulang hanya bila daftar berubah.
  const showWiki = (r) => {
    const items = wikiList(env.wiki.notes(), env.wiki.selfId, r.query), key = 'w:' + items.map((c) => c.id + '|' + c.title).join(',');
    if (key !== menuKey) {
      menuKey = key;
      menu.replaceChildren(...(items.length ? items.map((c) => h('button', { type: 'button', class: 'kq-btn kq-note', 'data-nid': c.id, 'aria-label': 'Tautkan ke catatan ' + c.title, onpointerdown: stop, onmousedown: stop, onclick: () => pickNote(c.id) }, c.title)) : [h('span', { class: 'kq-none' }, 'Tidak ada catatan yang cocok')]));
      menu.scrollLeft = 0;
    }
    menu.hidden = false;
  };
  const pickNote = (id) => {
    const r = find(); // hitung ulang: kursor/ketikan mungkin berubah sejak kapsul tampil
    const it = r && r.kind === 'wiki' ? wikiList(env.wiki.notes(), env.wiki.selfId, r.query).find((c) => c.id === id) : null;
    if (!it) { hide(); return; }
    busy = true;
    try {
      flushHist(); // ketikan `[[kata` satu langkah, penyisipan tautan langkah berikutnya: SATU Urungkan membuang tautannya saja
      const rg = document.createRange(); rg.setStart(r.node, r.off - (r.query.length + 2)); rg.setEnd(r.node, r.off);
      const sl = getSelection(); sl.removeAllRanges(); sl.addRange(rg);
      document.execCommand('delete'); // buang `[[kata`
      hide();
      document.execCommand('insertHTML', false, wikiHtml(it.id, it.title));
      env.wiki.done(it.id);
      flushHist();
    } finally { busy = false; }
  };
  const check = () => {
    const r = find();
    if (!r || (r.kind === 'tag' && r.st === 'on')) { hide(); return; } // label sudah terpasang = tidak ada yang ditawarkan
    cur = r;
    if (r.kind === 'wiki') { row.hidden = true; showWiki(r); return; }
    if (r.kind === 'slash') { row.hidden = true; showMenu(r); return; }
    if (!menu.hidden) { menu.hidden = true; menuKey = ''; }
    if (r.kind === 'remind') { cap.textContent = 'Ingatkan'; hasil.textContent = r.label; btn.setAttribute('aria-label', 'Atur pengingat ' + r.label + ' untuk baris ini'); row.hidden = false; return; }
    if (r.kind === 'calc') { cap.textContent = 'Hasil'; hasil.textContent = r.text; btn.setAttribute('aria-label', 'Sisipkan hasil ' + r.text + ' sesudah tanda sama dengan'); }
    else { cap.textContent = r.st === 'new' ? 'Buat label' : 'Pasang label'; hasil.textContent = r.tag; btn.setAttribute('aria-label', (r.st === 'new' ? 'Buat dan pasang label ' : 'Pasang label ') + r.tag + ' pada catatan ini'); }
    row.hidden = false;
  };
  const apply = () => {
    const r = find(); // hitung ulang: kursor mungkin sudah berpindah sejak saran tampil
    if (!r) { hide(); return; }
    if (r.kind === 'remind') { hide(); env.remind.open(r.row, r.when); return; } // membuka lembar Ingatkan saya terisi; tidak menjadwalkan langsung
    if (r.kind === 'tag') {
      const o = env.tags.apply(r.tag); hide();
      if (!o) return;
      if (o.ok) tOk(o.msg, o.undo); else tWarn(o.msg);
      return;
    }
    flushHist(); // ketikan `12*3=` jadi langkah sendiri, penyisipan hasil langkah berikutnya = satu Urungkan membuang hasilnya saja
    document.execCommand('insertText', false, r.text);
    flushHist();
    hide();
  };

  // ---- Rev 339 / I7 + Rev 358: format otomatis `[] `, `1. ` dan `- ` ----
  const setCaret = (node, off) => { const sl = getSelection(), r = document.createRange(); r.setStart(node, off); r.collapse(true); sl.removeAllRanges(); sl.addRange(r); };
  const fmtFind = () => {
    if (busy || composing || !ed.isConnected || !ed.isContentEditable || document.activeElement !== ed) return null;
    const sl = getSelection();
    if (!sl || !sl.rangeCount || !sl.isCollapsed) return null;
    const nd = sl.anchorNode, off = sl.anchorOffset;
    if (!nd || nd.nodeType !== 3 || !ed.contains(nd) || off < 1 || off < nd.data.length) return null; // kursor di ujung simpul teks
    const ch = nd.data[off - 1];
    if (ch !== ' ' && ch !== '\u00a0') return null; // gerbang murah: spasi tepat di kiri kursor
    const el = nd.parentElement;
    if (!el || (el.closest && el.closest(BLOCKED))) return null;
    let blk = nd; while (blk.parentNode && blk.parentNode !== ed) blk = blk.parentNode;
    if (blk.parentNode !== ed || !fmtBlockOk(blk)) return null;
    const kind = fmtFor(lineBefore(ed, nd, off), blk.textContent || '');
    return kind ? { kind, blk } : null;
  };
  const fmtApply = () => {
    const f = fmtFind(); if (!f) return false;
    busy = true;
    try {
      flushHist(); // ketikan pemicu satu langkah, perubahan format langkah berikutnya: SATU Urungkan mengembalikan teks pemicu
      let el;
      if (f.kind === 'checkbox') {
        el = newTodoRow(document); ed.replaceChild(el, f.blk);
        const c = caretAfterBox(el); if (c) setCaret(c.node, c.offset);
      } else {
        const d = document.createElement('div'); d.appendChild(document.createElement('br')); ed.replaceChild(d, f.blk);
        setCaret(d, 0);
        document.execCommand(f.kind === 'bullet' ? 'insertUnorderedList' : 'insertOrderedList');
        const a = getSelection().anchorNode; el = a && (a.nodeType === 1 ? a : a.parentElement); el = el && el.closest ? el.closest('li') : null;
        if (!el) { // perintah gagal: kembalikan teks pemicu persis seperti diketik
          const t = document.createElement('div'); t.textContent = f.kind === 'bullet' ? '-\u00a0' : '1.\u00a0';
          if (d.parentNode === ed) { ed.replaceChild(t, d); setCaret(t.firstChild, 2); }
          return false;
        }
      }
      last = { kind: f.kind, el };
      ed.dispatchEvent(new Event('input', { bubbles: true })); // pulihkan invarian (healTodos), simpan otomatis, riwayat
      flushHist();
    } finally { busy = false; }
    return true;
  };
  // Backspace TEPAT sesudah format otomatis (barisnya masih kosong, kursor masih di situ) = kembalikan teks pemicu. Fase capture supaya mendahului penanganan Backspace baris centang (Rev 108).
  const undoFmt = () => {
    const l = last; last = null;
    if (!l || !l.el.isConnected) return false;
    const sl = getSelection();
    if (!sl || !sl.rangeCount || !sl.isCollapsed || !l.el.contains(sl.anchorNode)) return false;
    if (l.kind === 'checkbox' ? !isTodoBlank(l.el) : !blankText(l.el)) return false;
    busy = true;
    try {
      flushHist();
      if (l.kind === 'checkbox') { const d = document.createElement('div'); d.appendChild(document.createElement('br')); ed.replaceChild(d, l.el); setCaret(d, 0); }
      else document.execCommand(l.kind === 'bullet' ? 'insertUnorderedList' : 'insertOrderedList'); // sakelar: li tunggal kembali jadi baris biasa
      document.execCommand('insertText', false, l.kind === 'checkbox' ? '[]\u00a0' : l.kind === 'bullet' ? '-\u00a0' : '1.\u00a0');
      ed.dispatchEvent(new Event('input', { bubbles: true }));
      flushHist();
    } finally { busy = false; }
    return true;
  };
  const onBefore = (e) => {
    if (e.isComposing) return;
    if (e.inputType === 'insertParagraph') { waEnter(); return; } // Rev 364 / W4: fase capture, jadi mendahului penanganan Enter baris centang/bagian lipat di notes.js
    if (!last || e.inputType !== 'deleteContentBackward') return;
    if (last.kind === 'wa2' ? undoWa2() : last.kind === 'wa' ? undoWa() : undoFmt()) { e.preventDefault(); e.stopImmediatePropagation(); }
  };
  const format = () => fmtApply();

  const onSel = () => { if (!ed.isConnected) { destroy(); return; } if (last && !busy) { const sl = getSelection(); if (!sl || !sl.rangeCount || !last.el.contains(sl.anchorNode)) last = null; } check(); }; // editor ditutup = pendengar dokumen melepas diri sendiri
  const onComp = (e) => { composing = e.type === 'compositionstart'; if (!composing) { check(); if (spaceTyped) format(); waApply(null, 'comp'); } }; // W4: pemicu yang tiba bersama selesainya komposisi IME
  // Format otomatis HANYA oleh ketikan yang berakhir spasi (bukan oleh Backspace/tempel yang kebetulan meninggalkan `[] ` di awal baris).
  const typedSpace = (e) => !!e && /^insert/.test(e.inputType || '') && /[ \u00a0]$/.test(e.data || '');
  const onInput = (e) => { if (busy) return; if (enterHeal) { const hl = enterHeal; enterHeal = null; healEnter(hl, e); } last = null; muted = false; spaceTyped = typedSpace(e); if (e && e.isComposing) { check(); return; } check(); if (!(spaceTyped && format())) waApply(e); }; // saat IME menyusun, check() sendiri menolak semua pemicu kecuali menu `/`
  const onKey = (e) => { if (e.key === 'Escape' && !menu.hidden) { muted = true; hide(); } }; // Esc (papan ketik fisik) menutup menu; `/` tetap sebagai teks
  // ---- Rev 362 / W2: tebal `*x*` dan miring `_x_` gaya WhatsApp ----
  const waTyped = (e) => !!e && e.inputType === 'insertText' && !e.isComposing && typeof e.data === 'string' && e.data.length === 1 && isTriggerChar(e.data);
  // Rev 364 / W4: `mode` = undefined (ketikan karakter pemicu, W2/W3), 'comp' (IME baru selesai menyusun; karakter pemicu sudah ada di DOM) atau 'enter' (Enter di ujung baris; satu karakter pemicu MAYA di kanan kursor, TIDAK ada di DOM).
  let enterHeal = null; // simpul teks kosong penampung kursor sesudah format lewat Enter; dipakai healEnter
  const waApply = (e, mode) => {
    const en = mode === 'enter';
    if (busy || composing || (!mode && !waTyped(e)) || !ed.isConnected || !ed.isContentEditable || document.activeElement !== ed) return false;
    const sl = getSelection();
    if (!sl || !sl.rangeCount || !sl.isCollapsed) return false;
    const nd = sl.anchorNode;
    if (!nd || nd.nodeType !== 3 || !ed.contains(nd) || (en && sl.anchorOffset !== nd.data.length)) return false;
    const off = en ? sl.anchorOffset + 1 : sl.anchorOffset, dat = en ? nd.data + '\u00a0' : nd.data;
    if (off < 2 || !isTriggerChar(dat[off - 1])) return false; // spasi diketik jadi nbsp di Chrome; di simpul yang sama paling pendek `*x* ` = 4 huruf (dijaga di bawah), lintas simpul penutup + pemicu = 2
    const pc = dat[off - 2]; if (pc !== '*' && pc !== '_') return false; // gerbang murah: penutup tepat sebelum karakter yang baru diketik
    const el = nd.parentElement;
    if (!el || (el.closest && el.closest(BLOCKED))) return false;
    const lb = lineBefore(ed, nd, en ? off - 1 : off), ctx = lb == null ? null : en ? lb + '\u00a0' : lb; if (!ctx || ctx.length < off) return false;
    const base = ctx.length - off; // posisi awal simpul ini di dalam baris
    const ps = pairsClosedBefore(ctx, ctx.length);
    if (!ps.length) return false;
    const done = (ok) => { if (ok && en) { last = null; enterHeal = { n: enterHeal && enterHeal.n }; } return ok; }; // Enter: tidak ada Backspace-batal
    if (ps.some((p) => p.open < base)) return done(ps.length === 1 ? waCross(nd, off, ctx, ps[0]) : false); // melintasi simpul (W3): satu pasangan, pembuka saudara penutup; gabungan lintas simpul tidak didukung
    if (off < 4) return false;
    const a = Math.min(...ps.map((p) => p.open)) - base, seg = dat.slice(a, off - 1);
    const r = resolveLine(seg); if (!r.runs.length) return false;
    busy = true;
    try {
      flushHist(); // ketikan satu langkah, format langkah berikutnya: SATU Urungkan mengembalikan teks mentah
      const nodes = []; let at = 0;
      const put = (n) => nodes.push(n);
      for (const run of r.runs) {
        if (run.start > at) put(document.createTextNode(r.plain.slice(at, run.start)));
        let x = document.createTextNode(r.plain.slice(run.start, run.end));
        if (run.miring) { const i = document.createElement('i'); i.appendChild(x); x = i; }
        if (run.tebal) { const b = document.createElement('b'); b.appendChild(x); x = b; }
        put(x); at = run.end;
      }
      if (at < r.plain.length) put(document.createTextNode(r.plain.slice(at)));
      const post = document.createTextNode(en ? '' : dat.slice(off - 1)); // Enter: karakter pemicu maya TIDAK ditulis
      nd.data = nd.data.slice(0, a);
      nd.after(...nodes, post);
      setCaret(post, en ? 0 : 1);
      last = { kind: 'wa', el: post, post, nodes, seg, ch: post.data[0] };
      if (en) enterHeal = { n: post };
      ed.dispatchEvent(new Event('input', { bubbles: true })); // simpan otomatis, riwayat
      flushHist();
    } finally { busy = false; }
    return done(true);
  };
  // Rev 363 / W3: pasangan yang membungkus teks berformat lain (pembuka dan penutup = simpul teks bersaudara, di antaranya boleh elemen sebaris seperti <b>/<i>).
  const waCross = (nd, off, ctx, p) => {
    const A_ = lineTexts(ed, nd); let acc = ctx.length - off - A_.slice(0, -1).reduce((n, t) => n + t.data.length, 0); // awal teks A_[0] di dalam ctx (0 bila baris dimulai di sana)
    let A = null, aOff = 0;
    for (const t of A_) { if (p.open >= acc && p.open < acc + t.data.length) { A = t; aOff = p.open - acc; break; } acc += t.data.length; }
    if (!A || A === nd || A.parentNode !== nd.parentNode || A.data[aOff] !== p.ch) return false;
    const c = off - 2, par = nd.parentNode;
    const sibs = []; for (let x = A; x; x = x.nextSibling) { sibs.push(x); if (x === nd) break; }
    if (sibs[sibs.length - 1] !== nd) return false;
    const rg = document.createRange(); rg.setStart(A, aOff + 1); rg.setEnd(nd, c);
    if (rg.cloneContents().querySelector(BLOCKED)) return false; // kartu/tautan/gambar/tabel di antara = tidak diformat
    busy = true;
    try {
      flushHist();
      const clones = sibs.map((x) => x.cloneNode(true)), ref = nd.nextSibling, ch = nd.data[off - 1];
      const frag = rg.extractContents(), wrap = document.createElement(p.tebal ? 'b' : 'i'); wrap.appendChild(frag);
      A.data = A.data.slice(0, aOff); nd.data = nd.data.slice(1);
      A.after(wrap); setCaret(nd, Math.min(1, nd.data.length)); if (!nd.data) enterHeal = { n: nd }; // Enter (W4): simpul penutup tinggal kosong
      last = { kind: 'wa2', el: nd, A, wrap, nd, par, clones, ref, ch, off };
      ed.dispatchEvent(new Event('input', { bubbles: true }));
      flushHist();
    } finally { busy = false; }
    return true;
  };
  // Rev 364 / W4: Enter di ujung baris tepat sesudah penutup. Syarat: kursor di UJUNG simpul teks dan tidak ada teks lain sesudahnya di baris itu.
  const waEnter = () => {
    enterHeal = null;
    if (busy || composing) return;
    const sl = getSelection();
    if (!sl || !sl.rangeCount || !sl.isCollapsed) return;
    const nd = sl.anchorNode, off = sl.anchorOffset;
    if (!nd || nd.nodeType !== 3 || off < 1 || off !== nd.data.length || !ed.contains(nd)) return;
    const c = nd.data[off - 1]; if (c !== '*' && c !== '_') return; // gerbang murah
    const nx = nd.nextSibling; if (nx && !(nx.nodeType === 1 && nx.tagName === 'BR') && !(nx.nodeType === 3 && !nx.data)) return;
    waApply(null, 'enter');
  };
  // Penyembuhan sesudah Enter yang tadi memformat: baris baru BUKAN lanjutan tebal/miring (Chromium menaruh <b><br></b> / <i><br></i> di baris baru) dan simpul teks kosong penampung kursor dibuang.
  const healEnter = (hl, e) => {
    if (hl.n && hl.n.isConnected && !hl.n.data) hl.n.remove();
    if (!e || e.inputType !== 'insertParagraph') return; // Enter yang dicegat pengendali lain (baris centang baru, bagian lipat) = baris baru sudah bersih
    const sl = getSelection();
    if (!sl || !sl.rangeCount || !sl.isCollapsed) return;
    let x = sl.anchorNode; if (x && x.nodeType === 3) x = x.parentNode;
    let target = null;
    for (; x && x !== ed && (x.tagName === 'B' || x.tagName === 'I') && x.textContent === ''; x = x.parentNode) target = x; // pembungkus kosong terluar
    if (!target) return;
    busy = true;
    try {
      const par = target.parentNode, idx = Array.prototype.indexOf.call(par.childNodes, target), br = target.querySelector('br') || document.createElement('br');
      par.insertBefore(br, target); target.remove(); setCaret(par, idx);
      ed.dispatchEvent(new Event('input', { bubbles: true })); // simpan otomatis + riwayat memakai isi yang sudah bersih
    } finally { busy = false; }
  };
  const undoWa2 = () => {
    const l = last; last = null;
    if (!l || !l.nd.isConnected || !l.A.isConnected || !l.wrap.isConnected || l.A.parentNode !== l.par) return false;
    const sl = getSelection();
    if (!sl || !sl.rangeCount || !sl.isCollapsed || sl.anchorNode !== l.nd || sl.anchorOffset !== 1 || l.nd.data[0] !== l.ch) return false;
    busy = true;
    try {
      flushHist();
      const ref = l.nd.nextSibling;
      [l.A, l.wrap, l.nd].forEach((n) => n.remove());
      l.clones.forEach((n) => l.par.insertBefore(n, ref));
      setCaret(l.clones[l.clones.length - 1], l.off);
      ed.dispatchEvent(new Event('input', { bubbles: true }));
      flushHist();
    } finally { busy = false; }
    return true;
  };
  const undoWa = () => {
    const l = last; last = null;
    if (!l || !l.post.isConnected || !l.nodes.every((n) => n.isConnected)) return false;
    const sl = getSelection();
    if (!sl || !sl.rangeCount || !sl.isCollapsed || sl.anchorNode !== l.post || sl.anchorOffset !== 1 || l.post.data[0] !== l.ch) return false;
    busy = true;
    try {
      flushHist();
      const raw = document.createTextNode(l.seg);
      l.post.before(raw); l.nodes.forEach((n) => n.remove());
      setCaret(l.post, 1);
      ed.dispatchEvent(new Event('input', { bubbles: true }));
      flushHist();
    } finally { busy = false; }
    return true;
  };
  function destroy() { document.removeEventListener('selectionchange', onSel); ed.removeEventListener('input', onInput); ed.removeEventListener('compositionstart', onComp); ed.removeEventListener('compositionend', onComp); ed.removeEventListener('blur', hide); ed.removeEventListener('beforeinput', onBefore, true); ed.removeEventListener('keydown', onKey); row.remove(); menu.remove(); last = null; cur = null; }
  document.addEventListener('selectionchange', onSel);
  ed.addEventListener('input', onInput);
  ed.addEventListener('compositionstart', onComp); ed.addEventListener('compositionend', onComp);
  ed.addEventListener('blur', hide);
  ed.addEventListener('beforeinput', onBefore, true);
  ed.addEventListener('keydown', onKey);
  return { check, destroy, apply, format, wa: waApply, pick, pickNote, get shown() { return !row.hidden; }, get menuShown() { return !menu.hidden; } };
}
