// Rev 423 / PART SY3c (Paket SY): SINKRON OTOMATIS. Dimuat MALAS dari main.js HANYA bila pengaturan `auto` menyala (pemeriksaan murah di main.js).
// Pemicu: 'buka' (sesudah gambar pertama), 'simpan' (tiap persist, ditunda sampai tenang), 'kembali' (app kembali dari latar), 'online' (internet kembali).
// Aturan: butuh sambungan + sakelar Otomatis; jeda minimal antar putaran; TIDAK jalan saat editor layar penuh terbuka (ditunda, supaya tarikan tidak menimpa catatan yang sedang diedit);
// offline = menunggu kejadian `online`; gagal = jeda panjang (backoff); hapus massal TIDAK pernah diizinkan otomatis (ditahan, pengguna diberi tahu).
import { loadSyncCfg, jalankanSinkron, sedangSinkron } from './sync-jalan.js';
import { loadConn } from './ai/sambungan.js';

export const AUTO = { simpanTunda: 8000, bukaTunda: 3000, jedaMin: 30000, jedaKembali: 60000, jedaGagal: 300000, cekEditor: 10000 };

// deps (semua opsional, untuk tes): now, setTimeout, clearTimeout, online(), editorBuka(), store, jalan(opts), render, toast {warn, info}.
export function buatPenjadwal(ctx, deps = {}) {
  const now = deps.now || (() => Date.now()), st = deps.setTimeout || setTimeout, ct = deps.clearTimeout || clearTimeout;
  const online = deps.online || (() => !globalThis.navigator || globalThis.navigator.onLine !== false);
  const editorBuka = deps.editorBuka || (() => !!(globalThis.document && globalThis.document.querySelector('.fs')));
  const jalan = deps.jalan || jalankanSinkron, store = deps.store;
  let timer = null, gagalSampai = 0, menungguOnline = false, laporKeluar = false;
  const catat = { mulai: 0, jalan: 0 };

  const aktif = () => { const c = loadSyncCfg(store); return c.auto === true && !!loadConn(store); };
  const jadwal = (ms) => { if (timer) ct(timer); timer = st(() => { timer = null; coba(); }, Math.max(0, ms)); };

  async function coba() {
    if (!aktif()) return;
    if (sedangSinkron()) return jadwal(AUTO.cekEditor);
    if (!online()) { menungguOnline = true; return; }
    const t = now();
    if (t < gagalSampai) return jadwal(gagalSampai - t);
    const sisa = catat.mulai + AUTO.jedaMin - t; if (sisa > 0) return jadwal(sisa);
    if (editorBuka()) return jadwal(AUTO.cekEditor);
    catat.mulai = t; catat.jalan++;
    const res = await jalan({ data: ctx.data, persist: () => ctx.persist(), sanitize: deps.sanitize, afterApply: deps.afterApply || (() => {}), store, allowMassDelete: false });
    if (!res || res.busy) return;
    if (res.ok === false && !res.needConn) {
      gagalSampai = now() + AUTO.jedaGagal;
      if (res.passcode && !laporKeluar) { laporKeluar = true; if (deps.toast) deps.toast.warn('Sinkron otomatis berhenti: passcode ditolak. Cek di tab Kelimaa AI.'); }
    } else { gagalSampai = 0; laporKeluar = false; }
    if (res.held && deps.toast) deps.toast.warn(res.held.deletes + ' penghapusan ditahan. Buka Setelan > Sync untuk memutuskan.');
  }

  // why: 'buka' | 'simpan' | 'kembali' | 'online'
  function pemicu(why) {
    if (!aktif()) return false;
    if (why === 'simpan' && sedangSinkron()) return false; // simpan yang dipicu sinkron itu sendiri tidak boleh memicu putaran baru (lingkaran tak berujung)
    const t = now();
    if (why === 'buka') jadwal(AUTO.bukaTunda);
    else if (why === 'simpan') jadwal(AUTO.simpanTunda);
    else if (why === 'online') { if (menungguOnline) { menungguOnline = false; jadwal(AUTO.bukaTunda); } }
    else if (why === 'kembali') { const c = loadSyncCfg(store); if (t - (c.lastTryAt || 0) >= AUTO.jedaKembali) jadwal(AUTO.bukaTunda); }
    else return false;
    return true;
  }
  return { pemicu, coba, status: () => ({ terjadwal: !!timer, menungguOnline, gagalSampai, putaran: catat.jalan }) };
}

// Penjadwal tunggal untuk aplikasi. main.js memanggil `pemicu(ctx, why)`.
let tunggal = null;
export async function pemicu(ctx, why) {
  if (!tunggal) {
    const [{ sanitize }, { syncAllReminders }, { syncAllNoteAlarms }, ui] = await Promise.all([import('./notes.js'), import('./reminders.js'), import('./cb-alarm.js'), import('./ui.js')]);
    tunggal = buatPenjadwal(ctx, { sanitize, toast: { warn: ui.tWarn, info: ui.tInfo },
      afterApply: () => { try { syncAllReminders(ctx.data); syncAllNoteAlarms(ctx.data); } catch (_) { /* pengingat tidak boleh menggagalkan sinkron */ } if (!document.querySelector('.fs')) ctx.render(); } });
    if (globalThis.addEventListener) globalThis.addEventListener('online', () => tunggal.pemicu('online'));
  }
  return tunggal.pemicu(why);
}
