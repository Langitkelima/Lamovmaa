// Rev 254 / S5a: aksi yang mengikuti SELEKSI (hapus isi, sisip/hapus baris dan kolom). Modul murni: hanya mengubah `tab` lewat API lembar.js; tanpa DOM/penyimpanan/native/eval.
// Rujukan rumus disimpan lewat ID baris/kolom (bukan nomor), jadi sisip/geser tidak merusaknya; yang dirujuk lalu dihapus menjadi #REF! (perilaku mesin rumus).
// Pemanggil (lembar-ui.js) memegang Urungkan: ser() sebelum, hist.push hanya bila `changed`, dan fitsLimit sesudah.
import * as L from './lembar.js';
import * as SX from './lembar-seleksi.js';

// Hapus nilai dan rumus sel di seleksi; GAYA tetap (seperti 'Hapus isi' di Google Sheets). rowOk(r) = penyaring baris (filter aktif); bawaan semua baris.
export function clearContents(tab, sx, rowOk) {
  let n = 0; if (!tab || !sx) return { ok: false, changed: false, n: 0 };
  for (const x of SX.existingCells(tab, sx)) {
    if (typeof rowOk === 'function' && !rowOk(x.r)) continue;
    if (x.cell && (x.cell.v !== undefined || x.cell.fx !== undefined) && L.setCell(tab, x.row.id, x.col.id, { v: null })) n++;
  }
  return { ok: true, changed: n > 0, n };
}

// Sisip baris sebanyak baris terpilih di atas ('above') atau di bawah ('below') seleksi. Dibatasi MAX_ROWS: k < diminta bila lembar hampir penuh.
export function insertRows(tab, sx, where) {
  if (!tab || !sx) return { ok: false, changed: false, n: 0 };
  const want = SX.rowCount(sx), k = Math.min(want, L.MAX_ROWS - tab.rows.length); if (k <= 0) return { ok: false, changed: false, n: 0, full: true };
  const at = where === 'below' ? sx.rect.r2 + 1 : sx.rect.r1;
  for (let i = 0; i < k; i++) if (!L.insertRow(tab, at)) break;
  return { ok: true, changed: true, n: k, want, at };
}
export function insertCols(tab, sx, where) {
  if (!tab || !sx) return { ok: false, changed: false, n: 0 };
  const want = SX.colCount(sx), k = Math.min(want, L.MAX_COLS - tab.cols.length); if (k <= 0) return { ok: false, changed: false, n: 0, full: true };
  const at = where === 'right' ? sx.rect.c2 + 1 : sx.rect.c1;
  for (let i = 0; i < k; i++) if (!L.insertCol(tab, at)) break;
  return { ok: true, changed: true, n: k, want, at };
}

// Hapus baris/kolom terpilih. Sedikitnya SATU baris dan SATU kolom harus tersisa (all = true bila diminta menghapus semuanya; tidak mengubah apa pun).
export function deleteRows(tab, sx) {
  if (!tab || !sx) return { ok: false, changed: false, n: 0 };
  const ids = []; for (let r = sx.rect.r1; r <= sx.rect.r2; r++) if (tab.rows[r]) ids.push(tab.rows[r].id);
  if (!ids.length) return { ok: false, changed: false, n: 0 }; if (ids.length >= tab.rows.length) return { ok: false, changed: false, n: 0, all: true };
  let n = 0; for (const id of ids) if (L.deleteRow(tab, id)) n++; return { ok: true, changed: n > 0, n };
}
export function deleteCols(tab, sx) {
  if (!tab || !sx) return { ok: false, changed: false, n: 0 };
  const ids = []; for (let c = sx.rect.c1; c <= sx.rect.c2; c++) if (tab.cols[c]) ids.push(tab.cols[c].id);
  if (!ids.length) return { ok: false, changed: false, n: 0 }; if (ids.length >= tab.cols.length) return { ok: false, changed: false, n: 0, all: true };
  let n = 0; for (const id of ids) if (L.deleteCol(tab, id)) n++; return { ok: true, changed: n > 0, n };
}

// Teks untuk tombol/toast (Bahasa Indonesia).
export const labelOf = (kind, sx) => {
  const r = sx ? SX.rowCount(sx) : 0, c = sx ? SX.colCount(sx) : 0, b = (n, w) => (n === 1 ? '1 ' + w : n + ' ' + w);
  return { clear: 'Hapus isi', rowUp: 'Sisip ' + b(r, 'baris') + ' di atas', rowDown: 'Sisip ' + b(r, 'baris') + ' di bawah', colLeft: 'Sisip ' + b(c, 'kolom') + ' di kiri', colRight: 'Sisip ' + b(c, 'kolom') + ' di kanan', delRows: 'Hapus ' + b(r, 'baris'), delCols: 'Hapus ' + b(c, 'kolom') }[kind] || '';
};
