// Rev 281 / V6c-1: daftar pilihan DARI RENTANG SEL. Modul MURNI dan MALAS (dimuat bersama lembar-ui.js; BUKAN jalur buka). Tanpa DOM/penyimpanan/native/eval.
// Aturan list boleh punya `src: { c1, c2, r1, r2 }` (ID kolom/baris). `items` = salinan terakhir isi rentang (urut baris demi baris), disegarkan di sini.
import { MAX_ITEMS, MAX_ITEM_LEN } from './lembar-validasi.js';
// Rentang sumber -> indeks { r1, r2, c1, c2 } atau null bila ID hilang (urutan dibalik dibetulkan).
export function srcRect(tab, src) {
  if (!tab || !src || !Array.isArray(tab.cols) || !Array.isArray(tab.rows)) return null;
  const ix = (arr, id) => arr.findIndex((x) => x.id === id), a = ix(tab.cols, src.c1), b = ix(tab.cols, src.c2), c = ix(tab.rows, src.r1), d = ix(tab.rows, src.r2);
  if (a < 0 || b < 0 || c < 0 || d < 0) return null; return { c1: Math.min(a, b), c2: Math.max(a, b), r1: Math.min(c, d), r2: Math.max(c, d) };
}
// Isi rentang -> daftar pilihan: teks TAMPIL tiap sel (trim), kosong dibuang, kembar (tak peka huruf besar-kecil) dibuang, maks. MAX_ITEMS, tiap pilihan dipotong MAX_ITEM_LEN.
export function itemsFromRange(tab, src, text) {
  const rc = srcRect(tab, src), out = [], seen = new Set(); if (!rc || typeof text !== 'function') return out;
  for (let i = rc.r1; i <= rc.r2 && out.length < MAX_ITEMS; i++) for (let j = rc.c1; j <= rc.c2 && out.length < MAX_ITEMS; j++) {
    let t = ''; try { t = String(text(i, j) == null ? '' : text(i, j)).replace(/\s+/g, ' ').trim(); } catch (_) {} if (!t) continue; if (t.length > MAX_ITEM_LEN) t = t.slice(0, MAX_ITEM_LEN).trim();
    const k = t.toLocaleLowerCase('id'); if (seen.has(k)) continue; seen.add(k); out.push(t);
  }
  return out;
}
// Segarkan `items` semua aturan yang punya `src`. Sumber yang ID-nya hilang DIBUANG (daftar terakhir jadi daftar biasa; kosong = aturan dibuang oleh cleanChecks berikutnya).
// Mengembalikan true bila ada yang berubah. Tab tidak diberi langkah Urungkan (data turunan).
export function refreshSrc(tab, text) {
  let ch = false; if (!tab || !Array.isArray(tab.checks)) return ch;
  for (const ck of tab.checks) {
    if (!ck.src) continue; if (!srcRect(tab, ck.src)) { delete ck.src; ch = true; continue; }
    const now = itemsFromRange(tab, ck.src, text); if (now.length === ck.items.length && now.every((x, i) => x === ck.items[i])) continue;
    ck.items = now; ch = true;
  }
  return ch;
}
// Rev 283 / V6c-3: urut baris memindahkan baris (ID ikut baris), jadi rentang SUMBER dijaga tetap di POSISI (indeks) seperti rentang aturan (Rev 272).
// snap = pinSrc(tab) SEBELUM baris dipindah; unpinSrc(tab, snap) sesudahnya memasang ulang ID batas pada posisi yang sama. Aturan tanpa src dilewati.
export const pinSrc = (tab) => (tab && Array.isArray(tab.checks) ? tab.checks.map((ck) => (ck.src ? srcRect(tab, ck.src) : null)) : null);
export function unpinSrc(tab, snap) {
  if (!snap || !Array.isArray(tab.checks)) return;
  tab.checks.forEach((ck, k) => { const rc = snap[k]; if (rc && ck.src && tab.rows[rc.r1] && tab.rows[rc.r2]) { ck.src.r1 = tab.rows[rc.r1].id; ck.src.r2 = tab.rows[rc.r2].id; } });
}
