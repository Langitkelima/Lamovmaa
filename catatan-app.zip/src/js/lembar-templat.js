// Rev 180, v2 Rev 286 / T1: templat lembar kerja (MURNI). Data di templat-*.js; pemilih di settings.js. Rumus A1 dengan `;` lewat fxFromA1 (ditolak = `failed`).
// Bentuk: { id, name, desc, guide?, tabs? | (tab,w,nfc,head,total,rows,merges,charts,rules,checks) }; akar = tab ke-1, `tabs` = banyak tab (maks. 5 + Panduan).
// rules: [{ c:'D', op, a, b, bg, fg | lo, hi }]; checks: [{ k:'list', rg:'C2:C30', items, cl }] (HURUF kolom, dipetakan ke ID); guide: [[judul, teks]] -> tab Panduan.
import * as L from './lembar.js';
import { fxFromA1 } from './lembar-tampil.js';
import { LAMA } from './templat-lama.js';
import { FITUR } from './templat-fitur.js';
import { RUMUS } from './templat-rumus.js';
import { RUMUS2 } from './templat-rumus-lanjut.js';
import { ADMIN } from './templat-admin.js';
import { ADMIN2 } from './templat-admin-lanjut.js';
import { CENTANG } from './templat-centang.js';

export const TEMPLATE_NF = { rp: { k: 'currency', c: 'IDR', d: 0 }, pct: { k: 'percent', d: 0 }, num: { k: 'number' }, num1: { k: 'number', d: 1 }, date: { k: 'date', p: 'short' } };
const HEAD = { b: true, bg: '#DBEAFE', fg: '#111827' }, TOTAL = { b: true, bg: '#EEF2FF', fg: '#111827' };
const D0 = Date.UTC(1899, 11, 30);
const serialOf = (ms) => { const d = new Date(ms); return Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - D0) / 86400000); };

export const TEMPLATES = [...FITUR, ...RUMUS, ...RUMUS2, ...ADMIN, ...ADMIN2, ...CENTANG, ...LAMA] // urutan pemilih (Rev 293, Rev 305): Fitur, Rumus, Admin, Centang, lalu templat lama;
export const templateList = () => TEMPLATES.map((t) => ({ id: t.id, name: t.name, desc: t.desc }));
export const hasTemplate = (id) => TEMPLATES.some((t) => t.id === id);

function fill(sheet, tab, def, ms) {
  let failed = 0; const cid = (ch) => (tab.cols[ch.charCodeAt(0) - 65] || {}).id;
  const hr = def.head === true ? 0 : Number.isInteger(def.head) ? def.head : -1; // baris judul
  if (def.rows.length > tab.rows.length) L.addRows(tab, def.rows.length - tab.rows.length);
  (def.w || []).forEach((w, j) => { if (tab.cols[j]) L.setColWidth(tab, tab.cols[j].id, w); });
  def.rows.forEach((row, i) => {
    if (!tab.rows[i]) return;
    row.forEach((spec, j) => {
      if (spec === null || spec === undefined || spec === '' || !tab.cols[j]) return;
      let o = spec && typeof spec === 'object' ? spec : { v: spec };
      const patch = {}; let s = {};
      if (i === hr) s = { ...HEAD }; else if (def.total === i || o.t) s = { ...TOTAL };
      if (o.b) s.b = true;
      if (o.s && typeof o.s === 'object') s = { ...s, ...o.s };
      if (o.v && typeof o.v === 'object' && Number.isFinite(o.v.today)) o = { ...o, v: serialOf(ms) + Math.trunc(o.v.today) }; // tanggal contoh = hari ini + n hari
      if (typeof o.v === 'string' && o.v[0] === '=') {
        const fx = fxFromA1(o.v, tab); if (!fx) { failed++; return; } patch.fx = fx;
      } else patch.v = o.v;
      const kind = o.nf || ((i !== hr && (typeof o.v === 'number' || patch.fx)) ? (def.nfc || [])[j] : '');
      if (kind && TEMPLATE_NF[kind]) s.nf = { ...TEMPLATE_NF[kind] };
      if (Object.keys(s).length) patch.s = s;
      L.setCell(tab, tab.rows[i].id, tab.cols[j].id, patch);
    });
  });
  const rl = (def.rules || []).map((r) => ({ ...r, c: cid(r.c) })); L.setRules(tab, rl); failed += rl.length - (tab.rules || []).length;
  const ck = (def.checks || []).map(({ rg, c, ...x }) => {
    const m = rg && /^([A-Z])(\d+):([A-Z])(\d+)$/.exec(rg); if (!m) return { ...x, c: cid(c) };
    return { ...x, c: cid(m[1]), rg: { c2: cid(m[3]), r1: (tab.rows[m[2] - 1] || {}).id, r2: (tab.rows[m[4] - 1] || {}).id } };
  }); L.setChecks(tab, ck); failed += ck.length - (tab.checks || []).length;
  for (const m of def.merges || []) { const r = L.mergeCells(tab, m[0], m[1], m[2], m[3], { clear: true }); if (!r.ok) failed++; } // gabung sel sesudah semua sel terisi
  for (const c of def.charts || []) L.saveChart(tab, { r1: c.r1, c1: c.c1, r2: c.r2, c2: c.c2 }, c.vc, { kind: c.kind, title: c.title, legend: c.legend });
  return failed;
}
function guideTab(sheet, guide) {
  const id = L.addTab(sheet, 'Panduan'); if (!id) return 1; const tab = sheet.tabs.find((t) => t.id === id), lines = [];
  for (const [t, x] of guide) { lines.push([t, 1]); let cur = ''; for (const w of String(x).split(/\s+/)) { if (cur && (cur + ' ' + w).length > 46) { lines.push([cur]); cur = w; } else cur = cur ? cur + ' ' + w : w; } if (cur) lines.push([cur]); lines.push(['']); }
  if (lines.length > tab.rows.length) L.addRows(tab, Math.min(lines.length, L.MAX_ROWS) - tab.rows.length);
  L.setColWidth(tab, tab.cols[0].id, 320); let bad = 0;
  lines.forEach(([v, b], i) => { if (!v) return; if (!tab.rows[i]) { bad = 1; return; } L.setCell(tab, tab.rows[i].id, tab.cols[0].id, { v, ...(b ? { s: { ...HEAD } } : {}) }); });
  return bad;
}

export function buildFromDef(def, { name, now } = {}) {
  const ms = Number.isFinite(now) ? now : Date.now(), specs = def.tabs || [def];
  const sheet = L.newSheet({ name: name || def.name, now }); let failed = 0;
  specs.forEach((sp, k) => {
    const id = k ? L.addTab(sheet, sp.tab || def.name) : sheet.tabs[0].id; if (!id) { failed++; return; }
    L.renameTab(sheet, id, sp.tab || def.name); failed += fill(sheet, sheet.tabs.find((t) => t.id === id), sp, ms);
  });
  if (def.guide) failed += guideTab(sheet, def.guide);
  return L.fitsLimit(sheet) ? { sheet, failed } : null;
}
export function makeFromTemplate(id, o = {}) { const def = TEMPLATES.find((t) => t.id === id); return def ? buildFromDef(def, o) : null; }
