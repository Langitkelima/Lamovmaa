// Rev 412 (S1-S3): layar Sync = satu pintu Cadangkan / Pulihkan (desain B pilihan pengguna). Dimuat MALAS dari settings.js.
// Rev 421 / SY3b: bagian atas layar = status sinkron varian G "Orbit + Jalur" (pilihan pengguna dari pratinjau): lingkaran orbit, judul status, jalur HP - Worker - Laptop, tombol Sinkronkan sekarang, sakelar Otomatis, Keluar.
// Fungsi lama DIPAKAI ULANG tanpa diubah: askExport, pickBackup (settings.js), bukaEksporMd, bukaImporMd (modul malas). Mesin sinkron (`sync-jalan.js`) dimuat MALAS dari sini.
import { h, ico, PATH, tErr, tOk, tWarn, tInfo } from './ui.js';
import { askExport, pickBackup } from './settings.js';
import { sanitize } from './notes.js';
import { syncAllReminders, cancelReminder } from './reminders.js';
import { syncAllNoteAlarms } from './cb-alarm.js';

const eksporMd = (ctx) => import('./ekspor-md-ui.js').then((m) => m.bukaEksporMd(ctx), () => tErr('Ekspor Markdown gagal dibuka.'));
const imporMd = (ctx) => import('./impor-md-ui.js').then((m) => m.bukaImporMd(ctx), () => tErr('Impor Markdown gagal dibuka.'));

export const SYNC_PILIHAN = {
  cadangkan: { judul: 'Cadangkan', sub: 'Pilih isi yang disimpan ke berkas di HP.', semua: ['CADANGKAN SEMUA', 'penuh', 'Catatan, tugas, kebiasaan, label, pengaturan, dan sampah. Untuk pindah HP atau jaga-jaga.'], catatan: ['CATATAN SAJA', 'biasa', 'Satu berkas .md per catatan. Gambar dan tabel ikut; tugas dan pengaturan tidak.'], note: 'Catatan Privat hanya ikut di Cadangkan semua, atau di Catatan saja bila dicentang.' },
  pulihkan: { judul: 'Pulihkan', sub: 'Pilih asal data yang dikembalikan.', semua: ['PULIHKAN SEMUA', 'penuh', 'Dari berkas cadangan (JSON atau ZIP). Data di HP ini diganti isi cadangan.'], catatan: ['CATATAN SAJA', 'biasa', 'Dari berkas .md, .txt, atau ZIP. Masuk sebagai catatan baru; data lama tidak diubah.'], note: 'Impor catatan tidak pernah masuk ke Catatan Privat.' },
};

export function bukaPilihan(ctx, jenis, aksi = {}) {
  const P = SYNC_PILIHAN[jenis]; const A = { cadangkan: [askExport, eksporMd], pulihkan: [pickBackup, imporMd], ...aksi }[jenis];
  const ov = h('div', { class: 'ov dlgov' });
  const opt = (d, fn) => h('button', { type: 'button', class: 'syo', onclick: () => { ov.remove(); fn(ctx); } },
    h('span', { class: 'syt' }, h('b', {}, d[0]), h('i', {}, ' \u00b7 ' + d[1])), h('small', {}, d[2]));
  ov.append(h('div', { class: 'sheet dlg sysheet' }, h('h3', {}, P.judul), h('p', { class: 'sub' }, P.sub),
    opt(P.semua, A[0]), opt(P.catatan, A[1]), h('p', { class: 'cap' }, P.note),
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal'))));
  document.body.append(ov);
}

// ---- Rev 421 / SY3b: status sinkron (varian G).
export const IKON_SY = {
  sync: PATH.refresh, ok: 'M5 12.5l4.5 4.5L19 7.5', tunggu: PATH.clock,
  off: 'M3 3l18 18M8.5 8.5A7 7 0 0 0 5 14a4 4 0 0 0 4 4h8M18 17a4 4 0 0 0-1-7.9A6 6 0 0 0 12 6',
  galat: 'M12 8v5M12 16.5v.01M10.3 4.3L2.8 17.5A2 2 0 0 0 4.5 20.5h15a2 2 0 0 0 1.7-3L13.7 4.3a2 2 0 0 0-3.4 0z',
  belum: 'M7 18a4 4 0 0 1-.5-8A6 6 0 0 1 18 8.5 4.5 4.5 0 0 1 17.5 18z',
  out: 'M9 4H5v16h4M16 8l4 4-4 4M20 12H9',
  hp: 'M9.5 2.5h5A2.5 2.5 0 0 1 17 5v14a2.5 2.5 0 0 1-2.5 2.5h-5A2.5 2.5 0 0 1 7 19V5a2.5 2.5 0 0 1 2.5-2.5zM11 18.5h2',
  laptop: 'M6 5h12a2 2 0 0 1 2 2v9H4V7a2 2 0 0 1 2-2zM2.5 19.5h19',
};
let J = null, jLoading = false, busy = false;

export function lalu(ms, now = Date.now()) {
  const m = Math.max(0, Math.floor((now - ms) / 60000));
  if (m < 1) return 'baru saja';
  if (m < 60) return m + ' menit lalu';
  if (m < 1440) return Math.floor(m / 60) + ' jam lalu';
  return Math.floor(m / 1440) + ' hari lalu';
}
// Judul + keterangan per kode status. Murni (diuji).
export function teksStatus(s, now = Date.now()) {
  const c = s.cfg || {};
  switch (s.kode) {
    case 'belum': return ['Belum masuk', 'Isi alamat Worker dan passcode di layar Kelimaa AI (tab AI) untuk mulai.'];
    case 'jalan': return ['Sedang menyinkronkan', 'Mengirim dan menarik perubahan\u2026'];
    case 'off': return ['Offline', 'Tidak ada internet. Perubahan disimpan dulu dan dikirim saat tersambung.'];
    case 'galat': return ['Gagal sinkron', c.lastErr || 'Sinkron gagal.'];
    case 'tunggu': return ['Menunggu dikirim', s.dirty + ' catatan berubah di HP ini dan belum dikirim.'];
    default: return c.lastOkAt ? ['Tersinkron', 'Terakhir cocok ' + lalu(c.lastOkAt, now) + '. ' + s.notes + ' catatan di HP ini.'] : ['Siap disinkronkan', 'Belum pernah disinkronkan. Ketuk tombol di bawah untuk memulai.'];
  }
}

function afterApply(ctx) {
  return (t) => {
    try { for (const id of t.removed || []) cancelReminder('note', id); syncAllReminders(ctx.data); syncAllNoteAlarms(ctx.data); } catch (_) { /* pengingat tidak boleh menggagalkan sinkron */ }
    ctx.render();
  };
}

function dialogTahan(ctx, held) {
  const ov = h('div', { class: 'ov dlgov' });
  ov.append(h('div', { class: 'sheet dlg' }, h('h3', {}, 'Hapus ' + held.deletes + ' catatan?'),
    h('p', { class: 'sub' }, 'Sinkron akan menghapus ' + held.deletes + ' catatan di server sekaligus. Itu banyak, jadi ditahan dulu. Catatan di HP ini belum diubah.'),
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Tahan'),
      h('button', { type: 'button', class: 'btn red', onclick: () => { ov.remove(); jalan(ctx, true); } }, 'Hapus semua'))));
  document.body.append(ov);
}
function dialogKeluar(ctx) {
  const ov = h('div', { class: 'ov dlgov' });
  ov.append(h('div', { class: 'sheet dlg' }, h('h3', {}, 'Keluar dari sinkron?'),
    h('p', { class: 'sub' }, 'HP ini berhenti terhubung. Catatan di HP dan di server tidak dihapus. Masuk lagi nanti tanpa membuat salinan ganda.'),
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal'),
      h('button', { type: 'button', class: 'btn red', onclick: () => { ov.remove(); J.putusSinkron(); tInfo('HP ini sudah keluar dari sinkron.'); ctx.render(); } }, 'Keluar'))));
  document.body.append(ov);
}

async function jalan(ctx, izinHapusMassal) {
  if (busy || !J) return;
  busy = true; ctx.render();
  let res;
  try { res = await J.jalankanSinkron({ data: ctx.data, persist: () => ctx.persist(), sanitize, afterApply: afterApply(ctx), allowMassDelete: izinHapusMassal === true }); }
  catch (e) { res = { ok: false, msg: 'Sinkron berhenti: ' + String((e && e.message) || e).slice(0, 120) }; }
  busy = false;
  if (res.busy) return ctx.render();
  const nada = res.needConn ? 'info' : J.nadaHasil(res);
  (nada === 'sukses' ? tOk : nada === 'peringatan' ? tWarn : nada === 'info' ? tInfo : tErr)(res.msg);
  ctx.render();
  if (res.held && !izinHapusMassal) dialogTahan(ctx, res.held);
}

function statusG(ctx, s) {
  const [judul, ket] = teksStatus(s), k = s.kode, jl = k === 'jalan';
  const orb = h('div', { class: 'syorb sy-' + k + (jl ? ' jl' : ''), 'aria-hidden': 'true' },
    h('i', { class: 'rg' }), h('i', { class: 'rg' }), h('i', { class: 'rg' }), h('i', { class: 'trk' }), jl ? h('i', { class: 'sat' }) : null,
    h('div', { class: 'core' }, ico(IKON_SY[jl ? 'sync' : k])));
  const nd = (ic, lb, mid) => h('div', { class: 'synd' + (mid ? ' mid' : '') }, ico(ic), h('small', {}, lb), mid && k === 'galat' ? h('span', { class: 'x' }, '!') : null);
  const ln = () => h('div', { class: 'syln' }, h('i'), h('i'), h('i'));
  const rute = h('div', { class: 'syrute sy-' + k + ' ' + k + (jl ? ' jl' : ''), 'aria-hidden': 'true' }, nd(IKON_SY.hp, 'HP'), ln(), nd(IKON_SY.belum, 'WORKER', true), ln(), nd(IKON_SY.laptop, 'LAPTOP'));
  const mati = jl || k === 'belum' || k === 'off';
  return [
    orb,
    h('div', { class: 'sycen sy-' + k, role: 'status', 'aria-live': 'polite' }, h('h3', {}, judul), h('p', {}, ket)),
    rute,
    h('button', { type: 'button', class: 'btn sybtn', disabled: mati ? '' : null, onclick: () => jalan(ctx) }, ico(IKON_SY.sync), jl ? 'Menyinkronkan\u2026' : 'Sinkronkan sekarang'),
  ];
}

function barisPengaturan(ctx, s) {
  const on = s.cfg.auto === true;
  const auto = h('button', { type: 'button', class: 'mzr', role: 'switch', 'aria-checked': on ? 'true' : 'false', onclick: () => { J.setAutoSync(!on); ctx.render(); } },
    h('span', { class: 'si tn-b' }, ico(IKON_SY.sync)),
    h('span', { class: 'mzl' }, h('b', {}, 'Sinkron otomatis'), h('small', {}, on ? 'Aktif: saat app dibuka, setelah menyimpan, dan saat kembali ke app.' : 'Mati. Kamu yang menekan tombol.')),
    h('span', { class: 'am-tg' }));
  const keluar = s.conn ? h('button', { type: 'button', class: 'mzr', onclick: () => dialogKeluar(ctx) },
    h('span', { class: 'si tn-r' }, ico(IKON_SY.out)),
    h('span', { class: 'mzl' }, h('b', {}, 'Keluar dari sinkron'), h('small', {}, 'Catatan di HP dan server tetap ada.')),
    h('span', { class: 'mzc' }, ico(PATH.chev))) : null;
  return h('div', { class: 'mzlist' }, auto, keluar);
}

export function viewSync(ctx) {
  const { ui } = ctx;
  if (!J && !jLoading) {
    jLoading = true;
    import('./sync-jalan.js').then((m) => { J = m; jLoading = false; if (ui.moreView === 'sync') ctx.render(); }, () => { jLoading = false; tErr('Mesin sinkron gagal dibuka.'); });
  }
  const s = J ? J.bacaStatus({ data: ctx.data, busy, online: globalThis.navigator ? globalThis.navigator.onLine !== false : true }) : null;
  const row = (ic, lb, v, jenis) => h('button', { type: 'button', class: 'mzr', onclick: () => bukaPilihan(ctx, jenis) },
    h('span', { class: 'si tn-b' }, ico(ic)), h('span', { class: 'mzl' }, h('b', {}, lb), h('small', {}, v)), h('span', { class: 'mzc' }, ico(PATH.chev)));
  return [
    h('h1', {}, 'SYNC'),
    h('p', { class: 'sub' }, 'Cadangkan & pulihkan data tanpa internet, atau sinkronkan catatan biasa lewat Worker-mu. Catatan Privat tidak pernah ikut sinkron.'),
    ...(s ? [...statusG(ctx, s), barisPengaturan(ctx, s)] : []),
    h('div', { class: 'mzlist' }, row(PATH.up, 'Cadangkan', 'Simpan data ke berkas', 'cadangkan'), row(PATH.down, 'Pulihkan', 'Kembalikan dari berkas', 'pulihkan')),
    h('button', { type: 'button', class: 'btn line', onclick: () => { ui.moreView = 'main'; ctx.render(); } }, 'Kembali'),
  ];
}
