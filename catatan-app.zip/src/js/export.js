// Bagikan satu catatan (Rev 19): bagian MURNI (tanpa DOM, bisa dites di Node).
// Alur: html catatan (sudah disaring sanitize) -> blok -> baris (tata letak) -> halaman -> (digambar di share.js) -> JPEG -> PDF.
// PDF dirakit sendiri tanpa plugin: tiap halaman = satu gambar JPEG penuh. Konsekuensinya teks di PDF tidak bisa diseleksi/disalin.
import { isValidDateISO, formatDateID } from './tanggal.js';
import { isValidTimeHM } from './waktu.js';
import { cleanCountdownTitle, countdownLabel, countdownDateLine, countdownBadge } from './hitung-mundur.js';

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: '\u00a0' };
export function decodeEntities(s) {
  return String(s).replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === '#') {
      const c = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(c) && c > 0 && c < 0x110000 ? String.fromCodePoint(c) : m;
    }
    return Object.prototype.hasOwnProperty.call(ENT, e.toLowerCase()) ? ENT[e.toLowerCase()] : m;
  });
}

// "#abc", "#aabbcc", "rgb(1, 2, 3)" -> "#rrggbb" huruf kecil; selain itu ''.
export function cssColor(v) {
  v = String(v || '').trim().toLowerCase().replace(/;$/, '');
  let m = /^#([0-9a-f]{3})$/.exec(v);
  if (m) return '#' + m[1].split('').map((c) => c + c).join('');
  m = /^#?([0-9a-f]{6})$/.exec(v);
  if (m) return '#' + m[1];
  m = /^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})/.exec(v);
  if (m) return '#' + [m[1], m[2], m[3]].map((x) => Math.min(255, Number(x)).toString(16).padStart(2, '0')).join('');
  return '';
}

function attrsOf(str) {
  const out = {}; const re = /([a-zA-Z][\w-]*)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g; let m;
  while ((m = re.exec(str || ''))) out[m[1].toLowerCase()] = decodeEntities(m[2] ?? m[3] ?? m[4] ?? '');
  return out;
}
// Rev 123 / U7b-2: model ekspor lembar kerja (lembar-pulau.js exportModel) -> blok judul + blok tabel (+ catatan bila dipotong). MURNI.
const SHEET_RUN = { b: false, i: false, s: false, u: false, color: '', fs: 100 };
const sheetPara = (t, o = {}) => ({ kind: 'p', depth: 0, runs: [{ t, ...SHEET_RUN, ...o }] });
// Rev 184c-2 / U10e-3b: tinggi baris bebas -> properti `h` (px grid) pada larik baris tabel (seperti `total`); hanya bila baris punya tinggi khusus. MURNI.
export const withRowH = (row, h) => { if (Number.isFinite(h) && h > 0) row.h = h; return row; };
// Tinggi minimal baris di kertas: px grid x (ukuran huruf / 15 = huruf grid), dibatasi maxPx (baris sangat tinggi tidak boleh melebihi sebagian halaman). Baris tidak pernah lebih pendek dari isinya. MURNI.
export const GRID_FONT = 15, ROW_MAX_FRAC = 0.4;
export function rowMinPx(h, size, pageH) { const n = Number(h); if (!(n > 0)) return 0; const cap = Number(pageH) > 0 ? Math.floor(pageH * ROW_MAX_FRAC) : 600; return Math.min(cap, Math.round(n * (Number(size) || GRID_FONT) / GRID_FONT)); }
export function sheetBlocks(m) {
  if (!m || !Array.isArray(m.rows)) return [sheetPara('Lembar kerja (tidak tersedia)', { i: true })];
  const out = [sheetPara('Lembar kerja: ' + String(m.name || ''), { b: true })];
  if (m.empty || !m.rows.length) { out.push(sheetPara('(lembar kosong)', { i: true })); return out; }
  out.push({ kind: 'table', headerRow: false, headerCol: false, rows: m.rows.map((r, ri) => withRowH(r.map((c) => ({ runs: c.t ? [{ t: c.t, ...SHEET_RUN, b: !!c.b, i: !!c.i }] : [], th: false, a: c.a || '', ...(c.bg ? { bg: c.bg, fg: c.fg } : {}), ...(c.cs > 1 ? { cs: c.cs } : {}), ...(c.cv ? { cv: true } : {}), ...(c.vu ? { vu: true } : {}), ...(c.vd ? { vd: true } : {}) })), m.rowH && m.rowH[ri])) });
  const nc = m.rows[0].length, cut = m.rows.length < m.totalRows || nc < m.totalCols, more = m.tabs > 1;
  if (cut || more) out.push(sheetPara([cut ? '\u2026 menampilkan ' + m.rows.length + ' dari ' + m.totalRows + ' baris dan ' + nc + ' dari ' + m.totalCols + ' kolom' : '', more ? (cut ? '; ' : '') + 'hanya tab "' + m.tab + '" (' + (m.tabs - 1) + ' tab lain tidak disertakan)' : ''].join(''), { i: true }));
  for (const c of Array.isArray(m.charts) ? m.charts : []) if (c && typeof c.svg === 'string' && c.svg.startsWith('<svg') && c.w > 0 && c.h > 0) out.push({ kind: 'chart', svg: c.svg, w: c.w, h: c.h, title: String(c.title || '') }); // Rev 161 / U10c-3b: hanya PDF/JPG (TXT/MD melewati blok ini)
  return out;
}
// HTML catatan -> blok. Blok: { kind: 'p'|'ul'|'ol'|'todo', depth, num?, checked?, blank?, runs: [{t,b,i,s,u,color}] }
export function parseNoteHtml(html, now = new Date(), sheetOf = null) {
  const blocks = []; const stack = []; const lists = [];
  let cur = null, table = null, row = null, cell = null, wrapperDepth = 0, quoteDepth = 0, skipFigure = false, moodSkip = 0, dateSkip = 0, timeSkip = 0, countdownSkip = 0, sheetSkip = 0, lkSkip = 0;
  let divKinds = [], foldOpen = false, inFb = false; // Rev 110 / U6b: tumpukan jenis DIV bagian lipat (BUKAN wrapperDepth)
  const style = () => {
    const o = { b: false, i: false, s: false, u: false, color: '', fs: 100 };
    for (const f of stack) { if (f.b) o.b = true; if (f.i) o.i = true; if (f.s) o.s = true; if (f.u) o.u = true; if (f.color) o.color = f.color; if (f.fs) o.fs = f.fs; }
    return o;
  };
  const open = (kind, extra = {}) => { flush(); cur = { kind, depth: Math.max(0, lists.length - 1), runs: [], ...extra }; };
  const flush = () => {
    if (!cur) return;
    // <br> di ujung blok hanyalah penanda baris kosong dari peramban, bukan baris tambahan.
    const last = cur.runs[cur.runs.length - 1];
    if (last && /\n$/.test(last.t)) last.t = last.t.slice(0, -1);
    cur.runs = cur.runs.filter((r) => r.t !== '');
    if (cur.kind === 'todo') { const f = cur.runs[0]; if (f) f.t = f.t.replace(/^[\s\u00a0]+/, ''); cur.runs = cur.runs.filter((r) => r.t !== ''); }
    const has = cur.runs.some((r) => /\S/.test(r.t));
    if (!has && cur.kind !== 'todo') { cur.blank = true; cur.runs = []; }
    if (inFb && !cur.fold) cur.fi = 1; // isi bagian lipat: menjorok satu tingkat saat diekspor
    blocks.push(cur); cur = null;
  };
  const finishCell = () => {
    if (!table || !cell) return;
    const last = cell.runs[cell.runs.length - 1];
    if (last && /\n+$/.test(last.t)) last.t = last.t.replace(/\n+$/, '');
    cell.runs = cell.runs.filter((r) => r.t !== '');
    if (!row) row = [];
    if (row.total) cell.runs.forEach((r) => { r.b = true; }); // Rev 100 / U4e: baris Total (tr.tt) dicetak tebal di semua format
    row.push(cell); cell = null;
  };
  const cellBreak = () => {
    if (!cell || !cell.runs.length) return;
    const last = cell.runs[cell.runs.length - 1];
    if (!last || !/\n$/.test(last.t)) cell.runs.push({ t: '\n', ...style() });
  };
  const finishRow = () => {
    if (!table || !row) return;
    finishCell(); table.rows.push(row); row = null;
  };
  const finishTable = () => {
    if (!table) return;
    finishCell(); finishRow();
    // Rev 100 / U4e: tabel editor (Rev 33+) menandai judul dengan TH, bukan data-hr/data-hc; baris Total tidak ikut menentukan judul.
    const dr = table.rows.filter((r) => !r.total);
    if (!table.headerRow && dr.length && dr[0].length && dr[0].every((c) => c.th)) table.headerRow = true;
    if (!table.headerCol && dr.length && dr.every((r) => r[0] && r[0].th)) table.headerCol = true;
    if (table.rows.length) blocks.push(table);
    table = null; row = null; cell = null; stack.length = 0;
  };
  const addText = (txt) => {
    if (skipFigure || moodSkip || dateSkip || timeSkip || countdownSkip || sheetSkip || lkSkip || txt === '') return;
    if (cell) { cell.runs.push({ t: txt, ...style() }); return; }
    if (!cur) { if (!/\S/.test(txt)) return; open('p'); } // spasi/newline antar tag di luar blok diabaikan
    cur.runs.push({ t: txt, ...style() });
  };
  const re = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)((?:[^>"]|"[^"]*")*)>|([^<]+)/g; let m;
  const src = String(html || '');
  while ((m = re.exec(src))) {
    if (m[4] !== undefined) { addText(decodeEntities(m[4]).replace(/[\r\n\t]+/g, ' ')); continue; }
    const close = m[1] === '/', tag = m[2].toUpperCase(), at = attrsOf(m[3]);
    if (skipFigure) {
      if (close && tag === 'FIGURE') skipFigure = false;
      continue;
    }
    if (moodSkip) { // Rev C-2: isi blok Suasana hati (wajah, tombol) tidak ikut diekspor
      if (tag === 'DIV') moodSkip += close ? -1 : 1;
      continue;
    }
    if (dateSkip) { if (tag === 'DIV') dateSkip += close ? -1 : 1; continue; }
    if (timeSkip) { if (tag === 'DIV') timeSkip += close ? -1 : 1; continue; }
    if (countdownSkip) { if (tag === 'DIV') countdownSkip += close ? -1 : 1; continue; }
    if (sheetSkip) { if (tag === 'DIV') sheetSkip += close ? -1 : 1; continue; } // Rev 123 / U7b-2
    if (lkSkip) { if (tag === 'DIV') lkSkip += close ? -1 : 1; continue; } // Rev 325 / L4
    if (!close && tag === 'DIV' && /(?:^|\s)lk-card(?:\s|$)/.test(String(at.class || ''))) { // Rev 325 / L4: kartu tautan -> satu baris "Tautan: judul - alamat" (TXT/Markdown/PDF/JPG); alamat tidak sah = kartu dilewati
      flush();
      const lu = String(at['data-u'] || ''), lt = String(at['data-t'] || '').replace(/[\u0000-\u001f\u007f\s]+/g, ' ').trim().slice(0, 140);
      if (/^https?:\/\/[^\s\u0000-\u001f\u007f]{1,1990}$/i.test(lu)) blocks.push({ kind: 'p', depth: 0, runs: [{ t: 'Tautan: ' + (lt ? lt + ' - ' : '') + lu, ...style() }] });
      lkSkip = 1;
      continue;
    }
    if (!close && tag === 'DIV' && /(?:^|\s)ksheet(?:\s|$)/.test(String(at.class || ''))) { // Rev 123 / U7b-2: pulau lembar kerja -> judul + tabel (data dari sumber, BUKAN dari HTML yang hanya punya ID)
      flush();
      let model = null; try { model = typeof sheetOf === 'function' ? sheetOf(String(at['data-sheet'] || '')) : null; } catch (_) { model = null; }
      for (const b of sheetBlocks(model)) blocks.push(b);
      sheetSkip = 1;
      continue;
    }
    if (!close && tag === 'DIV' && /(?:^|\s)mood-block(?:\s|$)/.test(String(at.class || ''))) {
      flush();
      const v = Number(at['data-mood-value']);
      const label = ['Sangat buruk', 'Kurang baik', 'Biasa saja', 'Baik', 'Sangat baik'][Number.isInteger(v) && v >= 0 && v <= 4 ? v : 4];
      const msz = String(at['data-mood-size'] || '');
      // Rev E: teks tetap ada untuk TXT/Markdown; PDF/JPG menggambar kartunya (mood/moodSize) lewat layoutDoc + share.js.
      blocks.push({ kind: 'p', depth: 0, mood: Number.isInteger(v) && v >= 0 && v <= 4 ? v : 4, moodSize: /^(small|normal|large)$/.test(msz) ? msz : 'normal', runs: [{ t: 'Suasana hati: ' + label, ...style(), b: true }] });
      moodSkip = 1;
      continue;
    }
    if (!close && tag === 'DIV' && /(?:^|\s)kb-date-block(?:\s|$)/.test(String(at.class || ''))) {
      flush();
      const raw = String(at['data-kb-date'] || '');
      const label = isValidDateISO(raw) ? formatDateID(raw) : '';
      const dsz = String(at['data-kb-size'] || '');
      blocks.push({ kind: 'p', depth: 0, card: label ? { type: 'date', value: label, size: /^(small|large)$/.test(dsz) ? dsz : 'normal' } : undefined, runs: [{ t: 'Tanggal: ' + label, ...style(), b: true }] });
      dateSkip = 1;
      continue;
    }
    if (!close && tag === 'DIV' && /(?:^|\s)kb-time-block(?:\s|$)/.test(String(at.class || ''))) {
      flush();
      const raw = String(at['data-kb-time'] || '');
      const label = isValidTimeHM(raw) ? raw : '';
      const tsz = String(at['data-kb-size'] || '');
      blocks.push({ kind: 'p', depth: 0, card: label ? { type: 'time', value: label, size: /^(small|large)$/.test(tsz) ? tsz : 'normal' } : undefined, runs: [{ t: 'Waktu: ' + label, ...style(), b: true }] });
      timeSkip = 1;
      continue;
    }
    if (!close && tag === 'DIV' && /(?:^|\s)kb-countdown-block(?:\s|$)/.test(String(at.class || ''))) {
      flush();
      const rawDate = String(at['data-kb-date'] || '');
      const validDate = isValidDateISO(rawDate);
      const dateLabel = validDate ? countdownDateLine(rawDate) : '';
      const rawTime = String(at['data-kb-time'] || '');
      const time = validDate && isValidTimeHM(rawTime) ? ' · ' + rawTime : '';
      const title = cleanCountdownTitle(at['data-kb-title'] || '');
      const remain = validDate ? countdownLabel(rawDate, now) : '';
      const summary = validDate
        ? `Hitung mundur: ${title || 'Tanpa judul'}, ${dateLabel}${time}${remain ? ` (${remain})` : ''}`
        : `Hitung mundur: ${title || 'Tanpa judul'}, tanggal tidak valid`;
      const cdBadge = validDate ? countdownBadge(rawDate) : null;
      blocks.push({ kind: 'p', depth: 0, card: validDate ? { type: 'cd', title, remain, dateLine: dateLabel + time, month: cdBadge.month, day: cdBadge.day, state: remain === 'Hari ini!' ? 'today' : /lalu$/.test(remain) ? 'past' : 'upcoming' } : undefined, runs: [{ t: summary, ...style(), b: true }] });
      countdownSkip = 1;
      continue;
    }
    // Rev 110 / U6b: bagian lipat. Hanya DIV di luar tabel dilacak (tumpukan jenis); judul = blok 'p' bertanda fold.head, isi = blok bertanda fi.
    if (tag === 'DIV' && !table) {
      if (!close) {
        const cl = String(at.class || '').split(/\s+/), top = divKinds[divKinds.length - 1];
        const k = cl.includes('fold') ? 'fold' : cl.includes('fh') && top === 'fold' ? 'fh' : cl.includes('fb') && top === 'fold' ? 'fb' : 'other';
        divKinds.push(k);
        if (k === 'fold') { flush(); foldOpen = at['data-o'] === '1'; continue; }
        if (k === 'fh') { flush(); open('p', { fold: { head: true, open: foldOpen } }); continue; }
        if (k === 'fb') { flush(); inFb = true; continue; }
      } else if (divKinds.length) {
        const k = divKinds.pop();
        if (k === 'fold' || k === 'fh' || k === 'fb') { flush(); if (k === 'fb') inFb = false; if (k === 'fold') foldOpen = false; continue; }
      }
    }
    if (!close) {
      if (tag === 'FIGURE') {
        flush();
        const cls = String(at.class || '').split(/\s+/);
        const id = String(at['data-kimg'] || '');
        const w = Number(at['data-w']), h = Number(at['data-h']);
        if (cls.includes('ki') && /^[a-z0-9]{10,40}$/i.test(id) && Number.isSafeInteger(w) && Number.isSafeInteger(h) && w > 0 && h > 0) {
          blocks.push({ kind: 'image', id, width: w, height: h, scale: /^(?:[2-9][05]|100)$/.test(String(at['data-s'] || '')) ? Number(at['data-s']) : 100, align: /^[lcr]$/.test(String(at['data-a'] || '')) ? String(at['data-a']) : 'c', float: at['data-f'] === '1' });
        }
        skipFigure = true;
      } else if (tag === 'TABLE' && !table) {
        flush();
        table = { kind: 'table', rows: [], headerRow: at['data-hr'] === '1', headerCol: at['data-hc'] === '1', dw: /^\d{1,3}(?:,\d{1,3}){0,7}$/.test(String(at['data-w'] || '')) ? String(at['data-w']).split(',').map(Number) : null }; // Rev 320: lebar kolom (data-w)
        row = null; cell = null; stack.length = 0;
      } else if (table) {
        if (tag === 'TR') { finishRow(); row = []; if (/(?:^|\s)tt(?:\s|$)/.test(String(at.class || ''))) row.total = true; }
        else if (tag === 'TD' || tag === 'TH') { finishCell(); if (!row) row = []; cell = { runs: [], th: tag === 'TH', a: /^[cr]$/.test(String(at['data-a'] || '')) ? at['data-a'] : '' }; }
        else if (tag === 'BR' && cell) cell.runs.push({ t: '\n', ...style() });
        else if (tag === 'B' || tag === 'STRONG') stack.push({ tag: 'B', b: true });
        else if (tag === 'I' || tag === 'EM') stack.push({ tag: 'I', i: true });
        else if (tag === 'S' || tag === 'STRIKE') stack.push({ tag: 'S', s: true });
        else if (tag === 'U') stack.push({ tag: 'U', u: true });
        else if (tag === 'FONT' || tag === 'SPAN') {
          const mc = /(?:^|;)\s*color\s*:\s*([^;]+)/i.exec(at.style || '');
          const mf = /(?:^|;)\s*font-size\s*:\s*(\d{2,3})%/i.exec(at.style || '');
          stack.push({ tag, color: cssColor(at.color) || (mc ? cssColor(mc[1]) : ''), fs: Math.max(70, Math.min(250, Number(at['data-fs'] || (mf && mf[1]) || 100))) });
        }
      } else if (tag === 'DIV' && ['kt', 'kt-scroll'].includes(String(at.class || '').trim())) {
        wrapperDepth++;
      } else if (tag === 'BLOCKQUOTE') { quoteDepth++; open('quote'); }
      else if (tag === 'UL' || tag === 'OL') { flush(); lists.push({ type: tag === 'OL' ? 'ol' : 'ul', n: 0 }); }
      else if (tag === 'LI') { const l = lists[lists.length - 1] || { type: 'ul', n: 0 }; l.n++; open(l.type, { num: l.n }); }
      else if ((tag === 'DIV' || tag === 'P') && quoteDepth > 0) { /* pembungkus internal kutipan */ }
      else if (tag === 'DIV' || tag === 'P') open(/\btodo\b/.test(at.class || '') ? 'todo' : 'p', /\btodo\b/.test(at.class || '') ? { checked: false } : {});
      else if (tag === 'BR') { if (!cur) open('p'); cur.runs.push({ t: '\n', ...style() }); }
      else if (tag === 'INPUT') { if (cur && cur.kind === 'todo' && 'checked' in at) cur.checked = true; else if (!cur) { open('todo', { checked: 'checked' in at }); } }
      else if (tag === 'B' || tag === 'STRONG') stack.push({ tag: 'B', b: true });
      else if (tag === 'I' || tag === 'EM') stack.push({ tag: 'I', i: true });
      else if (tag === 'S' || tag === 'STRIKE') stack.push({ tag: 'S', s: true });
      else if (tag === 'U') stack.push({ tag: 'U', u: true });
      else if (tag === 'FONT' || tag === 'SPAN') {
        const mc = /(?:^|;)\s*color\s*:\s*([^;]+)/i.exec(at.style || '');
        const mf = /(?:^|;)\s*font-size\s*:\s*(\d{2,3})%/i.exec(at.style || '');
          stack.push({ tag, color: cssColor(at.color) || (mc ? cssColor(mc[1]) : ''), fs: Math.max(70, Math.min(250, Number(at['data-fs'] || (mf && mf[1]) || 100))) });
      }
    } else {
      if (tag === 'TABLE' && table) finishTable();
      else if (table) {
        if (tag === 'TD' || tag === 'TH') finishCell();
        else if (tag === 'TR') finishRow();
        else if ((tag === 'DIV' || tag === 'P') && cell) cellBreak();
        else {
          const k = tag === 'STRONG' ? 'B' : tag === 'EM' ? 'I' : tag === 'STRIKE' ? 'S' : tag;
          for (let j = stack.length - 1; j >= 0; j--) if (stack[j].tag === k) { stack.splice(j, 1); break; }
        }
      } else if (tag === 'DIV' && wrapperDepth > 0) wrapperDepth--;
      else if (tag === 'BLOCKQUOTE') { quoteDepth = Math.max(0, quoteDepth - 1); flush(); }
      else if ((tag === 'DIV' || tag === 'P') && quoteDepth > 0) { /* pembungkus internal kutipan */ }
      else if (tag === 'UL' || tag === 'OL') { flush(); lists.pop(); }
      else if (tag === 'LI' || tag === 'DIV' || tag === 'P') flush();
      else {
        const k = tag === 'STRONG' ? 'B' : tag === 'EM' ? 'I' : tag === 'STRIKE' ? 'S' : tag;
        for (let j = stack.length - 1; j >= 0; j--) if (stack[j].tag === k) { stack.splice(j, 1); break; }
      }
    }
  }
  if (table) finishTable();
  flush();
  // Baris kosong berurutan di ujung dibuang.
  while (blocks.length && blocks[blocks.length - 1].blank && !blocks[blocks.length - 1].fold) blocks.pop(); // Rev 110: judul bagian lipat kosong adalah bagian sah, bukan baris kosong
  return blocks;
}
const plain = (b) => (b.runs || []).map((r) => r.t).join('');
// Teks biasa untuk dibagikan: judul, baris kosong, lalu isi dengan penanda poin/centang/nomor.
export function blocksToText(title, blocks) {
  const lines = [];
  for (const b of blocks) {
    if (b.kind === 'table') {
      for (const row of b.rows || []) lines.push(row.map((cell) => plain(cell).replace(/\s*\n\s*/g, ' ')).join(' | '));
      continue;
    }
    if (b.kind === 'chart') continue; // Rev 161: diagram hanya di PDF/JPG
    if (b.kind === 'image') { lines.push('[gambar]'); continue; }
    if (b.fold && b.fold.head) { lines.push('\u25b8 ' + (plain(b).replace(/\s+/g, ' ').trim() || 'Bagian lipat')); continue; } // Rev 110 / U6b
    if (b.blank) { lines.push(''); continue; }
    const fp = b.fi ? '  ' : '', pad = '  '.repeat(b.depth || 0), t = plain(b).replace(/\n/g, '\n' + fp);
    lines.push(fp + (b.kind === 'quote' ? '> ' + t
      : b.kind === 'todo' ? pad + (b.checked ? '\u2611 ' : '\u2610 ') + t
      : b.kind === 'ul' ? pad + '\u2022 ' + t
        : b.kind === 'ol' ? pad + b.num + '. ' + t : t));
  }
  const body = lines.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  const head = String(title || '').trim();
  return head && body ? head + '\n\n' + body : head || body;
}
// Markdown untuk ekspor berkas .md (Rev 59): judul = #, poin = -, nomor = 1., centang = - [ ] / - [x], tabel = tabel pipa.
// Tebal/miring/coret ikut; garis bawah dan warna tidak punya padanan Markdown sehingga dibuang. Gambar jadi penanda [gambar].
const mdEsc = (t) => String(t).replace(/([\\`*_~|])/g, '\\$1');
function mdRuns(b) {
  let out = '';
  for (const r of b.runs || []) {
    const t = String(r.t).replace(/\n/g, '  \n');
    if (!/\S/.test(t)) { out += t; continue; }
    const lead = /^\s*/.exec(t)[0], trail = /\s*$/.exec(t)[0], core = mdEsc(t.slice(lead.length, t.length - trail.length));
    let w = core;
    if (r.s) w = '~~' + w + '~~';
    if (r.b && r.i) w = '***' + w + '***'; else if (r.b) w = '**' + w + '**'; else if (r.i) w = '*' + w + '*';
    out += lead + w + trail;
  }
  return out;
}
export function blocksToMarkdown(title, blocks, opts = null) { // Rev 397: opts.imageUrl(id) -> alamat relatif gambar (ekspor zip); tanpa opts tetap "[gambar]"
  const lines = [], head = String(title || '').trim();
  let prev = '';
  if (head) lines.push('# ' + mdEsc(head), '');
  for (const b of blocks) {
    if (b.kind === 'table') { prev = 'table';
      const rows = (b.rows || []).map((row) => row.map((cell) => mdRuns(cell).replace(/\s*\n\s*/g, ' ').replace(/ {2,}/g, ' ').trim() || ' '));
      if (!rows.length) continue;
      const cols = Math.max(...rows.map((r) => r.length));
      const fix = (r) => '| ' + Array.from({ length: cols }, (_, i) => r[i] || ' ').join(' | ') + ' |';
      lines.push('', fix(rows[0]), '|' + Array(cols).fill(' --- ').join('|') + '|');
      for (const r of rows.slice(1)) lines.push(fix(r));
      lines.push('');
      continue;
    }
    if (b.kind === 'chart') continue; // Rev 161: diagram hanya di PDF/JPG
    if (b.kind === 'image') { const u = opts && typeof opts.imageUrl === 'function' && b.id ? opts.imageUrl(b.id) : ''; lines.push('', u ? '![gambar](' + u + ')' : '[gambar]', ''); prev = 'image'; continue; }
    if (b.fold && b.fold.head) { // Rev 110 / U6b: judul bagian lipat = butir berjudul tebal; isinya bertingkat di bawahnya
      const ht0 = mdRuns({ runs: (b.runs || []).map((r) => ({ ...r, b: false })) }).replace(/\s*\n\s*/g, ' ').trim(), ht = ht0 ? '**' + ht0 + '**' : '';
      if (lines.length && lines[lines.length - 1] !== '') lines.push('');
      lines.push('- ' + (ht || '**Bagian lipat**')); prev = 'fold'; continue;
    }
    if (b.blank) { prev = ''; continue; }
    const fp = b.fi ? '  ' : '', pad = '  '.repeat(b.depth || 0), t = mdRuns(b).replace(/\n/g, '\n' + fp), kk = b.kind + (b.fi ? '~' : '');
    // Markdown menggabungkan baris berurutan jadi satu paragraf: beri baris kosong bila jenis blok berganti atau paragraf bertemu paragraf.
    if (lines.length && lines[lines.length - 1] !== '' && (prev !== kk || b.kind === 'p')) lines.push('');
    prev = kk;
    lines.push(fp + (b.kind === 'quote' ? '> ' + t
      : b.kind === 'todo' ? pad + '- [' + (b.checked ? 'x' : ' ') + '] ' + t
      : b.kind === 'ul' ? pad + '- ' + t
        : b.kind === 'ol' ? pad + b.num + '. ' + t : t));
  }
  return lines.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
}
// Nama berkas aman: huruf kecil, angka, tanda hubung. part (opsional) untuk gambar bagian 2, 3, dst.
export function shareFileName(title, ext, d = new Date(), part = 0) {
  const slug = String(title || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30).replace(/-+$/, '') || 'catatan';
  const p2 = (n) => String(n).padStart(2, '0');
  return slug + '-' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + (part > 0 ? '-' + part : '') + '.' + ext;
}

// ---- Tata letak ----
// o: { width, padX, size, titleSize, measure(text, {b,i,size}) -> px, lhRatio?, gap?, ink? }
// Hasil: daftar baris { lh, size, x, segs:[{t,x,b,i,s,u,color,size}], mark?, kind: 'text'|'blank'|'rule' }
function wrap(runs, maxWIn, size, measure) {
  // maxWIn: angka, atau fungsi (nomorBaris) -> lebar (Rev 49: baris di samping gambar lebih sempit).
  const mw = typeof maxWIn === 'function' ? maxWIn : () => maxWIn;
  let maxW = mw(0);
  const lines = []; let cur = [], x = 0;
  const push = () => {
    while (cur.length && !/\S/.test(cur[cur.length - 1].t)) cur.pop();
    if (cur.length) cur[cur.length - 1].t = cur[cur.length - 1].t.replace(/\s+$/, '');
    lines.push(cur); cur = []; x = 0; maxW = mw(lines.length);
  };
  const add = (t, st, w) => { const runSize = size * (Number(st.fs || 100) / 100); cur.push({ t, x, b: !!st.b, i: !!st.i, s: !!st.s, u: !!st.u, color: st.color || '', size: runSize }); x += w; };
  for (const run of runs) {
    const st = run; const runSize = size * (Number(st.fs || 100) / 100); const m = (t) => measure(t, { b: st.b, i: st.i, size: runSize });
    for (const part of run.t.split(/(\n)/)) {
      if (part === '\n') { push(); continue; }
      for (const tok of part.match(/\s+|\S+/g) || []) {
        const sp = /^\s+$/.test(tok);
        if (sp && x === 0) continue;
        const w = m(tok);
        if (!sp && x > 0 && x + w > maxW) push();
        if (!sp && w > maxW) { // kata terlalu panjang: patahkan per huruf
          let buf = '', bw = 0;
          for (const ch of tok) {
            const cw = m(ch);
            if (bw + cw > maxW - x && buf) { add(buf, st, bw); push(); buf = ''; bw = 0; }
            buf += ch; bw += cw;
          }
          if (buf) add(buf, st, bw);
        } else add(tok, st, w);
      }
    }
  }
  if (cur.length || !lines.length) push();
  return lines;
}

// Rev E: ukuran kartu Suasana hati untuk PDF/JPG. Satu rumus dipakai tata letak (tinggi) dan penggambaran (share.js).
export function moodGeom(size, moodSize, inner) {
  const k = moodSize === 'small' ? 0.85 : moodSize === 'large' ? 1.15 : 1;
  const s = size * k, pad = s * 0.62, labelS = s * 0.4, titleS = s * 0.78, R = s * 0.95;
  const w = moodSize === 'small' ? inner * 0.84 : inner;
  const labelY = pad + labelS, titleY = labelY + s * 0.22 + titleS, faceCy = titleY + s * 0.42 + R * 1.25;
  return { k, s, pad, labelS, titleS, R, w, labelY, titleY, faceCy, h: Math.ceil(faceCy + R * 1.25 + pad * 0.7) };
}
// Rev 89: kartu Tanggal / Waktu / Hitung mundur untuk PDF/JPG (satu rumus untuk tata letak dan penggambaran, seperti moodGeom).
export function cardGeom(size, card, inner) {
  const k = card.size === 'small' ? 0.85 : card.size === 'large' ? 1.2 : 1;
  const s = size * k;
  if (card.type === 'cd') {
    const pad = s * 0.6, bw = s * 2.1, bh = s * 2.45;
    const labelS = s * 0.36, remS = s * 0.95, dateS = s * 0.46;
    const h = Math.ceil(Math.max(bh + pad * 2, pad * 2 + labelS + remS * 1.25 + dateS * 1.6));
    return { s, k, pad, bw, bh, labelS, remS, dateS, w: inner, h };
  }
  const pad = s * 0.5, ic = s * 1.35, labelS = s * 0.34, valS = card.type === 'time' ? s * 0.95 : s * 0.72;
  const h = Math.ceil(Math.max(ic, labelS + valS * 1.3) + pad * 2);
  return { s, k, pad, ic, labelS, valS, w: 0, h };
}
export function layoutDoc({ title, blocks }, o) {
  const lhR = o.lhRatio || 1.45, gap = o.gap == null ? Math.round(o.size * 0.3) : o.gap;
  const inner = o.width - o.padX * 2, step = Math.round(o.size * 1.5);
  const out = [];
  // Rev 49: gambar yang "teks di sampingnya" (data-f=1, rata kiri/kanan, 20-70%) menjadi satu kelompok 'float':
  // gambar + baris teks di sampingnya, satu satuan paginasi. Teks yang melewati tinggi gambar kembali selebar penuh.
  let flt = null;
  const fgap = Math.round(o.size * 0.9);
  const fOpen = () => !!flt && flt.used < flt.h;
  const flushFlt = () => {
    if (!flt) return;
    out.push({ kind: 'float', lh: Math.ceil(Math.max(flt.h, flt.used)) + gap, img: flt.img, lines: flt.lines });
    flt = null;
  };
  const put = (ln) => { if (fOpen()) { flt.lines.push(ln); flt.used += ln.lh; } else { flushFlt(); out.push(ln); } };
  const t = String(title || '').trim();
  if (t) {
    const ls = wrap([{ t: t.toUpperCase(), b: true }], inner, o.titleSize, o.measure);
    for (const l of ls) out.push({ kind: 'text', lh: Math.round(o.titleSize * 1.3), size: o.titleSize, x: o.padX, segs: l.map((s) => ({ ...s, x: s.x + o.padX })) });
    out.push({ kind: 'rule', lh: Math.round(o.size * 1.1), x: o.padX, w: inner });
  }
  for (const b0 of blocks) {
    // Rev 110 / U6b: judul bagian lipat di PDF/JPG = baris tebal berpanah (isi SELALU terbuka); judul kosong memakai teks cadangan.
    const b = b0.fold && b0.fold.head
      ? { ...b0, kind: 'fold', blank: false, runs: (b0.runs && b0.runs.length ? b0.runs : [{ t: 'Bagian lipat', b: false, i: false, s: false, u: false, color: '', fs: 100 }]).map((r) => ({ ...r, b: true })) }
      : b0;
    if (b.kind === 'table') {
      flushFlt();
      const rows = b.rows || [];
      const cols = Math.max(0, ...rows.map((r) => r.length));
      if (!cols) continue;
      const minCell = Math.min(72, inner / cols);
      const weights = Array.from({ length: cols }, (_, ci) => Math.max(minCell, ...rows.map((r, ri) => {
        const c = r[ci]; if (!c || c.cv || c.cs > 1) return minCell; // Rev 153: gabungan melebar tidak memaksa satu kolom melebar
        const head = (b.headerRow && ri === 0) || (b.headerCol && ci === 0) || !!r.total;
        const runs = (c.runs || []).map((x) => ({ ...x, b: !!x.b || head }));
        const natural = runs.reduce((sum, x) => sum + o.measure(x.t, { b: x.b, i: x.i, size: o.size }), 0);
        return Math.min(420, natural + 28);
      })));
      const extra = weights.map((w) => Math.max(0, w - minCell));
      const extraSum = extra.reduce((a, x) => a + x, 0), remain = Math.max(0, inner - minCell * cols);
      let widths = extraSum > 0
        ? extra.map((x) => minCell + remain * x / extraSum)
        : Array(cols).fill(inner / cols);
      if (b.dw && b.dw.some((n) => n > 0)) { // Rev 320 / U3: lebar kolom atur-sendiri = perbandingan px di layar (kolom otomatis dihitung 105 px), diskalakan ke lebar halaman
        const px = Array.from({ length: cols }, (_, ci) => Math.max(56, Math.min(320, b.dw[ci] || 105))), tot = px.reduce((a, x) => a + x, 0);
        widths = px.map((x) => Math.max(minCell, inner * x / tot)); const ws = widths.reduce((a, x) => a + x, 0); widths = widths.map((x) => x * inner / ws);
      }
      const padX = Math.max(7, Math.round(o.size * 0.28)), padY = Math.max(6, Math.round(o.size * 0.22));
      const lineH = Math.round(o.size * lhR);
      for (let ri = 0; ri < rows.length; ri++) {
        const cells = []; let x = 0, maxLines = 1;
        for (let ci = 0; ci < cols; ci++) {
          const source = rows[ri][ci] || { runs: [] };
          if (source.cv) continue; // Rev 153: sel tertutup gabungan melebar (lebarnya sudah masuk jangkar)
          const span = Math.max(1, Math.min(Math.floor(source.cs) || 1, cols - ci)); let cw = 0; for (let k = 0; k < span; k++) cw += widths[ci + k];
          const head = (b.headerRow && ri === 0) || (b.headerCol && ci === 0) || !!rows[ri].total;
          const runs = (source.runs || []).map((r) => ({ ...r, b: !!r.b || head }));
          const cellLines = wrap(runs, Math.max(16, cw - padX * 2), o.size, o.measure);
          maxLines = Math.max(maxLines, cellLines.length);
          cells.push({ x, w: cw, header: head, lines: cellLines, padX, padY, a: source.a || '', ...(source.bg ? { bg: source.bg, fg: source.fg } : {}), ...(source.vu ? { vu: true } : {}), ...(source.vd ? { vd: true } : {}) }); // Rev 155: gabungan tegak
          x += cw;
        }
        const maxCellSize = Math.max(o.size, ...cells.flatMap((c) => c.lines.flatMap((ln) => ln.map((seg) => seg.size || o.size))));
        const actualLineH = Math.round(maxCellSize * lhR);
        const rowH = Math.max(maxLines * actualLineH + padY * 2, rowMinPx(rows[ri].h, o.size, o.pageH)); // Rev 184c-2: tinggi baris bebas (tidak lebih pendek dari isi)
        out.push({ kind: 'tableRow', x: o.padX, w: inner, lh: rowH, lineH: actualLineH, cells, headerRow: !!b.headerRow && ri === 0 });
      }
      out.push({ kind: 'gap', lh: gap, size: o.size, x: o.padX, segs: [] });
      continue;
    }
    if (b.kind === 'chart') { // Rev 161 / U10c-3b: diagram lembar kerja = satu satuan paginasi, rata tengah, 90% lebar isi, tidak melebihi tinggi halaman
      flushFlt();
      const cw = Number.isFinite(b.w) && b.w > 0 ? b.w : 1, ch = Number.isFinite(b.h) && b.h > 0 ? b.h : 1;
      let w = inner * 0.9, h = w * ch / cw;
      const maxH = Math.max(o.size * 2, (o.pageH || 3000) - (o.padTop || 0) - (o.padBottom || 0));
      if (h > maxH) { h = maxH; w = h * cw / ch; }
      h = Math.max(1, Math.ceil(h)); w = Math.max(1, Math.min(inner, w));
      out.push({ kind: 'chart', svg: b.svg, title: b.title || '', x: o.padX + (inner - w) / 2, w, h, lh: h });
      out.push({ kind: 'gap', lh: gap, size: o.size, x: o.padX, segs: [] });
      continue;
    }
    if (b.kind === 'image') {
      flushFlt();
      const iw = Number.isFinite(b.width) && b.width > 0 ? b.width : 1;
      const ih = Number.isFinite(b.height) && b.height > 0 ? b.height : 1;
      const sc = Number.isFinite(b.scale) && b.scale >= 20 && b.scale <= 100 ? b.scale / 100 : 1;
      let w = inner * sc, h = w * ih / iw;
      const maxH = Math.max(o.size * 2, (o.pageH || 3000) - (o.padTop || 0) - (o.padBottom || 0));
      if (h > maxH) { h = maxH; w = h * iw / ih; }
      h = Math.max(1, Math.ceil(h)); w = Math.max(1, Math.min(inner, w));
      const x = b.align === 'l' ? o.padX : b.align === 'r' ? o.padX + (inner - w) : o.padX + (inner - w) / 2;
      const img = { kind: 'image', id: b.id || '', x, w, h, lh: h, sourceWidth: iw, sourceHeight: ih };
      const flow = b.float === true && (b.align === 'l' || b.align === 'r') && sc >= 0.2 && sc <= 0.7 && inner - w - fgap >= o.size * 6;
      if (flow) { flt = { img, side: b.align, shift: w + fgap, h, used: 0, lines: [] }; continue; }
      out.push(img);
      out.push({ kind: 'gap', lh: gap, size: o.size, x: o.padX, segs: [] });
      continue;
    }
    if (b.mood !== undefined) {
      flushFlt();
      const mg = moodGeom(o.size, b.moodSize, inner);
      out.push({ kind: 'mood', x: o.padX, w: mg.w, lh: mg.h, v: b.mood, label: (b.runs[0] && b.runs[0].t || '').replace(/^Suasana hati:\s*/, ''), size: mg.s, msize: b.moodSize });
      out.push({ kind: 'gap', lh: gap, size: o.size, x: o.padX, segs: [] });
      continue;
    }
    if (b.card) {
      flushFlt();
      const cg = cardGeom(o.size, b.card, inner);
      out.push({ kind: 'card', x: o.padX, lh: cg.h, card: b.card, size: cg.s, w: cg.w || 0 });
      out.push({ kind: 'gap', lh: gap, size: o.size, x: o.padX, segs: [] });
      continue;
    }
    if (b.blank) { put({ kind: 'blank', lh: Math.round(o.size * lhR * 0.8), size: o.size, x: o.padX, segs: [] }); continue; }
    const ind = (b.depth || 0) * step + (b.fi ? step : 0);
    const hasMark = b.kind !== 'p';
    const cx = o.padX + ind + (hasMark ? step : 0);
    const label = b.kind === 'ol' ? b.num + '.' : '';
    const full = o.width - o.padX - cx, approx = Math.round(o.size * lhR);
    const narrow = [];
    const widthFor = (i) => { const on = !!flt && flt.used + i * approx < flt.h; narrow[i] = on; return on ? full - flt.shift : full; };
    const ls = wrap(b.runs, flt ? widthFor : full, o.size, o.measure);
    ls.forEach((l, k) => {
      const beside = !!flt && narrow[k] === true;
      const sh = beside && flt.side === 'l' ? flt.shift : 0;
      const lineSize = Math.max(o.size, ...l.map((x) => x.size || o.size));
      const ln = { kind: 'text', lh: Math.round(lineSize * lhR), size: lineSize, x: cx + sh, segs: l.map((s) => ({ ...s, x: s.x + cx + sh })) };
      if (k === 0 && hasMark) ln.mark = { type: b.kind === 'todo' ? 'todo' : b.kind === 'ol' ? 'num' : b.kind === 'quote' ? 'quote' : b.kind === 'fold' ? 'fold' : 'bullet', x: o.padX + ind + sh, label, checked: !!b.checked };
      if (beside) { flt.lines.push(ln); flt.used += ln.lh; } else { flushFlt(); out.push(ln); }
    });
    put({ kind: 'gap', lh: gap, size: o.size, x: cx, segs: [] });
  }
  flushFlt();
  while (out.length && (out[out.length - 1].kind === 'gap' || out[out.length - 1].kind === 'blank')) out.pop();
  return out;
}
// Bagi baris ke halaman. pageH = tinggi halaman penuh; area isi = pageH - padTop - padBottom. Tiap baris utuh (tidak terpotong).
// Baris kosong/jarak di puncak halaman dibuang. Selalu mengembalikan minimal 1 halaman.
// Rev 177: gabungan TEGAK yang terbelah di pergantian halaman: baris terakhir halaman kehilangan penanda vd dan baris pertama halaman berikutnya kehilangan vu
// (salinan baris, baris asli tidak diubah), jadi penggambar (share.js) menutup tepi bawah/atas di batas halaman. Tanpa gabungan tegak: tidak ada yang berubah.
const cutEdge = (l, key) => (l && l.kind === 'tableRow' && Array.isArray(l.cells) && l.cells.some((c) => c && c[key]) ? { ...l, cells: l.cells.map((c) => { if (!c || !c[key]) return c; const d = { ...c }; delete d[key]; return d; }) } : l);
export function paginate(lines, { pageH, padTop, padBottom }) {
  const room = pageH - padTop - padBottom;
  const pages = []; let cur = { lines: [], used: 0 };
  const spacer = (l) => l.kind === 'gap' || l.kind === 'blank';
  const close = () => { // jarak kosong di ujung halaman dibuang
    while (cur.lines.length && spacer(cur.lines[cur.lines.length - 1])) cur.used -= cur.lines.pop().lh;
    if (cur.lines.length) cur.lines[cur.lines.length - 1] = cutEdge(cur.lines[cur.lines.length - 1], 'vd'); // Rev 177
    pages.push(cur); cur = { lines: [], used: 0 };
  };
  for (const l of lines) {
    if (cur.used + l.lh > room && cur.lines.length) close();
    if (!cur.lines.length && spacer(l)) continue;
    cur.lines.push(!cur.lines.length && pages.length ? cutEdge(l, 'vu') : l); cur.used += l.lh; // Rev 177: baris pertama halaman lanjutan
  }
  close();
  return pages;
}

// ---- base64 <-> byte (tanpa Buffer, jalan di WebView) ----
export function bytesToB64(bytes) {
  let s = ''; const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  return btoa(s);
}
export function b64ToBytes(b64) {
  const s = atob(b64); const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

// ---- PDF ----
// pages: [{ jpeg: Uint8Array, w, h }] (w,h = piksel gambar). Ukuran halaman PDF = pageW x pageH poin (bawaan A4).
export function buildPdf(pages, { title = '', pageW = 595.28, pageH = 841.89 } = {}) {
  if (!pages.length) throw new Error('PDF tanpa halaman');
  const enc = new TextEncoder(); const chunks = []; let len = 0; const offs = [];
  const put = (x) => { const b = typeof x === 'string' ? enc.encode(x) : x; chunks.push(b); len += b.length; };
  const obj = (n, body) => { offs[n] = len; put(n + ' 0 obj\n'); put(body); put('\nendobj\n'); };
  const N = pages.length, f = (x) => x.toFixed(2);
  put('%PDF-1.4\n'); put(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]));
  // 1 katalog, 2 daftar halaman, 3 info; tiap halaman i memakai 4+3i (halaman), 5+3i (isi), 6+3i (gambar)
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, '<< /Type /Pages /Count ' + N + ' /Kids [' + pages.map((_, i) => (4 + 3 * i) + ' 0 R').join(' ') + '] >>');
  const ts = '\ufeff' + String(title).slice(0, 80); let hex = ''; // UTF-16BE: string JS sudah berupa unit UTF-16
  for (let k = 0; k < ts.length; k++) hex += ts.charCodeAt(k).toString(16).padStart(4, '0');
  obj(3, '<< /Title <' + hex + '> /Producer (Notes Kelimaa) >>');
  pages.forEach((p, i) => {
    const pg = 4 + 3 * i, ct = pg + 1, im = pg + 2;
    obj(pg, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + f(pageW) + ' ' + f(pageH) + '] /Resources << /XObject << /Im0 ' + im + ' 0 R >> >> /Contents ' + ct + ' 0 R >>');
    const draw = 'q ' + f(pageW) + ' 0 0 ' + f(pageH) + ' 0 0 cm /Im0 Do Q';
    obj(ct, '<< /Length ' + draw.length + ' >>\nstream\n' + draw + '\nendstream');
    offs[im] = len;
    put(im + ' 0 obj\n<< /Type /XObject /Subtype /Image /Width ' + p.w + ' /Height ' + p.h + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + p.jpeg.length + ' >>\nstream\n');
    put(p.jpeg); put('\nendstream\nendobj\n');
  });
  const total = 4 + 3 * N, xr = len;
  put('xref\n0 ' + total + '\n0000000000 65535 f \n');
  for (let n = 1; n < total; n++) put(String(offs[n]).padStart(10, '0') + ' 00000 n \n');
  put('trailer\n<< /Size ' + total + ' /Root 1 0 R /Info 3 0 R >>\nstartxref\n' + xr + '\n%%EOF\n');
  const out = new Uint8Array(len); let o = 0;
  for (const c of chunks) { out.set(c, o); o += c.length; }
  return out;
}
