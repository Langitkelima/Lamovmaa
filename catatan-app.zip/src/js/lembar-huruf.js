// Rev 298: UBAH HURUF sel lembar kerja = UPPERCASE / lowercase / Title Case / Sentence case, dipakai tombol "Aa" di sebelah Tebal pada bilah format.
// MURNI: tanpa DOM, penyimpanan, native, eval, dan tanpa mengimpor mesin rumus (isi rumus dibaca lewat hasFx saja).
// Aturan bersama (sama seperti replaceAll di lembar-alat.js): hanya sel TEKS yang diubah; sel berumus TIDAK pernah ditimpa diam-diam (dihitung dan dilaporkan);
// angka dan benar/salah dilewati; perubahan lewat setCell supaya batas ukuran dan aturan sel tetap satu pintu. Hasil selalu laporan {...} agar UI bisa memberi tahu pengguna.
import { setCell } from './lembar.js';
import { hasFx } from './lembar-tampil.js';

export const CASE_MODES = ['upper', 'lower', 'title', 'sentence'];
export const CASE_LABELS = { upper: 'UPPERCASE', lower: 'lowercase', title: 'Title Case', sentence: 'Sentence case' };
export const CASE_HINTS = { upper: 'Semua huruf besar', lower: 'Semua huruf kecil', title: 'Tiap kata diawali huruf besar', sentence: 'Hanya awal kalimat yang besar' };

// Kata = rangkaian huruf/angka; apostrof di tengah kata ikut kata (don't -> Don't, bukan Don'T). Tanda hubung memisahkan kata (seperti PROPER di Excel: e-mail -> E-Mail).
const WORD = /[\p{L}\p{N}]+(?:['’]\p{L}+)*/gu;
// Awal kalimat: awal teks (boleh didahului tanda baca/spasi), sesudah . ! ? … (+ penutup kutip/kurung) lalu spasi, dan awal baris baru.
const SENT = /(^[^\p{L}\p{N}\n]*|[.!?…]+["'”’)\]]*\s+|\n[^\p{L}\p{N}\n]*)(\p{L})/gu;

export function caseText(s, mode) {
  if (typeof s !== 'string' || s === '') return s;
  if (mode === 'upper') return s.toUpperCase();
  if (mode === 'lower') return s.toLowerCase();
  if (mode === 'title') return s.toLowerCase().replace(WORD, (w) => w.replace(/^./u, (c) => c.toUpperCase()));
  if (mode === 'sentence') return s.toLowerCase().replace(SENT, (m, a, b) => a + b.toUpperCase());
  return s;
}

const clampRect = (tab, rect) => {
  const nr = tab.rows.length, nc = tab.cols.length;
  const r1 = rect ? Math.max(0, rect.r1) : 0, r2 = rect ? Math.min(nr - 1, rect.r2) : nr - 1, c1 = rect ? Math.max(0, rect.c1) : 0, c2 = rect ? Math.min(nc - 1, rect.c2) : nc - 1;
  return { r1, r2, c1, c2 };
};

// changeCase(tab, mode, rect?) -> { cells, text, skippedFormula }
//   cells = sel yang benar-benar berubah; text = sel teks yang diperiksa; skippedFormula = sel berumus yang dilewati. rect kosong = seluruh tab.
export function changeCase(tab, mode, rect) {
  const res = { cells: 0, text: 0, skippedFormula: 0 };
  if (!tab || !Array.isArray(tab.rows) || !Array.isArray(tab.cols) || !CASE_MODES.includes(mode)) return res;
  const q = clampRect(tab, rect);
  for (let i = q.r1; i <= q.r2; i++) for (let j = q.c1; j <= q.c2; j++) {
    const cell = tab.rows[i].cells[tab.cols[j].id]; if (!cell) continue;
    if (hasFx(cell)) { res.skippedFormula++; continue; }
    if (typeof cell.v !== 'string') continue;
    res.text++;
    const out = caseText(cell.v, mode); if (out === cell.v) continue;
    if (setCell(tab, tab.rows[i].id, tab.cols[j].id, { v: out })) res.cells++;
  }
  return res;
}

// caseInfo(tab, rect?, limit?) -> { sample, text, same }  (hanya BACA; murah, berhenti di `limit` sel teks)
//   sample = teks sel teks pertama (untuk pratinjau di menu) atau null; text = jumlah sel teks yang dipindai;
//   same[mode] = true bila SEMUA sel teks yang dipindai sudah berbentuk mode itu (untuk menandai pilihan yang sedang berlaku).
export function caseInfo(tab, rect, limit = 3000) {
  const info = { sample: null, text: 0, same: { upper: false, lower: false, title: false, sentence: false } };
  if (!tab || !Array.isArray(tab.rows) || !Array.isArray(tab.cols)) return info;
  const q = clampRect(tab, rect), ok = { upper: true, lower: true, title: true, sentence: true };
  scan: for (let i = q.r1; i <= q.r2; i++) for (let j = q.c1; j <= q.c2; j++) {
    const cell = tab.rows[i].cells[tab.cols[j].id]; if (!cell || hasFx(cell) || typeof cell.v !== 'string') continue;
    if (info.sample === null) info.sample = cell.v;
    info.text++;
    for (const m of CASE_MODES) if (ok[m] && caseText(cell.v, m) !== cell.v) ok[m] = false;
    if (info.text >= limit) break scan;
  }
  if (info.text) for (const m of CASE_MODES) info.same[m] = ok[m];
  return info;
}

// Pesan untuk toast (Bahasa Indonesia).
export function caseMessage(res, mode) {
  const lb = CASE_LABELS[mode] || '', fx = res && res.skippedFormula ? ' · ' + res.skippedFormula + ' sel rumus dilewati' : '';
  if (!res || !res.text) return 'Tidak ada sel teks yang bisa diubah' + fx + '.';
  if (!res.cells) return 'Sudah berbentuk ' + lb + fx + '.';
  return 'Diubah ke ' + lb + ': ' + res.cells + ' sel' + fx;
}
