/** Utilitas waktu lokal untuk blok Waktu Notes Kelimaa. */
export function localTimeHM(date = new Date()) {
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
}

export function isValidTimeHM(value) {
  return typeof value === 'string' && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
}

export function formatTimeID(value) {
  return isValidTimeHM(value) ? value : '';
}
