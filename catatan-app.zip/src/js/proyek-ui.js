// Rev 248: tampilan dirombak (judul KAPITAL, kartu keterangan terbaca, kartu proyek berprogres, cincin kemajuan di detail). Logika dan batas TIDAK berubah.
// Rev 235 / Tahap 7b: tampilan Project Studio (daftar proyek, detail, tautkan tugas dan catatan, kemajuan).
// Dimuat MALAS oleh settings.js (import() dinamis), jadi tidak menambah byte saat aplikasi dibuka. Belum terhubung ke AI (itu 7c).
// Tidak pernah mengubah tugas atau catatan: hanya membaca judul dan status selesai. Catatan Privat tidak pernah muncul.
import { h, ico, PATH, toast, dlg, infoKey, tWarn, tErr, tOk } from './ui.js';
import { newId } from './logic.js';
import { MAX_PROJECTS, MAX_NAME, MAX_DESC, MAX_LINKS, STATUSES } from './proyek.js';
import { newProject, addProject, removeProject, toggleProjectLink, projectProgress } from './proyek-alat.js';

const STATUS_LABEL = { aktif: 'Aktif', selesai: 'Selesai', arsip: 'Arsip' };
const SCOPE_LABEL = { hari: 'Fokus', minggu: 'Target', bulan: 'Rencana' };
const TONES = ['v', 't', 'b', 'i', 'o', 'r'];
const p2 = (n) => String(n).padStart(2, '0');
const isoOf = (ts) => { if (!ts) return ''; const d = new Date(ts); return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); };
const tsOf = (iso) => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); if (!m) return 0; const t = new Date(+m[1], +m[2] - 1, +m[3]).getTime(); return Number.isFinite(t) && t > 0 ? t : 0; };
const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const tglID = (ts) => { const d = new Date(ts); return Number.isFinite(d.getTime()) ? d.getDate() + ' ' + BULAN[d.getMonth()] + ' ' + d.getFullYear() : ''; };
const isLate = (p) => p.status === 'aktif' && !!p.due && p.due + 86400000 <= Date.now();
const noteTitle = (n) => (n && typeof n.title === 'string' && n.title.trim()) || 'Tanpa judul';
const bar = (pct, label) => h('div', { class: 'pjbar', role: 'img', 'aria-label': label }, h('i', { style: 'width:' + pct + '%' }));

export function viewProyek(ctx) {
  const { ui } = ctx;
  if (!Array.isArray(ctx.data.projects)) ctx.data.projects = [];
  const cur = ui.projectId ? ctx.data.projects.find((x) => x.id === ui.projectId) : null;
  if (ui.projectId && !cur) ui.projectId = ''; // proyek sudah dihapus
  return cur ? viewDetail(ctx, cur) : viewList(ctx);
}

// Nama proyek selalu HURUF KAPITAL: papan ketik langsung kapital (autocapitalize) dan teks dipaksa kapital sambil mengetik, kursor tidak loncat.
function capsInput(inp) {
  inp.setAttribute('autocapitalize', 'characters');
  inp.addEventListener('input', () => {
    const v = inp.value, u = v.toUpperCase();
    if (v === u) return;
    const a = inp.selectionStart, b = inp.selectionEnd;
    inp.value = u;
    try { inp.setSelectionRange(a, b); } catch (e) { /* abaikan */ }
  });
  return inp;
}

function viewList(ctx) {
  const { data, ui } = ctx; const all = data.projects;
  const flt = STATUSES.includes(ui.pjFilter) ? ui.pjFilter : 'aktif';
  const count = (s) => all.filter((p) => p.status === s).length;
  const shown = all.filter((p) => p.status === flt);
  const create = () => {
    if (all.length >= MAX_PROJECTS) { infoKey('maks', 'proyek', MAX_PROJECTS, 'Hapus proyek yang sudah selesai, lalu buat lagi.'); return; }
    const ov = h('div', { class: 'ov dlgov' });
    const inp = h('input', { class: 'in', maxlength: String(MAX_NAME), placeholder: 'Nama proyek, mis. Renovasi dapur', 'aria-label': 'Nama proyek', enterkeyhint: 'done' });
    capsInput(inp);
    const save = () => {
      const p = newProject(inp.value.toUpperCase(), newId); if (!p) { tWarn('Nama proyek tidak boleh kosong.'); return; }
      if (!addProject(all, p)) { tErr('Proyek gagal ditambahkan.'); return; }
      ov.remove(); ui.pjFilter = 'aktif'; ui.projectId = p.id; ctx.persist(); ctx.render();
    };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); save(); } });
    ov.append(h('div', { class: 'sheet dlg pjdlgx' }, h('h3', {}, 'Proyek baru'), inp,
      h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal'), h('button', { type: 'button', class: 'btn', onclick: save }, 'Buat'))));
    document.body.append(ov); setTimeout(() => inp.focus(), 50);
  };
  const card = (p, i) => {
    const pr = projectProgress(data, p), tone = TONES[i % TONES.length], late = isLate(p);
    return h('button', { type: 'button', class: 'pjc tn-' + tone, onclick: () => { ui.projectId = p.id; ctx.render(); } },
      h('span', { class: 'pji' }, ico(PATH.proyek)),
      h('span', { class: 'pjt' },
        h('span', { class: 'pjtop' }, h('span', { class: 'pjn' }, p.name), pr.total ? h('span', { class: 'pjpct' }, pr.pct + '%') : null),
        pr.total ? bar(pr.pct, pr.pct + '% tugas selesai') : h('span', { class: 'pjnone' }, 'Belum ada tugas'),
        h('span', { class: 'pjm' }, pr.total ? h('span', { class: 'pjp' }, pr.done + '/' + pr.total + ' tugas') : null, h('span', { class: 'pjp' }, p.notes.length + ' catatan'), p.due ? h('span', { class: 'pjp' + (late ? ' late' : '') }, (late ? 'Lewat tenggat ' : 'Tenggat ') + tglID(p.due)) : null)),
      h('span', { class: 'pjgo' }, ico(PATH.chev)));
  };
  const seg = h('div', { class: 'pjseg', role: 'group', 'aria-label': 'Filter status' }, STATUSES.map((s) => h('button', { type: 'button', class: s === flt ? 'on' : '', 'data-s': s, 'aria-pressed': String(s === flt), onclick: () => { ui.pjFilter = s; ctx.render(); } }, STATUS_LABEL[s] + ' ' + count(s))));
  const empty = h('div', { class: 'empty pjem' }, h('span', { class: 'pjemi' }, ico(PATH.star)), h('span', {}, all.length ? 'Tidak ada proyek berstatus ' + STATUS_LABEL[flt].toLowerCase() + '.' : 'Belum ada proyek.'));
  return [h('div', { class: 'pjset' },
    h('h1', {}, 'PROYEK'),
    h('div', { class: 'pjintro' }, h('span', { class: 'pjii' }, ico(PATH.proyek)),
      h('div', { class: 'pjit' }, h('p', { class: 'pjlead' }, 'Kumpulkan tugas dan catatan yang berkaitan dalam satu proyek, lalu pantau kemajuannya.'), h('p', { class: 'pjnote' }, 'Menautkan tidak mengubah atau menyalin tugas dan catatanmu.'))),
    seg,
    shown.length ? h('div', { class: 'pjcards' }, shown.map(card)) : empty,
    h('button', { type: 'button', class: 'btn', onclick: create }, '+ Proyek baru'),
    h('button', { type: 'button', class: 'btn line', onclick: () => { ui.moreView = 'main'; ctx.render(); } }, 'Kembali'))];
}

function viewDetail(ctx, p) {
  const { data, ui } = ctx;
  const tasks = (data.tasks || []).filter((t) => t && p.tasks.includes(t.id)), notes = (data.notes || []).filter((n) => n && p.notes.includes(n.id));
  const pr = projectProgress(data, p);
  const commit = (fn) => { fn(); ctx.persist(); };
  const nm = h('input', { class: 'in pjname', maxlength: String(MAX_NAME), value: p.name, 'aria-label': 'Nama proyek' });
  capsInput(nm);
  nm.addEventListener('change', () => { const v = nm.value.trim().toUpperCase().slice(0, MAX_NAME); if (!v) { nm.value = p.name; tWarn('Nama proyek tidak boleh kosong.'); return; } commit(() => { p.name = v; }); });
  const ds = h('textarea', { class: 'in pjds', maxlength: String(MAX_DESC), rows: '3', placeholder: 'Deskripsi singkat (opsional)', 'aria-label': 'Deskripsi proyek' }); ds.value = p.desc;
  ds.addEventListener('change', () => commit(() => { p.desc = ds.value.trim().slice(0, MAX_DESC); }));
  const due = h('input', { class: 'in pjdue', type: 'date', value: isoOf(p.due), 'aria-label': 'Tenggat proyek' });
  due.addEventListener('change', () => { const t = tsOf(due.value); commit(() => { if (t) p.due = t; else delete p.due; }); });
  const seg = h('div', { class: 'pjseg', role: 'group', 'aria-label': 'Status proyek' }, STATUSES.map((s) => h('button', { type: 'button', class: s === p.status ? 'on' : '', 'data-s': s, 'aria-pressed': String(s === p.status), onclick: () => { commit(() => { p.status = s; }); ctx.render(); } }, STATUS_LABEL[s])));
  const unlink = (kind, id) => { commit(() => toggleProjectLink(p, kind, id)); ctx.render(); };
  const row = (kind, id, text, sub, done) => h('div', { class: 'pjr' + (done ? ' done' : '') },
    kind === 'tasks' ? h('span', { class: 'pjk', 'aria-hidden': 'true' }, done ? ico(PATH.tugas) : null) : h('span', { class: 'pjk n', 'aria-hidden': 'true' }, ico(PATH.catatan)),
    h('span', { class: 'pjrt' }, h('b', {}, text), sub ? h('small', {}, sub) : null),
    h('button', { type: 'button', class: 'pjx', 'aria-label': 'Lepas tautan ' + text, onclick: () => unlink(kind, id) }, '\u00d7'));
  const pick = (kind) => {
    const linked = new Set(p[kind]), chosen = new Set();
    const pool = kind === 'tasks' ? (data.tasks || []).filter((t) => t && !linked.has(t.id)) : (data.notes || []).filter((n) => n && !linked.has(n.id));
    const room = MAX_LINKS - p[kind].length;
    if (!pool.length) { toast(kind === 'tasks' ? 'Semua tugas sudah tertaut, atau belum ada tugas.' : 'Semua catatan sudah tertaut, atau belum ada catatan.'); return; }
    if (room <= 0) { infoKey('maks', 'tautan', MAX_LINKS, 'Hapus tautan yang tidak dipakai.'); return; }
    const ov = h('div', { class: 'ov dlgov' }), okBtn = h('button', { type: 'button', class: 'btn' }, 'Tautkan');
    const refresh = () => { okBtn.textContent = chosen.size ? 'Tautkan ' + chosen.size : 'Tautkan'; okBtn.disabled = !chosen.size; };
    const items = pool.slice(0, 200).map((x) => { const b = h('button', { type: 'button', class: 'pjo', 'aria-pressed': 'false' }, h('span', { class: 'pjk', 'aria-hidden': 'true' }),
      h('span', { class: 'pjrt' }, h('b', {}, kind === 'tasks' ? String(x.title || 'Tanpa judul') : noteTitle(x)), kind === 'tasks' && SCOPE_LABEL[x.scope] ? h('small', {}, SCOPE_LABEL[x.scope] + (x.done ? ' \u00b7 selesai' : '')) : null));
      b.addEventListener('click', () => { if (chosen.has(x.id)) chosen.delete(x.id); else { if (chosen.size >= room) { infoKey('maks', 'tautan di proyek ini', MAX_LINKS, 'Hapus tautan yang tidak dipakai.'); return; } chosen.add(x.id); } const on = chosen.has(x.id); b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); refresh(); });
      return b; });
    okBtn.addEventListener('click', () => { chosen.forEach((id) => toggleProjectLink(p, kind, id)); ov.remove(); ctx.persist(); ctx.render(); toast(chosen.size + (kind === 'tasks' ? ' tugas' : ' catatan') + ' ditautkan.'); });
    refresh();
    ov.append(h('div', { class: 'sheet dlg pjdlg pjdlgx' }, h('h3', {}, kind === 'tasks' ? 'Tautkan tugas' : 'Tautkan catatan'), h('div', { class: 'pjopts' }, items),
      h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal'), okBtn)));
    document.body.append(ov);
  };
  const sec = (title, n, kind, items, emptyText, addText) => h('section', { class: 'pjsec' }, h('div', { class: 'pjsh' }, h('h2', {}, title + ' (' + n + ')'), h('button', { type: 'button', class: 'pjadd', onclick: () => pick(kind) }, addText)), n ? h('div', { class: 'pjlist' }, items) : h('p', { class: 'pjempty' }, emptyText));
  const del = () => dlg({ title: 'Hapus proyek?', msg: '"' + p.name + '" akan dihapus. Tugas dan catatan yang tertaut TIDAK ikut terhapus.', yes: 'Hapus', red: true, reverse: true, ok: () => {
    const idx = data.projects.findIndex((x) => x.id === p.id), copy = JSON.parse(JSON.stringify(p));
    removeProject(data.projects, p.id); ui.projectId = ''; ctx.persist(); ctx.render();
    tOk('Proyek dihapus.', () => { if (!data.projects.some((x) => x.id === copy.id)) { data.projects.splice(Math.min(idx, data.projects.length), 0, copy); ctx.persist(); ctx.render(); } });
  } });
  return [h('div', { class: 'pjset pjdet' },
    h('h1', {}, 'PROYEK'),
    h('div', { class: 'pjcard' }, nm, ds),
    h('div', { class: 'pjhero' },
      h('div', { class: 'pjring', style: '--p:' + (pr.total ? pr.pct : 0), role: 'img', 'aria-label': pr.total ? pr.pct + '% tugas selesai' : 'Belum ada kemajuan' }, h('b', {}, pr.total ? pr.pct + '%' : '\u2014')),
      h('div', { class: 'pjhs' }, h('strong', {}, pr.total ? pr.done + ' dari ' + pr.total + ' tugas selesai' : 'Belum ada kemajuan'), h('span', {}, pr.total ? (p.due ? (isLate(p) ? 'Lewat tenggat ' : 'Tenggat ') + tglID(p.due) : 'Tanpa tenggat') : 'Tautkan tugas untuk melihat kemajuan'))),
    h('div', { class: 'pjcard' }, h('div', { class: 'pjlab' }, 'Status'), seg, h('div', { class: 'pjlab' }, 'Tenggat (opsional)'), due),
    sec('Tugas', tasks.length, 'tasks', tasks.map((t) => row('tasks', t.id, String(t.title || 'Tanpa judul'), SCOPE_LABEL[t.scope] || '', t.done === true)), 'Belum ada tugas tertaut.', '+ Tautkan tugas'),
    sec('Catatan', notes.length, 'notes', notes.map((n) => row('notes', n.id, noteTitle(n), '', false)), 'Belum ada catatan tertaut.', '+ Tautkan catatan'),
    h('button', { type: 'button', class: 'btn red', onclick: del }, 'Hapus proyek'),
    h('button', { type: 'button', class: 'btn line', onclick: () => { ui.projectId = ''; ctx.render(); } }, 'Kembali ke daftar'))];
}
