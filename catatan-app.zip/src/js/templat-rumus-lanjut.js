// Rev 289 / T4: kelompok templat "Rumus" bagian 2 (data murni, tanpa impor): Logika dan syarat, Teks, Tanggal, Cari data. Bentuk: lihat lembar-templat.js.
// Teks rumus yang dipamerkan = rumus hidup tanpa "=" (D-T2), dibuat otomatis oleh `demo`.
const RED = { bg: '#FEE2E2', fg: '#991B1B' }, GRN = { bg: '#DCFCE7', fg: '#166534' };
const HD = { b: true, s: { bg: '#DBEAFE', fg: '#111827' } };
const demo = (nama, fx, guna, isi, nf) => [nama, ...(isi === undefined ? [] : [isi]), nf ? { v: fx, nf } : fx, fx.slice(1), guna];
const dt = (n) => ({ v: n, nf: 'date' });

// ---- Logika dan syarat: data di A:C (+ Status per baris di D), contoh di F:I
const ORG = [['Ani', 'Toko', 500000], ['Budi', 'Gudang', 300000], ['Cici', 'Toko', 700000], ['Dedi', 'Gudang', 200000], ['Eka', 'Toko', 400000], ['Fajar', 'Kantor', 600000], ['Gita', 'Kantor', 350000], ['Hadi', 'Toko', 250000]];
const LG = [
  demo('JIKA (IF)', '=IF(C2>=400000;"Target";"Belum")', 'Kalau syarat benar jawab A, kalau tidak jawab B.'),
  demo('DAN (AND)', '=IF(AND(B2="Toko";C2>=400000);"Bonus";"-")', 'Semua syarat harus benar.'),
  demo('ATAU (OR)', '=IF(OR(B3="Gudang";B3="Kantor");"Non-toko";"Toko")', 'Cukup salah satu syarat yang benar.'),
  demo('BUKAN (NOT)', '=IF(NOT(B2="Toko");"Bukan toko";"Toko")', 'Membalik syarat: benar jadi salah.'),
  demo('Jaga galat (IFERROR)', '=IFERROR(C2/0;"Tidak bisa dibagi")', 'Kalau rumus galat, tampilkan jawaban lain.'),
  demo('Jumlah bersyarat (SUMIF)', '=SUMIF(B2:B9;"Toko";C2:C9)', 'Jumlahkan hanya baris yang cocok.'),
  demo('Cacah bersyarat (COUNTIF)', '=COUNTIF(C2:C9;">=400000")', 'Hitung banyak baris yang cocok.'),
  demo('Rata-rata bersyarat (AVERAGEIF)', '=AVERAGEIF(B2:B9;"Toko";C2:C9)', 'Rata-rata hanya baris yang cocok.'),
  demo('Jumlah dua syarat (SUMIFS)', '=SUMIFS(C2:C9;B2:B9;"Toko";C2:C9;">=400000")', 'Jumlah dengan beberapa syarat sekaligus.'),
  demo('Cacah dua syarat (COUNTIFS)', '=COUNTIFS(B2:B9;"Toko";C2:C9;">=400000")', 'Hitung dengan beberapa syarat sekaligus.'),
];
const LOGIKA = {
  id: 'rumus-logika', name: 'Rumus · Logika dan syarat', desc: 'JIKA, DAN, ATAU, dan jumlah/cacah bersyarat dari data penjualan kecil.',
  tab: 'Logika', w: [80, 80, 90, 80, 24, 220, 130, 280, 290], head: true, nfc: ['', '', 'num', '', '', '', 'num', '', ''],
  rows: [
    ['Nama', 'Bagian', 'Penjualan', 'Status', '', 'Ukuran', 'Hasil', 'Rumus', 'Gunanya'],
    ...ORG.map((o, i) => [...o, '=IF(C' + (i + 2) + '>=400000;"Target";"Belum")', '', ...(LG[i] ? [LG[i][0], LG[i][1], LG[i][2], LG[i][3]] : [])]),
    ['', '', '', '', '', ...LG[8]],
    ['', '', '', '', '', ...LG[9]],
  ],
  rules: [{ c: 'D', op: 'eq', a: 'Target', ...GRN }, { c: 'D', op: 'eq', a: 'Belum', ...RED }],
  guide: [
    ['Apa ini?', 'Contoh rumus bersyarat: memilih jawaban atau menjumlah hanya baris yang cocok.'],
    ['Kolom Status', 'Tiap baris pakai IF: penjualan 400.000 ke atas = Target (hijau), sisanya Belum (merah).'],
    ['Cara memakai', 'Ganti angka Penjualan atau nama Bagian. Semua hasil di kanan ikut berubah.'],
    ['Teks dalam rumus', 'Teks ditulis dalam tanda kutip, mis. "Toko". Syarat angka juga dikutip, mis. ">=400000".'],
    ['Rumus', 'Kolom Rumus hanya teks contoh. Di selmu sendiri ketik tanda = lalu rumusnya.'],
  ],
};

// ---- Teks: Fungsi | Isi A | Isi B | Hasil | Rumus | Gunanya
const TK = [
  ['Gabung (CONCAT)', 'Budi', 'Santoso', '=CONCAT(B2;" ";C2)', 'Menyambung beberapa teks jadi satu.'],
  ['Gabung dengan &', 'Budi', 'Santoso', '=B3&", "&C3', 'Tanda & juga menyambung teks, lebih singkat.'],
  ['Ambil kiri (LEFT)', 'Surat Masuk', 5, '=LEFT(B4;C4)', 'Ambil B huruf dari kiri.'],
  ['Ambil kanan (RIGHT)', 'INV-2026-015', 3, '=RIGHT(B5;C5)', 'Ambil B huruf dari kanan, mis. nomor urut.'],
  ['Ambil tengah (MID)', 'INV-2026-015', 5, '=MID(B6;C6;4)', 'Ambil 4 huruf mulai posisi B (posisi 1 = huruf pertama).'],
  ['Panjang teks (LEN)', 'Notes Kelimaa', '', '=LEN(B7)', 'Banyak karakter, spasi ikut dihitung.'],
  ['Huruf besar (UPPER)', 'budi santoso', '', '=UPPER(B8)', 'Semua huruf jadi kapital.'],
  ['Huruf kecil (LOWER)', 'ANI WULANDARI', '', '=LOWER(B9)', 'Semua huruf jadi kecil.'],
  ['Rapikan spasi (TRIM)', '  Cici   Permata  ', '', '=TRIM(B10)', 'Buang spasi di ujung dan spasi ganda.'],
  ['Teks jadi angka (VALUE)', '1250', '', '=VALUE(B11)', 'Teks berisi angka diubah agar bisa dihitung.'],
  ['Kapital di awal', 'budi', '', '=UPPER(LEFT(B12;1))&LOWER(MID(B12;2;LEN(B12)))', 'Gabungan: huruf pertama besar, sisanya kecil.'],
  ['Inisial', 'Budi', 'Santoso', '=UPPER(LEFT(B13;1)&LEFT(C13;1))', 'Huruf pertama dua nama, mis. untuk kode.'],
];
const TEKS = {
  id: 'rumus-teks', name: 'Rumus · Teks', desc: 'Menyambung, memotong, dan merapikan teks: nama, kode, dan nomor surat.',
  tab: 'Teks', w: [160, 120, 90, 150, 330, 330], head: true, nfc: ['', '', '', '', '', ''],
  rows: [['Fungsi', 'Isi A', 'Isi B', 'Hasil', 'Rumus', 'Gunanya'], ...TK.map(([n, a, b, fx, g]) => [n, a, b, fx, fx.slice(1), g])],
  guide: [
    ['Apa ini?', 'Contoh rumus teks yang sering dipakai untuk merapikan nama, kode, dan nomor.'],
    ['Cara memakai', 'Ganti teks di kolom Isi A dan Isi B. Kolom Hasil langsung ikut berubah.'],
    ['Teks dalam rumus', 'Teks tetap ditulis dalam tanda kutip, mis. " " untuk satu spasi.'],
    ['Posisi huruf', 'Posisi dihitung dari 1. Spasi dan tanda baca juga dihitung sebagai huruf.'],
    ['Rumus', 'Kolom Rumus hanya teks contoh. Di selmu sendiri ketik tanda = lalu rumusnya.'],
  ],
};

// ---- Tanggal: Fungsi | Isi A | Isi B | Hasil | Rumus | Gunanya (tanggal contoh tetap: 14 Nov 2026, 5 Jan 2027, lahir 20 Mei 2000)
const TG = [
  ['Hari ini (TODAY)', '', '', '=TODAY()', 'Tanggal hari ini; berubah sendiri tiap hari.', 'date'],
  ['Sekarang (NOW)', '', '', '=NOW()', 'Tanggal dan jam saat ini.', 'date'],
  ['Buat tanggal (DATE)', 2026, 12, '=DATE(B4;C4;25)', 'Merangkai tahun, bulan, tanggal jadi satu tanggal.', 'date'],
  ['Tahun (YEAR)', dt(46340), '', '=YEAR(B5)', 'Ambil tahunnya saja.'],
  ['Bulan (MONTH)', dt(46340), '', '=MONTH(B6)', 'Ambil bulannya (1 sampai 12).'],
  ['Tanggal (DAY)', dt(46340), '', '=DAY(B7)', 'Ambil tanggalnya (1 sampai 31).'],
  ['Jam (HOUR)', 0.75, '', '=HOUR(B8)', 'Jam dari waktu; 0,75 = pukul 18.00 (sehari = 1).'],
  ['Menit (MINUTE)', 0.5104167, '', '=MINUTE(B9)', 'Menit dari waktu; 0,5104167 = pukul 12.15.'],
  ['Nomor hari (WEEKDAY)', dt(46340), '', '=WEEKDAY(B10;2)', 'Senin = 1 sampai Minggu = 7 (14 Nov 2026 = Sabtu).'],
  ['Selisih hari (DATEDIF)', dt(46340), dt(46392), '=DATEDIF(B11;C11;"D")', 'Jumlah hari antara dua tanggal, mis. sisa waktu.'],
  ['Umur tahun (DATEDIF)', dt(36666), dt(46340), '=DATEDIF(B12;C12;"Y")', 'Selisih dalam tahun penuh, mis. umur.'],
  ['Sisa bulan (DATEDIF)', dt(36666), dt(46340), '=DATEDIF(B13;C13;"YM")', 'Bulan di luar tahun penuh (umur: sekian bulan).'],
  ['Umur sekarang', dt(36666), '', '=DATEDIF(B14;TODAY();"Y")', 'Umur yang selalu mengikuti hari ini.'],
  ['Jatuh tempo +30 hari', dt(46340), '', '=B15+30', 'Tanggal ditambah angka = maju sekian hari.', 'date'],
  ['Teks jadi tanggal', '14/11/2026', '', '=DATEVALUE(B16)', 'Teks hari/bulan/tahun jadi tanggal yang bisa dihitung.', 'date'],
  ['Tanggal jadi teks (TEXT)', dt(46340), '', '=TEXT(B17;"dd mmmm yyyy")', 'Tanggal ditulis dengan format sendiri.'],
];
const TANGGAL = {
  id: 'rumus-tanggal', name: 'Rumus · Tanggal', desc: 'Umur, selisih hari, jatuh tempo, nomor hari, dan tanggal jadi teks.',
  tab: 'Tanggal', w: [170, 110, 110, 130, 260, 330], head: true, nfc: ['', '', '', '', '', ''],
  rows: [['Fungsi', 'Isi A', 'Isi B', 'Hasil', 'Rumus', 'Gunanya'], ...TG.map(([n, a, b, fx, g, nf]) => [n, a, b, nf ? { v: fx, nf } : fx, fx.slice(1), g])],
  guide: [
    ['Apa ini?', 'Contoh rumus tanggal yang sering dipakai: umur, jatuh tempo, dan sisa hari.'],
    ['Cara memakai', 'Ganti tanggal di kolom Isi A dan Isi B. Kolom Hasil ikut berubah.'],
    ['Tanggal itu angka', 'Tanggal disimpan sebagai nomor urut hari, jadi bisa dijumlah dan dikurangi.'],
    ['Baris yang berubah sendiri', 'Hari ini, Sekarang, dan Umur sekarang mengikuti tanggal HP, jadi hasilnya berbeda tiap hari.'],
    ['Rumus', 'Kolom Rumus hanya teks contoh. Di selmu sendiri ketik tanda = lalu rumusnya.'],
  ],
};

// ---- Cari data: tabel harga (A1:C6), tabel nilai (A8:B13), tabel target (A15:D16); contoh di E:I
const CR = [
  ['Cari nama (VLOOKUP)', 'K03', '=VLOOKUP(F2;$A$2:$C$6;2;0)', 'Cari kode di kolom pertama, ambil kolom ke-2.'],
  ['Cari harga (VLOOKUP)', 'K02', '=VLOOKUP(F3;$A$2:$C$6;3;0)', 'Sama, ambil kolom ke-3. Angka 0 = harus persis sama.'],
  ['Kalau tidak ada', 'K09', '=IFERROR(VLOOKUP(F4;$A$2:$C$6;3;0);"Tidak ada")', 'Kode tidak ketemu: tampilkan jawaban sendiri.'],
  ['Ambil urutan (INDEX)', 3, '=INDEX(C2:C6;F5)', 'Ambil isi baris ke-3 dari daftar harga.'],
  ['Cari urutan (MATCH)', 'K04', '=MATCH(F6;A2:A6;0)', 'Baris ke berapa K04 berada di daftar kode.'],
  ['Cari ke kiri (INDEX+MATCH)', 'Buku', '=INDEX(C2:C6;MATCH(F7;B2:B6;0))', 'Cari lewat nama barang, ambil harganya.'],
  ['Nilai jadi huruf (VLOOKUP)', 78, '=VLOOKUP(F8;$A$9:$B$13;2;1)', 'Angka 1 = ambil batas terdekat di bawahnya.'],
  ['Cari mendatar (HLOOKUP)', 'Q2', '=HLOOKUP(F9;$A$15:$D$16;2;0)', 'Cari di baris atas, ambil baris ke-2.'],
];
const cr = (i) => [CR[i][0], CR[i][1], CR[i][2], CR[i][2].slice(1), CR[i][3]];
const CARI = {
  id: 'rumus-cari', name: 'Rumus · Cari data', desc: 'Cari harga atau nilai huruf dari tabel: VLOOKUP, HLOOKUP, INDEX, dan MATCH.',
  tab: 'Cari data', w: [70, 100, 80, 24, 190, 90, 110, 330, 330], head: true, nfc: ['', '', 'num', '', '', '', 'num', '', ''],
  rows: [
    ['Kode', 'Barang', 'Harga', '', 'Contoh', 'Isian', 'Hasil', 'Rumus', 'Gunanya'],
    ...[['K01', 'Pensil', 3000], ['K02', 'Buku', 12000], ['K03', 'Pulpen', 5000], ['K04', 'Penghapus', 2000], ['K05', 'Map', 7000]].map((r, i) => [...r, '', ...cr(i)]),
    ['', '', '', '', ...cr(5)],
    [{ v: 'Batas', ...HD }, { v: 'Huruf', ...HD }, '', '', ...cr(6)],
    [0, 'E', '', '', ...cr(7)], [60, 'D'],
    [70, 'C'], [80, 'B'], [90, 'A'], [],
    [{ v: 'Kuartal', ...HD }, { v: 'Q1', ...HD }, { v: 'Q2', ...HD }, { v: 'Q3', ...HD }],
    ['Target', 100, 150, 200],
  ],
  guide: [
    ['Apa ini?', 'Tiga tabel kecil (harga, nilai huruf, target) dan contoh mencari isinya dengan rumus.'],
    ['Cara memakai', 'Ganti kolom Isian (mis. kode K03) dan lihat Hasil ikut berubah.'],
    ['Persis atau terdekat', 'Angka 0 di akhir VLOOKUP = harus persis sama. Angka 1 = ambil batas terdekat di bawahnya (tabel harus urut naik).'],
    ['INDEX dan MATCH', 'MATCH mencari baris ke berapa, INDEX mengambil isi baris itu. Berdua bisa mencari ke arah kiri.'],
    ['Rumus', 'Kolom Rumus hanya teks contoh. Di selmu sendiri ketik tanda = lalu rumusnya.'],
  ],
};

export const RUMUS2 = [LOGIKA, TEKS, TANGGAL, CARI];
