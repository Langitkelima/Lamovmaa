// Rev 287 / T2: kelompok templat "Fitur" (data murni, tanpa impor): contoh tiap fitur lembar kerja + tab Panduan. Bentuk: lihat lembar-templat.js.
const RED = { bg: '#FEE2E2', fg: '#991B1B' }, GRN = { bg: '#DCFCE7', fg: '#166534' }, YEL = { bg: '#FEF9C3', fg: '#854D0E' };
const day = (n) => ({ v: { today: n }, nf: 'date' });
const CAT = ['Makan', 'Transport', 'Belanja', 'Hiburan', 'Tagihan'];
const sumif = (r, k) => '=SUMIF($C$2:$C$41;G' + r + ';$' + k + '$2:$' + k + '$41)';

const TUR = {
  id: 'fitur-tur', name: 'Fitur · Tur lengkap', desc: 'Satu lembar yang memakai semua fitur: seri, dropdown, warna, rumus, diagram.',
  tabs: [{
    tab: 'Data', w: [44, 90, 110, 110, 90, 24, 110, 110], head: true, total: 5, nfc: ['num', '', '', 'rp', '', '', '', 'rp'],
    rows: [
      ['No', 'Tanggal', 'Kategori', 'Jumlah', 'Status', '', 'Kategori', 'Total'],
      [1, day(-9), 'Makan', 45000, 'Lunas', '', 'Makan', sumif(2, 'D').replace('$C$2:$C$41', '$C$2:$C$30').replace('$D$2:$D$41', '$D$2:$D$30')],
      [2, day(-8), 'Transport', 20000, 'Lunas', '', 'Transport', sumif(3, 'D').replace('$C$2:$C$41', '$C$2:$C$30').replace('$D$2:$D$41', '$D$2:$D$30')],
      [3, day(-7), 'Belanja', 150000, 'Belum', '', 'Belanja', sumif(4, 'D').replace('$C$2:$C$41', '$C$2:$C$30').replace('$D$2:$D$41', '$D$2:$D$30')],
      [4, day(-6), 'Hiburan', 60000, 'Lunas', '', 'Hiburan', sumif(5, 'D').replace('$C$2:$C$41', '$C$2:$C$30').replace('$D$2:$D$41', '$D$2:$D$30')],
      [5, day(-5), 'Makan', 38000, 'Lunas', '', { v: 'Total', t: true }, { v: '=SUM(H2:H5)', t: true }],
      [6, day(-4), 'Transport', 25000, 'Belum'],
      [7, day(-3), 'Belanja', 210000, 'Lunas'],
      [8, day(-2), 'Hiburan', 75000, 'Belum'],
      [9, day(-1), 'Makan', 42000, 'Lunas'],
      [10, day(0), 'Transport', 30000, 'Lunas'],
    ],
    rules: [{ c: 'D', op: 'gte', a: 150000, ...RED }, { c: 'D', op: 'between', a: 50000, b: 149999, ...YEL }, { c: 'H', op: 'scale', lo: '#FFFFFF', hi: '#93C5FD' }],
    checks: [{ k: 'list', rg: 'C2:C30', items: ['Makan', 'Transport', 'Belanja', 'Hiburan', 'Tagihan'] }, { k: 'list', rg: 'E2:E30', items: ['Lunas', 'Belum'], cl: { Lunas: GRN, Belum: RED } }],
    charts: [{ kind: 'column', title: 'Total per kategori', r1: 0, c1: 6, r2: 4, c2: 7, vc: 7 }, { kind: 'donut', title: 'Porsi kategori', r1: 0, c1: 6, r2: 4, c2: 7, vc: 7 }],
  }],
  guide: [
    ['Apa ini?', 'Contoh pengeluaran kecil yang memakai semua fitur lembar kerja. Ganti isinya, fiturnya tetap jalan.'],
    ['Isi seri (kolom No)', 'Ketuk sel No terakhir, buka Lainnya > Isi seri, pilih Ke bawah. Angka, tanggal, dan nama hari ikut bertambah.'],
    ['Dropdown (Kategori, Status)', 'Ketuk sel lalu pilih dari daftar. Ubah daftarnya lewat Lainnya > Validasi data.'],
    ['Warna bersyarat (Jumlah, Total)', 'Jumlah besar jadi merah, sedang kuning, Total berskala biru. Atur lewat Lainnya > Warna bersyarat.'],
    ['Rumus (kolom Total)', 'SUMIF menjumlahkan Jumlah per kategori. Ubah angka di Jumlah dan Total ikut berubah sendiri.'],
    ['Diagram', 'Kolom dan donat dari tabel Total. Lihat atau tambah lewat Lainnya > Diagram.'],
    ['Filter', 'Lainnya > Filter baris, mis. Status sama dengan Belum. Filter hanya sementara dan tidak mengubah data.'],
  ],
};

const WARNA = {
  id: 'fitur-warna', name: 'Fitur · Warna bersyarat', desc: 'Sel berganti warna sendiri menurut nilainya: merah, kuning, hijau, dan skala.',
  tab: 'Warna', w: [120, 80, 100, 80, 100], head: true, nfc: ['', 'num', 'pct', 'num', ''],
  rows: [
    ['Nama', 'Nilai', 'Kehadiran', 'Stok', 'Status'],
    ['Ani', 92, 1, 12, 'Lunas'], ['Budi', 58, 0.6, 3, 'Belum'], ['Cici', 75, 0.85, 0, 'Lunas'], ['Dedi', 40, 0.5, 5, 'Belum'],
    ['Eka', 88, 0.95, 20, 'Lunas'], ['Fajar', 67, 0.7, 1, 'Belum'], ['Gita', 100, 1, 8, 'Lunas'], ['Hadi', 55, 0.65, 0, 'Belum'],
  ],
  rules: [
    { c: 'B', op: 'lt', a: 60, ...RED }, { c: 'B', op: 'gte', a: 85, ...GRN }, { c: 'C', op: 'scale', lo: '#FFFFFF', hi: '#86EFAC' },
    { c: 'D', op: 'eq', a: 0, ...RED }, { c: 'D', op: 'between', a: 1, b: 5, ...YEL }, { c: 'E', op: 'eq', a: 'Lunas', ...GRN }, { c: 'E', op: 'eq', a: 'Belum', ...RED },
  ],
  guide: [
    ['Apa ini?', 'Warna sel mengikuti isinya, jadi data yang bermasalah langsung kelihatan tanpa dicari.'],
    ['Yang dipakai di sini', 'Nilai: kurang dari 60 merah, 85 ke atas hijau. Kehadiran: skala putih ke hijau. Stok: 0 merah, 1 sampai 5 kuning. Status: teks Lunas hijau, Belum merah.'],
    ['Mengubah atau menambah', 'Lainnya > Warna bersyarat. Satu aturan berlaku untuk satu kolom, maksimal 10 aturan per tab.'],
    ['Perlu diingat', 'Aturan paling atas yang cocok yang menang. Warna hanya tampilan, isi sel tidak berubah. Warna sel yang kamu beri manual tetap menang.'],
  ],
};

const DROP = {
  id: 'fitur-dropdown', name: 'Fitur · Dropdown status', desc: 'Pilih status dan prioritas dari daftar berwarna; tanggal, email, dan angka diperiksa.',
  tab: 'Tugas', w: [170, 100, 90, 90, 160, 100], head: true, nfc: ['', '', '', '', '', 'rp'],
  rows: [
    ['Tugas', 'Status', 'Prioritas', 'Tenggat', 'Email penanggung jawab', 'Biaya'],
    ['Siapkan laporan', 'Dikerjakan', 'Tinggi', day(3), 'ani@contoh.com', 250000], ['Pesan konsumsi rapat', 'Belum', 'Sedang', day(5), 'budi@contoh.com', 400000],
    ['Cetak undangan', 'Selesai', 'Rendah', day(-2), 'cici@contoh.com', 150000], ['Booking ruangan', 'Selesai', 'Tinggi', day(-4), 'dedi@contoh.com', 0],
    ['Hubungi pembicara', 'Dikerjakan', 'Sedang', day(2), 'eka@contoh.com', 0], ['Siapkan materi', 'Belum', 'Rendah', day(9), 'fajar@contoh.com', 75000],
  ],
  checks: [
    { k: 'list', rg: 'B2:B30', items: ['Belum', 'Dikerjakan', 'Selesai'], cl: { Belum: { bg: '#FEE2E2', fg: '#991B1B' }, Dikerjakan: { bg: '#FEF9C3', fg: '#854D0E' }, Selesai: { bg: '#DCFCE7', fg: '#166534' } } },
    { k: 'list', rg: 'C2:C30', items: ['Tinggi', 'Sedang', 'Rendah'], cl: { Tinggi: { bg: '#FEE2E2', fg: '#991B1B' }, Sedang: { bg: '#FEF9C3', fg: '#854D0E' }, Rendah: { bg: '#DBEAFE', fg: '#1E40AF' } } },
    { k: 'date', op: 'ok', rg: 'D2:D30' }, { k: 'email', rg: 'E2:E30' }, { k: 'num', op: 'ge', a: 0, rg: 'F2:F30' },
  ],
  guide: [
    ['Apa ini?', 'Isian yang dipilih dari daftar, jadi tidak ada salah ketik dan statusnya seragam.'],
    ['Cara pakai', 'Ketuk sel Status atau Prioritas, lalu pilih satu dari daftar. Tiap pilihan punya warna sendiri.'],
    ['Pemeriksaan lain', 'Tenggat harus tanggal yang valid, Email harus berbentuk email, Biaya tidak boleh minus. Isi yang tidak sah ditandai.'],
    ['Mengubah daftar atau warna', 'Lainnya > Validasi data. Daftar maksimal 20 pilihan, tiap pilihan bisa diberi warna.'],
  ],
};

const DIAG = {
  id: 'fitur-diagram', name: 'Fitur · Diagram', desc: 'Contoh diagram kolom, batang, dan donat dari tiga tabel kecil.',
  tab: 'Diagram', w: [90, 100, 24, 110, 100, 24, 110, 90], head: true, nfc: ['', 'rp', '', '', 'rp', '', '', 'pct'],
  rows: [
    ['Bulan', 'Penjualan', '', 'Produk', 'Terjual', '', 'Kategori', 'Porsi'],
    ['Jan', 12000000, '', 'Kopi', 8500000, '', 'Minuman', 0.45], ['Feb', 15500000, '', 'Teh', 4200000, '', 'Makanan', 0.35],
    ['Mar', 14000000, '', 'Roti', 6100000, '', 'Camilan', 0.15], ['Apr', 18200000, '', 'Kue', 3900000, '', 'Lainnya', 0.05],
    ['Mei', 17000000, '', { v: 'Total', t: true }, { v: '=SUM(E2:E5)', t: true }, '', { v: 'Total', t: true }, { v: '=SUM(H2:H5)', t: true }],
    ['Jun', 21000000],
  ],
  charts: [
    { kind: 'column', title: 'Penjualan per bulan', r1: 0, c1: 0, r2: 6, c2: 1, vc: 1 }, { kind: 'bar', title: 'Terjual per produk', r1: 0, c1: 3, r2: 4, c2: 4, vc: 4 },
    { kind: 'donut', title: 'Porsi kategori', r1: 0, c1: 6, r2: 4, c2: 7, vc: 7 },
  ],
  guide: [
    ['Apa ini?', 'Tiga jenis diagram dari tabel kecil: kolom (naik turun), batang (urutan), donat (porsi).'],
    ['Cara membuat sendiri', 'Ketuk satu sel di tabelmu, buka Lainnya > Diagram, pilih jenis, lalu Simpan. Kolom pertama jadi label, kolom di kanannya jadi angka.'],
    ['Perlu diingat', 'Satu diagram memakai satu kolom angka. Diagram ikut berubah saat angkanya kamu ganti. Maksimal 6 diagram per tab.'],
  ],
};

const rowsFilter = [['No', 'Tanggal', 'Kategori', 'Keterangan', 'Jumlah', 'Status', '', 'Ringkasan', 'Nilai']];
for (let i = 1; i <= 40; i++) rowsFilter.push([i, day(i - 40), CAT[(i - 1) % 5], CAT[(i - 1) % 5] + ' #' + i, ((i * 37) % 19 + 1) * 10000, i % 8 === 0 ? '' : i % 3 === 0 ? 'Belum' : 'Lunas']);
rowsFilter[1].push('', 'Total jumlah', '=SUM(E2:E41)'); rowsFilter[2].push('', 'Jumlah baris', '=COUNTA(C2:C41)'); rowsFilter[3].push('', 'Belum lunas', '=COUNTIF(F2:F41;"Belum")');
const FILTER = {
  id: 'fitur-filter', name: 'Fitur · Filter dan isi seri', desc: 'Empat puluh baris contoh untuk berlatih menyaring, mengurutkan, dan mengisi seri.',
  tab: 'Data', w: [44, 90, 100, 130, 90, 80, 24, 110, 100], head: true, nfc: ['num', '', '', '', 'rp', '', '', '', 'rp'], rows: rowsFilter,
  rules: [{ c: 'E', op: 'gte', a: 150000, ...YEL }],
  checks: [{ k: 'list', rg: 'C2:C41', items: CAT }, { k: 'list', rg: 'F2:F41', items: ['Lunas', 'Belum'], cl: { Lunas: GRN, Belum: RED } }],
  guide: [
    ['Apa ini?', 'Data contoh untuk mencoba filter, urut, dan isi seri tanpa takut merusak data aslimu.'],
    ['Filter baris', 'Lainnya > Filter baris. Coba Kategori sama dengan Makan, Jumlah lebih dari 100000, atau Status kosong. Hanya menyembunyikan baris, data dan rumus tetap utuh, dan hilang saat lembar ditutup.'],
    ['Isi seri', 'Ketuk sel No baris terakhir, buka Lainnya > Isi seri, pilih Ke bawah dan jumlah baris. Angka dan tanggal ikut bertambah.'],
    ['Urutkan', 'Ketuk satu sel di kolom Jumlah, lalu Lainnya > A→Z atau Z→A. Seluruh baris ikut berpindah.'],
    ['Cari dan ganti', 'Lainnya > Cari dan ganti, mis. ganti Belum jadi Lunas di seluruh tab.'],
  ],
};

export const FITUR = [TUR, WARNA, DROP, DIAG, FILTER];
