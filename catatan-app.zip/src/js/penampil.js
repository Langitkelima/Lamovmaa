// Rev 60 (G4): penampil gambar layar penuh. Satu gambar dimuat pada satu waktu; URL blob dicabut saat pindah/tutup.
// Cubit = zoom, seret = geser (saat diperbesar), ketuk dua kali = zoom cepat, geser mendatar (zoom 1) = gambar lain,
// tombol Kembali HP menutup (lewat closeViewer() di handleBack). Matematikanya MURNI di gambar.js dan dites di Node.
import { h, ico, PATH } from './ui.js';
import * as G from './gambar.js';
import { isNative } from './native.js';

let cur = null; // { root, close }

export function closeViewer() { if (!cur) return false; const c = cur; cur = null; try { c.close(); } catch (_) {} return true; }

// items: [{ id, w, h, x }] urut tampil; index: gambar yang dibuka; load(item) -> Promise<Blob>.
export function openViewer({ items, index = 0, load }) {
  closeViewer();
  const list = (Array.isArray(items) ? items : []).filter((r) => r && r.id);
  if (!list.length || typeof load !== 'function') return false;
  let i = Math.min(list.length - 1, Math.max(0, index)), url = null, token = 0;
  let st = { scale: 1, tx: 0, ty: 0 }, fit = { w: 0, h: 0 };
  const img = h('img', { class: 'iv-img', alt: 'Gambar catatan', draggable: 'false' });
  const msg = h('div', { class: 'iv-msg', role: 'status' }, 'Memuat gambar...');
  const count = h('span', { class: 'iv-count' }, '');
  const prev = h('button', { type: 'button', class: 'iv-b iv-prev', 'aria-label': 'Gambar sebelumnya' }, '‹');
  const next = h('button', { type: 'button', class: 'iv-b iv-next', 'aria-label': 'Gambar berikutnya' }, '›');
  const x = h('button', { type: 'button', class: 'iv-b iv-x', 'aria-label': 'Tutup' }, ico(PATH.close || 'M6 6l12 12M18 6L6 18'));
  const stage = h('div', { class: 'iv-stage' }, img, msg);
  const root = h('div', { class: 'imgviewer', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Penampil gambar' },
    h('div', { class: 'iv-top' }, count, x), stage, prev, next);
  const vsize = () => { const r = stage.getBoundingClientRect(); return { vw: r.width || innerWidth, vh: r.height || innerHeight }; };
  const apply = () => { img.style.transform = `translate(${st.tx}px,${st.ty}px) scale(${st.scale})`; root.classList.toggle('zoomed', st.scale > 1.01); };
  const layout = () => {
    const it = list[i], { vw, vh } = vsize();
    fit = G.fitInto(it.w, it.h, vw, vh);
    img.style.width = fit.w + 'px'; img.style.height = fit.h + 'px';
    const c = G.clampPan(st.tx, st.ty, st.scale, vw, vh, fit.w, fit.h); st = { scale: G.clampScale(st.scale), tx: c.tx, ty: c.ty }; apply();
  };
  const release = () => { if (url) { try { URL.revokeObjectURL(url); } catch (_) {} url = null; } img.removeAttribute('src'); };
  const show = async (j) => {
    const my = ++token; i = j; st = { scale: 1, tx: 0, ty: 0 };
    release(); img.style.visibility = 'hidden'; msg.textContent = 'Memuat gambar...'; msg.style.display = '';
    count.textContent = list.length > 1 ? (i + 1) + ' / ' + list.length : '';
    prev.style.display = list.length > 1 && G.neighborIndex(i, list.length, -1) >= 0 ? '' : 'none';
    next.style.display = list.length > 1 && G.neighborIndex(i, list.length, 1) >= 0 ? '' : 'none';
    layout();
    try {
      const blob = await load(list[i]);
      if (my !== token || !cur) return; // sudah pindah/tutup
      url = URL.createObjectURL(blob); img.src = url; img.style.visibility = ''; msg.style.display = 'none'; layout();
    } catch (_) { if (my === token) msg.textContent = G.pesanGambarGagal(isNative()); }
  };
  const go = (dir) => { const j = G.neighborIndex(i, list.length, dir); if (j >= 0) show(j); };
  // Abaikan ketukan susulan (klik hantu) yang menyusul jari yang baru saja membuka penampil.
  const t0 = Date.now(), fresh = () => Date.now() - t0 < 350;
  prev.addEventListener('click', () => { if (!fresh()) go(-1); }); next.addEventListener('click', () => { if (!fresh()) go(1); });
  x.addEventListener('click', () => { if (!fresh()) closeViewer(); });

  // Gestur: peta pointer aktif. Dua jari = cubit; satu jari = geser (zoom > 1) atau geser-ganti-gambar (zoom 1).
  const ptr = new Map(); let pinch = null, pan = null, tap = { t: 0, x: 0, y: 0 }, moved = false, swipe = null;
  const center = (e) => { const r = stage.getBoundingClientRect(); return { x: e.clientX - (r.left + r.width / 2), y: e.clientY - (r.top + r.height / 2) }; };
  const dist = () => { const [a, b] = [...ptr.values()]; return Math.hypot(a.x - b.x, a.y - b.y); };
  const mid = () => { const [a, b] = [...ptr.values()], r = stage.getBoundingClientRect(); return { x: (a.x + b.x) / 2 - (r.left + r.width / 2), y: (a.y + b.y) / 2 - (r.top + r.height / 2) }; };
  stage.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    try { stage.setPointerCapture(e.pointerId); } catch (_) {}
    ptr.set(e.pointerId, { x: e.clientX, y: e.clientY }); moved = false;
    if (ptr.size === 2) { pinch = { d: dist(), s: st.scale }; pan = null; swipe = null; }
    else if (ptr.size === 1) { pan = { x: e.clientX, y: e.clientY, tx: st.tx, ty: st.ty }; swipe = { x: e.clientX, y: e.clientY }; }
  });
  stage.addEventListener('pointermove', (e) => {
    if (!ptr.has(e.pointerId)) return;
    ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
    const { vw, vh } = vsize();
    if (ptr.size >= 2 && pinch) {
      const ns = G.pinchScale(pinch.s, pinch.d, dist()), m = mid();
      st = G.zoomAt(st, ns, m.x, m.y, vw, vh, fit.w, fit.h); moved = true; apply(); return;
    }
    if (pan && ptr.size === 1) {
      const dx = e.clientX - pan.x, dy = e.clientY - pan.y;
      if (Math.abs(dx) + Math.abs(dy) > 6) moved = true;
      if (st.scale > 1.01) { const c = G.clampPan(pan.tx + dx, pan.ty + dy, st.scale, vw, vh, fit.w, fit.h); st = { ...st, tx: c.tx, ty: c.ty }; apply(); }
    }
  });
  const up = (e) => {
    if (!ptr.has(e.pointerId)) return;
    const was = ptr.size, last = ptr.get(e.pointerId); ptr.delete(e.pointerId);
    if (ptr.size < 2) pinch = null;
    if (was === 1) {
      const dx = e.clientX - (swipe ? swipe.x : last.x), dy = e.clientY - (swipe ? swipe.y : last.y);
      if (st.scale <= 1.01 && e.type === 'pointerup') { const d = G.swipeDir(dx, dy); if (d) { go(d); pan = null; swipe = null; return; } }
      if (!moved && e.type === 'pointerup') { // ketuk; dua ketukan cepat = zoom
        const now = Date.now(), near = Math.hypot(e.clientX - tap.x, e.clientY - tap.y) < 32;
        if (now - tap.t < 300 && near) {
          const { vw, vh } = vsize(), c = center(e);
          st = st.scale > 1.01 ? { scale: 1, tx: 0, ty: 0 } : G.zoomAt(st, G.VIEW_DOUBLE, c.x, c.y, vw, vh, fit.w, fit.h); apply(); tap.t = 0;
        } else tap = { t: now, x: e.clientX, y: e.clientY };
      }
    }
    if (ptr.size === 1) { const [p] = [...ptr.values()]; pan = { x: p.x, y: p.y, tx: st.tx, ty: st.ty }; swipe = null; } else if (!ptr.size) { pan = null; swipe = null; }
  };
  stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
  stage.addEventListener('wheel', (e) => { e.preventDefault(); const { vw, vh } = vsize(), c = center(e); st = G.zoomAt(st, st.scale * (e.deltaY < 0 ? 1.15 : 1 / 1.15), c.x, c.y, vw, vh, fit.w, fit.h); apply(); }, { passive: false });
  const onKey = (e) => { if (e.key === 'Escape') closeViewer(); else if (e.key === 'ArrowLeft') go(-1); else if (e.key === 'ArrowRight') go(1); };
  const onResize = () => { if (cur) layout(); };
  document.addEventListener('keydown', onKey); addEventListener('resize', onResize);
  document.body.append(root);
  cur = {
    root,
    close: () => { token++; release(); document.removeEventListener('keydown', onKey); removeEventListener('resize', onResize); root.remove(); },
  };
  show(i);
  return true;
}
