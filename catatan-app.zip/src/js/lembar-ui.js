// Item lembar Lainnya yang ditambah bertahap (rincian tiap revisi: RIWAYAT.md): Diagram (Rev 157), Filter baris sementara (149), Validasi data (148), Warna bersyarat (146), Impor CSV/TSV (144), Isi seri (143), Cari dan ganti (142), Urutkan + Unduh CSV/TSV (141); ketuk sel saat bilah berisi rumus = sisip rujukan (131).
// Rev 131 / U8a-4c menambah: ketuk sel saat kolom isian berisi rumus = SISIP RUJUKAN (A1) di kursor (refSlot/insertRef murni); chip "Rentang" menambah ':' agar ketukan berikut jadi ujung rentang.
// Rev 130 / U8a-4b menambah: tombol Σ di baris alat (isi bilah dengan =SUM(rentang di atas/kiri sel terpilih); belum disimpan sampai Enter/centang).
// Rev 129 / U8a-4a menambah: CHIP SARAN fungsi + PETUNJUK ARGUMEN di atas bilah isian saat mengetik rumus (pembantu murni di rumus-bantu.js; chip memakai pointerdown+preventDefault agar keyboard/fokus tidak hilang).
// Rev 120 / U7a-2c-2 menambah: URUNGKAN/ULANGI khusus lembar kerja (snapshot nama+tab per langkah; createHistory murni; maks 50 langkah / ~8 MB; hilang saat layar ditutup).
// Rev 119 / U7a-2c-1 menambah: GAYA sel terpilih (Tebal, Miring, Rata Kiri/Tengah/Kanan, warna Isian, warna Teks) lewat baris alat di atas bilah isian; lewat L.setCell({s}); tersimpan via onChange.
// Rev 118 / U7a-2b-3 menambah: SERET lebar kolom (pegangan di tepi kanan kepala kolom; pointer events + setPointerCapture; lebar tersimpan SEKALI saat jari diangkat; batal = kembali ke lebar awal).
// Rev 116 / U7a-2b-1 menambah: edit sel (bilah nilai jadi kolom isian, Enter/centang/pindah sel = simpan), Tambah baris 10/100, Hapus lembar kerja.
// Rev 117 / U7a-2b-2 menambah: tab baru (+), ketuk tab aktif = ubah nama / hapus tab, ketuk judul = ubah nama lembar kerja. Lebar kolom = U7a-2b-3.
// (dulu: Tab baru/ganti nama + lebar kolom = U7a-2b-2.) Semua perubahan lewat lembar.js (setCell/addRows); penyimpanan lewat callback onChange.
// Rev 115 / U7a-2a: layar penuh LEMBAR KERJA, tahap TAMPILAN saja (belum bisa mengedit sel = U7a-2b).
// Isi: kepala kolom A-Z dan nomor baris yang menempel saat digulir, grid dengan VIRTUALISASI BARIS (hanya baris yang terlihat
// dibuat; 500 baris tetap ringan), pilih sel (ketuk), bilah nilai baca-saja di bawah, dan tab (ganti tab yang sudah ada).
// Matematika tampilan MURNI (visibleRange, displayValue, colLeft, gridSize) dan dites di Node. Tombol Kembali HP menutup lewat
// closeSheet() di handleBack (pola penampil.js). Tanpa penyimpanan, tanpa native, tanpa rumus.
import { h, ico, PATH, toast, dlg, infoDlg, tOk, tWarn } from './ui.js';
// Rev 311b: penolakan lembar kerja = dialog yang menjelaskan alasan dan solusi.
const tooBig = (apa) => infoDlg({ title: 'Lembar kerja terlalu besar', msg: 'Perubahan ini membuat lembar kerja melewati batas ukuran penyimpanan' + (apa ? ' (' + apa + ')' : '') + ', jadi dibatalkan dan lembar dikembalikan seperti semula.', fix: 'Hapus baris, kolom, atau teks yang tidak terpakai, lalu coba lagi.' });
const batas = (judul, msg, fix) => infoDlg({ title: judul, msg, fix });
import * as L from './lembar.js';
import { computeTab, valueToText, isErr, storedToA1, a1ToStored, fxAutoNf } from './rumus.js'; // Rev 127 / U8a-2
import * as MESIN from './rumus.js'; import { setEngine } from './lembar-mesin.js'; setEngine(MESIN); // Rev 192b / P2b: layar lembar memuat mesin rumus, jadi tampilan di luar layar ini (pulau, ekspor) ikut mendapat mesin
import { typedPercent, typedShorthand, formatNumber, NF_PRESETS, nfKey, nfLabel, stepDecimals } from './lembar-format.js'; // Rev 132 / U8a-5
import { sortTab, tabToDelimited, usedRange, findAll, replaceAll, seriesPlan, fillSeries, importDelimited, parseDelimited, detectDelimiter } from './lembar-alat.js'; // Rev 141 / U9a-2; seriesPlan+fillSeries = Rev 143 / U9a-3b
import { copyCell, pasteClip, copyRange, pasteRange } from './lembar-alat.js'; // Rev 171: Salin/Tempel (baris terpisah agar tes penjaga impor lama tetap utuh)
import { getFreeze, freezeBy, setFreeze, freezeLabel, fzScale, fzTooWide, MAX_FZ_ROWS, MAX_FZ_COLS } from './lembar-beku.js'; // Rev 300b: bekukan baris (alat murni, modul malas)
import { shareFileName } from './export.js'; // Rev 141: nama berkas unduhan
import { formulaContext, argHint, suggestionsFor, applySuggestion, sumGuess, refSlot, insertRef, extendRange } from './rumus-bantu.js'; // Rev 129 / U8a-4a; sumGuess = Rev 130 / U8a-4b
import { ruleColors, ruleText, MAX_RULES } from './lembar-aturan.js'; // Rev 146 / U9b-2b: warna bersyarat (murni)
import { checkAt, checkRect, colorOf, validate, invalidCells, invalidTip, nextInvalid, overlapChecks, itemsFromText, rangeText, parseRange, partsFromRect, kindLabel, operands, parseNumText, parseDateText, serialText, itemRowsOf, itemsFromRows, ITEM_COLORS, MAX_CHECKS, MAX_ITEMS, MAX_ITEM_LEN } from './lembar-validasi.js'; // Rev 148 / U9b-3b: validasi data pilihan (murni)
import { isBox, boxState, nextBoxValue, boxTally, boxSelCells, boxTallyText } from './lembar-kotak.js'; // Rev 303b: kotak centang di sel (mesin murni Rev 303a; lembar-ui.js sendiri dimuat malas)
import { syncErrLog, MAX_ERRLOG } from './lembar-riwayat.js'; // Rev 278 / W3
import { refreshSrc, itemsFromRange } from './lembar-sumber.js'; // Rev 281 / V6c-1: daftar pilihan dari rentang sel
import { mergeList, mergeView, mergeAt, planMerge, MAX_MERGES } from './lembar-gabung.js'; // Rev 152 / U10b-2a: gabung sel (murni)
import { rectRef } from './lembar-rentang.js'; // Rev 179a / U10e-1: teks alamat rentang (murni); Rev 258: sisanya tak dipakai lagi di UI
import * as AS from './lembar-aksi-seleksi.js'; // Rev 254 / S5a: aksi mengikuti seleksi (murni)
import * as SX from './lembar-seleksi.js'; // Rev 251 / S2: model seleksi gaya Google Sheets (murni); UI = satu lapisan .lz-sel, kepala in/on, kotak alamat
import * as WN from './lembar-warna.js'; // Rev 262 / S8: panel warna (roda warna, kecerahan, hex, pratinjau terang/gelap); murni
import { filterRows, filterText, cleanFilter, FILTER_KINDS, FILTER_LABELS, filterNeedsValue } from './lembar-filter.js'; // Rev 149 / U9b-1: filter baris sementara (murni)
import { makeDisplay } from './lembar-tampil.js'; // Rev 148: teks TAMPIL sel untuk memeriksa validasi (sama dengan grid/ekspor)
import { rowTops, visibleRangeH, dragRowHeight, dragRowHeightN } from './lembar-baris.js'; // Rev 184b / U10e-2: tinggi baris bebas di grid (murni)
import { chartData, chartSvg, CHART_KINDS, KIND_LABELS, MAX_POINTS } from './lembar-diagram.js'; // Rev 157 / U10c-2a: UI diagram (pratinjau + Unduh SVG; mesin murni Rev 156)
import { CASE_MODES, CASE_LABELS, CASE_HINTS, changeCase, caseInfo, caseMessage, caseText } from './lembar-huruf.js'; // Rev 298: tombol Aa (ubah huruf) di sebelah Tebal; mesin murni

export const ROW_H = 40, HEAD_H = 32, NUM_W = 44, BUFFER = 6;

// Baris yang perlu dibuat untuk jendela gulir. Mengembalikan { from, to } (to eksklusif), selalu di dalam [0, total].
export function visibleRange(scrollTop, viewH, rowH = ROW_H, total = 0, buffer = BUFFER) {
  const t = Math.max(0, Math.floor(total)); if (!t) return { from: 0, to: 0 };
  const st = Math.max(0, Number(scrollTop) || 0), vh = Math.max(0, Number(viewH) || 0);
  const from = Math.min(t, Math.max(0, Math.floor(st / rowH) - buffer));
  const to = Math.min(t, Math.max(from, Math.ceil((st + vh) / rowH) + buffer));
  return { from, to };
}

// Teks yang ditampilkan di sel (nilai mentah tidak berubah). Angka memakai koma desimal; boolean TRUE/FALSE.
export function displayValue(cell) {
  if (!cell || cell.v === undefined || cell.v === null) return '';
  const v = cell.v;
  if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
  if (typeof v === 'number') return Number.isFinite(v) ? String(v).replace('.', ',') : '';
  return String(v);
}

// Rev 127 / U8a-2: teks hasil sel berumus + penanda galat. MURNI. v === undefined (belum dihitung) = kosong.
export function fxDisplay(v) { if (v === undefined || v === null) return { text: '', err: false }; return { text: valueToText(v, { comma: true }), err: isErr(v) }; }
export const hasFx = (cell) => !!(cell && typeof cell.fx === 'string');
export const tabHasFx = (tab) => !!(tab && Array.isArray(tab.rows) && tab.rows.some((r) => r && r.cells && Object.keys(r.cells).some((k) => hasFx(r.cells[k]))));

// Rev 128 / U8a-3: isian berawalan '=' adalah RUMUS (diketik bentuk A1). MURNI.
export const isFormulaText = (t) => /^\s*=/.test(String(t == null ? '' : t));

// Posisi kiri kolom ke-idx (di luar lajur nomor baris) dan ukuran grid.
export function colLeft(tab, idx) { let x = 0; for (let i = 0; i < idx && i < tab.cols.length; i++) x += tab.cols[i].w; return x; }
export function gridSize(tab) { const t = rowTops(tab.rows.map((r) => (r && r.h) || ROW_H)).tops; return { w: NUM_W + colLeft(tab, tab.cols.length), h: HEAD_H + t[t.length - 1] }; } // Rev 184b: tinggi ikut tinggi tiap baris

// Riwayat Urungkan/Ulangi (Rev 120): tumpukan snapshot string. push(sebelum) dipanggil SEBELUM perubahan berlaku (hanya bila benar-benar berubah);
// undo(sekarang) mengembalikan snapshot sebelumnya dan menyimpan keadaan sekarang untuk Ulangi; redo(sekarang) sebaliknya. push mengosongkan Ulangi.
export function createHistory(max = 50, maxBytes = 8000000) {
  let u = [], r = [];
  const bytes = (a) => a.reduce((n, x) => n + x.length, 0);
  const trim = () => { while (u.length > max || (u.length > 1 && bytes(u) > maxBytes)) u.shift(); while (r.length > max || (r.length > 1 && bytes(r) > maxBytes)) r.shift(); };
  return {
    push(snap) { u.push(String(snap)); r = []; trim(); },
    undo(cur) { if (!u.length) return null; r.push(String(cur)); const x = u.pop(); trim(); return x; },
    redo(cur) { if (!r.length) return null; u.push(String(cur)); const x = r.pop(); trim(); return x; },
    canUndo: () => u.length > 0, canRedo: () => r.length > 0, clear() { u = []; r = []; }, sizes: () => [u.length, r.length],
  };
}

// Gaya sel (Rev 119). Warna harus lolos COLORS di lembar.js (#RRGGBB). Rata: Kiri -> Tengah -> Kanan -> Kiri.
export const BG_COLORS = ['#FDE68A', '#BBF7D0', '#BFDBFE', '#FECACA', '#E9D5FF', '#FED7AA', '#E5E7EB'];
export const FG_COLORS = ['#DC2626', '#16A34A', '#2563EB', '#9333EA', '#EA580C', '#6B7280', '#111827'];
export const HA_NAMES = { start: 'Kiri', center: 'Tengah', end: 'Kanan' };
export const nextAlign = (ha) => (ha === 'center' ? 'end' : ha === 'end' ? 'start' : 'center');

// Lebar kolom baru saat diseret: lebar awal + geseran (px), dibulatkan dan dibatasi COL_W_MIN..COL_W_MAX. Masukan rusak = lebar awal (tetap dibatasi).
export function dragWidth(startW, dx) {
  const w0 = Number(startW), d = Number(dx);
  const base = Number.isFinite(w0) ? w0 : L.COL_W_DEF, n = Math.round(base + (Number.isFinite(d) ? d : 0));
  return Math.min(L.COL_W_MAX, Math.max(L.COL_W_MIN, n));
}

// Teks isian -> nilai sel. Angka (koma/titik desimal) jadi number; selain itu teks apa adanya (rumus '=' belum ada = U8, disimpan sebagai teks).
export function parseInput(text) {
  const t = String(text == null ? '' : text).trim(); if (!t) return null;
  if (/^[-+]?\d+([.,]\d+)?$/.test(t) && t.length <= 15) return Number(t.replace(',', '.'));
  const sh = typedShorthand(t); if (sh !== null) return sh; // Rev 140: 6e5 -> 600000, 5rb -> 5000, 1,5jt -> 1500000
  return String(text).slice(0, L.MAX_CELL);
}

// Dialog nama kecil (tanpa pustaka): { title, value, yes, onOk(text), extra? (tombol tambahan, mis. Hapus tab) }
function namePrompt({ title, value, yes = 'Simpan', onOk, extra }) {
  const input = h('input', { class: 'in', type: 'text', maxlength: String(L.MAX_NAME), value: value || '', 'aria-label': title, autocomplete: 'off' });
  const ov = h('div', { class: 'ov dlgov lz-prompt', onclick: (e) => { if (e.target === ov) ov.remove(); } });
  const done = () => { const t = input.value; ov.remove(); onOk(t); };
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); done(); } });
  ov.append(h('div', { class: 'sheet dlg' }, h('h3', {}, title), input,
    h('div', { class: 'dlgb rev' }, h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal'), h('button', { type: 'button', class: 'btn', onclick: done }, yes)),
    extra ? extra(() => ov.remove()) : null));
  document.body.append(ov); setTimeout(() => { try { input.focus(); input.select(); } catch (_) {} }, 50);
}

// Rev 127: kalimat tambahan di dialog hapus bila lembar masih dipakai catatan (n = jumlah catatan; 0/rusak = kosong). MURNI.
export function deleteNote(n) { const k = Math.floor(Number(n)); return Number.isFinite(k) && k > 0 ? ' Lembar ini masih dipakai di ' + k + ' catatan; kartunya di catatan akan tampil "sudah tidak ada".' : ''; }

// Rev 141 / U9a-2: nama berkas unduhan = nama lembar (+ nama tab bila ada beberapa) + tanggal. MURNI.
export function exportName(sheetName, tabName, multi, ext, d = new Date()) { return shareFileName(String(sheetName || '') + (multi ? ' ' + String(tabName || '') : '') || 'lembar kerja', ext, d); }
// Kalimat hasil urutkan untuk toast. res = hasil sortTab. MURNI.
export function sortMessage(res, colLabel, dir) {
  if (!res || !res.ok) return 'Tidak bisa mengurutkan.';
  const arah = dir === 'desc' ? 'Z\u2192A' : 'A\u2192Z';
  const fx = res.fixedRows ? ' ' + res.fixedRows + ' baris bergabungan tetap di tempatnya.' : ''; // Rev 153
  if (!res.moved) return 'Kolom ' + colLabel + ' sudah berurutan (' + arah + ').' + fx;
  const gr = res.charts ? ' Rentang ' + res.charts + ' diagram tetap di posisinya.' : ''; // Rev 176
  return 'Diurutkan menurut kolom ' + colLabel + ' (' + arah + ').' + (res.header ? ' Baris 1 dianggap judul.' : '') + fx + gr;
}

// Rev 142 / U9a-3a: kalimat hasil Ganti semua untuk toast. res = hasil replaceAll. MURNI.
export function replaceMessage(res) {
  const r = res || {}; const base = r.cells ? r.replaced + ' kali diganti di ' + r.cells + ' sel.' : 'Tidak ada yang diganti.';
  const extra = []; if (r.skippedFormula) extra.push(r.skippedFormula + ' sel berumus dilewati'); if (r.skippedFormat) extra.push(r.skippedFormat + ' sel berformat dilewati'); if (r.truncatedText) extra.push(r.truncatedText + ' sel dipotong (maks. ' + L.MAX_CELL + ' karakter)'); // Rev 332 / TD
  return base + (extra.length ? ' ' + extra.join(', ') + '.' : '');
}

// Rev 143 / U9a-3b: pembantu murni Isi seri. Sumber = m sel yang BERAKHIR di sel terpilih (ke bawah: m sel ke atas; ke kanan: m sel ke kiri).
export function fillSource(sel, m, dir) {
  if (!sel) return null; const n = Math.max(1, m | 0);
  return dir === 'right' ? { r1: sel.r, c1: Math.max(0, sel.c - n + 1), r2: sel.r, c2: sel.c } : { r1: Math.max(0, sel.r - n + 1), c1: sel.c, r2: sel.r, c2: sel.c };
}
export function fillRangeText(src, count, dir) {
  if (!src || !(count > 0)) return ''; const a = (r, c) => L.colLabel(c) + (r + 1), one = (r1, c1, r2, c2) => (r1 === r2 && c1 === c2 ? a(r1, c1) : a(r1, c1) + ':' + a(r2, c2));
  const to = dir === 'right' ? one(src.r1, src.c2 + 1, src.r2, src.c2 + count) : one(src.r2 + 1, src.c1, src.r2 + count, src.c1);
  return 'Sumber ' + one(src.r1, src.c1, src.r2, src.c2) + ' \u2192 isi ' + to;
}
// Panjang sumber awal: 2 bila sel terpilih dan sel sebelumnya (atas/kiri) sama-sama terisi dan membentuk pola seri; selain itu 1.
export function defaultSourceLen(tab, sel, dir) {
  if (!sel) return 1; const r = sel.r - (dir === 'right' ? 0 : 1), c = sel.c - (dir === 'right' ? 1 : 0); if (r < 0 || c < 0) return 1;
  const cell = (rr, cc) => (tab.rows[rr] && tab.cols[cc] ? tab.rows[rr].cells[tab.cols[cc].id] : null);
  const a = cell(r, c), b = cell(sel.r, sel.c); if (!a || !b || a.fx || b.fx || a.v === undefined || b.v === undefined) return 1;
  return seriesPlan([a.v, b.v]).kind === 'copy' ? 1 : 2;
}
export function patternLabel(plan) {
  if (!plan) return ''; if (plan.kind === 'linear') return 'angka ' + (plan.step >= 0 ? '+' : '\u2212') + String(Math.abs(plan.step)).replace('.', ',');
  if (plan.kind === 'texnum') return 'teks + angka ' + (plan.step >= 0 ? '+' : '\u2212') + Math.abs(plan.step); return plan.kind === 'formula' ? 'sumber berumus dilewati' : 'ulangi isi sumber';
}
export function fillMessage(res) {
  const r = res || {}; const base = r.filled ? r.filled + ' sel diisi.' : 'Tidak ada yang diisi.'; const extra = [];
  if (r.skippedFormula) extra.push(r.skippedFormula + ' lajur sumber berumus dilewati'); if (r.skippedTarget) extra.push(r.skippedTarget + ' sel tujuan berumus tidak ditimpa'); if (r.truncated) extra.push(r.truncated + ' sel di luar lembar dilewati');
  if (r.skippedCovered) extra.push(r.skippedCovered + ' sel tujuan tertutup gabungan dilewati'); if (r.skippedSource) extra.push(r.skippedSource + ' lajur sumber bergabungan dilewati'); // Rev 153
  return base + (extra.length ? ' ' + extra.join(', ') + '.' : '');
}

// Rev 172: cara tempel di dialog Salin & Tempel (murni).
export const PASTE_MODES = [{ id: 'all', label: 'Semua', sub: 'isi, rumus, gaya' }, { id: 'content', label: 'Isi & rumus', sub: 'tanpa gaya' }, { id: 'values', label: 'Nilai saja', sub: 'hasil hitung' }, { id: 'style', label: 'Gaya saja', sub: 'isi tidak berubah' }];
// Rev 171: pesan hasil Tempel (murni, dipakai toast).
export function pasteMessage(res) {
  const r = res || {};
  if (r.blocked === 'tab') return 'Rumus hanya bisa ditempel di tab asalnya. Pakai Tempel nilai saja untuk tab lain.';
  if (r.blocked === 'origin') return 'Sel asal sudah dihapus, jadi rumusnya tidak bisa ditempel. Pakai Tempel nilai saja.';
  if (r.blocked === 'err') return 'Hasil sel asal berupa galat, tidak bisa ditempel sebagai nilai.';
  const base = r.pasted ? r.pasted + ' sel ditempel.' : 'Tidak ada yang berubah.'; const extra = [];
  if (r.fxPasted) extra.push(r.fxPasted + ' rumus ditempel'); if (r.refLost) extra.push(r.refLost + ' rujukan keluar lembar jadi #REF!'); if (r.skippedFormula) extra.push(r.skippedFormula + ' rumus rusak dilewati'); if (r.skippedTarget) extra.push(r.skippedTarget + ' sel tujuan berumus tidak ditimpa'); if (r.skippedCovered) extra.push(r.skippedCovered + ' sel tujuan tertutup gabungan dilewati'); if (r.skippedErr) extra.push(r.skippedErr + ' sel berhasil galat dilewati'); if (r.truncated) extra.push(r.truncated + ' sel di luar lembar dilewati');
  return base + (extra.length ? ' ' + extra.join(', ') + '.' : '');
}
// Rev 171: teks rentang tujuan Tempel sederet, mis. "C18:E18" (murni).
export function pasteRangeText(sel, count, dir) {
  if (!sel || !(count > 0)) return ''; const a = (r, c) => L.colLabel(c) + (r + 1); const n = Math.floor(count);
  return n === 1 ? a(sel.r, sel.c) : a(sel.r, sel.c) + ':' + (dir === 'right' ? a(sel.r, sel.c + n - 1) : a(sel.r + n - 1, sel.c));
}

// Rev 144 / U9a-3c: pembantu murni Impor.
export const DELIM_NAME = { ',': 'koma', '\t': 'tab', ';': 'titik koma' };
export const IMPORT_MAX_BYTES = 2000000;
export function importSummary(text) {
  const d = detectDelimiter(text), m = parseDelimited(text, d).filter((r, k, a) => !(r.length === 1 && r[0] === '' && k === a.length - 1));
  return { delim: d, rows: m.length, cols: m.length ? Math.max(...m.map((r) => r.length)) : 0 };
}
export function importMessage(res) {
  const r = res || {}; if (!r.ok) return r.reason === 'kosong' ? 'Berkas kosong.' : 'Tidak ada yang diimpor.';
  const extra = []; if (r.truncatedRows) extra.push(r.truncatedRows + ' baris dipotong'); if (r.truncatedCols) extra.push(r.truncatedCols + ' kolom dipotong'); if (r.skippedFormula) extra.push(r.skippedFormula + ' sel berumus dilewati'); if (r.skippedCovered) extra.push(r.skippedCovered + ' sel tertutup gabungan dilewati'); if (r.truncatedText) extra.push(r.truncatedText + ' sel dipotong (maks. ' + L.MAX_CELL + ' karakter)'); // Rev 153; Rev 332 / TD: pemotongan teks dilaporkan
  return r.rows + ' baris \u00d7 ' + r.cols + ' kolom diimpor.' + (extra.length ? ' ' + extra.join(', ') + '.' : '');
}

let cur = null; // { root, close }
let clip = null; // Rev 171: sel yang disalin (potret copyCell); hidup selama aplikasi terbuka, tidak disimpan
export const isSheetOpen = () => !!cur;
export function closeSheet() { if (!cur) return false; const more = document.querySelector('.lz-more'); if (more) { more.remove(); return true; } /* Rev 141: Kembali HP menutup lembar Lainnya dulu */ const c = cur; cur = null; try { c.close(); } catch (_) {} return true; }

// sheet: objek dari data.sheets (hanya DIBACA di tahap ini). onClose dipanggil sesudah layar tertutup.
export function openSheet({ sheet, onClose, onChange, onDelete, usedIn = 0 } = {}) {
  closeSheet();
  if (!sheet || !Array.isArray(sheet.tabs) || !sheet.tabs.length) return false;
  let tab = sheet.tabs[0], sel = null, raf = 0, lastKey = '', lastBase = '', shown = '', ver = 0, calcKey = '', calc = null; // ver = naik tiap perubahan isi (kunci cache hitung rumus) // shown = teks isian saat sel dipilih (Rev 127: tanpa ketikan = tanpa simpan)
  const hist = createHistory(); // Rev 120
  const ser = () => JSON.stringify({ name: sheet.name, tabs: sheet.tabs });
  const scroller = h('div', { class: 'lz-scroll', tabindex: '-1' });
  const inner = h('div', { class: 'lz-inner' });
  const headRow = h('div', { class: 'lz-head' });
  const body = h('div', { class: 'lz-body' });
  const frz = h('div', { class: 'lz-frz' }); frz.style.top = HEAD_H + 'px'; // Rev 300b: lapisan baris beku (sticky, anak body); hanya ada di DOM bila ada baris beku
  const selBox = h('div', { class: 'lz-sel', 'aria-hidden': 'true', hidden: true }); // Rev 251 / S2: SATU lapisan seleksi (bukan elemen per sel); di luar body supaya tidak terhapus saat baris digambar ulang
  inner.append(headRow, body, selBox); scroller.append(inner);
  const addr = h('b', { class: 'lz-addr' }, '-');
  const val = h('input', { class: 'lz-val', type: 'text', autocomplete: 'off', autocapitalize: 'sentences', enterkeyhint: 'done', placeholder: 'Ketuk sel untuk memilih', disabled: true, 'aria-label': 'Isi sel' });
  const ok = h('button', { type: 'button', class: 'lz-ok', 'aria-label': 'Simpan isi sel', disabled: true }, ico(PATH.tugas)); // Rev 181c: centang dua lapis (cincin + cakram), digambar CSS
  const bar = h('div', { class: 'lz-bar' }, addr, h('span', { class: 'lz-fx', 'aria-hidden': 'true' }, '\u0192x'), val, ok);
  const errB = h('button', { type: 'button', class: 'lz-err', hidden: true, 'aria-label': 'Sel tidak sah' }, ico('M12 4L3 20h18zM12 10v5M12 17.5v.5')), errN = h('span', { class: 'lz-errn' }); errB.append(errN); // Rev 277 / W2: ikon peringatan + ringkasan "N sel tidak sah" (kanan chip Tambah baris)
  const addBar = h('div', { class: 'lz-add' }, h('span', {}, 'Tambah baris'));
  // Rev 170: bilah format = IKON saja (tanpa tulisan); nama tetap ada di aria-label/title.
  const FB = { undo: 'M9 14L4 9l5-5M4 9h10.5a5.5 5.5 0 010 11H11', redo: 'M15 14l5-5-5-5M20 9H9.5a5.5 5.5 0 000 11H13', sum: 'M17.5 5h-11l6 7-6 7h11', fmt: 'M5 9h14M5 15h14M10 4L8 20M16 4l-2 16', bold: 'M7 5h5.5a3.5 3.5 0 010 7H7zM7 12h6.5a3.5 3.5 0 010 7H7z', italic: 'M10 5h7M7 19h7M14.5 5l-5 14', bg: 'M5 12.5L11.5 6 18 12.5l-5.3 5.3a1.6 1.6 0 01-2.3 0zM8 9.5h8M19.5 14.5c1.2 1.6 1.7 2.4 1.7 3.1a1.7 1.7 0 01-3.4 0c0-.7.5-1.5 1.7-3.1z', fg: 'M6.5 16L12 4.5 17.5 16M8.5 12h7', more: PATH.star, /* Rev 171: tombol Lainnya memakai ikon bintang Langit (bukan titik tiga) */ pick: 'M7 10l5 5 5-5' };
  const fb = (cls, path, aria, extra = {}) => { const b = h('button', { type: 'button', class: 'lz-fb ' + cls, 'aria-label': aria, title: aria, disabled: true, ...extra }); b.append(ico(path)); return b; };
  const bB = fb('fb-b', FB.bold, 'Tebal'), bI = fb('fb-i', FB.italic, 'Miring'), bAL = fb('fb-a', PATH.alignL, 'Rata kiri'), bAC = fb('fb-a', PATH.alignC, 'Rata tengah'), bAR = fb('fb-a', PATH.alignR, 'Rata kanan'), bBg = fb('fb-bg', FB.bg, 'Warna isian sel'), bFg = fb('fb-fg', FB.fg, 'Warna teks');
  const pal = h('div', { class: 'lz-pal', hidden: true, role: 'group', 'aria-label': 'Pilih warna' });
  const bU = fb('fb-u', FB.undo, 'Urungkan'), bR = fb('fb-u', FB.redo, 'Ulangi');
  const bS = fb('fb-s', FB.sum, 'Jumlahkan (Σ)'); // Rev 130
  const fmtBar = h('div', { class: 'lz-fmt' }, bU, bR, bS, bB, bI, bAL, bAC, bAR, bBg, bFg);
  const bM = fb('fb-m', FB.more, 'Lainnya'); bM.disabled = false; fmtBar.append(bM); // Rev 141 / U9a-2: menu Lainnya (selalu aktif: Unduh tidak butuh sel)
  const bP = fb('fb-p', FB.pick, 'Pilih dari daftar', { hidden: true }); fmtBar.insertBefore(bP, bU); // Rev 148 (paling kiri agar langsung terlihat) / U9b-3b: hanya tampil di kolom bervalidasi
  const hintEl = h('div', { class: 'lz-hint' }), chipsEl = h('div', { class: 'lz-chips', role: 'group', 'aria-label': 'Saran fungsi' }); // Rev 129 / U8a-4a
  const assistEl = h('div', { class: 'lz-assist', hidden: true }, hintEl, chipsEl);
  const fltEl = h('div', { class: 'lz-flt', hidden: true }); // Rev 149: spanduk filter aktif
  const del = h('button', { type: 'button', class: 'lz-del', 'aria-label': 'Hapus lembar kerja' }, 'Hapus');
  const tabs = h('div', { class: 'lz-tabs', role: 'tablist', 'aria-label': 'Tab lembar kerja' });
  const info = h('span', { class: 'lz-info' }, '');
  const titleEl = h('button', { type: 'button', class: 'lz-title', 'aria-label': 'Ubah nama lembar kerja' }, sheet.name);
  const x = h('button', { type: 'button', class: 'lz-x', 'aria-label': 'Tutup lembar kerja' }, ico(PATH.chev));
  const root = h('div', { class: 'lembarfs', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Lembar kerja ' + sheet.name },
    h('div', { class: 'lz-top' }, x, titleEl, info, del), fltEl, scroller, addBar, pal, fmtBar, assistEl, bar, tabs);

  // Rev 304a: kolom beku menyempit sementara saat digeser (tampilan saja). Variabel CSS --fzs di pembungkus gulir = faktor 0..1; lebar/kiri kolom beku = calc(px * var(--fzs, 1)).
  const fzCap = () => Math.max(0, ((scroller.clientWidth || innerWidth) - NUM_W) * 0.7);
  const fzPx = (v) => 'calc(' + v + 'px * var(--fzs, 1))';
  const fzS = () => { const f = getFreeze(tab).c; return f ? fzScale(colLeft(tab, f), scroller.scrollLeft, fzCap()) : 1; };
  const fzUpdate = () => { if (!getFreeze(tab).c) { scroller.style.removeProperty('--fzs'); return 1; } const s = fzS(); scroller.style.setProperty('--fzs', String(s)); return s; };
  const buildHead = () => {
    headRow.textContent = '';
    headRow.style.width = gridSize(tab).w + 'px';
    normSel(); const dm = SX.dimsOfTab(tab); // Rev 251 / S2: kepala kolom 'in' (tersentuh seleksi) / 'on' (seluruh kolom terpilih)
    headRow.append(h('div', { class: 'lz-corner' + (selx && selx.kind === 'all' ? ' hs-on' : ''), 'aria-label': 'Pilih semua sel' }));
    const fcN = getFreeze(tab).c, fzw = fcN ? h('div', { class: 'lz-fzw' }) : null; // Rev 302a: kolom beku = pembungkus STICKY (digeser sistem Android, bukan JS yang telat satu frame)
    if (fzw) { fzw.style.width = fzPx(colLeft(tab, fcN)); headRow.append(fzw); }
    tab.cols.forEach((c, i) => {
      const hs = SX.headState(selx, 'col', i, dm), fz = !!fzw && i < fcN;
      const hc = h('div', { class: 'lz-hc' + (hs ? ' hs-' + hs : ''), 'data-c': String(i) }, L.colLabel(i));
      hc.style.left = fz ? fzPx(colLeft(tab, i)) : NUM_W + colLeft(tab, i) + 'px'; hc.style.width = fz ? fzPx(c.w) : c.w + 'px'; // di dalam pembungkus, kiri dihitung dari pembungkus (sudah di x = NUM_W)
      hc.append(h('div', { class: 'lz-rz' + (i === tab.cols.length - 1 ? ' last' : ''), 'aria-hidden': 'true' }));
      (fz ? fzw : headRow).append(hc);
    });
    fzUpdate();
  };
  // Rev 127: hasil rumus dihitung ULANG hanya bila isi berubah / tab ganti (bukan tiap gulir). Tanpa rumus = null (tanpa biaya).
  const paintFlt = (ord) => {
    if (!ord && !(flt && flt.tabId === tab.id)) { fltEl.hidden = true; return; }
    const ci = flt ? tab.cols.findIndex((c) => c.id === flt.c) : -1; if (!ord || ci < 0) { fltEl.hidden = true; return; }
    fltEl.hidden = false; fltEl.textContent = '';
    fltEl.append(h('span', { class: 'lz-ft' }, 'Filter aktif \u00b7 ' + ord.length + ' dari ' + tab.rows.length + ' baris \u00b7 ' + filterText(flt, L.colLabel(ci))), h('button', { type: 'button', class: 'lz-fx2', 'data-f': 'clear', onclick: () => { flt = null; lastKey = ''; scroller.scrollTop = 0; drawRows(); } }, 'Hapus filter'));
  };
  const getCalc = () => { const k = tab.id + '|' + ver; if (k !== calcKey) { calcKey = k; try { calc = tabHasFx(tab) ? computeTab(tab) : null; } catch (_) { calc = null; } } return calc; };
  // Rev 146 / U9b-2b: warna bersyarat dihitung SEKALI per (tab, ver) memakai HASIL rumus (bukan per sel dan bukan tiap gulir). Tanpa aturan = Map kosong tanpa biaya.
  const NO_RC = new Map(); let rcKey = '', rcMap = NO_RC;
  const getRC = (cc) => {
    if (!tab.rules || !tab.rules.length) return NO_RC;
    const k = tab.id + '|' + ver; if (k === rcKey) return rcMap; rcKey = k;
    const raw = (i, j) => { const row = tab.rows[i], col = tab.cols[j], cell = row && col ? row.cells[col.id] : null; if (!cell) return undefined; return hasFx(cell) ? (cc ? cc.get(row.id, col.id) : undefined) : cell.v; };
    try { rcMap = ruleColors(tab, raw); } catch (_) { rcMap = NO_RC; } return rcMap;
  };
  // Rev 148 / U9b-3b: sel BERISI yang tidak ada di daftar pilihan kolomnya (hanya DITANDAI, tidak ditolak) dihitung SEKALI per (tab, ver) memakai teks TAMPIL. Tanpa validasi = Set kosong tanpa biaya.
  // Rev 149 / U9b-1: filter sementara. order = indeks baris yang lolos (null = tanpa filter). Dihitung SEKALI per (tab, ver, filter), bukan per gulir.
  let rng = null; // Rev 179a: rng = { tabId, rect, rows, cols, cells, ref } (hanya di layar, turunan selx)
  let selx = null, selxTab = '', normKey = ''; // Rev 251 / S2: seleksi gaya Sheets (model lembar-seleksi.js; hanya di layar). `sel` tetap = jangkar (bilah isian). rng sekarang TURUNAN selx (hanya bila kind bukan 'cell'), jadi Salin/format lama ikut jalan.
  let flt = null, ordKey = '', ordArr = null; const fltSig = () => (flt && flt.tabId === tab.id ? flt.c + '|' + flt.k + '|' + flt.a : '-');
  const getOrder = () => {
    if (!flt || flt.tabId !== tab.id || !cleanFilter(flt, tab.cols)) return null;
    const k = tab.id + '|' + ver + '|' + fltSig(); if (k === ordKey) return ordArr; ordKey = k;
    try { ordArr = filterRows(tab, flt, makeDisplay(tab)); } catch (_) { ordArr = null; } return ordArr;
  };
  const NO_IV = new Set(); let ivKey = '', ivSet = NO_IV, ivTx = null, srcKey = '';
  // Rev 281 / V6c-1: daftar pilihan bersumber rentang disegarkan sekali per (tab, ver); gagal = diam (daftar terakhir tetap dipakai).
  const liveSrc = () => { if (!tab.checks || !tab.checks.some((x) => x.src)) return; const k = tab.id + '|' + ver; if (k === srcKey) return; srcKey = k; try { refreshSrc(tab, makeDisplay(tab).text); } catch (_) {} };
  const getIV = () => {
    if (!tab.checks || !tab.checks.length) return NO_IV; liveSrc();
    const k = tab.id + '|' + ver; if (k === ivKey) return ivSet; ivKey = k;
    try { const dp = makeDisplay(tab); ivSet = invalidCells(tab, dp.text, dp.raw); ivTx = dp.text; } catch (_) { ivSet = NO_IV; } return ivSet;
  };
  // Rev 278 / W3: riwayat error tab aktif disamakan tiap onChange; gagal = diam.
  const emitUp = onChange; onChange = (s) => { try { const iv = getIV(), none = iv === NO_IV; if (!none || !(tab.checks && tab.checks.length)) syncErrLog(tab, iv, none ? () => '' : ivTx); } catch (_) {} if (typeof emitUp === 'function') emitUp(s); };
  const paintErr = (iv) => { const n = iv.size; if (errN.dataset.n === String(n)) return; errN.dataset.n = String(n); errB.hidden = !n; errN.textContent = n ? n + ' sel tidak sah' : ''; errB.setAttribute('aria-label', n + ' sel tidak sah. Ketuk untuk melompat.'); };
  // Rev 277 / W2: lompat ke sel (m = { r, c } indeks baris data + kolom): hanya menggeser pilihan + gulir, tidak mengubah data.
  const goTo = (m) => {
    sel = { r: m.r, c: m.c }; { const o1 = getOrder(), l1 = layout(o1), k1 = o1 ? o1.indexOf(m.r) : m.r; scroller.scrollTop = Math.max(0, (k1 >= 0 ? l1.tops[k1] : 0) - ROW_H); }
    scroller.scrollLeft = Math.max(0, colLeft(tab, m.c) - NUM_W);
    lastKey = ''; buildHead(); drawRows(); paintBar(); toast('Tidak sah: ' + L.cellAddr(m.c, m.r) + ' (' + getIV().size + ' sel ditandai)');
  };
  const rgClear = () => { rng = null; selx = null; normKey = ''; }; // selx dibangun ulang dari `sel` (satu sel) oleh normSel
  // Rev 251 / S2: jaga selx tetap sah (ukuran tab, gabungan, jangkar `sel` di dalamnya) dan turunkan rng. Murah: dilewati bila kuncinya sama.
  const firstRow = () => { const o = getOrder(); return o && o.length ? o[0] : 0; };
  const normSel = () => {
    if (!sel) { selx = null; rng = null; normKey = ''; return; }
    const key = [tab.id, ver, tab.rows.length, tab.cols.length, sel.r, sel.c, SX.sig(selx), selxTab].join('|'); if (key === normKey) return;
    const dm = SX.dimsOfTab(tab), ml = mergeList(tab);
    let k = selx && selxTab === tab.id ? SX.clampSel(dm, selx, ml) : null;
    if (!k || !SX.contains(k, sel.r, sel.c)) k = SX.selectCell(dm, sel.r, sel.c, ml);
    selx = k; selxTab = tab.id;
    rng = k && k.kind !== 'cell' ? { tabId: tab.id, rect: k.rect, rows: SX.rowCount(k), cols: SX.colCount(k), cells: SX.cellCount(k), ref: SX.refText(k, L.cellAddr) } : null;
    normKey = [tab.id, ver, tab.rows.length, tab.cols.length, sel.r, sel.c, SX.sig(selx), selxTab].join('|');
  };
  const paintRg = () => { normSel(); }; // Rev 258: mode Pilih rentang lama + spanduknya DIHAPUS (D-S2); rentang kini hanya dari titik seret / ketuk kepala
  // Rev 251 / S2: posisi lapisan seleksi dari layout() (baris TAMPIL; filter = baris yang lolos dan masuk rentang, berurutan). Tanpa elemen per sel.
  let selL = 0, selW = 0; // Rev 251 / S2: kiri + lebar lapisan (untuk dipotong di bawah kolom nomor baris yang menempel)
  // Rev 252 / S3: dua pegangan seret (titik 14 px, area sentuh 44 px). Letak: sel = kanan-bawah; rentang = kiri-atas + kanan-bawah; kolom penuh = kanan-atas; baris penuh = kiri-bawah; semua = tanpa.
  const hdA = h('div', { class: 'lz-hd', 'aria-hidden': 'true', hidden: true }), hdB = h('div', { class: 'lz-hd', 'aria-hidden': 'true', hidden: true }); inner.append(hdA, hdB);
  const gd = h('div', { class: 'lz-gd', 'aria-hidden': 'true', hidden: true }); inner.append(gd); // Rev 253 / S4: garis pratinjau saat mengubah ukuran BANYAK kolom/baris sekaligus (hanya di layar)
  const showGd = (v, pos) => { gd.className = 'lz-gd ' + (v ? 'v' : 'hz'); if (v) { gd.style.left = pos + 'px'; gd.style.top = '0px'; } else { gd.style.top = pos + 'px'; gd.style.left = '0px'; } gd.hidden = false; };
  // Rev 300b: jumlah baris TAMPIL yang beku = baris tampil terdepan yang indeks aslinya < tab.fz.r (filter aktif: hanya yang lolos filter). Selalu menyisakan 1 baris bebas.
  const frCount = (ord, total) => { const z = getFreeze(tab).r; if (!z || !total) return 0; let n = 0; if (ord) { while (n < ord.length && ord[n] < z) n++; } else n = Math.min(z, total); return Math.min(n, total - 1); };
  // Rev 302a: kolom beku TIDAK lagi digeser JS (Rev 300c: translate sebesar scrollLeft, telat satu frame saat gulir cepat = goyang/tertimpa nomor baris). Kini tiap baris punya pembungkus .lz-fzw (position:sticky; left:44px) berisi sel kolom beku, sama seperti nomor baris.
  const clipSel = () => {
    const fr1 = !(selBox.hidden && hdA.hidden) && selBox.dataset.fz === '1', fc1 = !(selBox.hidden && hdA.hidden) && selBox.dataset.fc === '1'; // Rev 300b/c: seleksi yang seluruhnya di baris/kolom beku ikut menempel (di atas lapisan beku)
    { const dy = fr1 ? Math.max(0, scroller.scrollTop) : 0, dx = fc1 ? Math.max(0, scroller.scrollLeft) : 0; for (const e of [selBox, hdA, hdB]) { e.style.translate = dx || dy ? dx + 'px ' + dy + 'px' : ''; e.style.zIndex = fr1 || fc1 ? '4' : ''; } }
    if (fc1) { // Rev 304a: seleksi di kolom beku ikut menyempit (kiri/lebar/pegangan = logis x faktor)
      const fs = fzS(), sc = (v) => NUM_W + (v - NUM_W) * fs; if (!selBox.hidden) { selBox.style.left = sc(selL) + 'px'; selBox.style.width = selW * fs + 'px'; } for (const e of [hdA, hdB]) if (!e.hidden) e.style.left = sc(Number(e.dataset.x)) + 'px';
      selBox.style.clipPath = ''; for (const e of [hdA, hdB]) if (!e.hidden) e.style.visibility = ''; return; }
    if (!selBox.hidden) { const x = Math.max(0, scroller.scrollLeft + NUM_W - selL); selBox.style.clipPath = x > 0 ? 'inset(0 0 0 ' + Math.min(x, selW) + 'px)' : ''; }
    for (const e of [hdA, hdB]) if (!e.hidden) e.style.visibility = Number(e.dataset.x) < scroller.scrollLeft + NUM_W - 4 ? 'hidden' : ''; // pegangan tidak menimpa kolom nomor baris
  };
  const paintSelBox = () => {
    const sx = selx; hdA.hidden = hdB.hidden = true; selBox.hidden = true; if (!sx || sx.kind === 'all') return;
    const rc = sx.rect, ord = getOrder(), lay = layout(ord); let k1 = -1, k2 = -1;
    if (ord) { for (let k = 0; k < ord.length; k++) { const r = ord[k]; if (r >= rc.r1 && r <= rc.r2) { if (k1 < 0) k1 = k; k2 = k; } } } else { k1 = rc.r1; k2 = Math.min(rc.r2, lay.total - 1); }
    const c1 = tab.cols[rc.c1], c2 = tab.cols[rc.c2]; if (k1 < 0 || k2 < k1 || !c1 || !c2) return;
    const fzSel = k2 < frCount(ord, lay.total) ? '1' : ''; const fcSel = rc.c2 < getFreeze(tab).c ? '1' : ''; for (const e of [selBox, hdA, hdB]) { e.dataset.fz = fzSel; e.dataset.fc = fcSel; } // Rev 300b/c
    const left = NUM_W + colLeft(tab, rc.c1), right = NUM_W + colLeft(tab, rc.c2) + c2.w, top = HEAD_H + lay.tops[k1], bottom = HEAD_H + lay.tops[k2 + 1];
    if (sx.kind !== 'cell') { selBox.style.left = left + 'px'; selBox.style.top = top + 'px'; selBox.style.width = (right - left) + 'px'; selBox.style.height = (bottom - top) + 'px'; selL = left; selW = right - left; selBox.hidden = false; }
    const put = (e, which, x, y) => { e.dataset.h = which; e.dataset.x = String(x); e.style.left = x + 'px'; e.style.top = y + 'px'; e.hidden = false; e.style.visibility = ''; };
    if (sx.kind === 'cell') put(hdA, 'br', right, bottom); else if (sx.kind === 'range') { put(hdA, 'tl', left, top); put(hdB, 'br', right, bottom); } else if (sx.kind === 'col') put(hdA, 'tr', right, top); else if (sx.kind === 'row') put(hdA, 'bl', left, bottom);
    clipSel();
  };
  // Rev 252 / S3: seret pegangan = perluas/ciutkan seleksi (selx.extend; jangkar tetap). Auto-gulir di tepi (per frame). Seleksi hanya di layar: tidak menyimpan, tidak masuk Urungkan.
  let hd = null; // { which, sx0, pid, el, x, y, raf }
  const hdFocus = () => {
    const sr = scroller.getBoundingClientRect(), o = { br: [-14, -14], tl: [14, 14], tr: [-14, 14], bl: [14, -14] }[hd.which] || [0, 0];
    let x = hd.x + o[0] - sr.left + scroller.scrollLeft - NUM_W; let y = hd.y + o[1] - sr.top + scroller.scrollTop - HEAD_H;
    const ord = getOrder(), lay = layout(ord); if (!lay.total) return null; { const fn = frCount(ord, lay.total), st = scroller.scrollTop; if (fn && st > 0 && y - st >= 0 && y - st < lay.tops[fn]) y -= st; } /* Rev 300b: jari di atas pita beku = baris beku, bukan baris yang tergulir di bawahnya */ { const fcn = getFreeze(tab).c, sl = scroller.scrollLeft; if (fcn && sl > 0) { const fs = fzS(), u = x - sl; if (u >= 0 && u < colLeft(tab, fcn) * fs) x = u / fs; } } /* Rev 300c: sama untuk kolom beku */ let c = tab.cols.length - 1; for (let i = 0; i < tab.cols.length; i++) if (x < colLeft(tab, i) + tab.cols[i].w) { c = i; break; } /* Rev 304a: kolom dihitung SESUDAH x disesuaikan ke kolom beku */ let k = lay.total - 1; for (let i = 0; i < lay.total; i++) if (y < lay.tops[i + 1]) { k = i; break; }
    return { r: ord ? ord[k] : k, c };
  };
  const hdApply = () => {
    const f = hdFocus(); if (!f) return; const n = SX.extend(SX.dimsOfTab(tab), hd.sx0, f, mergeList(tab)); if (!n || SX.sig(n) === SX.sig(selx)) return;
    selx = n; selxTab = tab.id; normKey = ''; lastKey = ''; buildHead(); drawRows(); paintBar();
  };
  const hdTick = () => {
    if (!hd) return; const sr = scroller.getBoundingClientRect(), edge = 56; let dx = 0, dy = 0;
    const tT = sr.top + HEAD_H + edge, tB = sr.bottom - edge, tL = sr.left + NUM_W + edge, tR = sr.right - edge;
    if (hd.y < tT) dy = -Math.min(28, (tT - hd.y) / 3); else if (hd.y > tB) dy = Math.min(28, (hd.y - tB) / 3);
    if (hd.x < tL) dx = -Math.min(28, (tL - hd.x) / 3); else if (hd.x > tR) dx = Math.min(28, (hd.x - tR) / 3);
    if (dx || dy) { scroller.scrollTop += dy; scroller.scrollLeft += dx; hdApply(); }
    hd.raf = requestAnimationFrame(hdTick);
  };
  const hdDown = (e) => {
    const el = e.target.closest && e.target.closest('.lz-hd'); if (!el || hd || !selx || (e.pointerType === 'mouse' && e.button !== 0)) return;
    e.preventDefault(); e.stopPropagation(); commit(); try { val.blur(); } catch (_) { /* tutup keyboard */ }
    const dm = SX.dimsOfTab(tab), ml = mergeList(tab), rc = selx.rect, w = el.dataset.h; let sx0 = selx;
    if (selx.kind === 'cell' || selx.kind === 'range') { sx0 = w === 'tl' ? SX.selectRange(dm, { r: rc.r2, c: rc.c2 }, { r: rc.r1, c: rc.c1 }, ml) : SX.selectRange(dm, { r: rc.r1, c: rc.c1 }, { r: rc.r2, c: rc.c2 }, ml); if (!sx0) return; sel = { r: sx0.a.r, c: sx0.a.c }; }
    hd = { which: w, sx0, pid: e.pointerId, el, x: e.clientX, y: e.clientY, raf: 0 };
    try { el.setPointerCapture(e.pointerId); } catch (_) {}
    el.classList.add('drag'); hd.raf = requestAnimationFrame(hdTick);
  };
  const hdMove = (e) => { if (!hd || e.pointerId !== hd.pid) return; hd.x = e.clientX; hd.y = e.clientY; hdApply(); };
  const hdEnd = (e) => { if (!hd || e.pointerId !== hd.pid) return; cancelAnimationFrame(hd.raf); try { hd.el.releasePointerCapture(hd.pid); } catch (_) {} hd.el.classList.remove('drag'); hd = null; lastKey = ''; drawRows(); paintBar(); };
  inner.addEventListener('pointerdown', hdDown); inner.addEventListener('pointermove', hdMove); inner.addEventListener('pointerup', hdEnd); inner.addEventListener('pointercancel', hdEnd); inner.addEventListener('lostpointercapture', hdEnd);
  inner.addEventListener('click', (e) => { if (e.target.closest && e.target.closest('.lz-hd')) e.stopPropagation(); }); // ketukan pegangan bukan memilih sel
  // Rev 184b: posisi atas + tinggi pakai tiap baris TAMPIL (urutan tampil k). Dihitung ulang tiap gambar (maks. 500 baris = murah).
  const layout = (ord) => { const total = ord ? ord.length : tab.rows.length, hs = new Array(total); for (let k = 0; k < total; k++) { const rw = tab.rows[ord ? ord[k] : k]; hs[k] = (rw && rw.h) || ROW_H; } const t = rowTops(hs); return { total, tops: t.tops, eff: t.eff }; };
  const drawRows = () => {
    paintRg(); const ord = getOrder(), lay = layout(ord), total = lay.total; paintFlt(ord);
    const fc = getFreeze(tab).c; const fr = frCount(ord, total); // Rev 300b: baris tampil terdepan yang beku (berubah hanya lewat applyFreeze/Urungkan = lastKey dikosongkan, atau sisip/hapus/filter = ver/fltSig ikut kunci)
    const sz = gridSize(tab); sz.h = HEAD_H + lay.tops[total]; inner.style.width = sz.w + 'px'; inner.style.height = sz.h + 'px';
    const vr = visibleRangeH(lay.tops, scroller.scrollTop, scroller.clientHeight || innerHeight, BUFFER); let { from } = vr; const { to } = vr;
    const mv = tab.merges && tab.merges.length ? mergeView(tab, ord) : null, mlist = mv ? mv.list : null, mm = mv ? mv.map : null; // Rev 178: gabungan ikut digambar saat filter aktif (membentang sebanyak baris yang tampil)
    if (mlist) for (const m of mlist) if (m.pos < from && m.pos + m.count > from) from = m.pos; // gabungan yang mulai di atas layar tetap digambar agar rentang ke bawahnya terlihat
    const base = [tab.id, ver, sel ? sel.r + ':' + sel.c : '-', SX.sig(selx), fltSig(), lay.tops[total]].join('|'), key = base + '|' + from + '|' + to; const cc = getCalc(), rc = getRC(cc), iv = getIV(); paintErr(iv); // Rev 256 / S6: base = semua selain jendela baris
    if (key === lastKey) return; const inc = lastKey !== '' && base === lastBase; lastKey = key; lastBase = base; // inc = hanya jendela baris yang bergeser (gulir): baris yang masih terlihat dipakai ulang
    const ckr = (tab.checks || []).map((ck) => ({ ck, rc: checkRect(tab, ck) })).filter((x) => x.rc); // Rev 148; Rev 267: rentang tiap aturan dihitung SEKALI per gambar (bukan per sel)
    const ckAt = (i, j) => { for (const x of ckr) if (i >= x.rc.r1 && i <= x.rc.r2 && j >= x.rc.c1 && j <= x.rc.c2) return x.ck; return null; }; // aturan PERTAMA yang mencakup sel
    let have = null; if (inc) { have = new Set(); for (const el of Array.from(body.children)) { if (el === frz) continue; const kk = Number(el.dataset.k); if (kk >= from && kk < to) have.add(kk); else el.remove(); } } else body.textContent = ''; // Rev 256 / S6: daur ulang baris
    body.style.width = sz.w + 'px'; body.style.height = lay.tops[total] + 'px'; const sdm = SX.dimsOfTab(tab); // Rev 300b: body bertinggi penuh agar lapisan beku (sticky) punya ruang menempel
    if (!inc) { frz.textContent = ''; if (fr) { frz.style.height = lay.tops[fr] + 'px'; frz.style.width = sz.w + 'px'; for (let k = 0; k < fr; k++) { const e = mkRow(k); if (e) frz.append(e); } body.append(frz); } } // Rev 300b: baris beku digambar SEKALI per perubahan (bukan tiap gulir)
    for (let k = from; k < to; k++) {
      if (k < fr) continue; // Rev 300b: baris beku sudah di lapisan beku
      if (have && have.has(k)) continue;
      const e = mkRow(k); if (e) body.append(e);
    }
    paintSelBox();
    function mkRow(k) { // Rev 300b: pembuat satu baris (dipakai grid biasa dan lapisan beku); function (di-hoist) agar urutan kode gambar tetap: lewati baris yang ada, baru buat
      const r = ord ? ord[k] : k; const row = tab.rows[r]; // Rev 149: k = urutan tampil, r = indeks baris asli
      if (!row) return null;
      const rowEl = h('div', { class: 'lz-row', 'data-r': String(r) });
      const eh = lay.eff[k]; rowEl.style.top = lay.tops[k] + 'px'; rowEl.style.width = sz.w + 'px'; rowEl.dataset.k = String(k);
      if (eh !== ROW_H) rowEl.style.height = eh + 'px';
      const rhs = SX.headState(selx, 'row', r, sdm); // Rev 251 / S2: nomor baris 'in' / 'on'
      const rnEl = h('div', { class: 'lz-rn' + (rhs ? ' hs-' + rhs : '') }, String(r + 1), h('div', { class: 'lz-rzr', 'aria-hidden': 'true' })); if (eh !== ROW_H) rnEl.style.height = eh + 'px'; // Rev 184b: pegangan seret tinggi baris
      rowEl.append(rnEl);
      const fzw = fc ? h('div', { class: 'lz-fzw' }) : null; if (fzw) { fzw.style.width = fzPx(colLeft(tab, fc)); rowEl.append(fzw); } // Rev 302a: pembungkus sticky kolom beku (sel gabungan tetap di luar)
      tab.cols.forEach((c, i) => {
        const mg = mm ? mm.get(r + ',' + i) : null; if (mg && !(mg.first === r && mg.c1 === i)) return; // Rev 152: sel tertutup gabungan tidak digambar (Rev 178: yang digambar = baris TAMPIL pertama gabungan)
        const sr = mg ? mg.r1 : r, srow = mg ? tab.rows[mg.r1] : row; // Rev 178: isi/gaya gabungan SELALU dari sel jangkar, walau baris jangkar tersembunyi filter
        const cell = srow.cells[c.id] || null, st = (cell && cell.s) || {};
        const fxd = hasFx(cell) ? fxDisplay(cc ? cc.get(srow.id, c.id) : undefined) : null; // Rev 127: sel berumus = HASIL (galat merah)
        const el = h('div', { class: 'lz-c' + (sel && sel.r === sr && sel.c === i ? ' sel' : '') + (st.b ? ' b' : '') + (st.i ? ' i' : '') + (st.ha ? ' ha-' + st.ha : '') + (fxd && fxd.err ? ' err' : ''), 'data-c': String(i) }, fxd ? fxd.text : displayValue(cell));
        const anf = st.nf || (fxd ? fxAutoNf(cell.fx) : null); if (anf) { const raw = fxd ? (cc ? cc.get(srow.id, c.id) : undefined) : (cell && cell.v), f = formatNumber(raw, anf); if (f !== null) el.textContent = f; } // Rev 164: tanpa format sendiri, DATE/TODAY otomatis Tanggal // Rev 132: format angka hanya saat tampil
        const fz = !!fzw && i < fc && !mg; el.style.left = fz ? fzPx(colLeft(tab, i)) : NUM_W + colLeft(tab, i) + 'px'; el.style.width = fz ? fzPx(c.w) : c.w + 'px'; // Rev 302a: di dalam pembungkus, kiri dihitung dari pembungkus
        if (!mg && eh !== ROW_H) { el.style.height = eh + 'px'; if (eh > ROW_H) el.classList.add('tall'); } // Rev 184b: baris tinggi = teks panjang membungkus
        if (mg) { el.classList.add('mg'); el.style.width = (colLeft(tab, mg.c2) + tab.cols[mg.c2].w - colLeft(tab, mg.c1)) + 'px'; el.style.height = (lay.tops[mg.pos + mg.count] - lay.tops[mg.pos]) + 'px'; el.dataset.ar = String(mg.r1); el.dataset.mp = String(mg.pos); el.dataset.mc = String(mg.count); } // Rev 152: sel jangkar membentang
        if (st.bg) el.style.background = st.bg; if (fxd && fxd.err) el.style.color = st.bg ? '#B91C1C' : '#DC2626'; else if (st.fg) el.style.color = st.fg; else if (st.bg) el.style.color = WN.inkOn(st.bg); // Rev 262: isian terang -> teks gelap, isian gelap -> teks terang (selalu terbaca di tema terang maupun gelap)
        const vck = ckr.length ? ckAt(sr, i) : null; // Rev 267 / V2: warna pilihan (melekat pada aturan) di bawah gaya sel manual dan di bawah warna bersyarat
        if (vck && vck.cl && !st.bg && !(fxd && fxd.err)) { const vc = colorOf(vck, el.textContent); if (vc) { el.classList.add('vc'); if (vc.bg) el.style.background = vc.bg; if (!st.fg) { if (vc.fg) el.style.color = vc.fg; else if (vc.bg) el.style.color = WN.inkOn(vc.bg); } } }
        const rcol = rc.size && !(fxd && fxd.err) ? rc.get(sr + ',' + i) : null; // Rev 146: warna bersyarat DI ATAS gaya sel; galat rumus tetap merah
        if (rcol) { el.classList.add('cf'); if (rcol.bg) { el.style.background = rcol.bg; el.style.color = rcol.fg || '#111827'; } else if (rcol.fg) el.style.color = rcol.fg; }
        if (vck && vck.k === 'box' && !fxd) { const rv = cell ? cell.v : undefined; if (rv === undefined || rv === null || rv === '' || typeof rv === 'boolean' || /^(true|false)$/i.test(String(rv).trim())) { const on = boxState(rv); el.textContent = ''; el.classList.add('ha-center'); el.dataset.box = on ? '1' : '0'; el.setAttribute('role', 'checkbox'); el.setAttribute('aria-checked', String(on)); } } // Rev 303b: sel kotak centang = kotak desain Rev 303c (digambar CSS lewat data-box, bukan glyph teks); sel berisi teks lain tetap tampil apa adanya dan ditandai tidak sah
        if (vck && vck.dd !== false) el.classList.add('dd'); if (iv.size && iv.has(sr + ',' + i)) { el.classList.add('bad'); el.title = invalidTip((iv.by && iv.by.get(sr + ',' + i)) || vck || checkAt(tab, sr, i)); } // Rev 148: panah pilihan + tanda sel tidak sah
        (fz ? fzw : rowEl).append(el);
      });
      return rowEl;
    }
  };
  const paintBar = () => {
    const on = !!sel; val.disabled = !on; ok.disabled = !on; paintFmt();
    if (!on) { addr.textContent = '-'; val.value = ''; return; }
    normSel(); addr.textContent = rng ? rng.ref : L.cellAddr(sel.c, sel.r); paintBoxInfo(); const pc = L.cellAt(tab, sel.r, sel.c); val.value = hasFx(pc) ? storedToA1(pc.fx, tab) : displayValue(pc); shown = val.value; // Rev 127: sel berumus = rumus (A1) di bilah
  };
  // Rev 303e: ringkasan kotak centang di info bar ("3 dari 5 tercentang"); hanya muncul bila seleksi menyentuh kotak, lalu info bar kembali ke "N kolom · M baris".
  let boxInfoOn = false;
  const paintBoxInfo = () => {
    let txt = '';
    try {
      const rects = (tab.checks || []).filter(isBox).map((ck) => checkRect(tab, ck)).filter(Boolean), sr = selx && selx.rect;
      if (rects.length && sr) {
        const boxAt = (i, j) => isBox(checkAt(tab, i, j)) && !hasFx(L.cellAt(tab, i, j)), cells = boxSelCells(sr, rects, boxAt);
        txt = boxTallyText(boxTally(cells, (i, j) => { const x = L.cellAt(tab, i, j); return x ? x.v : undefined; }));
      }
    } catch (_) { txt = ''; }
    if (txt) { info.textContent = txt; boxInfoOn = true; } else if (boxInfoOn) { boxInfoOn = false; try { paintInfo(); } catch (_) { info.textContent = ''; } }
  };
  // Simpan isian ke sel terpilih. Bila lembar jadi lewat batas ukuran, perubahan dibatalkan.
  let badTxt = '';
  const commit = () => {
    if (!sel || val.disabled) return;
    if (val.value === shown) return; // Rev 127: isian tidak diketik ulang -> sel tidak disentuh (teks "007"/nomor HP tidak berubah jadi angka)
    const row = tab.rows[sel.r], col = tab.cols[sel.c]; if (!row || !col) return;
    let patch, before = JSON.stringify(row.cells[col.id] || null);
    if (isFormulaText(val.value)) { // Rev 128 / U8a-3: rumus -> bentuk simpan; ditolak (tidak disimpan) bila salah
      const r = a1ToStored(val.value.trim(), tab);
      if (!r.ok) { if (badTxt === val.value) return; badTxt = val.value; val.classList.add('inerr'); setTimeout(() => val.classList.remove('inerr'), 4000); infoDlg({ title: 'Rumus tidak disimpan', msg: 'Rumus ' + String(val.value).trim().slice(0, 60) + ' tidak bisa dipakai: ' + (r.error || 'tidak valid') + '.', fix: 'Teks yang kamu ketik masih ada di kolom isian, sel tetap berisi nilai sebelumnya. Perbaiki rumusnya, lalu simpan lagi.', onAct: () => { try { val.focus(); } catch (_) {} }, act: 'Perbaiki' }); return; }
      badTxt = ''; val.classList.remove('inerr');
      const pc = L.cellAt(tab, sel.r, sel.c); if (hasFx(pc) && pc.fx === r.fx) { shown = val.value; return; }
      patch = { fx: r.fx };
    } else {
      if (String(val.value).length > L.MAX_CELL) batas('Teks dipotong', 'Satu sel hanya boleh berisi ' + L.MAX_CELL + ' karakter, jadi sisa teks tidak ikut tersimpan.', 'Pindahkan teks panjang ke catatan biasa, atau pecah ke beberapa sel.'); // Rev 311d
      const pct = typedPercent(val.value, (curStyle() || {}).nf), next = pct ? pct.v : parseInput(val.value); // Rev 133: 25% -> 0,25
      if (!hasFx(L.cellAt(tab, sel.r, sel.c)) && !(pct && pct.explicit && !curStyle().nf) && displayValue(L.cellAt(tab, sel.r, sel.c)) === (next === null ? '' : displayValue({ v: next }))) return;
      patch = { v: next }; if (pct && pct.explicit && !curStyle().nf) patch.s = { nf: { k: 'percent', d: pct.d } }; // sel tanpa format dapat format Persen otomatis
    } // tidak berubah (sel berumus selalu dianggap berubah: mengetik = menimpa rumus; rumus baru lewat bilah = U8a-3)
    const snap = ser();
    if (!L.setCell(tab, row.id, col.id, patch)) return;
    if (!L.fitsLimit(sheet)) { if (before === 'null') delete row.cells[col.id]; else row.cells[col.id] = JSON.parse(before); tooBig(); { const pc = L.cellAt(tab, sel.r, sel.c); val.value = hasFx(pc) ? storedToA1(pc.fx, tab) : displayValue(pc); } shown = val.value; return; }
    ver++, hist.push(snap); paintUndo(); shown = val.value;
    sheet.at = Date.now(); lastKey = ''; drawRows(); if (typeof onChange === 'function') onChange(sheet);
  };
  const addRowsBy = (n) => {
    const snap = ser(), k = L.addRows(tab, n); if (!k) { batas('Batas baris tercapai', 'Satu tab hanya boleh berisi ' + L.MAX_ROWS + ' baris.', 'Hapus baris yang tidak terpakai, atau pindahkan data ke tab lain.'); return; }
    if (!L.fitsLimit(sheet)) { tab.rows.length -= k; tooBig(); return; }
    ver++, hist.push(snap); paintUndo();
    sheet.at = Date.now(); lastKey = ''; buildHead(); drawRows(); paintTabs(); if (typeof onChange === 'function') onChange(sheet);
  };
  [10, 100].forEach((n) => addBar.append(h('button', { type: 'button', class: 'lz-addb', onclick: () => addRowsBy(n) }, String(n)))); addBar.append(errB);
  // Rev 279 / W4: dialog riwayat error (tab aktif). Ikon peringatan dan tombol di dialog Validasi data membukanya.
  const openHist = () => {
    try { const iv = getIV(), none = iv === NO_IV; if (!none || !(tab.checks && tab.checks.length)) syncErrLog(tab, iv, none ? () => '' : ivTx); } catch (_) {}
    const ov = h('div', { class: 'ov dlgov lz-more lz-find lz-rules lz-checks lz-vd', onclick: (e) => { if (e.target === ov) ov.remove(); } }), list = h('div', { class: 'eh-list' }), sum = h('p', { class: 'eh-sum' });
    const clr = h('button', { type: 'button', class: 'btn line lz-mx', 'data-f': 'clear' }, 'Bersihkan riwayat'); let armed = 0;
    const paint = () => {
      const log = (tab.errlog || []).slice().reverse(), on = log.filter((e) => e.st === 'open').length; list.textContent = ''; clr.hidden = !log.length;
      sum.textContent = log.length ? on + ' aktif, ' + (log.length - on) + ' selesai (maks. ' + MAX_ERRLOG + ' catatan terbaru).' : 'Belum ada catatan. Sel yang tidak sah akan tercatat di sini.';
      for (const e of log) {
        const i = tab.rows.findIndex((r) => r.id === e.r), j = tab.cols.findIndex((c) => c.id === e.c), ok = i >= 0 && j >= 0, open = e.st === 'open', d = (t) => new Date(t).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
        list.append(h('div', { class: 'eh-row' }, h('div', { class: 'eh-main' }, h('b', {}, (ok ? L.cellAddr(j, i) : '(sel dihapus)') + ': ' + (e.v || '(kosong)')), h('span', {}, e.rule.t), h('span', {}, open ? 'Sejak ' + d(e.at) : d(e.at) + ' sampai ' + d(e.fixedAt))),
          h('span', { class: 'eh-tag ' + (open ? 'on' : 'ok') }, open ? 'Aktif' : 'Selesai'),
          h('button', { type: 'button', class: 'btn line', 'data-f': 'go', disabled: !ok, onclick: () => { ov.remove(); goTo({ r: i, c: j }); if (!open) toast('Sel ' + L.cellAddr(j, i) + ' sudah beres.'); } }, 'Lompat')));
      }
    };
    clr.onclick = () => {
      if (!armed) { armed = 1; clr.textContent = 'Ketuk lagi untuk menghapus'; setTimeout(() => { armed = 0; clr.textContent = 'Bersihkan riwayat'; }, 3000); return; }
      const snap = ser(); delete tab.errlog; ver++, hist.push(snap); paintUndo(); touched(); armed = 0; clr.textContent = 'Bersihkan riwayat'; paint(); tOk('Riwayat dibersihkan. Bisa diurungkan.');
    };
    paint(); ov.append(h('div', { class: 'sheet vd-sheet' }, dlgHead('validasi', 'M12 4L3 20h18zM12 10v5M12 17.5v.5', 'Riwayat error', 'Sel yang pernah tidak sah di tab ini, dan apakah sudah dibetulkan.', ov), sum, list, clr, h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov);
  };
  errB.onclick = openHist;
  val.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); commit(); val.blur(); } });
  val.addEventListener('blur', () => { commit(); paintInfo(); });
  val.addEventListener('input', () => { // Rev 128: pratinjau hasil / pesan galat rumus selama mengetik
    if (!isFormulaText(val.value)) { paintInfo(); return; }
    const r = a1ToStored(val.value.trim(), tab);
    if (!r.ok) { info.textContent = r.error || 'Rumus belum lengkap'; return; }
    try { const c = getCalc() || computeTab(tab); info.textContent = '= ' + fxDisplay(c.evalExpr(r.fx)).text; } catch (_) { paintInfo(); }
  });
  // --- Rev 129 / U8a-4a: chip saran fungsi + petunjuk argumen (hanya saat kolom isian fokus dan berisi rumus) ---
  const paintAssist = () => {
    const ctx = document.activeElement === val && !val.disabled ? formulaContext(val.value, val.selectionStart) : null;
    hintEl.textContent = ''; chipsEl.textContent = '';
    const hint = ctx && ctx.fn ? argHint(ctx.fn, ctx.arg) : null, sugs = suggestionsFor(ctx);
    if (hint) {
      hintEl.append(h('b', {}, hint.name), '(');
      hint.parts.forEach((p, i) => { if (i) hintEl.append('; '); hintEl.append(i === hint.active ? h('b', { class: 'on' }, p) : p); });
      hintEl.append(')', h('span', { class: 'lz-hk' }, ' \u00b7 ' + hint.ket));
    }
    sugs.forEach((f) => { const b = h('button', { type: 'button', class: 'lz-sg', 'aria-label': 'Sisipkan fungsi ' + f.name, title: f.ket }, f.name); b.addEventListener('pointerdown', (e) => e.preventDefault()); b.onclick = () => useSuggestion(f.name); chipsEl.append(b); });
    const slot = ctx ? refSlot(val.value, val.selectionStart) : null; // Rev 131: chip Rentang bila kursor tepat sesudah satu rujukan
    if (slot && slot.kind === 'ref') { const rb = h('button', { type: 'button', class: 'lz-sg lz-rg', 'aria-label': 'Jadikan rentang' }, 'Rentang :'); rb.addEventListener('pointerdown', (e) => e.preventDefault()); rb.onclick = () => { const r = extendRange(val.value, val.selectionStart); val.value = r.text; try { val.setSelectionRange(r.caret, r.caret); } catch (_) {} val.dispatchEvent(new Event('input')); }; chipsEl.append(rb); }
    const nChips = chipsEl.children.length;
    hintEl.hidden = !hint; chipsEl.hidden = !nChips; assistEl.hidden = !hint && !nChips;
  };
  const useSuggestion = (name) => {
    const r = applySuggestion(val.value, val.selectionStart, name); val.value = r.text;
    try { val.setSelectionRange(r.caret, r.caret); } catch (_) {}
    val.dispatchEvent(new Event('input')); // pratinjau hasil + saran/petunjuk berikutnya
  };
  ['input', 'keyup', 'click', 'focus'].forEach((ev) => val.addEventListener(ev, paintAssist));
  val.addEventListener('blur', () => { assistEl.hidden = true; });
  ok.addEventListener('pointerdown', (e) => e.preventDefault());
  ok.onclick = () => { commit(); val.blur(); };
  del.onclick = () => dlg({ title: 'Hapus lembar kerja?', msg: '\u201c' + sheet.name + '\u201d dan semua isinya dihapus permanen. Tidak bisa dikembalikan.' + deleteNote(usedIn), yes: 'Hapus', red: true, ok: () => { closeSheet(); if (typeof onDelete === 'function') onDelete(sheet); } });
  // --- Rev 119 / U7a-2c-1: gaya sel terpilih ---
  let palMode = null; // null | 'bg' | 'fg'
  let nfOpen = false; // Rev 132: panel format angka terbuka
  let capOpen = false; // Rev 298: panel Ubah huruf terbuka
  const curStyle = () => { const c = sel ? L.cellAt(tab, sel.r, sel.c) : null; return (c && c.s) || {}; };
  function paintFmt() {
    const st = sel ? curStyle() : {}, on = !!sel;
    [bB, bI, bAL, bAC, bAR, bBg, bFg].forEach((b) => { b.disabled = !on; });
    bS.disabled = !on; // Rev 130
    { const pk = on ? checkAt(tab, sel.r, sel.c) : null, pkOn = !!pk && pk.dd !== false; bP.hidden = !pkOn; bP.disabled = !pkOn; } // Rev 148
    const bOn = rng ? allHave('b') : !!st.b, iOn = rng ? allHave('i') : !!st.i; // Rev 251 / S2: pada seleksi, nyala bila SEMUA sel bergaya itu (sama dengan yang dilakukan tombolnya)
    bB.classList.toggle('on', bOn); bI.classList.toggle('on', iOn); { const ha = st.ha || 'start'; [[bAL, 'start'], [bAC, 'center'], [bAR, 'end']].forEach(([b, k]) => { b.classList.toggle('on', on && ha === k); b.setAttribute('aria-pressed', String(on && ha === k)); }); bB.setAttribute('aria-pressed', String(bOn)); bI.setAttribute('aria-pressed', String(iOn)); }
    bBg.classList.toggle('on', palMode === 'bg'); bFg.classList.toggle('on', palMode === 'fg');
    bBg.style.setProperty('--sw', st.bg || 'transparent'); bFg.style.setProperty('--sw', st.fg || 'transparent');
    if (!on && palMode) palMode = null; paintPal(); paintNf(); paintCap();
  }
  function paintPal() {
    pal.textContent = ''; pal.hidden = !palMode; if (!palMode) return;
    const key = palMode, list = key === 'bg' ? BG_COLORS : FG_COLORS, cur = curStyle()[key] || null;
    pal.append(h('button', { type: 'button', class: 'lz-swk', 'aria-label': 'Warna apa saja (roda warna)', title: 'Roda warna', onclick: () => openColorPanel(key) })); // Rev 262 / S8
    list.forEach((c) => { const sw = h('button', { type: 'button', class: 'lz-sw' + (cur === c ? ' on' : ''), 'aria-label': 'Warna ' + c, onclick: () => applyStyle({ [key]: c }) }); sw.style.background = c; pal.append(sw); });
    pal.append(h('button', { type: 'button', class: 'lz-swn', onclick: () => applyStyle({ [key]: null }) }, 'Bawaan'));
  }
  // --- Rev 262 / S8: PANEL WARNA (lembar bawah) untuk warna isian / teks: roda warna (rona = sudut, kejenuhan = jari-jari), kecerahan, kode hex,
  // pratinjau di tema terang DAN gelap (+ di isian sel bila ada), deret warna per tema, Atur ulang. Satu Terapkan = satu langkah Urungkan lewat applyStyle.
  // Tanpa penyimpanan/native; warna keluar sebagai '#RRGGBB' (format lama, tanpa SCHEMA baru). Seleksi/gestur grid tidak disentuh.
  const recentCol = { bg: [], fg: [] }; // Rev 263: warna terakhir dipakai (hanya selama aplikasi terbuka; tanpa penyimpanan, sesuai aturan lembar-ui)
  // Rev 296: `ext` (opsional) = pemakaian dari luar sel: { title, start, ctx: {fg, bg}, ref, onApply(hex), onReset() }; dipakai warna pilihan Validasi data. Tanpa `ext` = perilaku Rev 262 (warna sel terpilih).
  function openColorPanel(key, ext) {
    if (document.querySelector('.lz-wn')) return; if (!ext) { if (!sel) return; commit(); }
    const isBg = key === 'bg', st0 = ext ? (ext.ctx || {}) : curStyle(), start = WN.normHex((ext ? ext.start : st0[key]) || '') || (isBg ? '#BFDBFE' : '#2563EB'), hs0 = WN.hexToHsl(start);
    let H = hs0.h, S = hs0.s, Lt = hs0.l, raf = 0;
    const ov = h('div', { class: 'ov dlgov lz-more lz-cm lz-wn', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const SZ = 220, R = SZ / 2;
    const cv = h('canvas', { class: 'wn-cv', width: String(SZ), height: String(SZ), 'aria-hidden': 'true' });
    const thumb = h('i', { class: 'wn-th', 'aria-hidden': 'true' });
    const box = h('div', { class: 'wn-wheel', role: 'group', 'aria-label': 'Roda warna: geser untuk memilih rona dan kejenuhan' }, cv, thumb);
    const sl = h('input', { type: 'range', class: 'wn-sl', min: '0', max: '100', step: '1', 'aria-label': 'Kecerahan' });
    const hex = h('input', { type: 'text', class: 'wn-hex', maxlength: '7', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', 'aria-label': 'Kode warna heksadesimal' });
    const chip = h('i', { class: 'wn-chip', 'aria-hidden': 'true' });
    const pv = h('div', { class: 'wn-pv', 'aria-live': 'polite' });
    const cur = () => WN.hslToHex(H, S, Lt);
    const drawWheel = () => {
      raf = 0; const g = cv.getContext && cv.getContext('2d'); if (!g) return;
      const img = g.createImageData(SZ, SZ), d = img.data;
      for (let y = 0; y < SZ; y++) for (let x = 0; x < SZ; x++) {
        const dx = x + 0.5 - R, dy = y + 0.5 - R, r = Math.hypot(dx, dy), i = (y * SZ + x) * 4; if (r > R) continue;
        const q = WN.wheelToHs(dx, dy, R), c = WN.hslToRgb(q.h, q.s, Lt); d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = r > R - 1 ? Math.round(255 * (R - r)) : 255;
      }
      g.putImageData(img, 0, 0);
    };
    const redraw = () => { if (!raf) raf = requestAnimationFrame(drawWheel); }; // satu gambar per frame saat slider/seret
    const paint = (skipHex) => {
      const c = cur(), p = WN.hsToWheel(H, S, R);
      thumb.style.left = ((R + p.x) / SZ * 100) + '%'; thumb.style.top = ((R + p.y) / SZ * 100) + '%'; thumb.style.background = c;
      sl.value = String(Math.round(Lt)); sl.style.setProperty('--wm', WN.hslToHex(H, S, 50)); sl.style.setProperty('--wc', c);
      chip.style.background = c; if (!skipHex) hex.value = c;
      pv.textContent = '';
      (WN.themePreview(key, c, { fg: st0.fg, bg: st0.bg }) || []).forEach((t) => {
        const pc = h('div', { class: 'wn-pc' }), tx = WN.inkOn(t.surface);
        pc.style.background = t.surface; pc.style.color = tx;
        const sm = h('b', { class: 'wn-ps' }, 'Aa 123'); sm.style.color = t.ink; if (isBg) sm.style.background = t.bg;
        pc.append(h('span', { class: 'wn-pn' }, t.nama), sm, h('em', {}, t.ratio + ':1 \u00b7 ' + (t.samar ? 'menyatu dengan latar' : t.nilai)));
        pv.append(pc);
      });
    };
    const setHex = (x) => { const q = WN.hexToHsl(x); if (!q) return; H = q.h; S = q.s; Lt = q.l; redraw(); paint(); };
    const fromPoint = (e) => { const r = box.getBoundingClientRect(), sc = SZ / (r.width || SZ), q = WN.wheelToHs((e.clientX - r.left) * sc - R, (e.clientY - r.top) * sc - R, R); H = q.h; S = q.s; paint(); };
    let drag = false;
    box.addEventListener('pointerdown', (e) => { drag = true; try { box.setPointerCapture(e.pointerId); } catch (_) {} fromPoint(e); e.preventDefault(); });
    box.addEventListener('pointermove', (e) => { if (drag) fromPoint(e); });
    const stop = () => { drag = false; }; box.addEventListener('pointerup', stop); box.addEventListener('pointercancel', stop);
    sl.addEventListener('input', () => { Lt = Number(sl.value) || 0; redraw(); paint(); });
    hex.addEventListener('input', () => { const n = WN.normHex(hex.value); if (n && hex.value.replace('#', '').length >= 3) { const q = WN.hexToHsl(n); H = q.h; S = q.s; Lt = q.l; redraw(); paint(true); } });
    hex.addEventListener('blur', () => { hex.value = cur(); });
    const mkRow = (label, colors, id) => h('div', { class: 'wn-row', 'data-wn': id }, h('span', { class: 'wn-rl' }, label),
      h('div', { class: 'wn-sws' }, ...colors.map((c) => { const b = h('button', { type: 'button', class: 'wn-sw', 'aria-label': 'Warna ' + c, onclick: () => setHex(c) }); b.style.background = c; return b; })));
    const lastC = recentCol[key], usedC = WN.usedColors(tab, key).filter((c) => !lastC.includes(c)); // Rev 263: terakhir dipakai + yang sudah ada di lembar ini
    const rows = [lastC.length ? mkRow('Terakhir dipakai', lastC, 'terakhir') : null, usedC.length ? mkRow('Di lembar ini', usedC, 'lembar') : null,
      ...(isBg ? WN.FILL_ROWS : WN.TEXT_ROWS).map((rw) => mkRow(rw.label, rw.colors, rw.id))];
    const eye = typeof window !== 'undefined' && typeof window.EyeDropper === 'function' ? h('button', { type: 'button', class: 'wn-eye', 'aria-label': 'Pipet dari layar', title: 'Pipet dari layar', onclick: () => { try { new window.EyeDropper().open().then((r) => { if (r && r.sRGBHex) setHex(r.sRGBHex); }, () => {}); } catch (_) {} } }, ico('M20 4l-3-1-4 4-1-1-2 2 1 1-7 7v3h3l7-7 1 1 2-2-1-1 4-4zM7 17l6-6')) : null; // hanya bila perangkat mendukung (Android WebView biasanya tidak)
    const btn = (cls, label, fn) => h('button', { type: 'button', class: 'wn-b' + cls, onclick: fn }, label);
    const ref = ext ? ext.ref || '' : selx ? SX.refText(selx, L.cellAddr) : '';
    const done = (c) => { ov.remove(); if (!ext) return applyStyle({ [key]: c }); if (c) recentCol[key] = WN.pushRecent(recentCol[key], c); (c ? ext.onApply : ext.onReset)(c); };
    ov.append(h('div', { class: 'sheet' },
      h('div', { class: 'cm-h' }, h('h3', {}, ext && ext.title ? ext.title : isBg ? 'Warna isian' : 'Warna teks'), ref ? h('span', { class: 'cm-ref' }, ref) : null),
      box, h('div', { class: 'wn-hexr' }, chip, hex, eye), sl, pv, ...rows,
      h('div', { class: 'wn-act' }, btn('', ext ? 'Kosongkan' : 'Atur ulang', () => done(null)), btn('', 'Batal', () => ov.remove()), btn(' p', 'Terapkan', () => done(cur())))));
    document.body.append(ov); drawWheel(); paint();
  }
  // --- Rev 132 / U8a-5: tombol Format + panel pilihan (Umum/Angka/Persen/Rp/Tanggal, desimal -/+). Hanya tampilan; nilai mentah tetap.
  const bN = h('button', { type: 'button', class: 'lz-fb fb-n', 'aria-label': 'Format angka', title: 'Format angka', disabled: true }); bN.append(ico(FB.fmt));
  const nfp = h('div', { class: 'lz-pal lz-nfp', hidden: true, role: 'group', 'aria-label': 'Format angka' });
  // --- Rev 298: tombol "Aa" (Ubah huruf) tepat di kiri Tebal + panel 4 pilihan dengan pratinjau langsung dari sel terpilih. Satu pilihan = satu langkah Urungkan; sel rumus dilewati dan dilaporkan.
  const bCase = fb('fb-case', 'M2.5 18L7.5 6.5l5 11.5M4.4 14h6.2M20.5 15.2a2.8 2.8 0 11-5.6 0 2.8 2.8 0 015.6 0zM20.5 12.4V18', 'Ubah huruf');
  const capEl = h('div', { class: 'lz-pal lz-cap', hidden: true, role: 'group', 'aria-label': 'Ubah huruf' }); root.insertBefore(capEl, fmtBar);
  bCase.addEventListener('pointerdown', (e) => e.preventDefault());
  bCase.onclick = () => { if (!sel) return; capOpen = !capOpen; if (capOpen) { palMode = null; nfOpen = false; } paintFmt(); };
  function paintCap() {
    const on = !!sel; if (!on || palMode || nfOpen) capOpen = false;
    bCase.disabled = !on; bCase.classList.toggle('on', capOpen); bCase.setAttribute('aria-expanded', String(capOpen));
    capEl.hidden = !capOpen; capEl.textContent = ''; if (!capOpen) return;
    const info = caseInfo(tab, styleRect()), eg = info.sample === null ? 'Contoh teks' : info.sample.split('\n')[0];
    CASE_MODES.forEach((m) => {
      const on1 = info.same[m], t = h('button', { type: 'button', class: 'lz-cs' + (on1 ? ' on' : ''), 'aria-pressed': String(on1), 'aria-label': CASE_LABELS[m] + '. ' + CASE_HINTS[m] + (on1 ? '. Sudah berlaku.' : ''), onclick: () => applyCase(m) }, h('span', { class: 'cs-t' }, caseText(eg, m)), h('span', { class: 'cs-n' }, CASE_LABELS[m]));
      t.addEventListener('pointerdown', (e) => e.preventDefault()); capEl.append(t);
    });
  }
  function applyCase(mode) {
    if (!sel) return; commit(); capOpen = false;
    const snap = ser(), res = changeCase(tab, mode, styleRect());
    if (res.cells) {
      if (!L.fitsLimit(sheet)) { restore(snap); paintFmt(); tooBig(); return; }
      ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar();
    } else paintFmt();
    toast(caseMessage(res, mode));
  }
  fmtBar.insertBefore(bN, bB); root.insertBefore(nfp, fmtBar); // Format ditaruh sesudah Σ (mudah ditemukan); baris pembuat fmtBar tidak diubah
  { const sep = () => h('span', { class: 'lz-sep', 'aria-hidden': 'true' }); fmtBar.textContent = ''; fmtBar.append(bP, bU, bR, sep(), bCase, bB, bI, sep(), bAL, bAC, bAR, sep(), bBg, bFg, sep(), bS, bN, bM); } // Rev 170: urutan dan pemisah kelompok (Riwayat | Teks | Rata | Warna | Hitung | Lainnya)
  bN.addEventListener('pointerdown', (e) => e.preventDefault());
  bN.onclick = () => { if (!sel) return; nfOpen = !nfOpen; if (nfOpen) palMode = null; paintFmt(); };
  function paintNf() {
    const on = !!sel, st = on ? curStyle() : {}; if (!on || palMode) nfOpen = false;
    bN.disabled = !on; { const t = st.nf ? 'Format angka: ' + nfLabel(st.nf) : 'Format angka'; bN.setAttribute('aria-label', t); bN.title = t; } bN.classList.toggle('on', nfOpen || !!st.nf);
    nfp.hidden = !nfOpen; nfp.textContent = ''; if (!nfOpen) return;
    const key = nfKey(st.nf);
    NF_PRESETS.forEach((p) => nfp.append(h('button', { type: 'button', class: 'lz-swn lz-nfb' + (p.id === key ? ' on' : ''), 'aria-pressed': String(p.id === key), onclick: () => applyStyle({ nf: p.nf }) }, p.label)));
    nfp.append(h('span', { class: 'lz-sep', 'aria-hidden': 'true' }));
    [['\u2212,0', -1], ['+,0', 1]].forEach(([t, d]) => { const n = stepDecimals(st.nf, d), b = h('button', { type: 'button', class: 'lz-swn lz-nfb', disabled: !n || JSON.stringify(n) === JSON.stringify(st.nf), 'aria-label': d < 0 ? 'Kurangi desimal' : 'Tambah desimal', onclick: () => applyStyle({ nf: n }) }, t); nfp.append(b); });
  }
  // Terapkan gaya ke sel terpilih, ATAU ke SEMUA sel rentang bila ada rentang terpilih di tab ini (Rev 181b). null = hapus kunci gaya itu. Bila lembar melewati batas ukuran, semuanya dibatalkan.
  const styleRect = () => (rng && rng.tabId === tab.id ? rng.rect : sel ? { r1: sel.r, c1: sel.c, r2: sel.r, c2: sel.c } : null);
  const allHave = (key) => { const q = styleRect(); if (!q) return false; for (let r = q.r1; r <= q.r2; r++) for (let c = q.c1; c <= q.c2; c++) { const x = L.cellAt(tab, r, c); if (!(x && x.s && x.s[key])) return false; } return true; }; // tebal/miring: nyala bila SEMUA sel sudah bergaya itu (seperti Excel)
  function applyStyle(patch) {
    if (!sel) return; commit();
    const q = styleRect(), snap = ser(), undo = []; let any = false; const dropOnly = Object.values(patch).every((v) => v === null); // Rev 251 / S2: hanya menghapus gaya = sel kosong tidak perlu dibuat (seleksi penuh jadi murah)
    for (let r = q.r1; r <= q.r2; r++) for (let c = q.c1; c <= q.c2; c++) {
      const row = tab.rows[r], col = tab.cols[c]; if (!row || !col) continue; if (dropOnly && !row.cells[col.id]) continue;
      undo.push([row, col.id, JSON.stringify(row.cells[col.id] || null)]);
      if (L.setCell(tab, row.id, col.id, { s: patch })) any = true;
    }
    if (!any) { paintFmt(); return; }
    if (!L.fitsLimit(sheet)) { for (const [row, id, before] of undo) { if (before === 'null') delete row.cells[id]; else row.cells[id] = JSON.parse(before); } tooBig(); paintFmt(); return; }
    ver++, hist.push(snap); paintUndo();
    for (const k of ['bg', 'fg']) if (typeof patch[k] === 'string') recentCol[k] = WN.pushRecent(recentCol[k], patch[k]); // Rev 263
    palMode = null; touched(); lastKey = ''; drawRows(); paintFmt();
  }
  [bB, bI, bAL, bAC, bAR, bBg, bFg].forEach((b) => b.addEventListener('pointerdown', (e) => e.preventDefault())); // tidak mencuri fokus/keyboard dari bilah isian
  bB.onclick = () => applyStyle({ b: allHave('b') ? null : true });
  bI.onclick = () => applyStyle({ i: allHave('i') ? null : true });
  bAL.onclick = () => applyStyle({ ha: null }); bAC.onclick = () => applyStyle({ ha: 'center' }); bAR.onclick = () => applyStyle({ ha: 'end' }); // Rev 170: tiga tombol rata (kiri = bawaan)
  bBg.onclick = () => { palMode = palMode === 'bg' ? null : 'bg'; paintFmt(); };
  bFg.onclick = () => { palMode = palMode === 'fg' ? null : 'fg'; paintFmt(); };
  // --- Rev 120 / U7a-2c-2: Urungkan / Ulangi ---
  function paintUndo() { bU.disabled = !hist.canUndo(); bR.disabled = !hist.canRedo(); }
  const restore = (snap) => {
    let o; try { o = JSON.parse(snap); } catch (_) { return false; }
    if (!o || !Array.isArray(o.tabs) || !o.tabs.length) return false;
    const keep = tab.id; sheet.name = o.name; sheet.tabs = o.tabs;
    const same = sheet.tabs.find((t) => t.id === keep);
    if (same) { tab = same; if (sel && (!tab.rows[sel.r] || !tab.cols[sel.c])) sel = null; } else { tab = sheet.tabs[0]; sel = null; scroller.scrollTop = 0; scroller.scrollLeft = 0; }
    ver++; palMode = null; titleEl.textContent = sheet.name; touched(); changed(); paintUndo(); return true;
  };
  const stepHist = (back) => {
    commit(); // isian yang sedang diketik jadi satu langkah dulu
    const snap = back ? hist.undo(ser()) : hist.redo(ser()); if (snap === null) { paintUndo(); return; }
    if (!restore(snap)) { hist.clear(); paintUndo(); batas('Riwayat tidak bisa dipulihkan', 'Versi riwayat yang dipilih tidak bisa dibuka lagi.', 'Pilih versi lain, atau lanjutkan dengan lembar yang sekarang.'); }
  };
  [bU, bR].forEach((b) => b.addEventListener('pointerdown', (e) => e.preventDefault()));
  bS.addEventListener('pointerdown', (e) => e.preventDefault()); // Rev 130 (terpisah: tes rev120 mengunci baris [bU, bR])
  // --- Rev 130 / U8a-4b: tombol Σ. Mengisi kolom isian (belum menyimpan); rentang tidak ketemu = '=SUM(' agar saran/petunjuk muncul.
  bS.onclick = () => {
    if (!sel || val.disabled) return;
    const g = sumGuess(tab, sel.r, sel.c), text = g ? g.text : '=SUM(';
    try { val.focus(); } catch (_) {}
    val.value = text; try { val.setSelectionRange(text.length, text.length); } catch (_) {}
    val.dispatchEvent(new Event('input')); // pratinjau hasil + petunjuk argumen
  };
  bU.onclick = () => stepHist(true); bR.onclick = () => stepHist(false);
  const touched = () => { sheet.at = Date.now(); if (typeof onChange === 'function') onChange(sheet); };
  const changed = () => { lastKey = ''; refresh(true); };
  // --- Rev 141 / U9a-2: menu Lainnya (lembar bawah). Isi: Urutkan A\u2192Z, Urutkan Z\u2192A, Unduh CSV, Unduh TSV. Cari/ganti, Isi seri, Impor = U9a-3.
  const sortBy = (dir) => {
    commit(); if (!sel) { tWarn('Pilih sel di kolom yang mau diurutkan.'); return; }
    const snap = ser(), c = sel.c, res = sortTab(tab, c, dir);
    if (res && res.ok && res.moved) { ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar(); }
    toast(sortMessage(res, L.colLabel(c), dir));
  };
  const downloadAs = async (delim, ext, mime) => {
    commit(); const u = usedRange(tab); if (!u.rows) { tWarn('Tab ini masih kosong.'); return; }
    try {
      const { saveFiles } = await import('./share.js');
      const where = await saveFiles([{ name: exportName(sheet.name, tab.name, sheet.tabs.length > 1, ext), text: tabToDelimited(tab, delim), mime }]);
      toast('Tersimpan: ' + where);
    } catch (_) { batas('Berkas tidak tersimpan', 'Aplikasi tidak berhasil menulis berkas ke penyimpanan perangkat.', 'Cek sisa ruang penyimpanan dan izin berkas, lalu coba lagi.'); }
  };
  // --- Rev 142 / U9a-3a: Cari dan ganti (seluruh tab; teks TAMPIL dicari; Berikutnya menyorot sel; Ganti semua = satu langkah Urungkan).
  const openFind = () => {
    commit(); let pos = -1;
    const q = h('input', { class: 'in', type: 'text', placeholder: 'Cari', autocomplete: 'off', 'aria-label': 'Cari' }), rp = h('input', { class: 'in', type: 'text', placeholder: 'Ganti dengan', autocomplete: 'off', 'aria-label': 'Ganti dengan' });
    const mc = h('input', { type: 'checkbox' }), wh = h('input', { type: 'checkbox' }), stat = h('div', { class: 'lz-fstat', 'aria-live': 'polite' });
    const ov = h('div', { class: 'ov dlgov lz-more lz-find', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const opts = () => ({ matchCase: mc.checked, whole: wh.checked }), hits = () => findAll(tab, q.value, opts());
    const paint = () => { pos = -1; const n = q.value === '' ? -1 : hits().length; stat.textContent = n < 0 ? '' : n ? n + ' sel cocok' : 'Tidak ketemu'; };
    const next = () => {
      const l = hits(); if (!l.length) { paint(); return; }
      if (pos < 0 && sel) { const k = l.findIndex((m) => m.row > sel.r || (m.row === sel.r && m.col > sel.c)); pos = k < 0 ? -1 : k - 1; }
      pos = (pos + 1) % l.length; const m = l[pos]; sel = { r: m.row, c: m.col };
      { const o1 = getOrder(), l1 = layout(o1), k1 = o1 ? o1.indexOf(m.row) : m.row; scroller.scrollTop = Math.max(0, (k1 >= 0 ? l1.tops[k1] : 0) - ROW_H); } // Rev 184b: posisi baris = jumlah tinggi baris di atasnya
      scroller.scrollLeft = Math.max(0, colLeft(tab, m.col) - NUM_W); // Rev 275: gulir mendatar ke kolom hasil (sebelumnya ikut tertulis di dalam komentar di atas, jadi tidak pernah jalan)
      lastKey = ''; buildHead(); drawRows(); paintBar(); stat.textContent = (pos + 1) + ' dari ' + l.length;
    };
    const replaceNow = () => {
      if (q.value === '') { tWarn('Isi kolom Cari dulu.'); return; }
      const snap = ser(), res = replaceAll(tab, q.value, rp.value, opts());
      if (res.cells) {
        if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); ov.remove(); return; }
        ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar();
      }
      ov.remove(); (res.truncatedText ? tWarn : toast)(replaceMessage(res)); // Rev 332 / TD
    };
    q.addEventListener('input', paint); [mc, wh].forEach((c) => c.addEventListener('change', paint));
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); next(); } });
    const chk = (c, t) => h('label', { class: 'lz-chk' }, c, h('span', {}, t));
    ov.append(h('div', { class: 'sheet' }, h('h3', {}, 'Cari dan ganti'), q, rp, chk(mc, 'Huruf besar/kecil dibedakan'), chk(wh, 'Seluruh isi sel saja'), stat,
      h('div', { class: 'dlgb rev' }, h('button', { type: 'button', class: 'btn line', 'data-f': 'next', onclick: next }, 'Berikutnya'), h('button', { type: 'button', class: 'btn', 'data-f': 'all', onclick: replaceNow }, 'Ganti semua')),
      h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov); setTimeout(() => { try { q.focus(); } catch (_) {} }, 50);
  };
  // --- Rev 143 / U9a-3b: Isi seri (dari sel terpilih; sumber = m sel yang berakhir di sel terpilih; satu langkah Urungkan).
  const openFill = () => {
    commit(); if (!sel) { tWarn('Pilih sel dulu.'); return; }
    let dir = 'down'; const mk = (v, min, max, label) => h('input', { class: 'in', type: 'number', inputmode: 'numeric', min: String(min), max: String(max), value: String(v), 'aria-label': label });
    const srcN = mk(defaultSourceLen(tab, sel, dir), 1, 50, 'Jumlah sel sumber'), cnt = mk(10, 1, L.MAX_ROWS, 'Jumlah sel baru'), inc = h('input', { type: 'checkbox' }), pv = h('div', { class: 'lz-fstat', 'aria-live': 'polite' });
    const ov = h('div', { class: 'ov dlgov lz-more lz-find lz-fill', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const num = (el, lo, hi) => Math.min(hi, Math.max(lo, Math.floor(Number(el.value)) || lo));
    const room = () => (dir === 'right' ? sel.c + 1 : sel.r + 1);
    const state = () => { const m = Math.min(num(srcN, 1, 50), room()), n = num(cnt, 1, L.MAX_ROWS), src = fillSource(sel, m, dir); return { m, n, src }; };
    const paint = () => {
      const { m, n, src } = state(); const vals = []; let hasF = false; for (let p = 0; p < m; p++) { const r = dir === 'right' ? src.r1 : src.r1 + p, c = dir === 'right' ? src.c1 + p : src.c1; const cell = tab.rows[r].cells[tab.cols[c].id]; if (cell && cell.fx) hasF = true; vals.push(cell && !cell.fx ? cell.v : undefined); }
      let plan = seriesPlan(vals); if (hasF) plan = { kind: 'formula' }; if (plan.kind === 'copy-or-inc') plan = inc.checked ? { kind: 'linear', step: 1 } : { kind: 'copy' };
      pv.textContent = fillRangeText(src, n, dir) + ' \u00b7 pola: ' + patternLabel(plan);
    };
    const dbtn = (id, t) => h('button', { type: 'button', class: 'btn line lz-dir', 'data-dir': id, 'aria-pressed': id === dir ? 'true' : 'false', onclick: () => { dir = id; dirs.forEach((b) => b.setAttribute('aria-pressed', b.dataset.dir === dir ? 'true' : 'false')); srcN.value = String(defaultSourceLen(tab, sel, dir)); paint(); } }, t);
    const dirs = [dbtn('down', 'Ke bawah'), dbtn('right', 'Ke kanan')];
    const go = () => {
      const { m, n, src } = state(); const snap = ser(), res = fillSeries(tab, src, n, { dir, inc: inc.checked });
      if (res.filled) {
        if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); ov.remove(); return; }
        ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar();
      }
      ov.remove(); toast(fillMessage(res));
    };
    [srcN, cnt].forEach((el) => el.addEventListener('input', paint)); inc.addEventListener('change', paint);
    const field = (t, el) => h('label', { class: 'lz-fld' }, h('span', {}, t), el);
    ov.append(h('div', { class: 'sheet' }, h('h3', {}, 'Isi seri'), h('div', { class: 'dlgb lz-dirs' }, ...dirs),
      field('Jumlah sel sumber (berakhir di sel terpilih)', srcN), field('Jumlah sel baru', cnt),
      h('label', { class: 'lz-chk' }, inc, h('span', {}, 'Angka tunggal naik +1')), pv,
      h('div', { class: 'dlgb rev' }, h('button', { type: 'button', class: 'btn', 'data-f': 'fill', onclick: go }, 'Isi'))
      , h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov); paint();
  };
  // --- Rev 144 / U9a-3c: Impor CSV/TSV (pemilih berkas -> ringkasan -> Ganti isi tab / Tempel dari sel terpilih; satu langkah Urungkan).
  const openImport = () => {
    commit(); const inp = h('input', { type: 'file', accept: '.csv,.tsv,.txt,text/csv,text/tab-separated-values,text/plain', style: 'display:none', 'aria-label': 'Pilih berkas CSV atau TSV' });
    inp.addEventListener('change', async () => {
      const f = inp.files && inp.files[0]; inp.remove(); if (!f) return;
      if (f.size > IMPORT_MAX_BYTES) { batas('Berkas terlalu besar', 'Berkas yang kamu pilih lebih dari 2 MB, melebihi batas impor.', 'Pilih berkas yang lebih kecil, atau bagi datanya jadi beberapa berkas.'); return; }
      let text = ''; try { text = await f.text(); } catch (_) { batas('Berkas tidak bisa dibaca', 'Isi berkas tidak bisa dibaca sebagai tabel.', 'Pastikan berkasnya CSV atau lembar yang valid dan tidak rusak, lalu coba lagi.'); return; }
      text = text.replace(/^\uFEFF/, ''); const sm = importSummary(text); if (!sm.rows) { tWarn('Berkas kosong.'); return; }
      const run = (replace) => {
        const snap = ser(), res = importDelimited(tab, text, { delim: sm.delim, row: replace ? 0 : sel.r, col: replace ? 0 : sel.c, replace });
        if (res.ok && res.written) {
          if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); return; }
          ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar();
        }
        (res.truncatedText || res.truncatedRows || res.truncatedCols ? tWarn : toast)(importMessage(res)); // Rev 332 / TD: ada yang dipotong = nada peringatan
      };
      const ov = h('div', { class: 'ov dlgov lz-more lz-imp', onclick: (e) => { if (e.target === ov) ov.remove(); } });
      const go = (replace) => () => { ov.remove(); run(replace); };
      ov.append(h('div', { class: 'sheet' }, h('h3', {}, 'Impor ' + f.name.slice(0, 40)),
        h('div', { class: 'lz-fstat' }, sm.rows + ' baris \u00d7 ' + sm.cols + ' kolom \u00b7 pemisah ' + DELIM_NAME[sm.delim] + '. Maks. ' + L.MAX_COLS + ' kolom \u00d7 ' + L.MAX_ROWS + ' baris; selebihnya dipotong.'),
        h('button', { type: 'button', class: 'btn', 'data-f': 'replace', onclick: go(true) }, 'Ganti isi tab ini'),
        sel ? h('button', { type: 'button', class: 'btn line', 'data-f': 'paste', onclick: go(false) }, 'Tempel dari sel ' + L.colLabel(sel.c) + (sel.r + 1)) : null,
        h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Batal')));
      document.body.append(ov);
    });
    document.body.append(inp); inp.click();
  };
  // --- Rev 267: kepala dialog bersama (ubin ikon + judul + keterangan + tombol tutup) untuk Warna bersyarat, Validasi data, dan Pilih; hanya tampilan, warna lewat variabel tema.
  const dlgHead = (tone, iconPath, title, sub, ov) => h('div', { class: 'vd-h', 'data-tone': tone }, h('i', { class: 'vd-ic', 'aria-hidden': 'true' }, ico(iconPath)), h('div', { class: 'vd-ht' }, h('h3', {}, title), h('p', {}, sub)), h('button', { type: 'button', class: 'vd-x', 'aria-label': 'Tutup', onclick: () => ov.remove() }, ico('M6 6l12 12M18 6L6 18')));
  // --- Rev 146 / U9b-2b: Warna bersyarat. Aturan berlaku pada KOLOM sel terpilih; aturan teratas didahulukan; hanya tampilan (nilai sel tidak berubah); satu langkah Urungkan per perubahan.
  // Rev 267: tampilan baru (kepala berikon, kartu aturan, pil warna berwarna asli); logika, data, dan penanda uji TIDAK berubah.
  const RULE_OPS_UI = [['gt', 'Lebih dari'], ['gte', 'Minimal'], ['lt', 'Kurang dari'], ['lte', 'Maksimal'], ['between', 'Antara'], ['eq', 'Sama dengan'], ['ne', 'Bukan'], ['scale', 'Skala warna']];
  const RULE_PRESETS = [{ label: 'Merah', bg: '#FECACA' }, { label: 'Kuning', bg: '#FDE68A' }, { label: 'Hijau', bg: '#BBF7D0' }, { label: 'Biru', bg: '#BFDBFE' }, { label: 'Teks merah', fg: '#DC2626' }, { label: 'Teks hijau', fg: '#16A34A' }];
  const SCALE_PRESETS = [{ label: 'Merah → hijau', lo: '#FECACA', hi: '#BBF7D0' }, { label: 'Putih → biru', lo: '#FFFFFF', hi: '#93C5FD' }, { label: 'Putih → hijau', lo: '#FFFFFF', hi: '#86EFAC' }];
  const parseRuleNum = (t) => { const x = String(t).trim().replace(',', '.'); if (!x) return null; const n = Number(x); return Number.isFinite(n) ? n : null; }; // koma desimal Indonesia
  const openRules = () => {
    commit(); if (!sel) { tWarn('Pilih sel dulu.'); return; }
    const colId = tab.cols[sel.c].id; let op = 'gt', pick = 0, spick = 0;
    const ov = h('div', { class: 'ov dlgov lz-more lz-find lz-rules lz-vd', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const list = h('div', { class: 'lz-rlist' });
    const swatch = (r) => { const s = h('span', { class: 'lz-sw', 'aria-hidden': 'true' }); if (r.op === 'scale') s.style.background = 'linear-gradient(90deg,' + r.lo + ',' + r.hi + ')'; else { if (r.bg) s.style.background = r.bg; if (r.fg) { s.style.color = r.fg; s.textContent = 'A'; } } return s; };
    const apply = (next) => {
      const snap = ser(); if (!L.setRules(tab, next)) return false;
      if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); return false; }
      ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar(); paintList(); return true;
    };
    const paintList = () => {
      list.textContent = ''; const rules = tab.rules || [];
      if (!rules.length) { list.append(h('div', { class: 'lz-fstat vd-empty' }, 'Belum ada aturan di tab ini.')); return; }
      rules.forEach((r) => { const ci = tab.cols.findIndex((c) => c.id === r.c); list.append(h('div', { class: 'lz-rrow', 'data-rule': r.id }, swatch(r), h('span', { class: 'lz-rt' }, ruleText(r, L.colLabel(ci))), h('button', { type: 'button', class: 'lz-rdel', 'aria-label': 'Hapus aturan', onclick: () => { apply(rules.filter((x) => x.id !== r.id)); } }, '×'))); });
    };
    const opSel = h('select', { class: 'in lz-rop', 'aria-label': 'Jenis aturan' }, ...RULE_OPS_UI.map(([k, t]) => h('option', { value: k }, t)));
    const inA = h('input', { class: 'in', type: 'text', inputmode: 'decimal', autocomplete: 'off', 'aria-label': 'Nilai' }), inB = h('input', { class: 'in', type: 'text', inputmode: 'decimal', autocomplete: 'off', placeholder: 'Sampai angka', 'aria-label': 'Sampai angka' });
    const chips = (arr, get, set, cls) => { const row = h('div', { class: 'lz-chips ' + cls }); const bs = arr.map((p, i) => { const b = h('button', { type: 'button', class: 'btn line lz-pc', 'aria-pressed': i === get() ? 'true' : 'false', onclick: () => { set(i); bs.forEach((x, k) => x.setAttribute('aria-pressed', k === i ? 'true' : 'false')); } }, swatch(p.lo ? { op: 'scale', lo: p.lo, hi: p.hi } : p), h('span', {}, p.label)); return b; }); row.append(...bs); return row; };
    const presets = chips(RULE_PRESETS, () => pick, (i) => { pick = i; }, 'lz-presets'), scales = chips(SCALE_PRESETS, () => spick, (i) => { spick = i; }, 'lz-scales');
    const sync = () => { const sc = op === 'scale'; inA.hidden = sc; inB.hidden = op !== 'between'; presets.hidden = sc; scales.hidden = !sc; inA.placeholder = op === 'eq' || op === 'ne' ? 'Angka atau teks' : op === 'between' ? 'Dari angka' : 'Angka'; };
    opSel.addEventListener('change', () => { op = opSel.value; sync(); }); sync();
    const add = () => {
      if ((tab.rules || []).length >= MAX_RULES) { batas('Batas aturan tercapai', 'Satu tab hanya boleh punya ' + MAX_RULES + ' aturan.', 'Hapus salah satu aturan lama dulu, lalu tambahkan lagi.'); return; }
      const rule = { id: '', c: colId, op };
      if (op === 'scale') { const p = SCALE_PRESETS[spick]; rule.lo = p.lo; rule.hi = p.hi; }
      else {
        if (op === 'eq' || op === 'ne') { const t = inA.value.trim(); if (!t) { tWarn('Isi nilainya dulu.'); return; } const n = parseRuleNum(t); rule.a = n === null ? t : n; }
        else { const a = parseRuleNum(inA.value); if (a === null) { tWarn('Isi angka yang valid.'); return; } rule.a = a; if (op === 'between') { const b = parseRuleNum(inB.value); if (b === null) { tWarn('Isi angka “sampai” yang valid.'); return; } rule.b = b; } }
        const p = RULE_PRESETS[pick]; if (p.bg) rule.bg = p.bg; if (p.fg) rule.fg = p.fg;
      }
      if (apply([...(tab.rules || []), rule])) { inA.value = ''; inB.value = ''; tOk('Aturan ditambahkan.'); }
    };
    paintList();
    ov.append(h('div', { class: 'sheet vd-sheet' }, dlgHead('warna', PATH.palette, 'Warna bersyarat', 'Isi sel berwarna otomatis menurut nilainya. Isi sel tetap.', ov),
      h('div', { class: 'vd-sec' }, 'Aturan di tab ini'), list,
      h('div', { class: 'vd-card' }, h('h4', { class: 'lz-rh' }, 'Aturan baru untuk kolom ' + L.colLabel(sel.c)), h('div', { class: 'vd-note' }, 'Aturan teratas didahulukan.'), opSel, inA, inB, presets, scales),
      h('div', { class: 'dlgb rev' }, h('button', { type: 'button', class: 'btn', 'data-f': 'add', onclick: add }, 'Tambah aturan')),
      h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov);
  };
  // --- Rev 148 / U9b-3b: Validasi data (pilihan). Sel di luar daftar hanya DITANDAI (impor/tempel/isi seri tidak pernah gagal karenanya); satu langkah Urungkan per perubahan.
  // Rev 267: lembar pilih = baris berwarna sesuai warna pilihan (bila ada) + centang pada pilihan sekarang; aturan dicari menurut RENTANG (checkAt), bukan hanya kolom.
  const openPick = () => {
    commit(); if (!sel) { tWarn('Pilih sel dulu.'); return; }
    const row = tab.rows[sel.r], col = tab.cols[sel.c], ck = row && col ? checkAt(tab, sel.r, sel.c) : null; if (!ck || (ck.k && ck.k !== 'list')) { tWarn('Kolom ini belum punya daftar pilihan.'); return; }
    const pc = L.cellAt(tab, sel.r, sel.c); if (hasFx(pc)) { batas('Sel ini berumus', 'Pilihan dari daftar tidak bisa menggantikan rumus yang ada di sel ini.', 'Hapus rumusnya dulu, lalu pilih lagi.'); return; }
    liveSrc(); const curText = displayValue(pc), now = validate(ck, curText).match;
    const ov = h('div', { class: 'ov dlgov lz-more lz-pick lz-vd', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const write = (v) => {
      ov.remove(); const snap = ser();
      if (!L.setCell(tab, row.id, col.id, { v })) return;
      if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); return; }
      ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar();
    };
    const btns = ck.items.map((it) => { const e = ck.cl && ck.cl[it] ? ck.cl[it] : null, b = h('button', { type: 'button', class: 'lz-mi vp-it' + (it === now ? ' on' : ''), 'data-pick': it, 'aria-pressed': String(it === now), onclick: () => write(it) }, h('b', {}, it), h('i', { class: 'vp-ck', 'aria-hidden': 'true' }, ico('M5 12l5 5 9-10')));
      if (e && e.bg) { b.classList.add('tint'); b.style.background = e.bg; b.style.color = e.fg || WN.inkOn(e.bg); } else if (e && e.fg) b.style.color = e.fg; return b; });
    ov.append(h('div', { class: 'sheet vd-sheet' }, dlgHead('validasi', 'M4 6h16v12H4zM9 11l3 3 3-3', 'Pilih untuk ' + L.cellAddr(sel.c, sel.r), 'Ketuk satu pilihan untuk mengisi sel.', ov), h('div', { class: 'vp-list' }, ...btns),
      curText ? h('button', { type: 'button', class: 'btn line lz-mx', 'data-pick-clear': '1', onclick: () => write(null) }, 'Kosongkan sel') : h('span', { class: 'lz-fstat' }, 'Sel masih kosong.'),
      h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov);
  };
  bP.addEventListener('pointerdown', (e) => e.preventDefault()); bP.onclick = openPick;
  // Rev 267 / V2+V3: editor Validasi data model spreadsheet: Rentang sel (diketik; bawaan dari seleksi), daftar pilihan BERWARNA (titik warna -> palet; baris ikut berwarna = pratinjau persis isi sel),
  // sakelar panah pilihan, pratinjau, Simpan / Hapus aturan. Beberapa aturan per tab (chip di atas). Warna melekat pada ATURAN (bukan gaya tiap sel). Mode Tolak/Beri tanda = Rev 269 / V4.
  const openChecks = () => {
    commit(); if (!sel) { tWarn('Pilih sel dulu.'); return; }
    let editing = checkAt(tab, sel.r, sel.c), rows = [], dd = true, palFor = -1, kind = 'list', op = 'gt', manual = [], stash = new Map();
    const ov = h('div', { class: 'ov dlgov lz-more lz-find lz-rules lz-checks lz-vd', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const apply = (next) => {
      const snap = ser(); if (!L.setChecks(tab, next)) return false;
      if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); return false; }
      ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar(); return true;
    };
    const strip = h('div', { class: 'vd-strip' }), rg = h('input', { class: 'in vd-rg', type: 'text', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', 'aria-label': 'Rentang sel', placeholder: 'mis. B2:B30' });
    const itemsEl = h('div', { class: 'vd-items' }), cnt = h('span', { class: 'vd-cnt' }), pv = h('div', { class: 'vd-pv', 'aria-label': 'Pratinjau pilihan' });
    const sw = h('button', { type: 'button', class: 'vd-sw', role: 'switch', 'data-f': 'dd', onclick: () => { dd = !dd; sw.setAttribute('aria-checked', String(dd)); } }, h('i', { 'aria-hidden': 'true' }));
    const rgNote = h('div', { class: 'vd-note' }); // Rev 276 / W1: catatan rentang + pemberitahuan bila sudah ada aturan di area itu
    const paintOvl = () => { const rc = parseRange(rg.value, tab), o = rc ? overlapChecks(tab, rc, editing && editing.id) : []; rgNote.classList.toggle('warn', !!o.length); rgNote.textContent = o.length ? 'Perhatian: area ini sudah punya aturan (' + o.map((x) => rangeText(tab, x)).join(', ') + '). Aturan baru tetap boleh dipasang; sel diperiksa terhadap semua aturan.' : 'Contoh: B2:B30, atau B:B untuk satu kolom penuh.'; };
    rg.addEventListener('input', paintOvl);
    // Rev 271 / V5b: kartu Kriteria (daftar pilihan | teks berisi/tidak berisi/sama persis | email | URL | angka | tanggal). Hanya 'Daftar pilihan' memakai kartu Pilihan + panah.
    const KIND_OPTS = [['list', 'Daftar pilihan'], ['range', 'Daftar dari rentang'], ['has', 'Teks berisi'], ['hasnot', 'Teks tidak berisi'], ['same', 'Teks sama persis'], ['email', 'Email valid'], ['url', 'URL valid'], ['num', 'Angka'], ['date', 'Tanggal'], ['box', 'Kotak centang']];
    const kindSel = h('select', { class: 'in vd-kind', 'aria-label': 'Kriteria' }, ...KIND_OPTS.map(([k, t]) => h('option', { value: k }, t))), opSel = h('select', { class: 'in vd-op', 'aria-label': 'Syarat' });
    const vIn = h('input', { class: 'in vd-v', type: 'text', autocomplete: 'off', maxlength: '60', 'aria-label': 'Teks', placeholder: 'Teks yang dicari' }), aIn = h('input', { class: 'in vd-a', type: 'text', autocomplete: 'off', 'aria-label': 'Nilai pertama' }), bIn = h('input', { class: 'in vd-b', type: 'text', autocomplete: 'off', 'aria-label': 'Nilai kedua' });
    const srcIn = h('input', { class: 'in vd-src', type: 'text', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', 'aria-label': 'Rentang sumber pilihan', placeholder: 'mis. D2:D10' });
    const critEl = h('div', { class: 'vd-crit' }, srcIn, opSel, vIn, h('div', { class: 'vd-two' }, aIn, bIn)), critNote = h('div', { class: 'vd-note' });
    const defOp = (k) => (k === 'date' ? 'bf' : 'gt'), ucf = (t) => t.charAt(0).toUpperCase() + t.slice(1);
    const paintCrit = () => {
      kindSel.value = kind; const isNum = kind === 'num', isDate = kind === 'date', isTxt = kind === 'has' || kind === 'hasnot' || kind === 'same', n = isNum || isDate ? operands(op) : 0;
      srcIn.hidden = kind !== 'range'; opSel.hidden = !(isNum || isDate); vIn.hidden = !isTxt; aIn.hidden = n < 1; bIn.hidden = n < 2; critEl.hidden = kind === 'list' || kind === 'email' || kind === 'url' || kind === 'box';
      if (isNum || isDate) { opSel.textContent = ''; (isNum ? ['gt', 'ge', 'lt', 'le', 'eq', 'ne', 'bt', 'nb'] : ['ok', 'eq', 'bf', 'af', 'obf', 'oaf', 'bt', 'nb']).forEach((o) => opSel.append(h('option', { value: o }, ucf(kindLabel(kind, o))))); opSel.value = op; }
      aIn.placeholder = isDate ? 'dd/mm/yyyy' : 'Angka'; bIn.placeholder = isDate ? 'dd/mm/yyyy' : 'Angka'; aIn.inputMode = isNum ? 'decimal' : 'text'; bIn.inputMode = isNum ? 'decimal' : 'text';
      critNote.textContent = kind === 'list' ? '' : kind === 'box' ? 'Sel di rentang jadi kotak centang: ketuk sel untuk mencentang atau melepas (nilai TRUE/FALSE, bisa dihitung rumus, mis. COUNTIF). Sel berisi teks lain ditandai tidak sah.' : kind === 'range' ? 'Pilihan diambil dari isi sel di rentang ini dan ikut berubah saat selnya berubah (kembar dan kosong dilewati, maks. ' + MAX_ITEMS + '). Ketuk titik di kartu Pilihan untuk mewarnai; warna diingat per teks.' : kind === 'email' ? 'Isian harus berupa alamat email, mis. nama@contoh.com.' : kind === 'url' ? 'Isian harus berupa alamat web, mis. contoh.com atau https://contoh.com.' : isNum ? 'Angka boleh ditulis 1.500, 2,5, atau 25%.' : isDate ? 'Tanggal ditulis hari/bulan/tahun, mis. 31/12/2026.' : 'Pencocokan ' + (kind === 'same' ? 'peka huruf besar-kecil.' : 'tidak peka huruf besar-kecil.');
      listCards.forEach((c) => { c.hidden = kind !== 'list' && kind !== 'range'; }); addB.hidden = kind === 'range';
    };
    // Rev 284: daftar bersumber = baris dari isi rentang (hanya baca) + warna per teks di `stash` (bertahan walau isi berubah)
    const blank3 = () => [{ t: '', bg: '', fg: '' }, { t: '', bg: '', fg: '' }, { t: '', bg: '', fg: '' }];
    const syncRows = () => { const q = parseRange(srcIn.value, tab), it = q ? itemsFromRange(tab, { c1: tab.cols[q.c1].id, c2: tab.cols[q.c2].id, r1: tab.rows[q.r1].id, r2: tab.rows[q.r2].id }, makeDisplay(tab).text) : []; rows = it.map((t) => { const e = stash.get(t) || {}; return { t, bg: e.bg || '', fg: e.fg || '' }; }); };
    kindSel.onchange = () => { const was = kind; kind = kindSel.value; op = defOp(kind); if (kind === 'range' && was !== 'range') { manual = rows; syncRows(); } else if (was === 'range' && kind !== 'range') rows = manual.length ? manual : blank3(); palFor = -1; paint(); };
    let tmSrc = 0; const resync = () => { if (kind !== 'range') return; const was = rows.map((r) => r.t).join('\n'); syncRows(); if (rows.map((r) => r.t).join('\n') !== was) { palFor = -1; paintItems(); } }; // tidak menggambar ulang bila daftar sama; jeda 350 ms agar kartu tidak melompat tepat saat tombol diketuk
    srcIn.addEventListener('input', () => { clearTimeout(tmSrc); tmSrc = setTimeout(resync, 350); }); srcIn.addEventListener('change', resync);
    opSel.onchange = () => { op = opSel.value; paintCrit(); };
    const listCards = [];
    const addB = h('button', { type: 'button', class: 'btn line vd-add', 'data-f': 'addrow', onclick: () => addRow() }, '+ Tambah pilihan'), sub = h('div', { class: 'vd-sec' }), delB = h('button', { type: 'button', class: 'btn line lz-mx vd-del', 'data-f': 'del' }, 'Hapus aturan');
    const tintOf = (el, r) => { el.classList.toggle('tint', !!r.bg); el.style.background = r.bg || ''; el.style.color = r.bg ? (r.fg || WN.inkOn(r.bg)) : (r.fg || ''); };
    const paintPv = () => { pv.textContent = ''; rows.filter((r) => r.t.trim()).forEach((r) => { const c = h('span', { class: 'vd-pc' }, r.t.trim().slice(0, 40)); tintOf(c, r); pv.append(c); }); pv.hidden = !pv.firstChild; };
    const mkPal = (i) => {
      const r = rows[i], box = h('div', { class: 'vd-pal', 'data-pal': String(i) });
      const set = (bg) => { r.bg = bg; r.fg = ''; if (kind === 'range') stash.set(r.t, { bg, fg: '' }); palFor = -1; paint(); };
      box.append(...ITEM_COLORS.map((c) => { const b = h('button', { type: 'button', class: 'vd-swc' + (r.bg === c ? ' on' : ''), 'aria-label': 'Warna ' + c, onclick: () => set(c) }); b.style.background = c; return b; }));
      // Rev 296: "+" membuka panel roda warna aplikasi (openColorPanel), BUKAN dialog warna bawaan Android (input type=color)
      const own = h('button', { type: 'button', class: 'vd-swc vd-more', 'aria-label': 'Warna lain (roda warna)', title: 'Warna lain', onclick: () => openColorPanel('bg', { title: 'Warna pilihan', start: r.bg, ctx: { fg: r.fg, bg: r.bg }, ref: r.t.trim().slice(0, 20), onApply: (c) => set(c.toUpperCase()), onReset: () => set('') }) });
      box.append(own, h('button', { type: 'button', class: 'vd-none', onclick: () => set('') }, 'Tanpa warna'));
      return box;
    };
    const paintItems = () => {
      itemsEl.textContent = ''; cnt.textContent = rows.length + '/' + MAX_ITEMS; const R = kind === 'range'; // Rev 284: daftar bersumber = baris hanya-baca, hanya warna yang bisa diubah
      rows.forEach((r, i) => {
        const inp = h('input', { class: 'in vd-ti', type: 'text', ...(R ? { readonly: '' } : {}), maxlength: String(MAX_ITEM_LEN), autocomplete: 'off', 'aria-label': 'Pilihan ' + (i + 1), placeholder: 'Pilihan ' + (i + 1), value: r.t });
        const line = h('div', { class: 'vd-it', 'data-i': String(i) }, h('button', { type: 'button', class: 'vd-dot', 'aria-label': 'Warna pilihan ' + (i + 1), 'aria-expanded': String(palFor === i), onclick: () => { palFor = palFor === i ? -1 : i; paint(); } }), inp,
          R ? h('span', { class: 'vd-mv ph' }) : i > 0 ? h('button', { type: 'button', class: 'vd-mv', 'aria-label': 'Naikkan pilihan ' + (i + 1), onclick: () => { [rows[i - 1], rows[i]] = [rows[i], rows[i - 1]]; palFor = -1; paint(); } }, ico('M12 19V6M6 12l6-6 6 6')) : h('span', { class: 'vd-mv ph' }),
          R ? h('span', { class: 'vd-mv ph' }) : h('button', { type: 'button', class: 'vd-rm', 'aria-label': 'Hapus pilihan ' + (i + 1), onclick: () => { rows.splice(i, 1); if (!rows.length) rows.push({ t: '', bg: '', fg: '' }); palFor = -1; paint(); } }, '×'));
        tintOf(line, r); const dot = line.firstChild; dot.style.background = r.bg || ''; dot.classList.toggle('none', !r.bg);
        if (R) { itemsEl.append(line); if (palFor === i) itemsEl.append(mkPal(i)); return; }
        inp.addEventListener('input', () => { r.t = inp.value; paintPv(); });
        inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addRow(i + 1); } });
        inp.addEventListener('paste', (e) => { // tempel banyak pilihan sekaligus (satu per baris / dipisah koma): dipecah jadi baris-baris
          const t = e.clipboardData && e.clipboardData.getData ? e.clipboardData.getData('text') : ''; if (!/[\n\r,;]/.test(t)) return; e.preventDefault();
          const parts = itemsFromText(t); if (!parts.length) return; const room = MAX_ITEMS - rows.length + 1; const take = parts.slice(0, Math.max(1, room));
          rows.splice(i, 1, ...take.map((x, k) => (k === 0 ? { ...r, t: x } : { t: x, bg: '', fg: '' }))); if (take.length < parts.length) toast('Hanya ' + MAX_ITEMS + ' pilihan yang muat.'); palFor = -1; paint();
        });
        itemsEl.append(line); if (palFor === i) itemsEl.append(mkPal(i));
      });
      paintPv();
    };
    const addRow = (at) => { if (rows.length >= MAX_ITEMS) { batas('Batas pilihan tercapai', 'Satu daftar pilihan hanya boleh berisi ' + MAX_ITEMS + ' pilihan.', 'Hapus pilihan yang tidak dipakai, lalu tambahkan lagi.'); return; } rows.splice(at === undefined ? rows.length : at, 0, { t: '', bg: '', fg: '' }); palFor = -1; paint(); const el = itemsEl.querySelector('[data-i="' + (at === undefined ? rows.length - 1 : at) + '"] input'); if (el) el.focus(); };
    const paintStrip = () => {
      strip.textContent = ''; const cks = tab.checks || []; strip.hidden = !cks.length; if (!cks.length) return;
      cks.forEach((ck) => strip.append(h('button', { type: 'button', class: 'vd-chip', 'data-check': ck.id, 'aria-pressed': String(!!editing && editing.id === ck.id), onclick: () => load(ck) }, rangeText(tab, ck) || '?', h('em', {}, ' · ' + (ck.src ? 'Rentang' : ck.k && ck.k !== 'list' ? ({ has: 'Berisi', hasnot: 'Tak berisi', same: 'Persis', email: 'Email', url: 'URL', num: 'Angka', date: 'Tanggal', box: 'Kotak' })[ck.k] : ck.items.length)))));
      strip.append(h('button', { type: 'button', class: 'vd-chip new', 'data-f': 'new', 'aria-pressed': String(!editing), onclick: () => load(null) }, '+ Baru'));
    };
    const defaultRange = () => { normSel(); const rc = selx && selx.rect && !SX.isSingle(selx) ? selx.rect : null, p = rc ? partsFromRect(tab, rc, false) : { c: tab.cols[sel.c].id, rg: null }; return rangeText(tab, { c: p.c, rg: p.rg }) || ''; };
    function paint() {
      paintStrip(); sub.textContent = editing ? 'Ubah aturan' : 'Aturan baru'; sw.setAttribute('aria-checked', String(dd)); paintOvl(); delB.hidden = !editing; paintItems(); paintCrit();
    }
    function load(ck) {
      editing = ck || null;
      kind = ck && ck.src ? 'range' : ck && ck.k ? ck.k : 'list'; srcIn.value = ck && ck.src ? rangeText(tab, { c: ck.src.c1, rg: { c2: ck.src.c2, r1: ck.src.r1, r2: ck.src.r2 } }) || '' : ''; op = ck && ck.op ? ck.op : defOp(kind); vIn.value = ck && ck.v ? ck.v : ''; const nv = (x) => (x === undefined ? '' : kind === 'date' ? serialText(x) || '' : String(x).replace('.', ',')); aIn.value = ck ? nv(ck.a) : ''; bIn.value = ck ? nv(ck.b) : '';
      stash = new Map(Object.entries(ck && ck.src && ck.cl ? ck.cl : {})); manual = [];
      if (ck) { rows = kind === 'list' ? itemRowsOf(ck) : blank3(); rg.value = rangeText(tab, ck) || ''; dd = ck.dd !== false; if (kind === 'range') syncRows(); } else { rows = blank3(); rg.value = defaultRange(); dd = true; }
      palFor = -1; paint();
    }
    const save = () => {
      const isR = kind === 'range', list = kind === 'list' || isR; let { items, cl } = kind === 'list' ? itemsFromRows(rows) : { items: [], cl: {} }; if (kind === 'list' && !items.length) { tWarn('Isi minimal satu pilihan.'); return; }
      let sr = null; if (isR) { const q = parseRange(srcIn.value, tab); if (!q) { tWarn('Rentang sumber tidak sah. Contoh: D2:D10.'); return; } sr = { c1: tab.cols[q.c1].id, c2: tab.cols[q.c2].id, r1: tab.rows[q.r1].id, r2: tab.rows[q.r2].id }; items = itemsFromRange(tab, sr, makeDisplay(tab).text); cl = {}; for (const t of [...items, ...stash.keys()]) { const e = stash.get(t); if (e && e.bg && !Object.prototype.hasOwnProperty.call(cl, t)) cl[t] = e; } } // Rev 284: warna per teks; teks yang sedang ada didahulukan
      const crit = { k: kind }; // Rev 271: bidang kriteria non-daftar (dicek di sini supaya pesannya jelas; cleanCheck tetap penjaga akhir)
      if (kind === 'has' || kind === 'hasnot' || kind === 'same') { crit.v = vIn.value.trim(); if (!crit.v) { tWarn('Isi teks yang dicari.'); return; } }
      if (kind === 'num' || kind === 'date') {
        const pr = kind === 'num' ? parseNumText : parseDateText, bad = kind === 'num' ? 'Isi angka yang sah, mis. 100 atau 2,5.' : 'Tulis tanggal sah seperti 31/12/2026.', n = operands(op); crit.op = op;
        if (n >= 1) { crit.a = pr(aIn.value); if (crit.a === null) { toast(bad); return; } } if (n >= 2) { crit.b = pr(bIn.value); if (crit.b === null) { toast(bad); return; } }
      }
      const rc = parseRange(rg.value, tab); if (!rc) { batas('Rentang tidak sah', 'Penulisan rentang tidak dikenali.', 'Tulis seperti B2:B30, atau B:B untuk satu kolom penuh.'); return; }
      const p = partsFromRect(tab, rc, rc.open), next = { id: editing ? editing.id : '', c: p.c, ...(list ? { k: 'list', items } : crit) }; if (p.rg) next.rg = p.rg; if (Object.keys(cl).length) next.cl = cl; if (sr) next.src = sr; if (list && !dd) next.dd = false;
      const cur = tab.checks || []; if (!editing && cur.length >= MAX_CHECKS) { batas('Batas validasi tercapai', 'Satu tab hanya boleh punya ' + MAX_CHECKS + ' aturan validasi data.', 'Hapus validasi yang tidak dipakai dulu, lalu tambahkan lagi.'); return; }
      const txt = rangeText(tab, next), ovl = overlapChecks(tab, rc, editing && editing.id).length; // Rev 276: aturan kembar/beririsan boleh, hanya diberi tahu
      const asked = isR ? 0 : rows.filter((r) => String(r.t).trim()).length, listNext = editing ? cur.map((x) => (x.id === editing.id ? next : x)) : [...cur, next];
      if (apply(listNext)) { ov.remove(); toast((isR ? 'Daftar dari ' + srcIn.value.trim().toUpperCase() : list ? items.length + ' pilihan' : 'Aturan') + ' disimpan untuk ' + txt + '.' + (list && asked > items.length ? ' ' + (asked - items.length) + ' dilewati (kembar atau melebihi batas).' : '') + (ovl ? ' Area ini juga punya ' + ovl + ' aturan lain; sel yang melanggar salah satunya ditandai.' : '')); }
    };
    // Rev 274 / V6c: lompat ke sel tidak sah berikutnya (setelah sel terpilih, berputar); hanya menggeser pilihan + gulir, tidak mengubah data.
    const goBad = () => { const m = nextInvalid(getIV(), getOrder(), sel); if (!m) { tOk('Tidak ada data yang tidak sah.'); return; } ov.remove(); goTo(m); };
    delB.onclick = () => { if (!editing) return; const id = editing.id; if (apply((tab.checks || []).filter((x) => x.id !== id))) { ov.remove(); tOk('Aturan dihapus.'); } };
    ov.append(h('div', { class: 'sheet vd-sheet' }, dlgHead('validasi', 'M4 6h16v12H4zM9 11l3 3 3-3', 'Validasi data', 'Batasi isi sel: daftar pilihan berwarna, teks, angka, tanggal, email, atau URL.', ov), strip, sub,
      h('div', { class: 'vd-card' }, h('label', { class: 'vd-lb' }, 'Rentang sel'), rg, rgNote),
      h('div', { class: 'vd-card' }, h('label', { class: 'vd-lb' }, 'Kriteria'), kindSel, critEl, critNote),
      listCards[0] = h('div', { class: 'vd-card' }, h('div', { class: 'vd-lbr' }, h('label', { class: 'vd-lb' }, 'Pilihan'), cnt), itemsEl,
        addB, pv),
      listCards[1] = h('div', { class: 'vd-card vd-row' }, h('div', { class: 'vd-sx' }, h('b', {}, 'Tampilkan panah pilihan'), h('span', {}, 'Panah kecil di sel; ketuk sel terpilih untuk membuka daftar.')), sw),
      h('div', { class: 'dlgb rev' }, h('button', { type: 'button', class: 'btn', 'data-f': 'save', onclick: save }, 'Simpan')), delB,
      h('button', { type: 'button', class: 'btn line lz-mx', 'data-f': 'goBad', onclick: goBad }, 'Lompat ke data tidak sah'),
      h('button', { type: 'button', class: 'btn line lz-mx', 'data-f': 'hist', onclick: () => { ov.remove(); openHist(); } }, 'Riwayat error'),
      h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    load(editing); document.body.append(ov);
  };
  // --- Rev 149 / U9b-1: Filter baris SEMENTARA (tidak disimpan, tanpa Urungkan). Berlaku pada KOLOM sel terpilih.
  const openFilter = () => {
    commit(); if (!sel) { tWarn('Pilih sel dulu.'); return; }
    const colId = tab.cols[sel.c].id, colName = L.colLabel(sel.c), cur = flt && flt.tabId === tab.id && flt.c === colId ? flt : null;
    const ov = h('div', { class: 'ov dlgov lz-more lz-find lz-rules lz-fltd', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const kSel = h('select', { class: 'in lz-rop', 'aria-label': 'Jenis filter' }, ...FILTER_KINDS.map((k) => h('option', { value: k }, FILTER_LABELS[k])));
    const inA = h('input', { class: 'in', type: 'text', autocomplete: 'off', 'aria-label': 'Nilai' });
    const sync = () => { inA.hidden = !filterNeedsValue(kSel.value); inA.inputMode = kSel.value === 'gt' || kSel.value === 'lt' ? 'decimal' : 'text'; inA.placeholder = kSel.value === 'gt' || kSel.value === 'lt' ? 'Angka' : 'Teks'; };
    if (cur) { kSel.value = cur.k; inA.value = cur.a; } kSel.addEventListener('change', sync); sync();
    const apply = () => {
      const f = cleanFilter({ c: colId, k: kSel.value, a: inA.value }, tab.cols);
      if (!f) { toast(kSel.value === 'gt' || kSel.value === 'lt' ? 'Isi angka yang valid.' : 'Isi nilainya dulu.'); return; }
      flt = { ...f, tabId: tab.id }; { const o0 = getOrder(); if (sel && o0 && !o0.includes(sel.r)) sel = null; } ov.remove(); lastKey = ''; scroller.scrollTop = 0; drawRows(); paintBar(); buildHead();
      const o = getOrder(); toast(o && o.length ? o.length + ' baris tampil.' : 'Tidak ada baris yang cocok.');
    };
    ov.append(h('div', { class: 'sheet' }, h('h3', {}, 'Filter baris'), h('div', { class: 'lz-fstat' }, 'Hanya menyembunyikan baris di layar ini. Data, rumus, dan ekspor tidak berubah; filter hilang saat lembar kerja ditutup.'),
      h('h4', { class: 'lz-rh' }, 'Untuk kolom ' + colName), kSel, inA,
      h('div', { class: 'dlgb rev' }, h('button', { type: 'button', class: 'btn', 'data-f': 'apply', onclick: apply }, 'Terapkan filter')),
      flt && flt.tabId === tab.id ? h('button', { type: 'button', class: 'btn line lz-mx', 'data-f': 'off', onclick: () => { flt = null; ov.remove(); lastKey = ''; scroller.scrollTop = 0; drawRows(); paintBar(); } }, 'Hapus filter') : h('span', {}),
      h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov);
  };
  // Rev 260: persegi seleksi bila LEBIH dari satu sel dan bukan persis satu gabungan yang sudah ada (itu = Pisahkan sel); selain itu null
  const mergeRange = () => {
    normSel(); const rc = selx && selx.rect && !SX.isSingle(selx) ? selx.rect : null; if (!rc) return null;
    const ex = sel ? mergeAt(tab, sel.r, sel.c) : null;
    return ex && ex.r1 === rc.r1 && ex.c1 === rc.c1 && ex.r2 === rc.r2 && ex.c2 === rc.c2 ? null : rc;
  };
  const openMore = () => {
    commit(); const ov = h('div', { class: 'ov dlgov lz-more lz-menu', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    // Rev 264: Lainnya = daftar berkelompok. Yang sudah ada di Menu sel (tekan lama: potong/salin/tempel, sisip/hapus baris-kolom, gabung sel, hapus isi, dropdown, diagram) TIDAK diulang di sini.
    const MI = { salin: PATH.copy, asc: 'M7 4v16M4 17l3 3 3-3M14 6h6M14 11h4M14 16h2', desc: 'M7 20V4M4 7l3-3 3 3M14 18h6M14 13h4M14 8h2', cari: 'M11 4a7 7 0 100 14 7 7 0 000-14zM20 20l-4-4', seri: 'M5 12h14M14 7l5 5-5 5M5 5v14', impor: PATH.up, beku: 'M4 5h16v14H4zM4 10h16M4 14.5h16', warna: PATH.palette, filter: 'M4 5h16l-6 8v6l-4-2v-4z', csv: PATH.down, tsv: PATH.down };
    const item = (id, label, sub, fn, cls = 'lm-r') => h('button', { type: 'button', class: 'lz-mi ' + cls, 'data-mi': id, onclick: () => { ov.remove(); fn(); } }, h('i', { class: 'mi-ic', 'aria-hidden': 'true' }, ico(MI[id] || PATH.star)), h('span', { class: 'lm-tx' }, h('b', {}, label), h('span', {}, sub)), cls === 'lm-r' ? h('i', { class: 'lm-chev', 'aria-hidden': 'true' }, ico('M9 6l6 6-6 6')) : '');
    const grp = (title, ...kids) => h('section', { class: 'lm-g' }, h('h4', { class: 'lm-gt' }, title), h('div', { class: 'lm-gl' }, ...kids));
    const colTxt = sel ? 'kolom ' + L.colLabel(sel.c) : 'pilih sel dulu';
    ov.append(h('div', { class: 'sheet lm-sheet' },
      h('div', { class: 'lm-h' }, h('h3', {}, 'Lainnya'), sel ? h('span', { class: 'lm-ref' }, L.cellAddr(sel.c, sel.r)) : ''),
      grp('Salin', item('salin', 'Salin & Tempel', clip ? 'asal ' + clipAddr() + ' \u00b7 pilih isi, rumus, gaya, atau nilai' : 'isi, rumus, gaya, atau nilai saja', openCopyPaste)),
      h('section', { class: 'lm-g' }, h('h4', { class: 'lm-gt' }, 'Urutkan'), h('div', { class: 'lm-pair' },
        item('asc', 'A\u2192Z', colTxt, () => sortBy('asc'), 'lm-q'), item('desc', 'Z\u2192A', colTxt, () => sortBy('desc'), 'lm-q'))),
      grp('Olah data',
        item('cari', 'Cari dan ganti', 'di seluruh tab ini', openFind),
        item('seri', 'Isi seri', sel ? 'dari sel ' + L.colLabel(sel.c) + (sel.r + 1) : 'pilih sel dulu', openFill),
        item('filter', 'Filter baris', flt && flt.tabId === tab.id ? 'aktif \u00b7 ketuk untuk ubah' : (sel ? 'sembunyikan baris menurut kolom ' + L.colLabel(sel.c) : 'pilih sel dulu'), openFilter),
        item('warna', 'Warna bersyarat', (tab.rules && tab.rules.length) ? tab.rules.length + ' aturan di tab ini' : (sel ? 'beri warna menurut nilai kolom ' + L.colLabel(sel.c) : 'pilih sel dulu'), openRules)),
      grp('Tampilan', item('beku', 'Bekukan baris & kolom', getFreeze(tab).r || getFreeze(tab).c ? 'beku: ' + freezeLabel(tab) + ' \u00b7 ketuk untuk ubah' : 'judul tetap terlihat saat menggulir \u00b7 cara cepat: pilih baris/kolom, tahan', openFreeze)), // Rev 300b
      grp('Impor & ekspor',
        item('impor', 'Impor CSV/TSV', 'dari berkas di HP', openImport),
        item('csv', 'Unduh CSV', 'untuk Excel / Google Sheets', () => downloadAs(',', 'csv', 'text/csv')),
        item('tsv', 'Unduh TSV', 'dipisah tab', () => downloadAs('\t', 'tsv', 'text/tab-separated-values'))),
      h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov);
  };
  bM.addEventListener('pointerdown', (e) => e.preventDefault()); bM.onclick = openMore;
  // --- Rev 300b: Bekukan baris (Lainnya > Tampilan). Pilihan: Baris 1, 2 baris teratas, sampai baris sel terpilih (maks. 5), Lepas. Satu langkah Urungkan; tersimpan di tab.fz. Kolom beku = Rev 300c.
  const applyFreeze = (mode, ri, ci) => { // Rev 302b: ri/ci = indeks baris/kolom eksplisit (dari Menu sel: ujung seleksi); tanpa itu = sel aktif seperti Rev 300b
    const R = Number.isInteger(ri) ? ri : sel ? sel.r : -1, C = Number.isInteger(ci) ? ci : sel ? sel.c : -1;
    if ((mode === 'rows' && R < 0) || (mode === 'cols' && C < 0)) { tWarn('Pilih sel dulu, lalu bekukan sampai baris/kolomnya.'); return; }
    if (mode === 'col1' || mode === 'cols') { const cnt = Math.min(MAX_FZ_COLS, mode === 'col1' ? 1 : C + 1), room = (scroller.clientWidth || innerWidth) - NUM_W; if (fzTooWide(colLeft(tab, cnt), room * 0.7)) { tWarn('Kolom beku terlalu lebar bahkan setelah dipersempit. Kecilkan lebar kolom atau bekukan lebih sedikit.'); return; } } // Rev 302a: sisakan minimal 30% lebar agar kolom lain masih bisa digeser
    const snap = ser(), was = getFreeze(tab); let ok = mode === 'none' ? setFreeze(tab, { r: 0, c: 0 }) : mode === 'norows' ? setFreeze(tab, { r: 0 }) : mode === 'nocols' ? setFreeze(tab, { c: 0 }) : freezeBy(tab, mode, R, C).changed; // Rev 300c: + kolom
    const n = getFreeze(tab);
    if (ok) { ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; buildHead(); drawRows(); paintBar(); }
    const cut = (mode === 'rows' && R + 1 > n.r) || (mode === 'cols' && C + 1 > n.c);
    toast(mode.startsWith('no') ? (was.r || was.c ? 'Beku dilepas. Sekarang: ' + freezeLabel(tab) + '.' : 'Tidak ada yang beku.') : !ok ? 'Sudah beku: ' + freezeLabel(tab) + '.' : 'Beku: ' + freezeLabel(tab) + (cut ? ' (maks. ' + MAX_FZ_ROWS + ' baris, ' + MAX_FZ_COLS + ' kolom).' : '.'));
  };
  const openFreeze = () => {
    commit(); const ov = h('div', { class: 'ov dlgov lz-more lz-menu lz-fzm', onclick: (e) => { if (e.target === ov) ov.remove(); } }), f = getFreeze(tab), n = f.r;
    const opt = (mode, label, sub, on) => h('button', { type: 'button', class: 'lz-mi lm-r' + (on ? ' on' : ''), 'data-fz': mode, onclick: () => { ov.remove(); applyFreeze(mode); } }, h('i', { class: 'mi-ic', 'aria-hidden': 'true' }, ico(mode.includes('col') ? 'M4 5h16v14H4zM9.5 5v14M14.5 5v14' : 'M4 5h16v14H4zM4 10h16M4 14.5h16')), h('span', { class: 'lm-tx' }, h('b', {}, label), h('span', {}, on ? 'aktif sekarang' : sub)));
    ov.append(h('div', { class: 'sheet lm-sheet' },
      h('div', { class: 'lm-h' }, h('h3', {}, 'Bekukan baris & kolom'), h('span', { class: 'lm-ref' }, f.r || f.c ? freezeLabel(tab) : 'tidak ada')),
      h('section', { class: 'lm-g' }, h('h4', { class: 'lm-gt' }, 'Baris'), h('div', { class: 'lm-gl' },
        opt('row1', 'Baris 1', 'judul tabel tetap terlihat', n === 1),
        opt('row2', '2 baris teratas', 'untuk judul dua tingkat', n === 2),
        opt('rows', sel ? 'Sampai baris ' + (sel.r + 1) : 'Sampai baris sel terpilih', sel ? 'baris 1 sampai ' + (sel.r + 1) + ' (maks. ' + MAX_FZ_ROWS + ')' : 'pilih sel dulu', false),
        n ? opt('norows', 'Lepas baris beku', 'baris bergulir seperti biasa', false) : '')),
      h('section', { class: 'lm-g' }, h('h4', { class: 'lm-gt' }, 'Kolom'), h('div', { class: 'lm-gl' },
        opt('col1', 'Kolom A', 'kolom pertama tetap terlihat saat menggeser', f.c === 1),
        opt('cols', sel ? 'Sampai kolom ' + L.colLabel(sel.c) : 'Sampai kolom sel terpilih', sel ? 'kolom A sampai ' + L.colLabel(sel.c) + ' (maks. ' + MAX_FZ_COLS + ')' : 'pilih sel dulu', false),
        f.c ? opt('nocols', 'Lepas kolom beku', 'kolom bergeser seperti biasa', false) : '')),
      f.r && f.c ? h('section', { class: 'lm-g' }, h('div', { class: 'lm-gl' }, opt('none', 'Lepas semua', 'baris dan kolom bergulir seperti biasa', false))) : '',
      h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov);
  };
  // --- Rev 171: Salin / Tempel / Tempel sederet / Tempel nilai saja (lembar bawah Lainnya). Satu sel disalin; ditempel ke satu sel atau sederet (kanan/bawah). Satu langkah Urungkan.
  const clipAddr = () => { if (!clip) return ''; if (clip.range) return clip.ref || 'rentang'; const t = sheet.tabs.find((x) => x.id === clip.tabId); const r = t ? t.rows.findIndex((x) => x.id === clip.rowId) : -1, c = t ? t.cols.findIndex((x) => x.id === clip.colId) : -1; return r < 0 || c < 0 ? 'sel asal' : L.cellAddr(c, r); };
  const doCopy = () => {
    if (rng && rng.tabId === tab.id) { // Rev 179b: ada rentang terpilih = salin RENTANG
      const res = copyRange(tab, rng.rect); if (!res.ok) { tWarn('Rentang tidak bisa disalin.'); return; }
      clip = res.clip; clip.ref = rng.ref; const n = rng.cells, ref = rng.ref; rgClear(); lastKey = ''; drawRows(); toast('Rentang ' + ref + ' disalin (' + n + ' sel).'); return;
    }
    if (!sel) { tWarn('Pilih sel dulu.'); return; } const res = copyCell(tab, sel.r, sel.c); if (!res.ok) { tWarn('Sel tidak bisa disalin.'); return; } clip = res.clip; toast('Sel ' + L.cellAddr(sel.c, sel.r) + ' disalin.'); };
  const runPaste = (o) => {
    if (!sel) { tWarn('Pilih sel dulu.'); return; } if (!clip) { tWarn('Belum ada sel yang disalin.'); return; }
    normSel(); const at = SX.pasteOrigin(selx, sel) || sel; // Rev 255 / S5b: seleksi lebih dari satu sel = tempel mulai dari sudut kiri-atas seleksi
    const snap = ser(), res = clip.range ? pasteRange(tab, clip, at.r, at.c, { mode: o.mode }) : pasteClip(tab, clip, at.r, at.c, { ...o, keepFx: (o.count || 1) > 1 }); // Rev 179b: clip rentang = tempel sebesar sumber
    if (res.pasted) {
      if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); return; }
      if (clip.range) { const nx = SX.selectRange(SX.dimsOfTab(tab), at, { r: Math.min(at.r + clip.rows - 1, tab.rows.length - 1), c: Math.min(at.c + clip.cols - 1, tab.cols.length - 1) }, mergeList(tab)); if (nx) { sel = { r: at.r, c: at.c }; selx = nx; selxTab = tab.id; normKey = ''; } }
      ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar();
    }
    toast(pasteMessage(res));
  };
  // --- Rev 254 / S5a: Lainnya > Ubah seleksi = hapus isi, sisip/hapus baris dan kolom sebanyak seleksi. Tiap aksi SATU langkah Urungkan. Sisip/hapus baris-kolom ditolak saat filter aktif (filter memakai urutan tampil).
  const applyAct = (kind) => {
    commit(); normSel(); const sx = selx; if (!sx) { tWarn('Pilih sel dulu.'); return; }
    const fOn = !!(flt && flt.tabId === tab.id); if (kind !== 'clear' && fOn) { tWarn('Matikan filter dulu.'); return; }
    const snap = ser(); let res, undo = null;
    if (kind === 'clear') { const o = fOn ? getOrder() : null, vis = o ? new Set(o) : null; res = AS.clearContents(tab, sx, vis ? (r) => vis.has(r) : undefined); }
    else if (kind === 'rowUp' || kind === 'rowDown') { res = AS.insertRows(tab, sx, kind === 'rowUp' ? 'above' : 'below'); undo = () => AS.deleteRows(tab, { rect: { r1: res.at, r2: res.at + res.n - 1, c1: 0, c2: 0 } }); }
    else if (kind === 'colLeft' || kind === 'colRight') { res = AS.insertCols(tab, sx, kind === 'colLeft' ? 'left' : 'right'); undo = () => AS.deleteCols(tab, { rect: { r1: 0, r2: 0, c1: res.at, c2: res.at + res.n - 1 } }); }
    else if (kind === 'delRows') res = AS.deleteRows(tab, sx); else res = AS.deleteCols(tab, sx);
    if (res.all) { toast(kind === 'delRows' ? 'Sedikitnya satu baris harus tersisa.' : 'Sedikitnya satu kolom harus tersisa.'); return; }
    if (res.full) { toast(kind.startsWith('row') ? 'Lembar kerja sudah mencapai batas baris.' : 'Lembar kerja sudah mencapai batas kolom.'); return; }
    if (!res.changed) { toast(kind === 'clear' ? 'Tidak ada isi yang dihapus.' : 'Tidak ada yang berubah.'); return; }
    if (undo && !L.fitsLimit(sheet)) { undo(); tooBig(); return; } // hanya sisip yang menambah ukuran; dikembalikan utuh
    ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; normKey = '';
    if (sel) sel = { r: Math.min(sel.r, tab.rows.length - 1), c: Math.min(sel.c, tab.cols.length - 1) };
    refresh(); const n = res.n, part = res.want && res.want > n ? ' (dibatasi ' + n + ' dari ' + res.want + ')' : '';
    toast(kind === 'clear' ? 'Isi ' + n + ' sel dihapus.' : kind.startsWith('row') ? n + ' baris disisipkan' + part + '.' : kind.startsWith('col') ? n + ' kolom disisipkan' + part + '.' : kind === 'delRows' ? n + ' baris dihapus.' : n + ' kolom dihapus.');
  };
  // --- Rev 172: menu "Salin & Tempel" (satu dialog): Salin sel terpilih, pilih cara tempel (Semua / Isi & rumus / Nilai saja / Gaya saja), tujuan 1 sel atau sederet (bawah/kanan). Satu langkah Urungkan.
  const pAt = () => { normSel(); return SX.pasteOrigin(selx, sel) || sel; }; // Rev 255 / S5b: titik awal tempel (juga dipakai pratinjau)
  const openCopyPaste = () => {
    commit(); if (!sel) { tWarn('Pilih sel dulu.'); return; }
    let dir = 'down', mode = 'all'; const cnt = h('input', { class: 'in', type: 'number', inputmode: 'numeric', min: '1', max: String(L.MAX_ROWS), value: '1', 'aria-label': 'Jumlah sel tujuan' });
    const ov = h('div', { class: 'ov dlgov lz-more lz-find lz-fill lz-cpv', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const src = h('div', { class: 'cp-src', 'aria-live': 'polite' }), pv = h('div', { class: 'lz-fstat cp-pv', 'aria-live': 'polite' });
    const num = () => Math.min(L.MAX_ROWS, Math.max(1, Math.floor(Number(cnt.value)) || 1));
    const paint = () => {
      const isR = !!(clip && clip.range); for (const el of rowOnly) el.hidden = isR; // Rev 179b: tempel rentang tidak memakai jumlah/arah
      src.textContent = clip ? (isR ? 'Disalin: rentang ' : 'Disalin: sel ') + clipAddr() : 'Belum ada sel yang disalin';
      pv.textContent = clip ? 'Tempel ' + PASTE_MODES.find((m) => m.id === mode).label.toLowerCase() + ' \u2192 ' + (isR ? rectRef({ r1: pAt().r, c1: pAt().c, r2: pAt().r + clip.rows - 1, c2: pAt().c + clip.cols - 1 }, L.cellAddr) + (pAt().r + clip.rows > tab.rows.length || pAt().c + clip.cols > tab.cols.length ? ' (sebagian di luar lembar dilewati)' : '') : pasteRangeText(sel, num(), dir)) : 'Ketuk Salin dulu, lalu pilih cara tempel.';
      go.disabled = !clip;
    };
    const mbtn = (m) => h('button', { type: 'button', class: 'cp-mode', 'data-mode': m.id, 'aria-pressed': m.id === mode ? 'true' : 'false', onclick: () => { mode = m.id; modes.forEach((b) => b.setAttribute('aria-pressed', b.dataset.mode === mode ? 'true' : 'false')); paint(); } }, h('b', {}, m.label), h('span', {}, m.sub));
    const modes = PASTE_MODES.map(mbtn);
    const dbtn = (id, t) => h('button', { type: 'button', class: 'btn line lz-dir', 'data-dir': id, 'aria-pressed': id === dir ? 'true' : 'false', onclick: () => { dir = id; dirs.forEach((b) => b.setAttribute('aria-pressed', b.dataset.dir === dir ? 'true' : 'false')); paint(); } }, t);
    const dirs = [dbtn('down', 'Ke bawah'), dbtn('right', 'Ke kanan')];
    const h4Dest = h('h4', { class: 'lz-rh' }, 'Tempel ke'), dirsBox = h('div', { class: 'dlgb lz-dirs' }, ...dirs), cntLbl = h('label', { class: 'lz-fld' }, h('span', {}, 'Jumlah sel tujuan (mulai dari sel terpilih)'), cnt), rowOnly = [h4Dest, dirsBox, cntLbl]; // Rev 179b
    const inRng = !!(rng && rng.tabId === tab.id); const copyBtn = h('button', { type: 'button', class: 'btn line', 'data-f': 'copy', onclick: () => { doCopy(); paint(); if (inRng) copyBtn.textContent = 'Salin sel ' + L.cellAddr(sel.c, sel.r); } }, inRng ? 'Salin rentang ' + rng.ref : 'Salin sel ' + L.cellAddr(sel.c, sel.r));
    const go = h('button', { type: 'button', class: 'btn', 'data-f': 'pastrun', onclick: () => { const o = { count: num(), dir, mode }; ov.remove(); runPaste(o); } }, 'Tempel');
    cnt.addEventListener('input', paint);
    ov.append(h('div', { class: 'sheet' }, h('h3', {}, 'Salin & Tempel'),
      h('div', { class: 'cp-row' }, src, copyBtn),
      h('h4', { class: 'lz-rh' }, 'Cara tempel'), h('div', { class: 'cp-modes' }, ...modes),
      h4Dest, dirsBox, cntLbl, pv,
      h('div', { class: 'dlgb rev' }, go),
      h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov); paint();
  };

  // --- Rev 152 / U10b-2a: Gabung sel / Pisahkan sel (lembar bawah Lainnya). Rentang = dari sel terpilih (kiri-atas) sejumlah kolom dan baris.
  const MERGE_MSG = { kecil: 'Pilih minimal 2 sel.', tumpang: 'Bersinggungan dengan gabungan lain. Pisahkan dulu.', batas: 'Maksimal ' + MAX_MERGES + ' gabungan per tab.', rentang: 'Di luar lembar kerja.' };
  const openMerge = () => {
    commit(); if (!sel) { tWarn('Pilih sel dulu.'); return; }
    normSel(); const rc = selx && selx.rect && !SX.isSingle(selx) ? selx.rect : null; // Rev 260: seleksi lebih dari satu sel = langsung digabung tanpa dialog
    const ex = mergeAt(tab, sel.r, sel.c), same = !!(ex && rc && ex.r1 === rc.r1 && ex.c1 === rc.c1 && ex.r2 === rc.r2 && ex.c2 === rc.c2);
    if (rc && !(ex && same)) {
      const p = planMerge(tab, rc.r1, rc.c1, rc.r2, rc.c2); if (!p.ok) { toast(MERGE_MSG[p.reason] || 'Tidak bisa digabung.'); return; }
      const ref = L.cellAddr(rc.c1, rc.r1) + ':' + L.cellAddr(rc.c2, rc.r2);
      const go = () => {
        const snap = ser(), res = L.mergeCells(tab, rc.r1, rc.c1, rc.r2, rc.c2, { clear: true });
        if (!res.ok) { toast(MERGE_MSG[res.reason] || 'Tidak bisa digabung.'); return; }
        if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); return; }
        sel = { r: rc.r1, c: rc.c1 }; selx = SX.selectCell(SX.dimsOfTab(tab), rc.r1, rc.c1, mergeList(tab)); selxTab = tab.id; normKey = '';
        ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; buildHead(); drawRows(); paintBar();
        toast('Digabung: ' + ref + (p.filled ? ' \u00b7 isi ' + p.filled + ' sel lain dihapus (bisa Urungkan)' : '') + '.');
      };
      // seleksi satu kolom/baris penuh atau semua sel yang berisi data: tanya dulu, supaya isi tidak hilang tanpa sengaja
      if (p.filled > 0 && selx && (selx.kind === 'row' || selx.kind === 'col' || selx.kind === 'all')) dlg({ title: 'Gabungkan ' + ref + '?', msg: 'Isi ' + p.filled + ' sel lain akan dihapus (hanya isi sel ' + L.cellAddr(rc.c1, rc.r1) + ' dipertahankan). Bisa dibatalkan dengan Urungkan.', yes: 'Gabungkan', red: true, ok: go });
      else go();
      return;
    }
    if (ex) { const snap = ser(); if (L.unmergeCell(tab, ex.r1, ex.c1)) { sel = { r: ex.r1, c: ex.c1 }; ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar(); toast('Gabungan ' + ex.ref + ' dipisahkan.'); } return; }
    const mkn = (v, lo, hi, label) => h('input', { class: 'in', type: 'number', inputmode: 'numeric', min: String(lo), max: String(hi), value: String(v), 'aria-label': label });
    const maxC = tab.cols.length - sel.c, maxR = tab.rows.length - sel.r;
    const nc = mkn(Math.min(2, maxC), 1, maxC, 'Jumlah kolom'), nr = mkn(1, 1, maxR, 'Jumlah baris'), pv = h('div', { class: 'lz-fstat', 'aria-live': 'polite' });
    const ov = h('div', { class: 'ov dlgov lz-more lz-find lz-merge', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const field = (t, el) => h('label', { class: 'lz-fld' }, h('span', {}, t), el);
    const num = (el, lo, hi) => Math.min(hi, Math.max(lo, Math.floor(Number(el.value)) || lo));
    const goB = h('button', { type: 'button', class: 'btn', 'data-f': 'merge' }, 'Gabungkan');
    const plan = () => { const c = num(nc, 1, maxC), r = num(nr, 1, maxR); return { c, r, p: planMerge(tab, sel.r, sel.c, sel.r + r - 1, sel.c + c - 1) }; };
    const paint = () => {
      const { c, r, p } = plan(), ref = L.cellAddr(sel.c, sel.r) + ':' + L.cellAddr(sel.c + c - 1, sel.r + r - 1);
      if (!p.ok) { pv.textContent = MERGE_MSG[p.reason] || 'Tidak bisa digabung.'; goB.disabled = true; goB.textContent = 'Gabungkan'; return; }
      goB.disabled = false; goB.textContent = p.filled ? 'Gabungkan dan kosongkan ' + p.filled + ' sel' : 'Gabungkan';
      pv.textContent = ref + ' \u00b7 ' + (c * r) + ' sel' + (p.filled ? ' \u00b7 isi ' + p.filled + ' sel lain akan dihapus (hanya isi sel ' + L.cellAddr(sel.c, sel.r) + ' dipertahankan)' : '');
    };
    nc.addEventListener('input', paint); nr.addEventListener('input', paint);
    goB.onclick = () => {
      const { c, r, p } = plan(); if (!p.ok) return; const snap = ser(), res = L.mergeCells(tab, sel.r, sel.c, sel.r + r - 1, sel.c + c - 1, { clear: true });
      if (!res.ok) { toast(MERGE_MSG[res.reason] || 'Tidak bisa digabung.'); return; }
      if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); ov.remove(); return; }
      ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar(); ov.remove(); toast('Digabung: ' + L.cellAddr(sel.c, sel.r) + ':' + L.cellAddr(sel.c + c - 1, sel.r + r - 1) + '.');
    };
    ov.append(h('div', { class: 'sheet' }, h('h3', {}, 'Gabung sel'), h('p', { class: 'lz-fstat' }, 'Mulai dari sel ' + L.cellAddr(sel.c, sel.r) + ' (kiri-atas).'),
      field('Jumlah kolom (ke kanan)', nc), field('Jumlah baris (ke bawah)', nr), pv, h('div', { class: 'dlgb rev' }, goB), h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov); paint();
  };

  // --- Rev 157 / U10c-2a: Diagram (lembar bawah Lainnya). Rentang = dari sel terpilih ke bawah; kolom pertama = label, kolom ke-n (n >= 2) = nilai.
  // Rev 159 / U10c-2c: + tombol Simpan (tab.charts lewat L.saveChart), daftar diagram tersimpan (Lihat/Hapus), satu langkah Urungkan per simpan/hapus. Pratinjau + Unduh SVG tetap tidak mengubah lembar kerja.
  const CHART_MSG = { rentang: 'Rentang di luar lembar kerja.', kolom: 'Kolom nilai harus di dalam rentang.', kosong: 'Tidak ada angka di rentang ini.', 'tak-positif': 'Donat butuh minimal satu angka positif.' };
  const CHART_THEME = { bg: '#FFFFFF' }; // latar putih supaya diagram terbaca di tema terang maupun gelap, dan berdiri sendiri saat diunduh
  const openChart = () => {
    commit(); if (!sel) { tWarn('Pilih sel dulu.'); return; }
    const maxR = tab.rows.length - sel.r, maxC = tab.cols.length - sel.c;
    if (maxC < 2) { tWarn('Diagram butuh minimal 2 kolom dari sel terpilih.'); return; }
    let kind = 'column'; const u = usedRange(tab);
    const mkn = (v, lo, hi, label) => h('input', { class: 'in', type: 'number', inputmode: 'numeric', min: String(lo), max: String(hi), value: String(v), 'aria-label': label });
    const nr = mkn(Math.min(maxR, Math.max(2, Math.min(MAX_POINTS + 1, u.rows - sel.r))), 1, maxR, 'Jumlah baris'), vc = mkn(2, 2, maxC, 'Kolom nilai');
    const ttl = h('input', { class: 'in', type: 'text', maxlength: '60', placeholder: 'Otomatis dari judul kolom', autocomplete: 'off', 'aria-label': 'Judul diagram' }), lg = h('input', { type: 'checkbox', checked: 'checked' });
    const box = h('div', { class: 'lz-chartpv', 'aria-live': 'polite' }), pv = h('div', { class: 'lz-fstat', 'aria-live': 'polite' });
    const ov = h('div', { class: 'ov dlgov lz-more lz-find lz-chart', onclick: (e) => { if (e.target === ov) ov.remove(); } });
    const num = (el, lo, hi) => Math.min(hi, Math.max(lo, Math.floor(Number(el.value)) || lo));
    const field = (t, el) => h('label', { class: 'lz-fld' }, h('span', {}, t), el);
    const lgRow = h('label', { class: 'lz-chk' }, lg, h('span', {}, 'Tampilkan legenda (donat)'));
    const build = (width) => {
      const n = num(nr, 1, maxR), k = num(vc, 2, maxC), src = { r1: sel.r, c1: sel.c, r2: sel.r + n - 1, c2: sel.c + k - 1 };
      const d = chartData(tab, src, { valueCol: src.c2 }); const res = d.ok ? chartSvg(d, { kind, title: ttl.value, legend: lg.checked, width, theme: CHART_THEME }) : { ok: false, reason: d.reason };
      return { src, d, res };
    };
    const dl = h('button', { type: 'button', class: 'btn', 'data-f': 'svg', disabled: 'disabled' }, 'Unduh SVG');
    const sv = h('button', { type: 'button', class: 'btn', 'data-f': 'save', disabled: 'disabled' }, 'Simpan diagram'), saved = h('div', { class: 'lz-svd' });
    const mount = (res) => { box.textContent = ''; let el = null; try { const doc = new DOMParser().parseFromString(res.svg, 'image/svg+xml'); if (doc.documentElement && doc.documentElement.nodeName === 'svg') el = document.importNode(doc.documentElement, true); } catch (_) { el = null; } if (el) box.append(el); return !!el; };
    const view = (c) => { const d = chartData(tab, c.src, { valueCol: c.valueCol }); const res = d.ok ? chartSvg(d, { kind: c.kind, title: c.title, legend: c.legend, width: 360, theme: CHART_THEME }) : { ok: false, reason: d.reason }; if (!res.ok || !mount(res)) { box.textContent = ''; pv.textContent = c.ref + ' \u00b7 ' + (CHART_MSG[res.reason] || 'Tidak bisa digambar.'); return; } pv.textContent = 'Tersimpan ' + c.ref + ' \u00b7 ' + d.values.length + ' data'; };
    const paintSaved = () => {
      const list = L.listCharts(tab); saved.textContent = ''; saved.hidden = !list.length; if (!list.length) return;
      saved.append(h('h4', {}, 'Tersimpan di tab ini (' + list.length + '/' + L.MAX_CHARTS + ')'));
      for (const c of list) saved.append(h('div', { class: 'lz-svr', 'data-id': c.id }, h('span', { class: 'lz-svt' }, c.ref + ' \u00b7 ' + KIND_LABELS[c.kind] + (c.title ? ' \u00b7 ' + c.title : '')),
        h('button', { type: 'button', class: 'btn line', 'data-a': 'lihat', onclick: () => view(c) }, 'Lihat'),
        h('button', { type: 'button', class: 'btn line', 'data-a': 'hapus', onclick: () => { const snap = ser(); if (L.deleteChart(tab, c.id)) { ver++, hist.push(snap); paintUndo(); touched(); paintSaved(); paint(); tOk('Diagram dihapus. Bisa diurungkan.'); } } }, 'Hapus')));
    };
    const paint = () => {
      lgRow.hidden = kind !== 'donut'; const { src, d, res } = build(360); box.textContent = '';
      const ref = L.cellAddr(src.c1, src.r1) + ':' + L.cellAddr(src.c2, src.r2);
      sv.disabled = true;
      if (!res.ok) { dl.disabled = true; pv.textContent = ref + ' \u00b7 ' + (CHART_MSG[res.reason] || 'Tidak bisa digambar.'); return; }
      if (!mount(res)) { dl.disabled = true; pv.textContent = 'Pratinjau gagal dibuat.'; return; }
      dl.disabled = false; sv.disabled = L.listCharts(tab).length >= L.MAX_CHARTS;
      pv.textContent = ref + ' \u00b7 ' + d.values.length + ' data' + (d.skipped ? ' \u00b7 ' + d.skipped + ' baris bukan angka dilewati' : '') + (d.truncated ? ' \u00b7 ' + d.truncated + ' baris terakhir dipotong (maks. ' + MAX_POINTS + ')' : '') + (d.title && !ttl.value.trim() ? ' \u00b7 judul: ' + d.title : '');
      if (sv.disabled) pv.textContent += ' \u00b7 Simpan nonaktif: batas ' + L.MAX_CHARTS + ' diagram per lembar sudah tercapai, hapus diagram lama dulu.'; // Rev 311e
    };
    const kbtn = (id) => h('button', { type: 'button', class: 'btn line lz-dir', 'data-kind': id, 'aria-pressed': id === kind ? 'true' : 'false', onclick: () => { kind = id; kinds.forEach((b) => b.setAttribute('aria-pressed', b.dataset.kind === kind ? 'true' : 'false')); paint(); } }, KIND_LABELS[id]);
    const kinds = CHART_KINDS.map(kbtn);
    dl.onclick = async () => {
      const { res } = build(640); if (!res.ok) return;
      try { const { saveFiles } = await import('./share.js'); const where = await saveFiles([{ name: exportName(sheet.name + ' diagram', tab.name, sheet.tabs.length > 1, 'svg'), text: res.svg, mime: 'image/svg+xml' }]); toast('Tersimpan: ' + where); } catch (_) { batas('Berkas tidak tersimpan', 'Aplikasi tidak berhasil menulis berkas ke penyimpanan perangkat.', 'Cek sisa ruang penyimpanan dan izin berkas, lalu coba lagi.'); }
    };
    sv.onclick = () => {
      const { src, res } = build(360); if (!res.ok) return; const snap = ser();
      const r = L.saveChart(tab, src, src.c2, { kind, title: ttl.value, legend: lg.checked });
      if (!r.ok) { toast(r.reason === 'batas' ? 'Maksimal ' + L.MAX_CHARTS + ' diagram per tab.' : 'Diagram tidak bisa disimpan.'); return; }
      if (!L.fitsLimit(sheet)) { L.deleteChart(tab, r.id); tooBig('diagram'); return; }
      ver++, hist.push(snap); paintUndo(); touched(); paintSaved(); paint(); tOk('Diagram disimpan di tab ini.');
    };
    [nr, vc, ttl].forEach((el) => el.addEventListener('input', paint)); lg.addEventListener('change', paint);
    ov.append(h('div', { class: 'sheet' }, h('h3', {}, 'Diagram'), h('p', { class: 'lz-fstat' }, 'Mulai dari sel ' + L.cellAddr(sel.c, sel.r) + ': kolom ini = label, kolom nilai di kanannya.' + (flt && flt.tabId === tab.id ? ' Filter baris tidak memengaruhi diagram: semua baris dalam rentang ikut (termasuk yang tersembunyi).' : '')),
      h('div', { class: 'dlgb lz-dirs' }, ...kinds), box, pv, h('div', { class: 'lz-two' }, field('Jumlah baris', nr), field('Kolom nilai (2 = kanan label)', vc)), field('Judul (boleh kosong)', ttl), lgRow,
      h('div', { class: 'dlgb rev' }, sv, dl), saved, h('button', { type: 'button', class: 'btn line lz-mx', onclick: () => ov.remove() }, 'Tutup')));
    document.body.append(ov); paintSaved(); paint();
  };

  const tabMenu = (t) => namePrompt({ title: 'Ubah tab', value: t.name, yes: 'Simpan',
    onOk: (name) => { const snap = ser(); if (L.renameTab(sheet, t.id, name)) { ver++, hist.push(snap); paintUndo(); touched(); changed(); } },
    extra: (close) => (sheet.tabs.length > 1 ? h('div', { class: 'lz-tabx' }, h('div', { class: 'lz-tabmove' }, ...[[-1, '\u25c0 Geser kiri'], [1, 'Geser kanan \u25b6']].map(([d, lb]) => h('button', { type: 'button', class: 'btn line lz-mv', disabled: sheet.tabs.indexOf(t) + d < 0 || sheet.tabs.indexOf(t) + d >= sheet.tabs.length, onclick: () => { close(); const snap = ser(); if (L.moveTab(sheet, t.id, d)) { ver++, hist.push(snap); paintUndo(); paintTabs(); touched(); changed(); } } }, lb))), h('button', { type: 'button', class: 'btn line lz-deltab', onclick: () => { close(); dlg({ title: 'Hapus tab \u201c' + t.name + '\u201d?', msg: 'Isi tab ini dihapus permanen.', yes: 'Hapus', red: true, ok: () => { const snap = ser(); if (L.removeTab(sheet, t.id)) { ver++, hist.push(snap); paintUndo(); if (tab === t) { tab = sheet.tabs[0]; sel = null; scroller.scrollTop = 0; scroller.scrollLeft = 0; } touched(); changed(); } } }); } }, 'Hapus tab')) : null) });
  const paintInfo = () => { info.textContent = tab.cols.length + ' kolom \u00b7 ' + tab.rows.length + ' baris'; };
  const paintTabs = () => {
    tabs.textContent = '';
    sheet.tabs.forEach((t) => tabs.append(h('button', { type: 'button', role: 'tab', class: 'lz-tab' + (t === tab ? ' on' : ''), 'aria-selected': String(t === tab), onclick: () => { if (t === tab) { tabMenu(t); return; } commit(); tab = t; sel = null; scroller.scrollTop = 0; scroller.scrollLeft = 0; refresh(true); } }, t.name)));
    if (sheet.tabs.length < L.MAX_TABS) tabs.append(h('button', { type: 'button', class: 'lz-tab lz-newtab', 'aria-label': 'Tab baru', onclick: () => { commit(); const snap = ser(), id = L.addTab(sheet); if (!id) return; const nt = sheet.tabs.find((x) => x.id === id); if (!L.fitsLimit(sheet)) { L.removeTab(sheet, id); tooBig(); return; } ver++, hist.push(snap); paintUndo(); tab = nt; sel = null; scroller.scrollTop = 0; scroller.scrollLeft = 0; touched(); changed(); } }, '+'));
    paintInfo();
  };
  const refresh = (full) => { if (full) { lastKey = ''; buildHead(); paintTabs(); } else buildHead(); drawRows(); paintBar(); };
  // --- Rev 118 / U7a-2b-3: seret lebar kolom. Tidak membangun ulang kepala saat menyeret (pegangan yang dipegang harus tetap ada):
  // hanya posisi/lebar elemen yang sudah ada diperbarui (relayout). Simpan (onChange) SEKALI saat jari diangkat.
  let rz = null; // { i, id, x, w, pid, g, snap, set } ; Rev 253 / S4: set = [{id, w}] semua kolom yang ikut (kepala 'on' = seluruh kolom terpilih; selain itu hanya kolom ini)
  const relayout = () => {
    const sz = gridSize(tab), lefts = []; let acc = 0; tab.cols.forEach((c) => { lefts.push(NUM_W + acc); acc += c.w; });
    headRow.style.width = sz.w + 'px'; inner.style.width = sz.w + 'px'; body.style.width = sz.w + 'px';
    const fzE = (e) => e.parentNode.classList.contains('lz-fzw'), lf = (e, i) => lefts[i] - (fzE(e) ? NUM_W : 0); // Rev 302a: sel di pembungkus beku dihitung dari pembungkus
    headRow.querySelectorAll('.lz-hc').forEach((hc) => { const i = Number(hc.dataset.c), c = tab.cols[i]; if (c) { hc.style.left = fzE(hc) ? fzPx(lf(hc, i)) : lf(hc, i) + 'px'; hc.style.width = fzE(hc) ? fzPx(c.w) : c.w + 'px'; } });
    body.querySelectorAll('.lz-row').forEach((rowEl) => { rowEl.style.width = sz.w + 'px'; rowEl.querySelectorAll('.lz-c').forEach((el) => { const i = Number(el.dataset.c), c = tab.cols[i]; if (c) { el.style.left = fzE(el) ? fzPx(lf(el, i)) : lf(el, i) + 'px'; el.style.width = fzE(el) ? fzPx(c.w) : c.w + 'px'; } }); });
    { const fcw = fzPx(colLeft(tab, getFreeze(tab).c)); scroller.querySelectorAll('.lz-fzw').forEach((e) => { e.style.width = fcw; }); fzUpdate(); } // Rev 302a: lebar pembungkus beku ikut
    paintSelBox(); // Rev 251 / S2: lapisan seleksi ikut lebar kolom
  };
  const rzInfo = (w) => { info.textContent = (rz.set.length > 1 ? rz.set.length + ' kolom' : 'Kolom ' + L.colLabel(rz.i)) + ' \u00b7 ' + w + ' px'; };
  const rzDown = (e) => {
    const g = e.target.closest && e.target.closest('.lz-rz'); if (!g || rz) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const hc = g.parentNode, i = Number(hc && hc.dataset.c), c = tab.cols[i]; if (!c) return;
    e.preventDefault(); e.stopPropagation();
    commit(); // simpan isian sel lama dulu
    const set = SX.resizeSet(selx, 'col', i, SX.dimsOfTab(tab)).filter((k) => tab.cols[k]).map((k) => ({ id: tab.cols[k].id, w: tab.cols[k].w }));
    rz = { i, id: c.id, x: e.clientX, w: c.w, fs: i < getFreeze(tab).c ? fzS() : 1 /* Rev 304b: kolom beku yang sedang menyempit = selisih jari dibagi faktor */, pid: e.pointerId, g, snap: ser(), set: set.length ? set : [{ id: c.id, w: c.w }] };
    try { g.setPointerCapture(e.pointerId); } catch (_) {}
    hc.classList.add('rz'); rzInfo(c.w); if (rz.set.length > 1) showGd(true, NUM_W + colLeft(tab, i) + c.w);
  };
  const rzMove = (e) => {
    if (!rz || e.pointerId !== rz.pid) return;
    const c = tab.cols[rz.i]; if (!c) return;
    const w = dragWidth(rz.w, (e.clientX - rz.x) / (rz.fs || 1)); if (w === c.w) return;
    for (const it of rz.set) L.setColWidth(tab, it.id, w); relayout(); rzInfo(w); // Rev 253 / S4: semua kolom terpilih SAMA lebar
    if (rz.set.length > 1) showGd(true, NUM_W + colLeft(tab, rz.i) + c.w);
  };
  const rzEnd = (e, cancel) => {
    if (!rz || e.pointerId !== rz.pid) return;
    const r = rz; rz = null;
    try { r.g.releasePointerCapture(r.pid); } catch (_) {}
    if (r.g.parentNode) r.g.parentNode.classList.remove('rz');
    gd.hidden = true; const cw = (id) => { const k = tab.cols.find((x) => x.id === id); return k ? k.w : undefined; }, cdiff = () => r.set.some((it) => cw(it.id) !== undefined && cw(it.id) !== it.w);
    if (cancel && cdiff()) { for (const it of r.set) L.setColWidth(tab, it.id, it.w); relayout(); } // dibatalkan = SEMUA kembali ke lebar awal
    paintInfo(); lastKey = '';
    if (cdiff()) { ver++, hist.push(r.snap); paintUndo(); touched(); } // SATU langkah Urungkan untuk seluruh perubahan
  };
  headRow.addEventListener('pointerdown', rzDown);
  headRow.addEventListener('pointermove', rzMove);
  headRow.addEventListener('pointerup', (e) => rzEnd(e, false));
  headRow.addEventListener('pointercancel', (e) => rzEnd(e, true));
  headRow.addEventListener('lostpointercapture', (e) => rzEnd(e, true));
  headRow.addEventListener('click', (e) => { if (e.target.closest && e.target.closest('.lz-rz')) e.stopPropagation(); }); // ketukan pegangan bukan memilih kolom
  // --- Rev 184b / U10e-2: seret tinggi baris lewat garis di bawah nomor baris. Seperti lebar kolom: baris TIDAK digambar ulang saat menyeret
  // (pegangan yang dipegang harus tetap ada), hanya posisi/tinggi elemen yang ada diperbarui (relayoutRows). Simpan (onChange) SEKALI saat jari diangkat.
  let rr = null; // { r, id, y, h, others, pid, g, snap, set } ; Rev 253 / S4: set = [{id, h}] semua baris yang ikut (nomor 'on' = seluruh baris terpilih; selain itu hanya baris ini)
  const relayoutRows = () => {
    const ord = getOrder(), lay = layout(ord); inner.style.height = (HEAD_H + lay.tops[lay.total]) + 'px'; body.style.height = lay.tops[lay.total] + 'px'; if (frz.parentNode) frz.style.height = lay.tops[frCount(ord, lay.total)] + 'px'; // Rev 300b
    body.querySelectorAll('.lz-row').forEach((rowEl) => {
      const k = Number(rowEl.dataset.k), eh = lay.eff[k]; if (eh === undefined) return;
      rowEl.style.top = lay.tops[k] + 'px'; rowEl.style.height = eh + 'px'; if (rowEl.firstChild) rowEl.firstChild.style.height = eh + 'px';
      rowEl.querySelectorAll('.lz-c').forEach((el) => {
        if (el.dataset.mp !== undefined) { const p = Number(el.dataset.mp), n = Number(el.dataset.mc); el.style.height = (lay.tops[p + n] - lay.tops[p]) + 'px'; }
        else { el.style.height = eh + 'px'; el.classList.toggle('tall', eh > ROW_H); }
      });
    });
    paintSelBox(); // Rev 251 / S2: lapisan seleksi ikut tinggi baris
  };
  const rrInfo = (n) => { info.textContent = (rr.set.length > 1 ? rr.set.length + ' baris' : 'Baris ' + (rr.r + 1)) + ' · ' + n + ' px'; };
  const rrGuide = () => { if (rr.set.length < 2) return; const ord = getOrder(), k = ord ? ord.indexOf(rr.r) : rr.r; if (k >= 0) showGd(false, HEAD_H + layout(ord).tops[k + 1]); };
  const rrDown = (e) => {
    const g0 = e.target.closest && e.target.closest('.lz-rzr'); if (!g0 || rr || rz) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    const r = Number(g0.closest('.lz-row') && g0.closest('.lz-row').dataset.r), row = tab.rows[r]; if (!row) return;
    e.preventDefault(); e.stopPropagation();
    commit(); // simpan isian sel lama dulu (bisa menggambar ulang baris, jadi pegangan dicari lagi sesudahnya)
    const g = body.querySelector('.lz-row[data-r="' + r + '"] .lz-rzr'); if (!g) return;
    const idx = SX.resizeSet(selx, 'row', r, SX.dimsOfTab(tab)).filter((k) => tab.rows[k]), inSet = new Set(idx.length ? idx : [r]);
    let others = 0; tab.rows.forEach((x, i) => { if (!inSet.has(i)) others += x.h || ROW_H; });
    rr = { r, id: row.id, y: e.clientY, h: row.h || ROW_H, others, pid: e.pointerId, g, snap: ser(), set: [...inSet].map((k) => ({ id: tab.rows[k].id, h: tab.rows[k].h || ROW_H })) };
    try { g.setPointerCapture(e.pointerId); } catch (_) {}
    g.closest('.lz-row').classList.add('rz'); rrInfo(rr.h); rrGuide();
  };
  const rrMove = (e) => {
    if (!rr || e.pointerId !== rr.pid) return;
    const row = tab.rows[rr.r]; if (!row) return;
    const n = dragRowHeightN(rr.h, e.clientY - rr.y, rr.set.length, rr.others); if (n === (row.h || ROW_H)) return;
    for (const it of rr.set) L.setRowHeight(tab, it.id, n); relayoutRows(); rrInfo(n); rrGuide(); // Rev 253 / S4: semua baris terpilih SAMA tinggi
  };
  const rrEnd = (e, cancel) => {
    if (!rr || e.pointerId !== rr.pid) return;
    const r = rr; rr = null;
    try { r.g.releasePointerCapture(r.pid); } catch (_) {}
    gd.hidden = true; const rh = (id) => { const k = tab.rows.find((x) => x.id === id); return k ? (k.h || ROW_H) : undefined; }, diff = () => r.set.some((it) => rh(it.id) !== undefined && rh(it.id) !== it.h), back = () => { for (const it of r.set) L.setRowHeight(tab, it.id, it.h); };
    if (cancel && diff()) back(); // dibatalkan = SEMUA kembali ke tinggi awal
    let changed = diff();
    if (changed && !L.fitsLimit(sheet)) { back(); changed = false; tooBig(); }
    paintInfo(); lastKey = '';
    if (changed) { ver++, hist.push(r.snap); paintUndo(); touched(); }
    drawRows();
  };
  body.addEventListener('pointerdown', rrDown);
  body.addEventListener('pointermove', rrMove);
  body.addEventListener('pointerup', (e) => rrEnd(e, false));
  body.addEventListener('pointercancel', (e) => rrEnd(e, true));
  body.addEventListener('lostpointercapture', (e) => rrEnd(e, true));
  body.addEventListener('click', (e) => { if (e.target.closest && e.target.closest('.lz-rzr')) e.stopPropagation(); }); // ketukan pegangan bukan memilih baris
  const onScroll = () => { fzUpdate(); clipSel(); if (raf) return; raf = requestAnimationFrame(() => { raf = 0; drawRows(); clipSel(); }); };
  // Rev 303b: ketuk sel kotak centang = centang/lepas (satu langkah Urungkan; sel berumus tidak ditimpa)
  const toggleBox = (r, ci) => {
    const row = tab.rows[r], col = tab.cols[ci]; if (!row || !col || !isBox(checkAt(tab, r, ci))) return;
    const pc = L.cellAt(tab, r, ci); if (hasFx(pc)) { batas('Sel ini berumus', 'Kotak centang hanya bisa mengubah sel yang berisi nilai biasa, sedangkan sel ini diisi oleh rumus.', 'Hapus rumusnya dulu atau ketik nilai biasa di sel ini, lalu centang lagi.'); return; }
    const snap = ser(); if (!L.setCell(tab, row.id, col.id, { v: nextBoxValue(pc && pc.v) })) return;
    if (!L.fitsLimit(sheet)) { restore(snap); tooBig(); return; }
    ver++, hist.push(snap); paintUndo(); touched(); lastKey = ''; drawRows(); paintBar();
    const bx = scroller.querySelector('.lz-row[data-r="' + r + '"] .lz-c[data-c="' + ci + '"]'); if (bx) { bx.classList.add('bxp'); setTimeout(() => bx.classList.remove('bxp'), 400); } // Rev 303c: kotak 'melenting' sebentar saat diketuk (hanya kotak yang diketuk, bukan saat menggulir)
  };
  const pick = (e) => {
    const c = e.target.closest && e.target.closest('.lz-c, .lz-rn, .lz-hc, .lz-corner'); if (!c) return; // Rev 251 / S2: pojok kiri-atas = pilih semua
    commit(); // simpan isian sel lama SEBELUM pindah pilihan
    const rowEl = c.closest('.lz-row'); let again = false; const dm = SX.dimsOfTab(tab), ml = mergeList(tab);
    // Rev 148: ketuk sel yang SUDAH terpilih di kolom bervalidasi = buka daftar pilihan
    let nsx = null;
    if (c.classList.contains('lz-c') && rowEl) { /* Rev 178: sel gabungan = pilih sel jangkar (data-ar) */ const nr = c.dataset.ar !== undefined ? Number(c.dataset.ar) : Number(rowEl.dataset.r), nc = Number(c.dataset.c); again = !!sel && sel.r === nr && sel.c === nc && !!selx && (selx.kind === 'cell' || (selx.kind === 'range' && selx.a.r === selx.f.r && selx.a.c === selx.f.c)); /* Rev 261: sel gabungan = rentang dengan jangkar = ujung, tetap dihitung satu sel */ sel = { r: nr, c: nc }; nsx = SX.selectCell(dm, nr, nc, ml); }
    else if (c.classList.contains('lz-rn') && rowEl) { const r = Number(rowEl.dataset.r); sel = { r, c: sel ? sel.c : 0 }; nsx = SX.selectRow(dm, r, ml); } // Rev 251 / S2: ketuk nomor baris = SELURUH baris
    else if (c.classList.contains('lz-hc')) { const cc = Number(c.dataset.c); sel = { r: sel ? sel.r : firstRow(), c: cc }; nsx = SX.selectCol(dm, cc, ml); } // Rev 251 / S2: ketuk kepala kolom = SELURUH kolom
    else if (c.classList.contains('lz-corner')) { if (!sel) sel = { r: firstRow(), c: 0 }; nsx = SX.selectAll(dm); } // Rev 251 / S2: pojok = semua
    else return;
    selx = nsx; selxTab = tab.id; normKey = '';
    lastKey = ''; buildHead(); drawRows(); paintBar();
    if (c.classList.contains('lz-c') && c.dataset.box !== undefined) { toggleBox(sel.r, sel.c); return; } // Rev 303b
    if (again && (() => { const pk = checkAt(tab, sel.r, sel.c); return !!pk && pk.dd !== false; })()) openPick();
    else if (again && nsx && nsx.kind === 'cell' && c.classList.contains('lz-c') && !val.disabled) { // Rev 260: ketuk PERTAMA hanya memilih sel; ketuk KEDUA pada sel yang sama = keyboard + bilah isian naik (adjustResize)
      try { val.focus(); } catch (_) { /* abaikan */ }
      const see = () => { const q = scroller.querySelector('.lz-row[data-r=\"' + sel.r + '\"] .lz-c[data-c=\"' + sel.c + '\"]'), sr = scroller.getBoundingClientRect(); if (!q) return; const b = q.getBoundingClientRect().bottom; if (b > sr.bottom - 6) scroller.scrollTop += b - sr.bottom + 10; };
      setTimeout(see, 150); setTimeout(see, 400);
    }
  };
  // --- Rev 131 / U8a-4c: ketuk sel saat mengetik rumus = sisip rujukan. pointerdown (preventDefault) menjaga fokus/keyboard kolom isian;
  // click fase tangkap menyisipkan lalu menghentikan `pick` (pilihan sel dan commit() tidak berubah). Di luar slot rujukan = perilaku lama.
  let tapRef = false;
  scroller.addEventListener('pointerdown', (e) => {
    tapRef = false; const c = e.target.closest && e.target.closest('.lz-c');
    if (!c || document.activeElement !== val || val.disabled || !refSlot(val.value, val.selectionStart)) return;
    tapRef = true; e.preventDefault();
  });
  scroller.addEventListener('click', (e) => {
    if (!tapRef) return; tapRef = false;
    const c = e.target.closest && e.target.closest('.lz-c'), rowEl = c && c.closest('.lz-row'); if (!c || !rowEl || document.activeElement !== val) return;
    const addr = L.cellAddr(Number(c.dataset.c), c.dataset.ar !== undefined ? Number(c.dataset.ar) : Number(rowEl.dataset.r)); if (!addr) return;
    e.stopImmediatePropagation(); e.preventDefault();
    const r = insertRef(val.value, val.selectionStart, addr); val.value = r.text; try { val.setSelectionRange(r.caret, r.caret); } catch (_) {}
    val.dispatchEvent(new Event('input')); // pratinjau hasil + chip Rentang
  }, true);
  // Rev 259 / M1: tekan lama sel = Menu sel
  let lpT = 0, lpD = null, lpFired = false, cmAt = 0;
  const copyKeep = (cut) => {
    normSel(); const keep = selx, ks = sel, before = clip; doCopy();
    if (keep) { selx = keep; selxTab = tab.id; sel = ks; normKey = ''; normSel(); }
    if (cut && clip && clip !== before) applyAct('clear'); else { lastKey = ''; drawRows(); paintBar(); }
  };
  const openCellMenu = () => {
    commit(); normSel(); const sx = selx; if (!sx) return; cmAt = Date.now();
    const ov = h('div', { class: 'ov dlgov lz-more lz-cm', onclick: (e) => { if (e.target === ov && Date.now() - cmAt > 350) ov.remove(); } });
    const ic = (d) => h('i', { class: 'cm-ic', 'aria-hidden': 'true' }, ico(d));
    const bt = (cls, id, d, label, fn, o = {}) => { const b = h('button', { type: 'button', class: cls + (o.red ? ' red' : ''), 'data-cm': id, onclick: () => { ov.remove(); fn(); } }, ...(d ? [ic(d)] : []), h('b', {}, label)); if (o.off) b.disabled = true; return b; };
    const act = (kind, label, red, msg) => bt('cm-p', kind, '', label, () => (msg ? dlg({ title: AS.labelOf(kind, sx) + '?', msg, yes: 'Hapus', red: true, ok: () => applyAct(kind) }) : applyAct(kind)), { red });
    const rn = SX.rowCount(sx), cn = SX.colCount(sx), P = 'M9 4h6v3H9zM7 5H5v16h14V5h-2';
    ov.append(h('div', { class: 'sheet' },
      h('div', { class: 'cm-h' }, h('h3', {}, 'Menu sel'), h('span', { class: 'cm-ref' }, SX.refText(sx, L.cellAddr))),
      h('div', { class: 'cm-qs' },
        bt('cm-q', 'cut', 'M6 9a3 3 0 100-6 3 3 0 000 6zM6 21a3 3 0 100-6 3 3 0 000 6zM20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12', 'Potong', () => copyKeep(true)),
        bt('cm-q', 'copy', PATH.copy, 'Salin', () => copyKeep(false)),
        bt('cm-q', 'paste', P, 'Tempel', () => runPaste({ mode: 'all' }), { off: !clip }),
        bt('cm-q', 'pasteval', P + 'M9 14l2 2 4-4', 'Nilai saja', () => runPaste({ mode: 'values' }), { off: !clip })),
      h('div', { class: 'cm-g' }, h('span', {}, rn > 1 ? 'Baris ' + rn : 'Baris'), act('rowUp', 'Sisip atas'), act('rowDown', 'Sisip bawah'), act('delRows', 'Hapus', true, 'Baris terpilih dihapus. Bisa dibatalkan dengan Urungkan.')),
      h('div', { class: 'cm-g' }, h('span', {}, cn > 1 ? 'Kolom ' + cn : 'Kolom'), act('colLeft', 'Sisip kiri'), act('colRight', 'Sisip kanan'), act('delCols', 'Hapus', true, 'Kolom terpilih dihapus; rumus yang merujuknya menjadi #REF!. Bisa dibatalkan dengan Urungkan.')),
      h('div', { class: 'cm-lst' },
        bt('cm-r', 'merge', 'M4 5h16v14H4zM9 9l-3 3 3 3M15 9l3 3-3 3', (sel && mergeAt(tab, sel.r, sel.c) && !mergeRange()) ? 'Pisahkan sel' : 'Gabungkan sel', openMerge),
        bt('cm-r', 'clear', 'M4 17l9-11 7 6-6 8H8zM9 21h11', 'Hapus isi', () => applyAct('clear')),
        bt('cm-r', 'dropdown', 'M4 6h16v12H4zM9 11l3 3 3-3', 'Dropdown', openChecks),
        bt('cm-r', 'chart', 'M5 20V10M12 20V4M19 20v-7', 'Diagram dari sel ini', openChart),
        ...freezeItems(sx, bt))));
    document.body.append(ov);
  };
  // Rev 302b: item Bekukan di Menu sel (gaya Google Sheets). Seluruh baris terpilih = 'Bekukan sampai baris N'; seluruh kolom = 'sampai kolom X'; sel/rentang = dua pilihan; pojok = hanya Lepas. Sudah beku = tambah 'Lepas bekukan'. Memakai applyFreeze (1 langkah Urungkan, tolak kolom terlalu lebar).
  const freezeItems = (sx, bt) => {
    const IC = 'M4 5h16v14H4zM4 10h16M9.5 10v9', f = getFreeze(tab), out = [], r2 = sx.rect.r2, c2 = sx.rect.c2, k = sx.kind;
    if (k !== 'col' && k !== 'all') out.push(bt('cm-r', 'frz-rows', IC, 'Bekukan sampai baris ' + (r2 + 1), () => applyFreeze('rows', r2, -1)));
    if (k !== 'row' && k !== 'all') out.push(bt('cm-r', 'frz-cols', IC, 'Bekukan sampai kolom ' + L.colLabel(c2), () => applyFreeze('cols', -1, c2)));
    if (f.r || f.c) out.push(bt('cm-r', 'frz-off', IC, 'Lepas bekukan (' + freezeLabel(tab) + ')', () => applyFreeze('none')));
    return out;
  };
  const onLongPress = (c) => {
    if (document.querySelector('.lz-cm')) return;
    if (!c.classList.contains('lz-c')) { // Rev 302b: tahan nomor baris / kepala kolom / pojok = pilih seluruhnya (kecuali sudah terpilih, mis. hasil seret) lalu Menu sel
      commit(); normSel(); const dm = SX.dimsOfTab(tab), kd = c.classList.contains('lz-rn') ? 'row' : c.classList.contains('lz-hc') ? 'col' : 'all', rw = kd === 'row' ? c.closest('.lz-row') : null;
      const held = !!selx && selx.kind === kd && (kd === 'all' || (kd === 'col' ? SX.contains(selx, 0, Number(c.dataset.c)) : !!rw && SX.contains(selx, Number(rw.dataset.r), 0)));
      if (!held) pick({ target: c });
      try { val.blur(); } catch (_) { /* abaikan */ }
      try { if (navigator.vibrate) navigator.vibrate(15); } catch (_) { /* abaikan */ }
      openCellMenu(); return;
    }
    const rowEl = c.closest('.lz-row'); if (!rowEl) return; commit(); normSel();
    const nr = c.dataset.ar !== undefined ? Number(c.dataset.ar) : Number(rowEl.dataset.r), nc = Number(c.dataset.c);
    if (!selx || !SX.contains(selx, nr, nc)) { sel = { r: nr, c: nc }; selx = SX.selectCell(SX.dimsOfTab(tab), nr, nc, mergeList(tab)); selxTab = tab.id; normKey = ''; lastKey = ''; buildHead(); drawRows(); paintBar(); }
    try { val.blur(); } catch (_) { /* abaikan */ }
    try { if (navigator.vibrate) navigator.vibrate(15); } catch (_) { /* abaikan */ }
    openCellMenu();
  };
  scroller.addEventListener('pointerdown', (e) => {
    clearTimeout(lpT); lpFired = false; lpD = null; const c = e.target.closest && !e.target.closest('.lz-rz, .lz-rzr') && e.target.closest('.lz-c, .lz-rn, .lz-hc, .lz-corner'); if (!c || e.isPrimary === false) return; // Rev 302b: + kepala (bukan pegangan seret lebar/tinggi)
    lpD = { x: e.clientX, y: e.clientY }; lpT = setTimeout(() => { lpT = 0; lpD = null; lpFired = true; onLongPress(c); }, 450);
  });
  scroller.addEventListener('pointermove', (e) => { if (lpD && Math.hypot(e.clientX - lpD.x, e.clientY - lpD.y) > 10) { clearTimeout(lpT); lpD = null; } });
  ['pointerup', 'pointercancel'].forEach((n) => scroller.addEventListener(n, () => { clearTimeout(lpT); lpD = null; }));
  scroller.addEventListener('contextmenu', (e) => { const c = e.target.closest && e.target.closest('.lz-c, .lz-rn, .lz-hc, .lz-corner'); if (!c) return; e.preventDefault(); if (!lpFired) { lpFired = true; onLongPress(c); } });
  scroller.addEventListener('click', (e) => { if (!lpFired) return; lpFired = false; e.stopImmediatePropagation(); e.preventDefault(); }, true);
  scroller.addEventListener('scroll', onScroll, { passive: true });
  scroller.addEventListener('click', pick);
  x.onclick = () => closeSheet();
  titleEl.onclick = () => { commit(); namePrompt({ title: 'Ubah nama lembar kerja', value: sheet.name, onOk: (name) => { const snap = ser(); if (L.renameSheet(sheet, name)) { ver++, hist.push(snap); paintUndo(); titleEl.textContent = sheet.name; touched(); } } }); };
  document.body.append(root);
  refresh(true);
  cur = { root, close: () => { try { commit(); } catch (_) { /* Rev 127: isian yang belum disimpan ikut tersimpan saat layar ditutup (Kembali HP / tombol tutup) */ } if (raf) cancelAnimationFrame(raf); raf = 0; if (hd) { cancelAnimationFrame(hd.raf); hd = null; } root.remove(); if (typeof onClose === 'function') onClose(); } };
  return true;
}
