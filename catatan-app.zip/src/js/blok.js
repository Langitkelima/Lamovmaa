/**
 * Fondasi blok pulau Notes Kelimaa.
 * Blok didaftarkan per jenis agar data tersimpan tetap ringan dan renderer
 * dapat dibangun ulang ketika catatan dibuka. Modul ini tidak mengubah HTML
 * catatan lama dan tidak mengizinkan atribut data bebas.
 */
const registry = new Map();

export function registerBlock(definition) {
  if (!definition || typeof definition.type !== 'string' || !/^[a-z][a-z0-9-]{0,23}$/.test(definition.type)) {
    throw new TypeError('Jenis blok tidak valid.');
  }
  if (typeof definition.selector !== 'string' || !definition.selector.trim()) {
    throw new TypeError('Selector blok wajib diisi.');
  }
  if (registry.has(definition.type)) throw new Error(`Jenis blok "${definition.type}" sudah terdaftar.`);
  const clean = {
    type: definition.type,
    selector: definition.selector,
    render: typeof definition.render === 'function' ? definition.render : () => {},
    strip: typeof definition.strip === 'function' ? definition.strip : () => {},
    tools: typeof definition.tools === 'function' ? definition.tools : null,
    toText: typeof definition.toText === 'function' ? definition.toText : () => '',
    toBlocks: typeof definition.toBlocks === 'function' ? definition.toBlocks : () => []
  };
  registry.set(clean.type, Object.freeze(clean));
  return clean;
}

export function getBlock(type) { return registry.get(type) || null; }
export function registeredBlockTypes() { return [...registry.keys()]; }

export function hydrateBlocks(root) {
  if (!root || typeof root.querySelectorAll !== 'function') return 0;
  let count = 0;
  for (const def of registry.values()) {
    const matches = [...root.querySelectorAll(def.selector)];
    if (root.nodeType === 1 && root.matches(def.selector)) matches.unshift(root);
    for (const el of matches) {
      def.render(el);
      count++;
    }
  }
  return count;
}

export function stripBlockTools(root) {
  if (!root || typeof root.querySelectorAll !== 'function') return 0;
  let count = 0;
  for (const def of registry.values()) {
    const matches = [...root.querySelectorAll(def.selector)];
    if (root.nodeType === 1 && root.matches(def.selector)) matches.unshift(root);
    for (const el of matches) {
      def.strip(el);
      count++;
    }
  }
  root.querySelectorAll('[data-kb-tool],.kb-tool,.kb-actions').forEach((el) => { el.remove(); count++; });
  if (root.nodeType === 1 && root.matches('[data-kb-tool],.kb-tool,.kb-actions')) { root.remove(); count++; }
  return count;
}
