// Rev 122 / U7b-1: PULAU pratinjau lembar kerja di dalam catatan.
// Di HTML catatan hanya tersimpan: <div class="ksheet" contenteditable="false" data-sheet="ID"></div> (TANPA isi sel; byte data tetap di data.sheets).
// Pratinjau dibangun ulang saat catatan dibuka / sesudah Urungkan / sesudah layar lembar kerja ditutup. Hanya BACA: mengubah sel = layar penuh (lembar-ui.js).
// Tanpa <table>/<td>/<input> di dalam pulau supaya alat tabel catatan tidak salah mengira pratinjau sebagai tabel catatan.
import * as L from './lembar.js';
import { makeDisplay, hasContent, fxFromA1 } from './lembar-tampil.js'; // Rev 134 / U8b-1: teks tampilan = HASIL rumus + format angka (sama dengan grid)
import { parseNum } from './tabel-hitung.js';
import { parseWidths, colCount } from './tabel.js'; // Rev 320: lebar kolom tabel catatan -> lebar kolom lembar
import { chartData, chartSvg } from './lembar-diagram.js'; // Rev 160 / U10c-3a: diagram tersimpan (tab pertama) tampil di pulau
import { mergeMap } from './lembar-gabung.js'; // Rev 153 / U10b-3: gabungan MELEBAR (kolom) digambar menyatu di pulau dan ekspor
import { checkRect, checkAt, colorOf } from './lembar-validasi.js'; // Rev 268 / V2b: warna pilihan (validasi data) tampil di pulau dan ekspor; modul murni tanpa impor, sudah ada di jalur buka (dipakai lembar.js)

// Perantara untuk notes.js (tes rev114 mengunci agar notes.js tidak mengimpor lembar.js langsung).
export const isSheetId = L.isSheetId, newSheet = L.newSheet, MAX_SHEETS = L.MAX_SHEETS;
export const PREVIEW_ROWS = 6, PREVIEW_COLS = 4, MIN_ROWS = 3, MIN_COLS = 3;
const HEX = /^#[0-9a-fA-F]{6}$/;
// Rev 262 / S8: teks otomatis di atas isian: gelap di isian terang, terang di isian gelap. Salinan kecil dari inkOn di lembar-warna.js
// (tanpa impor supaya jalur buka tidak bertambah); tes rev262 menjaga keduanya selalu sama. Ambang = luminansi 0,19387 (titik kontras sama dengan #F9FAFB dan #111827).
const inkOnFill = (bg) => { const n = parseInt(bg.slice(1), 16), ch = (v) => { const x = v / 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }; return 0.2126 * ch((n >> 16) & 255) + 0.7152 * ch((n >> 8) & 255) + 0.0722 * ch(n & 255) < 0.19387 ? '#F9FAFB' : '#111827'; };
let source = () => ({});
// notes.js mengisi sumber data (data.sheets) saat editor dibuka.
export function setSheetsSource(fn) { source = typeof fn === 'function' ? fn : () => ({}); }
export const sheetById = (id) => { try { const m = source() || {}; return L.isSheetId(id) && Object.prototype.hasOwnProperty.call(m, id) ? m[id] : null; } catch (_) { return null; } };

// Rev 153 / U10b-3 + Rev 155 / U10b-4: bidang gabungan sel untuk satu sel jendela (nc kolom x nr baris yang ditampilkan).
// Jangkar membawa cs (jumlah kolom, dipotong ke jendela). Sel tertutup SEBARIS dengan jangkar = cv (dilewati penggambar).
// Baris-baris di bawah jangkar (gabungan tegak): sel kolom pertama gabungan menjadi sel LANJUTAN (vu = bersambung dari atas, membawa cs), sel lainnya cv.
// vd = bersambung ke bawah (dipotong ke jendela). Penggambar menghapus garis atas bila vu dan garis bawah bila vd, jadi gabungan tampak satu kotak.
// Objek kosong bila tidak ada gabungan (bentuk model lama persis sama).
function spanOf(mm, i, j, nc, nr) {
  const m = mm && mm.get(i + ',' + j); if (!m) return {};
  const cs = Math.min(m.c2, nc - 1) - m.c1 + 1, out = {};
  if (m.r1 === i && m.c1 === j) { if (cs > 1) out.cs = cs; }
  else if (m.r1 === i || j !== m.c1) return { cv: true };
  else { if (cs > 1) out.cs = cs; out.vu = true; }
  if (i < Math.min(m.r2, nr - 1)) out.vd = true;
  return out;
}
// Rev 184c-1 / U10e-3: tinggi baris bebas di pratinjau. MURNI. Hanya baris ber-`h` (bukan 40) yang dicatat: rowH[i] = px grid, 0 = bawaan; undefined bila tidak ada satu pun.
// Pulau = pratinjau kecil (font 12.5 vs 15 di grid): tinggi diskalakan 0.8 dan dibatasi ISLAND_H_MIN..ISLAND_H_MAX supaya satu baris tinggi tidak memakan seluruh catatan.
export const ISLAND_H_SCALE = 0.8, ISLAND_H_MIN = 20, ISLAND_H_MAX = 120;
export const islandRowPx = (h) => { const n = Number(h); return Number.isFinite(n) && n > 0 ? Math.min(ISLAND_H_MAX, Math.max(ISLAND_H_MIN, Math.round(n * ISLAND_H_SCALE))) : 0; };
export function rowHeightsOf(tab, nr) { const a = []; let any = false; for (let i = 0; i < nr; i++) { const h = tab.rows[i] && L.cleanRowH(tab.rows[i].h); a.push(h || 0); if (h) any = true; } return any ? a : undefined; }
// Rev 268 / V2b: MURNI. Warna pilihan (validasi data) per sel, SAMA dengan grid (lembar-ui.js drawRows): aturan PERTAMA yang mencakup sel, teks TAMPIL sel dicocokkan dengan pilihan,
// gaya sel manual (bg) MENANG, sel galat rumus tidak diwarnai. Rentang tiap aturan dihitung SEKALI. null bila tab tanpa aturan berwarna. Hasil: { bg?, fg? } atau null.
export function pickPainter(tab, d) {
  const ckr = (Array.isArray(tab && tab.checks) ? tab.checks : []).map((ck) => ({ ck, rc: checkRect(tab, ck) })).filter((x) => x.rc);
  if (!ckr.length) return null;
  return (i, j, text, manualBg) => {
    if (manualBg) return null;
    let ck = null; for (const x of ckr) if (i >= x.rc.r1 && i <= x.rc.r2 && j >= x.rc.c1 && j <= x.rc.c2) { ck = x.ck; break; }
    if (!ck || !ck.cl || (d && d.err(i, j))) return null;
    const vc = colorOf(ck, text); if (!vc) return null;
    const out = {}; if (HEX.test(vc.bg || '')) out.bg = vc.bg; if (HEX.test(vc.fg || '')) out.fg = vc.fg;
    return out.bg || out.fg ? out : null;
  };
}
// MURNI: model pratinjau tab pertama. null bila lembar tidak ada.
// Rev 303d: sel di rentang aturan Kotak centang (tanpa rumus; kosong/boolean/TRUE-FALSE) tampil \u2611/\u2610 di pulau, kartu, ekspor; plain/salin dan pencarian tetap TRUE/FALSE
const boxView = (tab, d) => !Array.isArray(tab.checks) || !tab.checks.some((c) => c && c.k === 'box') ? d : { ...d, text: (i, j) => {
  const cell = tab.rows[i] && tab.cols[j] ? tab.rows[i].cells[tab.cols[j].id] : null, ck = cell && typeof cell.fx === 'string' ? null : checkAt(tab, i, j), v = cell ? cell.v : undefined;
  return ck && ck.k === 'box' && (v === undefined || v === null || v === '' || typeof v === 'boolean' || /^(true|false)$/i.test(String(v).trim())) ? (v === true || /^true$/i.test(String(v).trim()) ? '\u2611' : '\u2610') : d.text(i, j);
} };
export function islandModel(sheet, maxRows = PREVIEW_ROWS, maxCols = PREVIEW_COLS, opts = {}) {
  if (!sheet || !Array.isArray(sheet.tabs) || !sheet.tabs.length) return null;
  const tab = sheet.tabs[0], d = boxView(tab, makeDisplay(tab, opts)); // Rev 134: sel berumus = hasilnya, sel berformat = angka terformat
  let lastR = -1, lastC = -1;
  tab.rows.forEach((r, i) => tab.cols.forEach((c, j) => { const x = r.cells[c.id]; if (x && (hasContent(x) || (x.s && x.s.bg))) { lastR = Math.max(lastR, i); lastC = Math.max(lastC, j); } }));
  const nr = Math.min(maxRows, Math.max(MIN_ROWS, lastR + 1)), nc = Math.min(maxCols, Math.max(MIN_COLS, lastC + 1));
  const rows = [], mm = mergeMap(tab).size ? mergeMap(tab) : null, pk = pickPainter(tab, d); // Rev 268 / V2b
  for (let i = 0; i < nr; i++) {
    const row = [];
    for (let j = 0; j < nc; j++) {
      const cell = tab.rows[i] && tab.cols[j] ? tab.rows[i].cells[tab.cols[j].id] || null : null;
      const s = cell && cell.s ? cell.s : {};
      const t = d.text(i, j), mbg = HEX.test(s.bg || '') ? s.bg : '', mfg = HEX.test(s.fg || '') ? s.fg : '', vc = pk && t ? pk(i, j, t, mbg) : null; // Rev 268: gaya manual menang; fg manual menang atas fg pilihan
      row.push({ t, b: s.b === true, i: s.i === true, ha: s.ha === 'center' || s.ha === 'end' ? s.ha : 'start', bg: mbg || (vc && vc.bg) || '', fg: mfg || (vc && vc.fg) || '', ...spanOf(mm, i, j, nc, nr) });
    }
    rows.push(row);
  }
  const rowH = rowHeightsOf(tab, nr); // Rev 184c-1
  return { name: sheet.name, tab: tab.name, tabs: sheet.tabs.length, nr, nc, moreRows: lastR + 1 > maxRows, moreCols: lastC + 1 > maxCols, empty: lastR < 0, cols: tab.cols.slice(0, nc).map((_, j) => L.colLabel(j)), rows, ...(rowH ? { rowH } : {}) };
}

// Rev 160 / U10c-3a: MURNI. Diagram tersimpan (tab.charts) dari TAB PERTAMA, yang sama dengan tab pratinjau tabel. Maks. ISLAND_CHARTS digambar di pulau; sisanya hanya dihitung (more).
// Latar putih berdiri sendiri (sama dengan dialog Diagram). Diagram yang tidak bisa digambar (tanpa angka dsb.) dilewati. Gagal apa pun = daftar kosong (pulau tabel tidak boleh rusak).
export const ISLAND_CHARTS = 2, ISLAND_CHART_WIDTH = 360;
export function islandCharts(sheet) {
  const out = { items: [], more: 0 };
  try {
    const tab = sheet && Array.isArray(sheet.tabs) && sheet.tabs[0]; if (!tab) return out;
    const list = L.listCharts(tab);
    for (const c of list) {
      if (out.items.length >= ISLAND_CHARTS) { out.more++; continue; }
      const d = chartData(tab, c.src, { valueCol: c.valueCol }); if (!d.ok) continue;
      const res = chartSvg(d, { kind: c.kind, title: c.title, legend: c.legend, width: ISLAND_CHART_WIDTH, theme: { bg: '#FFFFFF' } }); if (!res.ok) continue;
      out.items.push({ id: c.id, ref: c.ref, kind: c.kind, svg: res.svg });
    }
  } catch (_) { return { items: [], more: 0 }; }
  return out;
}

// Rev 161 / U10c-3b: MURNI. Diagram tersimpan tab pertama untuk ekspor PDF/JPG (TXT/MD tidak memuat diagram). Maks. EXPORT_CHARTS; latar putih berdiri sendiri;
// diagram yang tidak bisa digambar dilewati; gagal apa pun = daftar kosong (ekspor tabel tidak boleh rusak). Hanya diminta lewat opts.charts di exportModel.
export const EXPORT_CHARTS = 6, EXPORT_CHART_WIDTH = 520;
export function exportCharts(sheet) {
  const out = [];
  try {
    const tab = sheet && Array.isArray(sheet.tabs) && sheet.tabs[0]; if (!tab) return out;
    for (const c of L.listCharts(tab)) {
      if (out.length >= EXPORT_CHARTS) break;
      const d = chartData(tab, c.src, { valueCol: c.valueCol }); if (!d.ok) continue;
      const res = chartSvg(d, { kind: c.kind, title: c.title, legend: c.legend, width: EXPORT_CHART_WIDTH, theme: { bg: '#FFFFFF' } }); if (!res.ok || !(res.w > 0) || !(res.h > 0)) continue;
      out.push({ id: c.id, ref: c.ref, kind: c.kind, title: String(c.title || ''), svg: res.svg, w: res.w, h: res.h });
    }
  } catch (_) { return []; }
  return out;
}

// Rev 123 / U7b-2: MURNI. Model ekspor tab pertama (TXT/MD/PDF/JPG). Baris/kolom ekor yang tanpa NILAI dibuang (gaya saja tidak dihitung, seperti tabToTsv).
// Batas rows/cols dipakai PDF/JPG (muat di halaman); TXT/MD memakai batas model penuh. Warna sel manual TIDAK diekspor (kertas ekspor punya latar sendiri, teks terang bisa hilang); Rev 268: warna PILIHAN (validasi data) diekspor sebagai isian sel + teks eksplisit.
export const EXPORT_ALL = { rows: L.MAX_ROWS, cols: L.MAX_COLS };
export function exportModel(sheet, lim = EXPORT_ALL, opts = {}) {
  if (!sheet || !Array.isArray(sheet.tabs) || !sheet.tabs.length) return null;
  const tab = sheet.tabs[0], d = boxView(tab, makeDisplay(tab, opts)); // Rev 134 / U8b-1: HASIL rumus + format angka (bukan nilai mentah / rumus)
  const maxR = Math.max(1, Math.min(L.MAX_ROWS, Math.floor(Number(lim && lim.rows)) || L.MAX_ROWS)), maxC = Math.max(1, Math.min(L.MAX_COLS, Math.floor(Number(lim && lim.cols)) || L.MAX_COLS));
  let lastR = -1, lastC = -1;
  tab.rows.forEach((r, i) => tab.cols.forEach((c, j) => { const x = r.cells[c.id]; if (hasContent(x)) { lastR = Math.max(lastR, i); lastC = Math.max(lastC, j); } }));
  const totalRows = lastR + 1, totalCols = lastC + 1, nr = Math.min(maxR, totalRows), nc = Math.min(maxC, totalCols);
  const rows = [], mm = mergeMap(tab).size ? mergeMap(tab) : null, pk = pickPainter(tab, d); // Rev 268
  for (let i = 0; i < nr; i++) {
    const row = [];
    for (let j = 0; j < nc; j++) {
      const cell = tab.rows[i].cells[tab.cols[j].id] || null; const s = cell && cell.s ? cell.s : {};
      const t = d.text(i, j).replace(/[\t\r\n]+/g, ' '), vc = pk && t ? pk(i, j, t, HEX.test(s.bg || '') ? s.bg : '') : null; // Rev 268 / V2b: HANYA warna pilihan yang berisian (bg) yang diekspor, dengan teks eksplisit yang terbaca; warna sel manual tetap TIDAK diekspor
      row.push({ t, b: s.b === true, i: s.i === true, a: s.ha === 'center' ? 'c' : s.ha === 'end' ? 'r' : '', ...(vc && vc.bg ? { bg: vc.bg, fg: vc.fg || inkOnFill(vc.bg) } : {}), ...spanOf(mm, i, j, nc, nr) });
    }
    rows.push(row);
  }
  const rowH = rowHeightsOf(tab, nr); // Rev 184c-1: tinggi baris dibawa ke model ekspor (dipakai PDF/JPG di 184c-2; TXT/MD mengabaikan)
  return { name: sheet.name, tab: tab.name, tabs: sheet.tabs.length, empty: totalRows === 0, totalRows, totalCols, rows, ...(rowH ? { rowH } : {}), ...(opts && opts.charts === true ? { charts: exportCharts(sheet) } : {}) }; // Rev 161: diagram HANYA bila diminta (PDF/JPG)
}

// Rev 124 / U7b-3: tabel catatan -> lembar kerja. Teks sel dijadikan ANGKA hanya bila isinya murni angka (tanda, digit, titik/koma); teks ber-"Rp", "%" atau satuan
// tetap TEKS supaya tidak ada yang hilang diam-diam (parseNum akan membuang "Rp"/"%"). Baris judul (TH) dan baris Total dicetak tebal; data-a c/r jadi rata tengah/kanan.
export const PURE_NUM = /^[+\-\u2212]?\d[\d.,]*$/;
export function cellValueFromText(text) {
  const t = String(text == null ? '' : text).replace(/\s+/g, ' ').trim();
  if (!t) return undefined;
  if (PURE_NUM.test(t)) { const n = parseNum(t.replace('\u2212', '-')); if (n !== null) return n; }
  return t;
}
// DOM: tabel catatan -> matriks [[{v?, b, ha, tf?, r1?, r2?}]]. Rev 136 / U8b-3: sel baris Total ber-data-f (sum/avg/cnt/min/max) membawa tf + rentang baris data (r1..r2, indeks matriks)
// bila SEMUA angka di kolomnya "murni" (aman jadi rumus: hasil sama dengan tabel); selain itu tetap nilai biasa (teks "Jumlah: ...") seperti Rev 124.
export const TOTAL_FN = { sum: 'SUM', avg: 'AVERAGE', cnt: 'COUNT', min: 'MIN', max: 'MAX' };
export function matrixFromTable(table) {
  const rows = [...table.rows], isTt = (r) => !!(r.classList && r.classList.contains('tt'));
  const data = rows.map((r, i) => ({ r, i })).filter((x) => !isTt(x.r));
  const head = data.length > 0 && data[0].r.cells.length > 0 && [...data[0].r.cells].every((x) => x.tagName === 'TH');
  const body = data.slice(head ? 1 : 0), r1 = body.length ? body[0].i : -1, r2 = body.length ? body[body.length - 1].i : -1;
  const colRange = (j) => { // rentang rumus kolom j + apakah aman (semua teks yang terbaca angka oleh tabel juga angka murni; ada minimal satu angka)
    let nums = 0;
    for (const x of body) { const c = x.r.cells[j]; if (!c || c.tagName !== 'TD') continue; const t = cellValueFromText(c.textContent); const asNum = parseNum(String(c.textContent || '').replace('\u2212', '-')); if (asNum !== null && typeof t !== 'number') return null; if (typeof t === 'number') nums++; }
    return nums ? { r1, r2 } : null;
  };
  const out = [];
  for (const row of rows) {
    const total = isTt(row);
    out.push([...row.cells].map((c, j) => {
      const a = c.getAttribute('data-a'); const cl = c.cloneNode(true); cl.querySelectorAll('br').forEach((x) => x.replaceWith(' '));
      const o = { v: cellValueFromText(cl.textContent), b: c.tagName === 'TH' || total, ha: a === 'c' ? 'center' : a === 'r' ? 'end' : 'start' };
      const f = total ? c.getAttribute('data-f') : ''; const rg = f && TOTAL_FN[f] && r1 >= 0 ? colRange(j) : null;
      if (rg) { o.tf = f; o.r1 = rg.r1; o.r2 = rg.r2; }
      return o;
    }));
  }
  out.w = parseWidths(table.getAttribute('data-w') || '', colCount(table)); // Rev 320: lebar kolom tabel ikut jadi lebar kolom lembar
  return out;
}
// MURNI: matriks -> objek lembar kerja baru (tab 1). null bila kosong, melewati batas, atau melewati ukuran.
export function sheetFromMatrix(matrix, { name = 'Lembar kerja', id } = {}) {
  if (!Array.isArray(matrix) || !matrix.length) return null;
  const nr = matrix.length, nc = matrix.reduce((m, r) => Math.max(m, Array.isArray(r) ? r.length : 0), 0);
  if (nr > L.MAX_ROWS || nc < 1 || nc > L.MAX_COLS) return null;
  const sh = L.newSheet({ id, name }); const tab = sh.tabs[0];
  if (nr > tab.rows.length) L.addRows(tab, nr - tab.rows.length);
  matrix.forEach((row, i) => row.forEach((c, j) => {
    if (!c) return; const s = {}; if (c.b) s.b = true; if (c.ha === 'center' || c.ha === 'end') s.ha = c.ha;
    L.setCell(tab, tab.rows[i].id, tab.cols[j].id, { ...(c.v !== undefined ? { v: c.v } : {}), ...(Object.keys(s).length ? { s } : {}) });
  }));
  if (Array.isArray(matrix.w)) matrix.w.forEach((w, j) => { if (w > 0 && tab.cols[j]) L.setColWidth(tab, tab.cols[j].id, w); }); // Rev 320
  // Rev 136 / U8b-3: sel Total ber-tf menjadi RUMUS hidup (mis. =SUM(B2:B5)); gagal = tetap nilai biasa. Dikerjakan SESUDAH semua sel ada (rujukan butuh ID baris/kolom).
  matrix.forEach((row, i) => row.forEach((c, j) => {
    if (!c || !c.tf || !TOTAL_FN[c.tf] || !Number.isInteger(c.r1) || !Number.isInteger(c.r2) || c.r2 < c.r1 || j >= L.MAX_COLS) return;
    const col = L.colLabel(j), fx = fxFromA1('=' + TOTAL_FN[c.tf] + '(' + col + (c.r1 + 1) + ':' + col + (c.r2 + 1) + ')', tab);
    if (fx) L.setCell(tab, tab.rows[i].id, tab.cols[j].id, { fx });
  }));
  return L.fitsLimit(sh) ? sh : null;
}

// MURNI: teks ringkas untuk pratinjau daftar / pencarian / ekspor teks (dipakai U7b-4).
export function islandText(sheet) { return sheet ? 'Lembar kerja: ' + sheet.name : 'Lembar kerja'; }

// Rev 135 / U8b-2: MURNI. Teks pencarian satu lembar kerja = isi SEMUA tab (HASIL rumus + format angka, sama dengan grid), sel dipisah spasi, baris dipisah baris baru, dipotong maxChars.
export const SEARCH_MAX = 20000;
export function sheetSearchText(sheet, maxChars = SEARCH_MAX, opts = {}) {
  if (!sheet || !Array.isArray(sheet.tabs)) return '';
  const out = [];
  let n = 0;
  for (const tab of sheet.tabs) {
    const d = makeDisplay(tab, opts);
    for (let i = 0; i < tab.rows.length && n < maxChars; i++) {
      const row = [];
      for (let j = 0; j < tab.cols.length; j++) { if (!d.has(i, j)) continue; const t = d.text(i, j).replace(/[\t\r\n]+/g, ' ').trim(); if (t) row.push(t); }
      if (row.length) { const line = row.join(' '); out.push(line); n += line.length + 1; }
    }
    if (n >= maxChars) break;
  }
  return out.join('\n').slice(0, maxChars);
}
// Rev 137 / U8b-4: MURNI. Pratinjau KARTU daftar Catatan: isi ringkas lembar kerja (HASIL rumus + format angka, sama dengan grid), dihitung SAAT KARTU DIGAMBAR (selalu segar, tidak disimpan di n.text).
// Tab pertama yang punya isi; sel dipisah spasi, baris dipisah "; ", dipotong CARD_PREVIEW_MAX huruf + "…".
export const CARD_PREVIEW_MAX = 160;
export function sheetCardText(sheet, maxChars = CARD_PREVIEW_MAX, opts = {}) {
  if (!sheet || !Array.isArray(sheet.tabs)) return '';
  for (const tab of sheet.tabs) {
    if (!tab || !Array.isArray(tab.rows) || !Array.isArray(tab.cols)) continue;
    const d = boxView(tab, makeDisplay(tab, opts)), lines = []; let n = 0;
    for (let i = 0; i < tab.rows.length && n <= maxChars; i++) {
      const row = [];
      for (let j = 0; j < tab.cols.length; j++) { if (!d.has(i, j)) continue; const t = d.text(i, j).replace(/\s+/g, ' ').trim(); if (t) row.push(t); }
      if (row.length) { const line = row.join(' '); lines.push(line); n += line.length + 2; }
    }
    if (lines.length) { const s = lines.join('; '); return s.length > maxChars ? s.slice(0, Math.max(1, maxChars - 1)).trimEnd() + '…' : s; }
  }
  return '';
}
// Teks pratinjau kartu: n.text dengan tiap baris ringkasan pulau ("Lembar kerja: Nama", disimpan notePlain) diganti "Lembar kerja: NamaTerbaru — isi ringkas".
// Baris dipasangkan dengan pulau di HTML menurut URUTAN; bila jumlahnya tidak sama (mis. pengguna mengetik sendiri "Lembar kerja: ...") teks dikembalikan APA ADANYA. Lembar hilang = baris dibiarkan.
export function notePreviewText(n, getSheet = sheetById, opts = {}) {
  const text = String((n && n.text) || ''), html = String((n && n.html) || '');
  if (text.indexOf('Lembar kerja') < 0 || html.indexOf('ksheet') < 0) return text;
  const ids = [], re = /data-sheet\s*=\s*"([a-z0-9]{4,24})"/g; let m;
  while ((m = re.exec(html))) ids.push(m[1]);
  const lines = text.split('\n'), at = [];
  lines.forEach((l, i) => { if (/^Lembar kerja(: .*)?$/.test(l)) at.push(i); });
  if (!ids.length || at.length !== ids.length) return text;
  try {
    at.forEach((li, k) => {
      const sh = getSheet(ids[k]); if (!sh) return;
      const body = sheetCardText(sh, CARD_PREVIEW_MAX, opts);
      lines[li] = 'Lembar kerja: ' + String(sh.name || '') + (body ? ' — ' + body : '');
    });
  } catch (_) { return text; }
  return lines.join('\n');
}
// ID lembar kerja yang dipakai satu catatan (dari data-sheet di HTML tersimpan), tanpa duplikat. MURNI.
export function sheetIdsIn(html) {
  const s = String(html || ''); if (s.indexOf('ksheet') < 0) return [];
  const ids = [], re = /data-sheet\s*=\s*"([a-z0-9]{4,24})"/g; let m;
  while ((m = re.exec(s))) if (!ids.includes(m[1])) ids.push(m[1]);
  return ids;
}
// Teks pencarian tambahan sebuah catatan: isi semua lembar kerja yang disisipkan di dalamnya. Dihitung SAAT MENCARI (selalu segar, tidak disimpan di n.text).
export function noteSheetSearchText(html, getSheet = sheetById) {
  const ids = sheetIdsIn(html); if (!ids.length) return '';
  return ids.map((id) => sheetSearchText(getSheet(id))).filter(Boolean).join('\n');
}

const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };

// Baris kaki: petunjuk + tombol "Hapus dari catatan" (hanya melepas pulau; lembar kerja tetap ada di Setelan > Lembar kerja).
function footRow(text) { const f = mk('div', 'ks-foot'); f.append(mk('span', 'ks-hint', text)); const d = mk('span', 'ks-del', 'Hapus dari catatan'); d.setAttribute('role', 'button'); d.setAttribute('tabindex', '-1'); f.append(d); return f; }

// DOM: bangun ulang isi pulau (aman dipanggil berulang). Atribut role/tabindex/aria hanya hidup di layar, tidak pernah tersimpan (sanitize membuangnya).
export function renderIsland(el) {
  if (!el || el.nodeType !== 1) return;
  const id = el.getAttribute('data-sheet') || '';
  const sheet = sheetById(id); const m = islandModel(sheet);
  el.setAttribute('contenteditable', 'false'); el.setAttribute('role', 'button'); el.setAttribute('tabindex', '0');
  el.setAttribute('aria-label', m ? 'Lembar kerja ' + m.name + '. Ketuk untuk membuka.' : 'Lembar kerja tidak tersedia');
  el.classList.toggle('missing', !m);
  const kids = [];
  if (!m) {
    const head = mk('div', 'ks-head'); head.append(mk('strong', 'ks-name', 'Lembar kerja'));
    kids.push(head, mk('div', 'ks-miss', 'Lembar kerja ini sudah tidak ada. Hapus blok ini dari catatan.'), footRow(''));
  } else {
    const head = mk('div', 'ks-head'); head.append(mk('strong', 'ks-name', m.name), mk('span', 'ks-tab', m.tabs > 1 ? m.tab + ' +' + (m.tabs - 1) : m.tab));
    const grid = mk('div', 'ks-grid'); grid.style.setProperty('--ksn', String(m.nc));
    const hr = mk('div', 'ks-row ks-hr'); hr.append(mk('span', 'ks-c ks-corner', '')); m.cols.forEach((c) => hr.append(mk('span', 'ks-c ks-hc', c))); grid.append(hr);
    m.rows.forEach((row, i) => {
      const r = mk('div', 'ks-row'); r.append(mk('span', 'ks-c ks-rn', String(i + 1)));
      const px = m.rowH ? islandRowPx(m.rowH[i]) : 0; if (px) { r.classList.add('kh'); if (m.rowH[i] > L.ROW_H_DEF) r.classList.add('kt'); r.style.setProperty('--ksh', px + 'px'); } // Rev 184c-1: tinggi baris bebas
      row.forEach((c) => { if (c.cv) return; const s = mk('span', 'ks-c', c.t); if (c.cs > 1) s.style.gridColumn = 'span ' + c.cs; if (c.vd) s.classList.add('vd'); if (c.vu) s.classList.add('vu'); if (c.b) s.classList.add('b'); if (c.i) s.classList.add('i'); if (c.ha !== 'start') s.classList.add('ha-' + c.ha); if (c.bg) s.style.background = c.bg; if (c.fg) s.style.color = c.fg; else if (c.bg) s.style.color = inkOnFill(c.bg); r.append(s); });
      grid.append(r);
    });
    kids.push(head, grid);
    const ch = islandCharts(sheet); // Rev 160: diagram tersimpan di bawah tabel (SVG dibangun lewat DOMParser + importNode)
    if (ch.items.length) {
      const box = mk('div', 'ks-charts');
      for (const it of ch.items) { try { const doc = new DOMParser().parseFromString(it.svg, 'image/svg+xml'); if (doc.documentElement && doc.documentElement.nodeName === 'svg') { const w = mk('div', 'ks-chart'); w.append(document.importNode(doc.documentElement, true)); box.append(w); } } catch (_) { /* dilewati */ } }
      if (ch.more) box.append(mk('div', 'ks-chmore', '+' + ch.more + ' diagram lain (buka lembar kerja)'));
      if (box.childNodes.length) kids.push(box);
    }
    kids.push(footRow(m.empty ? 'Lembar kosong. Ketuk untuk mengisi.' : (m.moreRows || m.moreCols ? 'Ketuk untuk melihat seluruh lembar…' : 'Ketuk untuk membuka')));
  }
  el.replaceChildren(...kids);
}
// Bangun ulang pulau di dalam root (semua, atau hanya yang menunjuk lembar tertentu).
export function refreshIslands(root, id) {
  if (!root || typeof root.querySelectorAll !== 'function') return 0;
  let n = 0; root.querySelectorAll('.ksheet').forEach((el) => { if (!id || el.getAttribute('data-sheet') === id) { renderIsland(el); n++; } });
  return n;
}
// Dipakai registri blok: simpan hanya penanda (tanpa isi pratinjau).
export function stripIsland(el) { if (el && el.nodeType === 1) { el.replaceChildren(); ['role', 'tabindex', 'aria-label'].forEach((a) => el.removeAttribute(a)); el.classList.remove('missing'); } }
