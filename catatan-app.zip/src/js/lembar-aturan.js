// Rev 145 / U9b-2a: aturan WARNA BERSYARAT per tab lembar kerja (MURNI: tanpa DOM, penyimpanan, native, eval, dan TANPA mengimpor lembar.js / rumus.js).
// Bentuk: tab.rules = [{ id, c: ID kolom, op, a?, b?, bg?, fg?, lo?, hi? }], maks. 10 per tab. Aturan berlaku pada SATU KOLOM (ID kolom, jadi aman saat kolom bergeser).
//   op lt/lte/gt/gte : angka a;  between : angka a..b (urutan dibetulkan);  eq/ne : angka ATAU teks a (teks tidak peka huruf besar-kecil)
//   op scale         : skala warna lo -> hi (heksa #RRGGBB) menurut nilai terkecil/terbesar kolom (hanya angka)
// Pencocokan memakai NILAI TAMPIL (hasil rumus untuk sel berumus), lewat fungsi raw(i, j) dari makeDisplay. Sel kosong, galat, dan teks tidak pernah cocok aturan angka.
// Aturan pertama yang cocok menang (urutan = prioritas). Hasil = warna TAMPILAN saja; tidak pernah menulis ke sel.
export const MAX_RULES = 10;
export const RULE_OPS = ['lt', 'lte', 'gt', 'gte', 'eq', 'ne', 'between', 'scale'];
export const MAX_RULE_TEXT = 100;
const HEX = /^#[0-9a-fA-F]{6}$/, COLORS = /^[a-z]{3,12}$|^#[0-9a-fA-F]{6}$/, RID = /^[a-z0-9]{4,24}$/;
const numOf = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : undefined);
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
const norm = (s) => String(s).trim().toLowerCase();

// Satu aturan dibersihkan; null bila tidak sah. colIds = Set ID kolom tab (aturan untuk kolom yang hilang dibuang).
export function cleanRule(raw, colIds) {
  if (!raw || typeof raw !== 'object' || typeof raw.c !== 'string' || !colIds || !colIds.has(raw.c) || !RULE_OPS.includes(raw.op)) return null;
  const r = { id: typeof raw.id === 'string' && RID.test(raw.id) ? raw.id : '', c: raw.c, op: raw.op };
  if (raw.op === 'scale') {
    if (typeof raw.lo !== 'string' || typeof raw.hi !== 'string' || !HEX.test(raw.lo) || !HEX.test(raw.hi)) return null;
    r.lo = raw.lo.toUpperCase(); r.hi = raw.hi.toUpperCase(); return r;
  }
  if (raw.op === 'eq' || raw.op === 'ne') {
    if (typeof raw.a === 'string') { const t = raw.a.slice(0, MAX_RULE_TEXT); if (!t.trim()) return null; r.a = t; }
    else if (numOf(raw.a) !== undefined) r.a = raw.a; else return null;
  } else {
    const a = numOf(raw.a); if (a === undefined) return null; r.a = a;
    if (raw.op === 'between') { const b = numOf(raw.b); if (b === undefined) return null; if (b < a) { r.a = b; r.b = a; } else r.b = b; }
  }
  const bg = typeof raw.bg === 'string' && COLORS.test(raw.bg) ? raw.bg : '', fg = typeof raw.fg === 'string' && COLORS.test(raw.fg) ? raw.fg : '';
  if (!bg && !fg) return null; // aturan tanpa warna tidak berguna
  if (bg) r.bg = bg; if (fg) r.fg = fg;
  return r;
}
// Daftar aturan sebuah tab. cols = tab.cols (untuk ID kolom yang masih ada). Selalu mengembalikan array (boleh kosong).
export function cleanRules(raw, cols) {
  const out = [], seen = new Set(); if (!Array.isArray(raw)) return out;
  const colIds = new Set((Array.isArray(cols) ? cols : []).map((c) => c && c.id));
  for (const x of raw) {
    if (out.length >= MAX_RULES) break; const r = cleanRule(x, colIds); if (!r) continue;
    if (!r.id || seen.has(r.id)) { let n = out.length + 1, id; do { id = 'g' + n++ + Math.random().toString(36).slice(2, 6); } while (seen.has(id)); r.id = id; }
    seen.add(r.id); out.push(r);
  }
  return out;
}

// --- pencocokan dan warna ---
const hexRgb = (h) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const rgbHex = (a) => '#' + a.map((x) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0')).join('').toUpperCase();
export const mixHex = (lo, hi, t) => { const a = hexRgb(lo), b = hexRgb(hi), k = Math.min(1, Math.max(0, Number.isFinite(t) ? t : 0)); return rgbHex(a.map((x, i) => x + (b[i] - x) * k)); };
export const luminance = (h) => { const [r, g, b] = hexRgb(h).map((x) => { const s = x / 255; return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4); }); return 0.2126 * r + 0.7152 * g + 0.0722 * b; };
export const textOn = (bg) => (luminance(bg) > 0.4 ? '#111827' : '#FFFFFF'); // teks otomatis terbaca di atas warna skala
export function matches(rule, v) {
  if (!rule) return false;
  switch (rule.op) {
    case 'lt': return isNum(v) && v < rule.a;
    case 'lte': return isNum(v) && v <= rule.a;
    case 'gt': return isNum(v) && v > rule.a;
    case 'gte': return isNum(v) && v >= rule.a;
    case 'between': return isNum(v) && v >= rule.a && v <= rule.b;
    case 'eq': case 'ne': {
      let same;
      if (typeof rule.a === 'number') same = isNum(v) && v === rule.a;
      else same = typeof v === 'string' && norm(v) === norm(rule.a);
      if (v === undefined || v === null || v === '') return false; // sel kosong tidak pernah cocok (juga untuk ne)
      if (v !== null && typeof v === 'object') return false; // galat rumus
      return rule.op === 'eq' ? same : !same;
    }
    default: return false;
  }
}
// ruleColors(tab, raw) -> Map "i,j" -> { bg?, fg? }. raw(i, j) = nilai tampil (angka/teks/boolean/undefined/objek galat). Tanpa aturan = Map kosong (tanpa biaya).
export function ruleColors(tab, raw) {
  const out = new Map(); const rules = tab && Array.isArray(tab.rules) ? tab.rules : []; if (!rules.length || typeof raw !== 'function') return out;
  const n = tab.rows.length, cache = new Map();
  const colOf = (id) => tab.cols.findIndex((c) => c.id === id);
  const get = (i, j) => { const k = i + ',' + j; if (!cache.has(k)) { let v; try { v = raw(i, j); } catch (_) { v = undefined; } cache.set(k, v); } return cache.get(k); };
  for (const rule of rules) {
    const j = colOf(rule.c); if (j < 0) continue;
    if (rule.op === 'scale') {
      let lo = Infinity, hi = -Infinity; for (let i = 0; i < n; i++) { const v = get(i, j); if (isNum(v)) { if (v < lo) lo = v; if (v > hi) hi = v; } }
      if (lo === Infinity) continue;
      for (let i = 0; i < n; i++) { const v = get(i, j); if (!isNum(v) || out.has(i + ',' + j)) continue; const bg = mixHex(rule.lo, rule.hi, hi === lo ? 0 : (v - lo) / (hi - lo)); out.set(i + ',' + j, { bg, fg: textOn(bg) }); }
      continue;
    }
    for (let i = 0; i < n; i++) {
      const k = i + ',' + j; if (out.has(k) || !matches(rule, get(i, j))) continue;
      const o = {}; if (rule.bg) o.bg = rule.bg; if (rule.fg) o.fg = rule.fg; out.set(k, o);
    }
  }
  return out;
}
// Deskripsi singkat satu aturan untuk daftar di UI nanti (Bahasa Indonesia, memakai nama kolom A, B, ...).
export function ruleText(rule, colName) {
  if (!rule) return ''; const k = colName ? 'Kolom ' + colName + ': ' : ''; const fmt = (x) => String(x).replace('.', ',');
  switch (rule.op) {
    case 'lt': return k + 'kurang dari ' + fmt(rule.a); case 'lte': return k + 'maks. ' + fmt(rule.a);
    case 'gt': return k + 'lebih dari ' + fmt(rule.a); case 'gte': return k + 'min. ' + fmt(rule.a);
    case 'between': return k + fmt(rule.a) + ' sampai ' + fmt(rule.b);
    case 'eq': return k + 'sama dengan ' + fmt(rule.a); case 'ne': return k + 'bukan ' + fmt(rule.a);
    case 'scale': return k + 'skala warna';
    default: return '';
  }
}
