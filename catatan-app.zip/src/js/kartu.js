// Rev 400 / K1: mesin kartu bagikan (tanpa UI). Tata letak = layoutDoc/paginate milik export.js, gambar = drawPage milik share.js. Rincian: RIWAYAT.md.
import { layoutDoc, paginate, b64ToBytes } from './export.js';
import { HEX, contrast } from './logic.js';
import { formatDateID, localDateISO } from './tanggal.js';

export const KARTU = { width: 1080, pageH: 2160, padX: 72, padTop: 84, padBottom: 132, size: 40, titleSize: 62, sheet: { rows: 12, cols: 4 } };
export const WARNA_KARTU = { biru: '#dbe9fb', hijau: '#d9f1df', gelap: '#1c2442', polos: '#fbfcfe' };

export function temaKartu(warna) {
  const k = String(warna || '').toLowerCase(), bg = WARNA_KARTU[k] || (HEX.test(k) ? k : WARNA_KARTU.biru), c = contrast(bg);
  return { bg, ink: c.ink, mut: c.mut };
}

export function rencanaKartu({ title, blocks }, { measure, warna, now = new Date() } = {}) {
  const o = { ...KARTU, measure }, lines = layoutDoc({ title, blocks }, o);
  let pages = paginate(lines, o), page = pages[0];
  const cut = pages.length > 1;
  if (cut) { // terlalu panjang: sisakan tempat untuk penanda, buang sisanya
    const lh = Math.round(o.size * 1.4), size = Math.round(o.size * 0.8);
    const mk = { kind: 'text', lh, size, x: o.padX, segs: [{ t: '… dipotong, selengkapnya ada di catatan', x: o.padX, size, b: false, i: true }] };
    page = paginate(lines, { ...o, padBottom: o.padBottom + lh })[0];
    page = { lines: [...page.lines, mk], used: page.used + lh };
  }
  const H = Math.min(o.pageH, Math.max(640, Math.ceil(page.used + o.padTop + o.padBottom)));
  return { page, cut, o, H, theme: temaKartu(warna), kiri: 'Notes Kelimaa', kanan: formatDateID(localDateISO(now)) };
}

export async function gambarKartu(g, r, S, images) { // S = modul share.js (drawPage, fontOf)
  await S.drawPage(g, r.page, r.o, r.theme, r.H, 1, 1, images);
  const y = r.H - Math.round(r.o.padBottom * 0.42);
  g.font = S.fontOf({}, Math.round(r.o.size * 0.7)); g.fillStyle = r.theme.mut; g.textBaseline = 'alphabetic';
  g.textAlign = 'left'; g.fillText(r.kiri, r.o.padX, y);
  g.textAlign = 'right'; g.fillText(r.kanan, r.o.width - r.o.padX, y); g.textAlign = 'left';
}

export async function renderKartu(n, opt = {}) { // opt: warna, now, images (Map id -> Blob), priv + izinPriv
  if (opt.priv && !opt.izinPriv) throw new Error('Catatan Privat hanya dibuat jadi kartu bila dicentang.');
  const S = await import('./share.js'), mc = document.createElement('canvas').getContext('2d');
  if (!mc) throw new Error('Canvas tidak tersedia');
  const measure = (t, st) => { mc.font = S.fontOf(st, st.size); return mc.measureText(t).width; };
  const r = rencanaKartu({ title: n.title, blocks: S.blocksOf(n, KARTU.sheet, true) }, { measure, warna: opt.warna, now: opt.now });
  const cv = document.createElement('canvas'); cv.width = r.o.width; cv.height = r.H;
  const g = cv.getContext('2d'); if (!g) throw new Error('Canvas tidak tersedia');
  await gambarKartu(g, r, S, opt.images);
  const url = cv.toDataURL('image/jpeg', 0.92), k = url.indexOf('base64,'); cv.width = 0; cv.height = 0;
  if (!url.startsWith('data:image/jpeg') || k < 0) throw new Error('Kartu gagal dibuat');
  return { bytes: b64ToBytes(url.slice(k + 7)), w: r.o.width, h: r.H, cut: r.cut };
}
