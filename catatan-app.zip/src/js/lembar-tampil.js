// Rev 134 / U8b-1: TEKS TAMPILAN sel lembar kerja untuk SEMUA pemakai di luar grid layar penuh (ekspor TXT/MD/PDF/JPG, pulau pratinjau di catatan, tabToTsv).
// MURNI: tanpa DOM, penyimpanan, native, Intl, eval. Satu sumber kebenaran supaya ekspor/pratinjau PERSIS sama dengan yang dilihat di grid:
//   sel berumus  -> HASIL rumus (galat tampil apa adanya, mis. #DIV/0!), bukan rumusnya dan bukan kosong
//   sel berformat (gaya nf) -> angka diformat (Rp 1.250.000, 25%, 09/11/2026); teks/boolean/galat tidak disentuh
//   selain itu   -> nilai mentah (angka memakai koma desimal)
// Modul ini satu-satunya jembatan ke mesin rumus bagi lembar-pulau.js dan lembar.js (tes rev127 melarang keduanya mengimpor mesin rumus langsung).
import { getEngine, loadEngine } from './lembar-mesin.js'; // Rev 192b / P2b: mesin rumus (rumus.js) dimuat belakangan, bukan saat buka
import { formatNumber } from './lembar-format.js';
// Rev 170: salin rumus (Isi seri) = jembatan tunggal ke mesin rumus bagi lembar-alat.js. Rev 192b: mesin belum dimuat = null (pemanggil = layar lembar, yang selalu memuat mesin dulu).
export const shiftFormula = (...a) => { const E = getEngine(); return E ? E.shiftFx(...a) : null; };
// Mesin belum dimuat -> pakai penggantian aman (tidak pernah dipanggil untuk sel berumus, karena sel berumus menampilkan kosong sampai mesin siap).
const isErr = (v) => { const E = getEngine(); return E ? E.isErr(v) : false; };
const valueToText = (...a) => { const E = getEngine(); return E ? E.valueToText(...a) : ''; };
const numToText = (...a) => { const E = getEngine(); return E ? E.numToText(...a) : ''; };
const fxAutoNf = (fx) => { const E = getEngine(); return E ? E.fxAutoNf(fx) : null; };

export const hasFx = (cell) => !!(cell && typeof cell.fx === 'string');
export const tabHasFx = (tab) => !!(tab && Array.isArray(tab.rows) && tab.rows.some((r) => r && r.cells && Object.keys(r.cells).some((k) => hasFx(r.cells[k]))));
// Sel "punya isi" = ada nilai ATAU rumus (rumus yang hasilnya kosong tetap dihitung sebagai isi, seperti Excel). Gaya saja bukan isi.
export const hasContent = (cell) => !!cell && (cell.v !== undefined || hasFx(cell));

const rawText = (v, comma) => (v === undefined || v === null ? '' : typeof v === 'boolean' ? (v ? 'TRUE' : 'FALSE') : typeof v === 'number' ? (Number.isFinite(v) ? (comma ? String(v).replace('.', ',') : String(v)) : '') : String(v));

// makeDisplay(tab, {now}) -> { has(i,j), raw(i,j), text(i,j), plain(i,j), err(i,j), calc }
//   i = indeks baris, j = indeks kolom (bukan ID). Rumus dihitung SEKALI per tab (tanpa rumus = tanpa biaya). Galat hitung = semua sel berumus kosong, tidak pernah melempar.
//   text  = seperti di grid (koma desimal, format nf)
//   plain = seperti text tetapi angka MENTAH tanpa nf memakai titik desimal (dasar TSV/CSV mesin)
export function makeDisplay(tab, { now } = {}) {
  const rows = (tab && Array.isArray(tab.rows)) ? tab.rows : [], cols = (tab && Array.isArray(tab.cols)) ? tab.cols : [];
  let calc = null, pending = false;
  if (tabHasFx(tab)) {
    const E = getEngine();
    if (E) { try { calc = E.computeTab(tab, Number.isFinite(now) ? { now } : {}); } catch (_) { calc = null; } }
    else { pending = true; loadEngine().catch(() => {}); } // Rev 192b: mesin belum siap -> sel berumus tampil kosong dulu; pemanggil menggambar ulang lewat onEngine
  }
  const cellAt = (i, j) => (rows[i] && cols[j] && rows[i].cells ? rows[i].cells[cols[j].id] || null : null);
  const raw = (i, j) => {
    const cell = cellAt(i, j); if (!cell) return undefined;
    if (hasFx(cell)) { try { return calc ? calc.get(rows[i].id, cols[j].id) : undefined; } catch (_) { return undefined; } }
    return cell.v;
  };
  const fmt = (i, j) => { const cell = cellAt(i, j), nf = (cell && cell.s && cell.s.nf) || (hasFx(cell) ? fxAutoNf(cell.fx) : null); return nf ? formatNumber(raw(i, j), nf) : null; }; // Rev 164: format sendiri menang; tanpa format, DATE/TODAY tampil sebagai Tanggal
  return {
    calc, pending,
    has: (i, j) => hasContent(cellAt(i, j)),
    raw,
    err: (i, j) => isErr(raw(i, j)),
    text: (i, j) => { const f = fmt(i, j); if (f !== null) return f; const cell = cellAt(i, j), v = raw(i, j); return hasFx(cell) ? (v === undefined || v === null ? '' : valueToText(v, { comma: true })) : rawText(v, true); },
    plain: (i, j) => { const f = fmt(i, j); if (f !== null) return f; const cell = cellAt(i, j), v = raw(i, j); return hasFx(cell) ? (v === undefined || v === null ? '' : typeof v === 'number' ? numToText(v) : valueToText(v, { comma: false })) : rawText(v, false); },
  };
}

// Rev 136 / U8b-3: rumus bentuk A1 (mis. "=SUM(B2:B5)") -> bentuk SIMPAN untuk tab ini, atau null bila ditolak. Jembatan bagi lembar-pulau.js (konversi baris Total tabel).
export function fxFromA1(text, tab) { try { const E = getEngine(); if (!E) return null; const r = E.a1ToStored(text, tab); return r && r.ok ? r.fx : null; } catch (_) { return null; } }
