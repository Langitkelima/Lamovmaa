// Terima teks dari Bagikan Android (Rev 20): di aplikasi lain, Bagikan > Notes Kelimaa membuat catatan BIASA baru dan membukanya di editor.
// Native (MainActivity) menyimpan teks yang masuk; JavaScript menariknya lewat KelimaaNative.takeShared() (jalur tarik: saat buka dingin
// JS belum tentu siap). Dipanggil: sekali setelah tampilan pertama, tiap aplikasi kembali ke layar, dan saat native mendorong
// window.__kelimaaShared() (aplikasi sudah terbuka). Catatan Privat TIDAK pernah menerima teks ini.
import { parseShared, sharedToHtml, newId, SHARE_IN_MAX } from './logic.js';
import { openEditor, closeEditor, sanitize } from './notes.js';
import { lockPrivat } from './privat.js';
import { dlg, closeDialog, tWarn } from './ui.js';

// Ambil teks yang menunggu. Tanpa jembatan native (peramban/tes) atau bila gagal: string kosong, tidak melempar.
export function readShared(g = globalThis) {
  const N = g.KelimaaNative;
  if (!N || typeof N.takeShared !== 'function') return '';
  try { return String(N.takeShared() || ''); } catch (e) { console.error('takeShared gagal:', e); return ''; }
}

// Buat catatan biasa dari muatan native lalu buka editornya (tanpa memunculkan keyboard, supaya isinya langsung terbaca).
export function importShared(ctx, raw) {
  const p = parseShared(raw);
  if (!p) return false;
  if (!p.ok) { tWarn('Notes Kelimaa hanya bisa menerima teks. Gambar atau berkas belum didukung.'); return false; }
  const { data, ui } = ctx;
  // Catatan Privat terbuka: kunci dulu (menyimpan dan menutup editornya); teks bagikan tidak boleh masuk ke privat.
  if (ui.unlocked) lockPrivat(ctx);
  closeEditor();                                    // menyimpan editor lain yang sedang terbuka
  for (let i = 0; i < 5 && closeDialog(); i++) { /* tutup dialog lewat tombol Batal agar pendengar tombolnya ikut dilepas */ }
  document.querySelectorAll('.ov').forEach((x) => x.remove()); // lembar tambah/ubah, pemilih, lembar Bagikan
  ui.tab = 'catatan'; ui.moreView = 'main'; ui.q = ''; ui.lf = '';
  const n = { id: newId(), title: p.title, text: p.text, html: sanitize(sharedToHtml(p.text)), col: '', pin: false, updated: Date.now() };
  data.notes.push(n);
  ctx.persist();                                    // tersimpan dulu; tidak bergantung pada editor ditutup rapi
  ctx.render();
  openEditor(ctx, n.id, 'note', false, true);
  if (p.truncated) dlg({ title: 'Teks terlalu panjang', msg: 'Hanya ' + SHARE_IN_MAX.toLocaleString('id-ID') + ' huruf pertama yang disimpan di catatan ini. Sisanya dipotong.', yes: 'Mengerti', ok: () => {} });
  return true;
}

export function pullShared(ctx, g = globalThis) {
  const raw = readShared(g);
  if (!raw) return false;
  try { return importShared(ctx, raw); } catch (e) { console.error('terima teks gagal:', e); return false; }
}

// Native mendorong sinyal ini saat aplikasi sudah terbuka dan ada Bagikan baru.
export function installShareInbox(ctx, g = globalThis) {
  g.__kelimaaShared = () => { pullShared(ctx, g); };
}
