// Rev 125 / U7b-4: siklus hidup lembar kerja yang dipakai catatan (MURNI, tanpa DOM/penyimpanan; tanpa impor supaya aman dipakai storage/logic/settings/notes).
// Aturan: salin catatan = KLON lembar (bukan berbagi); Catatan Privat tidak boleh memuat pulau; lembar tak terpakai TIDAK dihapus otomatis (hanya atas perintah pengguna).
export const SHEET_LIMIT = 50;
const REF = /data-sheet="([a-z0-9]{4,24})"/g;
const ISLAND = /<div\b[^>]*\bclass="ksheet"[^>]*>[\s\S]*?<\/div>/g; // HTML tersimpan selalu pulau KOSONG (isi dibuang saat sanitize)
export const sheetRefs = (html) => { const out = []; String(html || '').replace(REF, (_, id) => { out.push(id); return ''; }); return out; };
export const countSheetRefs = (html) => sheetRefs(html).length;
export const stripSheetIslands = (html) => String(html || '').replace(ISLAND, '');

// Berapa catatan BIASA (termasuk yang ada di Tempat sampah) yang memakai tiap lembar. Catatan Privat tidak dihitung (tidak boleh punya pulau).
export function sheetUsage(data) {
  const use = {}; const lists = [(data && data.notes) || [], ((data && data.trash) || []).filter((x) => x && x.kind === 'note' && x.item).map((x) => x.item)];
  for (const list of lists) for (const n of list) { if (!n || typeof n.html !== 'string') continue; for (const id of new Set(sheetRefs(n.html))) use[id] = (use[id] || 0) + 1; }
  return use;
}
export const unusedSheetIds = (data) => { const use = sheetUsage(data); return Object.keys((data && data.sheets) || {}).filter((id) => !use[id]); };

const newId = (sheets) => { let s; do { s = 's' + Math.random().toString(36).slice(2, 8); } while (Object.prototype.hasOwnProperty.call(sheets, s) || !/^[a-z0-9]{4,24}$/.test(s)); return s; };
// Menyalin catatan: tiap lembar yang dirujuk dikloning (id baru, nama + " (salinan)"); satu lembar yang dirujuk dua kali dikloning sekali.
// Lembar yang sudah tidak ada atau melewati batas jumlah: pulaunya DIBUANG dari salinan (tidak pernah berbagi diam-diam). Mengembalikan { html, cloned, dropped }.
export function cloneSheetsForCopy(html, sheets, limit = SHEET_LIMIT) {
  const map = new Map(); let cloned = 0, dropped = 0;
  const out = String(html || '').replace(ISLAND, (block) => {
    const m = /data-sheet="([a-z0-9]{4,24})"/.exec(block); const id = m ? m[1] : '';
    if (map.has(id)) return map.get(id) ? block.replace(id, map.get(id)) : (dropped++, '');
    const src = Object.prototype.hasOwnProperty.call(sheets, id) ? sheets[id] : null;
    if (!src || Object.keys(sheets).length >= limit) { map.set(id, ''); dropped++; return ''; }
    const copy = JSON.parse(JSON.stringify(src)); copy.id = newId(sheets); copy.name = (String(copy.name || 'Lembar kerja') + ' (salinan)').slice(0, 30); copy.at = Date.now();
    sheets[copy.id] = copy; map.set(id, copy.id); cloned++;
    return block.replace(id, copy.id);
  });
  return { html: out, cloned, dropped };
}
