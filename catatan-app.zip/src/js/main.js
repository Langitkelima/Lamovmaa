// Titik masuk aplikasi. Langkah 1: fondasi + layar Tugas. Data pengguna ditampilkan sebagai teks (anti-XSS).
import { SCOPES, purgeTrash, todayISO, dayOfWeek, sortTasks, tasksByScope, applyDailyReset, validateTitle, newId, formatDate, canHaveSubs, cleanSubs, subProgress, addSub, SUB_MAX, subReminderCount, navShape, toggleDone, withMode } from './logic.js';
import { load, save } from './storage.js';
import { h, ico, PATH, toast, dlg, infoDlg, infoPast, closeDialog, judul, $, tOk, tErr, tWarn, tInfo } from './ui.js';
import { viewNotes, openEditor, closeEditor, backEditor, closeEditorMenu, closeSelectMenu, exitSelect } from './notes.js';
import { askExitBack, installBrowserBack } from './exit.js';
import { viewPrivat, lockPrivat } from './privat.js';
import { viewSettings, viewKelimaaAI, applyTheme, applySelColor } from './settings.js';
import { applySnooze } from './settings.js'; // Rev 389 / TN2 (baris terpisah: tes lama mengunci baris impor di atas)
import { syncBars } from './native.js';
import { installShootingStars, installSkyLock } from './langit.js';
import { cleanupOrphanImages } from './gambar-app.js';
import { closeViewer } from './penampil.js';
import { closeSheet } from './lembar-pintu.js'; // Rev 192 / P2a: pintu kecil; layar lembar kerja (lembar-ui.js) dimuat belakangan
import { maybeAutoBackup } from './backup.js';
import { installShareInbox, pullShared } from './terima.js';
import { refreshDue } from './tp-alarm.js';
import { syncAllReminders, scheduleReminder, cancelReminder, fromLocalInput, toLocalInput, installReminderInbox, cancelTaskAlarms, cancelSubReminder, scheduleSubReminder, syncTaskAlarms, describeReminder } from './reminders.js';
import { syncAllNoteAlarms } from './cb-alarm.js'; // Rev 102 / U5b
import { loadEngine, onEngine, sheetsHaveFx } from './lembar-mesin.js'; // Rev 192b / P2b: mesin rumus dimuat belakangan, hanya bila ada lembar berumus
import { flushEditor } from './notes.js'; // Rev 193 / P3: simpan ketikan tertunda saat ke latar belakang (baris terpisah: tes lama mengunci baris impor notes.js)
import { warmSheetUI, setSlowNotice } from './lembar-pintu.js'; // Rev 192d / P2c: pemanasan diam-diam + penanda (baris terpisah: tes lama mengunci baris impor closeSheet)
import { wasLoadFailure } from './storage.js'; // Rev 295: baris terpisah
import { mark, afterFirstPaint } from './startup.js'; // Rev 191 / P1: tanda waktu buka + tugas sesudah gambar pertama

const data = load();
mark('data-siap'); // Rev 191 / P1
const ui = { tab: 'tugas', seg: 'habit', q: '', qp: '', lf: '', lfp: '', unlocked: false, waitTimer: 0, moreView: 'main' };
const ctx = { data, ui, persist: () => persist(), render: () => render() };
// Rev 423 / SY3c: sinkron otomatis dimuat MALAS hanya bila sakelar Otomatis menyala (pemeriksaan teks murah, tanpa mengurai JSON).
function autoSync(why) { try { if ((localStorage.getItem('catatan_app_sync_cfg') || '').includes('"auto":true')) import('./sync-auto.js').then((m) => m.pemicu(ctx, why), () => {}); } catch (_) { /* abaikan */ } }
function persist() { const r = save(data); if (!r.ok) toast(r.msg); else autoSync('simpan'); }

function remove(item, kind) {
  if (kind === 'task') cancelTaskAlarms(item);
  const arr = kind === 'habit' ? data.habits : data.tasks;
  const i = arr.indexOf(item); if (i < 0) return;
  arr.splice(i, 1);
  data.trash.push({ kind, item, at: Date.now() });
  persist(); render();
  tOk('Dipindah ke tempat sampah', () => {
    const j = data.trash.findIndex((x) => x.item === item);
    if (j >= 0) data.trash.splice(j, 1);
    arr.splice(Math.min(i, arr.length), 0, item);
    if (kind === 'task' && !item.done) syncTaskAlarms(item);
    persist();
  }, render);
}

// Rev 69/70: pengetikan kebiasaan, tugas, dan sub-tugas selalu KAPITAL (papan ketik huruf besar + diubah langsung + CSS).
function capInput(el) {
  el.setAttribute('autocapitalize', 'characters'); el.classList.add('cap-in');
  el.addEventListener('input', () => { const v = el.value, u = v.toUpperCase(); if (v !== u) { const a = el.selectionStart, b = el.selectionEnd; el.value = u; try { el.setSelectionRange(a, b); } catch (_) {} } });
}

// Rev 67: id tugas yang daftar sub-tugasnya sedang dibuka di layar (hanya tampilan, tidak disimpan).
const openSubs = new Set();
// Rev 68: id tugas yang baru saja dibuka (animasi muncul sekali saja, tidak diulang saat centang sub-tugas).
const justOpened = new Set();

// Rev 68: panel sub-tugas bergaya pohon: bilah progres + kartu sub-tugas yang tersambung garis; chip jam bila punya pengingat.
function subPanel(kind, item, pr) {
  const now = Date.now();
  const fill = h('i', {}); fill.style.width = Math.round((pr.done / pr.total) * 100) + '%';
  const bar = h('div', { class: 'subprog' + (pr.all ? ' all' : '') }, h('span', { class: 'subdot' }), h('div', { class: 'subtrack' }, fill), h('span', { class: 'subtxt' }, pr.done + ' dari ' + pr.total + ' selesai'));
  const list = h('div', { class: 'slist' }, item.subs.map((sb) => {
    const rem = sb.reminder && !sb.done ? describeReminder(sb.reminder, now) : '';
    return h('div', { class: 'srow' + (sb.done ? ' done' : '') + (rem ? ' hasrem' : '') },
      h('button', { type: 'button', class: 'ck sm' + (sb.done ? ' on' : ''), 'aria-label': sb.done ? 'Batalkan centang sub-tugas' : 'Centang sub-tugas', onclick: () => { sb.done = !sb.done; syncTaskAlarms(item); persist(); render(); } }),
      h('div', { class: 'stx', onclick: () => openSheet(kind, item, { sub: sb.id }) }, h('span', { class: 'stt tcap' }, sb.title), rem ? h('span', { class: 'sbell' + (rem === 'Terlewat' ? ' late' : ''), 'aria-label': 'Pengingat ' + rem }, '⏰ ' + rem) : null));
  }));
  const panel = h('div', { class: 'subs' }, bar, list);
  // Animasi muncul SEKALI (hanya saat dibuka), lewat Web Animations; dilewati bila pengguna memilih gerak dikurangi.
  if (justOpened.has(item.id) && typeof panel.animate === 'function' && !(globalThis.matchMedia && globalThis.matchMedia('(prefers-reduced-motion: reduce)').matches)) {
    try { panel.animate([{ opacity: 0, transform: 'translateY(-6px)' }, { opacity: 1, transform: 'none' }], { duration: 200, easing: 'ease-out' }); } catch (_) {}
  }
  return panel;
}

function row(item, kind) {
  const isH = kind === 'habit';
  const meta = !isH && (item.pri || item.due)
    ? h('small', {}, item.pri ? h('span', { class: 'chip hi' }, 'Penting') : null, item.due ? 'Tenggat ' + formatDate(item.due) : null)
    : null;
  const nSubRem = !isH ? subReminderCount(item) : 0;
  const reminderMeta = !isH && item.reminder ? h('small', { class: item.reminder.mode === 'alarm' ? 'alm-meta' : '' }, item.reminder.mode === 'alarm' ? '⏰ Alarm berdering' : '⏰ Ada pengingat') : (nSubRem ? h('small', {}, '⏰ ' + nSubRem + ' pengingat sub-tugas') : null);
  const pr = !isH ? subProgress(item) : { total: 0 };
  const opened = pr.total > 0 && openSubs.has(item.id);
  const subChip = pr.total ? h('button', { type: 'button', class: 'subchip' + (pr.all ? ' all' : ''), 'aria-expanded': opened ? 'true' : 'false', 'aria-label': 'Sub-tugas ' + pr.text + (opened ? ', tutup daftar' : ', buka daftar'),
    onclick: (e) => { e.stopPropagation(); if (openSubs.has(item.id)) openSubs.delete(item.id); else { openSubs.add(item.id); justOpened.add(item.id); } render(); justOpened.delete(item.id); } }, '☑ ' + pr.text + ' sub-tugas', h('span', { class: 'subar' }, opened ? '▴' : '▾')) : null;
  const mainRow = h('div', { class: 'row' + (item.done ? ' done' : '') + (!isH && item.pri && !item.done ? ' hi' : '') + (opened ? ' open' : '') },
    h('button', { type: 'button', class: 'ck' + (item.done ? ' on' : ''), 'aria-label': item.done ? 'Batalkan centang' : 'Centang', onclick: () => { toggleDone(item, !isH); if (!isH) syncTaskAlarms(item); persist(); render(); } }),
    h('div', { class: 'tx', onclick: () => openSheet(kind, item) }, h('b', { class: 'tcap' }, item.title), meta, reminderMeta, subChip),
    h('button', { type: 'button', class: 'ghost', 'aria-label': 'Hapus', onclick: () => remove(item, kind) }, ico(PATH.bin)));
  // Rev 204: geser-hapus di Tugas/Kebiasaan dicabut (membuat ketukan tidak terbaca di HP); hapus lewat tombol tempat sampah.
  if (!opened) return mainRow;
  return h('div', { class: 'trow' }, mainRow, subPanel(kind, item, pr));
}

// Rev 381 / AL3b-3: pemilih mode pengingat (alarm-ui.js, dimuat malas). Gagal memuat = dialog tetap terbuka tanpa pemilih (mode lama dipertahankan).
function openSheet(kind, item, opts = {}) { import('./alarm-ui.js').then((A) => openSheetNow(kind, item, opts, A), () => openSheetNow(kind, item, opts, null)); }
function openSheetNow(kind, item, opts, A) {
  const isH = kind === 'habit', isNew = !item;
  let pri = item && item.pri ? item.pri : 0;
  const title = h('input', { class: 'in', placeholder: isH ? 'Nama kebiasaan' : 'Judul tugas', 'aria-label': 'Judul', maxlength: '120' });
  capInput(title);
  title.value = item ? item.title : '';
  const due = h('input', { class: 'in', type: 'date', 'aria-label': 'Tenggat' });
  due.value = item && item.due ? item.due : '';
  const remAt = h('input', { class: 'in', type: 'datetime-local', 'aria-label': 'Waktu pengingat' });
  remAt.value = item && item.reminder ? toLocalInput(item.reminder.at) : '';
  const remRepeat = h('select', { class: 'in', 'aria-label': 'Pengulangan pengingat' }, h('option', { value: 'once' }, 'Sekali'), h('option', { value: 'daily' }, 'Setiap hari'));
  remRepeat.value = item && item.reminder && item.reminder.repeat === 'daily' ? 'daily' : 'once';
  const remHint = h('small', { class: 'remhint', 'aria-live': 'polite' }, remRepeat.value === 'daily' ? 'Pengingat berulang setiap hari.' : 'Pengingat hanya sekali.');
  const syncRemHint = () => { remHint.textContent = remRepeat.value === 'daily' ? 'Pengingat berulang setiap hari.' : 'Pengingat hanya sekali.'; };
  remRepeat.addEventListener('change', syncRemHint); remRepeat.addEventListener('input', syncRemHint);
  const err = h('p', { class: 'err', role: 'alert' });
  // Rev 311a: penolakan tampil sebagai dialog.
  const hi = (el) => { if (el) { if (el.scrollIntoView) el.scrollIntoView({ block: 'center' }); el.classList.add('inerr'); setTimeout(() => el.classList.remove('inerr'), 4000); } };
  const refuse = (d, el) => { err.textContent = d.msg; infoDlg(d); hi(el); };
  const refusePast = (t, who, el) => { err.textContent = 'Waktu pengingat sudah lewat.'; infoPast(t, who); hi(el); };
  // Rev 67: sub-tugas (hanya Fokus/Target/Rencana). Disunting sebagai salinan; baru masuk ke tugas saat Simpan.
  const hasSubs = !isH && canHaveSubs(item ? item.scope : ui.seg);
  let draft = hasSubs && item && Array.isArray(item.subs) ? item.subs.map((x) => ({ ...x })) : [];
  // Rev 92: sub-tugas dan pengingat hanya tampil bila sakelarnya aktif (supaya mengetik tugas biasa tidak terkesan penuh).
  let subsOn = hasSubs && (draft.length > 0 || !!opts.sub);
  let remOn = !isH && !!(item && (item.reminder || item.remMode === 'subs'));
  const subList = h('div', { class: 'sublist' });
  const subIn = h('input', { class: 'in', placeholder: 'Tambah sub-tugas', 'aria-label': 'Sub-tugas baru', maxlength: '120' }); capInput(subIn);
  const subCount = h('small', { class: 'subcount' });
  // Rev 68: mode pengingat. 'task' = satu pengingat di tugas (seperti sebelumnya); 'subs' = pengingat sendiri di tiap sub-tugas.
  let remMode = hasSubs && item && item.remMode === 'subs' ? 'subs' : 'task';
  // Rev 381: satu mode untuk pengingat tugas DAN semua pengingat sub-tugasnya (dipilih sekali di bagian Pengingat). Hanya 'alarm' yang disimpan.
  let rmode = item && item.reminder && item.reminder.mode === 'alarm' ? 'alarm' : 'notif'; // Rev 394 / SM2: hanya pengingat tugas sendiri; tiap sub-tugas punya mode sendiri (modePick)
  const mp = A && !isH ? A.modePicker({ mode: rmode, onChange: (m) => { rmode = m; } }) : null;
  const openRem = new Set(), repPick = new Map(), modePick = new Map(); // Rev 394: modePick = mode per sub-tugas (sebelum waktunya diisi)
  const remFields = h('div', { class: 'remfields' }, remAt, remRepeat, remHint);
  remAt.addEventListener('change', () => { const t = fromLocalInput(remAt.value); if (t && remRepeat.value !== 'daily' && t <= Date.now()) infoPast(t); });
  const bDirect = h('button', { type: 'button' }, 'Langsung di tugas');
  const bPerSub = h('button', { type: 'button' }, 'Di tiap sub-tugas');
  const modeNote = h('small', { class: 'remhint', 'aria-live': 'polite' });
  const remModeGroup = h('div', { class: 'pri remmode', role: 'group', 'aria-label': 'Tempat pengingat' }, bDirect, bPerSub);
  function syncMode() {
    const em = subsOn ? remMode : 'task';
    remModeGroup.style.display = subsOn ? '' : 'none';
    bDirect.classList.toggle('on', em === 'task'); bPerSub.classList.toggle('on', em === 'subs');
    bDirect.setAttribute('aria-pressed', em === 'task' ? 'true' : 'false'); bPerSub.setAttribute('aria-pressed', em === 'subs' ? 'true' : 'false');
    remFields.style.display = em === 'subs' ? 'none' : '';
    if (mp) mp.el.style.display = em === 'subs' ? 'none' : ''; // Rev 394: pemilih tugas tidak relevan saat pengingat per sub-tugas
    modeNote.style.display = em === 'subs' ? '' : 'none';
    modeNote.textContent = draft.length ? 'Ketuk "⏰ Atur pengingat" di bawah tiap sub-tugas (bagian Sub-tugas di atas).' : 'Tambah sub-tugas dulu, lalu atur pengingat di tiap sub-tugas.';
  }
  let syncSaveHook = () => {}; // diisi setelah tombol Simpan atas dibuat (Rev 91)
  let drawSubs = () => {
    subList.replaceChildren(...draft.map((sb, i) => {
      const ti = h('input', { class: 'in subin', 'data-sid': sb.id, 'aria-label': 'Sub-tugas ' + (i + 1), maxlength: '120' });
      capInput(ti); ti.value = sb.title;
      ti.addEventListener('input', () => { sb.title = ti.value; });
      const top = h('div', { class: 'srow edit' + (sb.done ? ' done' : '') },
        h('button', { type: 'button', class: 'ck sm' + (sb.done ? ' on' : ''), 'aria-label': sb.done ? 'Batalkan centang sub-tugas' : 'Centang sub-tugas', onclick: () => { sb.done = !sb.done; drawSubs(); } }),
        ti,
        h('button', { type: 'button', class: 'ghost', 'aria-label': 'Hapus sub-tugas', onclick: () => { openRem.delete(sb.id); draft.splice(i, 1); drawSubs(); } }, ico(PATH.bin)));
      if (remMode !== 'subs') return h('div', { class: 'sed' }, top);
      const has = !!sb.reminder, open = openRem.has(sb.id);
      const bell = h('button', { type: 'button', class: 'sbellbtn' + (has ? ' on' : ''), 'aria-expanded': open ? 'true' : 'false', 'aria-label': has ? 'Ubah pengingat sub-tugas ' + (i + 1) : 'Atur pengingat sub-tugas ' + (i + 1),
        onclick: () => { if (openRem.has(sb.id)) openRem.delete(sb.id); else openRem.add(sb.id); drawSubs(); } }, '⏰ ' + (has ? describeReminder(sb.reminder) + (sb.reminder.mode === 'alarm' ? ' · alarm' : '') : 'Atur pengingat'), h('span', { class: 'subar' }, open ? '▴' : '▾'));
      const kids = [top, bell];
      if (open) {
        const at = h('input', { class: 'in', type: 'datetime-local', 'aria-label': 'Waktu pengingat sub-tugas ' + (i + 1) });
        at.value = has ? toLocalInput(sb.reminder.at) : '';
        const rp = h('select', { class: 'in', 'aria-label': 'Pengulangan pengingat sub-tugas ' + (i + 1) }, h('option', { value: 'once' }, 'Sekali'), h('option', { value: 'daily' }, 'Setiap hari'));
        rp.value = has ? sb.reminder.repeat : (repPick.get(sb.id) || 'once');
        const subMode = () => (modePick.has(sb.id) ? modePick.get(sb.id) : (sb.reminder ? sb.reminder.mode : 'notif'));
        const msw = A && A.modeSwitch ? A.modeSwitch({ mode: subMode(), onChange: (m) => { modePick.set(sb.id, m); if (sb.reminder) { sb.reminder = withMode({ at: sb.reminder.at, repeat: sb.reminder.repeat }, m); drawSubs(); } syncSaveHook(); } }) : null; // Rev 394 / SM3 (varian B)
        const upd = () => {
          repPick.set(sb.id, rp.value === 'daily' ? 'daily' : 'once');
          const t = fromLocalInput(at.value);
          if (t) sb.reminder = withMode({ at: t, repeat: rp.value === 'daily' ? 'daily' : 'once' }, subMode()); else delete sb.reminder;
          err.textContent = ''; drawSubs();
          if (t && rp.value !== 'daily' && t <= Date.now()) refusePast(t, sb.title);
        };
        at.addEventListener('change', upd); rp.addEventListener('change', upd);
        kids.push(h('div', { class: 'sremp' }, at, rp, msw ? msw.el : null, has ? h('button', { type: 'button', class: 'btn line sbclear', onclick: () => { delete sb.reminder; drawSubs(); } }, 'Hapus pengingat') : null));
      }
      return h('div', { class: 'sed' }, kids);
    }));
    subCount.textContent = draft.length + ' dari ' + SUB_MAX + ' sub-tugas';
    syncMode();
    syncSaveHook();
  };
  bDirect.onclick = () => { remMode = 'task'; drawSubs(); };
  bPerSub.onclick = () => { remMode = 'subs'; drawSubs(); };
  const pushSub = () => {
    if (!subIn.value.trim()) return { ok: true, empty: true };
    const r = addSub(draft, subIn.value);
    if (!r.ok) { refuse({ title: 'Sub-tugas belum bisa ditambah', msg: r.msg, fix: 'Ubah atau hapus sub-tugas yang ada, lalu coba lagi.' }, subIn); return r; }
    draft = r.subs; subIn.value = ''; err.textContent = ''; drawSubs();
    return r;
  };
  subIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); pushSub(); subIn.focus(); } });
  drawSubs();
  const bBiasa = h('button', { type: 'button' }, 'Biasa');
  const bPenting = h('button', { type: 'button' }, 'Penting');
  const mark = () => { bBiasa.classList.toggle('on', pri === 0); bPenting.classList.toggle('on', pri === 1); };
  bBiasa.onclick = () => { pri = 0; mark(); };
  bPenting.onclick = () => { pri = 1; mark(); };
  mark();
  const ov = h('div', { class: 'ov', onclick: (e) => { if (e.target === ov) ov.remove(); } });
  const onSave = () => {
    const v = validateTitle(title.value);
    if (!v.ok) { refuse({ title: isH ? 'Nama kebiasaan kosong' : 'Judul tugas kosong', msg: isH ? 'Nama kebiasaan wajib diisi sebelum disimpan.' : 'Judul tugas wajib diisi sebelum disimpan.', fix: 'Ketik namanya di kolom paling atas, lalu simpan lagi.' }, title); return; }
    if (hasSubs && subsOn) { const sr = pushSub(); if (!sr.ok) return; draft.forEach((x) => { x.title = String(x.title || '').toUpperCase(); }); } // teks yang sudah diketik tapi belum ditambah tidak hilang
    const subsMode = hasSubs && subsOn && remOn && remMode === 'subs';
    // Rev 394 / SM2: TIDAK ada lagi penimpaan mode ke semua sub-tugas; tiap sub-tugas membawa modenya sendiri di x.reminder.mode.
    const now0 = Date.now();
    if (subsMode) {
      if (!cleanSubs(draft).length) { refuse({ title: 'Belum ada sub-tugas', msg: 'Mode pengingat "Di tiap sub-tugas" butuh minimal satu sub-tugas yang judulnya terisi.', fix: 'Tambah sub-tugas dulu, atau ganti ke "Langsung di tugas".' }, subIn); return; }
      const late = draft.find((x) => !x.done && x.reminder && x.reminder.repeat !== 'daily' && x.reminder.at <= now0);
      if (late) { openRem.add(late.id); drawSubs(); refusePast(late.reminder.at, String(late.title).slice(0, 40), subList.querySelector('[data-sid="' + late.id + '"]')); return; }
    }
    const chosenAt = (subsMode || !remOn) ? 0 : fromLocalInput(remAt.value);
    if (!isH && !subsMode && remOn && remAt.value && (!chosenAt || (remRepeat.value !== 'daily' && chosenAt <= Date.now()))) { if (chosenAt) refusePast(chosenAt, '', remAt); else refuse({ title: 'Waktu pengingat tidak valid', msg: 'Tanggal dan jam pengingat belum terisi lengkap.', fix: 'Isi tanggal dan jam, atau matikan pengingat.' }, remAt); return; }
    if (isNew) {
      const it = { id: newId(), title: v.value.toUpperCase(), done: false };
      if (!isH) { it.pri = pri; it.due = due.value; it.scope = ui.seg; const at = chosenAt; if (at) it.reminder = withMode({ at, repeat: remRepeat.value === 'daily' ? 'daily' : 'once' }, rmode); const cs = hasSubs && subsOn ? cleanSubs(draft) : []; if (!subsMode) cs.forEach((x) => { delete x.reminder; }); if (cs.length) it.subs = cs; if (subsMode && cs.length) it.remMode = 'subs'; }
      (isH ? data.habits : data.tasks).push(it);
    } else {
      item.title = v.value.toUpperCase();
      const oldSubIds = !isH && Array.isArray(item.subs) ? item.subs.map((x) => x.id) : [];
      if (!isH) { item.pri = pri; item.due = due.value; const at = chosenAt; if (at) item.reminder = withMode({ at, repeat: remRepeat.value === 'daily' ? 'daily' : 'once' }, rmode); else delete item.reminder; const cs = hasSubs && subsOn ? cleanSubs(draft) : []; if (!subsMode) cs.forEach((x) => { delete x.reminder; }); if (cs.length) item.subs = cs; else delete item.subs; if (subsMode && cs.length) { item.remMode = 'subs'; delete item.reminder; } else delete item.remMode; for (const oid of oldSubIds) if (!cs.some((x) => x.id === oid)) cancelSubReminder(item.id, oid); }
    }
    persist(); if (!isH) { const target = isNew ? data.tasks[data.tasks.length - 1] : item; const rs = syncTaskAlarms(target); if (rs.some((x) => x.expired)) persist(); const warn = rs.find((x) => x.warning === 'inexact_alarm'), bad = rs.find((x) => !x.ok && !x.skipped); if (warn) dlg({ title: 'Pengingat mungkin terlambat', msg: 'Izin Alarm & pengingat tepat belum aktif. Pengingat tetap dijadwalkan, tetapi bisa terlambat.', yes: 'Buka pengaturan', ok: () => { try { globalThis.AndroidAPI?.openExactAlarmSettings?.(); } catch (_) {} } }); else if (bad) toast(bad.reason === 'permission' ? 'Izinkan notifikasi Android. Jadwal akan disinkronkan setelah kembali ke aplikasi.' : 'Pengingat belum bisa dijadwalkan di perangkat ini.'); } ov.remove(); render();
  };
  // Rev 92: susunan dialog dirombak. Sakelar (toggle) untuk Sub-tugas dan Pengingat; bila sub-tugas aktif, Simpan
  // pindah jadi centang hijau di samping kolom judul (tidak perlu menggulir ke bawah), bila tidak aktif Simpan tetap di bawah.
  const saveTop = h('button', { type: 'button', class: 'savetop', 'aria-label': 'Simpan', onclick: onSave }, h('span', { class: 'savetop-ck', 'aria-hidden': 'true' }));
  const saveBottom = h('button', { type: 'button', class: 'btn', onclick: onSave }, 'Simpan');
  const syncSave = () => {
    const on = hasSubs && subsOn;
    saveTop.style.display = on ? '' : 'none';
    saveBottom.style.display = on ? 'none' : '';
  };
  const mkSwitch = (label, on, onToggle) => {
    const b = h('button', { type: 'button', class: 'tgl' + (on ? ' on' : ''), role: 'switch', 'aria-checked': on ? 'true' : 'false', 'aria-label': label }, h('span', { class: 'tgl-k' }));
    b.addEventListener('click', () => { const n = b.getAttribute('aria-checked') !== 'true'; b.classList.toggle('on', n); b.setAttribute('aria-checked', n ? 'true' : 'false'); onToggle(n); });
    return b;
  };
  const collapse = (open, cls, ...kids) => h('div', { class: 'cl' + (open ? ' open' : '') }, h('div', { class: 'cl-in' }, h('div', { class: 'cl-pad ' + cls }, ...kids)));
  const scHead = (icon, name, hint, sw) => h('div', { class: 'sc-head' }, h('span', { class: 'sc-ic', 'aria-hidden': 'true' }, ico(icon)), h('div', { class: 'sc-tt' }, h('b', {}, name), hint), sw);
  const subHint = h('small', {});
  const syncSubHint = () => { subHint.textContent = subsOn ? (draft.length ? draft.length + ' sub-tugas' : 'Pecah tugas jadi langkah kecil') : (draft.length ? draft.length + ' sub-tugas disembunyikan, dihapus saat Simpan' : 'Pecah tugas jadi langkah kecil'); };
  const subBody = hasSubs ? collapse(subsOn, 'task-subs', subList, subIn, h('button', { type: 'button', class: 'btn line subadd', onclick: () => { pushSub(); subIn.focus(); } }, '+ Tambah sub-tugas'), subCount) : null;
  const subSw = hasSubs ? mkSwitch('Aktifkan sub-tugas', subsOn, (n) => { subsOn = n; subBody.classList.toggle('open', n); drawSubs(); if (n && !draft.length) setTimeout(() => { try { subIn.focus(); } catch (_) {} }, 280); }) : null;
  const remHintEl = h('small', {}, 'Ingatkan di waktu yang kamu pilih');
  const remBody = !isH ? collapse(remOn, 'task-reminder', remModeGroup, modeNote, remFields, mp ? mp.el : null) : null;
  const remSw = !isH ? mkSwitch('Aktifkan pengingat', remOn, (n) => { remOn = n; remBody.classList.toggle('open', n); }) : null;
  const subDraw = drawSubs;
  drawSubs = () => { subDraw(); syncSubHint(); };
  drawSubs(); syncSaveHook = syncSave; syncSave();
  const sheetEl = h('div', { class: 'sheet tsheet' },
    h('div', { class: 'thead' }, h('h3', {}, (isNew ? 'Tambah ' : 'Ubah ') + (isH ? 'kebiasaan' : 'tugas')), h('div', { class: 'trow2' }, title, isH ? null : saveTop)),
    isH ? null : [
      h('section', { class: 'sc' }, h('label', { class: 'lb' }, 'Tenggat'), due, h('label', { class: 'lb' }, 'Prioritas'), h('div', { class: 'pri' }, bBiasa, bPenting)),
      hasSubs ? h('section', { class: 'sc' }, scHead(PATH.rows, 'Sub-tugas', subHint, subSw), subBody) : null,
      h('section', { class: 'sc' }, scHead(PATH.alarm, 'Pengingat', remHintEl, remSw), remBody)],
    err,
    saveBottom,
    h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Batal'));
  // Rev 22: lembar bisa digulir saat keyboard terbuka; judul menempel di atas agar ketikan selalu terlihat, kolom lain digulir ke area terlihat.
  // Rev 91: ketuk kolom sub-tugas mana pun = langsung tertuju ke kolom itu (posisi gulir dipertahankan, tidak loncat ke atas).
  // Posisi gulir dicatat saat jari menyentuh; bila WebView menggulir sendiri ke atas, dipulihkan lalu kolom dibuat terlihat
  // di bawah judul yang menempel dan di atas keyboard.
  let keepTop = 0;
  const keepScroll = () => { keepTop = sheetEl.scrollTop; };
  sheetEl.addEventListener('pointerdown', keepScroll, true); sheetEl.addEventListener('touchstart', keepScroll, { capture: true, passive: true });
  sheetEl.addEventListener('scroll', () => { if (!sheetEl.dataset.fx) keepTop = sheetEl.scrollTop; }, { passive: true });
  const reveal = (t, restore) => {
    if (!t.isConnected) return;
    if (restore && sheetEl.scrollTop < keepTop - 40) sheetEl.scrollTop = keepTop;
    const vv = window.visualViewport, bottom = vv ? vv.offsetTop + vv.height : window.innerHeight;
    const head = sheetEl.querySelector('.thead'), top = (head ? head.getBoundingClientRect().bottom : 0) + 8;
    const r = t.getBoundingClientRect();
    if (r.top < top) sheetEl.scrollTop -= top - r.top;
    else if (r.bottom > bottom - 8) sheetEl.scrollTop += r.bottom - (bottom - 8);
    keepTop = sheetEl.scrollTop;
  };
  sheetEl.addEventListener('focusin', (e) => {
    const t = e.target; if (!t || t === title || !t.getBoundingClientRect) return;
    sheetEl.dataset.fx = '1';
    [0, 120, 320, 600].forEach((ms) => setTimeout(() => { try { reveal(t, true); } catch (_) {} if (ms === 600) delete sheetEl.dataset.fx; }, ms));
  });
  ov.append(sheetEl);
  document.body.append(ov);
  if (opts.sub && subsOn) {
    // Rev 92: mengetuk sub-tugas di daftar membuka dialog langsung di kolom sub-tugas itu (bukan di judul).
    setTimeout(() => {
      const el = subList.querySelector('[data-sid="' + String(opts.sub).replace(/"/g, '') + '"]');
      if (!el) { title.focus(); return; }
      el.focus(); try { const n = el.value.length; el.setSelectionRange(n, n); } catch (_) {}
    }, 60);
  } else setTimeout(() => title.focus(), 50);
}

function viewTugas() {
  const sc = SCOPES.find((s) => s.id === ui.seg), isH = ui.seg === 'habit';
  const list = isH ? data.habits : sortTasks(tasksByScope(data.tasks, ui.seg));
  const done = list.filter((x) => x.done).length;
  const active = list.filter((x) => !x.done), finished = list.filter((x) => x.done);
  const kind = isH ? 'habit' : 'task';
  const offDay = isH && !data.settings.days.includes(dayOfWeek(todayISO()));
  const msg = !list.length ? 'Belum ada isi. Tambah dengan tombol +.'
    : isH ? 'Semua kebiasaan hari ini sudah beres. Kerja bagus!' : 'Semua beres. Tambah tugas baru dengan tombol +.';
  return [
    h('div', { class: 'seg' }, SCOPES.map((s) => h('button', { type: 'button', class: s.id === ui.seg ? 'on' : '', onclick: () => { ui.seg = s.id; render(); } },
      h('span', { class: 'em' }, s.emoji), h('span', {}, s.short)))),
    judul(sc.id),
    h('p', { class: 'sub' }, isH ? `${done} dari ${list.length} sudah dikerjakan. Dikosongkan lagi tiap hari kerja baru.` : `${done} dari ${list.length} selesai`),
    h('div', { class: 'prog' }, h('i', { style: `width:${list.length ? Math.round(done / list.length * 100) : 0}%` })),
    offDay ? h('div', { class: 'notice' }, 'Hari ini bukan hari kerja, jadi kebiasaan tidak ditagih.') : null,
    active.length ? active.map((x) => row(x, kind)) : h('div', { class: 'empty' }, msg),
    finished.length ? [h('p', { class: 'sub' }, 'Selesai'), finished.map((x) => row(x, kind))] : null,
  ];
}

function viewSoon(name) {
  return [h('h1', {}, name), h('div', { class: 'empty' }, 'Bagian ini dibuat di langkah implementasi berikutnya.')];
}

// Rev 71: gambar ulang bentuk bar menu bawah (lekukan di bawah lingkaran aktif); dipanggil tiap render dan saat layar berubah ukuran.
function navBg() {
  const NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'navbg'); svg.setAttribute('aria-hidden', 'true');
  for (const cls of ['navsh', 'navfill']) { const pth = document.createElementNS(NS, 'path'); pth.setAttribute('class', cls); svg.appendChild(pth); }
  return svg;
}

// Rev 93: bar bawah digerakkan lewat requestAnimationFrame (bukan transisi CSS `d`) supaya lekukan dan lingkaran penanda
// selalu serempak, memakai kurva yang sama, dan tidak bergantung dukungan WebView. Selama bergerak, bayangan blur dimatikan sementara (hemat repaint).
const NAV_MS = 360;
const navAnim = { cur: null, target: null, raf: 0 };
const navEase = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const reduceMotion = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

// Rev 415: lebar satu tab PECAHAN (mis. 63,2 px), bukan offsetWidth yang dibulatkan; penanda jadi tepat di tengah ikon di tab mana pun.
function navUnit(ind) { const w = parseFloat(getComputedStyle(ind).width); return w > 0 ? w : ind.offsetWidth; }

function navPaint(navEl, x) {
  // Rev 94: ikon + label tiap tab ikut posisi lingkaran (var --p = 0..1), bukan transisi CSS sendiri, sehingga ikon tidak "melompat" lebih dulu.
  navEl.querySelectorAll('button[data-tab]').forEach((b, i) => {
    const p = Math.max(0, 1 - Math.abs(x - i));
    b.style.setProperty('--p', p.toFixed(3));
    b.classList.toggle('lit', p >= 0.5);
  });
  const W = navEl.clientWidth, H = navEl.clientHeight;
  if (!W || !H) return;
  const svg = navEl.querySelector('.navbg'), ind = navEl.querySelector('.navind');
  if (svg && getComputedStyle(svg).display !== 'none') { // Rev 95: tema Bingkai Neon menyembunyikan .navbg; gambar lekukan hanya bila tampil
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    const d = navShape(W, H, x, { tabs: 5 });
    svg.querySelectorAll('path').forEach((pth) => { pth.setAttribute('d', d); pth.style.d = "path('" + d + "')"; });
  }
  if (ind) ind.style.transform = 'translate3d(' + (x * navUnit(ind)) + 'px,0,0)' + (navEl.classList.contains('navhold') ? ' scale(1.07)' : '');
}

function navTo(navEl, target, animate) {
  cancelAnimationFrame(navAnim.raf);
  const from = navAnim.cur == null ? target : navAnim.cur;
  navAnim.target = target;
  if (!animate || reduceMotion() || from === target) {
    navAnim.cur = target; navEl.classList.remove('navmove'); navPaint(navEl, target); return;
  }
  navEl.classList.add('navmove');
  const t0 = performance.now();
  const step = (now) => {
    const t = Math.min(1, (now - t0) / NAV_MS);
    navAnim.cur = from + (target - from) * navEase(t);
    navPaint(navEl, navAnim.cur);
    if (t < 1) navAnim.raf = requestAnimationFrame(step);
    else { navAnim.cur = target; navEl.classList.remove('navmove'); }
  };
  navAnim.raf = requestAnimationFrame(step);
}

// Rev 415: GESER BAR BAWAH. Tekan lalu geser: penanda ikut jari (posisi pecahan lewat navPaint yang sama); lepas: meluncur ke TENGAH tab
// terdekat dan berhenti tepat di sana (navTo, easing tanpa pantulan). Ketukan biasa tetap lewat onclick tombol.
const NAV_GESER_PX = 6;
function navGeser(navEl, tabs, pickTab) {
  let down = null, geser = false, blokirKlik = 0;
  const ind = () => navEl.querySelector('.navind');
  const posisi = (clientX) => {
    const i = ind(); const u = i ? navUnit(i) : 0; if (!u) return 0;
    const x = clientX - navEl.getBoundingClientRect().left - navEl.clientLeft;
    return Math.max(0, Math.min(tabs.length - 1, (x - i.offsetLeft) / u - 0.5));
  };
  const lepas = (batal) => {
    if (!down) return;
    const dipakai = geser; down = null; geser = false;
    navEl.classList.remove('navhold');
    if (!dipakai) return;
    blokirKlik = performance.now() + 400; // klik susulan sesudah geseran jangan menekan tombol di bawahnya
    const cur = navAnim.cur == null ? 0 : navAnim.cur;
    const idx = Math.max(0, Math.min(tabs.length - 1, Math.round(cur)));
    const id = tabs[idx][0];
    if (batal && id === ui.tab) { navTo(navEl, idx, true); return; }
    if (id === ui.tab) navTo(navEl, idx, true); // kembali ke tab yang sama: tetap meluncur ke tengah
    else pickTab(id);                           // tab lain: pindah (navTo dipanggil di dalamnya)
  };
  navEl.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    down = { x: e.clientX, id: e.pointerId }; geser = false;
  });
  navEl.addEventListener('pointermove', (e) => {
    if (!down || e.pointerId !== down.id) return;
    if (!geser) {
      if (Math.abs(e.clientX - down.x) < NAV_GESER_PX) return;
      geser = true;
      cancelAnimationFrame(navAnim.raf);
      navEl.classList.add('navhold', 'navmove');
      try { navEl.setPointerCapture(e.pointerId); } catch (_) { /* aman diabaikan */ }
    }
    navAnim.target = null; navAnim.cur = posisi(e.clientX);
    navPaint(navEl, navAnim.cur);
  });
  navEl.addEventListener('pointerup', (e) => { if (down && e.pointerId === down.id) lepas(false); });
  navEl.addEventListener('pointercancel', (e) => { if (down && e.pointerId === down.id) lepas(true); });
  navEl.addEventListener('click', (e) => { if (performance.now() < blokirKlik) { e.stopPropagation(); e.preventDefault(); } }, true);
}

function drawNav(navEl) { // gambar ulang tanpa animasi (resize / render pertama)
  if (navAnim.target != null && navAnim.cur !== navAnim.target) return; // sedang bergerak: biarkan animasi jalan
  navPaint(navEl, navAnim.cur == null ? (Number(navEl.dataset.i) || 0) : navAnim.cur);
}

function render() {
  const tabs = [['tugas', 'Tugas'], ['catatan', 'Catatan'], ['ai', 'Kelimaa AI'], ['privat', 'Private'], ['lainnya', 'Setelan']]; // Rev 215: tab AI di tengah (antara Catatan dan Private)
  const body = ui.tab === 'tugas' ? viewTugas() : ui.tab === 'catatan' ? viewNotes(ctx) : ui.tab === 'privat' ? viewPrivat(ctx) : ui.tab === 'ai' ? viewKelimaaAI(ctx) : ui.tab === 'lainnya' ? viewSettings(ctx) : viewSoon(tabs.find((t) => t[0] === ui.tab)[1]);
  const app = $('#app');
  let mainEl = app.querySelector(':scope > main');
  let navEl = app.querySelector(':scope > nav');
  let fabEl = app.querySelector(':scope > .fab');

  // Pertahankan elemen navigasi yang sama saat render. Ini menghindari sentuhan
  // terputus akibat tombol bawah dihancurkan dan dibuat ulang pada setiap perpindahan.
  if (!mainEl) {
    mainEl = h('main');
    // Rev 415: logika pindah tab dipakai bersama oleh ketukan (onclick) dan geseran bar (pointer).
    const pickTab = (id) => {
      if (id === ui.tab) return;
      exitSelect();
      if (ui.tab === 'privat' && id !== 'privat') { ui.unlocked = false; closeEditor('priv'); }
      if (id === 'ai') ui.prevTab = ui.tab; // Rev 223: chat AI layar penuh tanpa bilah bawah; Kembali HP / tombol di laci Riwayat mengembalikan ke tab ini
      ui.moreView = 'main'; ui.tab = id;
      // Rev 93: penanda bar mulai bergerak lebih dulu; isi halaman diganti 2 frame kemudian supaya gerakan tidak tersendat oleh pembangunan daftar.
      const idx = tabs.findIndex(([tid]) => tid === id);
      navEl.querySelectorAll('button[data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === id));
      navTo(navEl, idx, true);
      requestAnimationFrame(() => requestAnimationFrame(() => render()));
    };
    navEl = h('nav', {}, navBg(), h('span', { class: 'navind', 'aria-hidden': 'true' }), ...tabs.map(([id, label]) => h('button', {
      type: 'button', 'data-tab': id, class: id === ui.tab ? 'on' : '',
      onclick: () => pickTab(id),
    }, ico(id === 'tugas' ? PATH.tugasNav : id === 'ai' ? PATH.star : PATH[id]), h('span', {}, label))));
    app.replaceChildren(mainEl, navEl);
    navGeser(navEl, tabs, pickTab);
    window.addEventListener('resize', () => navPaint(navEl, navAnim.cur == null ? 0 : navAnim.cur));
  }

  mainEl.replaceChildren(...body.flat(Infinity).filter((node) => node != null && node !== false)); // Rev 40: daftar tugas = array bersarang; tanpa flat() jadi teks "[object HTMLDivElement]"
  mainEl.dataset.tab = ui.tab === 'ai' ? 'lainnya' : ui.tab; mainEl.dataset.sub = ui.tab === 'ai' ? 'ai' : ui.tab === 'lainnya' ? (ui.moreView || 'main') : ''; /* Rev 215: layar AI memakai gaya sub-layar Setelan */ // Rev 172: penanda layar untuk gaya Setelan (kolase di 'main', gaya halaman di sub-layar)
  const aiFull = ui.tab === 'ai' && ui.moreView === 'aichat', wasFull = app.classList.contains('aifull'); // Rev 223: chat AI = layar penuh (bilah bawah disembunyikan lewat CSS)
  app.classList.toggle('aifull', aiFull);
  mainEl.classList.remove('view-enter');
  // Reflow kecil hanya pada kontainer konten; navigasi bawah tidak ikut dibangun ulang.
  void mainEl.offsetWidth;
  mainEl.classList.add('view-enter');

  const navIdx = Math.max(0, tabs.findIndex(([id]) => id === ui.tab));
  navEl.dataset.i = String(navIdx); // geser penanda (Rev 36)
  if (navAnim.target !== navIdx) navTo(navEl, navIdx, navAnim.cur != null); // pindah tab lewat jalur lain (mis. kembali): tetap beranimasi
  else drawNav(navEl);
  if (wasFull && !aiFull) requestAnimationFrame(() => drawNav(navEl)); // bilah tampil lagi: gambar ulang lekukan dengan ukuran yang benar
  navEl.querySelectorAll('button[data-tab]').forEach((button) => {
    const active = button.dataset.tab === ui.tab;
    button.classList.toggle('on', active);
    button.setAttribute('aria-current', active ? 'page' : 'false');
  });

  const showFab = ui.tab === 'tugas' || (ui.tab === 'catatan' && !ui.favoritesRoom) ||
    (ui.tab === 'privat' && ui.unlocked && data.settings.pinHash);
  if (showFab && !fabEl) {
    fabEl = h('button', { type: 'button', class: 'fab', 'aria-label': 'Tambah', onclick: () => {
      exitSelect();
      return ui.tab === 'catatan' ? openEditor(ctx) : ui.tab === 'privat' ? openEditor(ctx, undefined, 'priv') : openSheet(ui.seg === 'habit' ? 'habit' : 'task');
    } }, '+');
    app.insertBefore(fabEl, navEl);
  } else if (!showFab && fabEl) {
    fabEl.remove();
  }
}

// Reset kebiasaan sekali per hari kerja baru, dan terapkan tema tersimpan
if (applyDailyReset(data)) persist();
// Tempat sampah otomatis kosong (Rev 19): buang item yang lewat batas (bawaan Mati, tidak melakukan apa-apa).
const purged = purgeTrash(data); if (purged) persist();
applyTheme(data.settings.theme); applySelColor(data.settings.selColor);
applySnooze(data.settings.snoozeMin); // Rev 389 / TN2: lama Tunda alarm ke Android saat aplikasi mulai
try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => syncBars()); } catch (e) { /* peramban lama */ }
render();
mark('render-awal'); // Rev 191 / P1
installSkyLock(); // Rev 75: tinggi latar dikunci (tidak melar saat keyboard muncul/turun)
if (purged) toast(purged + ' item lama dihapus dari tempat sampah.');
// Cadangan otomatis (Rev 17): dicek sebentar setelah aplikasi tampil, dan tiap aplikasi kembali ke layar.
setTimeout(() => { maybeAutoBackup(ctx).catch(() => {}); }, 1500);
// Terima teks dari Bagikan Android (Rev 20): teks yang menunggu dari buka dingin diambil sekarang; dorongan native saat aplikasi terbuka lewat __kelimaaShared.
installShareInbox(ctx); pullShared(ctx);
// Rev 191 / P1: pekerjaan yang tidak perlu menahan gambar pertama dijalankan SESUDAH gambar pertama (satu kali; cadangan 1,2 dtk bila rAF tertahan).
// Isinya sama seperti sebelumnya, hanya digeser waktunya: (1) Rev 21: sinkronkan jadwal Android dari data lokal setiap aplikasi dibuka (tetap SETIAP buka);
// (2) G3: bersihkan berkas gambar yatim > 24 jam (gagal = diabaikan); (3) Rev 39: bintang jatuh (hiasan; gagal = diabaikan).
afterFirstPaint(() => {
  if (wasLoadFailure()) setTimeout(() => tErr('Data gagal dibaca. Salinan mentah disimpan; gambar tidak dihapus. Jangan hapus aplikasi dulu.'), 1500);
  const reminderResults = [...syncAllReminders(data), ...syncAllNoteAlarms(data)];
  if (reminderResults.some((x) => x.expired)) persist();
  if (reminderResults.some((x) => x.warning === 'inexact_alarm')) setTimeout(() => tWarn('Sebagian pengingat mungkin terlambat karena izin alarm tepat belum aktif.'), 1800);
  cleanupOrphanImages(data).then(() => {}).catch(() => {}); // Rev 198 / P8: log console.info dibuang (tidak perlu di rilis)
  installShootingStars();
  // Rev 192b / P2b: mesin rumus (57 KB) tidak ada di jalur buka. Ada lembar berumus = dimuat sekarang (sesudah gambar pertama) lalu tampilan yang memuat hasil rumus digambar ulang.
  if (sheetsHaveFx(data.sheets)) { onEngine(() => { try { render(); } catch (_) { /* diabaikan */ } }); loadEngine().catch(() => {}); }
  // Rev 192d / P2c: pemakai lembar kerja (ada lembar tersimpan) = layar lembar kerja dimuat DIAM-DIAM saat idle supaya ketukan pertama langsung terbuka.
  // Tanpa lembar tersimpan tidak dimuat dulu (hemat RAM/CPU saat buka); ketukan pertama memuatnya dan menampilkan penanda singkat bila terasa lama.
  setSlowNotice(() => { tInfo('Membuka lembar kerja…'); return () => { const t = document.getElementById('toast'); if (t && t.textContent === 'Membuka lembar kerja…') t.remove(); }; });
  if (Object.keys(data.sheets || {}).length) { const w = () => warmSheetUI(); if (typeof requestIdleCallback === 'function') requestIdleCallback(w, { timeout: 4000 }); else setTimeout(w, 2500); }
  mark('tertunda-selesai');
  autoSync('buka');
});
installReminderInbox(ctx, (item, subId) => { ui.tab = 'tugas'; ui.seg = item.scope || 'hari'; if (subId) openSubs.add(item.id); render(); if (!subId) openSheet('task', item); }, (item) => { ui.tab = 'catatan'; render(); openEditor(ctx, item.id, 'note'); }, () => { ui.tab = 'lainnya'; ui.moreView = 'twopockets'; render(); });
// Rev 57: bila Two Pockets tersambung, muat daftar jatuh tempo servis/pajak dan pasang alarm (diam-diam; gagal/offline tidak mengubah apa pun; paling sering tiap 3 jam).
setTimeout(() => { refreshDue().catch(() => {}); }, 4000);
// Rev 193 / P3: pagehide (WebView dihancurkan) ikut menyimpan ketikan tertunda
window.addEventListener('pagehide', () => flushEditor());
// Kunci otomatis saat aplikasi ke latar belakang
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { flushEditor(); if (ui.unlocked) lockPrivat(ctx); }
  else {
    if (applyDailyReset(data)) { persist(); render(); } // aplikasi dibuka lagi di hari kerja baru
    const resumedReminders = [...syncAllReminders(data), ...syncAllNoteAlarms(data)]; if (resumedReminders.some((x) => x.expired)) persist();
    const p = purgeTrash(data); if (p) { persist(); render(); toast(p + ' item lama dihapus dari tempat sampah.'); cleanupOrphanImages(data).catch(() => {}); }
    maybeAutoBackup(ctx).catch(() => {});
    refreshDue().catch(() => {}); // Rev 57 (dibatasi 3 jam)
    pullShared(ctx); // Bagikan baru saat aplikasi di latar belakang
    autoSync('kembali');
  }
});

// Tombol Kembali HP / gestur geser. Ditangani NATIVE (MainActivity memanggil window.__kelimaaBack).
// Urutan: tutup dialog (termasuk dialog keluar), tutup editor, tutup lembar tambah/ubah, keluar dari submenu Lainnya.
// Bila sudah di layar utama (Rev 14): tampilkan dialog "Keluar dari aplikasi?" dan balas 'handled' (native TIDAK menutup).
// Aplikasi baru ditutup bila pengguna menekan "Keluar" (exitApp: simpan data, lalu KelimaaNative.exit()).
function handleBack() {
  if (closeViewer()) return 'handled'; // Rev 60 (G4): penampil gambar layar penuh paling atas
  if (closeSheet()) return 'handled'; // Rev 115 (U7a-2a): layar penuh lembar kerja
  if (closeDialog()) return 'handled';
  if (closeEditorMenu()) return 'handled'; // menu ⋮ editor (Rev 25) ditutup dulu sebelum lapisan di bawahnya
  if (closeSelectMenu()) return 'handled'; // menu ⋮ mode pilih (Rev 26)
  const pk = document.querySelector('.ov.pickov');
  if (pk) { pk.remove(); return 'handled'; }
  if (backEditor()) return 'handled';
  if (exitSelect()) return 'handled'; // mode pilih daftar Catatan (Rev 26): Kembali keluar dari mode dulu
  const sheet = document.querySelector('.ov:not(.dlgov)');
  if (sheet) { sheet.remove(); return 'handled'; }
  if (ui.tab === 'ai') { // Rev 223: Pengaturan AI -> kembali ke chat; chat -> kembali ke tab sebelumnya (mengetuk tab di bilah bawah)
    if (ui.moreView === 'ai' && ui.aiFrom === 'chat') { ui.moreView = 'aichat'; ui.aiFrom = ''; render(); return 'handled'; }
    if (ui.moreView === 'aichat') { const t = ui.prevTab && ui.prevTab !== 'ai' ? ui.prevTab : 'catatan', b = document.querySelector('nav button[data-tab="' + t + '"]'); if (b) { b.click(); return 'handled'; } }
  }
  if (ui.tab === 'catatan' && ui.favoritesRoom) { ui.favoritesRoom = false; render(); return 'handled'; }
  if (ui.tab === 'lainnya' && ui.moreView === 'proyek' && ui.projectId) { ui.projectId = ''; render(); return 'handled'; }
  if (ui.tab === 'lainnya' && ui.moreView === 'tpconn') { ui.moreView = 'twopockets'; render(); return 'handled'; } // Rev 64: Sambungan -> ruang TWO POCKETS
  if (ui.tab === 'lainnya' && ui.moreView !== 'main') { ui.moreView = 'main'; render(); return 'handled'; }
  askExitBack(ctx);
  return 'handled';
}
globalThis.__kelimaaBack = handleBack;

// Jalur event dari native: window.onAndroidEvent(event, data). Handler lama dipertahankan dan menerima event lain.
// (MainActivity saat ini memakai jalur tarik __kelimaaBack di atas, jadi jalur ini cadangan/tambahan.)
const prevAndroidEvent = globalThis.onAndroidEvent;
globalThis.onAndroidEvent = function (event, data) {
  if (event === 'backPressed') { handleBack(); return; }
  if (typeof prevAndroidEvent === 'function') return prevAndroidEvent.apply(this, arguments);
};

// Peramban tanpa jembatan native: Kembali ditangkap lewat pushState/popstate. Tidak aktif di aplikasi.
installBrowserBack(handleBack);
