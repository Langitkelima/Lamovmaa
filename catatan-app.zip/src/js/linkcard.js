// Rev 321 / PART L1: mesin Link Card (MURNI: tanpa DOM, jaringan, penyimpanan, atau impor selain logic.js).
// Belum dipanggil UI. Dimuat malas oleh UI Sisipkan > Link (L2); TIDAK boleh diimpor statis dari notes.js/main.js (anggaran jalur buka).
//
// KONTRAK HTML (satu-satunya bentuk yang disimpan; cangkang kosong, isi tampilan dibuat saat render):
//   <div class="lk-card" contenteditable="false" data-u="https://situs.id/jalan" data-t="Judul" data-i="https://.../gambar.jpg" data-s="Nama situs" data-a="c"></div>
//   data-u  WAJIB, alamat http/https sah (maks. 2000 huruf); kartu tanpa data-u sah dibuang.
//   data-t  judul halaman (maks. 140, teks biasa, tanpa karakter kontrol); kosong = tampilan memakai domain.
//   data-i  alamat gambar kecil, HANYA https (maks. 2000); kosong = ikon tautan.
//   data-s  nama situs (maks. 60).
//   data-a  rata kartu: l (bawaan, atribut dihilangkan) | c | r.
import { hostOf, safeImageUrl } from './logic.js';

export const LK_ERR = 'Alamat web tidak sah';
export const LK_MAX_URL = 2000;
export const LK_MAX_T = 140;
export const LK_MAX_S = 60;
const HOST_RE = /^[^.]+(\.[^.]+)*\.[a-z]{2,}$/i; // sama dengan extractUrls: harus ada titik dan akhiran huruf
const CTRL_RE = /[\u0000-\u001f\u007f]/;

// Memeriksa alamat yang ditempel pengguna. Mengembalikan { ok, url, host, error, why }.
// Diterima: https://..., http://..., atau diawali www. (dijadikan https). Ditolak: skema lain (javascript:, data:, file:, ftp:...),
// spasi/karakter kontrol, akun di alamat (https://a.com@b.com), domain tanpa titik/akhiran huruf (localhost, 192.168.0.1), alamat > 2000 huruf.
export function linkCardUrl(input) {
  const bad = (why) => ({ ok: false, url: '', host: '', error: LK_ERR, why });
  let s = String(input ?? '').trim();
  if (!s) return bad('kosong');
  if (s.length > LK_MAX_URL) return bad('panjang');
  if (/\s/.test(s) || CTRL_RE.test(s)) return bad('spasi');
  if (/^www\./i.test(s)) s = 'https://' + s;
  if (!/^https?:\/\//i.test(s)) return bad('skema');
  let p;
  try { p = new URL(s); } catch (_) { return bad('format'); }
  if (p.protocol !== 'https:' && p.protocol !== 'http:') return bad('skema');
  if (p.username || p.password) return bad('akun');
  if (!HOST_RE.test(p.hostname)) return bad('host');
  const url = p.href;
  if (url.length > LK_MAX_URL) return bad('panjang');
  return { ok: true, url, host: hostOf(url), error: '', why: '' };
}

// Kunci pembanding tautan (D5 hibrid: pratinjau lama di bawah isi melewati URL yang sudah dipakai kartu). Tanpa #bagian, tanpa garis miring penutup tunggal, huruf kecil pada domain.
export function linkKey(url) {
  const r = linkCardUrl(url); if (!r.ok) return '';
  const p = new URL(r.url);
  const path = p.pathname === '/' ? '' : p.pathname.replace(/\/+$/, '');
  return p.protocol + '//' + p.host.toLowerCase() + path + p.search;
}
export const sameLink = (a, b) => { const x = linkKey(a); return !!x && x === linkKey(b); };
// Daftar URL yang BELUM dipakai kartu (urutan asli dipertahankan).
export function skipCardUrls(urls, cards) {
  const used = new Set((cards || []).map((c) => linkKey(c && c.u)).filter(Boolean));
  return (urls || []).filter((u) => !used.has(linkKey(u)));
}

const cleanText = (s, max) => String(s ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);

// Mengubah data mentah ({ u, t, i, s, a }) menjadi data bersih, atau null bila alamatnya tidak sah.
export function normalizeLinkCard(o) {
  const src = o && typeof o === 'object' ? o : {};
  const r = linkCardUrl(src.u); if (!r.ok) return null;
  let i = safeImageUrl(src.i); if (i.length > LK_MAX_URL) i = '';
  return { u: r.url, t: cleanText(src.t, LK_MAX_T), i, s: cleanText(src.s, LK_MAX_S), a: /^[cr]$/.test(String(src.a)) ? String(src.a) : 'l' };
}

// Atribut yang disimpan (urutan tetap). Kosong/bawaan tidak ditulis.
export function linkCardAttrs(o) {
  const c = normalizeLinkCard(o); if (!c) return null;
  const a = { class: 'lk-card', contenteditable: 'false', 'data-u': c.u };
  if (c.t) a['data-t'] = c.t;
  if (c.i) a['data-i'] = c.i;
  if (c.s) a['data-s'] = c.s;
  if (c.a !== 'l') a['data-a'] = c.a;
  return a;
}
const escAttr = (v) => String(v).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const unescAttr = (v) => String(v).replace(/&quot;/g, '"').replace(/&#0*39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
export function linkCardHtml(o) {
  const a = linkCardAttrs(o); if (!a) return '';
  return '<div' + Object.keys(a).map((k) => ` ${k}="${escAttr(a[k])}"`).join('') + '></div>';
}

// Predikat untuk sanitize (dipasang di notes.js oleh L2): apakah atribut k=v boleh ada di DIV.lk-card. Nilai akhir tetap dinormalkan lewat sanitizeLinkCardEl.
export function linkCardAttrOk(k, v) {
  v = String(v ?? '');
  switch (k) {
    case 'class': return v === 'lk-card';
    case 'contenteditable': return v === 'false';
    case 'data-u': return linkCardUrl(v).ok;
    case 'data-t': return v.length <= LK_MAX_T && !CTRL_RE.test(v);
    case 'data-s': return v.length <= LK_MAX_S && !CTRL_RE.test(v);
    case 'data-i': return v.length <= LK_MAX_URL && safeImageUrl(v) !== '';
    case 'data-a': return /^[lcr]$/.test(v);
    default: return false;
  }
}

// Membersihkan SATU elemen kartu di DOM (dipanggil sanitize oleh L2): atribut ditulis ulang dari data yang dinormalkan, isi dikosongkan
// (tidak ada anak elemen yang lolos), kartu tanpa alamat sah dibuang. Mengembalikan data bersih atau null.
export function sanitizeLinkCardEl(el) {
  const raw = {}; for (const k of ['u', 't', 'i', 's', 'a']) raw[k] = el.getAttribute('data-' + k);
  const c = normalizeLinkCard(raw);
  if (!c) { el.remove(); return null; }
  for (const a of [...el.attributes]) el.removeAttribute(a.name);
  const attrs = linkCardAttrs(c);
  for (const k of Object.keys(attrs)) el.setAttribute(k, attrs[k]);
  el.replaceChildren();
  return c;
}

// ---- Ekstraksi dari string HTML catatan (tanpa DOM; untuk pencarian, pratinjau daftar, ekspor, cadangan) ----
const CARD_RE = /<div\b[^>]*\bclass\s*=\s*["']lk-card["'][^>]*>\s*<\/div>/gi;
const ATTR_RE = /([a-zA-Z:_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
function readAttrs(tag) {
  const o = {}; ATTR_RE.lastIndex = 0; let m;
  while ((m = ATTR_RE.exec(tag))) o[m[1].toLowerCase()] = unescAttr(m[2] ?? m[3] ?? '');
  return o;
}
const cardFromTag = (tag) => { const a = readAttrs(tag.slice(0, tag.indexOf('>') + 1)); return normalizeLinkCard({ u: a['data-u'], t: a['data-t'], i: a['data-i'], s: a['data-s'], a: a['data-a'] }); };
// Semua kartu sah menurut urutan dokumen (kartu rusak dilewati).
export function parseLinkCards(html) {
  const out = []; for (const m of String(html ?? '').matchAll(CARD_RE)) { const c = cardFromTag(m[0]); if (c) out.push(c); }
  return out;
}
// Mengganti tiap kartu dengan teks buatan fn(kartu); kartu rusak dibuang (diganti kosong).
export function replaceLinkCards(html, fn) {
  return String(html ?? '').replace(CARD_RE, (tag) => { const c = cardFromTag(tag); return c ? String(fn(c)) : ''; });
}

const title = (c) => c.t || c.s || hostOf(c.u);
// Teks untuk pencarian: judul + situs + domain + alamat (satu baris).
export const cardSearchText = (c) => [c.t, c.s, hostOf(c.u), c.u].filter(Boolean).join(' ');
// Teks biasa (TXT/pratinjau daftar): satu baris, judul lalu alamat.
export const cardPlain = (c) => 'Tautan: ' + (c.t ? c.t + ' - ' : '') + c.u;
// Markdown: [judul](alamat); kurung siku di judul dan kurung bulat di alamat di-escape.
export const cardMarkdown = (c) => '[' + title(c).replace(/([\\\[\]])/g, '\\$1') + '](' + c.u.replace(/\(/g, '%28').replace(/\)/g, '%29') + ')';

// Kebijakan Catatan Privat (keputusan pengguna D6, 18 Nov 2026): kartu BOLEH ada di Catatan Privat, tetapi hanya lokal = ikon + domain + panah,
// tanpa mengambil judul/gambar dari internet (alamat + IP perangkat tidak sampai ke situs lain sebelum pengguna sendiri mengetuk untuk mengunjungi).
export const linkCardAllowed = () => true;
export const linkCardFetchAllowed = (kind) => kind !== 'priv'; // pengambilan judul/gambar hanya untuk catatan biasa
export const linkCardForKind = (c, kind) => (c && kind === 'priv' ? { u: c.u, t: '', i: '', s: '', a: c.a } : c); // di privat judul/gambar/situs dibuang
