// Rev 156 / U10c-1: MESIN DIAGRAM lembar kerja (MURNI: tanpa DOM, penyimpanan, native, eval). TANPA UI (U10c-2) dan belum dipanggil modul lain.
// Tugasnya dua: (1) chartData = ambil kolom label + kolom nilai dari satu tab (HASIL rumus + format, lewat makeDisplay), (2) chartSvg = rakit teks SVG berdiri sendiri.
// SVG tidak berisi skrip, gambar luar, atau gaya luar; semua teks diloloskan; semua angka dibatasi. Jenis: 'column' (kolom), 'bar' (batang mendatar), 'donut'.
import { makeDisplay } from './lembar-tampil.js';

export const CHART_KINDS = ['column', 'bar', 'donut'];
export const KIND_LABELS = { column: 'Kolom', bar: 'Batang', donut: 'Donat' };
export const MAX_POINTS = 24, MAX_TITLE = 60, MAX_LABEL = 40;
export const PALETTE = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#14B8A6', '#EC4899', '#84CC16'];
const HEX = /^#[0-9a-fA-F]{6}$/;
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const f2 = (n) => String(Math.round(n * 100) / 100);

// Bersihkan pengaturan diagram mentah -> { kind, title, legend }. Jenis tak dikenal = 'column'.
export function cleanChart(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  return { kind: CHART_KINDS.includes(r.kind) ? r.kind : 'column', title: String(r.title == null ? '' : r.title).replace(/\s+/g, ' ').trim().slice(0, MAX_TITLE), legend: r.legend !== false };
}

// chartData(tab, src, {valueCol, now}) -> { ok, labels[], values[], title, skipped, reason? }
// src = {r1,c1,r2,c2} (indeks). Kolom c1 = label, kolom valueCol (bawaan c1+1; harus di dalam c1..c2) = nilai. Baris pertama dipakai sebagai JUDUL bila labelnya teks dan nilainya BUKAN angka.
// Baris tanpa angka (teks, galat, boolean, kosong) dilewati dan dihitung (skipped); baris tanpa label diberi "Baris n". Maks. MAX_POINTS titik (sisanya dipotong, truncated).
export function chartData(tab, src, opts = {}) {
  const bad = (reason) => ({ ok: false, reason, labels: [], values: [], title: '', skipped: 0, truncated: 0 });
  if (!tab || !Array.isArray(tab.rows) || !Array.isArray(tab.cols) || !src) return bad('rentang');
  const { r1, c1, r2, c2 } = src; if (![r1, c1, r2, c2].every(Number.isInteger) || r1 < 0 || c1 < 0 || r2 < r1 || c2 < c1 || r2 >= tab.rows.length || c2 >= tab.cols.length) return bad('rentang');
  const vc = Number.isInteger(opts.valueCol) ? opts.valueCol : c1 + 1; if (vc < c1 || vc > c2 || vc === c1) return bad('kolom');
  const d = makeDisplay(tab, opts); let start = r1, title = '';
  const l0 = d.raw(r1, c1), v0 = d.raw(r1, vc);
  if (typeof l0 === 'string' && l0 !== '' && !isNum(v0) && r2 > r1) { title = d.text(r1, vc) || l0; start = r1 + 1; }
  const labels = [], values = []; let skipped = 0, truncated = 0;
  for (let i = start; i <= r2; i++) {
    const v = d.raw(i, vc); if (!isNum(v)) { if (d.has(i, c1) || d.has(i, vc)) skipped++; continue; }
    if (values.length >= MAX_POINTS) { truncated++; continue; }
    const lab = d.text(i, c1).replace(/\s+/g, ' ').trim().slice(0, MAX_LABEL); labels.push(lab || 'Baris ' + (i + 1)); values.push(v);
  }
  if (!values.length) return { ...bad('kosong'), skipped, title };
  return { ok: true, labels, values, title, skipped, truncated };
}

export const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
const cut = (s, n) => { const t = String(s); return t.length > n ? t.slice(0, Math.max(1, n - 1)) + '\u2026' : t; };
// Angka ringkas Indonesia: 1500 -> "1,5 rb", 2000000 -> "2 jt", 3e9 -> "3 M".
export function compact(n) {
  if (!isNum(n)) return ''; const a = Math.abs(n), sg = n < 0 ? '\u2212' : '';
  const one = (x, u) => sg + String(Math.round(x * 10) / 10).replace('.', ',') + (u ? ' ' + u : '');
  if (a >= 1e9) return one(a / 1e9, 'M'); if (a >= 1e6) return one(a / 1e6, 'jt'); if (a >= 1e4) return one(a / 1e3, 'rb');
  return sg + String(Math.round(a * 100) / 100).replace('.', ',');
}
// Skala "rapi": batas bawah/atas dan langkah (3-6 garis), selalu memuat 0.
export function niceScale(min, max, want = 4) {
  let lo = Math.min(0, min), hi = Math.max(0, max); if (lo === hi) hi = lo + 1;
  const raw = (hi - lo) / want, p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p, m = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10, step = m * p;
  lo = Math.floor(lo / step + 1e-9) * step; hi = Math.ceil(hi / step - 1e-9) * step; const ticks = [];
  for (let t = lo, k = 0; t <= hi + step / 1000 && k < 40; t += step, k++) ticks.push(Math.round(t / step) * step);
  return { lo, hi, step, ticks };
}
const theme = (t) => { const o = t && typeof t === 'object' ? t : {}; return { ink: HEX.test(o.ink || '') ? o.ink : '#1F2937', mut: HEX.test(o.mut || '') ? o.mut : '#6B7280', grid: HEX.test(o.grid || '') ? o.grid : '#D1D5DB', bg: HEX.test(o.bg || '') ? o.bg : '' }; };
const head = (w, h, label, bg) => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '" role="img" aria-label="' + esc(label) + '" font-family="sans-serif">' + '<title>' + esc(label) + '</title>' + (bg ? '<rect width="' + w + '" height="' + h + '" fill="' + bg + '"/>' : '');
const txt = (x, y, s, o = {}) => '<text x="' + f2(x) + '" y="' + f2(y) + '" font-size="' + (o.size || 11) + '" fill="' + o.fill + '"' + (o.anchor ? ' text-anchor="' + o.anchor + '"' : '') + (o.bold ? ' font-weight="700"' : '') + '>' + esc(s) + '</text>';

// chartSvg(data, {kind, title, legend, width, height, theme}) -> { ok, svg, w, h, reason? }. data = hasil chartData (ok).
export function chartSvg(data, opts = {}) {
  if (!data || !data.ok || !Array.isArray(data.values) || !data.values.length) return { ok: false, svg: '', w: 0, h: 0, reason: 'kosong' };
  const c = cleanChart(opts), th = theme(opts.theme), title = c.title || data.title || '';
  const W = clamp(Math.floor(Number(opts.width)) || 360, 200, 1200); const n = data.values.length, ticks0 = title ? 30 : 12;
  const label = (KIND_LABELS[c.kind] || 'Diagram') + (title ? ': ' + title : '') + ', ' + n + ' data';
  const titleEl = title ? txt(W / 2, 20, cut(title, 44), { size: 14, fill: th.ink, anchor: 'middle', bold: true }) : '';
  if (c.kind === 'donut') {
    const pos = data.values.map((v, i) => ({ v, i })).filter((x) => x.v > 0), total = pos.reduce((a, x) => a + x.v, 0);
    if (!pos.length) return { ok: false, svg: '', w: 0, h: 0, reason: 'tak-positif' };
    const R = Math.min(W / 2 - 16, 90), cx = W / 2, cy = ticks0 + R + 4, r = R * 0.58, rowH = 18, legendRows = c.legend ? pos.length : 0, H = Math.ceil(cy + R + 14 + legendRows * rowH + 4);
    let a0 = -Math.PI / 2, body = ''; const pt = (rad, ang) => f2(cx + rad * Math.cos(ang)) + ' ' + f2(cy + rad * Math.sin(ang));
    pos.forEach((x, k) => {
      const frac = x.v / total, color = PALETTE[x.i % PALETTE.length];
      if (frac >= 0.9999) { body += '<circle cx="' + f2(cx) + '" cy="' + f2(cy) + '" r="' + f2((R + r) / 2) + '" fill="none" stroke="' + color + '" stroke-width="' + f2(R - r) + '"/>'; return; }
      const a1 = a0 + frac * Math.PI * 2, big = a1 - a0 > Math.PI ? 1 : 0;
      body += '<path d="M' + pt(R, a0) + ' A' + f2(R) + ' ' + f2(R) + ' 0 ' + big + ' 1 ' + pt(R, a1) + ' L' + pt(r, a1) + ' A' + f2(r) + ' ' + f2(r) + ' 0 ' + big + ' 0 ' + pt(r, a0) + ' Z" fill="' + color + '" stroke="' + (th.bg || '#FFFFFF') + '" stroke-width="1"/>'; a0 = a1;
    });
    body += txt(cx, cy + 5, compact(total), { size: 14, fill: th.ink, anchor: 'middle', bold: true });
    if (c.legend) pos.forEach((x, k) => { const y = cy + R + 20 + k * rowH; body += '<rect x="' + f2(W / 2 - 100) + '" y="' + f2(y - 9) + '" width="10" height="10" rx="2" fill="' + PALETTE[x.i % PALETTE.length] + '"/>' + txt(W / 2 - 84, y, cut(data.labels[x.i], 20) + ' \u00b7 ' + Math.round(x.v / total * 100) + '%', { size: 11, fill: th.ink }); });
    return { ok: true, svg: head(W, H, label, th.bg) + titleEl + body + '</svg>', w: W, h: H };
  }
  const vals = data.values, sc = niceScale(Math.min(...vals), Math.max(...vals));
  if (c.kind === 'bar') {
    const lw = Math.min(110, Math.max(40, Math.max(...data.labels.map((s) => Math.min(s.length, 14))) * 6.2)), L = lw + 8, Rm = 16, T = ticks0, rowH = 26, plotH = n * rowH, B = 26, H = Math.ceil(T + plotH + B), pw = W - L - Rm;
    const X = (v) => L + (v - sc.lo) / (sc.hi - sc.lo) * pw; let body = '';
    sc.ticks.forEach((t) => { body += '<line x1="' + f2(X(t)) + '" y1="' + T + '" x2="' + f2(X(t)) + '" y2="' + (T + plotH) + '" stroke="' + th.grid + '" stroke-width="1"/>' + txt(X(t), T + plotH + 16, compact(t), { size: 10, fill: th.mut, anchor: 'middle' }); });
    vals.forEach((v, i) => { const y = T + i * rowH + 4, x0 = X(Math.min(0, v)), x1 = X(Math.max(0, v)); body += '<rect x="' + f2(x0) + '" y="' + y + '" width="' + f2(Math.max(1, x1 - x0)) + '" height="' + (rowH - 8) + '" rx="2" fill="' + PALETTE[0] + '"/>' + txt(L - 6, y + 12, cut(data.labels[i], 14), { size: 11, fill: th.ink, anchor: 'end' }); });
    body += '<line x1="' + f2(X(0)) + '" y1="' + T + '" x2="' + f2(X(0)) + '" y2="' + (T + plotH) + '" stroke="' + th.mut + '" stroke-width="1"/>';
    return { ok: true, svg: head(W, H, label, th.bg) + titleEl + body + '</svg>', w: W, h: H };
  }
  // column
  const L = 46, Rm = 12, T = ticks0, plotH = 150, B = 46, H = T + plotH + B, pw = W - L - Rm, band = pw / n, bw = Math.max(2, Math.min(40, band * 0.68));
  const Y = (v) => T + plotH - (v - sc.lo) / (sc.hi - sc.lo) * plotH; let body = '';
  sc.ticks.forEach((t) => { body += '<line x1="' + L + '" y1="' + f2(Y(t)) + '" x2="' + (W - Rm) + '" y2="' + f2(Y(t)) + '" stroke="' + th.grid + '" stroke-width="1"/>' + txt(L - 6, Y(t) + 3.5, compact(t), { size: 10, fill: th.mut, anchor: 'end' }); });
  const every = Math.max(1, Math.ceil(n / Math.max(1, Math.floor(pw / 46))));
  vals.forEach((v, i) => { const x = L + i * band + (band - bw) / 2, y0 = Y(Math.max(0, v)), y1 = Y(Math.min(0, v)); body += '<rect x="' + f2(x) + '" y="' + f2(y0) + '" width="' + f2(bw) + '" height="' + f2(Math.max(1, y1 - y0)) + '" rx="2" fill="' + PALETTE[0] + '"/>'; if (i % every === 0) body += txt(x + bw / 2, T + plotH + 16, cut(data.labels[i], 8), { size: 10, fill: th.ink, anchor: 'middle' }); });
  body += '<line x1="' + L + '" y1="' + f2(Y(0)) + '" x2="' + (W - Rm) + '" y2="' + f2(Y(0)) + '" stroke="' + th.mut + '" stroke-width="1"/>';
  return { ok: true, svg: head(W, H, label, th.bg) + titleEl + body + '</svg>', w: W, h: H };
}
