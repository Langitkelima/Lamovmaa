// Bintang jatuh (Rev 39): satu elemen kecil, hanya animasi transform + opacity (ringan), muncul acak jarang
// dan HANYA di tema gelap (CSS: --shootd). Logika pemilihan posisi murni supaya bisa dites di Node.
export const SHOOT_MIN_MS = 14000; // jeda terpendek antar bintang jatuh
export const SHOOT_SPAN_MS = 26000; // ditambah acak 0..26 detik

// rand: fungsi 0..1 (bawaan Math.random). w,h: ukuran layar.
export function shootParams(w, h, rand = Math.random) {
  const right = rand() < 0.5; // arah: turun ke kanan atau ke kiri
  const ang = right ? 18 + rand() * 18 : 144 + rand() * 18; // derajat; 0 = ke kanan, positif = turun
  const left = Math.round(w * (right ? 0.05 + rand() * 0.55 : 0.4 + rand() * 0.55));
  const top = Math.round(h * (0.03 + rand() * 0.35));
  const len = Math.round(Math.min(w, h) * (0.45 + rand() * 0.25));
  return { left, top, ang: Math.round(ang), len, wait: SHOOT_MIN_MS + Math.round(rand() * SHOOT_SPAN_MS) };
}

export function installShootingStars(doc = document, win = window) {
  try {
    if (!doc || !doc.body || doc.getElementById('shoot')) return null;
    const el = doc.createElement('div');
    el.id = 'shoot'; el.className = 'shoot'; el.setAttribute('aria-hidden', 'true');
    doc.body.appendChild(el);
    let timer = 0;
    const reduce = () => { try { return win.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (_) { return false; } };
    const visible = () => { try { return win.getComputedStyle(el).display !== 'none'; } catch (_) { return false; } };
    const schedule = (ms) => { clearTimeout(timer); timer = setTimeout(fire, ms); };
    const fire = () => {
      try {
        if (!doc.hidden && !reduce() && visible()) {
          const p = shootParams(win.innerWidth || 360, win.innerHeight || 800);
          el.style.left = p.left + 'px'; el.style.top = p.top + 'px';
          el.style.setProperty('--a', p.ang + 'deg'); el.style.setProperty('--len', p.len + 'px');
          el.classList.remove('go'); void el.offsetWidth; el.classList.add('go');
        }
      } catch (_) { /* abaikan: hiasan saja */ }
      schedule(shootParams(1, 1).wait);
    };
    el.addEventListener('animationend', () => el.classList.remove('go'));
    schedule(6000 + Math.round(Math.random() * 6000)); // yang pertama agak cepat, lalu jarang
    return { el, fire };
  } catch (_) { return null; }
}

// Rev 75: kunci tinggi latar. Saat keyboard muncul, WebView mengecil (adjustResize) dan gradasi latar yang berukuran persen
// ikut mengecil, lalu melar lagi saat keyboard turun (kesan "tertarik"). --skyh = tinggi layar PENUH terbesar yang pernah terlihat
// (reset bila lebar berubah, mis. diputar), dipakai CSS sebagai tinggi tetap gambar latar.
export function skyHeight(prevH, prevW, h, w) {
  const hh = Number(h) || 0, ww = Number(w) || 0;
  if (hh <= 0) return { h: prevH || 0, w: prevW || ww };
  if (!prevH || ww !== prevW) return { h: hh, w: ww };
  return { h: Math.max(prevH, hh), w: ww };
}

export function installSkyLock(doc = document, win = window) {
  try {
    if (!doc || !doc.documentElement) return null;
    let st = { h: 0, w: 0 };
    const apply = () => {
      try {
        st = skyHeight(st.h, st.w, win.innerHeight, win.innerWidth);
        if (st.h > 0) doc.documentElement.style.setProperty('--skyh', st.h + 'px');
      } catch (_) { /* hiasan saja */ }
    };
    apply();
    win.addEventListener('resize', apply);
    return { apply };
  } catch (_) { return null; }
}
