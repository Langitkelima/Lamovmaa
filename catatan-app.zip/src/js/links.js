// Pratinjau tautan (gambar kecil + judul). Satu-satunya bagian aplikasi yang memakai internet, dan hanya
// saat ada tautan di catatan. Tanpa internet, kartu tetap tampil (alamat situs saja) dan aplikasi tetap jalan.
import { isNative, nativePlugin } from './native.js';
import { parsePreview, hostOf } from './logic.js';

const UA = 'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';
const MAX_HTML = 400000;
const TIMEOUT = 8000;

async function getHtml(url) {
  if (isNative()) {
    // Lewat jaringan native (CapacitorHttp bawaan) supaya tidak terhalang aturan CORS peramban.
    const r = await nativePlugin('CapacitorHttp').request({
      url, method: 'GET', responseType: 'text', connectTimeout: TIMEOUT, readTimeout: TIMEOUT,
      headers: { 'User-Agent': UA, Accept: 'text/html,application/xhtml+xml', 'Accept-Language': 'id,en;q=0.8' },
    });
    if (!r || r.status < 200 || r.status >= 400) throw new Error('HTTP ' + (r && r.status));
    return typeof r.data === 'string' ? r.data.slice(0, MAX_HTML) : '';
  }
  const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), TIMEOUT);
  try {
    const r = await fetch(url, { signal: ctl.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return (await r.text()).slice(0, MAX_HTML);
  } finally { clearTimeout(tm); }
}

// Mengembalikan { t: judul, i: alamat gambar (https) atau '', s: nama situs, at: waktu }. Melempar error jika gagal.
export async function fetchPreview(url, get = getHtml) {
  const tries = /^http:/i.test(url) ? [url.replace(/^http:/i, 'https:'), url] : [url];
  let last = new Error('tidak ada percobaan');
  for (const u of tries) {
    try {
      const p = parsePreview(await get(u), u);
      return { t: p.t, i: p.i, s: p.s || hostOf(u), at: Date.now() };
    } catch (e) { last = e; }
  }
  throw last;
}

// Membuka tautan di peramban HP (bukan di dalam aplikasi). Hanya http/https.
export function openExternal(url, g = globalThis) {
  if (!/^https?:\/\//i.test(String(url))) return false;
  const N = g.KelimaaNative;
  if (N && typeof N.openUrl === 'function') {
    try { N.openUrl(url); return true; } catch (e) { console.error('buka tautan gagal:', e); }
  }
  try { return !!(g.open && g.open(url, '_blank', 'noopener')); } catch (e) { console.error('buka tautan gagal:', e); return false; }
}
