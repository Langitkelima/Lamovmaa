// Rev 305 / T6: kelompok templat "Centang" (data murni, tanpa impor): KOTAK CENTANG dicampur RUMUS. Bentuk: lihat lembar-templat.js.
// Kotak = aturan { k: 'box', rg } (Rev 303) + nilai sel boolean true/false. Rumus membaca kotaknya langsung: COUNTIF(A2:A30;TRUE), SUMIF(A2:A30;TRUE;C2:C30), IF(A2;...), AND/OR/NOT.
const RED = { bg: '#FEE2E2', fg: '#991B1B' }, GRN = { bg: '#DCFCE7', fg: '#166534' }, YEL = { bg: '#FEF9C3', fg: '#854D0E' };
const day = (n) => ({ v: { today: n }, nf: 'date' });
const INP = { s: { bg: '#FEF9C3', fg: '#111827' } }; // kotak isian (kuning muda)
const inp = (v, nf) => ({ v, ...INP, ...(nf ? { nf } : {}) });
const lbl = (v) => ({ v, t: true }); // label ringkasan (gaya total)
const pad = (row, n) => { const r = row.slice(); while (r.length < n) r.push(''); return r; };

// ---- Daftar tugas: Status, kemajuan, dan biaya mengikuti kotak centang
const TUGAS_DATA = [
  [true, 'Siapkan laporan bulanan', 250000, -6], [true, 'Pesan konsumsi rapat', 400000, -3], [false, 'Cetak undangan', 150000, -2],
  [false, 'Booking ruangan', 0, 3], [true, 'Hubungi pembicara', 0, -1], [false, 'Siapkan materi presentasi', 75000, 5], [false, 'Kirim notulen', 0, 9],
];
const TUGAS_SUM = [
  [lbl('Jumlah tugas'), { v: '=COUNTA(B2:B30)', t: true, nf: 'num' }],
  ['Sudah selesai', { v: '=COUNTIF(A2:A30;TRUE)', nf: 'num' }],
  ['Belum selesai', { v: '=H2-H3', nf: 'num' }],
  ['Kemajuan', { v: '=IF(H2=0;0;H3/H2)', nf: 'pct' }],
  ['Biaya selesai', { v: '=SUMIF(A2:A30;TRUE;C2:C30)', nf: 'rp' }],
  ['Biaya tersisa', { v: '=SUM(C2:C30)-H6', nf: 'rp' }],
  ['Terlambat', { v: '=COUNTIF(E2:E30;"Terlambat")', nf: 'num' }],
];
const TUGAS = {
  id: 'centang-tugas', name: 'Centang · Daftar tugas', desc: 'Centang tugas yang selesai; status, kemajuan, dan biaya tersisa ikut dihitung rumus.',
  tab: 'Tugas', w: [64, 180, 96, 92, 96, 24, 120, 104], head: true, nfc: ['', '', 'rp', '', '', '', '', ''],
  rows: [
    ['Selesai', 'Tugas', 'Biaya', 'Tenggat', 'Status', '', 'Ringkasan', ''],
    ...Array.from({ length: 10 }, (_, k) => {
      const r = k + 2, d = TUGAS_DATA[k], st = '=IF(B' + r + '="";"";IF(A' + r + ';"Selesai";IF(D' + r + '<TODAY();"Terlambat";"Berjalan")))';
      const base = d ? [d[0], d[1], d[2], day(d[3]), st] : ['', '', '', '', st];
      return pad(base, 6).concat(TUGAS_SUM[k] ? TUGAS_SUM[k] : []);
    }),
  ],
  rules: [{ c: 'E', op: 'eq', a: 'Selesai', ...GRN }, { c: 'E', op: 'eq', a: 'Terlambat', ...RED }, { c: 'E', op: 'eq', a: 'Berjalan', ...YEL }, { c: 'H', op: 'scale', lo: '#FFFFFF', hi: '#86EFAC' }],
  checks: [{ k: 'box', rg: 'A2:A30' }],
  guide: [
    ['Apa ini?', 'Daftar tugas yang bisa dicentang. Setiap kotak centang bernilai TRUE (tercentang) atau FALSE (kosong), jadi rumus bisa membacanya langsung.'],
    ['Cara pakai', 'Ketuk kotak di kolom Selesai untuk mencentang atau melepas. Ketik tugas baru di baris kosong; Status terisi sendiri.'],
    ['Rumus Status', 'IF(A2;"Selesai";...) memakai kotak sebagai syarat. Belum dicentang dan tenggat sudah lewat = Terlambat, selain itu Berjalan.'],
    ['Rumus Ringkasan', 'COUNTIF(A2:A30;TRUE) menghitung kotak tercentang. SUMIF(A2:A30;TRUE;C2:C30) menjumlah Biaya hanya dari tugas yang selesai.'],
    ['Menambah kotak', 'Ingin kotak di sel lain? Tahan sel > Dropdown > Kotak centang. Tambah juga lewat Lainnya > Validasi data.'],
  ],
};

// ---- Daftar belanja: subtotal, sudah dibeli, sisa anggaran
const BELANJA_DATA = [
  [true, 'Beras (kg)', 5, 14000], [true, 'Minyak goreng (liter)', 2, 18000], [false, 'Telur (kg)', 2, 28000], [false, 'Gula (kg)', 1, 17000],
  [true, 'Sabun cuci (pak)', 1, 22000], [false, 'Sayur bayam (ikat)', 4, 3000], [false, 'Ayam (kg)', 1, 38000],
];
const BELANJA_SUM = [
  [lbl('Anggaran'), inp(300000, 'rp')],
  ['Total daftar', { v: '=SUM(E2:E30)', nf: 'rp' }],
  ['Sudah dibeli', { v: '=SUMIF(A2:A30;TRUE;E2:E30)', nf: 'rp' }],
  ['Belum dibeli', { v: '=H3-H4', nf: 'rp' }],
  ['Sisa anggaran', { v: '=H2-H3', nf: 'rp' }],
  ['Barang dibeli', { v: '=COUNTIF(A2:A30;TRUE)&" dari "&COUNTA(B2:B30)' }],
  ['Status', { v: '=IF(H3>H2;"Melebihi";"Aman")' }],
];
const BELANJA = {
  id: 'centang-belanja', name: 'Centang · Daftar belanja', desc: 'Centang barang yang sudah dibeli; subtotal, sisa belanja, dan sisa anggaran dihitung sendiri.',
  tab: 'Belanja', w: [52, 170, 52, 84, 96, 24, 120, 104], head: true, nfc: ['', '', 'num', 'rp', 'rp', '', '', ''],
  rows: [
    ['Beli', 'Barang', 'Jml', 'Harga', 'Subtotal', '', 'Ringkasan', ''],
    ...Array.from({ length: 10 }, (_, k) => {
      const r = k + 2, d = BELANJA_DATA[k], sub = '=IF(B' + r + '="";"";C' + r + '*D' + r + ')';
      const base = d ? [d[0], d[1], d[2], d[3], sub] : ['', '', '', '', sub];
      return pad(base, 6).concat(BELANJA_SUM[k] ? BELANJA_SUM[k] : []);
    }),
  ],
  rules: [{ c: 'H', op: 'eq', a: 'Aman', ...GRN }, { c: 'H', op: 'eq', a: 'Melebihi', ...RED }],
  checks: [{ k: 'box', rg: 'A2:A30' }],
  guide: [
    ['Apa ini?', 'Daftar belanja dengan kotak centang. Centang barang yang sudah masuk keranjang; total yang sudah dibeli langsung berubah.'],
    ['Kotak kuning', 'Anggaran adalah isian: ganti angkanya. Sisa anggaran dan Status ikut menyesuaikan.'],
    ['Rumus yang dipakai', 'Subtotal = Jml x Harga. Sudah dibeli = SUMIF(A2:A30;TRUE;E2:E30), yaitu jumlah Subtotal yang kotaknya tercentang.'],
    ['Barang dibeli', 'COUNTIF(A2:A30;TRUE) digabung dengan COUNTA(B2:B30) memakai tanda &, hasilnya teks seperti "3 dari 7".'],
  ],
};

// ---- Kehadiran: lima kotak per orang, rumus menghitung hadir, persen, dan upah
const HADIR_NAMA = ['Ani', 'Budi', 'Cici', 'Dedi', 'Eka', 'Fajar'];
const HADIR_POLA = ['11111', '11011', '10110', '11101', '01111', '11000'];
const HADIR = {
  id: 'centang-hadir', name: 'Centang · Hadir dan upah', desc: 'Centang hari hadir tiap orang; jumlah hari, persen, upah, dan keterangan dihitung rumus.',
  tab: 'Hadir', w: [110, 46, 46, 46, 46, 46, 56, 70, 100, 80, 24, 120, 100], head: true, nfc: ['', '', '', '', '', '', 'num', 'pct', 'rp', '', '', '', ''],
  rows: [
    ['Nama', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Hadir', 'Persen', 'Upah', 'Ket', '', 'Upah per hari', inp(120000, 'rp')],
    ...Array.from({ length: 10 }, (_, k) => {
      const r = k + 2, nm = HADIR_NAMA[k] || '', pola = HADIR_POLA[k];
      const kt = pola ? [...pola].map((c) => c === '1') : ['', '', '', '', ''];
      const g = '=IF(A' + r + '="";"";COUNTIF(B' + r + ':F' + r + ';TRUE))';
      return [nm, ...kt, g, '=IF(A' + r + '="";"";G' + r + '/5)', '=IF(A' + r + '="";"";G' + r + '*$M$1)',
        '=IF(A' + r + '="";"";IF(H' + r + '>=0.8;"Baik";IF(H' + r + '>=0.6;"Cukup";"Kurang")))'];
    }),
    [],
    [lbl('Hadir per hari'), ...['B', 'C', 'D', 'E', 'F'].map((c) => ({ v: '=COUNTIF(' + c + '2:' + c + '11;TRUE)', t: true, nf: 'num' })), { v: '=SUM(G2:G11)', t: true, nf: 'num' }, { v: '=IF(COUNTA(A2:A11)=0;0;G13/(COUNTA(A2:A11)*5))', t: true, nf: 'pct' }, { v: '=SUM(I2:I11)', t: true, nf: 'rp' }],
  ],
  total: 12,
  rules: [{ c: 'J', op: 'eq', a: 'Baik', ...GRN }, { c: 'J', op: 'eq', a: 'Cukup', ...YEL }, { c: 'J', op: 'eq', a: 'Kurang', ...RED }, { c: 'H', op: 'scale', lo: '#FFFFFF', hi: '#86EFAC' }],
  checks: [{ k: 'box', rg: 'B2:F11' }],
  guide: [
    ['Apa ini?', 'Absen satu pekan. Satu kotak = satu hari. Centang berarti hadir.'],
    ['Rumus per orang', 'Hadir = COUNTIF(B2:F2;TRUE), Persen = Hadir / 5, Upah = Hadir x Upah per hari (kotak kuning). Ket: 80% ke atas Baik, 60% ke atas Cukup, selain itu Kurang.'],
    ['Baris Hadir per hari', 'COUNTIF(B2:B11;TRUE) menghitung berapa orang hadir tiap hari. Persen di barisnya = kehadiran seluruh tim.'],
    ['Menambah orang', 'Ketik nama di baris kosong sampai baris 11. Kotaknya sudah tersedia; rumus akan terisi sendiri.'],
  ],
};

// ---- Tagihan: Lunas dicentang, denda dan total bayar mengikuti tanggal
const TAGIHAN_DATA = [
  [true, 'Listrik', 450000, -25], [true, 'Internet', 350000, -18], [false, 'Air', 120000, -7], [false, 'Sewa kantor', 2500000, -2],
  [false, 'Asuransi', 800000, 6], [false, 'Cicilan alat', 650000, 12],
];
const TAGIHAN_SUM = [
  [lbl('Denda per telat'), inp(0.02, 'pct')],
  ['Jumlah tagihan', { v: '=COUNTA(B2:B30)', nf: 'num' }],
  ['Sudah lunas', { v: '=COUNTIF(A2:A30;TRUE)', nf: 'num' }],
  ['Belum lunas', { v: '=J3-J4', nf: 'num' }],
  ['Sudah dibayar', { v: '=SUMIF(A2:A30;TRUE;C2:C30)', nf: 'rp' }],
  ['Harus dibayar', { v: '=SUM(G2:G30)', nf: 'rp' }],
  ['Denda berjalan', { v: '=SUM(F2:F30)', nf: 'rp' }],
];
const TAGIHAN = {
  id: 'centang-tagihan', name: 'Centang · Tagihan dan denda', desc: 'Centang tagihan yang lunas; telat hari, denda, dan sisa yang harus dibayar dihitung sendiri.',
  tab: 'Tagihan', w: [56, 130, 100, 92, 70, 84, 104, 24, 120, 100], head: true, nfc: ['', '', 'rp', '', 'num', 'rp', 'rp', '', '', ''],
  rows: [
    ['Lunas', 'Tagihan', 'Nominal', 'Jatuh tempo', 'Telat', 'Denda', 'Harus bayar', '', 'Ringkasan', ''],
    ...Array.from({ length: 10 }, (_, k) => {
      const r = k + 2, d = TAGIHAN_DATA[k];
      const tl = '=IF(B' + r + '="";"";IF(A' + r + ';0;MAX(0;TODAY()-D' + r + ')))';
      const dn = '=IF(B' + r + '="";"";IF(E' + r + '>0;ROUND(C' + r + '*$J$2;0);0))';
      const hb = '=IF(B' + r + '="";"";IF(A' + r + ';0;C' + r + '+F' + r + '))';
      const base = d ? [d[0], d[1], d[2], day(d[3]), tl, dn, hb] : ['', '', '', '', tl, dn, hb];
      return pad(base, 8).concat(TAGIHAN_SUM[k] ? TAGIHAN_SUM[k] : []);
    }),
  ],
  rules: [{ c: 'E', op: 'gt', a: 0, ...RED }, { c: 'F', op: 'gt', a: 0, ...YEL }, { c: 'G', op: 'scale', lo: '#FFFFFF', hi: '#FCA5A5' }],
  checks: [{ k: 'box', rg: 'A2:A30' }],
  guide: [
    ['Apa ini?', 'Pantau tagihan rutin. Centang kolom Lunas begitu tagihan dibayar.'],
    ['Telat dan denda', 'Telat = hari lewat jatuh tempo (0 bila sudah lunas). Denda = Nominal x Denda per telat (kotak kuning) bila Telat lebih dari 0.'],
    ['Harus bayar', 'IF(A2;0;...) mengosongkan kewajiban bila kotak dicentang. Jika belum lunas, hasilnya Nominal + Denda.'],
    ['Ringkasan', 'Sudah dibayar memakai SUMIF(A2:A30;TRUE;C2:C30). Harus dibayar menjumlah kolom Harus bayar, jadi turun saat kotak dicentang.'],
  ],
};

// ---- Persiapan acara: tiap pekerjaan punya bobot, kemajuan = bobot yang tercentang / total bobot
const ACARA_DATA = [
  [true, 'Tentukan tanggal dan tempat', 10, 'Ani'], [true, 'Kirim undangan', 10, 'Budi'], [true, 'Pesan konsumsi', 15, 'Cici'], [false, 'Sewa sound system', 15, 'Dedi'],
  [false, 'Siapkan susunan acara', 20, 'Eka'], [false, 'Latihan pembawa acara', 10, 'Ani'], [false, 'Dekorasi ruangan', 20, 'Budi'],
];
const ACARA_SUM = [
  [lbl('Total bobot'), { v: '=SUM(C2:C30)', t: true, nf: 'num' }],
  ['Bobot selesai', { v: '=SUMIF(A2:A30;TRUE;C2:C30)', nf: 'num' }],
  ['Kemajuan', { v: '=IF(H2=0;0;H3/H2)', nf: 'pct' }],
  ['Tugas siap', { v: '=COUNTIF(A2:A30;TRUE)&" dari "&COUNTA(B2:B30)' }],
  ['Status', { v: '=IF(H4>=1;"SIAP";IF(H4>=0.5;"Separuh jalan";"Baru mulai"))' }],
  ['Tugas Ani siap', { v: '=COUNTIFS(D2:D30;"Ani";A2:A30;TRUE)', nf: 'num' }],
  ['Tugas Ani sisa', { v: '=COUNTIFS(D2:D30;"Ani";A2:A30;FALSE)', nf: 'num' }],
];
const ACARA = {
  id: 'centang-acara', name: 'Centang · Persiapan acara', desc: 'Centang persiapan yang selesai; kemajuan berbobot dan status acara dihitung rumus.',
  tab: 'Acara', w: [52, 190, 56, 84, 24, 24, 130, 104], head: true, nfc: ['', '', 'num', '', '', '', '', ''],
  rows: [
    ['Siap', 'Persiapan', 'Bobot', 'PJ', '', '', 'Ringkasan', ''],
    ...Array.from({ length: 10 }, (_, k) => {
      const d = ACARA_DATA[k], base = d ? [d[0], d[1], d[2], d[3]] : ['', '', '', ''];
      return pad(base, 6).concat(ACARA_SUM[k] ? ACARA_SUM[k] : []);
    }),
  ],
  rules: [{ c: 'H', op: 'eq', a: 'SIAP', ...GRN }, { c: 'H', op: 'eq', a: 'Separuh jalan', ...YEL }, { c: 'H', op: 'eq', a: 'Baru mulai', ...RED }],
  checks: [{ k: 'box', rg: 'A2:A30' }, { k: 'list', rg: 'D2:D30', items: ['Ani', 'Budi', 'Cici', 'Dedi', 'Eka'] }],
  guide: [
    ['Apa ini?', 'Persiapan acara dengan bobot. Pekerjaan besar menyumbang lebih banyak ke kemajuan daripada pekerjaan kecil.'],
    ['Kemajuan berbobot', 'Bobot selesai = SUMIF(A2:A30;TRUE;C2:C30), lalu dibagi Total bobot. Centang satu kotak dan persennya naik sebesar bobot barisnya.'],
    ['Status', 'Kemajuan 100% = SIAP, 50% ke atas = Separuh jalan, selain itu Baru mulai. Warnanya berganti sendiri.'],
    ['Tugas per orang', 'COUNTIFS(D2:D30;"Ani";A2:A30;TRUE) menghitung dua syarat sekaligus: PJ-nya Ani dan kotaknya tercentang. Ganti "Ani" dengan nama lain.'],
  ],
};

export const CENTANG = [TUGAS, BELANJA, HADIR, TAGIHAN, ACARA];
