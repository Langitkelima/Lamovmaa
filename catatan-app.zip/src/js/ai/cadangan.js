// Rev 228 / Kelimaa AI butir 5: CADANGAN dan PEMULIHAN riwayat percakapan AI (tombol terpisah, keputusan 27.9 butir 8). Riwayat TIDAK ikut cadangan data aplikasi (disimpan di berkas, bukan localStorage).
// Bagian murni (tanpa DOM, tanpa plugin): buildBackup, parseBackup, mergeRestore, backupName. Bagian berkas: saveBackupFile. Hanya teks percakapan; TIDAK ada isi catatan/tugas/Catatan Privat, TIDAK ada alamat Worker/passcode.
// Pemulihan hanya MENAMBAH ruang baru (id baru, nama dibuat unik); riwayat yang sedang ada tidak pernah dihapus atau ditimpa.
import * as R from './ruang.js';
import { isNative, nativePlugin } from '../native.js';

export const APP_ID = 'kelimaa-ai-riwayat', FILE_MAX = 5 * 1024 * 1024;
const p2 = (n) => String(n).padStart(2, '0');
export const backupName = (d = new Date()) => 'riwayat-ai-' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes()) + '.json';

// rooms: [{id, name, task, at, msgs}] -> teks JSON. Ruang tanpa pesan tidak dimasukkan.
export function buildBackup(rooms, now = Date.now()) {
  const list = [], msgs = {};
  for (const r of rooms) { const m = R.normMsgs(r.msgs); if (!m.length || !R.ID_RE.test(String(r.id))) continue; list.push({ id: r.id, name: r.name, task: r.task, at: r.at }); msgs[r.id] = m; }
  return JSON.stringify({ app: APP_ID, v: 1, at: now, idx: { v: 1, active: list.length ? list[0].id : '', list }, msgs });
}
// Teks berkas -> {ok, rooms:[{name,task,at,msgs}], count, msgCount} atau {ok:false,msg}. Semua isi divalidasi ulang (normIndex/normMsgs).
export function parseBackup(text) {
  if (typeof text !== 'string' || !text.trim()) return { ok: false, msg: 'Berkas kosong.' };
  if (text.length > FILE_MAX) return { ok: false, msg: 'Berkas terlalu besar.' };
  let o; try { o = JSON.parse(text); } catch (e) { return { ok: false, msg: 'Bukan berkas cadangan riwayat AI.' }; }
  if (!o || typeof o !== 'object' || o.app !== APP_ID || !o.idx || !o.msgs || typeof o.msgs !== 'object') return { ok: false, msg: 'Bukan berkas cadangan riwayat AI.' };
  const src = Array.isArray(o.idx.list) ? o.idx.list : [], rooms = []; let msgCount = 0;
  for (const w of R.normIndex({ list: src, active: o.idx.active }).list) {
    if (!src.some((x) => x && x.id === w.id)) continue; // normIndex menambah ruang bawaan bila kosong: jangan ikut
    const m = R.normMsgs(o.msgs[w.id]); if (!m.length) continue;
    rooms.push({ name: w.name, task: w.task, at: w.at, msgs: m }); msgCount += m.length;
  }
  if (!rooms.length) return { ok: false, msg: 'Tidak ada percakapan di berkas ini.' };
  return { ok: true, rooms, count: rooms.length, msgCount };
}
// Tambahkan ruang hasil parse ke indeks yang ada (id baru, nama unik, batas MAX_WS). -> {idx, added:[{id,msgs}], skipped}
export function mergeRestore(idx, rooms, now = Date.now(), rnd = Math.random) {
  let cur = idx; const added = []; let skipped = 0;
  for (const r of rooms) {
    if (cur.list.length >= R.MAX_WS) { skipped++; continue; }
    let id = R.newId(now, rnd); while (cur.list.some((w) => w.id === id)) id = R.newId(now, rnd);
    cur = { ...cur, list: [...cur.list, { id, name: R.uniqueName(cur, r.name), task: r.task, at: r.at }] }; added.push({ id, msgs: r.msgs });
  }
  return { idx: cur, added, skipped };
}

// ---- Berkas. Di HP: tulis ke CACHE lalu menu Bagikan Android (pola sama dengan ekspor cadangan data). Di peramban: unduh.
export async function saveBackupFile(name, text) {
  if (isNative()) {
    const FS = nativePlugin('Filesystem'), SH = nativePlugin('Share');
    const r = await FS.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
    await SH.share({ title: 'Cadangan riwayat Kelimaa AI', files: [r.uri], dialogTitle: 'Simpan cadangan riwayat' });
    setTimeout(() => { FS.deleteFile({ path: name, directory: 'CACHE' }).catch(() => {}); }, 120000);
    return;
  }
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' })), a = document.createElement('a');
  a.href = url; a.download = name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 10000);
}
// Pilih berkas JSON -> teks (null bila batal). Melempar galat bila gagal baca.
export function pickBackupText() {
  return new Promise((resolve, reject) => {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'application/json,.json';
    inp.onchange = () => { const f = inp.files && inp.files[0]; if (!f) { resolve(null); return; } if (f.size > FILE_MAX) { reject(new Error('Berkas terlalu besar.')); return; } f.text().then(resolve, reject); };
    inp.click();
  });
}
