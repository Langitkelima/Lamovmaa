// Rev 306a / Kelimaa AI LAMPIRAN CATATAN: bagian kecil TANPA impor apa pun, supaya ruang.js (riwayat) bisa menyimpan rujukan lampiran tanpa menarik modul lain.
// Yang tersimpan di riwayat hanya {id, judul} (TANPA isi catatan). Mesin lengkap ada di lampiran.js, yang mengekspor ulang semuanya.
export const ATT_MAX_NOTES = 5;      // catatan per pesan
export const TITLE_SHOW = 80;
export const ID_RE = /^[\w.-]{1,64}$/;
const one = (s, n) => { const t = String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1).trimEnd() + '\u2026' : t; };
// -> [{id,title}] maks. ATT_MAX_NOTES; kembar, id aneh, dan semua kolom lain (mis. isi) dibuang
export function cleanAtt(raw) {
  const out = [], seen = new Set();
  for (const x of Array.isArray(raw) ? raw : []) {
    if (!x || typeof x !== 'object' || !ID_RE.test(String(x.id)) || seen.has(String(x.id))) continue;
    seen.add(String(x.id)); out.push({ id: String(x.id), title: one(x.title, TITLE_SHOW) || 'Tanpa judul' }); if (out.length >= ATT_MAX_NOTES) break;
  }
  return out;
}
