// Rev 237 / Kelimaa AI Tahap 8a: INSIGHT MINGGUAN (logika murni, tanpa DOM, tanpa jaringan). Ringkasan dihitung di HP dari `data.tasks`, `data.notes` (HANYA waktu ubah, bukan isi/judul) dan `data.projects`.
// Rev 239 / 8b-2: tren dari `doneAt` tugas dan `habitLog` (hanya hitungan; tanpa judul tugas dan tanpa nama kebiasaan). Tidak membaca Catatan Privat, sampah, nama kebiasaan, atau lembar kerja. Tidak mengirim apa pun sendiri: teks hanya ditampilkan, dan baru masuk ke kolom pesan chat bila pengguna menekan tombolnya (lalu masih bisa diedit sebelum dikirim).
import { projectProgress } from '../proyek-alat.js';
export const INSIGHT_MAX = 1500, INSIGHT_ITEMS = 5, DAY = 86400000;
const p2 = (n) => String(n).padStart(2, '0');
const isoOf = (t) => { const d = new Date(t); return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); };
const clean = (v, n = 50) => { const t = String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1).trimEnd() + '\u2026' : t; };
const arr = (x) => (Array.isArray(x) ? x : []);
export function buildInsight(data, now = Date.now()) {
  const today = isoOf(now), soonTo = isoOf(now + 7 * DAY), d0 = new Date(now); d0.setHours(0, 0, 0, 0);
  const start = d0.getTime(), tasks = arr(data && data.tasks).filter((t) => t && !t.done && clean(t.title));
  const dueOf = (t) => (/^\d{4}-\d{2}-\d{2}$/.test(String(t.due || '')) ? t.due : '');
  const late = tasks.filter((t) => dueOf(t) && dueOf(t) < today), soon = tasks.filter((t) => dueOf(t) && dueOf(t) >= today && dueOf(t) <= soonTo), imp = tasks.filter((t) => t.pri === 1);
  const weekAgo = now - 7 * DAY, notes = arr(data && data.notes).filter((n) => n && (n.updated || 0) >= weekAgo && (n.updated || 0) <= now + DAY).length;
  const projs = arr(data && data.projects).filter((p) => p && p.status === 'aktif' && clean(p.name));
  const pLate = projs.filter((p) => p.due && p.due < start), pSoon = projs.filter((p) => p.due && p.due >= start && p.due <= start + 14 * DAY);
  const stats = { open: tasks.length, late: late.length, soon: soon.length, important: imp.length, notesWeek: notes, projects: projs.length, projLate: pLate.length, projSoon: pSoon.length };
  const all = arr(data && data.tasks).filter((t) => t && t.done === true && t.doneAt > 0); // Rev 239 / 8b-2: tren (hanya hitungan, tanpa judul)
  const dn = (a, b) => all.filter((t) => t.doneAt >= a && t.doneAt < b).length, doneWeek = dn(weekAgo, now + DAY), donePrev = dn(now - 14 * DAY, weekAgo);
  const i7 = isoOf(weekAgo), i14 = isoOf(now - 14 * DAY), hl = arr(data && data.habitLog).filter((x) => x && /^\d{4}-\d{2}-\d{2}$/.test(String(x.d)) && x.total > 0 && x.done >= 0 && x.done <= x.total);
  const hw = (a, b) => { const r = hl.filter((x) => x.d > a && x.d <= b), tot = r.reduce((n, x) => n + x.total, 0); return { days: r.length, pct: tot ? Math.round((r.reduce((n, x) => n + x.done, 0) / tot) * 100) : null }; };
  const hc = hw(i7, today), hp = hw(i14, i7), trend = { doneWeek, donePrev, hasDone: all.length > 0, habitPct: hc.pct, habitDays: hc.days, habitPctPrev: hp.pct, habitDaysPrev: hp.days };
  const cmp = (a, b, u) => (a > b ? ', naik ' + (a - b) + u : a < b ? ', turun ' + (b - a) + u : ', sama');
  const trendLines = [trend.hasDone ? 'Tugas selesai 7 hari terakhir: ' + doneWeek + ' (minggu sebelumnya: ' + donePrev + cmp(doneWeek, donePrev, '') + ')' : 'Tugas selesai: belum ada data (waktu selesai baru dicatat sejak pembaruan ini)',
    hc.days ? 'Kebiasaan 7 hari terakhir: ' + hc.pct + '% terpenuhi dari ' + hc.days + ' hari tercatat' + (hp.days ? ' (minggu sebelumnya: ' + hp.pct + '%' + cmp(hc.pct, hp.pct, ' poin') + ')' : '') : 'Kebiasaan: belum ada riwayat harian (mulai tercatat sejak pembaruan ini)'];
  const lines = ['Tugas belum selesai: ' + stats.open + (stats.open ? ' (' + stats.late + ' terlambat, ' + stats.soon + ' jatuh tempo 7 hari ke depan, ' + stats.important + ' penting)' : ''), 'Catatan diubah 7 hari terakhir: ' + notes, 'Proyek aktif: ' + projs.length + (projs.length ? ' (' + pLate.length + ' lewat tenggat, ' + pSoon.length + ' tenggat dalam 14 hari)' : '')];
  lines.push(...trendLines);
  const byDue = (a, b) => (dueOf(a) < dueOf(b) ? -1 : dueOf(a) > dueOf(b) ? 1 : 0);
  const urgent = late.slice().sort(byDue).concat(soon.slice().sort(byDue)).slice(0, INSIGHT_ITEMS);
  if (urgent.length) { lines.push('Perlu perhatian:'); for (const t of urgent) lines.push('- ' + clean(t.title) + ', tenggat ' + dueOf(t) + (dueOf(t) < today ? ' (terlambat)' : '')); }
  const pl = projs.slice().sort((a, b) => (b.at || 0) - (a.at || 0)).slice(0, INSIGHT_ITEMS);
  if (pl.length) { lines.push('Proyek:'); for (const p of pl) { const pr = projectProgress(data, p); lines.push('- ' + clean(p.name) + ', ' + (pr.total ? pr.done + ' dari ' + pr.total + ' tugas selesai' : 'belum ada tugas tertaut') + (p.due ? ', tenggat ' + isoOf(p.due) : '')); } }
  let text = '[Ringkasan data aplikasi per ' + today + ', dihitung di HP]\n' + lines.join('\n');
  if (text.length > INSIGHT_MAX) text = text.slice(0, INSIGHT_MAX - 1).replace(/\s+\S*$/, '') + '\u2026';
  return { stats, trend, lines, text, empty: !stats.open && !notes && !projs.length && !trend.hasDone && !hc.days };
}
// Isi kolom pesan chat: instruksi + ringkasan. Selalu <= `max` huruf (batas pesan Worker).
export function insightPrompt(text, max = 4000) {
  const head = 'Dari ringkasan berikut, beri 3 saran prioritas untuk minggu ini dan satu hal yang berisiko terlewat. Komentari tren bila datanya ada. Jawab singkat dalam bahasa Indonesia.\n\n';
  const body = String(text || ''); const room = max - head.length; return head + (body.length > room ? body.slice(0, Math.max(0, room - 1)) + '\u2026' : body);
}
