// Rev 309b: isi tab "Riwayat token" di dialog Data aplikasi untuk AI. Membaca riwayat (riwayat-token.js), TIDAK menyentuh data catatan/tugas.
// Ringkasan (hari ini, 7 hari, bulan ini), grafik batang 7 hari, log per pesan dikelompokkan per hari, tombol Hapus riwayat. Angka perkiraan diberi tanda \u2248.
import { h, ico, dlg, tOk } from '../ui.js';
import { muat, ringkasan, tujuhHari, hapusSemua, hariKey } from './riwayat-token.js';
const fmt = (n) => Number(n || 0).toLocaleString('id-ID');
export const SRC_LABEL = { tugas: 'Tugas', proyek: 'Proyek', lampiran: 'Lampiran', ocr: 'Baca foto' }; // Rev 353: ocr
const HARI = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'], BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
export const jam = (t) => { const d = new Date(t); return String(d.getHours()).padStart(2, '0') + '.' + String(d.getMinutes()).padStart(2, '0'); };
export const labelHari = (t, now) => { const k = hariKey(t), d = new Date(t); return k === hariKey(now) ? 'Hari ini' : k === hariKey(now - 86400000) ? 'Kemarin' : HARI[d.getDay()] + ', ' + d.getDate() + ' ' + BULAN[d.getMonth()]; };
// Kelompokkan log per hari lokal, terbaru di atas; tiap kelompok { key, label, total, items }.
export function kelompok(list, now) {
  const out = [];
  for (const e of [...list].sort((a, b) => b.t - a.t)) { const k = hariKey(e.t); let g = out[out.length - 1]; if (!g || g.key !== k) { g = { key: k, label: labelHari(e.t, now), total: 0, items: [] }; out.push(g); } g.total += e.in + e.out; g.items.push(e); }
  return out;
}
export function isiRiwayat(panel, now = Date.now(), store) {
  const list = muat(now, store); panel.textContent = '';
  if (!list.length) { panel.append(h('div', { class: 'kd-empty' }, h('b', {}, 'Belum ada riwayat'), h('small', {}, 'Setiap balasan AI yang berhasil akan dicatat di sini: jumlah token, awal pesan, dan data yang ikut. Isi balasan tidak disimpan.'))); return; }
  const r = ringkasan(list, now), kartu = (nama, k) => h('div', { class: 'rt-k' }, h('small', {}, nama), h('b', {}, fmt(k.in + k.out)), h('small', {}, k.n + ' pesan' + (k.est ? ' \u2248' : '')));
  panel.append(h('div', { class: 'rt-ks' }, kartu('Hari ini', r.hari), kartu('7 hari', r.minggu), kartu('Bulan ini', r.bulan)));
  const g7 = tujuhHari(list, now), maks = Math.max(1, ...g7.map((x) => x.total));
  panel.append(h('div', { class: 'kd-sec' }, 'Token per hari (7 hari)'), h('div', { class: 'rt-gr', role: 'img', 'aria-label': 'Grafik token 7 hari terakhir' }, ...g7.map((x, i) => {
    const d = new Date(now); d.setDate(d.getDate() - (6 - i));
    return h('div', { class: 'rt-c' }, h('span', { class: 'rt-v' }, x.total ? fmt(x.total) : ''), h('span', { class: 'rt-b' + (x.est ? ' est' : ''), style: 'height:' + Math.max(x.total ? 6 : 2, Math.round((x.total / maks) * 100)) + '%' }), h('span', { class: 'rt-d' }, HARI[d.getDay()]));
  })));
  panel.append(h('div', { class: 'kd-sec' }, 'Per pesan'));
  for (const g of kelompok(list, now)) {
    panel.append(h('div', { class: 'rt-gh' }, h('b', {}, g.label), h('small', {}, fmt(g.total) + ' token')), h('div', { class: 'rt-log' }, ...g.items.map((e) => h('div', { class: 'rt-it' }, h('span', { class: 'rt-t' }, jam(e.t)), h('span', { class: 'rt-m' }, h('b', {}, e.m || '(tanpa teks)'), e.src.length ? h('small', {}, e.src.map((s) => SRC_LABEL[s]).join(' \u00b7 ')) : null), h('span', { class: 'rt-n' }, (e.est ? '\u2248 ' : '') + fmt(e.in + e.out), h('small', {}, fmt(e.in) + ' / ' + fmt(e.out)))))));
  }
  panel.append(h('p', { class: 'kd-info' }, 'Tanda \u2248 = perkiraan (penyedia tidak melaporkan token). Angka kecil = masuk / keluar. Disimpan 30 hari atau 200 pesan terakhir di HP ini, tidak ikut cadangan.'),
    h('div', { class: 'kd-lnks' }, h('button', { type: 'button', class: 'kd-lnk rt-hps', onclick: () => dlg({ title: 'Hapus riwayat token?', msg: 'Catatan token di HP ini dihapus. Percakapan, catatan, dan data lain tidak berubah.', yes: 'Hapus', red: true, ok: () => { hapusSemua(store); isiRiwayat(panel, Date.now(), store); tOk('Riwayat token dihapus.'); } }) }, 'Hapus riwayat')));
}
