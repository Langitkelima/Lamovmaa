// Rev 201 / Kelimaa AI Tahap 1b: SAMBUNGAN ke Worker Kelimaa AI (Cloudflare). LOGIKA MURNI, tanpa DOM, dimuat MALAS (hanya saat layar Setelan > Kelimaa AI dibuka).
// Hanya MENANYAKAN dua hal, persis pola Two Pockets: "apakah ini Worker Kelimaa AI?" (GET ?ping=1) dan "siapa pemilik passcode ini?" (POST whoami).
// TIDAK ada isi catatan/tugas yang dikirim, dan BELUM ada permintaan ke penyedia AI (itu Rev 202+). Alamat + passcode disimpan di kunci localStorage
// TERPISAH (bukan di data aplikasi), jadi TIDAK ikut ekspor cadangan JSON/ZIP maupun cadangan otomatis.
import { isNative, nativePlugin } from '../native.js';

export const CONN_KEY = 'kelimaa_ai_conn';
export const CFG_KEY = 'kelimaa_ai_cfg';
const TIMEOUT = 20000;
// Hanya alamat workers.dev (nama-worker.nama-akun.workers.dev): passcode tidak boleh terkirim ke alamat sembarang.
const URL_RE = /^https:\/\/[a-z0-9][a-z0-9-]{0,62}\.[a-z0-9][a-z0-9-]{0,62}\.workers\.dev$/i;

// Mengembalikan { ok, value } atau { ok:false, msg }. Query (?...), garis miring akhir, dan spasi dibuang.
export function cleanUrl(raw) {
  const v = String(raw == null ? '' : raw).trim().split(/[?#]/)[0].replace(/\/+$/, '');
  if (!v) return { ok: false, msg: 'Alamat belum diisi.' };
  if (!URL_RE.test(v)) return { ok: false, msg: 'Alamat harus berbentuk https://nama-worker.nama-akun.workers.dev (alamat Worker dari dasbor Cloudflare).' };
  return { ok: true, value: v.toLowerCase() };
}

export function cleanPass(raw) {
  const v = String(raw == null ? '' : raw).trim();
  if (!v) return { ok: false, msg: 'Passcode belum diisi.' };
  if (v.length < 8) return { ok: false, msg: 'Passcode minimal 8 karakter (sama seperti yang kamu isi di Worker).' };
  if (v.length > 200 || /[\u0000-\u001f]/.test(v)) return { ok: false, msg: 'Passcode tidak valid.' };
  return { ok: true, value: v };
}

export function loadConn(store = globalThis.localStorage) {
  try {
    const o = JSON.parse(store.getItem(CONN_KEY) || 'null');
    if (!o || typeof o !== 'object') return null;
    const u = cleanUrl(o.url), k = cleanPass(o.key);
    if (!u.ok || !k.ok) return null;
    return { url: u.value, key: k.value, me: typeof o.me === 'string' ? o.me.slice(0, 20) : '', testedAt: Number(o.testedAt) || 0 };
  } catch (_) { return null; }
}
export function saveConn(conn, store = globalThis.localStorage) {
  const u = cleanUrl(conn && conn.url), k = cleanPass(conn && conn.key);
  if (!u.ok) return u;
  if (!k.ok) return k;
  try {
    store.setItem(CONN_KEY, JSON.stringify({ url: u.value, key: k.value, me: String((conn && conn.me) || '').slice(0, 20), testedAt: Number(conn && conn.testedAt) || 0 }));
    return { ok: true };
  } catch (e) { return { ok: false, msg: 'Gagal menyimpan di HP.' }; }
}
export function clearConn(store = globalThis.localStorage) { try { store.removeItem(CONN_KEY); } catch (_) { /* abaikan */ } }

// Sakelar utama Kelimaa AI + pilihan jalur, model, dan batas harian (Rev 209). BAWAAN MATI. Disimpan di kunci terpisah dari data aplikasi (tidak ikut cadangan).
// provider: '' = otomatis (Worker memilih), atau sakelar | relay | gemini. model: '' = bawaan Worker, atau nama model (daftar pilihan ATAU ketikan sendiri).
// limit: 100 | 150 | 200 | 0 (0 = TANPA BATAS); angka lain >= 1 juga diterima (maks. 10000). Batas dihitung di Worker per orang per hari (WIB).
export const PROVIDER_CHOICES = [['', 'Otomatis'], ['sakelar', 'Sakelar'], ['relay', 'Relay'], ['gemini', 'Gemini']];
// Rev 213c: jenis pekerjaan yang boleh dikirim ke Worker (harus sama dengan ROUTES di worker.mjs). Aplikasi mengirim jenis pekerjaan, BUKAN nama model.
export const TASK_CHOICES = [['chat.general', 'Umum'], ['analysis.general', 'Analisis'], ['creative.general', 'Kreatif'], ['utility.small', 'Cepat']];
// Pilihan cepat per jalur: HANYA nama yang tercatat di PANDUAN_WORKER.md. Model lain: pilih "Ketik manual".
export const MODEL_PRESETS = { sakelar: ['deepseek/deepseek-v4-flash', 'anthropic/haiku-5.5'], relay: [], gemini: ['gemini-3.5-flash', 'gemini-3.5-flash-lite'] };
export const LIMIT_CHOICES = [[100, '100'], [150, '150'], [200, '200'], [0, 'Tanpa batas']];
export const DEFAULT_LIMIT = 100, MAX_LIMIT = 10000;
// Rev 242 / Tahap 9c: token bulan ini dari Worker ({in, out}); hanya angka bulat >= 0 yang diterima, selain itu null. Angka = laporan penyedia (perkiraan), bukan tagihan.
export function cleanTokens(t) {
  if (!t || typeof t !== 'object') return null;
  const f = (x) => (typeof x === 'number' && Number.isFinite(x) && x >= 0 ? Math.floor(x) : null), a = f(t.in), b = f(t.out);
  return a === null || b === null || a + b === 0 ? null : { in: a, out: b };
}
export function tokensText(t) { const c = cleanTokens(t); return c ? 'token bulan ini: masuk ' + c.in.toLocaleString('id-ID') + ', keluar ' + c.out.toLocaleString('id-ID') : ''; }
// Rev 241 / Tahap 9b: batas BULANAN opsional (Worker Rev 240). 0 = tanpa batas bulanan (BAWAAN; permintaan tidak membawa monthLimit sama sekali). Dihitung di Worker per orang per bulan (WIB).
export const MONTH_CHOICES = [[0, 'Tanpa'], [1500, '1.500'], [3000, '3.000'], [6000, '6.000']];
export const MAX_MONTH = 100000;
export function cleanMonthLimit(raw) { const n = Math.floor(Number(raw)); return Number.isFinite(n) && n >= 1 ? Math.min(n, MAX_MONTH) : 0; }
const MODEL_RE = /^[a-z0-9][a-z0-9./:-]{2,80}$/i; // sama dengan Worker
export function cleanModel(raw) {
  const v = String(raw == null ? '' : raw).trim();
  if (!v) return { ok: true, value: '' };
  if (!MODEL_RE.test(v)) return { ok: false, msg: 'Nama model tidak valid: 3-81 karakter, hanya huruf, angka, titik, garis miring, titik dua, dan minus (contoh: gemini-3.5-flash).' };
  return { ok: true, value: v };
}
export function cleanLimit(raw) {
  if (raw === 0 || raw === '0') return 0;
  const n = Math.floor(Number(raw));
  return Number.isFinite(n) && n >= 1 ? Math.min(n, MAX_LIMIT) : DEFAULT_LIMIT;
}
function cleanProvider(raw) { const v = String(raw == null ? '' : raw).toLowerCase(); return PROVIDER_CHOICES.some((p) => p[0] === v) ? v : ''; }
// Rev 211: model yang sudah dihapus dari pilihan (permintaan pengguna) otomatis kembali ke "bawaan Worker" bila masih tersimpan di HP.
export const RETIRED_MODELS = ['gemini-3.8-flash'];
function normCfg(o) {
  const x = o && typeof o === 'object' ? o : {};
  const m = cleanModel(x.model);
  return { on: x.on === true, provider: cleanProvider(x.provider), model: m.ok && !RETIRED_MODELS.includes(m.value) ? m.value : '', limit: x.limit === undefined ? DEFAULT_LIMIT : cleanLimit(x.limit), ...(cleanMonthLimit(x.monthLimit) ? { monthLimit: cleanMonthLimit(x.monthLimit) } : {}) }; // Rev 241: monthLimit hanya ada bila aktif (bentuk lama tidak berubah)
}
export function loadCfg(store = globalThis.localStorage) {
  try { return normCfg(JSON.parse(store.getItem(CFG_KEY) || 'null')); } catch (_) { return normCfg(null); }
}
export function saveCfg(cfg, store = globalThis.localStorage) {
  try { store.setItem(CFG_KEY, JSON.stringify(normCfg({ ...cfg, on: !!(cfg && cfg.on) }))); return { ok: true }; } catch (_) { return { ok: false, msg: 'Gagal menyimpan di HP.' }; }
}
// Pilihan yang ikut dikirim ke Worker bersama tiap chat.
export function chatOpts(cfg) {
  const c = normCfg(cfg);
  return { provider: c.provider, model: c.model, limit: c.limit, ...(c.monthLimit ? { monthLimit: c.monthLimit } : {}) };
}
// Ringkasan satu baris untuk layar: "Gemini · gemini-3.5-flash · tanpa batas".
export function pilihanText(cfg) {
  const c = normCfg(cfg), p = PROVIDER_CHOICES.find((x) => x[0] === c.provider);
  return [c.provider ? p[1] : 'Jalur otomatis', c.model || 'model bawaan Worker', c.limit === 0 ? 'tanpa batas' : 'batas ' + c.limit + '/hari', c.monthLimit ? 'bulan ' + c.monthLimit : ''].filter(Boolean).join(' \u00b7 ');
}
export function clearCfg(store = globalThis.localStorage) { try { store.removeItem(CFG_KEY); } catch (_) { /* abaikan */ } }

// Pengirim HTTP: di aplikasi lewat CapacitorHttp (bebas aturan CORS); di peramban lewat fetch (kemungkinan terhalang CORS, hanya untuk pengembangan).
// Content-Type text/plain agar peramban tidak meminta pra-pemeriksaan (Worker membaca isi sebagai teks lalu JSON).
export async function nativeHttp({ method, url, body, timeout = TIMEOUT }) {
  if (isNative()) {
    const r = await nativePlugin('CapacitorHttp').request({
      url, method, responseType: 'text', connectTimeout: timeout, readTimeout: timeout,
      headers: method === 'POST' ? { 'Content-Type': 'text/plain;charset=utf-8' } : {},
      data: method === 'POST' ? body : undefined,
    });
    return { status: r && r.status, text: typeof (r && r.data) === 'string' ? r.data : JSON.stringify((r && r.data) || '') };
  }
  const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), timeout);
  try {
    const r = await fetch(url, { method, body, signal: ctl.signal, headers: method === 'POST' ? { 'Content-Type': 'text/plain;charset=utf-8' } : {} });
    return { status: r.status, text: await r.text() };
  } finally { clearTimeout(tm); }
}

function parseJson(text) {
  try { const o = JSON.parse(String(text || '')); return o && typeof o === 'object' ? o : null; } catch (_) { return null; }
}
function netMsg(e) {
  const m = String((e && e.message) || e || '').slice(0, 120);
  return /timeout|timed out|abort/i.test(m) ? 'Waktu habis (Worker tidak menjawab dalam 20 detik).' : 'Tidak tersambung: ' + (m || 'tanpa keterangan') + '. Cek internet.';
}

// Terjemahan jawaban galat Worker ke bahasa awam (kode HTTP + isi `error`).
export function explainWorkerError(status, errText) {
  const e = String(errText || '').slice(0, 140);
  if (status === 401) return 'Passcode salah: ketikan tidak sama dengan Secret di Worker. Cek huruf besar/kecil, atau ketik ulang Secret-nya di dasbor lalu Deploy.';
  if (status === 503) return 'Worker belum punya passcode. Isi Secret PASS_RAMA / PASS_DESY di Worker (Settings > Variables and Secrets), lalu tekan Deploy.';
  if (status === 429) return 'Terlalu banyak percobaan salah dari jaringan ini. Tunggu sekitar satu jam, lalu coba lagi.';
  if (status === 413) return 'Permintaan terlalu besar.';
  if (/aksi tidak dikenal/i.test(e)) return 'Kode Worker belum yang terbaru: tempel ulang worker.mjs lalu Deploy.';
  return e || 'Ditolak oleh Worker (kode ' + status + ').';
}

// Dua langkah terpisah supaya jelas bagian mana yang bermasalah:
//  1) GET  alamat?ping=1            -> apakah alamat benar, Worker terpasang, dan kodenya benar
//  2) POST {key, action:'whoami'}   -> apakah passcode benar
// Hasil: { ok, me, info, steps:[{id, ok, msg, note?}] }. Langkah 'info' (catatan) hanya muncul bila passcode benar. Tidak pernah melempar error.
export async function testConnection(conn, http = nativeHttp) {
  const u = cleanUrl(conn && conn.url), k = cleanPass(conn && conn.key);
  if (!u.ok) return { ok: false, me: '', info: null, steps: [{ id: 'input', ok: false, msg: u.msg }] };
  if (!k.ok) return { ok: false, me: '', info: null, steps: [{ id: 'input', ok: false, msg: k.msg }] };
  const steps = [];

  try {
    const r = await http({ method: 'GET', url: u.value + '/?ping=1' });
    const j = parseJson(r && r.text), st = r && r.status;
    if (st >= 200 && st < 300 && j && j.ok === true && j.app === 'KELIMAA AI') steps.push({ id: 'ping', ok: true, msg: 'Alamat benar, Worker Kelimaa AI menjawab.' });
    else if (st >= 200 && st < 300 && !j) steps.push({ id: 'ping', ok: false, msg: 'Menjawab, tetapi bukan jawaban Kelimaa AI (mungkin masih "Hello World": tempel kode worker.mjs di Edit code, lalu Deploy).' });
    else if (st && (st < 200 || st >= 300)) steps.push({ id: 'ping', ok: false, msg: 'Server membalas kode ' + st + '. Cek alamat Worker dan pastikan sudah di-Deploy.' });
    else steps.push({ id: 'ping', ok: false, msg: 'Jawaban tidak dikenali. Cek alamat dan kode Worker yang sudah di-Deploy.' });
  } catch (e) { steps.push({ id: 'ping', ok: false, msg: netMsg(e) }); }
  if (!steps[0].ok) return { ok: false, me: '', info: null, steps };

  try {
    const r = await http({ method: 'POST', url: u.value + '/', body: JSON.stringify({ key: k.value, action: 'whoami' }) });
    const j = parseJson(r && r.text), st = r && r.status;
    if (j && j.ok === true && typeof j.me === 'string' && j.me) {
      steps.push({ id: 'whoami', ok: true, msg: 'Passcode benar. Terhubung sebagai ' + j.me + '.' });
      const limit = Number(j.limit) || 0, used = typeof j.used === 'number' ? j.used : null;
      const monthUsed = typeof j.monthUsed === 'number' ? j.monthUsed : null, monthTokens = cleanTokens(j.monthTokens), hardLimit = typeof j.hardLimit === 'number' && j.hardLimit >= 1 ? Math.floor(j.hardLimit) : 0, info = { limit, used, kv: j.kv === true, monthUsed, monthTokens, ...(hardLimit ? { hardLimit } : {}) };
      steps.push({ id: 'info', ok: true, note: true, msg: j.kv === true
        ? 'KV terpasang. Terpakai hari ini: ' + (used === null ? 'belum diketahui' : used) + (monthUsed === null ? '' : '; bulan ini: ' + monthUsed) + (monthTokens ? '; ' + tokensText(monthTokens) : '') + (hardLimit ? '. Plafon server: ' + hardLimit + '/hari (tidak bisa dilewati, termasuk Tanpa batas)' : '') + '. Batas harian dipilih di aplikasi (bawaan Worker ' + limit + ').'
        : 'KV belum terpasang: belum ada pembatas percobaan salah, dan chat BERBATAS akan ditolak sampai KV dipasang (pilihan Tanpa batas tetap jalan).' });
      return { ok: true, me: j.me, info, steps };
    }
    if (j && j.ok === false) steps.push({ id: 'whoami', ok: false, msg: explainWorkerError(st, j.error) });
    else steps.push({ id: 'whoami', ok: false, msg: 'Kirim passcode tidak berhasil: jawaban tidak dikenali (kode ' + st + '). Langkah 1 berhasil tetapi POST gagal; kabari ini ke pembuat aplikasi.' });
  } catch (e) { steps.push({ id: 'whoami', ok: false, msg: netMsg(e) }); }
  return { ok: false, me: '', info: null, steps };
}

// ---- Rev 202b: CHAT UMUM. Hanya teks yang diketik pengguna di layar Chat (tanpa isi catatan/tugas/Catatan Privat). Logika murni, bisa dites di Node.
export const CHAT_MAX_MSG = 4000, CHAT_KEEP = 12, CHAT_TIMEOUT = 60000;
export function cleanChatInput(raw) {
  const v = String(raw == null ? '' : raw).trim();
  if (!v) return { ok: false, msg: 'Tulis pesan dulu.' };
  if (v.length > CHAT_MAX_MSG) return { ok: false, msg: 'Pesan terlalu panjang (maks. ' + CHAT_MAX_MSG + ' huruf).' };
  return { ok: true, value: v };
}
// Riwayat (hanya pasangan yang BERHASIL) + pesan baru -> daftar untuk Worker: maks. CHAT_KEEP terakhir, mulai dari pesan pengguna, tiap pesan dipotong ke batas Worker.
export function buildMessages(history, text) {
  const all = (Array.isArray(history) ? history : []).concat([{ role: 'user', content: text }])
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
    .map((m) => ({ role: m.role, content: m.content.trim().slice(0, CHAT_MAX_MSG) }));
  const out = all.slice(-CHAT_KEEP);
  while (out.length && out[0].role !== 'user') out.shift();
  return out;
}
function chatErr(status, errText) {
  const e = String(errText || '').slice(0, 200);
  if (status === 401) return 'Passcode salah atau sudah berubah di Worker. Buka Setelan > Kelimaa AI, ketik ulang passcode, lalu Tes sambungan.';
  return e || 'Ditolak oleh Worker (kode ' + status + ').';
}
// Mengembalikan { ok:true, text, model, provider, used, limit } atau { ok:false, msg }. Tidak pernah melempar error.
export async function kirimChat(conn, messages, http = nativeHttp, opts = {}) {
  const u = cleanUrl(conn && conn.url), k = cleanPass(conn && conn.key);
  if (!u.ok) return { ok: false, msg: u.msg };
  if (!k.ok) return { ok: false, msg: k.msg };
  if (!Array.isArray(messages) || !messages.length) return { ok: false, msg: 'Tidak ada pesan untuk dikirim.' };
  const o = opts && typeof opts === 'object' ? opts : {}, req = { key: k.value, action: 'chat', task: 'chat.general', messages };
  if (o.provider) req.provider = cleanProvider(o.provider) || undefined;
  if (o.task && TASK_CHOICES.some((t) => t[0] === o.task)) req.task = o.task;
  if (o.model) { const m = cleanModel(o.model); if (!m.ok) return { ok: false, msg: m.msg }; if (m.value) req.model = m.value; }
  if (o.limit !== undefined && o.limit !== null) req.limit = cleanLimit(o.limit);
  if (cleanMonthLimit(o.monthLimit) > 0) req.monthLimit = cleanMonthLimit(o.monthLimit); // Rev 241: hanya dikirim bila aktif
  try {
    const r = await http({ method: 'POST', url: u.value + '/', body: JSON.stringify(req), timeout: CHAT_TIMEOUT });
    const j = parseJson(r && r.text), st = r && r.status;
    if (j && j.ok === true && typeof j.text === 'string' && j.text.trim()) {
      return { ok: true, text: j.text, model: String(j.model || '').slice(0, 60), provider: String(j.provider || '').slice(0, 20), used: typeof j.used === 'number' ? j.used : null, limit: Number(j.limit) || 0, ...(typeof j.monthUsed === 'number' ? { monthUsed: j.monthUsed, monthLimit: Number(j.monthLimit) || 0 } : {}), ...(cleanTokens(j.monthTokens) ? { monthTokens: cleanTokens(j.monthTokens) } : {}), ...(cleanTokens(j.usage) ? { usage: cleanTokens(j.usage) } : {}), ...(typeof j.fallbackProvider === 'string' && j.fallbackProvider ? { fallbackProvider: j.fallbackProvider.slice(0, 20) } : {}) };
    }
    if (j && j.ok === false) return { ok: false, msg: chatErr(st, j.error) };
    return { ok: false, msg: 'Jawaban Worker tidak dikenali (kode ' + st + '). Pastikan kode Worker yang terbaru sudah di-Deploy.' };
  } catch (e) {
    const m = String((e && e.message) || e || '').slice(0, 120);
    return { ok: false, msg: /timeout|timed out|abort/i.test(m) ? 'Waktu habis: tidak ada jawaban dalam 60 detik.' : 'Tidak tersambung: ' + (m || 'tanpa keterangan') + '. Cek internet.' };
  }
}

// Rev 232: aksi `research` (Worker Rev 231). Hanya `limit` yang dikirim: jalur/model chat TIDAK dipakai (riset selalu Gemini di Worker). Mengembalikan { ok:true, text, sources, queries, grounded, model, provider, used, limit } atau { ok:false, msg }. Tidak pernah melempar error.
export async function kirimRiset(conn, messages, http = nativeHttp, opts = {}) {
  const u = cleanUrl(conn && conn.url), k = cleanPass(conn && conn.key);
  if (!u.ok) return { ok: false, msg: u.msg };
  if (!k.ok) return { ok: false, msg: k.msg };
  if (!Array.isArray(messages) || !messages.length) return { ok: false, msg: 'Tidak ada pesan untuk dikirim.' };
  const o = opts && typeof opts === 'object' ? opts : {}, req = { key: k.value, action: 'research', messages };
  if (o.limit !== undefined && o.limit !== null) req.limit = cleanLimit(o.limit);
  if (cleanMonthLimit(o.monthLimit) > 0) req.monthLimit = cleanMonthLimit(o.monthLimit); // Rev 241: hanya dikirim bila aktif
  try {
    const r = await http({ method: 'POST', url: u.value + '/', body: JSON.stringify(req), timeout: CHAT_TIMEOUT });
    const j = parseJson(r && r.text), st = r && r.status;
    if (j && j.ok === true && typeof j.text === 'string' && j.text.trim()) {
      return { ok: true, text: j.text, sources: Array.isArray(j.sources) ? j.sources : [], queries: Array.isArray(j.queries) ? j.queries : [], grounded: j.grounded === true, ...(j.noSearch === true ? { noSearch: true, fallbackProvider: String(j.fallbackProvider || '').slice(0, 20) } : {}), model: String(j.model || '').slice(0, 60), provider: String(j.provider || '').slice(0, 20), used: typeof j.used === 'number' ? j.used : null, limit: Number(j.limit) || 0, ...(typeof j.monthUsed === 'number' ? { monthUsed: j.monthUsed, monthLimit: Number(j.monthLimit) || 0 } : {}), ...(cleanTokens(j.monthTokens) ? { monthTokens: cleanTokens(j.monthTokens) } : {}), ...(cleanTokens(j.usage) ? { usage: cleanTokens(j.usage) } : {}) };
    }
    if (j && j.ok === false) return { ok: false, msg: chatErr(st, j.error) };
    return { ok: false, msg: 'Jawaban Worker tidak dikenali (kode ' + st + '). Pastikan kode Worker terbaru (Rev 231 atau lebih baru) sudah di-Deploy.' };
  } catch (e) {
    const m = String((e && e.message) || e || '').slice(0, 120);
    return { ok: false, msg: /timeout|timed out|abort/i.test(m) ? 'Waktu habis: tidak ada jawaban dalam 60 detik.' : 'Tidak tersambung: ' + (m || 'tanpa keterangan') + '. Cek internet.' };
  }
}
