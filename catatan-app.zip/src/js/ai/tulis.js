// Rev 217 / Kelimaa AI Tahap 3a: mesin WRITING STUDIO (logika murni, TANPA UI, TANPA DOM). Mengolah SATU potongan teks yang dipilih pengguna (rapikan, ringkas, kembangkan, formal, santai, terjemah).
// Yang dikirim ke Worker HANYA instruksi + teks terpilih (satu pesan, tanpa riwayat chat, tanpa data aplikasi). Hasil = teks biasa; penerapannya ke catatan (3b) wajib lewat konfirmasi.
import { kirimChat, chatOpts, CHAT_MAX_MSG } from './sambungan.js';

export const SEL_MAX = 3000; // sisakan ruang untuk instruksi di bawah batas 4000 huruf per pesan Worker
// id, label, jenis pekerjaan Worker (harus ada di TASK_CHOICES), instruksi. Isi tabel = USULAN AI (asumsi), bisa diubah tanpa menyentuh Worker.
export const WRITE_ACTIONS = [
  { id: 'rapikan', label: 'Rapikan', task: 'utility.small', ins: 'Rapikan teks berikut: perbaiki ejaan, tanda baca, dan kalimat yang janggal, tanpa mengubah makna dan tanpa menambah isi baru.' },
  { id: 'ringkas', label: 'Ringkas', task: 'utility.small', ins: 'Ringkas teks berikut menjadi lebih pendek dengan semua poin pentingnya tetap ada.' },
  { id: 'kembangkan', label: 'Kembangkan', task: 'creative.general', ins: 'Kembangkan teks berikut menjadi lebih lengkap dan enak dibaca, tanpa mengarang fakta baru yang tidak ada di teks.' },
  { id: 'formal', label: 'Formal', task: 'utility.small', ins: 'Tulis ulang teks berikut dengan bahasa yang lebih formal dan sopan, makna tetap sama.' },
  { id: 'santai', label: 'Santai', task: 'utility.small', ins: 'Tulis ulang teks berikut dengan bahasa yang lebih santai dan hangat, makna tetap sama.' },
  { id: 'inggris', label: 'Ke Inggris', task: 'utility.small', ins: 'Terjemahkan teks berikut ke bahasa Inggris yang natural.' },
  { id: 'indonesia', label: 'Ke Indonesia', task: 'utility.small', ins: 'Terjemahkan teks berikut ke Bahasa Indonesia yang natural.' },
];
// Rev 220 / Tahap 3c: CREATIVE STUDIO = aksi kreatif pada teks terpilih (jalur `creative.general`). `tambah: true` = hasil berupa daftar usulan, hanya boleh DISISIPKAN (tidak mengganti teks asli). Isi tabel = USULAN AI (asumsi).
export const CREATIVE_ACTIONS = [
  { id: 'judul', label: 'Ide judul', task: 'creative.general', tambah: true, ins: 'Beri 5 ide judul yang menarik untuk teks berikut. Tulis satu judul per baris, bernomor 1 sampai 5.' },
  { id: 'caption', label: 'Caption', task: 'creative.general', tambah: true, ins: 'Buat 3 pilihan caption singkat (maksimal 150 huruf per caption) untuk teks berikut. Tulis satu caption per baris, bernomor 1 sampai 3.' },
  { id: 'ide', label: 'Ide lanjutan', task: 'creative.general', tambah: true, ins: 'Beri 5 ide untuk melanjutkan atau mengembangkan teks berikut. Tulis satu ide per baris, bernomor, masing-masing satu kalimat.' },
  { id: 'puisi', label: 'Jadi puisi', task: 'creative.general', ins: 'Ubah teks berikut menjadi puisi pendek (4 sampai 8 baris) dengan makna yang sama.' },
  { id: 'cerita', label: 'Jadi cerita', task: 'creative.general', ins: 'Tulis ulang teks berikut sebagai paragraf bercerita yang hidup (satu sampai dua paragraf), tanpa mengarang fakta penting yang bertentangan dengan teks.' },
];
export const ALL_ACTIONS = [...WRITE_ACTIONS, ...CREATIVE_ACTIONS];
const TAIL = 'Balas HANYA dengan hasil teksnya saja, tanpa pembuka, penjelasan, atau tanda kutip pembungkus. Jangan menyebut bahwa kamu AI.';

export function cleanSelection(raw) {
  const t = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
  if (!t) return { ok: false, msg: 'Pilih (blok) dulu teks yang mau diolah.' };
  if (t.length > SEL_MAX) return { ok: false, msg: 'Teks terpilih terlalu panjang (maks. ' + SEL_MAX.toLocaleString('id-ID') + ' huruf). Pilih bagian yang lebih pendek.' };
  return { ok: true, text: t };
}
// -> { ok, content, task, label } | { ok:false, msg }
export function buildPrompt(actionId, rawSel) {
  const a = ALL_ACTIONS.find((x) => x.id === actionId); if (!a) return { ok: false, msg: 'Aksi tulis tidak dikenal.' };
  const s = cleanSelection(rawSel); if (!s.ok) return s;
  const content = a.ins + ' ' + TAIL + '\n\n---\n' + s.text;
  if (content.length > CHAT_MAX_MSG) return { ok: false, msg: 'Teks terpilih terlalu panjang untuk aksi ini.' };
  return { ok: true, content, task: a.task, label: a.label, tambah: !!a.tambah };
}
// Bersihkan balasan AI: buang pagar kode pembungkus dan tanda kutip pembungkus; tetap teks biasa.
export function cleanResult(raw) {
  let t = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
  const f = t.match(/^```[a-zA-Z]*\n([\s\S]*?)\n?```$/); if (f) t = f[1].trim();
  const q = t.match(/^["\u201c]([\s\S]+)["\u201d]$/); if (q && !/["\u201c\u201d]/.test(q[1])) t = q[1].trim();
  return t.slice(0, 20000);
}
// Satu panggilan ke Worker. Tidak pernah melempar. -> { ok:true, text, label, provider, model } | { ok:false, msg }
export async function tulisDenganAI(conn, cfg, actionId, rawSel, http) {
  const p = buildPrompt(actionId, rawSel); if (!p.ok) return p;
  const res = await kirimChat(conn, [{ role: 'user', content: p.content }], http, { ...chatOpts(cfg), task: p.task });
  if (!res.ok) return res;
  const text = cleanResult(res.text); if (!text) return { ok: false, msg: 'AI tidak memberi hasil. Coba lagi.' };
  return { ok: true, text, label: p.label, tambah: p.tambah, provider: res.provider, model: res.model };
}
