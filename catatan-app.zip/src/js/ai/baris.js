// Rev 230 / Kelimaa AI Tahap 5 (sisa): aksi `sheet.append_row` = tambahkan baris dari balasan AI (baris tabel Markdown `| a | b |` atau butir daftar) ke bagian BAWAH satu tab lembar kerja Notes, HANYA setelah pengguna mencentang baris, memilih lembar + tab, dan mengonfirmasi; bisa Urungkan.
// Hanya menulis nilai sel (teks/angka) lewat `setCell` milik lembar.js; TIDAK menulis rumus, gaya, aturan, gabung sel, atau diagram; tidak menyentuh catatan, tugas, kebiasaan, Catatan Privat, atau sampah. Maks. 10 baris per aksi.
// Catatan jujur: aturan validasi sel (Rev 145/147) tidak dijalankan untuk nilai yang ditambahkan dari sini.
import { cleanValue, setCell, addRows, fitsLimit, MAX_ROWS, MAX_CELL } from '../lembar.js';
import { plainInline } from './markdown.js';

export const ROW_MAX = 10, ROW_COLS = 26;

const isSep = (l) => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(l);
const cleanCell = (v) => plainInline(String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ')).replace(/\s+/g, ' ').trim().slice(0, MAX_CELL);
// Teks sel -> nilai sel. Angka polos (mis. 15000, 12,5) jadi angka; "15.000" (ribuan gaya Indonesia) sengaja TETAP teks agar tidak salah tafsir. Awalan "=" diberi apostrof supaya tidak terbaca sebagai rumus bila diekspor.
export function toCellValue(s) {
  const t = String(s == null ? '' : s).trim(); if (!t) return undefined;
  if (/^-?\d{1,3}(\.\d{3})+$/.test(t)) return cleanValue(t); // 15.000 / 1.250.000 = ribuan gaya Indonesia: tetap teks
  if (/^-?\d{1,15}([.,]\d{1,6})?$/.test(t)) { const n = Number(t.replace(',', '.')); if (Number.isFinite(n)) return n; }
  return cleanValue(t[0] === '=' ? "'" + t : t);
}
// Balasan AI -> usulan baris [{cells:[teks...], head}] (maks. ROW_MAX). Bila ada baris tabel Markdown, hanya itu yang dipakai (baris judul = `head`, tidak dicentang bawaannya); selain itu butir daftar jadi baris satu sel.
export function rowDrafts(raw) {
  const lines = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').split('\n'), table = [], list = [];
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (l.includes('|') && !isSep(l)) {
      const body = l.trim().replace(/^\|/, '').replace(/\|$/, ''), cells = body.split('|').map(cleanCell).slice(0, ROW_COLS);
      if (cells.some((c) => c)) table.push({ cells, head: i + 1 < lines.length && isSep(lines[i + 1]) });
      continue;
    }
    const m = l.match(/^\s*(?:[-*\u2022]|\d{1,2}[.)])\s+(?:\[[ xX]?\]\s*)?(.+)$/);
    if (m) { const c = cleanCell(m[1]); if (c) list.push({ cells: [c], head: false }); }
  }
  return (table.length ? table : list).slice(0, ROW_MAX);
}

// Calon tujuan: lembar kerja terbaru (maks. `limit`). `data.sheets` tidak pernah memuat isi Catatan Privat (pulau lembar dibuang dari catatan Privat).
export function sheetChoices(ctx, limit = 30) {
  const s = ctx && ctx.data && ctx.data.sheets; if (!s || typeof s !== 'object' || Array.isArray(s)) return [];
  return Object.keys(s).map((k) => s[k]).filter((x) => x && typeof x.id === 'string' && Array.isArray(x.tabs) && x.tabs.length)
    .sort((a, b) => (b.at || 0) - (a.at || 0)).slice(0, limit).map((x) => ({ id: x.id, name: String(x.name || 'Lembar kerja'), tabs: x.tabs.map((t) => ({ id: t.id, name: String(t.name || 'Lembar') })) }));
}
const hasVal = (c) => !!c && (c.v !== undefined || c.fx !== undefined);
const usedRow = (r) => !!r && !!r.cells && Object.keys(r.cells).some((k) => hasVal(r.cells[k]));
// Indeks (0-based) baris kosong pertama sesudah baris terisi terakhir.
export function firstFreeRow(tab) { let last = -1; for (let i = 0; i < tab.rows.length; i++) if (usedRow(tab.rows[i])) last = i; return last + 1; }

// Tambah baris. rows = larik larik teks. -> {sheetId, tabId, rowIds, addedIds, prev, start (nomor baris 1-based), dropped} atau {error:'invalid'|'full'|'big'} (tidak ada yang berubah).
export function appendRows(ctx, sheetId, tabId, rows, now = Date.now()) {
  const sh = ctx && ctx.data && ctx.data.sheets && ctx.data.sheets[sheetId]; const tab = sh && Array.isArray(sh.tabs) ? sh.tabs.find((t) => t && t.id === tabId) : null;
  if (!tab || !Array.isArray(rows)) return { error: 'invalid' };
  const vals = rows.slice(0, ROW_MAX).map((r) => (Array.isArray(r) ? r : [r]).map(toCellValue)).filter((r) => r.some((v) => v !== undefined));
  if (!vals.length) return { error: 'invalid' };
  const start = firstFreeRow(tab), oldLen = tab.rows.length, need = start + vals.length;
  if (need > MAX_ROWS) return { error: 'full' };
  if (need > oldLen) addRows(tab, need - oldLen);
  if (tab.rows.length < need) { tab.rows.length = oldLen; return { error: 'full' }; }
  const addedIds = tab.rows.slice(oldLen).map((r) => r.id), rowIds = [], prev = {}; let dropped = 0;
  vals.forEach((r, i) => {
    const row = tab.rows[start + i]; rowIds.push(row.id); prev[row.id] = JSON.stringify(row.cells || {});
    r.forEach((v, j) => { if (v === undefined) return; if (j >= tab.cols.length) { dropped++; return; } setCell(tab, row.id, tab.cols[j].id, { v }); });
  });
  const undo = { sheetId, tabId, rowIds, addedIds, prev };
  if (!fitsLimit(sh)) { restoreRows(ctx, undo, null); return { error: 'big' }; }
  sh.at = now; ctx.persist();
  return { ...undo, start: start + 1, dropped };
}
// Urungkan: isi sel baris-baris itu dikembalikan, baris yang ditambah dibuang. -> true bila lembar/tab masih ada.
export function restoreRows(ctx, u, now = Date.now()) {
  const sh = ctx && ctx.data && ctx.data.sheets && u ? ctx.data.sheets[u.sheetId] : null; const tab = sh && Array.isArray(sh.tabs) ? sh.tabs.find((t) => t && t.id === u.tabId) : null;
  if (!tab) return false;
  for (const id of u.rowIds) { const r = tab.rows.find((x) => x && x.id === id); if (r && u.prev[id] !== undefined) r.cells = JSON.parse(u.prev[id]); }
  const add = new Set(u.addedIds); for (let i = tab.rows.length - 1; i >= 0; i--) if (add.has(tab.rows[i].id) && tab.rows.length > 1) tab.rows.splice(i, 1);
  if (now !== null) { sh.at = now; ctx.persist(); }
  return true;
}
// Kalimat hasil untuk toast.
export function appendSummary(res, sheetName) {
  const n = res.rowIds.length; return n + ' baris ditambahkan ke \u201c' + sheetName + '\u201d (mulai baris ' + res.start + ').' + (res.dropped ? ' ' + res.dropped + ' sel di luar kolom yang ada dilewati.' : '');
}
export const appendError = (e) => (e === 'full' ? 'Tab itu sudah penuh (maks. ' + MAX_ROWS + ' baris).' : e === 'big' ? 'Lembar kerja terlalu besar.' : 'Baris gagal ditambahkan.');
