// Rev 216 / Kelimaa AI Tahap 4 (bagian kecil): aksi `note.create` = simpan balasan AI jadi catatan BIASA baru, HANYA setelah konfirmasi pengguna (kontrak 27.7).
// Rev 219 / Tahap 4 (sisa): aksi `note.append` = tambah balasan AI ke AKHIR catatan biasa yang sudah ada, pilihan pengguna, bisa Urungkan (pulihkan isi lama). Hanya `data.notes` (tanpa Catatan Privat dan sampah).
// Rev 222 / Tahap 5a: aksi `task.create` = jadikan butir daftar di balasan AI jadi TUGAS (judul KAPITAL, tanpa tenggat/pengingat/sub-tugas), HANYA setelah pengguna mencentang dan mengonfirmasi; bisa Urungkan. Tidak menyentuh kebiasaan, Catatan Privat, atau pengingat.
// Rev 229: aksi `reminder.set` (createReminders) = tugas BARU dengan pengingat lewat scheduleReminder yang sudah ada; waktu dipilih pengguna.
// Teks AI selalu teks biasa -> sharedToHtml (escape) -> sanitize; tidak pernah HTML mentah. Tidak membuka editor, tidak menyentuh Catatan Privat, tidak membaca data apa pun.
import { sharedToHtml, newId, SHARE_IN_MAX } from '../logic.js';
import { sanitize } from '../notes.js';
import { parse, toPlain, toHtml, plainInline } from './markdown.js'; // Rev 227
import { scheduleReminder, cancelTaskAlarms } from '../reminders.js'; // Rev 229
import { toggleProjectLink } from '../proyek-alat.js'; // Rev 236

export const TITLE_MAX = 60;
// Rev 227: teks balasan (Markdown) -> {title, text, html}. `text` = teks BERSIH tanpa tanda (**, *, <i>); `html` = isi catatan BERGAYA (tebal, miring, daftar, judul), tetap harus lewat sanitize. Judul = baris pertama bila isi lebih dari satu baris; selain itu kosong.
export function noteDraft(raw) {
  let src = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').replace(/[ \u00a0]+\n/g, '\n').replace(/\n{4,}/g, '\n\n\n').trim();
  if (!src) return null;
  if (src.length > SHARE_IN_MAX) { src = src.slice(0, SHARE_IN_MAX); const c = src.charCodeAt(src.length - 1); if (c >= 0xd800 && c <= 0xdbff) src = src.slice(0, -1); src = src.replace(/\s+$/, ''); }
  const blocks = parse(src), text = toPlain(blocks).replace(/\n{4,}/g, '\n\n\n').trim();
  if (!text) return null;
  const first = text.split('\n')[0].replace(/^[\u2022\-\s]+/, '').replace(/\s+/g, ' ').trim().slice(0, TITLE_MAX).trim();
  return { title: text.includes('\n') ? first : '', text, html: toHtml(blocks) };
}
export function createNote(ctx, draft) {
  if (!ctx || !ctx.data || !Array.isArray(ctx.data.notes) || !draft || !draft.text) return null;
  const n = { id: newId(), title: draft.title, text: draft.text, html: sanitize(draft.html || sharedToHtml(draft.text)), col: '', pin: false, updated: Date.now() };
  ctx.data.notes.push(n); ctx.persist(); if (ctx.ui && ctx.ui.tab === 'catatan') ctx.render();
  return n;
}
export function removeNote(ctx, id) {
  const i = ctx.data.notes.findIndex((x) => x.id === id); if (i < 0) return false;
  ctx.data.notes.splice(i, 1); ctx.persist(); if (ctx.ui && ctx.ui.tab === 'catatan') ctx.render();
  return true;
}

// ---- Rev 219: note.append
export const NOTE_HTML_MAX = 200000; // batas isi satu catatan sesudah ditambah (huruf HTML); lebih dari ini ditolak
export function noteLabel(n) {
  const t = String((n && n.title) || '').trim() || String((n && n.text) || '').split('\n').find((l) => l.trim()) || '';
  return t.replace(/\s+/g, ' ').trim().slice(0, 50) || 'Tanpa judul';
}
// Catatan biasa terbaru (maks. `limit`) sebagai calon tujuan. Tidak pernah memuat `priv` atau `trash`.
export function appendableNotes(ctx, limit = 30) {
  if (!ctx || !ctx.data || !Array.isArray(ctx.data.notes)) return [];
  return ctx.data.notes.filter((n) => n && n.id).slice().sort((a, b) => (b.updated || 0) - (a.updated || 0)).slice(0, limit);
}
// Tambah draft ke akhir catatan `id`. Hasil {prev} (untuk Urungkan) atau null bila catatan tak ada / terlalu besar / draft kosong.
export function appendNote(ctx, id, draft) {
  if (!ctx || !ctx.data || !Array.isArray(ctx.data.notes) || !draft || !draft.text) return null;
  const n = ctx.data.notes.find((x) => x && x.id === id); if (!n) return null;
  const base = String(n.html || '') || (n.text ? sharedToHtml(String(n.text)) : '');
  const html = sanitize(base + (base ? '<div><br></div>' : '') + (draft.html || sharedToHtml(draft.text)));
  if (html.length > NOTE_HTML_MAX) return null;
  const prev = { text: n.text, html: n.html, updated: n.updated };
  n.html = html; n.text = (n.text ? String(n.text) + '\n\n' : '') + draft.text; n.updated = Date.now();
  ctx.persist(); if (ctx.ui && ctx.ui.tab === 'catatan') ctx.render();
  return { prev };
}
export function restoreNote(ctx, id, prev) {
  const n = ctx.data.notes.find((x) => x && x.id === id); if (!n || !prev) return false;
  n.text = prev.text; n.html = prev.html; n.updated = prev.updated;
  ctx.persist(); if (ctx.ui && ctx.ui.tab === 'catatan') ctx.render();
  return true;
}

// ---- Rev 222: task.create
export const TASK_MAX = 10, TASK_TITLE_MAX = 120; // maks. 10 aksi per usulan (kontrak 27.7); batas judul sama dengan kolom judul tugas
export const TASK_SCOPES = [['hari', 'Fokus'], ['minggu', 'Target'], ['bulan', 'Rencana']]; // hanya lingkup tugas (Kebiasaan sengaja tidak termasuk)
const cleanTitle = (v) => plainInline(String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ')).slice(0, TASK_TITLE_MAX).trim(); // Rev 227: tanda tebal/miring/<i> dibuang lewat pengurai yang sama
// Balasan AI -> daftar judul usulan (maks. TASK_MAX). Butir daftar (-, *, bullet, 1., 1), [ ]) dipakai; bila tak ada butir, satu baris pendek dipakai apa adanya; selain itu kosong.
export function taskDrafts(raw) {
  const lines = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').split('\n'), out = [];
  for (const l of lines) {
    const m = l.match(/^\s*(?:[-*\u2022]|\d{1,2}[.)])\s+(?:\[[ xX]?\]\s*)?(.+)$/); if (!m) continue;
    const t = cleanTitle(m[1]); if (t && !out.some((x) => x.toUpperCase() === t.toUpperCase())) out.push(t);
    if (out.length >= TASK_MAX) break;
  }
  if (!out.length) { const one = String(raw == null ? '' : raw).trim(); if (one && !one.includes('\n') && one.length <= TASK_TITLE_MAX) { const t = cleanTitle(one); if (t) out.push(t); } }
  return out;
}
// Buat tugas baru di lingkup `scope`. -> daftar id yang dibuat, atau null bila lingkup tak sah / tak ada judul sah.
export function createTasks(ctx, titles, scope, rem = null) { // Rev 229: `rem` = {at, repeat} opsional (dipakai createReminders)
  if (!ctx || !ctx.data || !Array.isArray(ctx.data.tasks) || !TASK_SCOPES.some((x) => x[0] === scope) || !Array.isArray(titles)) return null;
  const seen = new Set(), made = [];
  for (const raw of titles) {
    const t = cleanTitle(raw).toUpperCase(); if (!t || seen.has(t)) continue; seen.add(t);
    made.push(rem ? { id: newId(), title: t, done: false, pri: 0, due: '', scope, reminder: { at: rem.at, repeat: rem.repeat } } : { id: newId(), title: t, done: false, pri: 0, due: '', scope });
    if (made.length >= TASK_MAX) break;
  }
  if (!made.length) return null;
  made.forEach((x) => ctx.data.tasks.push(x)); ctx.persist(); if (ctx.ui && ctx.ui.tab === 'tugas') ctx.render();
  return made.map((x) => x.id);
}
export function removeTasks(ctx, ids) {
  if (!ctx || !ctx.data || !Array.isArray(ctx.data.tasks) || !Array.isArray(ids)) return 0;
  const set = new Set(ids); let n = 0; // hapus di tempat (larik yang sama), supaya rujukan lama ke `data.tasks` tidak basi
  for (let i = ctx.data.tasks.length - 1; i >= 0; i--) { const x = ctx.data.tasks[i]; if (x && set.has(x.id)) { if (x.reminder) cancelTaskAlarms(x); ctx.data.tasks.splice(i, 1); n++; } }
  if (n) { ctx.persist(); if (ctx.ui && ctx.ui.tab === 'tugas') ctx.render(); }
  return n;
}

// ---- Rev 229: reminder.set = jadikan butir daftar di balasan AI sebagai TUGAS yang punya PENGINGAT (alarm lewat jalur pengingat tugas yang sudah ada). Waktu dipilih pengguna; tanpa tebakan waktu dari teks.
export const REM_MIN_MS = 60000, REM_MAX_MS = 366 * 24 * 3600 * 1000;
// Waktu sah = angka, paling cepat 1 menit lagi, paling lambat sekitar setahun. Selain itu 0.
export function cleanRemindAt(at, now = Date.now()) { const n = Number(at); return Number.isFinite(n) && n >= now + REM_MIN_MS && n <= now + REM_MAX_MS ? Math.round(n) : 0; }
// Pilihan cepat: 1 jam lagi, sore ini 17:00 (bila masih > 30 menit lagi), besok 08:00, besok 17:00. -> [{label, at}]
export function remindPresets(now = Date.now()) {
  const at = (add, h) => { const d = new Date(now); d.setDate(d.getDate() + add); d.setHours(h, 0, 0, 0); return d.getTime(); };
  const out = [{ label: '1 jam lagi', at: Math.ceil((now + 3600000) / 60000) * 60000 }];
  if (at(0, 17) > now + 1800000) out.push({ label: 'Sore ini 17:00', at: at(0, 17) });
  out.push({ label: 'Besok 08:00', at: at(1, 8) }, { label: 'Besok 17:00', at: at(1, 17) });
  return out;
}
export const REMIND_REPEATS = [['once', 'Sekali'], ['daily', 'Tiap hari']];
// -> {ids, results} atau null (waktu/lingkup/judul tidak sah; tidak ada yang berubah). `results` = hasil scheduleReminder per tugas (untuk memberi tahu pengguna).
export function createReminders(ctx, titles, scope, at, repeat, now = Date.now()) {
  const t = cleanRemindAt(at, now); if (!t) return null;
  const rep = repeat === 'daily' ? 'daily' : 'once';
  const ids = createTasks(ctx, titles, scope, { at: t, repeat: rep }); if (!ids || !ids.length) return null;
  const results = ids.map((id) => ctx.data.tasks.find((x) => x && x.id === id)).filter(Boolean).map((x) => scheduleReminder('task', x, now));
  return { ids, results };
}
// Kalimat hasil untuk toast.
export function remindSummary(n, results) {
  const bad = results.find((r) => r && r.ok === false);
  if (bad && bad.reason === 'permission') return n + ' pengingat dibuat, tapi izin notifikasi belum aktif.';
  if (bad && bad.reason === 'unavailable') return n + ' pengingat tersimpan; alarm hanya berbunyi di aplikasi HP.';
  if (bad) return n + ' pengingat tersimpan, tapi alarm gagal dijadwalkan.';
  if (results.some((r) => r && r.warning === 'inexact_alarm')) return n + ' pengingat dibuat; bisa terlambat karena izin alarm tepat belum aktif.';
  return n + ' pengingat dibuat.';
}

// ---- Rev 236 / Tahap 7c: tautkan tugas yang BARU dibuat AI ke satu proyek aktif (pilihan pengguna). Hanya menambah id ke `project.tasks`; tidak mengubah tugas lain, catatan, atau proyek lain.
export function activeProjects(ctx) {
  const a = ctx && ctx.data && Array.isArray(ctx.data.projects) ? ctx.data.projects : [];
  return a.filter((p) => p && p.id && p.status === 'aktif').slice().sort((x, y) => (y.at || 0) - (x.at || 0));
}
// -> { linked, skipped } atau null (proyek tidak ada / bukan aktif). Tautan yang tidak muat (batas 100) dilewati dan dihitung di `skipped`.
export function linkTasksToProject(ctx, projectId, ids) {
  if (!ctx || !ctx.data || !Array.isArray(ids)) return null;
  const p = activeProjects(ctx).find((x) => x.id === projectId); if (!p) return null;
  let linked = 0, skipped = 0;
  for (const id of ids) { if (Array.isArray(p.tasks) && p.tasks.includes(id)) continue; /* sudah tertaut: biarkan, urutan tidak berubah */ if (toggleProjectLink(p, 'tasks', id) === 'added') linked++; else skipped++; }
  if (linked) ctx.persist();
  return { linked, skipped };
}
// Urungkan: buang id tugas dari semua proyek (tugasnya sendiri dihapus oleh removeTasks).
export function unlinkTasks(ctx, ids) {
  if (!ctx || !ctx.data || !Array.isArray(ctx.data.projects) || !Array.isArray(ids)) return 0;
  const set = new Set(ids); let n = 0;
  for (const p of ctx.data.projects) { if (!p || !Array.isArray(p.tasks)) continue; const keep = p.tasks.filter((id) => !set.has(id)); n += p.tasks.length - keep.length; p.tasks = keep; }
  if (n) ctx.persist();
  return n;
}
