// Rev 306b / Kelimaa AI LAMPIRAN CATATAN, bagian B: UI (pemilih catatan, pratinjau teks yang dikirim, chip lampiran). Mesinnya ada di lampiran.js (murni); modul ini hanya menggambar dan memanggil mesin.
// Aturan: teks catatan HANYA lewat node teks (h() + textContent), tidak pernah HTML mentah. Catatan Privat dan sampah tidak pernah muncul karena attachable() tidak membacanya. Tidak ada yang disimpan di sini (pilihan hidup di memori layar chat).
import { h, ico, PATH, toast } from '../ui.js';
import { attachable, toggleAtt, buildAttachment, budgetFor, estTokens, attSummary, ATT_MAX_NOTES, ATT_NOTE_MAX } from './lampiran.js';

export const I_KLIP = 'M20 11.5l-8.2 8.2a5 5 0 01-7.1-7.1l8.5-8.5a3.3 3.3 0 014.7 4.7l-8.5 8.5a1.7 1.7 0 01-2.4-2.4l7.8-7.8';
const num = (n) => Number(n).toLocaleString('id-ID');
export const tokText = (chars) => '\u2248 ' + num(estTokens(chars)) + ' token';

// Kata kunci pesan galat dari Worker LAMA (batas 4000 huruf per pesan) -> petunjuk yang jelas.
export const WORKER_LAMA = /maks\.\s*4000 huruf|terlalu besar/i;
export const pesanWorkerLama = 'Worker kamu masih versi lama dan menolak lampiran (batas pesannya masih 4000 huruf). Tempel ulang worker.mjs terbaru di Cloudflare lalu Deploy, atau lepas lampirannya dulu.';

// Pratinjau: teks PERSIS yang ditempel di depan pesan (belum ada yang dikirim).
export function bukaPratinjau({ data, ids, typedLen = 0, ctxLen = 0 }) {
  const ab = buildAttachment(data, ids, { total: budgetFor(typedLen, ctxLen) });
  const o = h('div', { class: 'ov dlgov kai-tulis' }), tutup = () => o.remove();
  o.addEventListener('click', (e) => { if (e.target === o) tutup(); });
  o.append(h('div', { class: 'sheet dlg kd-sheet' },
    h('h3', {}, 'Lampiran yang dikirim'),
    h('p', { class: 'sub' }, ab.ok ? attSummary(ab.items) + ' \u00b7 ' + num(ab.chars) + ' huruf (' + tokText(ab.chars) + '). Teks ini ditempel di depan pesanmu, dan dibaca ulang dari catatan tiap kali kirim. Belum ada yang dikirim.' : ab.msg),
    ab.ok ? h('div', { class: 'kai-tv' }, ab.text) : null,
    ab.ok && ab.cut ? h('p', { class: 'kd-info' }, 'Catatan yang panjang dipotong di batas kata; bagian akhirnya tidak ikut.') : null,
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: tutup }, 'Tutup'))));
  document.body.append(o);
}

// Pemilih catatan: pencarian judul/isi, centang maks. ATT_MAX_NOTES, ukuran per catatan, jumlah token perkiraan. onApply(ids) dipanggil saat "Lampirkan"/"Selesai".
export function bukaPemilih({ data, ids, typedLen = 0, ctxLen = 0, onApply }) {
  let sel = (Array.isArray(ids) ? ids : []).map(String), q = '';
  const o = h('div', { class: 'ov dlgov kai-tulis' }), tutup = () => o.remove();
  const list = h('div', { class: 'kd-list lp-list', role: 'group', 'aria-label': 'Pilih catatan untuk dilampirkan' }), info = h('p', { class: 'kd-info' });
  const cari = h('input', { type: 'search', class: 'in lp-q', placeholder: 'Cari judul atau isi\u2026', 'aria-label': 'Cari catatan', autocomplete: 'off', maxlength: '60' });
  const lihat = h('button', { type: 'button', class: 'btn line', onclick: () => bukaPratinjau({ data, ids: sel, typedLen, ctxLen }) }, 'Pratinjau');
  const ok = h('button', { type: 'button', class: 'btn', onclick: () => { tutup(); onApply(sel.slice()); } }, 'Lampirkan');
  const hitung = () => {
    const ab = sel.length ? buildAttachment(data, sel, { total: budgetFor(typedLen, ctxLen) }) : null;
    info.classList.toggle('on', sel.length > 0);
    info.textContent = !sel.length ? 'Pilih sampai ' + ATT_MAX_NOTES + ' catatan. Judul dan isinya ikut terkirim di setiap pesan sampai kamu lepas lampirannya. Catatan Privat dan sampah tidak pernah ikut.'
      : sel.length + ' dari ' + ATT_MAX_NOTES + ' dipilih' + (ab && ab.ok ? ' \u00b7 ' + num(ab.chars) + ' huruf (' + tokText(ab.chars) + ')' + (ab.cut ? ' \u00b7 sebagian dipotong' : '') : ab ? ' \u00b7 ' + ab.msg : '');
    ok.textContent = sel.length ? 'Lampirkan (' + sel.length + ')' : 'Selesai';
    lihat.disabled = !sel.length;
  };
  const gambar = () => {
    list.textContent = '';
    const rows = attachable(data, q);
    if (!rows.length) { list.append(h('p', { class: 'kd-info' }, q.trim() ? 'Tidak ada catatan yang cocok.' : 'Belum ada catatan yang bisa dilampirkan.')); return; }
    rows.forEach((r) => {
      const on = sel.includes(r.id);
      list.append(h('button', { type: 'button', class: 'kd-row lp-row' + (on ? ' on' : ''), role: 'checkbox', 'aria-checked': String(on), 'data-id': r.id, onclick: (ev) => {
        const t = toggleAtt(sel, r.id); if (!t.ok) { toast(t.msg); return; }
        sel = t.ids; const b = ev.currentTarget, now = sel.includes(r.id); b.classList.toggle('on', now); b.setAttribute('aria-checked', String(now)); hitung();
      } },
      h('span', { class: 'lp-ck', 'aria-hidden': 'true' }, ico(PATH.tugas)),
      h('span', { class: 'kd-tx' }, h('b', {}, (r.pin ? '\u2022 ' : '') + r.title), h('small', {}, r.snip || '(tanpa isi)'),
        h('small', { class: 'lp-meta' }, num(r.len) + ' huruf' + (r.len > ATT_NOTE_MAX ? ' \u00b7 dipotong saat dikirim' : '') + (r.inBody ? ' \u00b7 cocok di isi' : '')))));
    });
  };
  let tmr = 0; cari.addEventListener('input', () => { clearTimeout(tmr); tmr = setTimeout(() => { q = cari.value; gambar(); }, 120); });
  o.addEventListener('click', (e) => { if (e.target === o) tutup(); });
  o.append(h('div', { class: 'sheet dlg kd-sheet lp-sheet' },
    h('div', { class: 'kd-head' }, h('span', { class: 'kd-hi' }, ico(I_KLIP)), h('div', { class: 'kd-ht' }, h('h3', {}, 'Lampirkan catatan'), h('p', { class: 'sub' }, 'AI membaca judul dan isi catatan yang kamu pilih, seperti melampirkan berkas.'))),
    cari, list, info,
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: tutup }, 'Batal'), lihat, ok)));
  document.body.append(o); gambar(); hitung();
}

// Baris chip di atas kolom ketik. paint(items) dengan items = [{id, title}] (kosong = baris hilang). Ketuk chip = pratinjau, ketuk x = lepas.
export function buatBarisChip({ onLihat, onLepas }) {
  const el = h('div', { class: 'lp-bar', role: 'group', 'aria-label': 'Catatan yang dilampirkan' });
  const paint = (items) => {
    el.textContent = '';
    (Array.isArray(items) ? items : []).forEach((x) => el.append(h('span', { class: 'lp-chip' },
      h('button', { type: 'button', class: 'lp-o', 'aria-label': 'Lihat lampiran ' + x.title, onclick: onLihat }, ico(PATH.catatan), h('span', {}, x.title)),
      h('button', { type: 'button', class: 'lp-x', 'aria-label': 'Lepas lampiran ' + x.title, onclick: () => onLepas(x.id) }, ico(PATH.close)))));
  };
  return { el, paint };
}

// Chip kecil (hanya tampilan) di atas teks balon pengguna; x = [{id, title}] dari riwayat (rujukan saja, tanpa isi).
export function chipBalon(att) {
  const a = Array.isArray(att) ? att : []; if (!a.length) return null;
  return h('div', { class: 'lp-bub' }, a.map((x) => h('span', { class: 'lp-bc' }, ico(PATH.catatan), h('span', {}, x.title))));
}
