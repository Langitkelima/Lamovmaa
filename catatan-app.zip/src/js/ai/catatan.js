// Rev 301a / Kelimaa AI untuk CATATAN, bagian A: mesin murni (logika saja, TANPA UI, TANPA DOM, TANPA penyimpanan, TANPA sanitize).
// Berbeda dari tulis.js (Rev 217: olah potongan teks yang DIBLOK pengguna), mesin ini mengolah SATU CATATAN UTUH: Ringkas, Usul judul, Rapikan tulisan.
// Yang dikirim ke Worker HANYA instruksi + judul + isi teks catatan itu (satu pesan, tanpa riwayat chat, tanpa data aplikasi lain). Catatan Privat DITOLAK di sini (penjaga ke-2 selain notes.js).
// Hasil AI tidak pernah langsung menulis ke catatan: `planEdit` hanya menyusun rencana (patch + kebalikannya); UI (301b) wajib menampilkan pratinjau dan meminta Terapkan; `undoPlan` mengembalikan hanya bila catatan belum berubah lagi.
import { kirimChat, chatOpts, CHAT_MAX_MSG } from './sambungan.js';
import { cleanResult } from './tulis.js';
import { sharedToHtml } from '../logic.js';

export const NOTE_MAX = 3000; // huruf isi yang dikirim; sisakan ruang instruksi di bawah batas 4000 huruf per pesan Worker
export const TITLE_MAX = 80;  // panjang maksimal satu usulan judul
// id, label, jenis pekerjaan Worker (harus ada di TASK_CHOICES), mode hasil, instruksi. Isi tabel = USULAN AI (asumsi), bisa diubah tanpa menyentuh Worker.
// mode: 'ringkas' = ringkasan disisipkan di catatan | 'judul' = daftar usulan judul, pengguna memilih satu | 'rapikan' = isi catatan diganti (hanya catatan teks biasa)
export const NOTE_ACTIONS = [
  { id: 'ringkas', label: 'Ringkas', task: 'utility.small', mode: 'ringkas', ins: 'Ringkas catatan berikut menjadi 2 sampai 4 kalimat pendek dengan semua poin pentingnya tetap ada. Jangan menambah fakta yang tidak ada di catatan.' },
  { id: 'judul', label: 'Usul judul', task: 'utility.small', mode: 'judul', ins: 'Beri 5 usulan judul singkat (maksimal 60 huruf) untuk catatan berikut. Tulis satu judul per baris, bernomor 1 sampai 5.' },
  { id: 'rapikan', label: 'Rapikan tulisan', task: 'utility.small', mode: 'rapikan', ins: 'Rapikan tulisan catatan berikut: perbaiki ejaan, tanda baca, dan kalimat yang janggal tanpa mengubah makna, tanpa menambah atau menghapus isi. Pertahankan urutan isi dan pemisah baris.' },
];
const TAIL = 'Balas HANYA dengan hasilnya saja, tanpa pembuka, penjelasan, atau tanda kutip pembungkus. Jangan menyebut bahwa kamu AI.';
const CTRL = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g;
const clean = (s) => String(s == null ? '' : s).replace(/\r\n?/g, '\n').replace(CTRL, '');

// Teks biasa dari HTML catatan (editor memakai <div>/<br>). Hanya dipakai bila note.text kosong. Tanpa DOM.
export function htmlToText(html) {
  const s = String(html == null ? '' : html).replace(/<br\s*\/?>/gi, '\n').replace(/<\/div>\s*<div[^>]*>/gi, '\n').replace(/<[^>]*>/g, '');
  return clean(s.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')).trim();
}
// true bila isi catatan HANYA <div> polos, </div>, <br>: tidak ada tebal/miring/tautan/tabel/gambar/kotak centang/bagian lipat/blok sisipan/lembar kerja yang bisa hilang.
export function isPlainHtml(html) {
  const s = String(html == null ? '' : html).replace(/<\/?div>|<br\s*\/?>/gi, ''); // hanya <div> TANPA atribut: blok sisipan/centang/lipat/lembar memakai div ber-atribut
  return !/<[a-z!\/]/i.test(s);
}
const eq = (a, b) => String(a == null ? '' : a) === String(b == null ? '' : b);

// -> { ok:true, title, body, cut, plain } | { ok:false, msg }. `kind` = 'notes' | 'priv' (Catatan Privat ditolak).
export function noteInput(note, actionId, kind = 'notes') {
  const a = NOTE_ACTIONS.find((x) => x.id === actionId); if (!a) return { ok: false, msg: 'Aksi catatan tidak dikenal.' };
  if (kind === 'priv' || (note && note.priv)) return { ok: false, msg: 'Catatan Privat tidak dikirim ke AI.' };
  if (!note || typeof note !== 'object') return { ok: false, msg: 'Catatan tidak ditemukan.' };
  const title = clean(note.title).replace(/\n+/g, ' ').trim().slice(0, 200);
  const full = clean(note.text).trim() || htmlToText(note.html);
  if (!full) return { ok: false, msg: 'Catatan masih kosong. Tulis isinya dulu.' };
  const plain = isPlainHtml(note.html);
  if (a.mode === 'rapikan') {
    if (!plain) return { ok: false, msg: 'Catatan ini punya format atau blok (tebal, tabel, gambar, kotak centang, dll.). Blok teks biasa lalu pakai Tulis AI agar tidak ada yang hilang.' };
    if (full.length > NOTE_MAX) return { ok: false, msg: 'Catatan terlalu panjang untuk dirapikan sekaligus (maks. ' + NOTE_MAX.toLocaleString('id-ID') + ' huruf). Blok bagian yang lebih pendek lalu pakai Tulis AI.' };
    return { ok: true, title, body: full, cut: false, plain };
  }
  if (full.length <= NOTE_MAX) return { ok: true, title, body: full, cut: false, plain };
  const head = full.slice(0, NOTE_MAX), sp = Math.max(head.lastIndexOf('\n'), head.lastIndexOf(' '));
  return { ok: true, title, body: (sp > NOTE_MAX * 0.8 ? head.slice(0, sp) : head).trim(), cut: true, plain }; // ringkas/judul boleh membaca bagian awal saja; `cut` WAJIB diberitahukan di UI
}
// -> { ok, content, task, label, mode, cut, plain, title, body } | { ok:false, msg }
export function buildNotePrompt(actionId, note, kind = 'notes') {
  const a = NOTE_ACTIONS.find((x) => x.id === actionId), inp = noteInput(note, actionId, kind); if (!inp.ok) return inp;
  const content = a.ins + ' ' + TAIL + '\n\n---\n' + (inp.title && a.mode !== 'rapikan' ? 'Judul saat ini: ' + inp.title + '\n\n' : '') + inp.body;
  if (content.length > CHAT_MAX_MSG) return { ok: false, msg: 'Catatan terlalu panjang untuk aksi ini.' };
  return { ok: true, content, task: a.task, label: a.label, mode: a.mode, cut: inp.cut, plain: inp.plain, title: inp.title, body: inp.body };
}

// Usulan judul: satu per baris, nomor/butir/tanda kutip/tebal dibuang, kembar (tak peka huruf) dibuang, maks. 5.
export function parseTitles(raw) {
  const out = [], seen = new Set();
  for (const ln of cleanResult(raw).split('\n')) {
    let t = ln.replace(/^\s*(?:\d{1,2}\s*[.)\-:]|[-*\u2022])\s*/, '').replace(/\*\*|__/g, '').replace(/^["'\u201c\u2018]+|["'\u201d\u2019]+$/g, '').replace(/\s+/g, ' ').trim();
    if (t.length > TITLE_MAX) t = t.slice(0, TITLE_MAX - 1).trim() + '\u2026';
    const k = t.toLowerCase(); if (!t || seen.has(k)) continue;
    seen.add(k); out.push(t); if (out.length >= 5) break;
  }
  return out;
}
// -> { ok:true, mode, label, titles | text, warn?, same? } | { ok:false, msg }. `note` dipakai untuk memeriksa hasil Rapikan terhadap aslinya.
export function parseNoteResult(actionId, raw, note) {
  const a = NOTE_ACTIONS.find((x) => x.id === actionId); if (!a) return { ok: false, msg: 'Aksi catatan tidak dikenal.' };
  if (a.mode === 'judul') { const titles = parseTitles(raw); return titles.length ? { ok: true, mode: 'judul', label: a.label, titles } : { ok: false, msg: 'AI tidak memberi usulan judul. Coba lagi.' }; }
  const text = cleanResult(raw); if (!text) return { ok: false, msg: 'AI tidak memberi hasil. Coba lagi.' };
  const res = { ok: true, mode: a.mode, label: a.label, text };
  if (a.mode === 'rapikan') {
    const orig = note ? (clean(note.text).trim() || htmlToText(note.html)) : '';
    if (orig) {
      if (text === orig) res.same = true;
      else if (text.length < orig.length * 0.5 || text.length > orig.length * 1.6) res.warn = 'Panjang hasil jauh berbeda dari catatan asli. Periksa baik-baik sebelum diterapkan.';
    }
  }
  return res;
}

// Rencana perubahan. -> { ok:true, mode, label, patch, before, summary } | { ok:false, msg }
// patch/before hanya memuat kolom yang berubah (title | html + text). `before` = nilai kolom SAAT rencana dibuat (dipakai memeriksa catatan belum berubah dan untuk Urungkan).
// opts: { index } (judul: nomor usulan), { pos: 'atas' | 'bawah' } (ringkas, bawaan atas). Isi HTML selalu lewat sharedToHtml (escape); UI tetap WAJIB sanitize sebelum menyimpan.
export function planEdit(note, parsed, opts = {}, kind = 'notes') {
  if (kind === 'priv' || (note && note.priv)) return { ok: false, msg: 'Catatan Privat tidak dikirim ke AI.' };
  if (!note || typeof note !== 'object' || !parsed || !parsed.ok) return { ok: false, msg: 'Tidak ada hasil untuk diterapkan.' };
  const html0 = String(note.html || ''), text0 = clean(note.text) || htmlToText(html0), base = html0 || (text0 ? sharedToHtml(text0) : '');
  if (parsed.mode === 'judul') {
    const i = Number.isInteger(opts.index) ? opts.index : 0, t = parsed.titles && parsed.titles[i];
    if (!t) return { ok: false, msg: 'Pilih salah satu usulan judul.' };
    return { ok: true, mode: 'judul', label: parsed.label, patch: { title: t }, before: { title: String(note.title || '') }, summary: 'Judul diganti.' };
  }
  const before = { html: html0, text: String(note.text == null ? '' : note.text) };
  if (parsed.mode === 'ringkas') {
    const blok = 'Ringkasan\n' + parsed.text, bawah = opts.pos === 'bawah';
    const text = bawah ? (text0 ? text0 + '\n\n' + blok : blok) : (text0 ? blok + '\n\n' + text0 : blok);
    const html = bawah ? base + (base ? '<div><br></div>' : '') + sharedToHtml(blok) : sharedToHtml(blok) + (base ? '<div><br></div>' + base : '');
    return { ok: true, mode: 'ringkas', label: parsed.label, patch: { html, text }, before, summary: 'Ringkasan disisipkan di ' + (bawah ? 'bawah' : 'atas') + ' catatan.' };
  }
  if (parsed.mode === 'rapikan') {
    if (!isPlainHtml(html0)) return { ok: false, msg: 'Catatan punya format atau blok, jadi tidak bisa diganti seluruhnya.' };
    if (parsed.same) return { ok: false, msg: 'Tulisan sudah rapi, tidak ada yang perlu diganti.' };
    return { ok: true, mode: 'rapikan', label: parsed.label, patch: { html: sharedToHtml(parsed.text), text: parsed.text }, before, summary: 'Tulisan catatan dirapikan.' };
  }
  return { ok: false, msg: 'Aksi catatan tidak dikenal.' };
}
const fieldsOf = (p) => Object.keys(p).filter((k) => k === 'title' || k === 'html' || k === 'text');
// Salinan catatan baru dengan patch dipasang. Gagal bila catatan sudah berubah sejak rencana dibuat (mis. diketik selagi menunggu AI). Tidak mengubah catatan asli.
export function applyPlan(note, plan, { now = Date.now() } = {}) {
  if (!note || !plan || !plan.ok || !plan.patch || !plan.before) return { ok: false, msg: 'Rencana tidak sah.' };
  if (fieldsOf(plan.before).some((k) => !eq(note[k], plan.before[k]))) return { ok: false, msg: 'Catatan berubah selagi menunggu AI, jadi hasilnya tidak diterapkan. Ulangi dari awal.' };
  const next = { ...note }; fieldsOf(plan.patch).forEach((k) => { next[k] = plan.patch[k]; }); next.updated = now;
  return { ok: true, note: next };
}
// Urungkan: hanya bila kolom yang diubah AI belum berubah lagi (supaya ketikan sesudahnya tidak tertimpa).
export function canUndo(note, plan) { return !!(note && plan && plan.ok && plan.patch && fieldsOf(plan.patch).every((k) => eq(note[k], plan.patch[k]))); }
export function undoPlan(note, plan, { now = Date.now() } = {}) {
  if (!canUndo(note, plan)) return { ok: false, msg: 'Catatan sudah berubah sejak AI diterapkan, jadi Urungkan dibatalkan agar ketikanmu tidak tertimpa.' };
  const next = { ...note }; fieldsOf(plan.before).forEach((k) => { next[k] = plan.before[k]; }); next.updated = now;
  return { ok: true, note: next };
}

// Satu panggilan ke Worker. Tidak pernah melempar. -> { ok:true, parsed, label, mode, cut, provider, model } | { ok:false, msg }
export async function olahCatatan(conn, cfg, actionId, note, http, kind = 'notes') {
  const p = buildNotePrompt(actionId, note, kind); if (!p.ok) return p;
  let res; try { res = await kirimChat(conn, [{ role: 'user', content: p.content }], http, { ...chatOpts(cfg), task: p.task }); } catch (_) { return { ok: false, msg: 'Kesalahan tak terduga.' }; }
  if (!res.ok) return res;
  const parsed = parseNoteResult(actionId, res.text, note); if (!parsed.ok) return parsed;
  return { ok: true, parsed, label: p.label, mode: p.mode, cut: p.cut, provider: res.provider, model: res.model };
}
