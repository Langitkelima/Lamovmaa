// Rev 309a: PENCATAT RIWAYAT TOKEN Kelimaa AI (logika murni + penyimpanan kecil, tanpa DOM, tanpa UI; UI = tab Riwayat token di Rev 309b).
// Tiap balasan BERHASIL dicatat: { t: waktu (ms), m: awal pesan (maks. 40 huruf), in, out, est: true bila perkiraan, src: sumber yang ikut }.
// Kunci terpisah `kelimaa_ai_riwayat` (TIDAK ikut cadangan). Simpan 30 hari atau maks. 200 entri. Isi balasan TIDAK disimpan.
import { estTokens } from './lampiran.js';
export const RW_KEY = 'kelimaa_ai_riwayat';
export const RW_MAX = 200, RW_DAYS = 30, RW_MSG = 40, RW_VER = 1;
const SRC_OK = ['tugas', 'proyek', 'lampiran', 'ocr']; // Rev 353: 'ocr' = baca teks dari foto
const num = (x) => (typeof x === 'number' && Number.isFinite(x) && x >= 0 ? Math.floor(x) : null);
// `usage` Worker = { in, out }; kosong atau 0 = tidak ada laporan penyedia.
export function cleanUsage(u) { if (!u || typeof u !== 'object') return null; const a = num(u.in), b = num(u.out); return a === null || b === null || a + b === 0 ? null : { in: a, out: b }; }
export const awalPesan = (s) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().slice(0, RW_MSG);
// Bangun satu entri. Bila `usage` kosong, pakai perkiraan estTokens (kirim = huruf yang dikirim, balas = huruf balasan) dan tandai est.
export function buatEntri({ now, pesan, usage, kirimChars, balasChars, sumber }) {
  const t = num(now); if (t === null) return null;
  const u = cleanUsage(usage), est = !u, tin = u ? u.in : estTokens(kirimChars), tout = u ? u.out : estTokens(balasChars);
  const src = []; for (const s of Array.isArray(sumber) ? sumber : []) if (SRC_OK.includes(s) && !src.includes(s)) src.push(s);
  return { t, m: awalPesan(pesan), in: tin, out: tout, ...(est ? { est: true } : {}), src };
}
// Rapikan daftar: buang entri rusak dan yang lebih tua dari 30 hari, urut lama -> baru, simpan 200 terbaru.
export function rapikan(list, now) {
  const batas = (num(now) || 0) - RW_DAYS * 86400000, out = [];
  for (const e of Array.isArray(list) ? list : []) {
    if (!e || typeof e !== 'object') continue; const t = num(e.t), a = num(e.in), b = num(e.out); if (t === null || a === null || b === null || t < batas) continue;
    const src = []; for (const s of Array.isArray(e.src) ? e.src : []) if (SRC_OK.includes(s) && !src.includes(s)) src.push(s);
    out.push({ t, m: awalPesan(e.m), in: a, out: b, ...(e.est === true ? { est: true } : {}), src });
  }
  return out.sort((x, y) => x.t - y.t).slice(-RW_MAX);
}
export function muat(now, store = globalThis.localStorage) { try { const o = JSON.parse(store.getItem(RW_KEY) || 'null'); return o && o.v === RW_VER ? rapikan(o.list, now) : []; } catch (_) { return []; } }
export function catat(entri, now, store = globalThis.localStorage) {
  if (!entri) return { ok: false };
  try { const list = rapikan([...muat(now, store), entri], now); store.setItem(RW_KEY, JSON.stringify({ v: RW_VER, list })); return { ok: true, n: list.length }; } catch (_) { return { ok: false }; }
}
export function hapusSemua(store = globalThis.localStorage) { try { store.removeItem(RW_KEY); return { ok: true }; } catch (_) { return { ok: false }; } }
// Kunci hari lokal YYYY-MM-DD (untuk ringkasan dan grafik 7 hari di 309b).
export const hariKey = (t) => { const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
// Ringkasan: hari ini, 7 hari terakhir (termasuk hari ini), bulan ini; jumlah masuk + keluar; `est` = ada angka perkiraan di dalamnya.
export function ringkasan(list, now) {
  const d0 = new Date(now), awalHari = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate()).getTime(), awal7 = awalHari - 6 * 86400000, awalBulan = new Date(d0.getFullYear(), d0.getMonth(), 1).getTime();
  const z = () => ({ in: 0, out: 0, n: 0, est: false }), r = { hari: z(), minggu: z(), bulan: z() };
  const tambah = (k, e) => { k.in += e.in; k.out += e.out; k.n += 1; if (e.est) k.est = true; };
  for (const e of Array.isArray(list) ? list : []) { if (e.t >= awalHari) tambah(r.hari, e); if (e.t >= awal7) tambah(r.minggu, e); if (e.t >= awalBulan) tambah(r.bulan, e); }
  return r;
}
// Grafik 7 hari: larik 7 { key, total, est } dari 6 hari lalu sampai hari ini.
export function tujuhHari(list, now) {
  const d0 = new Date(now), out = [];
  for (let i = 6; i >= 0; i--) out.push({ key: hariKey(new Date(d0.getFullYear(), d0.getMonth(), d0.getDate() - i).getTime()), total: 0, est: false });
  for (const e of Array.isArray(list) ? list : []) { const k = hariKey(e.t), s = out.find((x) => x.key === k); if (s) { s.total += e.in + e.out; if (e.est) s.est = true; } }
  return out;
}
