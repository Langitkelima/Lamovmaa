// Rev 227: balasan AI tampil BERGAYA (tebal, miring, judul, daftar) tanpa tanda **, *, <i>.
// Satu pengurai MURNI (tanpa DOM) -> pohon sederhana, lalu tiga keluaran: toDom (layar chat, node DOM lewat createElement, tanpa HTML mentah), toHtml (isi catatan; di-escape, lalu tetap lewat sanitize), toPlain (salin / teks cadangan catatan, tanpa tanda).
// Rev 246: tabel Markdown (| a | b | + baris pemisah |---|) jadi blok 'table' (layar chat = tabel bergulir ke samping; catatan = tabel catatan biasa; salin = teks berpipa).
// Mengerti Markdown dan juga tag HTML yang kadang ikut keluar dari model (<i>, <b>, <u>, <s>, <br>). Tag lain tidak pernah dijalankan: hanya jadi teks atau dibuang.

const INL = [
  { re: /\*\*\*(?=\S)([\s\S]+?)(?<=\S)\*\*\*/, make: (m) => ({ t: 'b', c: [{ t: 'i', c: inl(m[1]) }] }) },
  { re: /`([^`\n]+)`/, make: (m) => ({ t: 'code', v: m[1] }) },
  { re: /\*\*(?=\S)([\s\S]+?)(?<=\S)\*\*/, make: (m) => ({ t: 'b', c: inl(m[1]) }) },
  { re: /(?<![\w_])__(?=\S)([\s\S]+?)(?<=\S)__(?![\w_])/, make: (m) => ({ t: 'b', c: inl(m[1]) }) },
  { re: /~~(?=\S)([\s\S]+?)(?<=\S)~~/, make: (m) => ({ t: 's', c: inl(m[1]) }) },
  { re: /<(b|strong|i|em|u|s|strike|del)>([\s\S]*?)<\/\1>/i, make: (m) => ({ t: TAG[m[1].toLowerCase()], c: inl(m[2]) }) },
  { re: /\*(?=[^\s*])([\s\S]*?[^\s*])\*(?!\*)/, make: (m) => ({ t: 'i', c: inl(m[1]) }) },
  { re: /(?<![\w_])_(?=[^\s_])([\s\S]*?[^\s_])_(?![\w_])/, make: (m) => ({ t: 'i', c: inl(m[1]) }) },
  { re: /\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/, make: (m) => ({ t: 'a', href: m[2], c: inl(m[1]) }) },
];
const TAG = { b: 'b', strong: 'b', i: 'i', em: 'i', u: 'u', s: 's', strike: 's', del: 's' };
const STRAY = /<\/?(?:b|strong|i|em|u|s|strike|del|br|p|span|div)\b[^>]*>/gi; // tag sisa yang tak berpasangan: dibuang, bukan ditampilkan

function inl(s, depth = 0) {
  const out = []; let rest = String(s);
  const push = (v) => { v = v.replace(STRAY, ''); if (v) out.push({ t: 'x', v }); };
  while (rest) {
    let best = null;
    if (depth < 8) for (const p of INL) { const m = p.re.exec(rest); if (m && (!best || m.index < best.m.index)) best = { m, p }; }
    if (!best) { push(rest); break; }
    if (best.m.index) push(rest.slice(0, best.m.index));
    out.push(best.p.make(best.m)); rest = rest.slice(best.m.index + best.m[0].length);
  }
  return out;
}
const inline = (s) => inl(String(s).replace(/<br\s*\/?>/gi, '\n'));

// ---- Tabel (Rev 246)
const T_MAXC = 20, T_MAXR = 200, BRK = '\u2028'; // BRK = penanda <br> di dalam sel (supaya tidak memecah baris tabel)
const splitRow = (line) => {
  let t = line.trim(); if (t.startsWith('|')) t = t.slice(1); if (t.endsWith('|') && !t.endsWith('\\|')) t = t.slice(0, -1);
  const out = []; let cur = '', code = false;
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (ch === '\\' && t[i + 1] === '|') { cur += '|'; i++; continue; }
    if (ch === '`') code = !code;
    if (ch === '|' && !code) { out.push(cur.trim()); cur = ''; continue; }
    cur += ch;
  }
  out.push(cur.trim()); return out;
};
const isSep = (line) => /^\s*\|?\s*:?-{1,}:?\s*(\|\s*:?-{1,}:?\s*)*\|?\s*$/.test(line) && line.includes('-') && line.includes('|');
const alignOf = (c) => { const l = c.startsWith(':'), r = c.endsWith(':'); return l && r ? 'c' : r ? 'r' : ''; };
const cellInl = (s) => { const parts = s.split(BRK), c = []; parts.forEach((p, k) => { if (k) c.push({ t: 'br' }); c.push(...inline(p)); }); return c; };
const plainRow = (r) => r.map((c) => plainI(c).replace(/\s*\n\s*/g, ' ').trim());

const LI = /^(\s*)([-*+\u2022]|\d{1,3}[.)])\s+(.*)$/;
// Teks mentah -> daftar blok. Blok: {k:'p',c} {k:'h',n,c} {k:'list',ord,start,items:[{d,c}]} {k:'q',c} {k:'pre',v} {k:'hr'}
export function parse(raw) {
  const lines = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').split('\n').map((l) => (l.includes('|') ? l.replace(/<br\s*\/?>/gi, BRK) : l)).join('\n').replace(/<br\s*\/?>/gi, '\n').split('\n');
  const blocks = []; let para = [], list = null, i = 0;
  const flush = () => { if (para.length) { const c = []; para.forEach((l, k) => { if (k) c.push({ t: 'br' }); c.push(...inline(l)); }); blocks.push({ k: 'p', c }); para = []; } };
  const endList = () => { list = null; };
  const nextNonBlank = (from) => { for (let j = from; j < lines.length; j++) if (lines[j].trim()) return lines[j]; return ''; };
  for (; i < lines.length; i++) {
    const line = lines[i], tr = line.trim();
    if (/^```/.test(tr)) { // blok kode
      flush(); endList(); const buf = []; i++;
      while (i < lines.length && !/^```/.test(lines[i].trim())) buf.push(lines[i++]);
      blocks.push({ k: 'pre', v: buf.join('\n') }); continue;
    }
    if (!tr) { flush(); if (list) { const nx = nextNonBlank(i + 1).match(LI); if (!nx || (/\d/.test(nx[2][0]) !== list.ord)) endList(); } continue; }
    if (tr.includes('|') && i + 1 < lines.length && isSep(lines[i + 1])) { // tabel Markdown: baris judul + baris pemisah + baris isi
      const hd = splitRow(tr), sp = splitRow(lines[i + 1]);
      if (hd.length === sp.length && hd.length >= 1) {
        flush(); endList(); const nc = Math.min(hd.length, T_MAXC), rows = []; i += 2;
        while (i < lines.length && lines[i].trim() && lines[i].includes('|') && rows.length < T_MAXR) { const cs = splitRow(lines[i]).slice(0, nc); while (cs.length < nc) cs.push(''); rows.push(cs.map(cellInl)); i++; }
        i--; blocks.push({ k: 'table', align: sp.slice(0, nc).map(alignOf), head: hd.slice(0, nc).map(cellInl), rows }); continue;
      }
    }
    let m;
    if ((m = tr.match(/^(#{1,6})\s+(.*?)\s*#*$/))) { flush(); endList(); blocks.push({ k: 'h', n: Math.min(m[1].length, 3), c: inline(m[2]) }); continue; }
    if (/^(?:-{3,}|\*{3,}|_{3,})$/.test(tr)) { flush(); endList(); blocks.push({ k: 'hr' }); continue; }
    if ((m = tr.match(/^>\s?(.*)$/))) { flush(); endList(); const prev = blocks[blocks.length - 1]; const c = inline(m[1]); if (prev && prev.k === 'q' && !prev.closed) { prev.c.push({ t: 'br' }, ...c); } else blocks.push({ k: 'q', c }); continue; }
    if ((m = line.match(LI))) {
      flush(); const ord = /\d/.test(m[2][0]), d = Math.min(Math.floor(m[1].replace(/\t/g, '  ').length / 2), 3);
      if (!list || list.ord !== ord) { list = { k: 'list', ord, start: ord ? parseInt(m[2], 10) : 1, items: [] }; blocks.push(list); }
      list.items.push({ d, c: inline(m[3].replace(/^\[[ xX]?\]\s+/, '')) }); continue;
    }
    if (list && /^\s{2,}\S/.test(line)) { const it = list.items[list.items.length - 1]; it.c.push({ t: 'br' }, ...inline(tr)); continue; } // lanjutan butir daftar
    endList(); para.push(tr);
  }
  flush();
  blocks.forEach((b) => { if (b.k === 'q') b.closed = true; });
  return blocks;
}

// ---- Teks biasa (salin, isi catatan.text, judul)
const plainI = (c) => c.map((n) => n.t === 'x' ? n.v : n.t === 'br' ? '\n' : n.t === 'code' ? n.v : n.t === 'a' ? plainI(n.c) + (plainI(n.c) === n.href ? '' : ' (' + n.href + ')') : plainI(n.c || [])).join('');
export const plainInline = (s) => plainI(inline(s)).replace(/\s+/g, ' ').trim();
export function toPlain(blocks) {
  return blocks.map((b) => {
    if (b.k === 'p' || b.k === 'h' || b.k === 'q') return plainI(b.c);
    if (b.k === 'pre') return b.v;
    if (b.k === 'hr') return '\u2014\u2014\u2014';
    if (b.k === 'table') return [b.head, ...b.rows].map((r) => plainRow(r).join(' | ')).join('\n');
    return b.items.map((it, n) => '  '.repeat(it.d) + (b.ord ? (b.start + n) + '. ' : '\u2022 ') + plainI(it.c)).join('\n');
  }).join('\n\n');
}

// ---- HTML catatan (string, di-escape; pemanggil WAJIB tetap melewatkan sanitize)
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const htmlI = (c) => c.map((n) => n.t === 'x' ? esc(n.v) : n.t === 'br' ? '<br>' : n.t === 'code' ? esc(n.v) : n.t === 'a' ? htmlI(n.c) + (plainI(n.c) === n.href ? '' : ' (' + esc(n.href) + ')') : '<' + n.t + '>' + htmlI(n.c) + '</' + n.t + '>').join('');
const BLANK = '<div><br></div>';
export function toHtml(blocks) {
  const parts = blocks.map((b) => {
    if (b.k === 'p') return '<div>' + htmlI(b.c) + '</div>';
    if (b.k === 'h') return '<div><b>' + htmlI(b.c) + '</b></div>';
    if (b.k === 'q') return '<blockquote>' + htmlI(b.c) + '</blockquote>';
    if (b.k === 'pre') return b.v.split('\n').map((l) => (l ? '<div>' + esc(l) + '</div>' : BLANK)).join('');
    if (b.k === 'hr') return '<div>\u2014\u2014\u2014</div>';
    if (b.k === 'table') { // tabel catatan biasa (sanitize catatan mengenali div.tbl-wrap > table, th/td, data-a c|r)
      const cell = (tg, c, k) => '<' + tg + (b.align[k] ? ' data-a="' + b.align[k] + '"' : '') + '>' + (htmlI(c) || '<br>') + '</' + tg + '>';
      const row = (r, tg) => '<tr>' + r.map((c, k) => cell(tg, c, k)).join('') + '</tr>';
      return '<div class="tbl-wrap"><table><tbody>' + row(b.head, 'th') + b.rows.map((r) => row(r, 'td')).join('') + '</tbody></table></div>';
    }
    const tag = b.ord ? 'ol' : 'ul';
    return '<' + tag + (b.ord && b.start !== 1 ? ' start="' + b.start + '"' : '') + '>' + b.items.map((it) => '<li>' + htmlI(it.c) + '</li>').join('') + '</' + tag + '>';
  });
  if (blocks.length && blocks[blocks.length - 1].k === 'table') parts.push(''); // ada baris kosong untuk kursor sesudah tabel
  return parts.join(BLANK);
}

// ---- Layar chat: node DOM saja. Tautan hanya digaris bawahi (ketukan di balasan = simpan ke Catatan, bukan buka tautan).
function domI(c, doc) {
  const f = doc.createDocumentFragment();
  for (const n of c) {
    if (n.t === 'x') f.append(doc.createTextNode(n.v));
    else if (n.t === 'br') f.append(doc.createElement('br'));
    else if (n.t === 'code') { const e = doc.createElement('code'); e.textContent = n.v; f.append(e); }
    else if (n.t === 'a') { const e = doc.createElement('span'); e.className = 'md-a'; e.append(domI(n.c, doc)); f.append(e); }
    else { const e = doc.createElement(n.t === 'b' ? 'strong' : n.t === 'i' ? 'em' : n.t); e.append(domI(n.c, doc)); f.append(e); }
  }
  return f;
}
export function toDom(blocks, doc = document) {
  const root = doc.createElement('div'); root.className = 'md';
  for (const b of blocks) {
    let e;
    if (b.k === 'p') { e = doc.createElement('p'); e.append(domI(b.c, doc)); }
    else if (b.k === 'h') { e = doc.createElement('p'); e.className = 'md-h md-h' + b.n; e.append(domI(b.c, doc)); }
    else if (b.k === 'q') { e = doc.createElement('blockquote'); e.append(domI(b.c, doc)); }
    else if (b.k === 'pre') { e = doc.createElement('pre'); const cd = doc.createElement('code'); cd.textContent = b.v; e.append(cd); }
    else if (b.k === 'hr') e = doc.createElement('hr');
    else if (b.k === 'table') { // bungkus bergulir ke samping; sel hanya teks/format lewat node DOM
      e = doc.createElement('div'); e.className = 'md-tbl'; e.setAttribute('role', 'region'); e.setAttribute('tabindex', '0');
      const tb = doc.createElement('table'), th = doc.createElement('thead'), tr0 = doc.createElement('tr'), bd = doc.createElement('tbody');
      const fill = (tr, r, tg) => r.forEach((c, k) => { const td = doc.createElement(tg); if (b.align[k]) td.setAttribute('data-a', b.align[k]); td.append(domI(c, doc)); tr.append(td); });
      fill(tr0, b.head, 'th'); th.append(tr0); tb.append(th);
      for (const r of b.rows) { const tr = doc.createElement('tr'); fill(tr, r, 'td'); bd.append(tr); }
      tb.append(bd); e.append(tb);
    }
    else {
      e = doc.createElement(b.ord ? 'ol' : 'ul'); if (b.ord && b.start !== 1) e.setAttribute('start', String(b.start));
      for (const it of b.items) { const li = doc.createElement('li'); if (it.d) li.setAttribute('data-d', String(it.d)); li.append(domI(it.c, doc)); e.append(li); }
    }
    root.append(e);
  }
  return root;
}
