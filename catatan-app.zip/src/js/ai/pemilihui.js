// Rev 308b: lembar pemilih tugas/proyek untuk konteks AI. Mesin di konteks.js; hanya Selesai yang menerapkan.
import { h, ico, PATH, toast, infoKey } from '../ui.js';
import { CTX_PICK_MAX, pickable, livePerms, setPicks, togglePick } from './konteks.js';
const NAMA = { tugas: { judul: 'Pilih tugas', sub: 'Hanya yang kamu centang yang ikut terkirim ke AI di setiap pesan. Tugas yang sudah selesai tidak ditampilkan.', cari: 'Cari tugas', kosong: 'Belum ada tugas yang belum selesai.' },
  proyek: { judul: 'Pilih proyek', sub: 'Hanya yang kamu centang yang ikut terkirim ke AI di setiap pesan. Yang diarsipkan tidak ditampilkan.', cari: 'Cari proyek', kosong: 'Belum ada proyek aktif.' } };
export function bukaPemilihData({ data, src, perms, onApply }) {
  const N = NAMA[src]; if (!N) return;
  const all = pickable(data, src), max = CTX_PICK_MAX[src];
  let sel = livePerms(data, perms)[src].slice(), q = '';
  const o = h('div', { class: 'ov dlgov kai-tulis' }), tutup = () => o.remove();
  const list = h('div', { class: 'kd-list lp-list', role: 'group', 'aria-label': N.judul }), info = h('p', { class: 'kd-info' });
  const cari = h('input', { type: 'search', class: 'in lp-q', placeholder: N.cari + '…', 'aria-label': N.cari, autocomplete: 'off', maxlength: '60' });
  const ok = h('button', { type: 'button', class: 'btn', onclick: () => { tutup(); onApply(setPicks(perms, src, sel)); } }, 'Selesai');
  const semua = h('button', { type: 'button', class: 'btn line', onclick: () => { const vis = rows().map((r) => r.id); const add = vis.filter((id) => !sel.includes(id)); sel = sel.concat(add).slice(0, max); if (add.length && sel.length >= max && vis.some((id) => !sel.includes(id))) infoKey('maks', 'pilihan', max, 'Lepas satu pilihan dulu, lalu pilih yang lain.'); gambar(); } }, 'Pilih semua');
  const kosong = h('button', { type: 'button', class: 'btn line', onclick: () => { sel = []; gambar(); } }, 'Kosongkan');
  const rows = () => { const t = q.trim().toLowerCase(); return t ? all.filter((r) => r.title.toLowerCase().includes(t)) : all; };
  const hitung = () => {
    info.classList.toggle('on', sel.length > 0);
    info.textContent = sel.length ? sel.length + ' dari maks. ' + max + ' dipilih. Hanya ini yang dikirim.' : 'Belum ada yang dipilih: tidak ada data ' + (src === 'tugas' ? 'tugas' : 'proyek') + ' yang dikirim. Catatan Privat dan sampah tidak pernah ikut.';
    ok.textContent = sel.length ? 'Selesai (' + sel.length + ')' : 'Selesai'; kosong.disabled = !sel.length; semua.disabled = !rows().length;
  };
  const gambar = () => {
    list.textContent = ''; const rs = rows();
    if (!rs.length) list.append(h('p', { class: 'kd-info' }, q.trim() ? 'Tidak ada yang cocok.' : N.kosong));
    rs.forEach((r) => {
      const on = sel.includes(r.id);
      list.append(h('button', { type: 'button', class: 'kd-row lp-row' + (on ? ' on' : ''), role: 'checkbox', 'aria-checked': String(on), 'data-id': r.id, onclick: (ev) => {
        const t = togglePick(setPicks(perms, src, sel), src, r.id); if (t.result === 'full') { infoKey('maks', 'pilihan', max, 'Lepas satu pilihan dulu, lalu pilih yang lain.'); return; }
        sel = t.perms[src].slice(); const b = ev.currentTarget, now = sel.includes(r.id); b.classList.toggle('on', now); b.setAttribute('aria-checked', String(now)); hitung();
      } }, h('span', { class: 'lp-ck', 'aria-hidden': 'true' }, ico(PATH.tugas)), h('span', { class: 'kd-tx' }, h('b', {}, r.title), r.meta ? h('small', {}, r.meta) : null)));
    });
    hitung();
  };
  let tmr = 0; cari.addEventListener('input', () => { clearTimeout(tmr); tmr = setTimeout(() => { q = cari.value; gambar(); }, 120); });
  o.addEventListener('click', (e) => { if (e.target === o) tutup(); });
  o.append(h('div', { class: 'sheet dlg kd-sheet lp-sheet' },
    h('div', { class: 'kd-head' }, h('span', { class: 'kd-hi' }, ico(PATH[src] || PATH.tugas)), h('div', { class: 'kd-ht' }, h('h3', {}, N.judul), h('p', { class: 'sub' }, N.sub))),
    cari, h('div', { class: 'pd-act' }, semua, kosong), list, info,
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: tutup }, 'Batal'), ok)));
  document.body.append(o); gambar();
}
