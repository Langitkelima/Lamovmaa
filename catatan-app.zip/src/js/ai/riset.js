// Rev 232 / Kelimaa AI Tahap 6b: sisi aplikasi untuk aksi Worker `research` (Rev 231). Logika MURNI (tanpa DOM, tanpa jaringan).
// Aturan sumber (27.5): jawaban riset tanpa sumber DILABELI "belum terverifikasi"; sumber hanya tautan https; data aplikasi TIDAK PERNAH ikut dikirim ke riset (pertanyaan diteruskan ke Google Search lewat Gemini).
export const SRC_MAX = 10, SRC_TITLE_MAX = 80, Q_MAX = 5;
const oneLine = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f|*_`#<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);
// Sumber dari Worker -> [{title, uri}] yang sah (https, unik, maks. SRC_MAX).
export function cleanSources(raw) {
  const out = [], seen = new Set();
  for (const s of Array.isArray(raw) ? raw : []) {
    if (!s || typeof s.uri !== 'string' || !/^https:\/\/[^\s]{3,1990}$/i.test(s.uri) || seen.has(s.uri)) continue;
    seen.add(s.uri); out.push({ title: oneLine(s.title, SRC_TITLE_MAX) || 'Sumber', uri: s.uri });
    if (out.length >= SRC_MAX) break;
  }
  return out;
}
export function cleanQueries(raw) { return (Array.isArray(raw) ? raw : []).map((q) => oneLine(q, 100)).filter(Boolean).slice(0, Q_MAX); }
// Judul sumber unik (domain) untuk baris "Sumber:" yang ikut tersimpan di riwayat/catatan. Bukan butir daftar, supaya tidak ikut jadi tugas/baris lembar.
export function sourceNames(sources) { const seen = new Set(), out = []; for (const s of cleanSources(sources)) { const k = s.title.toLowerCase(); if (!seen.has(k)) { seen.add(k); out.push(s.title); } } return out; }
export const UNVERIFIED = '_Belum terverifikasi: tidak ada sumber web yang dikembalikan._';
// Isi balasan riset yang disimpan: teks + baris sumber, atau label belum terverifikasi bila tak ada sumber (grounded dihitung ULANG dari sumber yang sah, bukan dipercaya dari Worker).
export const NO_SEARCH = '_Pencarian web sedang tidak tersedia (Google kena batas). Jawaban ini dari pengetahuan AI, tanpa sumber, dan bisa tidak terbaru._';
export function researchText(res) {
  const text = String(res && res.text != null ? res.text : '').trim(); if (!text) return '';
  if (res && res.noSearch === true) return text + '\n\n' + NO_SEARCH; // Rev 249: jalur cadangan tanpa pencarian
  const names = sourceNames(res && res.sources);
  return text + '\n\n' + (names.length ? '**Sumber:** ' + names.join(', ') : UNVERIFIED);
}
export const isGrounded = (res) => cleanSources(res && res.sources).length > 0;
// Baris ringkas untuk bilah meta: kueri yang dijalankan Google.
export function queriesLine(res) { const q = cleanQueries(res && res.queries); return q.length ? 'pencarian: ' + q.join(' / ') : ''; }
// ---- Rev 233: Search Suggestions Google. Dokumentasi resmi (ai.google.dev, "Use Google Search Suggestions", dibaca 12 Nov 2026) mewajibkan: tampilkan `searchEntryPoint.renderedContent` APA ADANYA, tetap terlihat selama jawaban bersumber tampil, lebar minimal selebar jawaban, ketukan langsung ke halaman hasil Google (tanpa layar perantara).
export const MAX_SUGGEST = 16000;
// HTML saran dari Worker -> string sah atau '' (tidak pernah dipotong/diubah; yang terlalu besar atau memuat skrip/bingkai/objek dibuang seluruhnya). Aplikasi tetap menampilkannya di iframe tanpa izin skrip.
export function cleanSuggest(raw) {
  if (typeof raw !== 'string') return '';
  const s = raw.trim(); if (!s || s.length > MAX_SUGGEST) return '';
  if (/<\s*(script|iframe|object|embed|base|meta)\b/i.test(s)) return '';
  return s;
}
// Tautan dari widget saran yang boleh dibuka: hanya https ke google.com (halaman hasil pencarian / merek Google); selain itu '' (tidak dibuka).
export function googleLink(href) {
  if (typeof href !== 'string' || href.length > 2000) return '';
  return /^https:\/\/(www\.)?google\.com(\/|$)[^\s]*$/i.test(href) ? href : '';
}
// Bidang tambahan pesan asisten hasil riset yang ikut disimpan di riwayat: sumber (untuk chip) + saran (wajib tetap tampil).
export function researchExtras(res) {
  const out = {}, src = cleanSources(res && res.sources), sg = cleanSuggest(res && res.suggest);
  if (src.length) out.src = src; if (sg) out.sg = sg;
  return out;
}
