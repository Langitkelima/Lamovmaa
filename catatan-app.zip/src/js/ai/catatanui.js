// Rev 301b / Kelimaa AI untuk CATATAN, bagian B: dialog "Olah catatan" di editor catatan BIASA (tidak pernah Catatan Privat; penjagaan di notes.js dan di catatan.js). Dimuat MALAS dari notes.js (import() dinamis).
// Alur: pilih aksi -> AI membaca judul + isi catatan -> hasil tampil sebagai TEKS (node teks, bukan HTML) -> pengguna menekan Terapkan; Batal = tidak ada perubahan.
// Penerapan lewat planEdit/applyPlan (gagal bila catatan diubah selagi menunggu AI); sesudahnya toast Urungkan (undoPlan; tidak menimpa ketikan sesudahnya).
import { h, toast, tWarn } from '../ui.js';
import { sanitize, notePlain } from '../notes.js';
import { hydrateBlocks } from '../blok.js';
import { loadConn, loadCfg } from './sambungan.js';
import { NOTE_ACTIONS, NOTE_MAX, noteInput, olahCatatan, planEdit, applyPlan, undoPlan } from './catatan.js';

// env (sama dengan yang diberikan notes.js ke mulaiTulis): { ed (editor), tt (kolom judul), flushHist, auto, upd, refresh }. Dipanggil dari tulisui.js bila Tulis AI diketuk TANPA teks terblok.
export function mulaiCatatanAI(e) {
  if (!e || !e.ed || !e.tt) return false;
  const env = {
    getNote: () => ({ title: e.tt.value, text: notePlain(e.ed), html: sanitize(e.ed.innerHTML) }),
    setNote: (x) => {
      if (x.title !== e.tt.value) e.tt.value = x.title;
      if (x.html !== sanitize(e.ed.innerHTML)) { e.ed.innerHTML = sanitize(x.html); hydrateBlocks(e.ed); if (typeof e.refresh === 'function') e.refresh(); }
      e.upd(); e.auto();
    },
    flush: e.flushHist,
  };
  const conn = loadConn(), cfg = loadCfg();
  if (!conn || !cfg.on) { tWarn('Nyalakan Kelimaa AI dulu di tab AI (simpan sambungan, lalu sakelar MENYALA).'); return false; }
  env.flush(); const base0 = env.getNote(); if (!noteInput(base0, 'ringkas').ok) { tWarn('Catatan masih kosong. Tulis isinya dulu.'); return false; }
  let busy = false, parsed = null, base = null, pick = 0;
  const ov = h('div', { class: 'ov dlgov kai-tulis' }), close = () => ov.remove();
  const snip = (base0.text || '').trim();
  const prev = h('div', { class: 'kai-tv' }, (base0.title ? base0.title + '\n\n' : '') + (snip.length > 240 ? snip.slice(0, 240) + '\u2026' : snip));
  const status = h('small', { class: 'aimeta', role: 'status', 'aria-live': 'polite' }, 'Pilih apa yang mau dilakukan pada catatan ini.');
  const out = h('div', { class: 'kai-tr', hidden: 'hidden' }), tl = h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Usulan judul' });
  const b1 = h('button', { type: 'button', class: 'btn', disabled: 'disabled' }, 'Terapkan'), b2 = h('button', { type: 'button', class: 'btn line2', hidden: 'hidden' }, '');
  const reset = () => { parsed = null; out.hidden = true; out.textContent = ''; tl.textContent = ''; b1.disabled = true; b2.hidden = true; };
  const finish = (pos) => {
    if (!parsed) return;
    const live = env.getNote(), plan = planEdit(base, parsed, { index: pick, pos }); if (!plan.ok) { status.textContent = plan.msg; return; }
    const ap = applyPlan(live, plan); if (!ap.ok) { status.textContent = ap.msg; return; }
    env.flush(); env.setNote(ap.note); env.flush();
    const after = env.getNote(), done = { ...plan, patch: Object.fromEntries(Object.keys(plan.patch).map((k) => [k, after[k]])) }; // nilai SETELAH disaring editor, supaya Urungkan mengenalinya
    close();
    toast(plan.summary, () => { const u = undoPlan(env.getNote(), done); if (!u.ok) { toast(u.msg); return; } env.flush(); env.setNote(u.note); env.flush(); });
  };
  b1.onclick = () => finish('atas'); b2.onclick = () => finish('bawah');
  const chips = NOTE_ACTIONS.map((a) => h('button', { type: 'button', class: 'kai-wc', 'data-act': a.id, onclick: async () => {
    if (busy) return; busy = true; reset(); chips.forEach((x) => x.classList.toggle('on', x === chips[NOTE_ACTIONS.indexOf(a)]));
    const now = env.getNote(); status.textContent = a.label + '\u2026 menunggu AI.';
    let r; try { r = await olahCatatan(conn, cfg, a.id, now, undefined); } catch (_) { r = { ok: false, msg: 'Kesalahan tak terduga.' }; }
    busy = false; if (!ov.isConnected) return;
    if (!r.ok) { status.textContent = r.msg; return; }
    parsed = r.parsed; base = now; pick = 0; out.hidden = false;
    const warn = (r.cut ? ' Hanya ' + NOTE_MAX.toLocaleString('id-ID') + ' huruf pertama yang dibaca.' : '') + (parsed.warn ? ' ' + parsed.warn : '');
    if (parsed.mode === 'judul') {
      parsed.titles.forEach((t, i) => tl.append(h('button', { type: 'button', class: 'kai-wc' + (i === 0 ? ' on' : ''), onclick: () => { pick = i; [...tl.children].forEach((c, j) => c.classList.toggle('on', j === i)); } }, t)));
      out.append(tl); b1.textContent = 'Pakai judul terpilih'; b2.hidden = true;
    } else {
      out.append(h('div', {}, parsed.text));
      if (parsed.mode === 'ringkas') { b1.textContent = 'Sisipkan di atas catatan'; b2.textContent = 'Sisipkan di bawah catatan'; b2.hidden = false; } else { b1.textContent = 'Ganti isi catatan'; b2.hidden = true; }
    }
    b1.disabled = false;
    status.textContent = 'Hasil ' + a.label + (r.provider ? ' \u00b7 ' + r.provider : '') + '. Periksa dulu sebelum dipakai.' + warn;
  } }, a.label));
  ov.append(h('div', { class: 'sheet dlg' },
    h('h3', {}, 'Olah catatan dengan AI'), prev,
    h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Aksi catatan' }, chips), status, out,
    h('div', { class: 'kai-apply' }, b1, b2),
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: close }, 'Batal'))));
  document.body.append(ov);
  return true;
}
