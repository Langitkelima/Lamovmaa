// Rev 214 / Kelimaa AI Tahap 2: WORKSPACE (ruang percakapan) + riwayat per ruang. Logika MURNI (tanpa DOM); plugin Filesystem DISUNTIKKAN supaya bisa dites di Node.
// Penyimpanan: berkas di folder data pribadi aplikasi (directory DATA), bukan penyimpanan peramban (kuota terbatas). Tidak ikut cadangan (keputusan 27.8). Hanya teks percakapan yang diketik pengguna dan balasan AI; TIDAK ada isi catatan/tugas/Catatan Privat.
// Aturan keamanan: id ruang divalidasi ketat (ID_RE) sebelum dipakai di nama berkas; semua fungsi penyimpanan TIDAK pernah melempar error (mengembalikan {ok:false,msg}).
import { TASK_CHOICES } from './sambungan.js';
import { nativePlugin } from '../native.js';
import { cleanSources, cleanSuggest } from './riset.js'; // Rev 233
import { cleanAtt } from './lampiran-ref.js'; // Rev 306a: rujukan lampiran catatan (id + judul, TANPA isi) ikut tersimpan di pesan pengguna

export const DIR = 'DATA', BASE = 'kelimaa_ai', INDEX_PATH = BASE + '/ruang.json';
export const MAX_WS = 20, MAX_KEEP = 100, NAME_MAX = 30, MSG_MAX = 4000, DEFAULT_NAME = 'Umum', DEFAULT_TASK = 'chat.general';
export const ID_RE = /^w[a-z0-9]{4,24}$/;
const TASKS = TASK_CHOICES.map((t) => t[0]);
const msgPath = (id) => BASE + '/' + id + '.json';

export function cleanName(raw) {
  const v = String(raw == null ? '' : raw).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!v) return { ok: false, msg: 'Nama ruang tidak boleh kosong.' };
  if (v.length > NAME_MAX) return { ok: false, msg: 'Nama ruang maksimal ' + NAME_MAX + ' huruf.' };
  return { ok: true, value: v };
}
export function newId(now = Date.now(), rnd = Math.random) {
  return 'w' + Math.floor(now).toString(36).slice(-7) + Math.floor(rnd() * 36 ** 4).toString(36).padStart(4, '0');
}
export function defaultIndex(now = Date.now(), rnd = Math.random) {
  const id = newId(now, rnd);
  return { v: 1, active: id, list: [{ id, name: DEFAULT_NAME, task: DEFAULT_TASK, at: now }] };
}
// Bentuk apa pun -> indeks sah (id tak sah/duplikat dibuang, jumlah dibatasi, minimal satu ruang, active selalu ada di daftar).
export function normIndex(raw, now = Date.now(), rnd = Math.random) {
  const src = raw && typeof raw === 'object' && Array.isArray(raw.list) ? raw.list : [], seen = new Set(), list = [];
  for (const w of src) {
    if (!w || typeof w !== 'object' || typeof w.id !== 'string' || !ID_RE.test(w.id) || seen.has(w.id)) continue;
    const n = cleanName(w.name); if (!n.ok) continue;
    seen.add(w.id); list.push({ id: w.id, name: n.value, task: TASKS.includes(w.task) ? w.task : DEFAULT_TASK, at: Number.isFinite(w.at) ? w.at : now });
    if (list.length >= MAX_WS) break;
  }
  if (!list.length) return defaultIndex(now, rnd);
  return { v: 1, active: list.some((w) => w.id === (raw && raw.active)) ? raw.active : list[0].id, list };
}
// Pesan sah: hanya user/assistant, teks 1..MSG_MAX, jam HH:MM opsional; dimulai dari pengguna; maks. MAX_KEEP terakhir.
export function normMsgs(raw) {
  const out = [];
  for (const m of Array.isArray(raw) ? raw : []) {
    if (!m || typeof m !== 'object' || (m.role !== 'user' && m.role !== 'assistant') || typeof m.content !== 'string') continue;
    const c = m.content.trim(); if (!c || c.length > MSG_MAX) continue;
    const e = { role: m.role, content: c }; if (typeof m.t === 'string' && /^\d\d:\d\d$/.test(m.t)) e.t = m.t;
    if (m.role === 'user') { const at = cleanAtt(m.att); if (at.length) e.att = at; } // Rev 306a
    if (m.role === 'assistant') { const sr = cleanSources(m.src), sg = cleanSuggest(m.sg); if (sr.length) e.src = sr; if (sg) e.sg = sg; } // Rev 233: sumber + Search Suggestions riset ikut tersimpan
    out.push(e);
  }
  const cut = out.slice(-MAX_KEEP); while (cut.length && cut[0].role !== 'user') cut.shift();
  return cut;
}
export const activeWs = (idx) => idx.list.find((w) => w.id === idx.active) || idx.list[0];
export function addWs(idx, name, now = Date.now(), rnd = Math.random) {
  const n = cleanName(name); if (!n.ok) return n;
  if (idx.list.length >= MAX_WS) return { ok: false, msg: 'Maksimal ' + MAX_WS + ' ruang. Hapus satu dulu.' };
  if (idx.list.some((w) => w.name.toLowerCase() === n.value.toLowerCase())) return { ok: false, msg: 'Sudah ada ruang dengan nama itu.' };
  let id = newId(now, rnd); while (idx.list.some((w) => w.id === id)) id = newId(now, rnd);
  return { ok: true, id, idx: { v: 1, active: id, list: [...idx.list, { id, name: n.value, task: DEFAULT_TASK, at: now }] } };
}
export function renameWs(idx, id, name) {
  const n = cleanName(name); if (!n.ok) return n;
  if (!idx.list.some((w) => w.id === id)) return { ok: false, msg: 'Ruang tidak ditemukan.' };
  if (idx.list.some((w) => w.id !== id && w.name.toLowerCase() === n.value.toLowerCase())) return { ok: false, msg: 'Sudah ada ruang dengan nama itu.' };
  return { ok: true, idx: { ...idx, list: idx.list.map((w) => (w.id === id ? { ...w, name: n.value } : w)) } };
}
export function setTask(idx, id, task) {
  if (!TASKS.includes(task) || !idx.list.some((w) => w.id === id)) return idx;
  return { ...idx, list: idx.list.map((w) => (w.id === id ? { ...w, task } : w)) };
}
export function setActive(idx, id) { return idx.list.some((w) => w.id === id) ? { ...idx, active: id } : idx; }
// Hapus satu ruang. Bila itu satu-satunya, diganti ruang bawaan baru. active pindah ke ruang sebelumnya/berikutnya.
export function removeWs(idx, id, now = Date.now(), rnd = Math.random) {
  const i = idx.list.findIndex((w) => w.id === id); if (i < 0) return idx;
  const list = idx.list.filter((w) => w.id !== id);
  if (!list.length) return defaultIndex(now, rnd);
  return { v: 1, active: idx.active === id ? list[Math.max(0, i - 1)].id : idx.active, list };
}

// Rev 223: bantu tampilan "riwayat" ala aplikasi chat. uniqueName = nama unik (tanpa beda huruf besar) dengan akhiran angka bila bentrok; titleFrom = judul dari pesan pertama (maks. 28 huruf);
// touchWs = tandai ruang baru dipakai (urutan Terkini); isFresh = ruang masih bernama otomatis (Umum / Obrolan baru) sehingga boleh dinamai ulang dari pesan pertama.
export const NEW_NAME = 'Obrolan baru';
export function uniqueName(idx, base, exceptId = '') {
  const b = String(base || NEW_NAME).slice(0, NAME_MAX - 3).trim() || NEW_NAME, has = (n) => idx.list.some((w) => w.id !== exceptId && w.name.toLowerCase() === n.toLowerCase());
  if (!has(b)) return b.slice(0, NAME_MAX);
  for (let i = 2; i < 100; i++) { const n = (b + ' ' + i).slice(0, NAME_MAX); if (!has(n)) return n; }
  return b.slice(0, NAME_MAX);
}
export function titleFrom(text) {
  const v = String(text == null ? '' : text).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  if (!v) return NEW_NAME;
  return v.length > 28 ? v.slice(0, 27).trimEnd() + '\u2026' : v;
}
export const isFresh = (w) => !!w && (w.name === DEFAULT_NAME || /^Obrolan baru( \d+)?$/.test(w.name));
export function touchWs(idx, id, now = Date.now()) {
  return idx.list.some((w) => w.id === id) ? { ...idx, list: idx.list.map((w) => (w.id === id ? { ...w, at: now } : w)) } : idx;
}
export const byRecent = (idx) => idx.list.slice().sort((a, b) => b.at - a.at);

// ---- Penyimpanan berkas (Filesystem disuntikkan). Tulis diserialkan lewat antrean supaya tidak saling menimpa. Tidak pernah melempar error.
const MISSING = /does not exist|no such file|not exist|enoent|not found|tidak ada/i;
const msgOf = (e) => String((e && e.message) || e || 'galat tak dikenal').slice(0, 120);
export function makeStore(FS) {
  let tail = Promise.resolve();
  const queue = (fn) => { const p = tail.then(fn, fn); tail = p.then(() => {}, () => {}); return p; };
  const read = async (path) => { // -> {ok:true,text|null} (null = berkas belum ada) atau {ok:false,msg}
    try { const r = await FS.readFile({ path, directory: DIR, encoding: 'utf8' }); const d = r && r.data; return { ok: true, text: typeof d === 'string' ? d : null }; }
    catch (e) { return MISSING.test(msgOf(e)) ? { ok: true, text: null } : { ok: false, msg: msgOf(e) }; }
  };
  const write = (path, obj) => queue(async () => { try { await FS.writeFile({ path, data: JSON.stringify(obj), directory: DIR, encoding: 'utf8', recursive: true }); return { ok: true }; } catch (e) { return { ok: false, msg: msgOf(e) }; } });
  const parse = (t) => { try { return JSON.parse(t); } catch (e) { return null; } };
  return {
    async loadIndex(now = Date.now()) { const r = await read(INDEX_PATH); if (!r.ok) return r; return { ok: true, idx: r.text == null ? defaultIndex(now) : normIndex(parse(r.text), now) }; },
    saveIndex: (idx) => write(INDEX_PATH, normIndex(idx)),
    async loadMsgs(id) { if (!ID_RE.test(String(id))) return { ok: false, msg: 'Id ruang tidak sah.' }; const r = await read(msgPath(id)); if (!r.ok) return r; return { ok: true, msgs: r.text == null ? [] : normMsgs(parse(r.text)) }; },
    saveMsgs: (id, msgs) => (ID_RE.test(String(id)) ? write(msgPath(id), normMsgs(msgs)) : Promise.resolve({ ok: false, msg: 'Id ruang tidak sah.' })),
    removeMsgs: (id) => queue(async () => { if (!ID_RE.test(String(id))) return { ok: false, msg: 'Id ruang tidak sah.' }; try { await FS.deleteFile({ path: msgPath(id), directory: DIR }); return { ok: true }; } catch (e) { return MISSING.test(msgOf(e)) ? { ok: true } : { ok: false, msg: msgOf(e) }; } }),
    clearAll: () => queue(async () => { try { await FS.rmdir({ path: BASE, directory: DIR, recursive: true }); return { ok: true }; } catch (e) { return MISSING.test(msgOf(e)) ? { ok: true } : { ok: false, msg: msgOf(e) }; } }),
  };
}
// Dipanggil layar chat HANYA di aplikasi HP (isNative); plugin dibuat malas di sini supaya layar tidak menyebut plugin langsung.
export function openStore() { return makeStore(nativePlugin('Filesystem')); }
