// Rev 374 / OJ5: jalurBerikut + bisaCobaLain (tombol "Coba jalur lain" MANUAL; tanpa pindah jalur otomatis); galat 401 diberi tanda `passcode`, galat menyiapkan foto diberi tanda `siapkan`.
// Rev 369 / OJ2: pilihan jalur+model baca foto (bacaJalur/simpanJalur/bersihkanJalur, opts.provider/opts.jalur, hasil bacaFoto memuat `ms`), tanpa UI.
// Rev 353 / PART O2 (Paket OCR): mesin aplikasi untuk aksi Worker `ocr` (Rev 352). MODUL MALAS, TANPA UI (UI = O3). Satu foto -> teks.
// PRIVASI: foto hanya hidup di memori selama satu permintaan; TIDAK ditulis ke penyimpanan, TIDAK dicatat di log, isi hasil TIDAK masuk riwayat token (hanya angka). Canvas menggambar ulang foto sehingga EXIF/GPS terbuang.
// Bagian MURNI (tanpa DOM/jaringan) dites di Node; hanya `perkecilFoto` memakai DOM, `kirimOcr`/`bacaFoto` memakai jaringan lewat pengirim yang bisa diganti.
import * as G from '../gambar.js';
import { cleanUrl, cleanPass, cleanLimit, cleanMonthLimit, cleanTokens, cleanModel, nativeHttp, MODEL_PRESETS } from './sambungan.js';
import { buatEntri, catat } from './riwayat-token.js';
export const OCR_MAX_SIDE = 1600;          // sisi terpanjang foto yang dikirim (px)
export const OCR_MAX_BYTES = 400000;       // target ukuran biner (sekitar 533.400 huruf base64; Worker menerima sampai 560.000 huruf)
export const OCR_B64_MAX = 560000, OCR_B64_MIN = 40; // SAMA dengan Worker (MAX_OCR_B64 / MIN_OCR_B64)
export const OCR_TIMEOUT = 60000;          // aplikasi menunggu 60 dtk (Worker menyerah di 52 dtk)
export const OCR_MIME = 'image/jpeg';
export const OCR_EST_IN_CHARS = 2500;      // perkiraan token masuk bila penyedia tidak melapor (dipakai riwayat; ditandai `est`)
export const OCR_LABEL = 'Baca teks foto';
const QUALITIES = [0.8, 0.7, 0.6, 0.5];
export const b64Len = (n) => 4 * Math.ceil((Number(n) > 0 ? Number(n) : 0) / 3);
// Bytes -> base64 murni (tanpa awalan data:), per potongan agar tidak meledakkan tumpukan.
export function bytesToB64(bytes) {
  let out = ''; const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) out += String.fromCharCode.apply(null, bytes.subarray(i, i + step));
  return btoa(out);
}
// Rencana perkecil: dari ukuran asli -> langkah {width,height,quality} dicoba berurutan sampai <= OCR_MAX_BYTES.
// 1) sisi <= 1600 px, kualitas 0,8 -> 0,5; 2) bila masih besar: 1280 px @0,7 lalu 1024 px @0,6 (tulisan masih terbaca). Foto kecil TIDAK diperbesar.
export function planOcr(w, h) {
  const main = G.fitSize(w, h, OCR_MAX_SIDE);
  if (!main) return { ok: false, msg: 'Ukuran foto tidak terbaca.' };
  const steps = QUALITIES.map((quality) => ({ quality, width: main.width, height: main.height }));
  let last = main;
  for (const [side, quality] of [[1280, 0.7], [1024, 0.6]]) {
    const s = G.fitSize(w, h, side);
    if (s && (s.width < last.width || s.height < last.height)) { steps.push({ quality, width: s.width, height: s.height }); last = s; }
  }
  return { ok: true, width: main.width, height: main.height, maxBytes: OCR_MAX_BYTES, steps, resized: main.width !== Math.floor(w) || main.height !== Math.floor(h) };
}
// Pemeriksaan gambar yang akan dikirim (cermin `checkOcrImage` Worker, supaya galat ketahuan sebelum jaringan). {ok:true} atau {ok:false,msg}.
export function cekGambar(img) {
  const g = img && typeof img === 'object' ? img : {}, d = g.image;
  if (g.mime !== OCR_MIME && g.mime !== 'image/webp') return { ok: false, msg: 'Format foto harus JPEG atau WebP.' };
  if (typeof d !== 'string' || d.length < OCR_B64_MIN) return { ok: false, msg: 'Foto kosong atau rusak.' };
  if (d.length > OCR_B64_MAX) return { ok: false, msg: 'Foto terlalu besar untuk dikirim. Pilih foto yang lebih kecil.' };
  if (/^data:/i.test(d) || d.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(d)) return { ok: false, msg: 'Isi foto tidak sah.' };
  return { ok: true };
}
// Rev 369 / OJ2: pilihan JALUR dan MODEL baca foto (tanpa UI; UI = OJ3). TERPISAH dari pilihan chat di Setelan (model obrolan BUKAN model baca foto). Disimpan di kunci sendiri, berisi nama saja (tanpa foto, tanpa teks, tanpa kunci), tidak ikut cadangan. '' = bawaan Worker (Gemini).
export const JALUR_KEY = 'kelimaa_ocr_jalur', JALUR_OCR = ['gemini', 'sakelar', 'relay'], JALUR_NAMA = { gemini: 'Gemini', sakelar: 'Sakelar', relay: 'Relay' };
export const jalurSah = (v) => { const x = typeof v === 'string' ? v.trim().toLowerCase() : ''; return JALUR_OCR.includes(x) ? x : ''; };
// Murni. Jalur tak dikenal -> bawaan; model tak sah atau tanpa jalur -> dibuang (model tanpa jalur eksplisit bisa salah alamat). -> {provider, model}
export function bersihkanJalur(raw) {
  const o = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}, provider = jalurSah(o.provider);
  if (!provider) return { provider: '', model: '' };
  const m = cleanModel(o.model);
  return { provider, model: m.ok ? m.value : '' };
}
export const modelSiapPilih = (provider) => { const j = jalurSah(provider); return j ? (MODEL_PRESETS[j] || []).slice() : []; };
// Rev 374 / OJ5: \"Coba jalur lain\" = pindah MANUAL ke jalur berikutnya (gemini -> sakelar -> relay -> gemini); bawaan dianggap Gemini. Murni.
export const OCR_LAMBAT_MS = 20000; // bacaan sukses yang makan >= 20 dtk dianggap lambat (tombol ditawarkan untuk membandingkan)
export const jalurBerikut = (provider) => JALUR_OCR[(JALUR_OCR.indexOf(jalurSah(provider) || 'gemini') + 1) % JALUR_OCR.length];
// Tombol hanya bila jalur lain MASUK AKAL: gagal di jalan (bukan Worker lama, passcode salah, atau foto gagal disiapkan di HP), foto tanpa teks, atau terlalu lambat. Murni.
export function bisaCobaLain(r) {
  if (!r || typeof r !== 'object') return false;
  if (!r.ok) return !r.workerLama && !r.passcode && !r.siapkan;
  return r.empty === true || Number(r.ms) >= OCR_LAMBAT_MS;
}
export function bacaJalur(st = globalThis.localStorage) {
  try { return bersihkanJalur(JSON.parse(st.getItem(JALUR_KEY) || 'null')); } catch (_) { return { provider: '', model: '' }; }
}
// Simpan pilihan. Pilihan bawaan (tanpa jalur) = kunci dihapus. -> {ok:true, ...pilihan} atau {ok:false,msg}. Nama model tak sah = ditolak (tidak diam-diam diganti).
export function simpanJalur(raw, st = globalThis.localStorage) {
  const o = raw && typeof raw === 'object' ? raw : {};
  if (o.provider && !jalurSah(o.provider)) return { ok: false, msg: 'Jalur baca foto tidak dikenal.' };
  if (o.model) { const m = cleanModel(o.model); if (!m.ok) return { ok: false, msg: m.msg }; }
  const v = bersihkanJalur(o);
  try { if (!v.provider) st.removeItem(JALUR_KEY); else st.setItem(JALUR_KEY, JSON.stringify(v)); } catch (_) { return { ok: false, msg: 'Gagal menyimpan pilihan di HP.' }; }
  return { ok: true, ...v };
}
// Bentuk permintaan Worker. TIDAK mengirim provider/task/model kecuali `opts.model` diberikan sengaja (model obrolan di Setelan BUKAN model baca foto: jangan dioper). Jatah: limit + monthLimit seperti chat/riset.
export function buatPermintaan(conn, img, opts = {}) {
  const u = cleanUrl(conn && conn.url), k = cleanPass(conn && conn.key);
  if (!u.ok) return { ok: false, msg: u.msg };
  if (!k.ok) return { ok: false, msg: k.msg };
  const c = cekGambar(img); if (!c.ok) return c;
  const o = opts && typeof opts === 'object' ? opts : {}, req = { key: k.value, action: 'ocr', mime: img.mime, image: img.image };
  if (o.provider) { const pv = jalurSah(o.provider); if (!pv) return { ok: false, msg: 'Jalur baca foto tidak dikenal.' }; req.provider = pv; } // Rev 369: tanpa provider = bawaan Worker (Gemini)
  if (o.model) { const m = cleanModel(o.model); if (!m.ok) return { ok: false, msg: m.msg }; if (m.value) req.model = m.value; }
  if (o.limit !== undefined && o.limit !== null) req.limit = cleanLimit(o.limit);
  if (cleanMonthLimit(o.monthLimit) > 0) req.monthLimit = cleanMonthLimit(o.monthLimit);
  return { ok: true, url: u.value + '/', body: JSON.stringify(req) };
}
// Terjemahan galat Worker khusus OCR. Pesan Worker sendiri (batas harian, kunci Gemini belum ada, KV, gambar ditolak) sudah berbahasa awam, jadi dipakai apa adanya; hanya 401 dan Worker LAMA yang diganti.
export function jelaskanGalat(status, errText) {
  const e = String(errText || '').replace(/\s+/g, ' ').trim().slice(0, 220);
  if (status === 401) return 'Passcode salah atau sudah berubah di Worker. Buka Setelan > Kelimaa AI, ketik ulang passcode, lalu Tes sambungan.';
  if (/aksi tidak dikenal/i.test(e)) return 'Worker Anda belum versi terbaru (belum bisa baca foto): tempel ulang worker.mjs di Cloudflare lalu Deploy.';
  if (e) return e;
  return status === 413 ? 'Foto terlalu besar untuk dikirim.' : 'Ditolak oleh Worker (kode ' + status + ').';
}
const parseJson = (t) => { try { const o = JSON.parse(String(t || '')); return o && typeof o === 'object' ? o : null; } catch (_) { return null; } };
// Jawaban Worker -> {ok:true,text,empty,truncated,model,provider,used,limit,...} atau {ok:false,msg,workerLama?}. `empty` = foto tanpa teks (BUKAN galat; jatah sudah terpakai).
export function uraiJawaban(status, text) {
  const j = parseJson(text);
  if (j && j.ok === true && typeof j.text === 'string' && (j.text.trim() || j.empty === true)) {
    const r = { ok: true, text: j.text.trim(), empty: j.empty === true || !j.text.trim(), truncated: j.truncated === true, model: String(j.model || '').slice(0, 60), provider: String(j.provider || '').slice(0, 20), used: typeof j.used === 'number' ? j.used : null, limit: Number(j.limit) || 0 };
    if (typeof j.monthUsed === 'number') { r.monthUsed = j.monthUsed; r.monthLimit = Number(j.monthLimit) || 0; }
    const mt = cleanTokens(j.monthTokens); if (mt) r.monthTokens = mt;
    const us = cleanTokens(j.usage); if (us) r.usage = us;
    if (typeof j.fallbackFrom === 'string' && j.fallbackFrom) r.fallbackFrom = j.fallbackFrom.slice(0, 60);
    return r;
  }
  if (j && j.ok === false) return { ok: false, msg: jelaskanGalat(status, j.error), ...(/aksi tidak dikenal/i.test(String(j.error || '')) ? { workerLama: true } : {}), ...(status === 401 ? { passcode: true } : {}) };
  return { ok: false, msg: 'Jawaban Worker tidak dikenali (kode ' + status + '). Pastikan kode Worker terbaru (Rev 352 atau lebih baru) sudah di-Deploy.' };
}
// Kirim satu foto yang sudah dikecilkan. Tidak pernah melempar error.
export async function kirimOcr(conn, img, http = nativeHttp, opts = {}) {
  const q = buatPermintaan(conn, img, opts); if (!q.ok) return { ok: false, msg: q.msg };
  try {
    const r = await http({ method: 'POST', url: q.url, body: q.body, timeout: OCR_TIMEOUT });
    return uraiJawaban(r && r.status, r && r.text);
  } catch (e) {
    const m = String((e && e.message) || e || '').slice(0, 120);
    return { ok: false, msg: /timeout|timed out|abort/i.test(m) ? 'Waktu habis: tidak ada jawaban dalam 60 detik.' : 'Tidak tersambung: ' + (m || 'tanpa keterangan') + '. Cek internet.' };
  }
}
// Entri riwayat token untuk satu pindai berhasil (tanpa isi teks, tanpa foto). Tanpa laporan penyedia = perkiraan (`est`).
export function entriRiwayat(res, now) {
  return buatEntri({ now, pesan: OCR_LABEL, usage: res && res.usage, kirimChars: OCR_EST_IN_CHARS, balasChars: String((res && res.text) || '').length, sumber: ['ocr'] });
}
// ---- DOM: perkecil foto di perangkat (canvas JPEG putih-dasar). Melempar Error berpesan awam.
const canvasBlob = (canvas, mime, quality) => new Promise((resolve, reject) => canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('Kompres foto gagal.'))), mime, quality));
export async function perkecilFoto(file) {
  const check = G.checkSource(file); if (!check.ok) throw new Error(check.msg);
  if (typeof createImageBitmap !== 'function') throw new Error('Perangkat belum mendukung pemrosesan gambar.');
  const { sourceDimensions } = await import('../gambar-app.js');
  const dims = await sourceDimensions(file), plan = planOcr(dims.w, dims.h); if (!plan.ok) throw new Error(plan.msg);
  let bitmap;
  try {
    const opt = dims.w >= dims.h ? (dims.w > plan.width ? { resizeWidth: plan.width, resizeQuality: 'high' } : undefined) : (dims.h > plan.height ? { resizeHeight: plan.height, resizeQuality: 'high' } : undefined);
    bitmap = opt ? await createImageBitmap(file, opt) : await createImageBitmap(file); // kecilkan SAAT decode (foto 108 MP tidak masuk RAM penuh)
  } catch (_) { throw new Error('Foto tidak bisa dibuka. Gunakan JPG, PNG, atau WebP.'); }
  try {
    const canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas gambar tidak tersedia.');
    let blob = null, width = plan.width, height = plan.height;
    for (const st of plan.steps) {
      width = st.width; height = st.height; canvas.width = width; canvas.height = height;
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, width, height); ctx.drawImage(bitmap, 0, 0, width, height); // dasar putih: PNG transparan tidak jadi hitam
      blob = await canvasBlob(canvas, OCR_MIME, st.quality);
      if (blob.size <= plan.maxBytes) break;
    }
    if (!blob) throw new Error('Foto gagal dikecilkan.');
    if (blob.size > plan.maxBytes) throw new Error('Foto masih terlalu besar setelah dikecilkan. Pilih foto yang lebih kecil.');
    const image = bytesToB64(new Uint8Array(await blob.arrayBuffer()));
    return { mime: OCR_MIME, image, w: width, h: height, bytes: blob.size };
  } finally { try { bitmap.close(); } catch (_) { /* abaikan */ } }
}
// Alur lengkap untuk O3: perkecil -> kirim -> catat token. `opts`: { http, perkecil (untuk tes), now, store, limit, monthLimit, model }. Mengembalikan {ok:true,...hasil,w,h,bytes} atau {ok:false,msg,workerLama?}. Tidak pernah melempar error.
export async function bacaFoto(conn, file, opts = {}) {
  const o = opts && typeof opts === 'object' ? opts : {};
  let img; try { img = await (o.perkecil || perkecilFoto)(file); } catch (e) { return { ok: false, siapkan: true, msg: String((e && e.message) || 'Foto tidak bisa disiapkan.').slice(0, 160) }; }
  const j = o.jalur && typeof o.jalur === 'object' ? bersihkanJalur(o.jalur) : null, mulai = (o.jam || Date.now)();
  const res = await kirimOcr(conn, img, o.http || nativeHttp, j && j.provider ? { ...o, provider: j.provider, ...(j.model ? { model: j.model } : {}) } : o); // Rev 369: `opts.jalur` = {provider, model} dari bacaJalur(); tanpa itu perilaku lama
  const ms = Math.max(0, Math.round((o.jam || Date.now)() - mulai));
  if (!res.ok) return res;
  try { const now = typeof o.now === 'number' ? o.now : Date.now(); catat(entriRiwayat(res, now), now, o.store || globalThis.localStorage); } catch (_) { /* riwayat gagal tidak membatalkan hasil */ }
  return { ...res, w: img.w, h: img.h, bytes: img.bytes, ms };
}
