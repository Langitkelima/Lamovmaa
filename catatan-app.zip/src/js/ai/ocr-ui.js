// Rev 374 / OJ5: tombol MANUAL "Coba jalur lain: <jalur berikutnya>" bila bacaan gagal di jalan, foto tanpa teks, atau lambat (>= 20 dtk); memakai gerbang persetujuan yang sama dan jatah AI tiap percobaan.
// Rev 370 / OJ3: pilihan JALUR (Bawaan/Gemini/Sakelar/Relay) + MODEL baca foto di dialog (mesin = ocr.js OJ2: bacaJalur/simpanJalur/modelSiapPilih, dimuat malas lewat import()); persetujuan kirim foto TERPISAH untuk Sakelar/Relay; status hasil memuat jalur, model, lama baca.
// Rev 354 / PART O3a (Paket OCR): dialog "Pindai teks dari foto" di editor catatan BIASA (tidak pernah Catatan Privat; penjagaan di notes.js). Dimuat MALAS dari notes.js (import() dinamis). Mesin = ocr.js (O2).
// Satu foto per pindai (Kamera atau Galeri) -> pratinjau -> tombol "Baca teks" (kirim SATU foto ke Worker -> Gemini) -> hasil di kotak yang BISA DIEDIT -> Sisipkan di catatan / Salin / Batal. Batal = tidak ada perubahan.
// Foto hanya hidup di memori dialog (alamat objek dicabut saat ditutup); hasil teks hanya di kotak ini sampai dipakai; tidak ada yang disimpan di sini. Teks ditaruh lewat node teks/`value`, tidak pernah HTML mentah.
import { h, tOk, tWarn, tErr } from '../ui.js';
import { loadConn, loadCfg, chatOpts } from './sambungan.js';
import { sharedToHtml, SHARE_IN_MAX } from '../logic.js';

// Rev 355 / O3b: teks hasil pindai (teks BIASA, bukan Markdown: tanda * # _ dari foto dibiarkan apa adanya) -> draf catatan baru {title, text, html, cut}. Judul = baris pertama berisi (spasi dirapatkan, maks. 60 huruf); isi = seluruh teks; html lewat sharedToHtml (di-escape). null bila kosong. MURNI (dites Node).
export const OCR_TITLE_MAX = 60;
export function draftDariOcr(raw) {
  let src = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').replace(/[ \u00a0\t]+\n/g, '\n').replace(/\n{4,}/g, '\n\n\n').trim();
  if (!src) return null;
  let cut = false;
  if (src.length > SHARE_IN_MAX) { cut = true; src = src.slice(0, SHARE_IN_MAX); const c = src.charCodeAt(src.length - 1); if (c >= 0xd800 && c <= 0xdbff) src = src.slice(0, -1); src = src.replace(/\s+$/, ''); }
  const first = src.split('\n').find((l) => l.trim()) || '';
  const title = first.replace(/\s+/g, ' ').trim().slice(0, OCR_TITLE_MAX).trim();
  return { title, text: src, html: sharedToHtml(src), cut };
}

// Rev 356 / O4: persetujuan SEKALI sebelum foto pertama dikirim. Disimpan di kunci sendiri (bukan di cfg AI) bernomor versi: ganti OK_VER bila bunyi ketentuan berubah supaya ditanya lagi. Tanpa persetujuan TIDAK ada foto yang meninggalkan HP.
export const OK_KEY = 'kelimaa_ocr_ok', OK_VER = '1';
export function sudahSetuju(st = globalThis.localStorage) { try { return st.getItem(OK_KEY) === OK_VER; } catch (_) { return false; } }
export function catatSetuju(ya, st = globalThis.localStorage) { try { if (ya) st.setItem(OK_KEY, OK_VER); else st.removeItem(OK_KEY); return true; } catch (_) { return false; } }
// Rev 370 / OJ3: persetujuan TERPISAH bila foto dikirim lewat Sakelar/Relay (layanan perantara; ketentuan data mereka dan model di belakangnya BELUM diperiksa, jadi teksnya jujur soal itu).
export const OK_KEY_LAIN = 'kelimaa_ocr_ok_lain', OK_VER_LAIN = '1';
export function sudahSetujuLain(st = globalThis.localStorage) { try { return st.getItem(OK_KEY_LAIN) === OK_VER_LAIN; } catch (_) { return false; } }
export function catatSetujuLain(ya, st = globalThis.localStorage) { try { if (ya) st.setItem(OK_KEY_LAIN, OK_VER_LAIN); else st.removeItem(OK_KEY_LAIN); return true; } catch (_) { return false; } }
export const TEKS_SETUJU_LAIN = [
  'Foto dikirim lewat Worker kamu ke layanan perantara yang kamu pilih (Sakelar atau Relay), lalu diteruskan ke model AI pilihanmu. Aplikasi dan Worker tidak menyimpan foto itu.',
  'Tetapi apa yang dilakukan layanan perantara dan penyedia model di belakangnya dengan foto itu (disimpan, dicatat, atau dipakai untuk melatih model) ditentukan ketentuan mereka sendiri. Aplikasi belum memeriksa ketentuan itu, jadi anggap isi foto bisa dibaca pihak lain.',
  'Jangan pindai KTP, kartu bank, rekam medis, atau dokumen rahasia lain. Model yang kamu pilih juga harus bisa membaca gambar; model teks saja akan gagal.',
];
const perluLain = (j) => !!j && (j.provider === 'sakelar' || j.provider === 'relay');
// Isi ketentuan: ringkasan ketentuan Google yang DIBACA 19 Nov 2026 (halaman ketentuan tambahan Gemini API, terakhir diubah 28 Apr 2026). Aplikasi TIDAK tahu apakah kunci Gemini kamu gratis atau berbayar, jadi keduanya disebut.
export const TEKS_SETUJU = [
  'Foto dikirim lewat Worker kamu ke Google Gemini supaya tulisannya dibaca. Aplikasi dan Worker tidak menyimpan foto itu.',
  'Tetapi menurut ketentuan Google (dibaca 19 Nov 2026): bila kunci Gemini kamu GRATIS (tanpa penagihan), Google boleh memakai isi foto untuk mengembangkan produk dan modelnya, dan petugas bisa membacanya. Bila kunci BERBAYAR, isi foto tidak dipakai untuk itu, hanya dicatat sementara untuk memeriksa pelanggaran.',
  'Jadi jangan pindai KTP, kartu bank, rekam medis, atau dokumen rahasia lain. Ketentuan bisa berubah; cek halaman Gemini API Additional Terms of Service milik Google.',
];
function tanyaSetuju(onYes, lain) {
  const ov = h('div', { class: 'ov dlgov kai-tulis kai-ocr-ok' }), tutup = () => ov.remove();
  ov.addEventListener('click', (e) => { if (e.target === ov) tutup(); });
  ov.append(h('div', { class: 'sheet dlg' }, h('h3', {}, lain ? 'Kirim foto lewat layanan perantara?' : 'Kirim foto untuk dibaca?'), ...(lain ? TEKS_SETUJU_LAIN : TEKS_SETUJU).map((t) => h('p', { class: 'sub' }, t)),
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: tutup }, 'Batal'),
      h('button', { type: 'button', class: 'btn', onclick: () => { if (!(lain ? catatSetujuLain(true) : catatSetuju(true))) tWarn('Persetujuan tidak bisa disimpan; kamu akan ditanya lagi lain kali.'); tutup(); onYes(); } }, 'Setuju, kirim foto'))));
  document.body.append(ov);
}

// Teks -> potongan dokumen (baris baru jadi <br>), disisipkan di kursor tersimpan (atau akhir catatan bila kursor di luar editor). true bila berhasil.
export function sisipTeks(ed, saved, text, { flushHist, auto, setRng }) {
  const lines = String(text || '').replace(/\r\n?/g, '\n').split('\n'); if (!lines.some((l) => l.trim())) return false;
  const rr = saved && ed.contains(saved.startContainer) && ed.contains(saved.endContainer) ? saved.cloneRange() : (() => { const x = document.createRange(); x.selectNodeContents(ed); x.collapse(false); return x; })();
  flushHist(); rr.deleteContents();
  const frag = document.createDocumentFragment();
  lines.forEach((ln, i) => { if (i) frag.append(document.createElement('br')); if (ln) frag.append(document.createTextNode(ln)); });
  const last = frag.lastChild; rr.insertNode(frag);
  if (last) { const c = document.createRange(); c.setStartAfter(last); c.collapse(true); const sl = getSelection(); sl.removeAllRanges(); sl.addRange(c); setRng(c.cloneRange()); }
  flushHist(); auto(); return true;
}
async function salin(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* cadangan di bawah */ }
  try { const t = h('textarea', { style: 'position:fixed;opacity:0' }); t.value = text; document.body.append(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return !!ok; } catch (_) { return false; }
}
// Rev 367 / K4: jumlah penanda [?] (bagian yang diragukan model) di hasil bacaan. Murni.
export function hitungRagu(text) { return (String(text || '').match(/\[\?\]/g) || []).length; }
export function bukaOcr({ onInsert, onNew }) {
  const conn = loadConn(), cfg = loadCfg();
  if (!conn || !cfg.on) { tWarn('Nyalakan Kelimaa AI dulu di tab AI (simpan sambungan, lalu sakelar MENYALA).'); return false; }
  let file = null, url = '', busy = false, O = null, jal = { provider: '', model: '' }; // Rev 370: O = modul ocr.js (dimuat malas), jal = pilihan jalur aktif (cermin penyimpanan)
  const setuju = () => (perluLain(jal) ? sudahSetujuLain() : sudahSetuju());
  const ov = h('div', { class: 'ov dlgov kai-tulis kai-ocr' });
  const close = () => { if (url) { try { URL.revokeObjectURL(url); } catch (_) { /* abaikan */ } url = ''; } file = null; ta.value = ''; ov.remove(); };
  const pick = (cap) => h('input', { type: 'file', accept: 'image/*', ...(cap ? { capture: 'environment' } : {}), style: 'display:none', 'aria-label': cap ? 'Ambil foto dengan kamera' : 'Pilih foto dari galeri' });
  const inCam = pick(true), inGal = pick(false);
  const status = h('small', { class: 'aimeta', role: 'status', 'aria-live': 'polite' }, 'Pilih satu foto yang berisi tulisan. Hasil terbaik: foto lurus dari atas, cukup terang, tanpa bayangan atau pantulan, tulisan memenuhi bingkai.');
  const img = h('img', { class: 'kai-ocr-img', alt: 'Pratinjau foto', hidden: 'hidden' });
  const ta = h('textarea', { class: 'kai-ocr-ta', rows: '6', hidden: 'hidden', 'aria-label': 'Hasil teks dari foto (bisa diedit)' });
  const bRead = h('button', { type: 'button', class: 'btn', disabled: 'disabled' }, 'Baca teks');
  const bIns = h('button', { type: 'button', class: 'btn', hidden: 'hidden' }, 'Sisipkan di catatan');
  const bNew = h('button', { type: 'button', class: 'btn line2', hidden: 'hidden' }, 'Jadikan catatan baru');
  const bCopy = h('button', { type: 'button', class: 'btn line2', hidden: 'hidden' }, 'Salin');
  const bLain = h('button', { type: 'button', class: 'btn line2', hidden: 'hidden' }, 'Coba jalur lain');
  const chosen = (f) => {
    if (!f) return; if (url) { try { URL.revokeObjectURL(url); } catch (_) { /* abaikan */ } }
    file = f; url = URL.createObjectURL(f); img.src = url; img.hidden = false; ta.hidden = bIns.hidden = bNew.hidden = bCopy.hidden = true; bLain.hidden = true; ta.value = '';
    bRead.disabled = false; status.textContent = 'Foto siap. Foto tidak disimpan di aplikasi maupun Worker; sebelum dikirim kamu diminta setuju dulu. Ketuk Baca teks.';
  };
  inCam.onchange = () => chosen(inCam.files && inCam.files[0]); inGal.onchange = () => chosen(inGal.files && inGal.files[0]);
  const tawarLain = (r) => { const ya = !!O && O.bisaCobaLain(r); bLain.hidden = !ya; if (ya) bLain.textContent = 'Coba jalur lain: ' + O.JALUR_NAMA[O.jalurBerikut(jal.provider)]; }; // Rev 374 / OJ5
  const baca = async () => {
    if (busy || !file) return; busy = true; bRead.disabled = true; ta.hidden = bIns.hidden = bNew.hidden = bCopy.hidden = true; bLain.hidden = true; status.textContent = 'Membaca foto\u2026 menunggu AI (bisa sampai satu menit).';
    let r; try { const { bacaFoto } = await import('./ocr.js'); const o = chatOpts(cfg); r = await bacaFoto(conn, file, { limit: o.limit, ...(o.monthLimit ? { monthLimit: o.monthLimit } : {}), jalur: { provider: jal.provider, model: jal.model } }); } catch (_) { r = { ok: false, siapkan: true, msg: 'Kesalahan tak terduga.' }; }
    busy = false; if (!ov.isConnected) return; bRead.disabled = false;
    if (!r.ok) { status.textContent = r.msg + (O && O.bisaCobaLain(r) ? ' Kamu bisa mencoba jalur lain; tiap percobaan memakai jatah AI.' : ''); tawarLain(r); return; }
    if (r.empty) { status.textContent = 'Tidak ada teks yang terbaca di foto ini (jatah AI tetap terpakai). Coba foto yang lebih jelas' + (O && O.bisaCobaLain(r) ? ', atau coba jalur lain.' : '.'); tawarLain(r); return; }
    ta.value = r.text; ta.hidden = bIns.hidden = bNew.hidden = bCopy.hidden = false;
    const info = [r.provider ? ((O && O.JALUR_NAMA[r.provider]) || r.provider) : '', r.model, r.fallbackFrom ? '(model cadangan)' : '', r.ms >= 100 ? String(Math.round(r.ms / 100) / 10).replace('.', ',') + ' dtk' : ''].filter(Boolean).join(' \u00b7 '); // Rev 370: jalur, model, lama baca
    tawarLain(r);
    status.textContent = 'Hasil bacaan' + (info ? ' \u00b7 ' + info : '') + '. Periksa dan perbaiki dulu sebelum dipakai.' + (r.truncated ? ' Teks sangat panjang sehingga bagian akhirnya terpotong.' : '') + (hitungRagu(r.text) ? ' Ada ' + hitungRagu(r.text) + ' bagian bertanda [?] yang sulit dibaca; coba foto ulang lebih dekat dan terang, atau perbaiki sendiri.' : '') + (O && r.ms >= O.OCR_LAMBAT_MS ? ' Bacaan ini lambat; coba jalur lain untuk membandingkan.' : '');
  };
  // Rev 370 / OJ3: pilihan jalur + model baca foto. Disimpan lewat simpanJalur (kunci sendiri; model obrolan di Setelan TIDAK ikut). Aktif setelah ocr.js termuat (kecil, dimuat malas).
  const MANUAL = '__manual__', JL = [['', 'Bawaan'], ['gemini', 'Gemini'], ['sakelar', 'Sakelar'], ['relay', 'Relay']];
  const jBtns = JL.map(([v, t]) => h('button', { type: 'button', class: 'kai-wc', 'data-j': v, disabled: 'disabled', onclick: () => pilihJalur(v) }, t));
  const jSel = h('select', { class: 'in aisel', 'aria-label': 'Model baca foto', disabled: 'disabled' });
  const jMan = h('input', { class: 'in', type: 'text', autocomplete: 'off', autocapitalize: 'none', spellcheck: 'false', placeholder: 'mis. gemini-3.5-flash', 'aria-label': 'Nama model baca foto (ketik manual)', style: 'display:none' });
  const jNote = h('small', { class: 'aimeta' }, '');
  const paintJ = () => {
    jBtns.forEach((b) => { const on = b.getAttribute('data-j') === jal.provider; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); b.disabled = !O; });
    const pre = O ? O.modelSiapPilih(jal.provider) : [], manual = !!jal.model && !pre.includes(jal.model);
    jSel.textContent = ''; jSel.append(h('option', { value: '' }, 'Bawaan Worker'));
    pre.forEach((m) => jSel.append(h('option', { value: m }, m)));
    if (jal.provider) jSel.append(h('option', { value: MANUAL }, 'Ketik manual\u2026'));
    jSel.value = manual ? MANUAL : (jal.model || ''); jSel.disabled = !O || !jal.provider; jMan.value = manual ? jal.model : ''; jMan.style.display = manual ? '' : 'none';
    jNote.textContent = !O ? '' : !jal.provider ? 'Bawaan = jalur dan model yang diatur di Worker (Gemini bila tidak diubah).' : jal.provider === 'gemini' ? 'Gemini membaca foto langsung. flash-lite biasanya lebih cepat.' : 'Model HARUS bisa membaca gambar; model teks saja akan gagal. Belum diuji untuk jalur ini.' + (jal.provider === 'relay' && !jal.model ? ' Relay tidak punya model bawaan: ketik manual, atau isi MODEL_RELAY di Worker.' : '');
  };
  const simpanJ = (p) => { const r = O.simpanJalur(p); if (!r.ok) { tWarn(r.msg); return false; } jal = { provider: r.provider, model: r.model }; paintJ(); return true; };
  const pilihJalur = (v) => { if (busy || !O) return; if (simpanJ({ provider: v, model: '' })) status.textContent = 'Jalur baca foto: ' + (v ? O.JALUR_NAMA[v] : 'bawaan Worker') + '. Ketuk Baca teks untuk mencoba.'; };
  jSel.onchange = () => { if (busy || !O) return; if (jSel.value === MANUAL) { jMan.style.display = ''; jMan.focus(); return; } simpanJ({ provider: jal.provider, model: jSel.value }); };
  jMan.onchange = () => { if (busy || !O) return; const m = O.bersihkanJalur({ provider: jal.provider, model: jMan.value }); if (!jMan.value.trim()) { tWarn('Isi nama model, atau pilih \u201cBawaan Worker\u201d.'); return; } if (!m.model) { tWarn('Nama model tidak valid: 3-81 karakter, hanya huruf, angka, titik, garis miring, titik dua, dan minus.'); return; } simpanJ(m); };
  (async () => { try { O = await import('./ocr.js'); jal = O.bacaJalur(); } catch (_) { O = null; jNote.textContent = 'Pilihan jalur tidak tersedia; memakai jalur bawaan Worker.'; return; } if (ov.isConnected) paintJ(); })();
  bRead.onclick = () => { if (busy || !file) return; if (setuju()) baca(); else tanyaSetuju(() => { bRev.hidden = false; baca(); }, perluLain(jal)); }; // Rev 356 / O4: satu-satunya jalan ke jaringan lewat persetujuan
  bLain.onclick = () => { if (busy || !file || !O) return; const n = O.jalurBerikut(jal.provider); if (!simpanJ({ provider: n, model: '' })) return; bLain.hidden = true; status.textContent = 'Jalur baca foto: ' + O.JALUR_NAMA[n] + '.'; bRead.onclick(); }; // Rev 374 / OJ5: pindah MANUAL, lalu lewat gerbang persetujuan yang sama
  bIns.onclick = () => { const t = ta.value; if (!t.trim()) { tWarn('Teks kosong.'); return; } if (onInsert(t)) { close(); tOk('Teks disisipkan. Bisa Urungkan.'); } };
  const bRev = h('button', { type: 'button', class: 'btn line2', ...(sudahSetuju() || sudahSetujuLain() ? {} : { hidden: 'hidden' }) }, 'Cabut persetujuan kirim foto');
  bRev.onclick = () => { catatSetujuLain(false); if (catatSetuju(false)) { bRev.hidden = true; tOk('Persetujuan dicabut. Kamu akan ditanya lagi saat Baca teks.'); } else tErr('Persetujuan gagal dicabut.'); };
  bNew.onclick = async () => { // Rev 355 / O3b: catatan BARU dari teks di kotak; catatan yang sedang terbuka TIDAK disentuh; dialog tertutup hanya bila berhasil
    if (busy) return; const d = draftDariOcr(ta.value); if (!d) { tWarn('Teks kosong.'); return; }
    busy = true; bNew.disabled = true; let ok = false;
    try { ok = await onNew(d); } catch (_) { ok = false; }
    busy = false; bNew.disabled = false; if (ok && ov.isConnected) close();
  };
  bCopy.onclick = async () => { (await salin(ta.value)) ? tOk('Teks disalin.') : tErr('Gagal menyalin.'); };
  ov.append(h('div', { class: 'sheet dlg' },
    h('h3', {}, 'Pindai teks dari foto'),
    h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Sumber foto' }, h('button', { type: 'button', class: 'kai-wc', onclick: () => inCam.click() }, 'Kamera'), h('button', { type: 'button', class: 'kai-wc', onclick: () => inGal.click() }, 'Galeri')),
    inCam, inGal, img, status,
    h('small', { class: 'kai-ocr-jl' }, 'Jalur baca foto'), h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Jalur baca foto' }, ...jBtns), jSel, jMan, jNote,
    bRead, bLain, ta,
    h('div', { class: 'kai-apply' }, bIns, bNew, bCopy),
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: close }, 'Batal'), bRev)));
  document.body.append(ov); return true;
}
// Dipanggil notes.js saat tombol "Pindai" diketuk. env: { r (Range kursor atau null), ed, flushHist, auto, setRng }.
export function mulaiOcr(env) {
  const { r, ed, ctx } = env, saved = r ? r.cloneRange() : null;
  return bukaOcr({ onNew: async (d) => { // Rev 355 / O3b: memakai jalur buat-catatan yang SUDAH ada (aksi.js: createNote/removeNote), dimuat malas
    if (!ctx) { tErr('Catatan baru gagal dibuat.'); return false; }
    const { createNote, removeNote } = await import('./aksi.js'), n = createNote(ctx, { title: d.title, text: d.text, html: d.html });
    if (!n) { tErr('Catatan baru gagal dibuat.'); return false; }
    tOk('Catatan baru dibuat dari foto' + (d.cut ? ' (teks dipotong di 20.000 huruf)' : '') + '.', () => { removeNote(ctx, n.id); });
    return true;
  }, onInsert: (text) => { if (!ed.isConnected) { tErr('Editor sudah tertutup.'); return false; } return sisipTeks(ed, saved, text, env); } });
}
