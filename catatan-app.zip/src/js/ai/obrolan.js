// Rev 202b / Kelimaa AI Tahap 1c: layar CHAT UMUM (Setelan > Kelimaa AI > Buka chat). Dimuat MALAS lewat layar.js.
// Hanya teks yang diketik di sini yang dikirim. TIDAK ada isi catatan, tugas, atau Catatan Privat.
// Teks balasan AI selalu lewat node teks (textContent), tidak pernah HTML mentah.
// Rev 212 / langkah 3: tampilan STIKER TEBAL (judul KELIMAA AI, balon bergaris tebal, avatar bintang lewat CSS, jam di sudut balon, kolom ketik + tombol kirim berikon). Kolom ketik memakai warna tema (terbaca di gelap dan terang).
// Rev 223 / Bagian 1 desain ulang: layar chat LAYAR PENUH ala aplikasi chat modern (referensi pengguna): bilah atas (riwayat kiri, gerigi pengaturan kanan), sapaan + saran saat kosong, kolom ketik berbentuk pil, laci Riwayat. Pilihan jenis pekerjaan (Umum/Analisis/Kreatif/Cepat) DIHAPUS dari layar: chat selalu memakai chat.general; jalur dan model dipilih di Pengaturan AI.
// Rev 214 / Tahap 2: RUANG (workspace) percakapan. Tiap ruang punya nama, jenis pekerjaan sendiri, dan riwayat sendiri. Di aplikasi HP riwayat disimpan sebagai berkas lewat ai/ruang.js (bukan penyimpanan peramban, tidak ikut cadangan); di luar HP hanya di memori.
import { h, ico, judul, PATH, toast, dlg, svgEl, infoKey, tErr, tOk, tWarn, tInfo } from '../ui.js';
const icoBeranda = () => { const s = svgEl('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true' }); s.append(svgEl('path', { d: 'M3.5 11.5L12 4l8.5 7.5M5.5 10v9a1 1 0 001 1h11a1 1 0 001-1v-9' }), svgEl('path', { class: 'f', d: 'M12 11.4l.95 2.15 2.15.95-2.15.95L12 17.6l-.95-2.15-2.15-.95 2.15-.95z' })); return s; }; // Rev 310a: rumah + bintang beraksen (A1)
import { isNative } from '../native.js';
import { loadConn, loadCfg, cleanChatInput, buildMessages, kirimChat, kirimRiset, chatOpts, pilihanText, tokensText, CHAT_MAX_MSG } from './sambungan.js';
import { cleanSources, researchText, isGrounded, queriesLine, cleanSuggest, googleLink, researchExtras } from './riset.js'; // Rev 232, Rev 233
import { openExternal } from '../links.js'; // Rev 232
import * as R from './ruang.js';
import { toLocalInput, fromLocalInput } from '../reminders.js'; // Rev 229
import { rowDrafts, sheetChoices, appendRows, restoreRows, appendSummary, appendError } from './baris.js'; // Rev 230
import { buildBackup, parseBackup, mergeRestore, backupName, saveBackupFile, pickBackupText } from './cadangan.js'; // Rev 228
import { parse, toDom, toPlain } from './markdown.js'; // Rev 227: balasan AI bergaya (tebal, miring, daftar) tanpa tanda **, *, <i>
import { buildInsight, insightPrompt } from './insight.js'; // Rev 237
import { CTX_SOURCES, loadPerms, savePerms, buildContext, attachContext, anyOn, livePerms, tempelOn, setTempel } from './konteks.js';
import { bukaPemilihData } from './pemilihui.js'; // Rev 308b // Rev 221; Rev 308a: izin per ID
import { buatEntri, catat } from './riwayat-token.js'; // Rev 309a: pencatat riwayat token
import { isiRiwayat } from './riwayatui.js'; // Rev 309b: isi tab Riwayat token
import { buildAttachment, withAttachment, budgetFor, attSummary, attachable, cleanAtt, estTokens } from './lampiran.js'; // Rev 306b: lampiran catatan (mesin murni 306a)
import { bukaPemilih, bukaPratinjau, buatBarisChip, chipBalon, I_KLIP, WORKER_LAMA, pesanWorkerLama } from './lampiranui.js'; // Rev 306b
import { noteDraft, createNote, removeNote, appendNote, restoreNote, appendableNotes, noteLabel, taskDrafts, createTasks, removeTasks, TASK_SCOPES, createReminders, remindPresets, remindSummary, cleanRemindAt, REMIND_REPEATS, activeProjects, linkTasksToProject, unlinkTasks } from './aksi.js'; // Rev 216, 219, 222, 236

let riwayat = [];   // pesan ruang aktif: [{role, content, t}]
let sibuk = false;
const TUGAS = 'chat.general'; // Rev 223: chat selalu jenis umum (pilihan jenis pekerjaan dihapus dari layar)
let idx = null, store = null, mode = 'mem', note = ''; // mode: 'file' (tersimpan), 'mem' (hanya memori), 'err' (berkas bermasalah, hanya memori)
const memo = new Map(); // riwayat per ruang saat mode bukan 'file'
const SEND_D = 'M3 20.5 21 12 3 3.5l.1 6.6L15 12 3.1 13.9z';
const hm = () => { const d = new Date(); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
const logoEl = () => h('h1', { class: 'kai-logo' }, ico(PATH.star), h('span', {}, 'KELIMAA ', h('b', {}, 'AI')));

async function muat() { // sekali per aplikasi dibuka
  if (idx) return;
  idx = R.defaultIndex(Date.now());
  if (!isNative()) { mode = 'mem'; return; }
  try { store = R.openStore(); } catch (e) { mode = 'err'; note = 'plugin penyimpanan tidak tersedia'; return; }
  const r = await store.loadIndex();
  if (!r.ok) { mode = 'err'; note = r.msg; return; }
  idx = r.idx; const m = await store.loadMsgs(idx.active);
  if (!m.ok) { mode = 'err'; note = m.msg; return; }
  mode = 'file'; riwayat = m.msgs;
}
async function bacaPesan(id) {
  if (mode !== 'file') return memo.get(id) || [];
  const m = await store.loadMsgs(id); if (m.ok) return m.msgs;
  toast('Riwayat gagal dibaca: ' + m.msg); return [];
}
async function tulisPesan(id, msgs) {
  if (mode !== 'file') { memo.set(id, msgs); return; }
  const r = await store.saveMsgs(id, msgs); if (!r.ok) toast('Riwayat gagal disimpan: ' + r.msg);
}
async function tulisIndeks() {
  if (mode !== 'file') return;
  const r = await store.saveIndex(idx); if (!r.ok) toast('Daftar ruang gagal disimpan: ' + r.msg);
}
const catatanSimpan = () => (mode === 'file' ? 'Riwayat tiap ruang tersimpan di HP ini (tidak ikut cadangan).' : mode === 'err' ? 'Riwayat TIDAK bisa disimpan (' + note + '); hanya di memori.' : 'Riwayat hanya di memori selama aplikasi terbuka.');

// Rev 227: ikon dialog simpan (garis, mengikuti warna tema).
const I_SV = { note: 'M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h4', append: 'M12 5v14M5 12h14', task: 'M5 12.5l4.2 4.2L19 7', bell: 'M6 16v-5a6 6 0 0112 0v5l1.5 2h-15zM10 20a2 2 0 004 0', sheet: 'M4 5h16v14H4zM4 10h16M4 15h16M10 5v14' };
// Rev 219: dialog simpan balasan AI: catatan baru (note.create) atau tambah ke catatan yang ada (note.append). Batal selalu tombol .line pertama (tombol Kembali HP). Daftar catatan di luar .dlgb.
function tanyaSimpan(ctx, d) {
  const ov = h('div', { class: 'ov dlgov kai-tulis kai-save' }), sheet = h('div', { class: 'sheet dlg' }), tutup = () => ov.remove(), drafts = taskDrafts(d.text), barisD = rowDrafts(d.text), lembarC = barisD.length ? sheetChoices(ctx) : [];
  ov.addEventListener('click', (e) => { if (e.target === ov) tutup(); });
  const batal = h('button', { type: 'button', class: 'btn line sv-no', onclick: tutup }, 'Batal');
  const baru = h('button', { type: 'button', class: 'btn sv-main', onclick: () => {
    tutup(); const n = createNote(ctx, d); if (!n) { tErr('Catatan gagal dibuat.'); return; }
    tOk('Disimpan ke Catatan.', () => { removeNote(ctx, n.id); });
  } }, ico(I_SV.note), 'Simpan sebagai catatan baru');
  const awal = () => {
    sheet.textContent = '';
    const tambah = h('button', { type: 'button', class: 'btn line sv-alt', onclick: pilih }, ico(I_SV.append), 'Tambah ke catatan yang ada');
    // Rev 227: pratinjau isi yang akan disimpan (judul + beberapa baris pertama, tanpa tanda Markdown)
    const sisa = d.text.split('\n').slice(d.title ? 1 : 0).join(' ').replace(/\s+/g, ' ').trim();
    const pv = h('div', { class: 'sv-pv' }, d.title ? h('b', {}, d.title) : null, sisa ? h('span', {}, sisa.slice(0, 220)) : null);
    sheet.append(h('div', { class: 'sv-badge', 'aria-hidden': 'true' }, ico(I_SV.note)), h('h3', {}, 'Simpan ke Catatan?'), h('p', { class: 'sub' }, 'Jadikan catatan baru, tambahkan ke catatan yang sudah ada' + (drafts.length ? ', atau jadikan tugas atau pengingat' : '') + (lembarC.length ? (drafts.length ? '; baris datanya juga bisa masuk ke lembar kerja' : ', atau tambahkan barisnya ke lembar kerja') : '') + '. Catatan Privat tidak tersentuh.'), pv, h('div', { class: 'dlgb rev' }, batal, tambah, ...(drafts.length ? [h('button', { type: 'button', class: 'btn line sv-alt', onclick: tugasLayar }, ico(I_SV.task), 'Jadikan tugas'), h('button', { type: 'button', class: 'btn line sv-alt', onclick: pengingatLayar }, ico(I_SV.bell), 'Jadikan pengingat')] : []), ...(lembarC.length ? [h('button', { type: 'button', class: 'btn line sv-alt', onclick: barisLayar }, ico(I_SV.sheet), 'Tambah ke lembar kerja')] : []), baru));
  };
  const pilih = () => {
    const ns = appendableNotes(ctx);
    sheet.textContent = '';
    const kolom = h('div', { class: 'kai-pick' }, ns.length ? ns.map((n) => h('button', { type: 'button', class: 'btn line', onclick: () => {
      tutup(); const lb = noteLabel(n), r = appendNote(ctx, n.id, d);
      if (!r) { tErr('Gagal menambah (catatan terlalu besar).'); return; }
      toast('Ditambahkan ke \u201c' + lb + '\u201d.', () => { restoreNote(ctx, n.id, r.prev); });
    } }, noteLabel(n))) : h('p', { class: 'sub' }, 'Belum ada catatan biasa.'));
    sheet.append(h('h3', {}, 'Tambah ke catatan mana?'), h('p', { class: 'sub' }, 'Teks ditambahkan di akhir catatan yang kamu pilih. Bisa diurungkan lewat toast.'), kolom, h('div', { class: 'dlgb rev' }, batal));
  };
  // Rev 222: task.create. Daftar butir bisa dicentang, lingkup dipilih, baru dibuat; toast Urungkan menghapus tugas yang baru dibuat.
  const tugasLayar = () => {
    sheet.textContent = ''; let scope = 'hari';
    const rows = drafts.map((t) => { const cb = h('input', { type: 'checkbox', checked: 'checked', 'aria-label': t }); return { cb, t, el: h('label', { class: 'kai-trow' }, cb, h('span', {}, t)) }; });
    const seg = TASK_SCOPES.map((x) => h('button', { type: 'button', class: 'kai-wc', 'data-scope': x[0], onclick: () => { scope = x[0]; paint(); } }, x[1]));
    const projs = activeProjects(ctx).slice(0, 30); // Rev 236: pilihan proyek opsional (hanya proyek aktif)
    const selP = projs.length ? h('select', { class: 'in', 'aria-label': 'Tautkan ke proyek' }, [h('option', { value: '' }, 'Tanpa proyek')].concat(projs.map((x) => h('option', { value: x.id }, x.name)))) : null;
    const bOk = h('button', { type: 'button', class: 'btn', onclick: () => {
      const pick = rows.filter((r) => r.cb.checked).map((r) => r.t); if (!pick.length) { tWarn('Pilih minimal satu tugas.'); return; }
      tutup(); const ids = createTasks(ctx, pick, scope); if (!ids || !ids.length) { tErr('Tugas gagal dibuat.'); return; }
      const pj = selP ? projs.find((x) => x.id === selP.value) : null, lk = pj ? linkTasksToProject(ctx, pj.id, ids) : null; // Rev 236
      toast(ids.length + ' tugas dibuat di ' + TASK_SCOPES.find((x) => x[0] === scope)[1] + (lk ? (lk.linked ? ' dan ditautkan ke proyek \u201c' + pj.name + '\u201d' + (lk.skipped ? ' (' + lk.skipped + ' tidak muat)' : '') : ', tapi proyek \u201c' + pj.name + '\u201d penuh') : '') + '.', () => { unlinkTasks(ctx, ids); removeTasks(ctx, ids); });
    } }, 'Buat tugas');
    const upd = () => { const n = rows.filter((r) => r.cb.checked).length; bOk.textContent = n ? 'Buat ' + n + ' tugas' : 'Buat tugas'; bOk.disabled = !n; };
    const paint = () => seg.forEach((b) => { const on = b.getAttribute('data-scope') === scope; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
    rows.forEach((r) => r.cb.addEventListener('change', upd));
    sheet.append(h('h3', {}, 'Jadikan tugas?'), h('p', { class: 'sub' }, 'Judul otomatis KAPITAL. Centang tugas yang mau dibuat dan pilih letaknya. Tenggat dan pengingat bisa diatur sesudahnya di tab Tugas.'), h('div', { class: 'kai-pick' }, rows.map((r) => r.el)), h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Letak tugas' }, seg), selP, h('div', { class: 'dlgb rev' }, batal, bOk));
    paint(); upd();
  };
  // Rev 229: reminder.set. Butir dicentang -> tugas BARU yang punya pengingat (waktu dipilih pengguna, sekali atau tiap hari); toast Urungkan menghapus tugas dan membatalkan alarmnya.
  const pengingatLayar = () => {
    sheet.textContent = ''; let scope = 'hari', at = 0, rep = 'once';
    const rows = drafts.map((t) => { const cb = h('input', { type: 'checkbox', checked: 'checked', 'aria-label': t }); return { cb, t, el: h('label', { class: 'kai-trow' }, cb, h('span', {}, t)) }; });
    const dt = h('input', { class: 'in', type: 'datetime-local', 'aria-label': 'Waktu pengingat' });
    const chips = remindPresets().map((p) => h('button', { type: 'button', class: 'kai-wc', 'data-at': String(p.at), onclick: () => { at = p.at; dt.value = toLocalInput(p.at); paint(); } }, p.label));
    const segS = TASK_SCOPES.map((x) => h('button', { type: 'button', class: 'kai-wc', 'data-scope': x[0], onclick: () => { scope = x[0]; paint(); } }, x[1]));
    const segR = REMIND_REPEATS.map((x) => h('button', { type: 'button', class: 'kai-wc', 'data-rep': x[0], onclick: () => { rep = x[0]; paint(); } }, x[1]));
    const bOk = h('button', { type: 'button', class: 'btn', onclick: () => {
      const pick = rows.filter((r) => r.cb.checked).map((r) => r.t); if (!pick.length) { tWarn('Pilih minimal satu pengingat.'); return; }
      if (!cleanRemindAt(at)) { infoKey('chatWaktu'); return; }
      tutup(); const r = createReminders(ctx, pick, scope, at, rep); if (!r) { tErr('Pengingat gagal dibuat.'); return; }
      toast(remindSummary(r.ids.length, r.results), () => { removeTasks(ctx, r.ids); });
    } }, 'Buat pengingat');
    const paint = () => {
      segS.forEach((b) => { const on = b.getAttribute('data-scope') === scope; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
      segR.forEach((b) => { const on = b.getAttribute('data-rep') === rep; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
      chips.forEach((b) => { const on = Number(b.getAttribute('data-at')) === at; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
      const n = rows.filter((r) => r.cb.checked).length; bOk.textContent = n > 1 ? 'Buat ' + n + ' pengingat' : 'Buat pengingat'; bOk.disabled = !n || !cleanRemindAt(at);
    };
    dt.addEventListener('change', () => { at = fromLocalInput(dt.value); paint(); });
    rows.forEach((r) => r.cb.addEventListener('change', paint));
    sheet.append(h('h3', {}, 'Jadikan pengingat?'), h('p', { class: 'sub' }, 'Butir yang dicentang dibuat sebagai tugas dengan alarm di waktu yang kamu pilih. Alarm hanya berbunyi di aplikasi HP.'), h('div', { class: 'kai-pick' }, rows.map((r) => r.el)), h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Pilihan waktu cepat' }, chips), dt, h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Ulangi' }, segR), h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Letak tugas' }, segS), h('div', { class: 'dlgb rev' }, batal, bOk));
    paint();
  };
  // Rev 230: sheet.append_row. Baris dicentang (baris judul tabel tidak dicentang bawaannya) -> ditambahkan di bawah baris terisi terakhir pada lembar + tab pilihan; toast Urungkan mengembalikan isi dan membuang baris yang ditambah.
  const barisLayar = () => {
    sheet.textContent = '';
    const rows = barisD.map((r) => { const cb = h('input', { type: 'checkbox', 'aria-label': r.cells.join(' | ') }); if (!r.head) cb.checked = true; return { cb, cells: r.cells, el: h('label', { class: 'kai-trow' }, cb, h('span', {}, (r.head ? 'Judul: ' : '') + r.cells.join(' \u2022 '))) }; });
    const selS = h('select', { class: 'in', 'aria-label': 'Lembar kerja' }, lembarC.map((x) => h('option', { value: x.id }, x.name)));
    const selT = h('select', { class: 'in', 'aria-label': 'Tab lembar' });
    const isiTab = () => { const x = lembarC.find((y) => y.id === selS.value) || lembarC[0]; selT.textContent = ''; x.tabs.forEach((t) => selT.append(h('option', { value: t.id }, t.name))); selT.hidden = x.tabs.length < 2; };
    const bOk = h('button', { type: 'button', class: 'btn', onclick: () => {
      const pick = rows.filter((r) => r.cb.checked).map((r) => r.cells); if (!pick.length) { tWarn('Pilih minimal satu baris.'); return; }
      const x = lembarC.find((y) => y.id === selS.value); if (!x) return;
      tutup(); const res = appendRows(ctx, x.id, selT.value || x.tabs[0].id, pick); if (res.error) { toast(appendError(res.error)); return; }
      toast(appendSummary(res, x.name), () => { restoreRows(ctx, res); });
    } }, 'Tambah baris');
    const upd = () => { const n = rows.filter((r) => r.cb.checked).length; bOk.textContent = n > 1 ? 'Tambah ' + n + ' baris' : 'Tambah baris'; bOk.disabled = !n; };
    rows.forEach((r) => r.cb.addEventListener('change', upd)); selS.addEventListener('change', isiTab); isiTab(); upd();
    sheet.append(h('h3', {}, 'Tambah ke lembar kerja?'), h('p', { class: 'sub' }, 'Baris yang dicentang ditambahkan di bawah data terakhir. Hanya teks dan angka; rumus dan format lembar tidak berubah. Bisa diurungkan lewat toast.'), h('div', { class: 'kai-pick' }, rows.map((r) => r.el)), selS, selT, h('div', { class: 'dlgb rev' }, batal, bOk));
  };
  awal(); ov.append(sheet); document.body.append(ov);
}

// Rev 223: ikon garis (stroke mengikuti CSS .kc svg). Folder = Riwayat, plus = Data aplikasi, close = tutup, more = menu ruang.
const I = {
  folder: 'M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z',
  plus: 'M12 5v14M5 12h14',
  plan: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 7.5V12l3 2',
  tulis: 'M4.2 19.8l1-4.3L16.4 4.3a2.2 2.2 0 013.1 3.1L8.3 18.6zM14.2 6.5l3.3 3.3',
  ringkas: 'M6 3h12v18H6zM9 8h6M9 12h6M9 16h3',
  baru: 'M4.2 19.8l1-4.3L16.4 4.3a2.2 2.2 0 013.1 3.1L8.3 18.6z',
  web: 'M12 21a9 9 0 100-18 9 9 0 000 18zM3 12h18M12 3c2.5 2.5 3.8 5.5 3.8 9S14.5 18.5 12 21c-2.5-2.5-3.8-5.5-3.8-9S9.5 5.5 12 3z',
  eye: 'M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12zM12 15a3 3 0 100-6 3 3 0 000 6z',
  spark: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z',
};
const SARAN = [[I.plan, 'Susun rencana minggu ini'], [I.tulis, 'Bantu aku menulis pesan yang sopan'], [I.ringkas, 'Ringkas teks panjang yang aku tempel']];
const salam = () => { const j = new Date().getHours(); return j < 11 ? 'Selamat pagi' : j < 15 ? 'Selamat siang' : j < 18 ? 'Selamat sore' : 'Selamat malam'; };
const kalimatTop = (n) => (n ? 'kc-ttl on' : 'kc-ttl');

export function viewChat(ctx) {
  const { ui } = ctx;
  const keAI = () => { ui.aiFrom = 'chat'; ui.moreView = 'ai'; ctx.render(); const m = document.querySelector('#app > main'); if (m) m.scrollTop = 0; };
  const keluar = () => { const t = ui.prevTab && ui.prevTab !== 'ai' ? ui.prevTab : 'catatan', b = document.querySelector('nav button[data-tab="' + t + '"]'); if (b) b.click(); }; // sama dengan mengetuk tab di bilah bawah
  const siap = !!loadConn() && loadCfg().on;
  if (!siap) {
    return [h('div', { class: 'kc kc-off' }, logoEl(), h('p', { class: 'kc-sub' }, 'Simpan sambungan dan nyalakan sakelar Kelimaa AI dulu, baru chat bisa dipakai.'), h('button', { type: 'button', class: 'kc-btn', onclick: keAI }, 'Pengaturan AI'), h('button', { type: 'button', class: 'kc-btn line', onclick: keluar }, 'Kembali ke aplikasi'))];
  }
  const list = h('div', { class: 'aichat', 'aria-live': 'polite' });
  // Rev 226: tombol salin pada balasan AI (ikon tanpa teks); mengetuk tombol TIDAK membuka dialog simpan. Teks balasan = node teks pertama.
  const salin = async (text) => {
    try { await navigator.clipboard.writeText(text); tOk('Balasan disalin.'); return; } catch (_) { /* coba cara lama */ }
    try { const t = h('textarea', { style: 'position:fixed;opacity:0' }); t.value = text; document.body.append(t); t.select(); const ok = document.execCommand('copy'); t.remove(); toast(ok ? 'Balasan disalin.' : 'Gagal menyalin.'); } catch (_) { tErr('Gagal menyalin.'); }
  };
  const pasangSalin = (el) => { el.append(h('button', { type: 'button', class: 'kc-cp', 'aria-label': 'Salin balasan', onclick: (ev) => { ev.stopPropagation(); salin(toPlain(parse(el._raw || ''))); } }, ico(PATH.copy))); };
  // Rev 227: isi balasan AI = node DOM hasil pengurai Markdown (bukan HTML mentah). Teks asli disimpan di el._raw untuk salin dan simpan ke Catatan.
  const isiBot = (el, text) => { el._raw = String(text == null ? '' : text); el.textContent = ''; el.append(toDom(parse(el._raw))); pasangSalin(el); };
  const chipUser = (el, att) => { const cb = el.classList.contains('user') ? chipBalon(att) : null; if (cb) el.prepend(cb); return el; }; // Rev 306b: chip lampiran di atas teks balon pengguna (hanya rujukan judul)
  const bub = (kind, text, t, extra) => { const el = h('div', { class: 'aib ' + kind }, kind === 'bot' ? '' : text); if (t) el.setAttribute('data-t', t); if (kind === 'bot') isiBot(el, text); if (kind === 'bot' && extra) ekstraBot(el, extra); list.append(el); empty.hidden = true; try { el.scrollIntoView({ block: 'nearest' }); } catch (_) { /* abaikan */ } return el; };
  // Rev 216: ketuk balasan AI = usulan simpan ke Catatan; dialog konfirmasi dulu, lalu toast Urungkan.
  list.addEventListener('click', (ev) => {
    const el = ev.target && ev.target.closest ? ev.target.closest('.aib.bot') : null;
    if (!el || el.classList.contains('wait') || !list.contains(el)) return;
    const d = noteDraft(el._raw || ''); if (!d) return;
    tanyaSimpan(ctx, d);
  });
  const ta = h('textarea', { class: 'kc-in', rows: '1', maxlength: String(CHAT_MAX_MSG), placeholder: 'Tulis pesan…', 'aria-label': 'Pesan untuk Kelimaa AI' });
  const grow = () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 132) + 'px'; };
  ta.addEventListener('input', grow);
  const send = h('button', { type: 'button', class: 'kc-send', 'aria-label': 'Kirim' }, ico(SEND_D));
  const meta = h('div', { class: 'kc-meta' }, pilihanText(loadCfg()));
  // ---- Kosong: sapaan + saran
  const empty = h('div', { class: 'kc-empty' },
    h('div', { class: 'kc-mark' }, ico(PATH.star)),
    h('div', { class: 'kc-hi' }, salam() + ', mau ngobrol apa?'),
    h('p', { class: 'kc-sub' }, 'Ketuk balasan AI untuk menyimpannya ke Catatan atau menjadikannya tugas.'),
    h('div', { class: 'kc-sug' }, SARAN.map(([d, t]) => h('button', { type: 'button', class: 'kc-s', onclick: () => { ta.value = t; grow(); ta.focus(); } }, ico(d), h('span', {}, t)))));
  const body = h('div', { class: 'kc-body' }, empty, list);
  const turun = h('button', { type: 'button', class: 'kc-down', hidden: 'hidden', 'aria-label': 'Ke pesan terbaru', onclick: () => { try { body.scrollTo({ top: body.scrollHeight, behavior: 'smooth' }); } catch (_) { body.scrollTop = body.scrollHeight; } } }, ico(PATH.moveDown));
  body.addEventListener('scroll', () => { turun.hidden = body.scrollHeight - body.scrollTop - body.clientHeight < 120; }, { passive: true });
  // ---- Bilah atas
  const ttl = h('div', { class: 'kc-ttl' }, '');
  const paintTop = () => { const w = idx ? R.activeWs(idx) : null; ttl.textContent = ''; ttl.className = kalimatTop(riwayat.length); if (riwayat.length && w) ttl.append(ico(PATH.star), h('span', {}, w.name)); else ttl.append(judul('kelimaa')); }; // Rev 373: logo Kelimaa AI beranimasi (SVG), sama gaya dengan judul layar lain
  const paintList = () => { list.textContent = ''; riwayat.forEach((m) => chipUser(bub(m.role === 'user' ? 'user' : 'bot', m.content, m.t, m.role === 'assistant' ? m : null), m.att)); empty.hidden = list.children.length > 0; body.scrollTop = body.scrollHeight; };
  const paintAll = () => { paintTop(); paintList(); };
  // ---- Ruang (kini disebut Riwayat di layar)
  const pindah = async (id) => {
    if (sibuk) { tWarn('Tunggu balasan selesai dulu.'); return false; }
    if (id === idx.active) return true;
    const lama = idx.active, kosong = !riwayat.length && R.isFresh(R.activeWs(idx)) && idx.list.length > 1; // ruang baru yang tak jadi dipakai dibuang diam-diam
    memo.set(lama, riwayat);
    idx = R.setActive(idx, id); if (kosong) idx = R.removeWs(idx, lama);
    riwayat = await bacaPesan(id); lepasLamp(); paintAll(); await tulisIndeks(); return true;
  };
  const baru = async () => {
    if (sibuk) { tWarn('Tunggu balasan selesai dulu.'); return false; }
    if (!riwayat.length) { ta.focus(); return true; } // sudah di obrolan kosong
    const r = R.addWs(idx, R.uniqueName(idx, R.NEW_NAME)); if (!r.ok) { toast(r.msg); return false; }
    memo.set(idx.active, riwayat); idx = r.idx; riwayat = []; lepasLamp(); paintAll(); await tulisIndeks(); ta.focus(); return true;
  };
  // Rev 232: mode Cari di web (riset bersumber). Hanya di memori: mati lagi saat layar dibuka ulang. Data aplikasi TIDAK ikut dikirim di mode ini.
  let web = false;
  const kartuSumber = (el, sources) => { // chip tautan sumber di bawah balasan riset (hanya tampilan langsung; riwayat menyimpan nama sumber sebagai teks)
    const src = cleanSources(sources); if (!src.length) return;
    el.append(h('div', { class: 'kc-src', role: 'group', 'aria-label': 'Sumber' }, src.map((x) => h('button', { type: 'button', class: 'kc-sc', title: x.title, onclick: (ev) => { ev.stopPropagation(); if (!openExternal(x.uri)) tErr('Tautan gagal dibuka.'); } }, x.title))));
  };
  // Rev 233: Search Suggestions Google (WAJIB menurut dokumentasi resmi): HTML dari Worker ditampilkan APA ADANYA di iframe tanpa izin skrip, lebar penuh balasan, selalu ikut tampil selama balasan bersumber tampil (juga saat riwayat dibuka lagi). Ketukan tautan membuka halaman hasil Google langsung di peramban HP (tanpa layar perantara); tautan selain google.com tidak dibuka.
  const kartuSaran = (el, html) => {
    const sg = cleanSuggest(html); if (!sg) return;
    const f = h('iframe', { class: 'kc-sgf', title: 'Saran pencarian Google', sandbox: 'allow-same-origin', referrerpolicy: 'no-referrer', loading: 'lazy', scrolling: 'no' });
    f.srcdoc = sg; // sandbox TANPA izin skrip: skrip/penangan inline tidak jalan; izin same-origin hanya supaya induk bisa mengukur tinggi dan menangkap ketukan tautan
    f.addEventListener('load', () => {
      try {
        const d = f.contentDocument; if (!d) return;
        d.addEventListener('click', (ev) => { const a = ev.target && ev.target.closest ? ev.target.closest('a') : null; if (!a) return; ev.preventDefault(); ev.stopPropagation(); const u = googleLink(a.href); if (u && !openExternal(u)) tErr('Tautan gagal dibuka.'); });
        const hh = Math.ceil(Math.max(d.documentElement ? d.documentElement.scrollHeight : 0, d.body ? d.body.scrollHeight : 0)); if (hh >= 24) f.style.height = Math.min(hh, 220) + 'px';
      } catch (_) { /* tinggi bawaan tetap dipakai */ }
    });
    el.append(h('div', { class: 'kc-sg', 'aria-label': 'Saran pencarian Google' }, f));
  };
  const ekstraBot = (el, x) => { kartuSumber(el, x.src); kartuSaran(el, x.sg); }; // x = pesan tersimpan atau {src, sg}
  // Rev 306b: lampiran catatan. Pilihan (id) hidup di memori layar ini; Rev 306c: lampiran MENEMPEL, ikut dikirim di setiap pesan (isi dibaca ulang dari catatan tiap kirim, jadi selalu terbaru) sampai dilepas (x di chip), ganti/baru/hapus ruang percakapan, atau layar chat ditutup. Isi catatan TIDAK disimpan di riwayat, hanya rujukan {id, judul}.
  let lamp = [];
  const bilahLamp = buatBarisChip({ onLihat: () => bukaPratinjau({ data: ctx.data, ids: lamp, typedLen: ta.value.length, ctxLen: buildContext(ctx.data, loadPerms()).text.length }), onLepas: (id) => { lamp = lamp.filter((x) => x !== id); paintLamp(); } });
  const paintLamp = () => { const by = new Map(attachable(ctx.data).map((r) => [r.id, r.title])); lamp = lamp.filter((id) => by.has(id)); bilahLamp.paint(lamp.map((id) => ({ id, title: by.get(id) }))); kc.classList.toggle('on', anyOn(livePerms(ctx.data, perms)) || lamp.length > 0); };
  const lepasLamp = () => { if (lamp.length) { lamp = []; paintLamp(); } }; // Rev 306c: ganti/baru/hapus ruang = percakapan lain, lampiran tidak ikut pindah
  send.onclick = async () => {
    if (sibuk || !idx) return;
    const c = cleanChatInput(ta.value); if (!c.ok) { toast(c.msg); return; }
    const conn = loadConn(); if (!conn || !loadCfg().on) { tWarn('Simpan sambungan dan nyalakan Kelimaa AI dulu.'); return; }
    let ab = null; // Rev 306b: lampiran dibangun SEBELUM apa pun berubah; gagal = cukup toast, ketikan dan lampiran tetap
    if (lamp.length) {
      if (web) { tWarn('Lampiran tidak ikut saat Cari di web menyala. Matikan Cari di web dulu, atau lepas lampirannya.'); return; }
      ab = buildAttachment(ctx.data, lamp, { total: budgetFor(c.value.length, buildContext(ctx.data, loadPerms()).text.length) }); if (!ab.ok) { toast(ab.msg); return; }
    }
    const attRef = ab ? cleanAtt(ab.items.map((x) => ({ id: x.id, title: x.title }))) : [];
    let sentCtx = []; const typed = ta.value, wid = idx.active, pertama = !riwayat.length; sibuk = true; send.disabled = true; send.setAttribute('aria-busy', 'true'); ta.value = ''; grow(); meta.textContent = '';
    const cari = web, t0 = hm(), u = chipUser(bub('user', c.value, t0), attRef), w = bub('bot wait', cari ? 'Mencari…' : 'Mengetik…'); w.setAttribute('role', 'status');
    let res; try {
      if (cari) { res = await kirimRiset(conn, buildMessages(riwayat, c.value), undefined, { limit: chatOpts(loadCfg()).limit, monthLimit: chatOpts(loadCfg()).monthLimit }); if (res.ok) { res.shown = researchText(res); res.grounded = isGrounded(res); } } // Rev 232: riset TANPA data aplikasi (konteks tidak ditempel)
      else if (ab) { // Rev 306b: konteks data aplikasi + lampiran + ketikan, satu pesan (maks. 16000 huruf, batas Worker Rev 306a)
        const cx = buildContext(ctx.data, loadPerms()), wa = withAttachment(buildMessages(riwayat, c.value), { ctxText: cx.text, attText: ab.text });
        if (!wa.ok) res = { ok: false, msg: wa.msg }; else { sentCtx = wa.ctxUsed ? cx.parts.map((x) => x.id) : []; res = await kirimChat(conn, wa.messages, undefined, { ...chatOpts(loadCfg()), task: TUGAS }); if (!res.ok && WORKER_LAMA.test(res.msg || '')) res = { ok: false, msg: pesanWorkerLama }; }
      }
      else { const cx = buildContext(ctx.data, loadPerms()), at = attachContext(buildMessages(riwayat, c.value), cx.text); sentCtx = at.used ? cx.parts.map((x) => x.id) : []; res = await kirimChat(conn, at.messages, undefined, { ...chatOpts(loadCfg()), task: TUGAS }); }
    } catch (e) { res = { ok: false, msg: 'Kesalahan tak terduga.' }; }
    if (res.ok) {
      const t1 = hm(); const isi = cari ? res.shown : res.text; const ex = cari ? researchExtras(res) : {}; riwayat.push({ role: 'user', content: c.value, t: t0, ...(attRef.length ? { att: attRef } : {}) }, { role: 'assistant', content: isi, t: t1, ...ex }); riwayat = riwayat.slice(-R.MAX_KEEP);
      try { catat(buatEntri({ now: Date.now(), pesan: c.value, usage: res.usage, kirimChars: c.value.length + (ab ? ab.chars : 0), balasChars: String(isi || '').length, sumber: [...sentCtx, ...(ab ? ['lampiran'] : [])] }), Date.now()); } catch (_) { /* riwayat gagal tidak boleh mengganggu chat */ } // Rev 309a
      w.className = 'aib bot'; w.setAttribute('data-t', t1); isiBot(w, isi); if (cari) ekstraBot(w, ex);
      meta.textContent = [res.fallbackProvider ? res.provider + ' (dialihkan dari ' + res.fallbackProvider + ')' : res.provider, res.model, res.limit ? 'terpakai ' + res.used + '/' + res.limit + ' hari ini' : 'tanpa batas' + (typeof res.used === 'number' ? ' · hari ini ' + res.used : ''), res.monthLimit ? 'bulan ini ' + res.monthUsed + '/' + res.monthLimit : '', tokensText(res.monthTokens), sentCtx.length ? 'data dikirim: ' + sentCtx.join(', ') : '', ab ? (tempelOn() ? attSummary(ab.items) + ' (masih menempel, \u2248 ' + estTokens(ab.chars).toLocaleString('id-ID') + ' token per pesan)' : attSummary(ab.items) + ' (dilepas setelah balasan ini)') : '', cari ? queriesLine(res) : '', cari && isGrounded(res) && !ex.sg ? 'saran pencarian Google tidak dikembalikan (tempel ulang Worker terbaru)' : ''].filter(Boolean).join(' · ');
      if (ab && !tempelOn()) lepasLamp(); // Rev 308c
      if (ab) paintLamp(); // Rev 306c: lampiran TETAP menempel untuk pertanyaan lanjutan; paintLamp hanya menyegarkan (catatan yang sudah dihapus gugur sendiri)
      await tulisPesan(wid, riwayat);
      if (idx && idx.active === wid) { // judul riwayat = awal pesan pertama (hanya ruang bernama otomatis); lalu naik ke urutan Terkini
        if (pertama && R.isFresh(R.activeWs(idx))) { const rn = R.renameWs(idx, wid, R.uniqueName(idx, R.titleFrom(c.value), wid)); if (rn.ok) idx = rn.idx; }
        idx = R.touchWs(idx, wid); await tulisIndeks(); paintTop();
      }
    } else {
      u.remove(); w.className = 'aib err'; w.textContent = res.msg; ta.value = typed; grow();
    }
    try { w.scrollIntoView({ block: 'nearest' }); } catch (_) { /* abaikan */ }
    sibuk = false; send.disabled = false; send.removeAttribute('aria-busy');
  };
  // ---- Rev 221: Context Engine. Bawaan MATI per sumber; pratinjau = teks PERSIS yang ikut dikirim; Catatan Privat dan sampah tidak pernah ikut. Rev 223: dipindah ke lembar tombol + di kolom ketik.
  let perms = loadPerms();
  const bukaData = () => {
    const ov = h('div', { class: 'ov kai-tulis' }), sheet = h('div', { class: 'sheet dlg kd-sheet' }), ctxInfo = h('p', { class: 'kd-info' }, '');
    const SRC_ICO = { tugas: PATH.tugas, catatan: PATH.catatan, proyek: PATH.proyek };
    const btns = CTX_SOURCES.map((x) => h('button', { type: 'button', class: 'kd-row', 'data-src': x.id, onclick: () => {
        bukaPemilihData({ data: ctx.data, src: x.id, perms, onApply: (np) => { perms = np; const r = savePerms(perms); if (!r.ok) toast(r.msg); paint(); } });
      } },
      h('span', { class: 'kd-ic' }, ico(SRC_ICO[x.id] || PATH.tag)), h('span', { class: 'kd-tx' }, h('b', {}, x.label), h('small', { class: 'kd-pc' }, x.hint)), h('span', { class: 'kd-go', 'aria-hidden': 'true' }, ico(PATH.chev))));
    const actBody = (d, t, sub) => [h('span', { class: 'kd-ic' }, ico(d)), h('span', { class: 'kd-tx' }, h('b', {}, t), h('small', {}, sub)), h('span', { class: 'kd-go', 'aria-hidden': 'true' }, ico(PATH.chev))];
    const paint = () => { btns.forEach((b) => { const sid = b.getAttribute('data-src'), n = livePerms(ctx.data, perms)[sid].length, on = n > 0; b.classList.toggle('on', on); b.querySelector('.kd-pc').textContent = on ? n + ' dipilih. Ketuk untuk mengubah' : CTX_SOURCES.find((q) => q.id === sid).hint; }); const lv = livePerms(ctx.data, perms), nOn = CTX_SOURCES.filter((q) => lv[q.id].length > 0).length; ctxInfo.classList.toggle('on', nOn > 0); ctxInfo.textContent = nOn ? nOn + ' sumber berisi pilihan: yang dicentang ikut terkirim bersama tiap pesan. Ketuk Lihat data yang dikirim untuk memeriksanya.' : 'Semua mati: hanya yang kamu ketik yang dikirim.'; kc.classList.toggle('on', anyOn(livePerms(ctx.data, perms)) || lamp.length > 0); };
    const lihat = h('button', { type: 'button', class: 'kd-lnk', onclick: () => {
      const cx = buildContext(ctx.data, perms), o2 = h('div', { class: 'ov dlgov kai-tulis' });
      o2.append(h('div', { class: 'sheet dlg kd-sheet' }, h('h3', {}, 'Data yang dikirim'), h('p', { class: 'sub' }, cx.text ? 'Ini teks yang ditempel di depan pesanmu (' + cx.chars + ' huruf). Catatan Privat dan tempat sampah tidak pernah ikut.' : 'Tidak ada data aplikasi yang dikirim.'), cx.text ? h('div', { class: 'kai-tv' }, cx.text) : null, h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => o2.remove() }, 'Tutup'))));
      document.body.append(o2);
    } }, ico(I.eye), h('span', {}, 'Lihat data yang dikirim'));
    const lampir = h('button', { type: 'button', class: 'kd-act', onclick: () => { // Rev 306b: pilih catatan untuk dilampirkan (judul + isi)
      bukaPemilih({ data: ctx.data, ids: lamp, typedLen: ta.value.length, ctxLen: buildContext(ctx.data, perms).text.length, onApply: (ids) => { lamp = ids; paintLamp(); ov.remove(); ta.focus(); } });
    } }, actBody(I_KLIP, 'Lampirkan catatan', lamp.length ? lamp.length + ' catatan dilampirkan. Ketuk untuk mengubah' : 'Judul dan isi, mis. untuk diringkas'));
    const insight = h('button', { type: 'button', class: 'kd-lnk', onclick: () => { // Rev 237: ringkasan dihitung di HP; baru masuk ke kolom pesan bila dipilih, masih bisa diedit
      const ins = buildInsight(ctx.data), o3 = h('div', { class: 'ov dlgov kai-tulis' });
      const pakai = h('button', { type: 'button', class: 'btn', disabled: ins.empty ? 'disabled' : null, onclick: () => { o3.remove(); ov.remove(); ta.value = insightPrompt(ins.text, CHAT_MAX_MSG); grow(); ta.focus(); tInfo('Ringkasan masuk ke kolom pesan. Periksa dulu, lalu kirim.'); } }, 'Minta saran AI');
      o3.append(h('div', { class: 'sheet dlg kd-sheet' }, h('h3', {}, 'Insight mingguan'), h('p', { class: 'sub' }, 'Dihitung di HP dari tugas, waktu ubah catatan, proyek, dan hitungan kebiasaan harian (tanpa nama kebiasaan). Catatan Privat tidak ikut. Belum ada yang dikirim.'), h('div', { class: 'kai-tv' }, ins.lines.join('\n')), h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => o3.remove() }, 'Tutup'), pakai)));
      o3.addEventListener('click', (e) => { if (e.target === o3) o3.remove(); }); document.body.append(o3);
    } }, ico(I.spark), h('span', {}, 'Insight mingguan'));
    const tempel = h('button', { type: 'button', class: 'kd-row kd-tp', role: 'switch', 'aria-checked': 'false', onclick: () => { setTempel(!tempelOn()); paintTempel(); } },
      h('span', { class: 'kd-tx' }, h('b', {}, 'Tetap menempel di tiap pesan'), h('small', { class: 'kd-tpt' }, '')), h('span', { class: 'kd-sw', 'aria-hidden': 'true' }, h('i', {})));
    const paintTempel = () => { const on = tempelOn(); tempel.classList.toggle('on', on); tempel.setAttribute('aria-checked', String(on)); tempel.querySelector('.kd-tpt').textContent = on ? 'Ikut terus sampai kamu lepas' : 'Dilepas setelah balasan berhasil'; };
    const pData = h('div', { class: 'kd-pn', role: 'tabpanel', id: 'kd-p-data' }, h('div', { class: 'kd-priv' }, ico(PATH.lock), h('span', {}, 'Catatan Privat dan tempat sampah tidak pernah ikut.')),
      h('div', { class: 'kd-sec' }, 'Tugas dan proyek'), h('div', { class: 'kd-list', role: 'group', 'aria-label': 'Data aplikasi untuk AI' }, btns),
      h('div', { class: 'kd-sec' }, 'Catatan'), h('div', { class: 'kd-list' }, lampir, tempel), ctxInfo, h('div', { class: 'kd-lnks' }, lihat, insight));
    const pRiwayat = h('div', { class: 'kd-pn', role: 'tabpanel', id: 'kd-p-riwayat', hidden: 'hidden' });
    const tabs = h('div', { class: 'kd-tabs', role: 'tablist', 'aria-label': 'Bagian dialog' });
    const tabBtn = (id, label, panel) => h('button', { type: 'button', class: 'kd-tab', role: 'tab', 'data-tab': id, 'aria-controls': panel.id, onclick: () => pilihTab(id) }, label);
    const tD = tabBtn('data', 'Data', pData), tR = tabBtn('riwayat', 'Riwayat token', pRiwayat);
    const pilihTab = (id) => { [[tD, 'data', pData], [tR, 'riwayat', pRiwayat]].forEach(([b, k, pn]) => { const on = k === id; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); b.tabIndex = on ? 0 : -1; pn.hidden = !on; }); if (id === 'riwayat') isiRiwayat(pRiwayat); };
    tabs.append(tD, tR);
    sheet.append(h('div', { class: 'kd-head' }, h('span', { class: 'kd-hi' }, ico(I.spark)), h('div', { class: 'kd-ht' }, h('h3', {}, 'Data aplikasi untuk AI'), h('p', { class: 'sub' }, 'Pilih data yang boleh ikut dikirim bersama pesanmu. Bawaannya mati.'))), tabs, pData, pRiwayat, h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: () => ov.remove() }, 'Tutup')));
    ov.addEventListener('click', (e) => { if (e.target === ov) ov.remove(); });
    ov.append(sheet); document.body.append(ov); paint(); paintTempel(); pilihTab('data');
  };
  const kc = h('button', { type: 'button', class: 'kc-pl', 'aria-label': 'Data aplikasi untuk AI', onclick: bukaData }, ico(I.plus));
  const kw = h('button', { type: 'button', class: 'kc-pl kc-web', 'aria-label': 'Cari di web', 'aria-pressed': 'false', onclick: () => {
    web = !web; kw.classList.toggle('on', web); kw.setAttribute('aria-pressed', String(web)); ta.placeholder = web ? 'Cari di web…' : 'Tulis pesan…';
    toast(web ? 'Cari di web NYALA: pertanyaanmu dikirim ke Google Search lewat Gemini. Data aplikasi tidak ikut.' : 'Cari di web mati.');
  } }, ico(I.web));
  // ---- Laci Riwayat (dari ikon folder)
  const menuRuang = (w, segarkan) => {
    const ov = h('div', { class: 'ov dlgov kai-tulis' }), sheet = h('div', { class: 'sheet dlg' }), tutup = () => ov.remove();
    const nm = h('input', { class: 'kc-nm', type: 'text', maxlength: String(R.NAME_MAX), value: w.name, 'aria-label': 'Nama riwayat' });
    const batal = h('button', { type: 'button', class: 'btn line', onclick: tutup }, 'Batal');
    const simpan = h('button', { type: 'button', class: 'btn', onclick: async () => { const r = R.renameWs(idx, w.id, nm.value); if (!r.ok) { toast(r.msg); return; } idx = r.idx; tutup(); paintTop(); segarkan(); await tulisIndeks(); } }, 'Simpan nama');
    const hapus = h('button', { type: 'button', class: 'btn red', onclick: () => {
      if (sibuk) { tWarn('Tunggu balasan selesai dulu.'); return; }
      tutup();
      dlg({ title: 'Hapus riwayat?', msg: 'Percakapan "' + w.name + '" dihapus dari HP ini. Catatan dan data lain tidak berubah.', yes: 'Hapus', red: true, ok: async () => {
        const id = w.id; memo.delete(id); if (mode === 'file') await store.removeMsgs(id);
        const aktif = idx.active === id; idx = R.removeWs(idx, id); if (aktif) { riwayat = await bacaPesan(idx.active); lepasLamp(); }
        paintAll(); segarkan(); await tulisIndeks();
      } });
    } }, 'Hapus riwayat ini');
    sheet.append(h('h3', {}, 'Riwayat'), nm, h('div', { class: 'dlgb rev' }, batal, simpan), hapus);
    ov.append(sheet); document.body.append(ov);
  };
  const bukaLaci = () => {
    if (document.querySelector('.kc-drov')) return;
    const ov = h('div', { class: 'ov kc-drov' }), dr = h('aside', { class: 'kc-dr', 'aria-label': 'Riwayat percakapan' }), tutup = () => ov.remove();
    ov.addEventListener('click', (e) => { if (e.target === ov) tutup(); });
    const kol = h('div', { class: 'kc-list' });
    const segarkan = () => {
      kol.textContent = '';
      R.byRecent(idx).forEach((w) => kol.append(h('div', { class: 'kc-it' + (w.id === idx.active ? ' on' : '') },
        h('button', { type: 'button', class: 'kc-itn', onclick: async () => { if (await pindah(w.id)) tutup(); } }, w.name),
        h('button', { type: 'button', class: 'kc-itm', 'aria-label': 'Menu ' + w.name, onclick: () => menuRuang(w, segarkan) }, ico(PATH.more)))));
    };
    const semua = h('button', { type: 'button', class: 'kc-lnk red', onclick: () => {
      if (sibuk) { tWarn('Tunggu balasan selesai dulu.'); return; }
      dlg({ title: 'Hapus semua riwayat?', msg: 'Semua percakapan AI dihapus dari HP ini. Catatan dan data lain tidak berubah.', yes: 'Hapus semua', red: true, ok: async () => {
        memo.clear(); if (mode === 'file') { const r = await store.clearAll(); if (!r.ok) toast('Sebagian riwayat gagal dihapus: ' + r.msg); }
        idx = R.defaultIndex(Date.now()); riwayat = []; lepasLamp(); paintAll(); segarkan(); await tulisIndeks();
      } });
    } }, 'Hapus semua riwayat');
    // Rev 228: cadangkan / pulihkan riwayat AI (berkas JSON terpisah dari cadangan data aplikasi). Pemulihan hanya MENAMBAH riwayat baru.
    const cadangkan = async () => {
      const rooms = []; for (const w of idx.list) rooms.push({ ...w, msgs: w.id === idx.active ? riwayat : await bacaPesan(w.id) });
      if (!rooms.some((r) => r.msgs.length)) { tWarn('Belum ada percakapan untuk dicadangkan.'); return; }
      const text = buildBackup(rooms);
      dlg({ title: 'Cadangkan riwayat AI?', msg: 'Berkas memuat semua percakapan AI di HP ini dan tidak dienkripsi. Simpan di tempat aman. Alamat Worker dan passcode tidak ikut.', yes: 'Lanjut', ok: async () => {
        try { await saveBackupFile(backupName(), text); } catch (e) { if (!/cancel/i.test(String((e && e.message) || e))) toast('Gagal membuat cadangan: ' + String((e && e.message) || e).slice(0, 100)); }
      } });
    };
    const pulihkan = async () => {
      let text; try { text = await pickBackupText(); } catch (e) { toast(String((e && e.message) || 'Gagal membaca berkas.').slice(0, 100)); return; }
      if (text == null) return;
      const p = parseBackup(text); if (!p.ok) { toast(p.msg); return; }
      dlg({ title: 'Pulihkan riwayat AI?', msg: 'Berkas berisi ' + p.count + ' percakapan (' + p.msgCount + ' pesan). Semuanya ditambahkan sebagai riwayat baru; riwayat yang ada sekarang tidak dihapus atau diganti.' + (idx.list.length + p.count > R.MAX_WS ? ' Batas ' + R.MAX_WS + ' riwayat, jadi sebagian mungkin tidak muat.' : ''), yes: 'Pulihkan', ok: async () => {
        const m = mergeRestore(idx, p.rooms);
        for (const a of m.added) await tulisPesan(a.id, a.msgs);
        idx = m.idx; await tulisIndeks(); segarkan();
        toast(m.added.length + ' percakapan dipulihkan.' + (m.skipped ? ' ' + m.skipped + ' tidak muat (batas ' + R.MAX_WS + ' riwayat).' : ''));
      } });
    };
    dr.append(
      h('div', { class: 'kc-drh' }, h('span', { class: 'kc-drt' }, ico(PATH.star), 'KELIMAA AI'), h('button', { type: 'button', class: 'kc-ib sm', 'aria-label': 'Tutup', onclick: tutup }, ico(PATH.close))),
      h('div', { class: 'kc-lbl' }, 'Terkini'), kol,
      h('div', { class: 'kc-drf' }, h('small', {}, catatanSimpan()), h('div', { class: 'kc-lnks' }, h('button', { type: 'button', class: 'kc-lnk', onclick: cadangkan }, 'Cadangkan riwayat'), h('button', { type: 'button', class: 'kc-lnk', onclick: pulihkan }, 'Pulihkan riwayat')), semua,
        h('div', { class: 'kc-row2' },
          h('button', { type: 'button', class: 'kc-btn', onclick: async () => { if (await baru()) tutup(); } }, ico(I.baru), 'Obrolan baru'))));
    ov.append(dr); document.body.append(ov); segarkan();
  };
  const top = h('div', { class: 'kc-top' },
    h('button', { type: 'button', class: 'kc-ib', 'aria-label': 'Riwayat percakapan', onclick: bukaLaci }, ico(I.folder)),
    ttl,
    h('div', { class: 'kc-rt' }, h('button', { type: 'button', class: 'kc-ib', 'aria-label': 'Pengaturan AI', onclick: keAI }, ico(PATH.lainnya)), h('button', { type: 'button', class: 'kc-ib kc-home', 'aria-label': 'Ke aplikasi', onclick: keluar }, icoBeranda()))); // Rev 310a: Ke aplikasi jadi ikon rumah di bawah roda gigi
  const awal = () => { paintAll(); };
  if (idx) awal(); else { paintTop(); send.disabled = true; muat().then(() => { send.disabled = false; awal(); }, () => { send.disabled = false; mode = 'err'; note = 'gagal memuat'; if (!idx) idx = R.defaultIndex(Date.now()); awal(); }); }
  if (anyOn(livePerms(ctx.data, perms))) kc.classList.add('on');
  return [h('div', { class: 'kc' }, top, h('div', { class: 'kc-mid' }, body, turun), meta, bilahLamp.el, h('div', { class: 'kc-dock' }, kc, kw, ta, send))];
}
