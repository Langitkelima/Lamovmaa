// Rev 218 / Kelimaa AI Tahap 3b: dialog WRITING STUDIO di editor catatan BIASA (tidak pernah Catatan Privat; penjagaan ada di notes.js). Dimuat MALAS dari notes.js (import() dinamis).
// Hanya teks yang DIBLOK pengguna yang dikirim. Hasil ditampilkan lewat node teks (bukan HTML) dan baru dipakai setelah pengguna menekan Ganti / Sisipkan; Batal = tidak ada perubahan.
import { h, toast, infoKey, tWarn, tErr } from '../ui.js';
import { loadConn, loadCfg } from './sambungan.js';
import { WRITE_ACTIONS, CREATIVE_ACTIONS, cleanSelection, tulisDenganAI } from './tulis.js';

// onApply(teksHasil, 'ganti' | 'sisip') -> boolean (true bila berhasil diterapkan ke editor)
export function openTulis({ text, onApply }) {
  const sel = cleanSelection(text); if (!sel.ok) { toast(sel.msg); return false; }
  const conn = loadConn(), cfg = loadCfg();
  if (!conn || !cfg.on) { tWarn('Nyalakan Kelimaa AI dulu di tab AI (simpan sambungan, lalu sakelar MENYALA).'); return false; }
  let busy = false, result = '';
  const ov = h('div', { class: 'ov dlgov kai-tulis' });
  const close = () => ov.remove();
  const prev = h('div', { class: 'kai-tv' }, sel.text.length > 240 ? sel.text.slice(0, 240) + '\u2026' : sel.text);
  const status = h('small', { class: 'aimeta', role: 'status', 'aria-live': 'polite' }, 'Pilih apa yang mau dilakukan pada teks ini.');
  const out = h('div', { class: 'kai-tr', hidden: 'hidden' });
  const bReplace = h('button', { type: 'button', class: 'btn', disabled: 'disabled' }, 'Ganti teks terpilih');
  const bInsert = h('button', { type: 'button', class: 'btn line2', disabled: 'disabled' }, 'Sisipkan di bawahnya');
  const apply = (mode) => { if (!result) return; if (onApply(result, mode)) { close(); toast(mode === 'ganti' ? 'Teks diganti. Bisa Urungkan.' : 'Hasil disisipkan. Bisa Urungkan.'); } };
  bReplace.onclick = () => apply('ganti'); bInsert.onclick = () => apply('sisip');
  const mkChip = (a) => h('button', { type: 'button', class: 'kai-wc', 'data-act': a.id, onclick: async () => {
    if (busy) return; busy = true; result = ''; out.hidden = true; bReplace.disabled = bInsert.disabled = true;
    status.textContent = a.label + '\u2026 menunggu AI.';
    let r; try { r = await tulisDenganAI(conn, cfg, a.id, sel.text); } catch (_) { r = { ok: false, msg: 'Kesalahan tak terduga.' }; }
    busy = false; if (!ov.isConnected) return;
    if (!r.ok) { status.textContent = r.msg; return; }
    result = r.text; out.textContent = r.text; out.hidden = false; bInsert.disabled = false; bReplace.disabled = !!r.tambah;
    status.textContent = 'Hasil ' + a.label + (r.provider ? ' \u00b7 ' + r.provider : '') + '. Periksa dulu sebelum dipakai.' + (r.tambah ? ' Berupa usulan: hanya bisa disisipkan.' : '');
  } }, a.label);
  const chips = [...WRITE_ACTIONS, ...CREATIVE_ACTIONS].map(mkChip);
  chips.forEach((c) => c.addEventListener('click', () => chips.forEach((x) => x.classList.toggle('on', x === c))));
  ov.append(h('div', { class: 'sheet dlg' },
    h('h3', {}, 'Tulis dengan AI'), prev,
    h('small', { class: 'kai-wl' }, 'Tulis'), h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Aksi tulis' }, chips.slice(0, WRITE_ACTIONS.length)), h('small', { class: 'kai-wl' }, 'Kreatif'), h('div', { class: 'kai-wa', role: 'group', 'aria-label': 'Aksi kreatif' }, chips.slice(WRITE_ACTIONS.length)), status, out,
    h('div', { class: 'kai-apply' }, bReplace, bInsert),
    h('div', { class: 'dlgb' }, h('button', { type: 'button', class: 'btn line', onclick: close }, 'Batal'))));
  document.body.append(ov);
  return true;
}

// Dipanggil notes.js saat tombol "Tulis AI" diketuk. env: { r (Range seleksi saat ini atau null), ed, BLOCK_SEL, flushHist, auto, setRng }.
export function mulaiTulis(env) {
  const { r, ed, BLOCK_SEL, flushHist, auto, setRng } = env;
  const txt = r && !r.collapsed ? r.toString() : '';
  if (!txt.trim()) return import('./catatanui.js').then((m) => m.mulaiCatatanAI(env), () => { tErr('Olah catatan gagal dibuka.'); return false; }); // Rev 301b: tanpa blok = olah CATATAN UTUH (Ringkas, Usul judul, Rapikan)
  if (r.cloneContents().querySelector(BLOCK_SEL + ',table,img,.ksheet,.fold,.todo,input')) { infoKey('tulisBlok'); return false; }
  const saved = r.cloneRange();
  const terapkan = (text, mode) => {
    if (!ed.isConnected || !ed.contains(saved.startContainer) || !ed.contains(saved.endContainer)) { tWarn('Posisi teks berubah. Blok lagi lalu coba ulang.'); return false; }
    flushHist();
    const rr = saved.cloneRange(), frag = document.createDocumentFragment();
    if (mode === 'ganti') rr.deleteContents(); else { rr.collapse(false); frag.append(document.createElement('br')); }
    text.split('\n').forEach((ln, i) => { if (i) frag.append(document.createElement('br')); if (ln) frag.append(document.createTextNode(ln)); });
    const last = frag.lastChild; rr.insertNode(frag);
    if (last) { const c = document.createRange(); c.setStartAfter(last); c.collapse(true); const sl = getSelection(); sl.removeAllRanges(); sl.addRange(c); setRng(c.cloneRange()); }
    flushHist(); auto();
    return true;
  };
  return openTulis({ text: txt, onApply: terapkan });
}
