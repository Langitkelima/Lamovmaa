// Rev 201 / Kelimaa AI Tahap 1b: layar Setelan > Kelimaa AI (alamat Worker + passcode + Tes sambungan + sakelar). Dimuat MALAS oleh settings.js (import() dinamis).
// BELUM ada fitur AI yang bisa dipakai: layar ini hanya menyiapkan dan membuktikan sambungan ke Worker. Sakelar BAWAAN MATI.
import { h, ico, PATH, toast, dlg, tWarn, tOk } from '../ui.js';
import { isNative } from '../native.js';
import { viewChat } from './obrolan.js';
import { loadConn, saveConn, clearConn, loadCfg, saveCfg, clearCfg, cleanUrl, cleanPass, testConnection, cleanModel, PROVIDER_CHOICES, MODEL_PRESETS, LIMIT_CHOICES, MONTH_CHOICES } from './sambungan.js';

// Alamat Worker milik pengguna (BUKAN rahasia; tercatat di panduan pemasangan). Hanya mengisi kolom bila belum ada sambungan tersimpan; bisa diubah.
const ALAMAT_AWAL = 'https://kelimaa-ai.dhani5081.workers.dev';
const STEP = { input: 'Isian', ping: 'Langkah 1 · Alamat', whoami: 'Langkah 2 · Passcode', info: 'Info Worker' };

export { viewChat };

export function viewAI(ctx) {
  const { ui } = ctx; const native = isNative(); const saved = loadConn();
  const toMain = () => { ui.moreView = 'main'; ctx.render(); const m = document.querySelector('#app > main'); if (m) m.scrollTop = 0; };
  const url = h('input', { class: 'in', type: 'url', inputmode: 'url', autocomplete: 'off', autocapitalize: 'none', spellcheck: 'false', placeholder: 'https://nama-worker.nama-akun.workers.dev', value: saved ? saved.url : ALAMAT_AWAL, 'aria-label': 'Alamat Worker Kelimaa AI' });
  const key = h('input', { class: 'in', type: 'password', autocomplete: 'off', placeholder: 'Passcode RAMA atau DESY', value: saved ? saved.key : '', 'aria-label': 'Passcode Kelimaa AI' });
  const out = h('div', {});
  let busy = false, lastMe = saved ? saved.me : '';
  const show = (res) => {
    out.textContent = '';
    res.steps.forEach((x) => out.append(h('div', { class: 'row' }, h('div', { class: 'tx' }, h('b', {}, (x.note ? 'Catatan' : x.ok ? 'Berhasil' : 'Gagal') + ' · ' + (STEP[x.id] || x.id)), h('small', {}, x.msg)))));
  };

  // Sakelar utama (Rev 211: sakelar besar MATI | MENYALA, gaya Stiker Tebal): diperbarui di tempat (tanpa ctx.render()), supaya kolom ketik tidak hilang.
  const swBtn = h('button', { type: 'button', class: 'kai-sw', role: 'switch', 'aria-label': 'Kelimaa AI menyala', onclick: () => {
    const on = !loadCfg().on;
    if (on && !loadConn()) { tWarn('Simpan sambungan dulu, baru nyalakan.'); return; }
    const r = saveCfg({ ...loadCfg(), on }); if (!r.ok) { toast(r.msg); return; }
    paint(); toast(on ? 'Kelimaa AI dinyalakan. Chat ada di tombol Buka chat.' : 'Kelimaa AI dimatikan.');
  } }, h('span', {}, 'MATI'), h('span', {}, 'MENYALA'));
  const paint = () => { swBtn.setAttribute('aria-checked', String(loadCfg().on)); };
  paint();

  // Rev 209: pilihan JALUR + MODEL (daftar ATAU ketik manual) + BATAS harian. Tersimpan langsung saat dipilih; diperbarui di tempat (tanpa ctx.render()).
  const keep = (patch) => { const r = saveCfg({ ...loadCfg(), ...patch }); if (!r.ok) toast(r.msg); return r.ok; };
  const MANUAL = '__manual__';
  // Rev 211: jalur = 4 tombol besar (urutan Sakelar, Relay, Gemini, Otomatis); perilaku sama dengan pilihan lama.
  const provBtns = ['sakelar', 'relay', 'gemini', ''].map((v) => h('button', { type: 'button', 'data-prov': v, onclick: () => {
    if (!keep({ provider: v, model: '' })) return; paintProv(); fillModels(v, ''); tOk('Jalur diganti. Model kembali ke bawaan Worker.');
  } }, (PROVIDER_CHOICES.find((x) => x[0] === v) || [v, v])[1]));
  const paintProv = () => { const cur = loadCfg().provider; provBtns.forEach((b) => { const on = b.getAttribute('data-prov') === cur; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); }); };
  const modSel = h('select', { class: 'in aisel', 'aria-label': 'Model AI' });
  const modMan = h('input', { class: 'in', type: 'text', autocomplete: 'off', autocapitalize: 'none', spellcheck: 'false', placeholder: 'mis. gemini-3.5-flash', 'aria-label': 'Nama model (ketik manual)' });
  const modNote = h('small', { class: 'aimeta' }, '');
  const fillModels = (provider, model) => {
    const presets = MODEL_PRESETS[provider] || [];
    modSel.textContent = '';
    modSel.append(h('option', { value: '' }, 'Bawaan Worker'));
    presets.forEach((m) => modSel.append(h('option', { value: m }, m)));
    modSel.append(h('option', { value: MANUAL }, 'Ketik manual\u2026'));
    const manual = !!model && !presets.includes(model);
    modSel.value = manual ? MANUAL : (model || '');
    modMan.value = manual ? model : '';
    modMan.style.display = manual ? '' : 'none';
    modNote.textContent = provider ? '' : 'Jalur Otomatis memakai jalur pertama yang punya kunci di Worker; model yang kamu pilih harus cocok dengan jalur itu.';
  };
  { const c = loadCfg(); fillModels(c.provider, c.model); paintProv(); }
  modSel.onchange = () => {
    if (modSel.value === MANUAL) { modMan.style.display = ''; modMan.focus(); return; }
    modMan.style.display = 'none'; modMan.value = ''; keep({ model: modSel.value }); toast(modSel.value ? 'Model: ' + modSel.value : 'Model: bawaan Worker.');
  };
  modMan.onchange = () => {
    const m = cleanModel(modMan.value); if (!m.ok) { toast(m.msg); return; }
    if (!m.value) { tWarn('Isi nama model, atau pilih \u201cBawaan Worker\u201d.'); return; }
    if (keep({ model: m.value })) toast('Model: ' + m.value);
  };
  const limBtns = LIMIT_CHOICES.map(([n, label]) => h('button', { type: 'button', 'data-lim': String(n), onclick: () => { if (keep({ limit: n })) { paintLim(); toast(n === 0 ? 'Batas harian dimatikan (tanpa batas).' : 'Batas harian: ' + n + ' per hari.'); } } }, label));
  const paintLim = () => { const cur = loadCfg().limit; limBtns.forEach((b) => { const on = Number(b.getAttribute('data-lim')) === cur; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); }); };
  paintLim();
  // Rev 241 / Tahap 9b: batas bulanan opsional (bawaan mati; butuh Worker Rev 240 atau lebih baru).
  const monBtns = MONTH_CHOICES.map(([n, label]) => h('button', { type: 'button', 'data-mon': String(n), onclick: () => { if (keep({ monthLimit: n })) { paintMon(); toast(n === 0 ? 'Batas bulanan dimatikan.' : 'Batas bulanan: ' + n + ' per bulan.'); } } }, label));
  const paintMon = () => { const cur = loadCfg().monthLimit || 0; monBtns.forEach((b) => { const on = Number(b.getAttribute('data-mon')) === cur; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); }); };
  paintMon();

  const testBtn = h('button', { type: 'button', class: 'btn', onclick: async () => {
    if (busy) return;
    busy = true; testBtn.disabled = true; testBtn.textContent = 'Menguji…'; out.textContent = '';
    try {
      const res = await testConnection({ url: url.value, key: key.value });
      lastMe = res.ok ? res.me : ''; show(res);
    } catch (e) { show({ steps: [{ id: 'input', ok: false, msg: 'Kesalahan tak terduga: ' + String((e && e.message) || e).slice(0, 100) }] }); }
    busy = false; testBtn.disabled = false; testBtn.textContent = 'Tes sambungan';
  } }, 'Tes sambungan');
  const saveBtn = h('button', { type: 'button', class: 'btn line', onclick: () => {
    const u = cleanUrl(url.value), k = cleanPass(key.value);
    if (!u.ok) { toast(u.msg); return; } if (!k.ok) { toast(k.msg); return; }
    const r = saveConn({ url: u.value, key: k.value, me: lastMe, testedAt: lastMe ? Date.now() : 0 });
    toast(r.ok ? 'Sambungan disimpan di HP ini.' : r.msg);
    if (r.ok) ctx.render();
  } }, 'Simpan sambungan');
  const dropBtn = saved ? h('button', { type: 'button', class: 'btn line', onclick: () => dlg({ title: 'Putuskan Kelimaa AI?', msg: 'Alamat dan passcode dihapus dari HP ini dan sakelar dimatikan. Isi aplikasi ini tidak berubah, dan Worker di Cloudflare tidak disentuh.', yes: 'Putuskan',
    ok: () => { clearConn(); clearCfg(); tOk('Sambungan Kelimaa AI dihapus.'); toMain(); } }) }, 'Putuskan sambungan') : null;

  const stk = (t) => h('span', { class: 'kai-stk' }, t);
  const logo = h('h1', { class: 'kai-logo' }, ico(PATH.star), h('span', {}, 'KELIMAA ', h('b', {}, 'AI')));
  return [h('div', { class: 'kai' },
    logo,
    h('p', { class: 'sub' }, 'Opsional dan bawaannya mati. Layar ini menyambungkan aplikasi ke Worker Kelimaa AI dan memeriksa passcode. Fitur yang ada baru chat umum (jalur, model, dan batas harian bisa kamu pilih di bawah); isi catatan, tugas, dan Catatan Privat tidak pernah dikirim.'),
    h('p', { class: 'sub' }, 'Alamat dan passcode disimpan di HP ini saja dan tidak ikut berkas cadangan. Setelah memulihkan cadangan, isi lagi.'),
    native ? null : h('div', { class: 'notice' }, 'Di peramban, tes ini bisa gagal karena aturan keamanan peramban. Hasil yang benar hanya di aplikasi HP.'),
    stk('KELIMAA AI'), swBtn,
    stk('JALUR'), h('div', { class: 'kai-og', role: 'group', 'aria-label': 'Jalur penyedia AI' }, provBtns),
    stk('MODEL'), h('div', { class: 'kai-card' }, modSel, modMan, modNote),
    stk('BATAS'), h('div', { class: 'kai-segs', role: 'group', 'aria-label': 'Batas permintaan AI per hari' }, limBtns),
    h('small', { class: 'aimeta' }, 'Per orang per hari (hari menurut WIB), dihitung di Worker. Tanpa batas = tidak pernah diblokir.'),
    stk('BATAS BULANAN'), h('div', { class: 'kai-segs', role: 'group', 'aria-label': 'Batas permintaan AI per bulan' }, monBtns),
    h('small', { class: 'aimeta' }, 'Opsional, bawaan mati. Per orang per bulan (menurut WIB), dihitung di Worker; butuh Worker terbaru dan KV. Memakai 1 penulisan KV tambahan per permintaan.'),
    stk('SAMBUNGAN'),
    h('div', { class: 'kai-card' },
      h('div', { class: 'kai-st' }, h('i', { class: saved ? 'kai-dot' : 'kai-dot off' }), saved ? (saved.me ? saved.me.toUpperCase() + ' \u00b7 tersimpan' : 'tersimpan di HP ini') : 'belum ada sambungan tersimpan'),
      h('label', { class: 'kai-fl' }, 'Alamat Worker'), url, h('label', { class: 'kai-fl' }, 'Passcode'), key, testBtn, out),
    saveBtn, dropBtn,
    saved ? h('button', { type: 'button', class: 'btn', onclick: () => { if (!loadCfg().on) { tWarn('Nyalakan Kelimaa AI dulu.'); return; } ui.aiFrom = ''; ui.moreView = 'aichat'; ctx.render(); } }, ui.tab === 'ai' && ui.aiFrom === 'chat' ? 'Kembali ke chat' : 'Buka chat') : null, // Rev 310a: Buka chat dan Kembali ke chat disatukan (fungsinya sama)
    ui.tab === 'ai' ? null : h('button', { type: 'button', class: 'btn line', onclick: toMain }, 'Kembali'), // Rev 215/223: di tab AI jalan keluarnya = bilah bawah atau tombol chat di atas
  )];
}
