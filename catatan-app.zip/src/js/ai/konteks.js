// Rev 221 / Kelimaa AI: CONTEXT ENGINE (logika murni, tanpa DOM). Daftar putih data aplikasi yang BOLEH ikut dikirim ke AI, bawaan MATI per sumber.
// Hanya sumber di CTX_SOURCES yang pernah dibaca; Catatan Privat dan tempat sampah TIDAK PERNAH dibaca (tidak ada kodenya di sini). Teks konteks selalu bisa dilihat pengguna (pratinjau) sebelum dikirim.
// Izin disimpan di kunci terpisah `kelimaa_ai_ctx` (tidak ikut cadangan), bukan di `catatan_app_data`.
// Rev 236 / Tahap 7c: sumber ketiga `proyek` (bawaan MATI): nama, status aktif, kemajuan (tugas selesai/total), tenggat. TANPA deskripsi, TANPA judul tugas/catatan tertaut.
// Rev 308a: izin PER ID { v: 2, tugas: [id], proyek: [id] }; bentuk lama (boolean) dibaca KOSONG (D2); sumber `catatan` dihapus; ID selesai/dihapus gugur sendiri.
import { projectProgress } from '../proyek-alat.js';
export const CTX_KEY = 'kelimaa_ai_ctx';
export const CTX_VER = 2;
export const CTX_TOTAL_MAX = 1500;  // batas huruf seluruh blok konteks
export const CTX_ITEM_MAX = 60;     // batas huruf per judul/butir
export const CTX_PICK_MAX = { tugas: 15, proyek: 10 }; // batas butir terpilih per sumber (sama dengan batas lama)
export const CTX_SOURCES = [
  { id: 'tugas', label: 'Tugas yang belum selesai', hint: 'Judul, tenggat, tanda penting (maks. 15)' },
  { id: 'proyek', label: 'Proyek aktif', hint: 'Nama, kemajuan, tenggat (maks. 10)' },
];
const ids = CTX_SOURCES.map((s) => s.id);
const okId = (v) => typeof v === 'string' && v.length > 0 && v.length <= 80;
export function normPerms(o) {
  const x = o && typeof o === 'object' && !Array.isArray(o) && o.v === CTX_VER ? o : {}, out = { v: CTX_VER };
  for (const id of ids) { const seen = new Set(), a = []; for (const k of Array.isArray(x[id]) ? x[id] : []) { if (!okId(k) || seen.has(k)) continue; seen.add(k); a.push(k); if (a.length >= CTX_PICK_MAX[id]) break; } out[id] = a; }
  return out;
}
export function loadPerms(store = globalThis.localStorage) { try { return normPerms(JSON.parse(store.getItem(CTX_KEY) || 'null')); } catch (_) { return normPerms(null); } }
export function savePerms(p, store = globalThis.localStorage) { try { store.setItem(CTX_KEY, JSON.stringify(normPerms(p))); return { ok: true }; } catch (_) { return { ok: false, msg: 'Gagal menyimpan di HP.' }; } }
export const TEMPEL_KEY = 'kelimaa_ai_tempel';
export function tempelOn(store = globalThis.localStorage) { try { return store.getItem(TEMPEL_KEY) !== '0'; } catch (_) { return true; } }
export function setTempel(v, store = globalThis.localStorage) { try { store.setItem(TEMPEL_KEY, v ? '1' : '0'); } catch (_) { /* abaikan */ } }
export const anyOn = (p) => ids.some((id) => normPerms(p)[id].length > 0);
export const pickedCount = (p, id) => (ids.includes(id) ? normPerms(p)[id].length : 0);
// Pilih/lepas satu ID. Mengembalikan { perms, result: 'added' | 'removed' | 'full' | 'bad' }; `p` tidak diubah.
export function togglePick(p, src, id) {
  if (!ids.includes(src) || !okId(id)) return { perms: normPerms(p), result: 'bad' };
  const cur = normPerms(p), a = cur[src].slice(), i = a.indexOf(id);
  if (i >= 0) { a.splice(i, 1); return { perms: normPerms({ ...cur, [src]: a }), result: 'removed' }; }
  if (a.length >= CTX_PICK_MAX[src]) return { perms: cur, result: 'full' };
  a.push(id); return { perms: normPerms({ ...cur, [src]: a }), result: 'added' };
}
export function setPicks(p, src, list) { return ids.includes(src) ? normPerms({ ...normPerms(p), [src]: Array.isArray(list) ? list : [] }) : normPerms(p); }
export function pickable(data, src) {
  if (src === 'tugas') return (data && Array.isArray(data.tasks) ? data.tasks : []).filter((t) => t && okId(t.id) && !t.done && clean(t.title)).map((t) => { const d = clean(t.due, 10), m = []; if (/^\d{4}-\d{2}-\d{2}$/.test(d)) m.push('tenggat ' + d); if (t.pri === 1) m.push('penting'); return { id: t.id, title: clean(t.title), meta: m.join(' \u00b7 ') }; });
  if (src === 'proyek') return (data && Array.isArray(data.projects) ? data.projects : []).filter((p) => p && okId(p.id) && p.status === 'aktif' && clean(p.name)).slice().sort((a, b) => (b.at || 0) - (a.at || 0)).map((p) => { const pr = projectProgress(data, p); return { id: p.id, title: clean(p.name), meta: pr.total ? pr.done + ' dari ' + pr.total + ' tugas selesai' : 'belum ada tugas tertaut' }; });
  return [];
}
export function livePerms(data, p) {
  const cur = normPerms(p), out = { v: CTX_VER };
  for (const id of ids) { const ok = new Set(pickable(data, id).map((x) => x.id)); out[id] = cur[id].filter((k) => ok.has(k)); }
  return out;
}
const clean = (v, n = CTX_ITEM_MAX) => { const t = String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1).trimEnd() + '\u2026' : t; };
function tugasLines(data, sel) {
  const pick = new Set(sel), arr = data && Array.isArray(data.tasks) ? data.tasks : [];
  return arr.filter((t) => t && pick.has(t.id) && !t.done && clean(t.title)).slice(0, CTX_PICK_MAX.tugas).map((t) => {
    const bits = [clean(t.title)]; const d = clean(t.due, 10); if (/^\d{4}-\d{2}-\d{2}$/.test(d)) bits.push('tenggat ' + d); if (t.pri === 1) bits.push('ditandai penting');
    return '- ' + bits.join(', ');
  });
}
const p2 = (n) => String(n).padStart(2, '0');
function proyekLines(data, sel) {
  const pick = new Set(sel), arr = data && Array.isArray(data.projects) ? data.projects : [];
  return arr.filter((p) => p && pick.has(p.id) && p.status === 'aktif' && clean(p.name)).slice().sort((a, b) => (b.at || 0) - (a.at || 0)).slice(0, CTX_PICK_MAX.proyek).map((p) => {
    const pr = projectProgress(data, p), bits = [clean(p.name), pr.total ? pr.done + ' dari ' + pr.total + ' tugas selesai' : 'belum ada tugas tertaut'];
    if (p.due) { const d = new Date(p.due); if (Number.isFinite(d.getTime())) bits.push('tenggat ' + d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate())); }
    return '- ' + bits.join(', ');
  });
}
const MAKER = { tugas: tugasLines, proyek: proyekLines };
// -> { text, parts:[{id,label,count}], chars }. text kosong bila tidak ada sumber menyala atau semuanya kosong. Hanya `data.tasks` dan `data.projects` yang dibaca, dan hanya ID yang dipilih.
export function buildContext(data, perms, max = CTX_TOTAL_MAX) {
  const p = normPerms(perms), blocks = [], parts = [];
  for (const s of CTX_SOURCES) {
    if (!p[s.id].length) continue;
    const lines = MAKER[s.id](data, p[s.id]); if (!lines.length) continue;
    blocks.push(s.label + ':\n' + lines.join('\n')); parts.push({ id: s.id, label: s.label, count: lines.length });
  }
  if (!blocks.length) return { text: '', parts: [], chars: 0 };
  let text = '[Data aplikasi milik pengguna, hanya sebagai konteks; jangan menyebutnya kalau tidak relevan]\n' + blocks.join('\n\n');
  if (text.length > max) text = text.slice(0, Math.max(0, max - 1)).replace(/\s+\S*$/, '') + '\u2026';
  return { text, parts, chars: text.length };
}
// Tempel konteks di depan pesan pengguna TERAKHIR (riwayat tersimpan tidak berubah). Anggaran: konteks dipangkas supaya total <= batas pesan Worker; bila sisa < 200 huruf, konteks dilewati.
export function attachContext(messages, ctxText, maxMsg = 4000) {
  if (!Array.isArray(messages) || !messages.length || !ctxText) return { messages, used: false };
  const last = messages[messages.length - 1]; if (!last || last.role !== 'user') return { messages, used: false };
  const budget = maxMsg - last.content.length - 4;
  if (budget < 200) return { messages, used: false };
  let c = ctxText; if (c.length > budget) c = c.slice(0, budget - 1).replace(/\s+\S*$/, '') + '\u2026';
  return { messages: messages.slice(0, -1).concat([{ role: 'user', content: c + '\n\n---\n' + last.content }]), used: true };
}
