// Satu-satunya tempat akses penyimpanan. Mudah diganti (mis. ke penyimpanan lebih tahan lama).
import { withMode, DEFAULT_DAYS, emptyBackup, normalizeBackup, normalizeTrashDays, normalizeImageQuality, pruneLinks, cleanSubs, canHaveSubs, cleanHabitLog, cleanDoneAt } from './logic.js';
import { cleanNoteRem } from './ingatkan.js';
import { cleanSnooze } from './logic.js'; // Rev 389 / TN2 (baris terpisah: tes lama mengunci baris impor logic.js)
import { cleanSheets } from './lembar.js';
import { stripSheetIslands } from './lembar-siklus.js';
import { cleanProjects, pruneProjectLinks } from './proyek.js';

export const KEY = 'catatan_app_data';
export const SCHEMA = 22; // naikkan jika bentuk data berubah, lalu tambahkan migrasi
// v22 (Rev 300a): tab lembar kerja boleh punya `fz` = { r, c } (baris/kolom beku, maks. 5/3). Data v21 tetap valid.
// v21 (Rev 278, W3): tab lembar kerja boleh punya `errlog` (riwayat error validasi data, maks. 200 entri per tab; model murni di lembar-validasi.js, dibersihkan di cleanTab; TIDAK dihitung ke batas ukuran lembar kerja). Data v20 tetap valid tanpa migrasi (tab tanpa errlog).
// v20 (Rev 238, Tahap 8b-1): tugas selesai punya `doneAt` (ms; tugas lama tanpa doneAt tetap valid) dan data.habitLog = [{ d: 'YYYY-MM-DD', done, total }] (hasil kebiasaan per hari, maks. 60 hari, dicatat saat reset harian; fungsi murni di logic.js). Data v19 dimigrasi ke habitLog [].
// v19 (Rev 234, Tahap 7a): data.projects = [{ id, name, desc, status, at, due?, tasks: [id], notes: [id] }] (Project Studio; model murni di proyek.js; maks. 30 proyek, 100 tautan tugas dan 100 tautan catatan per proyek; tautan ke tugas/catatan yang tidak ada dibuang di normalize(); Catatan Privat tidak pernah ditautkan). Data v18 tanpa projects dimigrasi ke []. BELUM ada UI dan BELUM terhubung ke AI.
// v15 (Rev 147, U9b-3a): tab lembar kerja boleh punya `checks` (validasi data pilihan per kolom, maks. 10 per tab, satu per kolom; model dan mesin murni di lembar-validasi.js; dibersihkan di cleanTab). Data v14 tetap valid tanpa migrasi.
// v14 (Rev 145, U9b-2a): tab lembar kerja boleh punya `rules` (aturan warna bersyarat per kolom, maks. 10; model dan mesin murni di lembar-aturan.js; dibersihkan di cleanTab). Data v13 tetap valid (tanpa rules); tidak perlu migrasi. BELUM ada UI.
// v12 (Rev 127, U8a-2): sel lembar kerja boleh punya `fx` (rumus bentuk simpan, tanpa hasil). Data v11 tetap valid (tanpa fx); tidak perlu migrasi.
// v11 (Rev 114, U7a-1): data.sheets = { [id]: lembar kerja } (model di lembar.js; maks. 50 lembar, 5 tab, 26 kolom x 500 baris, ~500 KB per lembar; yang rusak/melewati batas dibuang utuh). Data lama tanpa sheets tetap valid ({}). BELUM ada UI.
// v10 (Rev 102, U5b): catatan biasa boleh punya `cbRem` ({[cid]: {at, repeat, sticky:false}}, pengingat baris kotak centang, maks. 30) dan `cdRem` ({[bid]: [hari sebelum...]}, pengingat hitung mundur, maks. 10 kartu x 4). Hanya cid/bid yang masih ada di HTML catatan yang dipertahankan; Catatan Privat tidak pernah punya. Data lama tanpa field ini tetap valid.
// v9 (Rev 67): tugas.subs = [{id, title, done}] (sub-tugas, maks. 20, hanya Fokus/Target/Rencana). Data lama tanpa subs tetap valid; normalize() membersihkan subs rusak.
// v8 (Rev 60, G4): settings.imageQuality ('hemat' | 'seimbang' | 'tajam'; bawaan 'seimbang'), berlaku untuk gambar BARU. Data lama dimigrasi di normalize().
// v7 (Rev 24A): settings.notesView ('list' = baris, bawaan; 'grid' = petak). Data lama dimigrasi di normalize() (bawaan baris, sama dengan tampilan sebelumnya).
// v6 (Rev 21): pengingat opsional pada tugas dan catatan biasa (reminder: {at, repeat}).
// v5 (Rev 19): settings.trashDays (tempat sampah otomatis kosong; 0 = mati). Data lama dimigrasi di normalize() (nilai bawaan, mati).
// v4 (Rev 18): catatan.links (hubungan antarcatatan, hanya catatan biasa). Data lama tanpa links tetap valid; normalize() membersihkan hubungan rusak.
// v3 (Rev 17): settings.backup (cadangan otomatis). Data lama dimigrasi di normalize() (nilai bawaan, mati).
// v2: label catatan (settings.labels, catatan.labels), pratinjau tautan (catatan.prev). Data v1 dimigrasi di normalize() (nilai bawaan).

export function emptyData() {
  return {
    version: SCHEMA,
    habits: [], tasks: [], notes: [], priv: [], trash: [], sheets: {}, projects: [], habitLog: [],
    settings: { days: [...DEFAULT_DAYS], theme: 'auto', lastReset: '', recent: [], labels: [], pinSalt: '', pinHash: '', pinFails: 0, pinLockUntil: 0, backup: emptyBackup(), trashDays: 0, notesView: 'list', imageQuality: 'seimbang', selColor: '', snoozeMin: 10 },
  };
}
export function normalize(d) {
  if (!d || typeof d !== 'object') return null;
  const e = emptyData();
  for (const k of ['habits', 'tasks', 'notes', 'priv', 'trash']) {
    if (d[k] !== undefined && !Array.isArray(d[k])) return null;
    e[k] = d[k] || [];
  }
  e.settings = { ...e.settings, ...(d.settings && typeof d.settings === 'object' ? d.settings : {}) };
  if (!Array.isArray(e.settings.days)) e.settings.days = [...DEFAULT_DAYS];
  if (!Array.isArray(e.settings.recent)) e.settings.recent = [];
  // Label: buang entri rusak dan nama ganda (dari cadangan yang diedit tangan).
  const seen = new Set();
  e.settings.labels = (Array.isArray(e.settings.labels) ? e.settings.labels : []).filter((l) => {
    const ok = l && typeof l.id === 'string' && l.id && typeof l.name === 'string' && l.name.trim() && !seen.has(l.id);
    if (ok) seen.add(l.id);
    return ok;
  }).map((l) => ({ id: l.id, name: l.name.trim().slice(0, 20) }));
  e.settings.backup = normalizeBackup(e.settings.backup);
  e.settings.trashDays = normalizeTrashDays(e.settings.trashDays);
  e.settings.notesView = e.settings.notesView === 'grid' ? 'grid' : 'list';
  e.settings.imageQuality = normalizeImageQuality(e.settings.imageQuality);
  e.settings.selColor = /^#[0-9a-f]{6}$/i.test(e.settings.selColor || '') ? e.settings.selColor.toLowerCase() : '';
  e.settings.snoozeMin = cleanSnooze(e.settings.snoozeMin); // Rev 389 / TN2: lama Tunda alarm (5/10/15/30, bawaan 10); data lama tanpa kunci ini menjadi 10, SCHEMA tidak naik (seperti selColor)
  // Pengingat: hanya timestamp positif dan pengulangan sekali/harian yang diterima.
  const cleanReminder = (x) => {
    if (!x || typeof x !== 'object') return null;
    const at = Number(x.at);
    if (!Number.isFinite(at) || at <= 0) return null;
    return withMode({ at, repeat: x.repeat === 'daily' ? 'daily' : 'once' }, x.mode); // Rev 378 / AL2: `mode` hanya ada bila 'alarm'
  };
  for (const x of [...e.tasks, ...e.notes]) { if (x && typeof x === 'object') { const r = cleanReminder(x.reminder); if (r) x.reminder = r; else delete x.reminder; } }
  // Sub-tugas: hanya tugas Fokus/Target/Rencana; larik bersih atau dibuang. Tugas di Tempat sampah ikut dibersihkan.
  const trashTasks = e.trash.filter((x) => x && typeof x === 'object' && x.kind === 'task' && x.item && typeof x.item === 'object').map((x) => x.item);
  for (const t of [...e.tasks, ...trashTasks]) {
    if (!t || typeof t !== 'object') continue;
    const c = canHaveSubs(t.scope) ? cleanSubs(t.subs) : [];
    if (c.length) t.subs = c; else delete t.subs;
    // Rev 68: remMode 'subs' hanya sah bila ada sub-tugas; alarm tugas dan alarm sub-tugas tidak dipakai bersamaan.
    if (t.remMode === 'subs' && c.length) delete t.reminder;
    else { delete t.remMode; if (t.subs) for (const sb of t.subs) delete sb.reminder; }
  }
  // Rev 102 / U5b: pengingat kotak centang (cbRem) dan hitung mundur (cdRem) hanya di catatan biasa (juga yang di Tempat sampah, agar Pulihkan menjadwalkan ulang); dipangkas ke cid/bid yang masih ada di HTML.
  const trashNotes = e.trash.filter((x) => x && typeof x === 'object' && x.kind === 'note' && x.item && typeof x.item === 'object').map((x) => x.item);
  for (const n of [...e.notes, ...trashNotes]) {
    if (!n || typeof n !== 'object') continue;
    const c = cleanNoteRem(n);
    if (Object.keys(c.cbRem).length) n.cbRem = c.cbRem; else delete n.cbRem;
    if (Object.keys(c.cdRem).length) n.cdRem = c.cdRem; else delete n.cdRem;
    if (c.cdMode) n.cdMode = c.cdMode; else delete n.cdMode; // Rev 378 / AL2: mode alarm per kartu hitung mundur
  }
  for (const n of e.priv) if (n && typeof n === 'object') { delete n.cbRem; delete n.cdRem; delete n.cdMode; if (typeof n.html === 'string' && n.html.includes('ksheet')) n.html = stripSheetIslands(n.html); } // Rev 125 / U7b-4: Catatan Privat tanpa pulau lembar kerja (cadangan lama/tempel)
  e.sheets = cleanSheets(d.sheets);
  pruneLinks(e);
  e.projects = cleanProjects(d.projects); pruneProjectLinks(e); // Rev 234 / Tahap 7a
  e.habitLog = cleanHabitLog(d.habitLog); cleanDoneAt([...e.tasks, ...trashTasks]); // Rev 238 / Tahap 8b-1
  return e;
}
// Rev 295 / 4-1: penanda gagal-muat (pembersih gambar berhenti).
let loadFailed = false;
export function wasLoadFailure() { return loadFailed; }
export function load(store = globalThis.localStorage) {
  let raw = null;
  loadFailed = false;
  try {
    raw = store.getItem(KEY);
    if (!raw) return emptyData();
    const d = normalize(JSON.parse(raw));
    if (d) return d;
    throw new Error('bentuk data tidak dikenal');
  } catch (err) {
    loadFailed = true;
    console.error('load gagal:', err && err.name); // Rev 295 / 7-1: tanpa pesan (bisa memuat isi catatan)
    try { if (raw && store.getItem(KEY + '_rusak') === null) store.setItem(KEY + '_rusak', raw); } catch (_) { /* abaikan */ }
    return emptyData();
  }
}
export function save(data, store = globalThis.localStorage) {
  try {
    store.setItem(KEY, JSON.stringify({ ...data, version: SCHEMA }));
    return { ok: true };
  } catch (err) {
    console.error('simpan gagal:', err);
    return { ok: false, msg: 'Gagal menyimpan. Penyimpanan mungkin penuh.' };
  }
}
export function exportJSON(data) {
  return JSON.stringify({ ...data, version: SCHEMA }, null, 2);
}
export function importJSON(text) {
  try {
    const d = normalize(JSON.parse(text));
    return d ? { ok: true, data: d } : { ok: false, msg: 'Isi berkas cadangan tidak dikenali.' };
  } catch (_) {
    return { ok: false, msg: 'Berkas cadangan rusak atau bukan JSON.' };
  }
}
