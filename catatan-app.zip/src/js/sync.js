// Rev 419 / PART SY2 (Paket SY): MESIN SINKRON catatan di aplikasi. MURNI: tanpa DOM, tanpa fetch, tanpa passcode, tanpa penyimpanan sendiri.
// Dimuat MALAS (import dinamis oleh SY3) dan BELUM dipanggil siapa pun di aplikasi: tidak ada UI, tidak ada perubahan perilaku.
// Pasangan Worker: aksi `sync` di berkas worker.mjs (Rev 418 / SY1). Kontrak ada di komentar blok itu.
//
// Cara kerja (ringkas):
// - Keadaan sinkron disimpan TERPISAH dari data catatan (kunci SYNC_STATE_KEY, bentuk { v, since, map }), jadi SCHEMA data TIDAK naik (tetap 22) dan
//   cadangan/pulihkan/ekspor tidak berubah. map[id] = { bv, sig } = versi server terakhir yang dilihat perangkat + tanda isi saat itu.
// - "Belum terkirim" dideteksi dengan membandingkan tanda isi sekarang (noteSig) dengan map[id].sig: tidak perlu menandai catatan saat diedit.
// - Catatan dihapus/dipindah ke Privat = id ada di map tetapi tidak ada lagi di data.notes -> dikirim sebagai tanda hapus.
// - CATATAN PRIVAT TIDAK PERNAH DIBACA: mesin hanya menyentuh data.notes. Id yang juga ada di data.priv dikecualikan (di satu tempat: eligible()).
// - Yang dikirim: title, html, col, pin, labels (NAMA, bukan id), updated. TIDAK ikut: text (dihitung ulang), links, cbRem, cdRem, cdMode, reminder, prev, gambar.
// - Catatan dari server selalu lewat deps.sanitize (WAJIB disuntikkan, sama seperti impor Markdown). Dihapus dari server -> masuk Tempat sampah (bisa dipulihkan).
// - Pengaman: penghapusan massal (>= 10 dan > separuh catatan terlacak) DITAHAN sampai pengguna mengizinkan (opts.allowMassDelete).
// - Hasil sinkron dikembalikan sebagai ringkasan; pemanggil (SY3) yang menyimpan data + keadaan, menyegarkan tampilan, dan menjadwal ulang pengingat.
import { parseNoteHtml, blocksToText } from './export.js';
import { LABEL_MAX, LABEL_NAME_MAX, newId as defaultNewId } from './logic.js';

export const SYNC_STATE_KEY = 'catatan_app_sync';
// Cermin batas Worker (SY1). Bila Worker berubah, ubah di sini juga.
export const SYNC_LIM = { idRe: /^[a-z0-9][a-z0-9_-]{3,62}$/i, push: 50, html: 200000, title: 300, labels: 20, labelLen: 40, bodyChars: 450000, rounds: 12, massDelete: 10 };

export function emptySyncState() { return { v: 1, since: 0, map: {} }; }
export function cleanSyncState(raw) {
  const s = emptySyncState();
  if (!raw || typeof raw !== 'object') return s;
  if (Number.isInteger(raw.since) && raw.since > 0) s.since = raw.since;
  if (raw.map && typeof raw.map === 'object') {
    for (const id of Object.keys(raw.map)) {
      const e = raw.map[id];
      if (!e || typeof e !== 'object' || !Number.isInteger(e.bv) || e.bv < 0) continue;
      s.map[id] = e.del ? { bv: e.bv, del: 1 } : { bv: e.bv, sig: typeof e.sig === 'string' ? e.sig : '' };
    }
  }
  return s;
}
export function loadSyncState(store = globalThis.localStorage) {
  try { const raw = store.getItem(SYNC_STATE_KEY); return cleanSyncState(raw ? JSON.parse(raw) : null); } catch (_) { return emptySyncState(); }
}
export function saveSyncState(state, store = globalThis.localStorage) {
  try { store.setItem(SYNC_STATE_KEY, JSON.stringify(state)); return true; } catch (_) { return false; }
}
export function clearSyncState(store = globalThis.localStorage) { try { store.removeItem(SYNC_STATE_KEY); } catch (_) { /* abaikan */ } }

// Hash 53-bit (cyrb53): tanda isi pendek supaya keadaan sinkron kecil walau catatannya besar.
function h53(str) {
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < str.length; i++) { const ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
const labelMap = (data) => new Map(((data.settings && data.settings.labels) || []).map((l) => [l.id, l.name]));
// Nama label catatan (urut seperti di catatan, tanpa ganda, id yang labelnya sudah hilang diabaikan).
function labelNames(n, byId) {
  const out = [];
  for (const id of Array.isArray(n.labels) ? n.labels : []) { const nm = byId.get(id); const t = typeof nm === 'string' ? nm.trim() : ''; if (t && !out.includes(t)) out.push(t); }
  return out;
}
const sigOf = (title, html, col, pin, names) => { const s = [title, html, col, pin ? '1' : '0', [...names].sort().join('\u0000')].join('\u0001'); return h53(s) + '.' + s.length; };
export function noteSig(n, byId) { return sigOf(n.title || '', n.html || '', n.col || '', n.pin === true, labelNames(n, byId)); }

// Catatan yang boleh disinkronkan: HANYA data.notes, objek, id teks, bukan bertanda privat, id bukan milik data.priv.
function eligible(data) {
  const priv = new Set((Array.isArray(data.priv) ? data.priv : []).filter((x) => x && typeof x.id === 'string').map((x) => x.id));
  const out = new Map();
  for (const n of Array.isArray(data.notes) ? data.notes : []) {
    if (!n || typeof n !== 'object' || typeof n.id !== 'string' || !n.id) continue;
    if (n.priv || n.private || n.kind === 'priv' || priv.has(n.id)) continue;
    out.set(n.id, n);
  }
  return { notes: out, priv };
}
const trashAt = (data, id) => { for (const t of Array.isArray(data.trash) ? data.trash : []) if (t && t.kind === 'note' && t.item && t.item.id === id && Number(t.at) > 0) return Number(t.at); return 0; };

// Rencana kirim. items: [{ id, bv, sig?, del?, updated, note?, size }]. skipped: [{ id, why }]. held: null | { deletes, tracked }.
export function planPush(data, state, opts = {}) {
  const now = Number(opts.now) || Date.now(), skip = opts.exclude instanceof Set ? opts.exclude : new Set();
  const byId = labelMap(data), { notes } = eligible(data), items = [], skipped = [], dels = [];
  for (const [id, n] of notes) {
    if (skip.has(id)) continue;
    const ent = state.map[id];
    const title = typeof n.title === 'string' ? n.title : '', html = typeof n.html === 'string' ? n.html : '';
    const sig = sigOf(title, html, typeof n.col === 'string' ? n.col : '', n.pin === true, labelNames(n, byId));
    if (ent && !ent.del && ent.sig === sig) continue; // bersih
    if (!SYNC_LIM.idRe.test(id)) { skipped.push({ id, why: 'Nomor catatan tidak cocok untuk sinkron' }); continue; }
    if (title.length > SYNC_LIM.title) { skipped.push({ id, why: 'Judul lebih dari ' + SYNC_LIM.title + ' huruf' }); continue; }
    if (html.length > SYNC_LIM.html) { skipped.push({ id, why: 'Catatan terlalu besar untuk sinkron' }); continue; }
    const names = labelNames(n, byId).filter((x) => x.length <= SYNC_LIM.labelLen).slice(0, SYNC_LIM.labels);
    const updated = Number(n.updated) > 0 ? Number(n.updated) : now;
    items.push({ id, bv: ent ? ent.bv : 0, sig, updated, size: html.length + title.length + 200,
      note: { title, html, col: typeof n.col === 'string' ? n.col : '', pin: n.pin === true, labels: names, updated } });
  }
  let tracked = 0;
  for (const id of Object.keys(state.map)) {
    const ent = state.map[id]; if (ent.del) continue; tracked++;
    if (notes.has(id) || skip.has(id)) continue;
    dels.push({ id, bv: ent.bv, del: true, updated: trashAt(data, id) || now, size: 200 });
  }
  let held = null;
  if (dels.length >= SYNC_LIM.massDelete && dels.length * 2 > tracked && !opts.allowMassDelete) held = { deletes: dels.length, tracked };
  else items.push(...dels);
  return { items, skipped, held };
}
export const dirtyCount = (data, state, now) => planPush(data, state, { now, allowMassDelete: true }).items.length;

// Potong satu gelombang kiriman: maks. 50 item dan sekitar 450.000 huruf per permintaan (batas badan Worker 600.000).
export function takeBatch(items) {
  const out = []; let chars = 0;
  for (const it of items) { if (out.length >= SYNC_LIM.push || (out.length && chars + it.size > SYNC_LIM.bodyChars)) break; out.push(it); chars += it.size; }
  return out;
}
export const toWire = (it) => (it.del ? { id: it.id, bv: it.bv, del: true, updated: it.updated } : { id: it.id, bv: it.bv, note: it.note });

const newSummary = () => ({ pushed: 0, deleted: 0, created: 0, updated: 0, removed: 0, conflicts: 0, copies: [], kept: 0, rejected: [], skipped: [], held: null, rounds: 0, resets: 0, labelsAdded: 0, labelsDropped: 0, touched: { added: [], updated: [], removed: [] }, error: null, truncated: false });

function dropTrash(data, id) { if (Array.isArray(data.trash)) data.trash = data.trash.filter((t) => !(t && t.kind === 'note' && t.item && t.item.id === id)); }
function labelIds(data, names, sum, newId) {
  const labels = data.settings.labels, idOf = new Map(labels.map((l) => [l.name.toLowerCase(), l.id])), out = [];
  for (const raw of Array.isArray(names) ? names : []) {
    const nm = String(raw || '').replace(/\s+/g, ' ').trim().slice(0, LABEL_NAME_MAX); if (!nm) continue;
    let id = idOf.get(nm.toLowerCase());
    if (!id) { if (labels.length >= LABEL_MAX) { sum.labelsDropped++; continue; } id = newId(); labels.push({ id, name: nm }); idOf.set(nm.toLowerCase(), id); sum.labelsAdded++; }
    if (!out.includes(id)) out.push(id);
  }
  return out;
}

// Terapkan satu jawaban Worker ke data + keadaan. sent = item yang dikirim di permintaan itu. Mengembalikan { again, refetch }.
export function applyResponse(data, state, sent, resp, deps, sum) {
  const byIdSent = new Map(sent.map((i) => [i.id, i])), force = new Set(), res = Array.isArray(resp.results) ? resp.results : [], chg = Array.isArray(resp.changes) ? resp.changes : [];
  const lbl = labelMap(data); let refetch = false;
  const cur = () => eligible(data).notes;
  for (const r of res) {
    const it = r && byIdSent.get(r.id); if (!it) continue;
    if (r.status === 'rejected') { sum.rejected.push({ id: r.id, why: String(r.why || 'Ditolak server') }); continue; }
    const v = Number.isInteger(r.v) ? r.v : 0;
    if (it.del) {
      if (r.status === 'kept') { sum.kept++; force.add(r.id); continue; }
      if (v > 0) state.map[r.id] = { bv: v, del: 1 }; else delete state.map[r.id];
      sum.deleted++; continue;
    }
    if (r.status === 'conflict') { sum.conflicts++; if (r.copy) sum.copies.push(r.copy); }
    if (r.status === 'conflict' && r.winner === 'server') { const n = cur().get(r.id); if (n && noteSig(n, lbl) === it.sig) force.add(r.id); continue; } // versi klien sudah tersimpan di server sebagai salinan
    state.map[r.id] = { bv: v, sig: it.sig }; sum.pushed++;
  }
  if (resp.reset) { // server lebih baru-dikosongkan: semua catatan lokal dianggap belum pernah dikirim, kirim ulang
    sum.resets++;
    for (const id of Object.keys(state.map)) { if (state.map[id].del) delete state.map[id]; else state.map[id] = { bv: 0, sig: '' }; }
  }
  const got = new Set();
  for (const c of chg) { if (!c || typeof c.id !== 'string' || !Number.isInteger(c.v)) continue; got.add(c.id); applyChange(data, state, c, force, deps, sum, byIdSent); }
  for (const id of force) if (!got.has(id)) refetch = true;
  return { again: !!resp.reset, refetch };
}

function applyChange(data, state, c, force, deps, sum, sent) {
  const id = c.id, ent = state.map[id], byId = labelMap(data);
  const { notes, priv } = eligible(data), local = notes.get(id);
  if (priv.has(id)) return; // tidak pernah menimpa Catatan Privat
  if (ent && c.v <= ent.bv) return; // sudah punya versi ini atau yang lebih baru
  const localSig = local ? noteSig(local, byId) : null;
  const clean = !local || (ent && !ent.del && ent.sig === localSig) || force.has(id);
  if (c.del) {
    if (!local) { state.map[id] = { bv: c.v, del: 1 }; return; }
    if (!clean) return; // diubah di perangkat ini sesudah dikirim: biarkan, kirim berikutnya menang (ubah mengalahkan hapus)
    const i = data.notes.indexOf(local); data.notes.splice(i, 1);
    if (!Array.isArray(data.trash)) data.trash = [];
    data.trash.push({ kind: 'note', item: local, at: deps.now });
    state.map[id] = { bv: c.v, del: 1 }; sum.removed++; sum.touched.removed.push(id); return;
  }
  const n = c.note; if (!n || typeof n !== 'object') return;
  const html = deps.sanitize(typeof n.html === 'string' ? n.html : ''), title = typeof n.title === 'string' ? n.title : '', col = typeof n.col === 'string' ? n.col : '', pin = n.pin === true;
  const ids = labelIds(data, n.labels, sum, deps.newId), lbl2 = labelMap(data);
  const sig = sigOf(title, html, col, pin, ids.map((x) => lbl2.get(x)).filter(Boolean));
  if (local && localSig === sig) { state.map[id] = { bv: c.v, sig }; return; } // isi sama: cukup catat versinya
  if (!clean) return; // diubah di sini sesudah dikirim: jangan ditimpa
  const text = blocksToText('', parseNoteHtml(html)).trim(), updated = Number(c.updated) > 0 ? Number(c.updated) : deps.now;
  if (local) { Object.assign(local, { title, html, text, col, pin, labels: ids, updated }); sum.updated++; sum.touched.updated.push(id); }
  else { dropTrash(data, id); data.notes.push({ id, title, text, html, col, pin, updated, labels: ids }); sum.created++; sum.touched.added.push(id); }
  state.map[id] = { bv: c.v, sig };
}

// Satu putaran penuh sampai tuntas. call(body) = fungsi yang dikirim pemanggil: menambahkan passcode, memanggil Worker, mengembalikan JSON
// (atau melempar { message, status }). Mesin TIDAK menyimpan apa pun: pemanggil menyimpan data dan keadaan sesudahnya, juga bila ada galat (sebagian sudah diterapkan).
export async function runSync(data, state, call, deps = {}, opts = {}) {
  if (typeof deps.sanitize !== 'function') throw new Error('deps.sanitize wajib disuntikkan');
  const d = { sanitize: deps.sanitize, newId: deps.newId || defaultNewId, now: Number(deps.now) || Date.now() };
  const sum = newSummary(), gaveUp = new Set(); let cursor = state.since, rc = null; // rc = kursor tarik-ulang penuh (null = tidak sedang)
  for (;;) {
    if (++sum.rounds > SYNC_LIM.rounds) { sum.truncated = true; break; }
    const plan = planPush(data, state, { now: d.now, exclude: gaveUp, allowMassDelete: !!opts.allowMassDelete });
    sum.skipped = plan.skipped; sum.held = plan.held;
    const inRefetch = rc !== null, batch = inRefetch ? [] : takeBatch(plan.items), pending = plan.items.length - batch.length;
    let resp;
    try { resp = await call({ action: 'sync', since: inRefetch ? rc : cursor, push: batch.map(toWire) }); } catch (e) { sum.error = { message: String((e && e.message) || 'Gagal terhubung'), status: (e && e.status) || 0 }; break; }
    if (!resp || resp.ok !== true) { sum.error = { message: String((resp && resp.error) || 'Jawaban server tidak dikenal'), status: (resp && resp.status) || 0 }; break; }
    const out = applyResponse(data, state, batch, resp, d, sum), more = !!resp.more, next = more ? (Number(resp.upto) || 0) : (Number(resp.seq) || 0);
    for (const r of sum.rejected) gaveUp.add(r.id);
    if (inRefetch) rc = more ? next : null;
    else { cursor = next; state.since = cursor; if (out.refetch) rc = 0; }
    if (rc === null && pending === 0 && !(!inRefetch && (more || out.again))) break;
  }
  state.at = d.now;
  return sum;
}

// Kalimat ringkas untuk toast/status (Bahasa Indonesia).
export function describeSync(sum) {
  if (sum.error) return 'Sinkron gagal: ' + sum.error.message;
  const p = [];
  const sent = sum.pushed + sum.deleted, got = sum.created + sum.updated + sum.removed;
  if (sent) p.push(sent + ' dikirim'); if (got) p.push(got + ' diterima');
  if (sum.conflicts) p.push(sum.conflicts + ' bentrok (salinan "konflik" disimpan)');
  if (sum.rejected.length) p.push(sum.rejected.length + ' ditolak server');
  if (sum.skipped.length) p.push(sum.skipped.length + ' dilewati');
  if (sum.held) p.push(sum.held.deletes + ' penghapusan ditahan menunggu izin');
  return p.length ? 'Tersinkron: ' + p.join(', ') + '.' : 'Tersinkron. Tidak ada perubahan.';
}
