// Rev 262 / S8: pembantu MURNI panel warna lembar kerja (tanpa DOM, penyimpanan, native, eval).
// Isi: normalisasi hex, HSL <-> hex, geometri color wheel (rona = sudut, kejenuhan = jari-jari), kontras WCAG,
// teks otomatis di atas isian (inkOn), dan deret warna per tema (cahaya / kaya / gelap).
// Hasil selalu '#RRGGBB' huruf besar, persis format yang diterima L.cleanStyle (tanpa perubahan SCHEMA).
import { luminance } from './lembar-aturan.js';

export const SURF_TERANG = '#F5F7FF', SURF_GELAP = '#0A0F24'; // latar aplikasi (--bg) tema terang / gelap, dipakai pratinjau
export const INK_GELAP = '#111827', INK_TERANG = '#F9FAFB';

const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, Number.isFinite(x) ? x : lo));
const h2 = (n) => Math.round(clamp(n, 0, 255)).toString(16).padStart(2, '0');

// '#abc' | 'abc' | '#AABBCC' | ' aabbcc ' -> '#AABBCC'; selain itu null
export function normHex(s) {
  if (typeof s !== 'string') return null;
  let t = s.trim().replace(/^#/, '');
  if (/^[0-9a-fA-F]{3}$/.test(t)) t = t.split('').map((x) => x + x).join('');
  return /^[0-9a-fA-F]{6}$/.test(t) ? '#' + t.toUpperCase() : null;
}

export function hexToRgb(hex) {
  const n = normHex(hex); if (!n) return null;
  return [parseInt(n.slice(1, 3), 16), parseInt(n.slice(3, 5), 16), parseInt(n.slice(5, 7), 16)];
}
export const rgbToHex = (r, g, b) => ('#' + h2(r) + h2(g) + h2(b)).toUpperCase();

// h 0..360, s 0..100, l 0..100 -> [r,g,b] 0..255 (tanpa pembulatan; dipakai juga untuk menggambar roda warna)
export function hslToRgb(h, s, l) {
  const H = ((clamp(h, -1e6, 1e6) % 360) + 360) % 360, S = clamp(s, 0, 100) / 100, Lg = clamp(l, 0, 100) / 100;
  const k = (n) => (n + H / 30) % 12, a = S * Math.min(Lg, 1 - Lg), f = (n) => Lg - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [f(0) * 255, f(8) * 255, f(4) * 255];
}
export const hslToHex = (h, s, l) => { const c = hslToRgb(h, s, l); return rgbToHex(c[0], c[1], c[2]); };
export function hexToHsl(hex) {
  const c = hexToRgb(hex); if (!c) return null;
  const [r, g, b] = c.map((x) => x / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, l = (mx + mn) / 2;
  let h = 0;
  if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
  const s = d ? d / (1 - Math.abs(2 * l - 1)) : 0;
  return { h: Math.round(h * 10) / 10, s: Math.round(s * 1000) / 10, l: Math.round(l * 1000) / 10 };
}

// Color wheel: titik (x, y) relatif pusat, jari-jari R -> rona (0 = kanan, searah jarum jam seperti layar) dan kejenuhan 0..100
export function wheelToHs(x, y, R) {
  const r = Math.hypot(x, y), rr = R > 0 ? R : 1;
  let h = (Math.atan2(y, x) * 180) / Math.PI; if (h < 0) h += 360;
  return { h: Math.round(h * 10) / 10, s: Math.round(clamp((r / rr) * 100, 0, 100) * 10) / 10 };
}
export function hsToWheel(h, s, R) {
  const a = (clamp(h, 0, 360) * Math.PI) / 180, r = (clamp(s, 0, 100) / 100) * R;
  return { x: Math.cos(a) * r, y: Math.sin(a) * r };
}

// Kontras WCAG (1..21) dan penilaian singkat
export const contrast = (a, b) => { const la = luminance(a), lb = luminance(b), hi = Math.max(la, lb), lo = Math.min(la, lb); return (hi + 0.05) / (lo + 0.05); };
export const rating = (ratio) => (ratio >= 4.5 ? 'baik' : ratio >= 3 ? 'cukup' : 'lemah');

// Teks otomatis di atas isian: pilih yang kontrasnya lebih tinggi (isian gelap -> teks terang, isian terang -> teks gelap)
export const inkOn = (bg) => { const n = normHex(bg); if (!n) return INK_GELAP; return contrast(n, INK_TERANG) > contrast(n, INK_GELAP) ? INK_TERANG : INK_GELAP; };

// Deret warna per tema. Rona tetap, kecerahan berbeda: cahaya (isian pastel, tema terang), kaya (pekat), gelap (isian pekat gelap, tema gelap).
export const HUES = [0, 28, 48, 135, 175, 215, 265, 325];
const row = (s, l) => HUES.map((h) => hslToHex(h, s, l)).concat([hslToHex(0, 0, l)]);
export const FILL_ROWS = [
  { id: 'cahaya', label: 'Cahaya (tema terang)', colors: row(85, 85) },
  { id: 'kaya', label: 'Kaya', colors: row(70, 52) },
  { id: 'gelap', label: 'Gelap (tema gelap)', colors: row(45, 24) },
];
export const TEXT_ROWS = [
  { id: 'untukTerang', label: 'Untuk latar terang', colors: row(75, 28) },
  { id: 'untukGelap', label: 'Untuk latar gelap', colors: row(90, 78) },
];

// Pratinjau pada dua tema (+ satu baris bila sel sudah punya warna lawannya).
// kind 'bg': sel berisian + teks (ctx.fg bila sel sudah punya warna teks, kalau tidak teks otomatis inkOn).
// kind 'fg': huruf di atas latar terang dan gelap aplikasi (+ 'Di isian sel' bila ctx.bg ada).
export function themePreview(kind, hex, ctx = {}) {
  const n = normHex(hex); if (!n) return null;
  const mk = (surface, nama) => {
    if (kind === 'bg') {
      const fg = normHex(ctx.fg), ink = fg || inkOn(n), r = contrast(n, ink);
      return { nama, surface, bg: n, ink, ratio: Math.round(r * 10) / 10, nilai: rating(r), samar: contrast(n, surface) < 1.25 }; // samar = isian nyaris menyatu dengan latar tema itu
    }
    const r = contrast(n, surface); return { nama, surface, bg: surface, ink: n, ratio: Math.round(r * 10) / 10, nilai: rating(r) };
  };
  if (kind === 'bg') return [mk(SURF_TERANG, 'Terang'), mk(SURF_GELAP, 'Gelap')];
  const out = [mk(SURF_TERANG, 'Terang'), mk(SURF_GELAP, 'Gelap')], cb = normHex(ctx.bg);
  if (cb) out.push(mk(cb, 'Di isian sel'));
  return out;
}

// Rev 263: warna terakhir dipakai + warna yang sudah ada di lembar (pipet tanpa layar). Murni, tanpa penyimpanan.
// pushRecent: hex sah dipindah ke depan, tanpa duplikat, maksimal `max` (bawaan 9); daftar asli tidak diubah.
export function pushRecent(list, hex, max = 9) {
  const n = normHex(hex); const base = (Array.isArray(list) ? list : []).map(normHex).filter(Boolean);
  if (!n) return base.slice(0, max);
  return [n, ...base.filter((x) => x !== n)].slice(0, max);
}
// usedColors: warna isian ('bg') atau teks ('fg') yang dipakai sel di tab, paling sering dulu (seri: yang lebih dulu ditemukan), maksimal `max`.
export function usedColors(tab, key, max = 9) {
  const cnt = new Map(); if (!tab || !Array.isArray(tab.rows) || (key !== 'bg' && key !== 'fg')) return [];
  for (const row of tab.rows) { const cells = row && row.cells; if (!cells) continue; for (const id of Object.keys(cells)) { const s = cells[id] && cells[id].s, n = s && normHex(s[key]); if (n) cnt.set(n, (cnt.get(n) || 0) + 1); } }
  return [...cnt.entries()].map(([c, k], i) => ({ c, k, i })).sort((a, b) => b.k - a.k || a.i - b.i).slice(0, max).map((x) => x.c);
}
