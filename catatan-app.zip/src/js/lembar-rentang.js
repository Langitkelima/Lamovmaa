// Rev 179a / U10e-1: PILIH RENTANG SEL lembar kerja (MURNI: tanpa DOM, penyimpanan, native, eval, dan tanpa impor modul lain).
// Rentang = persegi indeks { r1, c1, r2, c2 } (urut kecil -> besar) yang hanya hidup di layar (TIDAK disimpan, tidak mengubah data).
// Gabungan sel yang tersentuh rentang ikut DIMASUKKAN UTUH (rentang diperluas sampai stabil), supaya Salin/Tempel (179b) tidak pernah memotong gabungan.
export const MAX_RANGE_CELLS = 2000;
const overlap = (p, q) => p.r1 <= q.r2 && q.r1 <= p.r2 && p.c1 <= q.c2 && q.c1 <= p.c2;
const intOk = (v) => Number.isInteger(v) && v >= 0;
// merges = daftar persegi gabungan ({r1,c1,r2,c2}, mis. dari mergeList(tab)); boleh kosong.
// makeRange(dims, a, b, merges) -> { ok, reason?: 'luar'|'besar', rect, rows, cols, cells, expanded }
export function makeRange(dims, a, b, merges = []) {
  const nr = dims && Number.isInteger(dims.rows) ? dims.rows : 0, nc = dims && Number.isInteger(dims.cols) ? dims.cols : 0;
  if (!a || !b || !intOk(a.r) || !intOk(a.c) || !intOk(b.r) || !intOk(b.c) || Math.max(a.r, b.r) >= nr || Math.max(a.c, b.c) >= nc) return { ok: false, reason: 'luar' };
  let rect = { r1: Math.min(a.r, b.r), c1: Math.min(a.c, b.c), r2: Math.max(a.r, b.r), c2: Math.max(a.c, b.c) }, expanded = false;
  const list = Array.isArray(merges) ? merges : [];
  for (let guard = 0; guard <= list.length; guard++) {
    let grew = false;
    for (const m of list) if (overlap(rect, m) && (m.r1 < rect.r1 || m.r2 > rect.r2 || m.c1 < rect.c1 || m.c2 > rect.c2)) {
      rect = { r1: Math.min(rect.r1, m.r1), c1: Math.min(rect.c1, m.c1), r2: Math.max(rect.r2, m.r2), c2: Math.max(rect.c2, m.c2) }; grew = true; expanded = true;
    }
    if (!grew) break;
  }
  const rows = rect.r2 - rect.r1 + 1, cols = rect.c2 - rect.c1 + 1, cells = rows * cols;
  if (cells > MAX_RANGE_CELLS) return { ok: false, reason: 'besar', rect, rows, cols, cells };
  return { ok: true, rect, rows, cols, cells, expanded };
}
export const inRect = (rect, r, c) => !!rect && r >= rect.r1 && r <= rect.r2 && c >= rect.c1 && c <= rect.c2;
// addr(c, r) = pembuat alamat sel (mis. L.cellAddr). "A3:C6", atau satu alamat bila satu sel.
export function rectRef(rect, addr) {
  if (!rect || typeof addr !== 'function') return '';
  const a = addr(rect.c1, rect.r1), b = addr(rect.c2, rect.r2); return rect.r1 === rect.r2 && rect.c1 === rect.c2 ? a : a + ':' + b;
}
export const rectSig = (rect) => (rect ? rect.r1 + ':' + rect.c1 + ':' + rect.r2 + ':' + rect.c2 : '-');
export const RANGE_MSG = { luar: 'Di luar lembar kerja.', besar: 'Rentang terlalu besar (maks. ' + MAX_RANGE_CELLS + ' sel).' };
