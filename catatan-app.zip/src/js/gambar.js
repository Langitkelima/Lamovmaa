// Rev 24C (tahap G1 gambar): mesin MURNI untuk gambar di catatan. Tanpa DOM, tanpa penyimpanan, tanpa jaringan.
// BELUM dipanggil dari aplikasi mana pun; baru dipakai mulai Rev 28 (ekspor), 33 (cadangan), 34 (import).
// Aturan keras (PROMPT_SERAH_TERIMA 13.7): byte gambar tidak pernah di localStorage atau HTML catatan; HTML hanya memuat
// rujukan ringan (<figure class="ki" data-kimg=...>), berkasnya terpisah di folder gambar/.

export const IMAGE_DIR = 'gambar';
export const MAX_IMAGES_PER_NOTE = 10;
export const MAX_SOURCE_BYTES = 30 * 1024 * 1024; // berkas sumber lebih besar ditolak
export const WARN_TOTAL_BYTES = 200 * 1024 * 1024; // peringatan lembut, bukan penolakan
const ORPHAN_GRACE_MS = 24 * 60 * 60 * 1000; // Undo/Redo dan toast Urungkan masih bisa merujuk
export const QUALITY_FLOOR = 0.5;
const QUALITY_STEP = 0.05;
export const PRESETS = {
  hemat: { name: 'Hemat', maxSide: 1024, quality: 0.65, maxBytes: 150 * 1000 },
  seimbang: { name: 'Seimbang', maxSide: 1280, quality: 0.75, maxBytes: 250 * 1000 },
  tajam: { name: 'Tajam', maxSide: 1920, quality: 0.85, maxBytes: 500 * 1000 },
};
export const DEFAULT_PRESET = 'seimbang';
export const EXTS = ['webp', 'jpg', 'png'];

const posInt = (v) => { const x = Math.trunc(Number(v)); return Number.isFinite(x) && x > 0 ? x : 0; };
const round2 = (x) => Math.round(x * 100) / 100;

export function getPreset(p = DEFAULT_PRESET) {
  if (p && typeof p === 'object' && posInt(p.maxSide) && Number(p.quality) > 0 && posInt(p.maxBytes)) return p;
  return PRESETS[p] || PRESETS[DEFAULT_PRESET];
}

// Ukuran tampil hasil kompres: rasio dipertahankan, TIDAK pernah diperbesar, sisi terpanjang <= maxSide.
export function fitSize(w, h, maxSide) {
  const W = posInt(w), H = posInt(h), M = posInt(maxSide);
  if (!W || !H || !M) return null;
  const s = Math.min(1, M / Math.max(W, H));
  return { width: Math.max(1, Math.round(W * s)), height: Math.max(1, Math.round(H * s)) };
}

// Tangga kualitas: dari kualitas awal turun bertahap sampai batas bawah 0,5.
export function qualityLadder(start, floor = QUALITY_FLOOR, step = QUALITY_STEP) {
  const q0 = Math.min(1, Math.max(floor, Number(start) || floor));
  const out = [];
  for (let q = q0; q > floor + 1e-9; q -= step) out.push(round2(q));
  out.push(floor);
  return out;
}

// Pemeriksaan berkas sumber SEBELUM didekode (jangan mendekode foto raksasa atau format yang tidak bisa didekode).
export function checkSource({ type = '', name = '', size = 0 } = {}) {
  const ty = String(type || '').toLowerCase(), nm = String(name || '').toLowerCase();
  if (/heic|heif/.test(ty) || /\.(heic|heif)$/.test(nm)) return { ok: false, reason: 'unsupported', msg: 'Format HEIC/HEIF belum bisa dibuka. Ubah dulu jadi JPG atau PNG.' };
  if (ty && !/^image\//.test(ty)) return { ok: false, reason: 'not_image', msg: 'Berkas ini bukan gambar.' };
  if (Number(size) > MAX_SOURCE_BYTES) return { ok: false, reason: 'too_big', msg: 'Gambar terlalu besar (maksimal 30 MB).' };
  if (Number(size) < 0 || !Number.isFinite(Number(size))) return { ok: false, reason: 'invalid', msg: 'Ukuran berkas tidak valid.' };
  return { ok: true };
}

// Rencana kompres. Mengembalikan target ukuran dan daftar langkah (dicoba berurutan sampai hasil <= maxBytes):
// 1) ukuran target, kualitas turun bertahap sampai 0,5; 2) bila masih besar, sisi terpanjang diperkecil (80% dari target,
// = 1024 px untuk Seimbang) pada kualitas 0,5. Gambar kecil tidak diperbesar. Gambar tetap digambar ulang (membuang EXIF/GPS).
export function planCompress(src, preset = DEFAULT_PRESET) {
  const p = getPreset(preset);
  const w = posInt(src && src.w), h = posInt(src && src.h);
  if (!w || !h) return { ok: false, reason: 'invalid', msg: 'Ukuran gambar tidak terbaca.' };
  const main = fitSize(w, h, p.maxSide);
  const small = fitSize(w, h, Math.round(p.maxSide * 0.8));
  const steps = qualityLadder(p.quality).map((quality) => ({ quality, width: main.width, height: main.height }));
  if (small.width < main.width || small.height < main.height) steps.push({ quality: QUALITY_FLOOR, width: small.width, height: small.height });
  return { ok: true, preset: p, width: main.width, height: main.height, maxBytes: p.maxBytes, steps, upscaled: false, resized: main.width !== w || main.height !== h };
}
// Apakah hasil sudah memenuhi target ukuran berkas.
export function fitsTarget(bytes, preset = DEFAULT_PRESET) { const b = Number(bytes); return Number.isFinite(b) && b > 0 && b <= getPreset(preset).maxBytes; }

// Pilihan format keluaran: WebP bila peramban benar-benar menghasilkannya; transparansi tetap didukung (WebP/PNG).
export function chooseFormat({ alpha = false, webp = false } = {}) {
  if (webp) return { mime: 'image/webp', ext: 'webp' };
  return alpha ? { mime: 'image/png', ext: 'png' } : { mime: 'image/jpeg', ext: 'jpg' };
}

// ID acak (bukan nama berkas asli, demi privasi): 16 huruf kecil/angka. `rng` boleh disuntik untuk tes.
const ALPHA = 'abcdefghijklmnopqrstuvwxyz0123456789';
// Rev 430: pesan bila berkas gambar tidak terbaca. Berkas gambar hanya ada di HP (Filesystem native);
// di versi web/laptop kegagalan itu PASTI karena gambarnya memang tidak ada di sana, bukan galat, jadi pesannya dibedakan.
export const MSG_GAMBAR_GAGAL = 'Gambar tidak dapat dimuat';
export const MSG_GAMBAR_HANYA_HP = 'Gambar hanya ada di HP';
export const pesanGambarGagal = (native) => (native ? MSG_GAMBAR_GAGAL : MSG_GAMBAR_HANYA_HP);
export const ID_RE = /^[A-Za-z0-9]{10,40}$/;
export function newImageId(rng) {
  const bytes = new Uint8Array(16);
  const c = globalThis.crypto;
  if (typeof rng === 'function') for (let i = 0; i < 16; i++) bytes[i] = Math.floor(rng() * 256) & 255;
  else if (c && typeof c.getRandomValues === 'function') c.getRandomValues(bytes);
  else for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  let s = ''; for (const b of bytes) s += ALPHA[b % ALPHA.length];
  return s;
}
export function imageFileName(ref) { const x = EXTS.includes(ref && ref.x) ? ref.x : 'webp'; return ref.id + '.' + x; }
export function imagePath(ref) { return IMAGE_DIR + '/' + imageFileName(ref); }

// Blok HTML gambar (kontrak 13.7) + paragraf kosong agar kursor bisa lanjut. `data-x` (webp/jpg/png) ditambahkan
// ke kontrak usulan supaya berkasnya bisa dicari tanpa menebak ekstensi; bila tidak ada dianggap webp.
// Mengembalikan null bila rujukan tidak sah (ID aneh tidak boleh masuk HTML).
export function buildFigure(ref) {
  if (!ref || typeof ref.id !== 'string' || !ID_RE.test(ref.id)) return null;
  const w = posInt(ref.w), h = posInt(ref.h), b = posInt(ref.b);
  if (!w || !h) return null;
  const x = EXTS.includes(ref.x) ? ref.x : 'webp';
  return `<figure class="ki" contenteditable="false" data-kimg="${ref.id}" data-w="${w}" data-h="${h}" data-b="${b}" data-x="${x}"></figure><p><br></p>`;
}

// Daftar rujukan gambar dari HTML catatan, urut kemunculan. Tanpa DOM: hanya membaca tag <figure ...>.
// Rujukan rusak (ID tidak sah, ukuran hilang) dilewati. Duplikat tetap dikembalikan (usageOf yang menyatukan).
export function parseRefs(html) {
  if (typeof html !== 'string' || !html || !html.includes('data-kimg')) return [];
  const out = [];
  const tagRe = /<figure\b([^>]*)>/gi;
  let m;
  while ((m = tagRe.exec(html))) {
    const attrs = {};
    const aRe = /([\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
    let a;
    while ((a = aRe.exec(m[1]))) attrs[a[1].toLowerCase()] = a[2] !== undefined ? a[2] : a[3];
    if (!/(^|\s)ki(\s|$)/.test(attrs.class || '')) continue;
    const id = attrs['data-kimg'];
    if (typeof id !== 'string' || !ID_RE.test(id)) continue;
    const w = posInt(attrs['data-w']), h = posInt(attrs['data-h']);
    if (!w || !h) continue;
    out.push({ id, w, h, b: posInt(attrs['data-b']), x: EXTS.includes(attrs['data-x']) ? attrs['data-x'] : 'webp' });
  }
  return out;
}

// Pemakaian: jumlah gambar UNIK dan total byte (satu berkas yang dirujuk dua kali dihitung sekali).
export function usageOf(refs) {
  const seen = new Map();
  for (const r of Array.isArray(refs) ? refs : []) if (r && r.id && !seen.has(r.id)) seen.set(r.id, posInt(r.b));
  let bytes = 0; for (const b of seen.values()) bytes += b;
  return { count: seen.size, bytes };
}

// Semua rujukan di seluruh data: catatan biasa, privat, DAN catatan di Tempat sampah (termasuk salinan hasil Duplikat yang
// berbagi berkas dengan aslinya). Dipakai sebelum membuang berkas mana pun.
export function refsOfData(data) {
  const out = [];
  const add = (n) => { if (n && typeof n === 'object') out.push(...parseRefs(n.html)); };
  if (data) {
    for (const n of Array.isArray(data.notes) ? data.notes : []) add(n);
    for (const n of Array.isArray(data.priv) ? data.priv : []) add(n);
    for (const x of Array.isArray(data.trash) ? data.trash : []) if (x && x.kind === 'note') add(x.item);
  }
  return out;
}

// Berkas yatim: tidak dirujuk catatan mana pun DAN umurnya lebih dari masa tenggang. Aman-gagal: nama yang bukan pola
// ID.ext, atau waktu ubah yang tidak jelas, TIDAK PERNAH dianggap yatim. `refs` boleh larik rujukan atau larik id.
export function findOrphans(files, refs, now = Date.now(), graceMs = ORPHAN_GRACE_MS) {
  const used = new Set((Array.isArray(refs) ? refs : []).map((r) => (typeof r === 'string' ? r : r && r.id)).filter(Boolean));
  const out = [];
  for (const f of Array.isArray(files) ? files : []) {
    const name = f && typeof f.name === 'string' ? f.name : '';
    const m = /^([A-Za-z0-9]{10,40})\.(webp|jpg|png)$/.exec(name);
    if (!m || used.has(m[1])) continue;
    const mt = Number(f.mtime);
    if (!Number.isFinite(mt) || mt <= 0 || !(now - mt > graceMs)) continue;
    out.push(name);
  }
  return out;
}

// Batas per catatan dan peringatan total. Tidak melempar: mengembalikan keputusan dan pesan.
export function canAddImages(currentInNote, adding) {
  const cur = Math.max(0, posInt(currentInNote)), add = Math.max(0, posInt(adding));
  const room = Math.max(0, MAX_IMAGES_PER_NOTE - cur);
  if (add <= room) return { ok: true, allowed: add, msg: '' };
  if (room === 0) return { ok: false, allowed: 0, msg: 'Satu catatan maksimal ' + MAX_IMAGES_PER_NOTE + ' gambar.' };
  return { ok: true, allowed: room, msg: 'Hanya ' + room + ' gambar lagi yang muat (maksimal ' + MAX_IMAGES_PER_NOTE + ' per catatan).' };
}
export function totalWarning(totalBytes) {
  return Number(totalBytes) > WARN_TOTAL_BYTES ? 'Gambar tersimpan sudah lebih dari 200 MB. Pertimbangkan menghapus gambar yang tidak dipakai.' : '';
}

// Rev 46: ukuran tampil gambar di catatan = persen lebar kolom isi (atribut data-s, kelipatan 5, 20..100).
// Bawaan 100 (penuh). Berkas gambar TIDAK diubah; hanya tampilan, jadi kualitas tetap dan hemat penyimpanan.
export const SCALE_MIN = 20;
export const SCALE_MAX = 100;
export const SCALE_STEP = 5;
export function normalizeScale(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return SCALE_MAX;
  const snapped = Math.round(n / SCALE_STEP) * SCALE_STEP;
  return Math.min(SCALE_MAX, Math.max(SCALE_MIN, snapped));
}
// Skala dari atribut figure (string atau null). Tidak sah/hilang = 100.
export function scaleOf(attr) { return /^(?:[2-9][05]|100)$/.test(String(attr == null ? '' : attr)) ? Number(attr) : SCALE_MAX; }
// Geser +/- satu langkah (dir = 1 atau -1). Tombol +/- memakai langkah 10 supaya terasa.
export function stepScale(cur, dir, step = 10) { return normalizeScale(scaleOf(String(cur)) + (dir < 0 ? -step : step)); }
// Seret pegangan: lebar awal (px) + geseran (px) terhadap lebar kolom penuh (px) -> persen terpotong ke 20..100.
export function scaleFromDrag(startPx, dx, fullPx) {
  const full = Number(fullPx); if (!(full > 0)) return SCALE_MAX;
  return normalizeScale(((Number(startPx) + Number(dx)) / full) * 100);
}


// Rev 47: rata gambar (data-a: l/c/r, bawaan c = tengah) dan kunci (data-l="1"). Hanya atribut; tanpa style inline.
export const ALIGNS = ['l', 'c', 'r'];
export const ALIGN_DEFAULT = 'c';
export function alignOf(attr) { return /^[lcr]$/.test(String(attr == null ? '' : attr)) ? String(attr) : ALIGN_DEFAULT; }
export function isLocked(attr) { return String(attr == null ? '' : attr) === '1'; }
// Posisi kiri (px) gambar selebar w di dalam kolom selebar inner yang dimulai di padX.
export function alignedX(align, padX, inner, w) {
  const a = alignOf(align);
  return a === 'l' ? padX : a === 'r' ? padX + (inner - w) : padX + (inner - w) / 2;
}

// Rev 50: pindah posisi gambar (tahan lalu seret ke antara blok, atau tombol naik/turun).
export const LONG_PRESS_MS = 450;   // tahan selama ini sebelum gambar "terangkat"
export const MOVE_SLOP = 10;        // geser lebih dari ini SEBELUM terangkat = pengguna menggulir, bukan memindah
export const AUTOSCROLL_EDGE = 56;  // jarak dari tepi area gulir yang memicu gulir otomatis saat menyeret
// rects: [{top,bottom}] blok kandidat (tanpa gambar yang dipindah), urut dari atas; y: posisi jari.
// Hasil 0..n = sisipkan SEBELUM blok ke-i (n = di paling bawah). Aturan: setelah semua blok yang titik tengahnya di atas jari.
export function dropIndex(rects, y) {
  const list = Array.isArray(rects) ? rects : []; const yy = Number(y);
  if (!Number.isFinite(yy)) return list.length;
  let idx = 0;
  for (const r of list) { const mid = (Number(r && r.top) + Number(r && r.bottom)) / 2; if (Number.isFinite(mid) && mid < yy) idx++; else break; }
  return idx;
}
// Kecepatan gulir otomatis (px per bingkai): negatif = naik, positif = turun, 0 = di tengah area.
export function scrollStep(y, top, bottom, edge = AUTOSCROLL_EDGE, max = 14) {
  const yy = Number(y), t = Number(top), b = Number(bottom);
  if (![yy, t, b].every(Number.isFinite) || b <= t) return 0;
  if (yy < t + edge) return -Math.round(Math.min(1, (t + edge - yy) / edge) * max);
  if (yy > b - edge) return Math.round(Math.min(1, (yy - (b - edge)) / edge) * max);
  return 0;
}


// ---- Rev 60 (G4): penampil layar penuh + pengaturan kualitas. Semua MURNI (tanpa DOM). ----
export const QUALITY_KEYS = ['hemat', 'seimbang', 'tajam'];
// Tulisan singkat tiap kualitas, dibaca dari PRESETS supaya angkanya tidak pernah beda dari yang dipakai kompres.
export function qualityHint(key) {
  const p = getPreset(key);
  return 'Sisi terpanjang ' + p.maxSide + ' px, tiap gambar sekitar maks. ' + Math.round(p.maxBytes / 1000) + ' KB.';
}
// Teks ukuran berkas: 0 B, 812 KB, 3,4 MB. Koma desimal gaya Indonesia.
export function formatBytes(n) {
  const b = Number(n);
  if (!Number.isFinite(b) || b <= 0) return '0 KB';
  if (b < 1024 * 1024) return Math.max(1, Math.round(b / 1024)) + ' KB';
  const mb = b / (1024 * 1024);
  return (mb < 10 ? mb.toFixed(1) : String(Math.round(mb))).replace('.', ',') + ' MB';
}
// Gambar yang baru ditulis kurang dari ini TIDAK ikut dibersihkan tombol manual (bisa jadi sedang disisipkan).
export const MANUAL_GRACE_MS = 5 * 60 * 1000;

const VIEW_MIN = 1;
const VIEW_MAX = 5;
export const VIEW_DOUBLE = 2.5;     // ketuk dua kali: perbesar sampai segini
export const SWIPE_MIN = 70;        // geser mendatar minimal ini (px) pada zoom 1 = gambar sebelumnya/berikutnya
const num = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
export function clampScale(s) { return Math.min(VIEW_MAX, Math.max(VIEW_MIN, num(s, VIEW_MIN))); }
// Ukuran gambar yang pas di layar (contain) pada zoom 1. Tidak mengubah rasio.
export function fitInto(w, h, vw, vh) {
  const W = posInt(w), H = posInt(h), VW = posInt(vw), VH = posInt(vh);
  if (!W || !H || !VW || !VH) return { w: 0, h: 0 };
  const k = Math.min(VW / W, VH / H);
  return { w: Math.max(1, Math.round(W * k)), h: Math.max(1, Math.round(H * k)) };
}
// Batas geser: gambar berukuran (iw*scale x ih*scale) di layar vw x vh. Bila lebih kecil dari layar, tetap di tengah (0).
export function clampPan(tx, ty, scale, vw, vh, iw, ih) {
  const s = clampScale(scale);
  const mx = Math.max(0, (num(iw) * s - num(vw)) / 2), my = Math.max(0, (num(ih) * s - num(vh)) / 2);
  return { tx: Math.min(mx, Math.max(-mx, num(tx))) || 0, ty: Math.min(my, Math.max(-my, num(ty))) || 0 }; // `|| 0` membuang -0
}
// Zoom yang menjaga titik (fx, fy) tetap di bawah jari. fx/fy diukur dari TENGAH layar. Hasil sudah dibatasi.
export function zoomAt(state, newScale, fx, fy, vw, vh, iw, ih) {
  const s0 = clampScale(state.scale), s1 = clampScale(newScale), k = s1 / s0;
  const tx = num(fx) - (num(fx) - num(state.tx)) * k, ty = num(fy) - (num(fy) - num(state.ty)) * k;
  const c = clampPan(tx, ty, s1, vw, vh, iw, ih);
  return { scale: s1, tx: c.tx, ty: c.ty };
}
// Cubit: skala awal x (jarak sekarang / jarak awal).
export function pinchScale(startScale, startDist, dist) {
  const d0 = num(startDist), d1 = num(dist);
  return d0 > 0 && d1 > 0 ? clampScale(num(startScale, 1) * (d1 / d0)) : clampScale(startScale);
}
// Geser mendatar cukup jauh dan lebih mendatar daripada menurun? 1 = berikutnya (geser ke kiri), -1 = sebelumnya, 0 = bukan.
export function swipeDir(dx, dy) {
  const x = num(dx), y = num(dy);
  if (Math.abs(x) < SWIPE_MIN || Math.abs(x) < Math.abs(y) * 1.5) return 0;
  return x < 0 ? 1 : -1;
}
// Pindah indeks tanpa memutar (berhenti di ujung). Mengembalikan indeks baru, atau -1 bila tidak bisa.
export function neighborIndex(i, n, dir) {
  const a = Math.trunc(num(i, -1)), t = Math.trunc(num(n)), j = a + (dir < 0 ? -1 : 1);
  return a >= 0 && a < t && j >= 0 && j < t ? j : -1;
}
// Ringkasan pemakaian untuk layar Setelan > Gambar. `refs` = rujukan di data (usageOf menyatukan duplikat);
// `files` = berkas nyata [{name,size,mtime}] di folder gambar/. Berkas yatim memakai aturan findOrphans dengan masa tenggang `graceMs`.
export function summarizeImages(refs, files, now = Date.now(), graceMs = MANUAL_GRACE_MS) {
  const used = usageOf(refs);
  const have = new Set(); let diskBytes = 0, diskCount = 0;
  for (const f of Array.isArray(files) ? files : []) {
    const m = f && /^([A-Za-z0-9]{10,40})\.(webp|jpg|png)$/.exec(f.name || '');
    if (!m) continue;
    diskCount++; diskBytes += posInt(f.size); have.add(m[1]);
  }
  const ids = new Set((Array.isArray(refs) ? refs : []).map((r) => r && r.id).filter(Boolean));
  let missing = 0; for (const id of ids) if (!have.has(id)) missing++;
  const orphanNames = findOrphans(files, refs, now, graceMs);
  let orphanBytes = 0; for (const f of Array.isArray(files) ? files : []) if (orphanNames.includes(f && f.name)) orphanBytes += posInt(f.size);
  return { used, diskCount, diskBytes, missing, orphans: orphanNames, orphanBytes };
}
