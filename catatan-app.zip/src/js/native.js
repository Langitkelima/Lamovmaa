// Akses plugin Capacitor TANPA bundler. Di aplikasi, objek global Capacitor hanya berisi jembatan native,
// jadi Capacitor.registerPlugin bisa tidak ada. Fungsi ini mencoba tiga jalur, lalu gagal dengan pesan jelas.
export function isNative() {
  const C = globalThis.Capacitor;
  return !!(C && typeof C.isNativePlatform === 'function' && C.isNativePlatform());
}
export function nativePlugin(name) {
  const C = globalThis.Capacitor;
  if (!C) throw new Error('Capacitor tidak ditemukan');
  if (typeof C.registerPlugin === 'function') return C.registerPlugin(name);
  if (C.Plugins && C.Plugins[name]) return C.Plugins[name];
  if (typeof C.nativePromise === 'function') {
    return new Proxy({}, {
      get: (_, method) => (method === 'then' ? undefined : (opts) => C.nativePromise(name, String(method), opts || {})),
    });
  }
  throw new Error('Plugin ' + name + ' tidak bisa dipanggil. Isi Capacitor: ' + Object.keys(C).slice(0, 12).join(','));
}

// Beri tahu bagian native warna tema supaya area di belakang bar status/navigasi ikut tema (dan ikon bar terbaca).
// Aman dipanggil di mana saja: tanpa jembatan native (peramban/tes) tidak melakukan apa-apa.
export function syncBars(noteHex) {
  const n = globalThis.KelimaaNative;
  if (!n || typeof n.setBars !== 'function' || typeof document === 'undefined' || !document.body) return;
  try {
    // Rev 55: editor catatan BERWARNA memberi warna catatan; bar atas = warna catatan, bar bawah = warna bilah (dock) di atasnya.
    const nm = typeof noteHex === 'string' ? /^#([0-9a-f]{6})$/i.exec(noteHex) : null;
    if (nm) {
      const c = [0, 2, 4].map((i) => parseInt(nm[1].slice(i, i + 2), 16));
      const dark = (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255 < 0.5;
      const hexOf = (a) => '#' + a.map((x) => Math.round(x).toString(16).padStart(2, '0')).join('');
      const bm = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(getComputedStyle(document.body).backgroundColor || '');
      const appDark = bm ? (0.299 * bm[1] + 0.587 * bm[2] + 0.114 * bm[3]) / 255 < 0.5 : true;
      // pendekatan warna dock: kaca (gelap rgba(32,42,96,.46), terang rgba(255,255,255,.60)) di atas warna catatan
      const t = appDark ? { c: [32, 42, 96], a: 0.46 } : { c: [255, 255, 255], a: 0.6 };
      const dock = hexOf(c.map((x, i) => x * (1 - t.a) + t.c[i] * t.a));
      n.setBars(nm[0].toLowerCase(), dark);
      if (typeof n.setBarEdges === 'function') n.setBarEdges(nm[0] + ',' + nm[0], dock + ',' + dock);
      return;
    }
    const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(getComputedStyle(document.body).backgroundColor || '');
    if (!m) return;
    const hex = '#' + [m[1], m[2], m[3]].map((x) => Number(x).toString(16).padStart(2, '0')).join('');
    const lum = (0.299 * m[1] + 0.587 * m[2] + 0.114 * m[3]) / 255;
    const dark = lum < 0.5;
    n.setBars(hex, dark);
    // Rev 54: bar status/navigasi dibuat tembus pandang dan di belakangnya digambar gradasi yang sama dengan tepi atas/bawah latar halaman.
    if (typeof n.setBarEdges === 'function') {
      const e = dark ? BAR_EDGES.dark : BAR_EDGES.light;
      n.setBarEdges(e.top.join(','), e.bottom.join(','));
    }
  } catch (e) { /* tidak fatal */ }
}

// Warna tepi atas dan bawah latar halaman (kiri ke kanan, 5 titik), DIUKUR dari tampilan asli 360x800 (Rev 54).
// Bila gradasi latar (--sky di akhir styles.css) diubah, ukur ulang dan perbarui tabel ini.
export const BAR_EDGES = {
  dark: { top: ['#293583', '#1D2760', '#11173A', '#080C1E', '#080C1E'], bottom: ['#3A1E3C', '#211429', '#0E0C1D', '#060918', '#070B1D'] },
  light: { top: ['#C8D8FF', '#D7E2FF', '#E7EDFF', '#F2F5FF', '#F1F2FF'], bottom: ['#FDD8E8', '#E5D5ED', '#E2DFF6', '#E0E5FA', '#F1F4FF'] },
};
