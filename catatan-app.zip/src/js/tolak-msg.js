// Rev 311c: teks penolakan (apa yang terjadi + kenapa + solusi). MODUL MALAS: dimuat hanya saat ada penolakan, lewat infoKey() di ui.js.
export const M = {
  maks: (apa, n, fix) => ({ title: 'Sudah di batas maksimal', msg: 'Jumlah ' + apa + ' sudah mencapai batas maksimal (' + n + '), jadi tidak bisa ditambah lagi.', fix }),
  dlmTabel: (apa) => ({ title: 'Tidak bisa di dalam tabel', msg: apa + ' tidak bisa dimasukkan ke dalam sel tabel, karena sel tabel hanya menampung teks biasa.', fix: 'Taruh kursor di luar tabel, lalu coba lagi.' }),
  gbrKunci: (aksi) => ({ title: 'Gambar terkunci', msg: 'Gambar ini sedang dikunci, jadi tidak bisa ' + aksi + '.', fix: 'Buka kuncinya lewat bilah gambar, lalu coba lagi.' }),
  kartuDekat: () => ({ title: 'Tanggal kartu terlalu dekat', msg: 'Semua waktu pengingat untuk tanggal kartu ini sudah lewat atau terlalu dekat dari sekarang, jadi pengingat tidak bisa dipasang.', fix: 'Ubah tanggal kartu ke hari yang lebih jauh, lalu atur pengingat lagi.' }),
  izin: (awal) => ({ title: 'Notifikasi belum diizinkan', msg: (awal || 'Pengingat belum bisa berbunyi') + ' karena notifikasi Android belum diizinkan untuk Notes Kelimaa.', fix: 'Izinkan notifikasi di Pengaturan Android; jadwal ikut menyala setelah kamu kembali ke aplikasi.' }),
  jadwal: () => ({ tone: 'err', title: 'Pengingat tidak terjadwal', msg: 'Perangkat ini belum bisa menjadwalkan pengingat tersebut.', fix: 'Simpan ulang; bila tetap gagal, periksa izin Notes Kelimaa di Pengaturan Android.' }),
  alarmTepat: () => ({ title: 'Alarm bisa terlambat', msg: 'Izin alarm tepat belum aktif, jadi Android boleh menunda alarm beberapa menit.', fix: 'Aktifkan Alarm dan pengingat untuk Notes Kelimaa di Pengaturan Android.' }),
  tulisBlok: () => ({ title: 'Teks terpilih tidak bisa diolah', msg: 'Teks yang kamu blok berisi tabel, gambar, kotak centang, atau blok sisipan, sedangkan Tulis AI hanya mengolah teks biasa.', fix: 'Blok teks biasa saja, lalu coba lagi.' }),
  chatWaktu: () => ({ title: 'Waktu pengingat sudah lewat', msg: 'Waktu yang dipilih belum di masa depan, jadi pengingat tidak bisa dibuat.', fix: 'Pilih tanggal dan jam setelah sekarang.' }),
  gbrGagal: (n) => ({ tone: 'err', title: 'Gambar gagal ditambahkan', msg: 'Gambar tidak bisa diproses' + (n ? ', walau ' + n + ' gambar sebelumnya sudah masuk' : '') + '. Berkasnya mungkin rusak atau formatnya tidak didukung.', fix: 'Coba pilih gambar lain (JPG, PNG, atau WebP).' }),
  muatGagal: () => ({ tone: 'err', title: 'Daftar belum bisa dimuat', msg: 'Ada gangguan saat memuat daftar, jadi datanya belum diperbarui.', fix: 'Periksa koneksi, lalu coba lagi sebentar lagi.' }),
};
