// Rev 303a: KOTAK CENTANG di sel lembar kerja (MURNI: tanpa DOM/penyimpanan/native/eval; tanpa impor). Modul MALAS (anggaran JS awal tipis); kriteria 'box' sendiri (KINDS, cleanCriteria, okCriteria) ada di lembar-validasi.js.
// Aturan { k: 'box', c, rg?, items: [], dd: false } = bagian dari tab.checks (rentang, kolom penuh, kembar/beririsan, trim saat sisip/hapus, riwayat error: semua mekanisme yang sudah ada).
// Nilai sel = boolean true/false (rumus sudah membacanya: TRUE/FALSE, SUM/COUNTIF/IF). Sel kosong = belum dicentang. Teks 'TRUE'/'FALSE' (mis. hasil tempel) juga terbaca.
const norm = (s) => String(s).trim().toLowerCase();
export const isBox = (ck) => !!ck && ck.k === 'box';
export const boxState = (raw) => raw === true || (typeof raw === 'string' && norm(raw) === 'true');
// Nilai baru sesudah diketuk: kosong/FALSE -> true; TRUE -> false (selalu boolean sungguhan).
export const nextBoxValue = (raw) => !boxState(raw);
// Ringkasan sel [[i, j], ...] (rawFn(i, j) = nilai mentah): { done, total } untuk teks \"3 dari 5 tercentang\".
export function boxTally(cells, rawFn) {
  let done = 0, total = 0; for (const [i, j] of Array.isArray(cells) ? cells : []) { total++; if (boxState(rawFn(i, j))) done++; } return { done, total };
}
// Rev 303e: RINGKASAN \"3 dari 5 tercentang\" (MURNI, tanpa impor). Dipakai info bar lembar kerja.
// sel = rect seleksi { r1, r2, c1, c2 }; rects = rentang aturan Kotak centang; boxAt(i, j) = sel itu kotak sungguhan (aturan pertama yang menutupi = Kotak, tanpa rumus).
// Seleksi SATU sel kotak = seluruh rentang aturannya (mis. B2:B5); seleksi lebih dari satu sel = kotak di dalam seleksi saja. Dibatasi cap sel (kolom/baris penuh aman).
export function boxSelCells(sel, rects, boxAt, cap = 30000) {
  const out = [], seen = new Set(); if (!sel || !Array.isArray(rects)) return out;
  const one = sel.r1 === sel.r2 && sel.c1 === sel.c2; let scan = 0;
  for (const rc of rects) {
    if (!rc) continue; const hit = one && rc.r1 <= sel.r1 && sel.r1 <= rc.r2 && rc.c1 <= sel.c1 && sel.c1 <= rc.c2;
    if (one && !hit) continue; const win = one ? rc : { r1: Math.max(rc.r1, sel.r1), r2: Math.min(rc.r2, sel.r2), c1: Math.max(rc.c1, sel.c1), c2: Math.min(rc.c2, sel.c2) };
    if (one && !boxAt(sel.r1, sel.c1)) return out;
    for (let i = win.r1; i <= win.r2; i++) for (let j = win.c1; j <= win.c2; j++) {
      if (++scan > cap) return out; const k = i + ',' + j; if (seen.has(k)) continue; seen.add(k); if (boxAt(i, j)) out.push([i, j]);
    }
    if (one) break;
  }
  return out;
}
export const boxTallyText = (t) => (t && t.total > 0 ? t.done + ' dari ' + t.total + ' tercentang' : '');
