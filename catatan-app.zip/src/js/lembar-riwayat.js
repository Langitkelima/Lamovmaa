// Rev 278 / W3 (MURNI): pemeliharaan tab.errlog (bentuk + pembersih: lembar-validasi.js). Dimuat malas bersama UI lembar kerja.
import { checkText, MAX_ERRLOG } from './lembar-validasi.js';
export { MAX_ERRLOG };
const cutS = (s, n) => String(s === undefined || s === null ? '' : s).slice(0, n);
// iv = invalidCells (Set 'i,j' + .by), text(i, j) = teks tampil. true bila berubah (idempoten). Baru salah = 'open' baru; masih salah = diperbarui di tempat; beres/baris hilang = 'fixed'; penuh = 'fixed' tertua dibuang, tanpa itu dilewati.
export function syncErrLog(tab, iv, text, now = Date.now()) {
  if (!tab) return false; const log = Array.isArray(tab.errlog) ? tab.errlog : [], cur = new Map(), open = new Map(); let ch = false;
  if (iv && iv.size && iv.by) for (const key of iv) { const [i, j] = key.split(',').map(Number), r = tab.rows[i], c = tab.cols[j], ck = iv.by.get(key); if (r && c && ck) cur.set(r.id + '|' + c.id, { ck, i, j }); }
  const tx = (m) => { try { return cutS(text(m.i, m.j), 40); } catch (_) { return ''; } }, rl = (ck) => ({ id: ck.id, t: cutS(checkText(ck), 60) });
  for (const e of log) {
    if (e.st !== 'open') continue; const k = e.r + '|' + e.c, m = cur.get(k);
    if (!m) { e.st = 'fixed'; e.fixedAt = now; ch = true; continue; }
    open.set(k, e); const v = tx(m), q = rl(m.ck); if (e.v !== v || e.rule.id !== q.id || e.rule.t !== q.t) { e.v = v; e.rule = q; ch = true; }
  }
  for (const [k, m] of cur) {
    if (open.has(k)) continue;
    if (log.length >= MAX_ERRLOG) { const f = log.findIndex((e) => e.st === 'fixed'); if (f < 0) continue; log.splice(f, 1); }
    const [r, c] = k.split('|'), used = new Set(log.map((e) => e.id)); let id; do { id = 'e' + Math.floor(now).toString(36).slice(-5) + Math.random().toString(36).slice(2, 6); } while (used.has(id));
    log.push({ id, r, c, v: tx(m), rule: rl(m.ck), at: now, st: 'open' }); ch = true;
  }
  if (ch) { if (log.length) tab.errlog = log; else delete tab.errlog; } return ch;
}
