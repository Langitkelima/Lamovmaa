// Rev 397 / PART M2: ekspor catatan ke ZIP Markdown (satu .md per catatan). Tanpa DOM; akses penyimpanan lewat FS yang DISUNTIKKAN (dites di Node).
// Memakai noteToMarkdown (M1), zipWriter, dan pola tulis bertahap ke CACHE seperti cadangan ZIP. Catatan Privat HANYA bila opts.priv (bawaan mati).
import { noteToMarkdown } from './md-catatan.js';
import { shareFileName, parseNoteHtml } from './export.js';
import { zipWriter, buildZip, utf8, bytesToBase64, base64ToBytes } from './zip.js';
import { IMG_DIRECTORY, parseRefs, imagePath, imageFileName, IMAGE_DIR } from './cadangan-gambar.js';
import { noteLabels, todayISO } from './logic.js';

export const PRIV_DIR = 'privat';
export const MD_ZIP_MAX_NOTES = 5000; // pagar waras; di atas ini ekspor ditolak dengan penjelasan
const FLUSH_BYTES = 768 * 1024;
export const mdZipName = (d = new Date()) => 'catatan-markdown-' + todayISO(d) + '.zip';

const isEmpty = (n) => !String((n && n.title) || '').trim() && !parseNoteHtml((n && n.html) || '').some((b) => b.kind === 'image' || b.kind === 'table' || (b.runs || []).some((r) => String(r.t || '').trim()));
const uniq = (used, name) => { // nama berkas unik tanpa membedakan huruf besar/kecil: x.md, x-2.md, x-3.md
  let k = name.toLowerCase(), i = 1, out = name;
  while (used.has(k)) { i++; out = name.replace(/\.md$/, '-' + i + '.md'); k = out.toLowerCase(); }
  used.add(k); return out;
};

// Rencana ekspor (murni). opts: { labels = true, images = false, priv = false }.
// Hasil: { files: [{ name, text }], imageRefs: [ref], counts: { notes, priv, kosong, lembar, gambarDilewati } }
export function planMarkdownExport(data, opts = {}, now = new Date()) {
  const o = { labels: opts.labels !== false, images: !!opts.images, priv: !!opts.priv };
  const files = [], used = new Set(), seen = new Map();
  const counts = { notes: 0, priv: 0, kosong: 0, lembar: 0, gambarDilewati: 0 };
  const allLabels = Array.isArray(data && data.settings && data.settings.labels) ? data.settings.labels : [];
  const run = (list, dir, key) => {
    for (const n of Array.isArray(list) ? list : []) {
      if (!n || typeof n !== 'object') continue;
      if (isEmpty(n)) { counts.kosong++; continue; }
      const html = String(n.html || '');
      if (/data-sheet/.test(html)) counts.lembar++;
      const refs = parseRefs(html), ext = new Map(refs.map((r) => [r.id, r]));
      if (o.images) { for (const r of refs) if (!seen.has(r.id)) seen.set(r.id, r); } else counts.gambarDilewati += refs.length;
      const meta = { labelNames: o.labels ? noteLabels(n, allLabels).map((l) => l.name) : [] };
      if (o.images) meta.imageUrl = (id) => (ext.has(id) ? (dir ? '../' : '') + imagePath(ext.get(id)) : '');
      files.push({ name: uniq(used, (dir ? dir + '/' : '') + shareFileName(n.title, 'md', now)), text: noteToMarkdown(n, meta) });
      counts[key]++;
    }
  };
  run(data && data.notes, '', 'notes');
  if (o.priv) run(data && data.priv, PRIV_DIR, 'priv');
  return { files, imageRefs: [...seen.values()], counts };
}

// Zip kecil tanpa gambar (peramban): seluruhnya di memori.
export function buildMarkdownZipBytes(plan, now = new Date()) {
  return buildZip(plan.files.map((f) => ({ name: f.name, data: utf8.encode(f.text) })), now);
}

// Zip bertahap ke CACHE (HP). Gambar yang berkasnya hilang dilewati dan dicatat di missing. Mengembalikan { uri, included, missing, written }.
export async function writeMarkdownZipToCache(FS, plan, name, now = new Date()) {
  const w = zipWriter(now);
  let buf = [], size = 0, first = true, uri = '';
  const flush = async (force) => {
    if (!size || (!force && size < FLUSH_BYTES)) return;
    const all = new Uint8Array(size); let o = 0; for (const p of buf) { all.set(p, o); o += p.length; }
    buf = []; size = 0;
    const b64 = bytesToBase64(all);
    if (first) { const r = await FS.writeFile({ path: name, data: b64, directory: 'CACHE' }); uri = (r && r.uri) || ''; first = false; }
    else await FS.appendFile({ path: name, data: b64, directory: 'CACHE' });
  };
  const push = async (parts) => { for (const p of parts) { buf.push(p); size += p.length; } await flush(false); };
  const missing = []; let included = 0;
  try {
    for (const f of plan.files) await push(w.add(f.name, utf8.encode(f.text)));
    for (const ref of plan.imageRefs) {
      let bytes = null;
      try { const r = await FS.readFile({ path: imagePath(ref), directory: IMG_DIRECTORY }); if (r && typeof r.data === 'string') bytes = base64ToBytes(r.data); } catch (_) { /* hilang */ }
      if (!bytes || !bytes.length) { missing.push(ref.id); continue; }
      await push(w.add(IMAGE_DIR + '/' + imageFileName(ref), bytes)); included++;
    }
    await push(w.finish()); await flush(true);
  } catch (e) {
    try { await FS.deleteFile({ path: name, directory: 'CACHE' }); } catch (_) { /* abaikan */ }
    throw e;
  }
  return { uri, included, missing, written: plan.files.length };
}
