// Cadangan otomatis ke folder pilihan pengguna (Rev 17). Hanya jalan di aplikasi HP (butuh plugin Filesystem).
// "Otomatis" = dicek saat aplikasi dibuka atau kembali ke layar, bukan proses latar belakang.
import { isNative, nativePlugin } from './native.js';
import { exportJSON } from './storage.js';
import { toast } from './ui.js';
import { uniqueRefs, copyImagesToBackupFolder, imagesNote } from './cadangan-gambar.js';
import { BACKUP_BASE_DIR, backupAutoName, backupWhere, isBackupDue, pushBackupHistory } from './logic.js';

let busy = false;
export const isBusy = () => busy;
const msgOf = (e) => String((e && e.message) || e || 'gagal').slice(0, 120);

// kind: 'auto' | 'manual'. Mengembalikan { ok, msg?, where?, uri? }. Tidak pernah melempar; hasil dicatat di riwayat.
export async function runBackup(ctx, kind, deps = {}) {
  const b = ctx.data.settings.backup;
  if (busy) return { ok: false, msg: 'Cadangan sedang berjalan.' };
  busy = true;
  const now = deps.now ? deps.now() : Date.now();
  const where = backupWhere(b);
  let res;
  try {
    if (!(deps.native === undefined ? isNative() : deps.native)) throw new Error('Cadangan ke folder hanya jalan di aplikasi HP.');
    const FS = deps.FS || nativePlugin('Filesystem');
    const directory = BACKUP_BASE_DIR[b.base];
    // HP lama (Android 10 ke bawah) bisa meminta izin penyimpanan; di HP baru biasanya sudah "granted". Kegagalan di sini bukan fatal.
    try {
      if (b.base === 'documents' && typeof FS.checkPermissions === 'function') {
        const p = await FS.checkPermissions();
        if (p && p.publicStorage && p.publicStorage !== 'granted' && typeof FS.requestPermissions === 'function') await FS.requestPermissions();
      }
    } catch (e) { /* lanjut mencoba menulis */ }
    const name = backupAutoName(new Date(now));
    const r = await FS.writeFile({ path: b.folder + '/' + name, data: exportJSON(ctx.data), directory, encoding: 'utf8', recursive: true });
    // Rev 44 (G2): hanya bila ada gambar, salin berkasnya ke <folder>/gambar/ (yang belum ada saja). Tanpa gambar: tidak ada panggilan tambahan.
    let note = '';
    const refs = uniqueRefs(ctx.data);
    if (refs.length) { try { note = imagesNote(await copyImagesToBackupFolder(FS, refs, b)); } catch (e) { note = ' (gambar gagal disalin)'; } }
    res = { ok: true, where, uri: (r && r.uri) || '', name, note };
  } catch (e) {
    res = { ok: false, msg: msgOf(e), where };
  } finally { busy = false; }
  b.lastTry = now;
  if (res.ok) b.lastAt = now;
  pushBackupHistory(b, { at: now, kind, ok: res.ok, where, msg: res.ok ? res.name + (res.note || '') : res.msg });
  ctx.persist();
  return res;
}

// Dipanggil saat aplikasi dibuka dan saat kembali ke layar. Diam bila belum waktunya.
export async function maybeAutoBackup(ctx, deps = {}) {
  const b = ctx.data.settings.backup;
  const now = deps.now ? deps.now() : Date.now();
  if (busy || !isBackupDue(b, now)) return null;
  if (!(deps.native === undefined ? isNative() : deps.native)) return null;
  const r = await runBackup(ctx, 'auto', deps);
  const say = deps.toast || toast;
  say(r.ok ? 'Cadangan otomatis tersimpan di ' + r.where : 'Cadangan otomatis gagal: ' + r.msg);
  if (ctx.ui && ctx.ui.tab === 'lainnya') ctx.render();
  return r;
}
