/** Utilitas murni hitung mundur lokal untuk blok Notes Kelimaa. */
import { isValidDateISO, formatDateID } from './tanggal.js';
import { isValidTimeHM } from './waktu.js';

export function addLocalDays(date, days) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  d.setDate(d.getDate() + Number(days || 0));
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function cleanCountdownTitle(value) {
  return String(value || '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
}

export function countdownDays(targetISO, now = new Date()) {
  if (!isValidDateISO(targetISO)) return null;
  const [y, m, d] = targetISO.split('-').map(Number);
  const target = Date.UTC(y, m - 1, d);
  const today = Date.UTC(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((target - today) / 86400000);
}

export function countdownLabel(targetISO, now = new Date()) {
  const days = countdownDays(targetISO, now);
  if (days === null) return '';
  if (days === 0) return 'Hari ini!';
  if (days > 0) return `${days} hari lagi`;
  return `${Math.abs(days)} hari lalu`;
}

export function countdownDateLine(targetISO, time = '') {
  if (!isValidDateISO(targetISO)) return '';
  const [y, m, d] = targetISO.split('-').map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  const label = new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(date);
  return `${label}${isValidTimeHM(time) ? ' · ' + time : ''}`;
}

export function countdownBadge(targetISO) {
  if (!isValidDateISO(targetISO)) return { month: '', day: '' };
  const [y, m, d] = targetISO.split('-').map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  return {
    month: new Intl.DateTimeFormat('id-ID', { month: 'short', timeZone: 'UTC' }).format(date).replace(/\./g, '').toUpperCase(),
    day: String(d)
  };
}
