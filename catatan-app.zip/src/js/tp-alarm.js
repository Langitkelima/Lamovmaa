// Rev 57: alarm jatuh tempo servis & pajak dari Two Pockets.
// Memakai mesin alarm Rev 21 yang SUDAH ADA (AndroidAPI.scheduleNotification); tanpa perubahan native.
// ID alarm = tp:<idPengingat>:<w|d|n>   w = 7 hari sebelum, d = hari-H, n = terlambat / km hampir habis.
// Rev 61: jam, hari-sebelum, ingatkan-bila-terlambat, dan nyala/mati bisa diatur PER ITEM (bawaan 08:00, 7 hari sebelum + hari-H, ingatkan terlambat).
// Rev 63: utang/piutang berjatuh tempo -> ID tpd:<id>:<w|d|b<N>|n>, kunci pengaturan dbt_<id>; data dari due.debts (Code.gs dueList_).
// ID: w = 7 hari sebelum, d = hari-H, b<N> = N hari sebelum (selain 7), n = terlambat.
// Semua alarm bawaan pukul 08:00 waktu HP. Alarm hanya DIPASANG ulang saat aplikasi berhasil memuat daftar (paling sering tiap 3 jam).
import { pushSchedule, withMode } from './logic.js';
import { loadConn, loadDueCache, saveDueCache, clearDueCache, clearConn, fetchDue, loadAlarmCfg, saveAlarmCfg, clearAlarmCfg, cleanCfg, isDefaultCfg } from './twopockets.js';

const HOUR = 8;
export const MIN_GAP_MS = 3 * 60 * 60 * 1000;
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const LABEL = { terlambat: 'Terlambat', segera: 'Segera', aman: 'Aman', belum: 'Belum terjadwal' };

function api() { return globalThis.AndroidAPI || globalThis.KelimaaNative || null; }
export function fmtDate(iso) { const [y, m, d] = String(iso).split('-').map(Number); return d + ' ' + MON[(m || 1) - 1] + ' ' + y; }
export function fmtNum(n) { return String(Math.abs(Math.trunc(n))).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
function atLocal(iso, hour, min = 0) { const [y, m, d] = iso.split('-').map(Number); return new Date(y, m - 1, d, hour, min, 0, 0).getTime(); }
function shiftIso(iso, days) { const [y, m, d] = iso.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10); }
// 08:00 berikutnya yang paling cepat 1 menit dari sekarang
export function nextMorning(now, hour = HOUR, min = 0) {
  const d = new Date(now); const t = new Date(d.getFullYear(), d.getMonth(), d.getDate(), hour, min, 0, 0).getTime();
  return t > now + 60000 ? t : new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1, hour, min, 0, 0).getTime();
}

function daysText(n) { return n > 0 ? n + ' hari lagi' : n === 0 ? 'hari ini' : 'terlambat ' + (-n) + ' hari'; }
function kmText(n) { return n >= 0 ? 'sisa ' + fmtNum(n) + ' km' : 'lewat ' + fmtNum(n) + ' km'; }
export function localIso(now = Date.now()) {
  const d = new Date(now); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function daysBetween(aIso, bIso) {
  const A = aIso.split('-').map(Number), B = bIso.split('-').map(Number);
  return Math.round((Date.UTC(A[0], A[1] - 1, A[2]) - Date.UTC(B[0], B[1] - 1, B[2])) / 86400000);
}
// Teks satu baris untuk kartu di layar Two Pockets. Sisa hari dihitung dari TANGGAL HARI INI (bukan angka lama dari server).
export function describeBill(b) {
  const rem = (b && b.remind || []).map(r => (r.d === 0 ? 'hari-H' : 'H-' + r.d) + ' ' + r.t).join(', ');
  return (b && b.status === 'terlambat' ? 'Terlambat' : b && b.status === 'segera' ? 'Segera' : 'Aman') + ' · jatuh tempo ' + fmtDate(b.nextDue) + (rem ? ' · alarm ' + rem : ' · tanpa alarm');
}
// Rev 73: pengaturan efektif satu tagihan untuk tampilan kartu (pengingat lama Two Pockets diterjemahkan jadi jam + hari sebelum).
export function billCfgView(b, cfgs) {
  if (hasBillCfg(b, cfgs)) return cleanCfg(cfgs && cfgs[billKey(b.id)]);
  const r = b.remind, [h, m] = r[0].t.split(':').map(Number);
  return cleanCfg({ on: true, hour: h, min: m, before: r.map((x) => x.d), late: true });
}
// Rev 63: utang/piutang berjatuh tempo. Kunci pengaturan alarm = dbt_<id> (satu tempat dengan servis/pajak di kunci CFG).
export const debtKey = (id) => 'dbt_' + id;
// Rev 73: tagihan ikut model servis/pajak/utang: sakelar + jadwal diatur di Notes, kunci pengaturan bil_<id>.
// Tagihan yang BELUM punya pengaturan di Notes dan masih membawa pengingat lama dari Two Pockets tetap memakai pengingat lama itu.
export const billKey = (id) => 'bil_' + id;
export const hasBillCfg = (b, cfgs) => !!(cfgs && b && cfgs[billKey(b.id)]) || !(b && b.remind && b.remind.length);
export function describeDebt(d, today = localIso()) {
  const n = daysBetween(d.due, today);
  const st = n < 0 ? 'Terlambat' : n <= 7 ? 'Segera' : 'Aman';
  return st + ' \u00b7 sisa Rp' + fmtNum(d.left) + ' \u00b7 jatuh tempo ' + fmtDate(d.due) + ' (' + daysText(n) + ')';
}
// Rev 64: status satu baris untuk lencana kartu (terlambat | segera | aman | belum). kind: 'item' (servis/pajak), 'bill', 'debt'.
export function dueStatus(kind, x, today = localIso()) {
  if (kind === 'debt') { const n = daysBetween(x.due, today); return n < 0 ? 'terlambat' : n <= 7 ? 'segera' : 'aman'; }
  return x && LABEL[x.status] ? x.status : (kind === 'bill' ? 'aman' : 'belum');
}
export function describeDue(it, today = localIso()) {
  const parts = [LABEL[it.status] || LABEL.belum];
  if (it.dueDate) parts.push('jatuh tempo ' + fmtDate(it.dueDate) + ' (' + daysText(daysBetween(it.dueDate, today)) + ')');
  if (it.dueKm && it.kmLeft !== null) parts.push(kmText(it.kmLeft));
  return parts.join(' \u00b7 ');
}
function lateMessage(it) {
  const parts = [];
  if (it.daysLeft !== null && it.daysLeft < 0) parts.push('Terlambat ' + (-it.daysLeft) + ' hari');
  else if (it.dueDate) parts.push('Jatuh tempo ' + fmtDate(it.dueDate));
  if (it.kmLeft !== null) parts.push(kmText(it.kmLeft));
  const s = parts.join(' \u00b7 ');
  return (s ? s : 'Sudah waktunya') + '.';
}

export const hhmm = (c) => String(c.hour).padStart(2, '0') + ':' + String(c.min).padStart(2, '0');
const beforeId = (id, n) => 'tp:' + id + ':' + (n === 7 ? 'w' : n === 0 ? 'd' : 'b' + n);
// Teks ringkas pengaturan satu item, untuk ditampilkan di kartu.
export function describeCfg(raw) {
  const c = cleanCfg(raw);
  if (!c.on) return 'Alarm mati';
  const days = c.before.map((n) => (n === 0 ? 'hari-H' : 'H-' + n)).join(', ');
  return 'Alarm ' + hhmm(c) + ' \u00b7 ' + (days || 'tanpa pengingat sebelum') + (c.late ? ' \u00b7 + tiap hari bila terlambat' : '');
}

// MURNI: daftar alarm yang harus ada. Alarm yang waktunya sudah lewat tidak dibuat. cfgs = { [idItem]: pengaturan } (opsional).
export function planAlarms(items, now, cfgs = {}, bills = [], debts = []) {
  const out = [];
  for (const it of items || []) {
    if (!it || it.status === 'belum') continue;
    const cfg = cleanCfg(cfgs && cfgs[it.id]);
    if (!cfg.on) continue;
    const title = ((it.vehicle ? it.vehicle + ': ' : '') + it.name).slice(0, 80);
    if (it.dueDate) {
      for (const n of cfg.before) {
        const at = atLocal(shiftIso(it.dueDate, -n), cfg.hour, cfg.min);
        if (at > now + 60000) out.push(withMode({ id: beforeId(it.id, n), at, title, message: n === 0 ? 'Jatuh tempo hari ini.' : 'Jatuh tempo ' + n + ' hari lagi (' + fmtDate(it.dueDate) + ').' }, cfg.mode));
      }
    }
    const kmAlert = it.kmLeft !== null && it.kmLeft <= 300;
    if (cfg.late && (it.status === 'terlambat' || kmAlert)) out.push(withMode({ id: 'tp:' + it.id + ':n', at: nextMorning(now, cfg.hour, cfg.min), title, message: lateMessage(it) }, cfg.mode));
  }
  // Rev 62: alarm tagihan memakai namespace tpb: agar tidak bertabrakan dengan tp: servis/pajak.
  for (const b of bills || []) {
    if (!b || !b.id || !b.nextDue) continue;
    const title = ('Tagihan: ' + (b.name || 'Tagihan')).slice(0, 80);
    if (hasBillCfg(b, cfgs)) {
      // Rev 73: jadwal diatur di Notes (jam, hari sebelum, ulang bila terlambat, nyala/mati).
      const cfg = cleanCfg(cfgs && cfgs[billKey(b.id)]);
      if (!cfg.on) continue;
      for (const n of cfg.before) {
        const at = atLocal(shiftIso(b.nextDue, -n), cfg.hour, cfg.min);
        if (at > now + 60000) out.push(withMode({ id: 'tpb:' + b.id + ':' + (n === 7 ? 'w' : n === 0 ? 'd' : 'b' + n), at, title, message: n === 0 ? 'Jatuh tempo hari ini.' : 'Jatuh tempo ' + n + ' hari lagi (' + fmtDate(b.nextDue) + ').' }, cfg.mode));
      }
      if (cfg.late && b.nextDue < localIso(now)) out.push(withMode({ id: 'tpb:' + b.id + ':n', at: nextMorning(now, cfg.hour, cfg.min), title, message: 'Tagihan terlambat ' + daysBetween(localIso(now), b.nextDue) + ' hari (jatuh tempo ' + fmtDate(b.nextDue) + ').' }, cfg.mode));
      continue;
    }
    (b.remind || []).slice(0, 4).forEach((r, i) => {
      const at = atLocal(shiftIso(b.nextDue, -r.d), Number(r.t.slice(0, 2)), Number(r.t.slice(3, 5)));
      if (at > now + 60000) out.push({ id: 'tpb:' + b.id + ':b' + i, at, title, message: r.d === 0 ? 'Jatuh tempo hari ini.' : 'Jatuh tempo ' + r.d + ' hari lagi (' + fmtDate(b.nextDue) + ').' });
    });
    if (b.status === 'terlambat' && b.remind && b.remind.length) {
      const first = b.remind[0], at = nextMorning(now, Number(first.t.slice(0, 2)), Number(first.t.slice(3, 5)));
      out.push({ id: 'tpb:' + b.id + ':bn', at, title, message: 'Tagihan terlambat: ' + fmtDate(b.nextDue) + '.' });
    }
  }
  // Rev 63: utang/piutang memakai namespace tpd: dan kunci pengaturan dbt_<id>. Terlambat dihitung dari tanggal HP (bukan status lama di cache).
  for (const d of debts || []) {
    if (!d || !d.id || !d.due) continue;
    const cfg = cleanCfg(cfgs && cfgs[debtKey(d.id)]);
    if (!cfg.on) continue;
    const who = (d.person || '').slice(0, 50);
    const title = (d.kind === 'utang' ? 'Utang ke ' : 'Piutang dari ') + who;
    const sisa = ' Sisa Rp' + fmtNum(d.left) + '.';
    for (const n of cfg.before) {
      const at = atLocal(shiftIso(d.due, -n), cfg.hour, cfg.min);
      if (at > now + 60000) out.push(withMode({ id: 'tpd:' + d.id + ':' + (n === 7 ? 'w' : n === 0 ? 'd' : 'b' + n), at, title, message: (n === 0 ? 'Jatuh tempo hari ini.' : 'Jatuh tempo ' + n + ' hari lagi (' + fmtDate(d.due) + ').') + sisa }, cfg.mode));
    }
    if (cfg.late && d.due < localIso(now)) out.push(withMode({ id: 'tpd:' + d.id + ':n', at: nextMorning(now, cfg.hour, cfg.min), title, message: 'Terlambat ' + daysBetween(localIso(now), d.due) + ' hari (jatuh tempo ' + fmtDate(d.due) + ').' + sisa }, cfg.mode));
  }
  // Batas bersama: bila >60, pertahankan alarm dengan waktu terdekat.
  if (out.length > 60) return out.sort((a, b) => a.at - b.at).slice(0, 60);
  return out;
}

function cancelIds(ids, a = api()) {
  if (!a || typeof a.cancelScheduledNotification !== 'function') return;
  for (const id of ids || []) { try { a.cancelScheduledNotification(id); } catch (e) { console.warn('Pembatalan alarm Two Pockets gagal', e); } }
}
// Pasang semua alarm di rencana, lalu batalkan alarm lama yang tidak ada lagi di rencana.
export function applyAlarms(plan, prevIds, now, a = api()) {
  if (!a || typeof a.scheduleNotification !== 'function') return { ok: false, reason: 'unavailable', warning: '', ids: [] };
  const ids = []; let warning = '', denied = false, failed = 0, fallback = false;
  for (const p of plan) {
    try {
      const { res, fellBack } = pushSchedule(a, p.id, p.title, p.message, Math.max(1000, p.at - now), 0, p.mode);
      if (fellBack) fallback = true;
      if (res === 'permission_denied') { denied = true; continue; }
      if (res === 'error') { failed++; continue; }
      if (res === 'inexact_alarm') warning = 'inexact_alarm';
      ids.push(p.id);
    } catch (_) { failed++; }
  }
  if (denied) { try { if (typeof a.requestNotificationPermission === 'function') a.requestNotificationPermission(); } catch (_) { /* abaikan */ } }
  const keep = new Set(plan.map((p) => p.id));
  cancelIds((prevIds || []).filter((id) => !keep.has(id)), a);
  return { ok: !denied && failed === 0, reason: denied ? 'permission' : failed ? 'native_error' : '', warning, ids, ...(fallback ? { alarmFallback: true } : {}) };
}

// Muat daftar dari Two Pockets, simpan, lalu pasang alarm. Gagal (offline dll.) = cache dan alarm lama dibiarkan.
let inflight = null; // dua pemanggil sekaligus (buka aplikasi + kembali ke layar) berbagi satu permintaan
export function refreshDue(opts = {}) {
  if (inflight) return inflight;
  inflight = refreshDueNow(opts).finally(() => { inflight = null; });
  return inflight;
}
async function refreshDueNow({ http, now = Date.now(), store, api: a, force = false } = {}) {
  const conn = loadConn(store);
  if (!conn) return { ok: false, reason: 'noconn' };
  const cache = loadDueCache(store);
  if (!force && cache && cache.fetchedAt <= now && now - cache.fetchedAt < MIN_GAP_MS) return { ok: true, skipped: true, cache };
  const res = await fetchDue(conn, http);
  if (!res.ok) return { ok: false, reason: 'fetch', msg: res.msg, cache };
  const alarmOn = cache ? cache.alarm : true;
  const prev = cache ? cache.sched : [];
  const next = { fetchedAt: now, today: res.due.today, items: res.due.items, bills: res.due.bills || [], debts: res.due.debts || [], sched: [], alarm: alarmOn };
  let alarm = { ok: true, reason: '', warning: '', ids: [] };
  if (alarmOn) { alarm = applyAlarms(planAlarms(next.items, now, loadAlarmCfg(store), next.bills, next.debts), prev, now, a); next.sched = alarm.ids; }
  else cancelIds(prev, a);
  saveDueCache(next, store);
  return { ok: true, cache: next, alarm };
}

// Nyalakan/matikan alarm tanpa internet (memakai daftar yang sudah tersimpan).
export function setAlarmEnabled(on, { now = Date.now(), store, api: a } = {}) {
  const cache = loadDueCache(store) || { fetchedAt: 0, today: '', items: [], bills: [], debts: [], sched: [], alarm: true };
  let alarm = { ok: true, reason: '', warning: '', ids: [] };
  if (on) { alarm = applyAlarms(planAlarms(cache.items, now, loadAlarmCfg(store), cache.bills, cache.debts), cache.sched, now, a); cache.sched = alarm.ids; cache.alarm = true; }
  else { cancelIds(cache.sched, a); cache.sched = []; cache.alarm = false; }
  saveDueCache(cache, store);
  return { ok: true, alarm };
}

// Dipanggil setelah Pulihkan cadangan: cancelAllReminders() ikut menghapus alarm Two Pockets, jadi pasang lagi dari cache.
export function reapplyAlarms({ now = Date.now(), store, api: a } = {}) {
  const cache = loadDueCache(store);
  if (!cache || !cache.alarm || !(cache.items.length || (cache.bills || []).length || (cache.debts || []).length)) return { ok: true, skipped: true };
  const r = applyAlarms(planAlarms(cache.items, now, loadAlarmCfg(store), cache.bills, cache.debts), [], now, a);
  cache.sched = r.ids; saveDueCache(cache, store);
  return { ok: true, alarm: r };
}

// Rev 74: pemeriksaan SEMUA syarat notifikasi + notifikasi tes 10 detik (id tptest). Hanya membaca keadaan; tidak mengubah jadwal asli.
export function diagnose({ now = Date.now(), store, api: a = api(), test = true } = {}) {
  const r = { native: !!a, notif: 'unknown', exact: null, master: true, connected: !!loadConn(store), fetchedAt: 0, planned: 0, installed: 0, next: null, testAt: 0 };
  const cache = loadDueCache(store);
  if (cache) {
    r.fetchedAt = cache.fetchedAt || 0; r.master = cache.alarm !== false; r.installed = (cache.sched || []).length;
    const plan = planAlarms(cache.items, now, loadAlarmCfg(store), cache.bills, cache.debts).sort((x, y) => x.at - y.at);
    r.planned = plan.length; r.next = plan[0] ? { at: plan[0].at, title: plan[0].title } : null;
  }
  if (!a) return r;
  try { if (typeof a.canScheduleExactAlarms === 'function') r.exact = !!a.canScheduleExactAlarms(); } catch (_) { /* abaikan */ }
  if (test && typeof a.scheduleNotification === 'function') {
    let res = 'error';
    try { res = a.scheduleNotification('tptest', 'Tes notifikasi Notes', 'Kalau ini muncul, HP siap menerima alarm jatuh tempo.', 10000, 0); } catch (_) { /* error */ }
    r.notif = res === 'permission_denied' ? 'denied' : res === 'error' ? 'error' : 'ok';
    if (r.notif === 'ok') r.testAt = now + 10000;
    if (r.notif === 'denied') { try { if (typeof a.requestNotificationPermission === 'function') a.requestNotificationPermission(); } catch (_) { /* abaikan */ } }
  }
  return r;
}

// Batalkan semua alarm Two Pockets dan hapus daftar tersimpan (ganti passcode/alamat atau Putuskan).
export function dropDue({ store, api: a } = {}) {
  const cache = loadDueCache(store);
  if (cache) cancelIds(cache.sched, a);
  clearDueCache(store);
}
export function disconnect({ store, api: a } = {}) { dropDue({ store, api: a }); clearAlarmCfg(store); clearConn(store); }

// Rev 61: simpan pengaturan alarm satu item, lalu pasang ulang alarm dari daftar tersimpan (tanpa internet).
export function setItemCfg(itemId, raw, { now = Date.now(), store, api: a } = {}) {
  const all = loadAlarmCfg(store); const cfg = cleanCfg(raw);
  // Tagihan (bil_) selalu disimpan, supaya jadwal bawaan tidak jatuh kembali ke pengingat lama Two Pockets.
  if (isDefaultCfg(cfg) && !String(itemId).startsWith('bil_')) delete all[itemId]; else all[itemId] = cfg;
  if (!saveAlarmCfg(all, store)) return { ok: false, reason: 'save' };
  const cache = loadDueCache(store);
  if (!cache || !cache.alarm) return { ok: true, alarm: null };
  const alarm = applyAlarms(planAlarms(cache.items, now, all, cache.bills, cache.debts), cache.sched, now, a);
  cache.sched = alarm.ids; saveDueCache(cache, store);
  return { ok: true, alarm };
}
