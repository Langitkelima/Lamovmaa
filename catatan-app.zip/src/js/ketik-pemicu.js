// Rev 336 / PART I1: MESIN PEMICU KETIKAN TERSEMBUNYI (murni, tanpa DOM, tanpa impor, tanpa penyimpanan).
// Membaca teks SEBELUM kursor pada satu baris/blok (bukan seluruh catatan) lalu mengenali SATU pola:
//   [[judul   -> tautan antar catatan (I2)        #tag     -> label cepat (I3)
//   12*3=     -> hitung cepat (I4)                /perintah -> menu cepat (I6)
//   [] spasi  -> kotak centang (I7)               1. spasi -> daftar bernomor (I7)
//   - spasi   -> daftar bullet (Rev 358, gaya WhatsApp)
//   !jam 9    -> saran pengingat (I8)
// Modul ini TIDAK mengubah apa pun: hanya mengembalikan deskripsi pemicu (jenis, rentang teks yang dipicu, data).
// Penerapan (DOM, Undo, label, pengingat) ada di PART berikutnya. Semua indeks relatif terhadap `sebelum`;
// pemicu selalu berakhir di kursor (end === sebelum.length). Hanya editor catatan BIASA (ctx 'note'): konteks lain = null
// (Catatan Privat, sel tabel, lembar kerja tidak pernah memicu; keputusan D-I1).
// Dimuat MALAS oleh pemakainya nanti; JANGAN diimpor statis dari jalur buka (anggaran JS buka, tes rev193/rev194).

export const TRIGGER_KINDS = ['checkbox', 'numbered', 'bullet', 'calc', 'remind', 'wiki', 'tag', 'slash'];
export const TAIL = 400;         // huruf terakhir yang dipindai detectTrigger
export const MAX_SCAN = 80;      // huruf terakhir yang dipindai untuk ekspresi hitung
export const MAX_TAG = 20;       // sama dengan LABEL_NAME_MAX di logic.js
export const MAX_WIKI = 60;      // panjang pencarian judul sesudah [[
export const MAX_SLASH = 12;     // panjang perintah sesudah /
export const DEFAULT_HOUR = 9;   // jam bawaan bila pengingat diketik tanpa jam (ASUMSI, bisa diubah)

const SCAN_MAX_TOKENS = 60, SCAN_MAX_DEPTH = 20, SCAN_MAX_ABS = 1e15;

// ------------------------------------------------------------------ Hitung cepat (I4)
// Pengurai aman (tanpa eval/Function): + - * / ^ ( ) % dan × ÷ ; angka gaya Indonesia (koma = desimal; titik = ribuan bila
// berpola 1.500.000, selain itu desimal), akhiran rb/ribu/jt/juta menempel di angka. Persen sufiks: 10% = 0,1 (bukan "persen dari").
// Pangkat kanan-asosiatif dan lebih kuat dari minus satuan: -2^2 = -4.
const UNITS = { rb: 1e3, ribu: 1e3, jt: 1e6, juta: 1e6 };

function numFrom(raw) { // raw: potongan angka tanpa spasi; null bila tidak sah
  let s = raw;
  if (/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) s = s.replace(/\./g, '').replace(',', '.'); // 1.500.000 / 1.500,5
  else if (/^\d+(,\d+)?$/.test(s)) s = s.replace(',', '.');                              // 12 / 12,5
  else if (/^\d+\.\d+$/.test(s)) { /* 12.5 desimal titik */ }
  else return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

function tokenize(src) {
  const out = []; let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (ch === ' ' || ch === '\t' || ch === '\u00a0') { i++; continue; }
    if (/\d/.test(ch)) {
      const m = /^\d[\d.,]*/.exec(src.slice(i)); let raw = m[0];
      raw = raw.replace(/[.,]+$/, ''); // titik/koma di ujung bukan bagian angka
      if (!raw) return null;
      const n = numFrom(raw); if (n === null) return null;
      i += raw.length;
      const u = /^\s?(ribu|juta|rb|jt)(?![a-z])/i.exec(src.slice(i));
      let val = n;
      if (u) { val = n * UNITS[u[1].toLowerCase()]; i += u[0].length; }
      out.push({ t: 'n', v: val, unit: !!u }); continue;
    }
    if (ch === '*' || ch === '×') { out.push({ t: 'o', v: '*' }); i++; continue; }
    if (ch === '/' || ch === '÷') { out.push({ t: 'o', v: '/' }); i++; continue; }
    if ('+-^'.includes(ch)) { out.push({ t: 'o', v: ch }); i++; continue; }
    if (ch === '(' || ch === ')') { out.push({ t: ch }); i++; continue; }
    if (ch === '%') { out.push({ t: '%' }); i++; continue; }
    return null; // karakter asing = bukan ekspresi
  }
  return out.length && out.length <= SCAN_MAX_TOKENS ? out : null;
}

// Mengembalikan { v, ops } atau null. `ops` = jumlah operator/persen/satuan (agar "5=" polos tidak memicu).
export function evalExpr(src) {
  const toks = tokenize(String(src == null ? '' : src)); if (!toks) return null;
  let p = 0, ops = 0, bad = false;
  const peek = () => toks[p];
  const fail = () => { bad = true; return NaN; };
  function primary(depth) {
    if (depth > SCAN_MAX_DEPTH) return fail();
    const t = peek(); if (!t) return fail();
    let v;
    if (t.t === 'n') { p++; v = t.v; if (t.unit) ops++; }
    else if (t.t === '(') {
      p++; v = add(depth + 1);
      if (bad) return NaN;
      if (!peek() || peek().t !== ')') return fail();
      p++;
    } else return fail();
    while (peek() && peek().t === '%') { p++; v = v / 100; ops++; }
    return v;
  }
  function unary(depth) {
    const t = peek();
    if (t && t.t === 'o' && (t.v === '-' || t.v === '+')) { p++; ops++; const v = unary(depth + 1); return t.v === '-' ? -v : v; }
    return power(depth);
  }
  function power(depth) {
    const base = primary(depth); if (bad) return NaN;
    const t = peek();
    if (t && t.t === 'o' && t.v === '^') { p++; ops++; const ex = unary(depth + 1); if (bad) return NaN; return Math.pow(base, ex); }
    return base;
  }
  function mul(depth) {
    let v = unary(depth); if (bad) return NaN;
    for (;;) {
      const t = peek(); if (!t || t.t !== 'o' || (t.v !== '*' && t.v !== '/')) break;
      p++; ops++; const r = unary(depth); if (bad) return NaN;
      if (t.v === '*') v *= r; else { if (r === 0) return fail(); v /= r; }
    }
    return v;
  }
  function add(depth) {
    let v = mul(depth); if (bad) return NaN;
    for (;;) {
      const t = peek(); if (!t || t.t !== 'o' || (t.v !== '+' && t.v !== '-')) break;
      p++; ops++; const r = mul(depth); if (bad) return NaN;
      v = t.v === '+' ? v + r : v - r;
    }
    return v;
  }
  const v = add(0);
  if (bad || p !== toks.length || !Number.isFinite(v) || Math.abs(v) >= SCAN_MAX_ABS) return null;
  return { v: v === 0 ? 0 : Number(v.toPrecision(12)), ops };
}

// Angka -> teks Indonesia: titik ribuan, koma desimal, maksimal 10 desimal tanpa nol di ujung. Contoh: 1500000 -> "1.500.000", 0.5 -> "0,5".
export function formatCalc(n) {
  if (!Number.isFinite(n)) return '';
  const s = Number(n.toPrecision(12)).toFixed(10).replace(/0+$/, '').replace(/\.$/, '');
  let neg = s.startsWith('-'); const body = neg ? s.slice(1) : s;
  if (/^0(\.0*)?$/.test(body)) neg = false; // -0 dan pembulatan ke nol tidak diberi minus
  const [ip, fp] = body.split('.');
  const grouped = ip.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return (neg ? '-' : '') + grouped + (fp ? ',' + fp : '');
}

// before diakhiri "="; cari ekspresi TERPANJANG yang sah tepat sebelum "=" (mulai dari digit, "(" atau minus/plus satuan).
function detectCalc(before) {
  if (!before.endsWith('=')) return null;
  const body = before.slice(0, -1); if (!body.trim()) return null;
  const from = Math.max(0, body.length - MAX_SCAN);
  for (let i = from; i < body.length; i++) {
    const c = body[i];
    if (!(/\d/.test(c) || c === '(' || c === '-' || c === '+')) continue;
    if (i > 0 && /[\d.,]/.test(body[i - 1])) continue; // jangan mulai di tengah angka
    const r = evalExpr(body.slice(i));
    if (r && r.ops > 0) return { kind: 'calc', start: i, end: before.length, expr: body.slice(i).trim(), value: r.v, text: formatCalc(r.v) };
  }
  return null;
}

// ------------------------------------------------------------------ Pengingat cepat (I8)
const DAYS = { minggu: 0, senin: 1, selasa: 2, rabu: 3, kamis: 4, jumat: 5, sabtu: 6 };
const DAY_NAMES = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const MONTHS = { jan: 0, januari: 0, feb: 1, februari: 1, mar: 2, maret: 2, apr: 3, april: 3, mei: 4, jun: 5, juni: 5, jul: 6, juli: 6, agu: 7, agt: 7, agustus: 7, sep: 8, sept: 8, september: 8, okt: 9, oktober: 9, nov: 10, november: 10, des: 11, desember: 11 };
const MONTH_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const pad2 = (n) => String(n).padStart(2, '0');

function parseTime(s) { // "9", "09", "9.30", "9:30", "14.30" -> {h, m} atau null
  const m = /^(\d{1,2})(?:[.:](\d{2}))?$/.exec(s); if (!m) return null;
  const h = Number(m[1]), mi = m[2] === undefined ? 0 : Number(m[2]);
  return h <= 23 && mi <= 59 ? { h, m: mi } : null;
}
const atTime = (base, tm) => new Date(base.getFullYear(), base.getMonth(), base.getDate(), tm.h, tm.m, 0, 0);

// Mengurai teks SESUDAH "!" (mis. "jam 9", "besok 9.30", "jumat 14.30", "15 des 8"). `now` = Date atau ms.
// Mengembalikan { when (ms), label, hasTime } atau null. Waktu lampau TIDAK digeser di sini (aturan checkChoice milik pemakai).
export function parseRemind(text, now) {
  const t = String(text == null ? '' : text).trim().toLowerCase().replace(/\s+/g, ' '); if (!t || t.length > 24) return null;
  const nowD = new Date(now == null ? Date.now() : now); if (Number.isNaN(nowD.getTime())) return null;
  let m, tm, when, label;
  if ((m = /^jam (\S+)$/.exec(t))) { // jam wajib
    tm = parseTime(m[1]); if (!tm) return null;
    when = atTime(nowD, tm); label = 'Hari ini ' + pad2(tm.h) + '.' + pad2(tm.m);
    return { when: when.getTime(), label, hasTime: true };
  }
  const dflt = { h: DEFAULT_HOUR, m: 0 };
  if ((m = /^besok(?: (\S+))?$/.exec(t))) {
    tm = m[1] === undefined ? dflt : parseTime(m[1]); if (!tm) return null;
    const d = new Date(nowD.getFullYear(), nowD.getMonth(), nowD.getDate() + 1);
    return { when: atTime(d, tm).getTime(), label: 'Besok ' + pad2(tm.h) + '.' + pad2(tm.m), hasTime: m[1] !== undefined };
  }
  if ((m = /^([a-z]+)(?: (\S+))?$/.exec(t)) && Object.prototype.hasOwnProperty.call(DAYS, m[1])) {
    tm = m[2] === undefined ? dflt : parseTime(m[2]); if (!tm) return null;
    const target = DAYS[m[1]]; let ahead = (target - nowD.getDay() + 7) % 7;
    let d = new Date(nowD.getFullYear(), nowD.getMonth(), nowD.getDate() + ahead);
    if (ahead === 0 && atTime(d, tm).getTime() <= nowD.getTime()) d = new Date(nowD.getFullYear(), nowD.getMonth(), nowD.getDate() + 7);
    return { when: atTime(d, tm).getTime(), label: DAY_NAMES[target] + ' ' + pad2(tm.h) + '.' + pad2(tm.m), hasTime: m[2] !== undefined };
  }
  if ((m = /^(\d{1,2}) ([a-z]+)(?: (\S+))?$/.exec(t)) && Object.prototype.hasOwnProperty.call(MONTHS, m[2])) {
    tm = m[3] === undefined ? dflt : parseTime(m[3]); if (!tm) return null;
    const day = Number(m[1]), mon = MONTHS[m[2]]; if (day < 1 || day > 31) return null;
    let y = nowD.getFullYear(), d = new Date(y, mon, day);
    if (d.getMonth() !== mon || d.getDate() !== day) return null; // 31 feb dst. tidak ada
    if (atTime(d, tm).getTime() <= nowD.getTime()) { y += 1; d = new Date(y, mon, day); if (d.getMonth() !== mon || d.getDate() !== day) return null; } // tanggal yang sudah lewat = tahun depan
    return { when: atTime(d, tm).getTime(), label: day + ' ' + MONTH_SHORT[mon] + ' ' + pad2(tm.h) + '.' + pad2(tm.m), hasTime: m[3] !== undefined };
  }
  return null;
}

// ------------------------------------------------------------------ Menu cepat "/" (I6)
// id = aksi yang SAMA dengan menu Sisipkan/Langit (pemakai yang memetakan); kata = kata kunci pencarian (huruf kecil).
export const SLASH_COMMANDS = [
  { id: 'heading', label: 'Judul', kata: ['judul', 'heading', 'h1'] },
  { id: 'bullet', label: 'Daftar', kata: ['daftar', 'list', 'bullet'] },
  { id: 'numbered', label: 'Nomor', kata: ['nomor', 'angka', 'bernomor'] },
  { id: 'todo', label: 'Kotak centang', kata: ['centang', 'kotak', 'todo', 'ceklis', 'tugas'] },
  { id: 'table', label: 'Tabel', kata: ['tabel', 'table'] },
  { id: 'quote', label: 'Kutipan', kata: ['kutipan', 'quote'] },
  { id: 'date', label: 'Tanggal', kata: ['tanggal', 'tgl', 'date'] },
  { id: 'mood', label: 'Suasana hati', kata: ['suasana', 'hati', 'mood'] },
  { id: 'countdown', label: 'Hitung mundur', kata: ['hitung', 'mundur', 'countdown'] },
  { id: 'sheet', label: 'Lembar kerja', kata: ['lembar', 'kerja', 'sheet', 'excel'] },
];
// Saring perintah menurut ketikan sesudah "/". Kosong = semua. Awalan kata mengalahkan potongan di tengah; urutan daftar dipertahankan dalam tiap peringkat.
export function filterSlash(query, commands = SLASH_COMMANDS) {
  const q = String(query == null ? '' : query).toLowerCase().replace(/\s+/g, '');
  if (!q) return commands.slice();
  const pre = [], mid = [];
  for (const c of commands) {
    const hay = [c.label.toLowerCase().replace(/\s+/g, ''), ...c.kata];
    if (hay.some((w) => w.startsWith(q))) pre.push(c); else if (hay.some((w) => w.includes(q))) mid.push(c);
  }
  return pre.concat(mid);
}

// ------------------------------------------------------------------ Tag cepat (I3)
// Tag sah: diawali huruf, lalu huruf/angka/_/-, 1..MAX_TAG. (#123 dan #fff1 bukan tag; "#1" sering nomor, bukan label.)
export function normalizeTag(s) {
  const v = String(s == null ? '' : s);
  return /^\p{L}[\p{L}\p{N}_-]*$/u.test(v) && v.length <= MAX_TAG ? v : '';
}

// ------------------------------------------------------------------ Pemicu utama
// sebelum: teks dari AWAL BARIS sampai kursor (tanpa baris sebelumnya). opts: { ctx = 'note', now, only? }.
// Urutan prioritas (hanya SATU hasil): checkbox, numbered, bullet, wiki (bila [[ terbuka), calc, remind, tag, slash.
export function detectTrigger(sebelum, opts = {}) {
  const ctx = opts.ctx === undefined ? 'note' : opts.ctx;
  if (ctx !== 'note') return null;
  const full = String(sebelum == null ? '' : sebelum); if (!full || full.includes('\n')) return null;
  // Paragraf sangat panjang: pindai hanya ekor TAIL huruf terakhir (pemicu selalu pendek); indeks hasil tetap relatif ke `sebelum` utuh.
  const off = Math.max(0, full.length - TAIL), b = off ? full.slice(off) : full;
  const only = Array.isArray(opts.only) ? opts.only : null;
  const ok = (k) => !only || only.includes(k);
  const shift = (r) => { if (r && off) { r.start += off; r.end += off; } return r; };
  let m, r;
  if (ok('checkbox') && b === '[] ') return { kind: 'checkbox', start: 0, end: 3, raw: '[] ' };
  if (ok('numbered') && b === '1. ') return { kind: 'numbered', start: 0, end: 3, raw: '1. ' };
  if (ok('bullet') && b === '- ') return { kind: 'bullet', start: 0, end: 2, raw: '- ' }; // Rev 358: hanya `- ` (strip) sebagai SATU-SATUNYA isi baris
  // [[ yang masih terbuka menang atas hitung cepat: judul catatan boleh memuat angka dan "=".
  if (ok('wiki') && (m = /\[\[([^\[\]\n]{0,60})$/.exec(b))) return shift({ kind: 'wiki', start: b.length - m[0].length, end: b.length, query: m[1] });
  if (ok('calc') && (r = detectCalc(b))) return shift(r);
  if (ok('remind') && (m = /(?:^|\s)(!([^!\s][^!]{0,23}))$/.exec(b))) {
    const rm = parseRemind(m[2], opts.now);
    if (rm) return shift({ kind: 'remind', start: b.length - m[1].length, end: b.length, raw: m[1], when: rm.when, label: rm.label, hasTime: rm.hasTime });
  }
  if (ok('tag') && (m = /(?:^|\s)#([^\s#]{1,40})( ?)$/.exec(b))) {
    const tag = normalizeTag(m[1]);
    if (tag) return shift({ kind: 'tag', start: b.length - m[1].length - 1 - m[2].length, end: b.length, tag, complete: m[2] === ' ' });
  }
  if (ok('slash') && (m = /(?:^|\s)\/([A-Za-z]{0,12})$/.exec(b))) {
    const q = m[1]; return shift({ kind: 'slash', start: b.length - q.length - 1, end: b.length, query: q, items: filterSlash(q) });
  }
  return null;
}
