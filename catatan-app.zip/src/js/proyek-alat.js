// Rev 234 / Tahap 7a: alat proyek untuk UI/AI nanti (murni). TIDAK dimuat saat startup: hanya dipakai bila Project Studio dibuka.
import { cleanProject, MAX_PROJECTS, MAX_LINKS } from './proyek.js';
// Proyek baru (belum dimasukkan ke daftar). `genId` dan `now` disuntik agar bisa dites; null bila nama kosong.
export function newProject(name, genId, now = Date.now()) {
  return cleanProject({ id: genId(), name, desc: '', status: 'aktif', at: now, tasks: [], notes: [] });
}
// Tambah ke daftar: false bila penuh atau id sudah ada.
export function addProject(list, p) {
  if (!Array.isArray(list) || !p || list.length >= MAX_PROJECTS || list.some((x) => x.id === p.id)) return false;
  list.push(p); return true;
}
export function removeProject(list, id) {
  const i = Array.isArray(list) ? list.findIndex((x) => x.id === id) : -1;
  if (i < 0) return false; list.splice(i, 1); return true;
}
// Tautkan/lepas tugas atau catatan. kind: 'tasks' | 'notes'. Mengembalikan 'added' | 'removed' | 'full' | 'bad'.
export function toggleProjectLink(p, kind, id) {
  if (!p || (kind !== 'tasks' && kind !== 'notes') || typeof id !== 'string' || !id) return 'bad';
  const a = Array.isArray(p[kind]) ? p[kind] : (p[kind] = []);
  const i = a.indexOf(id);
  if (i >= 0) { a.splice(i, 1); return 'removed'; }
  if (a.length >= MAX_LINKS) return 'full';
  a.push(id); return 'added';
}
// Kemajuan dari tugas yang MASIH ADA: { total, done, pct } (pct bulat 0-100; tanpa tugas = 0).
export function projectProgress(data, p) {
  const tasks = data && Array.isArray(data.tasks) ? data.tasks : [];
  const mine = new Set(p && Array.isArray(p.tasks) ? p.tasks : []);
  let total = 0, done = 0;
  for (const t of tasks) if (t && mine.has(t.id)) { total++; if (t.done === true) done++; }
  return { total, done, pct: total ? Math.round((done / total) * 100) : 0 };
}
