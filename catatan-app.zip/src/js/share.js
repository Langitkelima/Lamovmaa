// Bagikan satu catatan (Rev 19): teks, PDF, atau gambar JPG. Hanya untuk catatan biasa (Catatan Privat tidak punya tombol ini).
// Bagian murni (parser, tata letak, perakit PDF) ada di export.js. Di sini: menggambar ke canvas dan mengirim lewat menu Bagikan Android.
import { h, toast, dlg, tOk, tWarn, tErr } from './ui.js';
import { isNative, nativePlugin } from './native.js';
import { HEX, contrast, contrastRatio } from './logic.js';
import { parseNoteHtml, blocksToText, blocksToMarkdown, layoutDoc, moodGeom, cardGeom, paginate, buildPdf, bytesToB64, b64ToBytes, shareFileName } from './export.js';
import * as G from './gambar.js';
import { exportModel, EXPORT_ALL, sheetById, setSheetsSource } from './lembar-pulau.js';
import { loadEngine, sheetsHaveFx } from './lembar-mesin.js'; // Rev 192b / P2b: ekspor wajib menunggu mesin rumus bila ada lembar berumus
import { imageFS, readImageBlob } from './gambar-app.js';

const PAPER = '#FBFCFE'; // kertas bila catatan tanpa warna (bukan putih murni)
const FONT = 'system-ui, -apple-system, Roboto, "Segoe UI", sans-serif';
const PDF = { width: 1240, pageH: 1754, padX: 110, padTop: 120, padBottom: 130, size: 30, titleSize: 46, sheet: { rows: 20, cols: 8 } }; // A4 pada 150 dpi; sheet = batas tabel lembar kerja (Rev 123)
const JPG = { width: 1080, pageH: 7000, padX: 72, padTop: 84, padBottom: 84, size: 40, titleSize: 62, sheet: { rows: 20, cols: 6 } }; // satu gambar panjang, dipecah tiap 7000 px
const MAX_PDF_PAGES = 60, MAX_JPG_PARTS = 12;
const tick = () => new Promise((r) => setTimeout(r, 25));
const msgOf = (e) => String((e && e.message) || e || 'gagal').slice(0, 140);
export const fontOf = (st, size) => (st.i ? 'italic ' : '') + (st.b ? '700 ' : '400 ') + size + 'px ' + FONT;

// Rev 123 / U7b-2: pulau lembar kerja diekspor dari data.sheets (sumber diisi openShare / editor); lim = batas baris/kolom (TXT/MD penuh, PDF/JPG dipotong).
export function blocksOf(n, lim = EXPORT_ALL, charts = false) { // Rev 161: charts = true hanya untuk PDF/JPG
  const b = parseNoteHtml(n.html || '', new Date(), (id) => exportModel(sheetById(id), lim, charts ? { charts: true } : {}));
  if (b.length || !n.text) return b;
  return String(n.text).split('\n').map((t) => (t.trim() ? { kind: 'p', depth: 0, runs: [{ t, b: false, i: false, s: false, u: false, color: '' }] } : { kind: 'p', depth: 0, blank: true, runs: [] }));
}
export const noteText = (n) => blocksToText(n.title, blocksOf(n));
export const noteMarkdown = (n) => blocksToMarkdown(n.title, blocksOf(n));

export async function loadShareImages(n) {
  const refs = G.parseRefs(n.html || ''); if (!refs.length) return new Map();
  const FS = imageFS(), map = new Map();
  try { for (const ref of refs) if (!map.has(ref.id)) map.set(ref.id, await readImageBlob(FS, ref)); return map; }
  catch (e) { throw new Error('Gambar catatan tidak dapat dimuat untuk dibagikan. ' + msgOf(e)); }
}
function closeShareImages(_map) { /* Blob tidak didekode; bitmap ditutup satu per satu di drawPage. */ }

function themeOf(n) {
  const c = String(n.col || '').toLowerCase(); // aplikasi menyimpan huruf kecil; cadangan yang diedit tangan bisa saja huruf besar
  const bg = HEX.test(c) ? c : PAPER;
  const t = contrast(bg);
  return { bg, ink: t.ink, mut: t.mut };
}
function roundRect(g, x, y, w, hh, r) {
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + hh, r); g.arcTo(x + w, y + hh, x, y + hh, r); g.arcTo(x, y + hh, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}

// Rev E: kartu Suasana hati digambar sebagai gambar (mirip tampilan editor), bukan teks. Warna/bentuk wajah mengikuti CSS Rev D.
const MOOD_MC = ['#ff5d73', '#ff9a4d', '#ffc83d', '#7fd86a', '#25d0a0'];
const MOOD_INK = '#3b2a45';
const MOOD_FACE = [
  { c1: '#ffa3b0', c2: '#ec3a58', ops: [{ t: 's', d: 'M15 27L26 22M49 27L38 22', w: 3.2 }, { t: 'e', x: 23, y: 33, rx: 3.2, ry: 3.8 }, { t: 'e', x: 41, y: 33, rx: 3.2, ry: 3.8 }, { t: 's', d: 'M21 50Q32 38 43 50', w: 3.6 }, { t: 'f', d: 'M47 38q3.4 5 0 8q-3.4-3 0-8z', c: '#8fd8ff' }] },
  { c1: '#ffc99a', c2: '#f4863a', ops: [{ t: 'e', x: 23, y: 30, rx: 3.4, ry: 3.4 }, { t: 'e', x: 41, y: 30, rx: 3.4, ry: 3.4 }, { t: 's', d: 'M23 47Q32 40 41 47', w: 3.6 }] },
  { c1: '#ffeb94', c2: '#f3b52a', ops: [{ t: 'e', x: 23, y: 30, rx: 3.4, ry: 3.4 }, { t: 'e', x: 41, y: 30, rx: 3.4, ry: 3.4 }, { t: 's', d: 'M24 44H40', w: 3.6 }] },
  { c1: '#d2f79a', c2: '#62c654', ops: [{ t: 'e', x: 23, y: 29, rx: 3.4, ry: 3.4 }, { t: 'e', x: 41, y: 29, rx: 3.4, ry: 3.4 }, { t: 's', d: 'M22 40Q32 52 42 40', w: 3.6 }] },
  { c1: '#86f3d3', c2: '#10b58a', ops: [{ t: 's', d: 'M17 32Q23 22 29 32M35 32Q41 22 47 32', w: 3.4 }, { t: 'f', d: 'M20 39Q32 59 44 39Z', c: MOOD_INK }, { t: 'f', d: 'M26 49.5Q32 44 38 49.5Q32 54 26 49.5Z', c: '#ff7d96' }, { t: 'e', x: 13.5, y: 41, rx: 5, ry: 3.2, c: '#ff86a4', a: 0.55 }, { t: 'e', x: 50.5, y: 41, rx: 5, ry: 3.2, c: '#ff86a4', a: 0.55 }, { t: 'f', d: 'M53 5l1.7 4.6L59 11.3l-4.3 1.7L53 17.6l-1.7-4.6L47 11.3l4.3-1.7z', c: '#ffffff', a: 0.92 }] },
];
function mixHex(a, b, t) { // t = bagian warna b (0..1); a dan b berupa #rrggbb
  const pa = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16)), pb = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16));
  return '#' + pa.map((v, i) => Math.round(v * (1 - t) + pb[i] * t).toString(16).padStart(2, '0')).join('');
}
function drawMoodFace(g, cx, cy, r, v, selected) {
  const f = MOOD_FACE[v]; g.save();
  g.translate(cx, cy); g.scale(r / 32, r / 32); g.translate(-32, -32);
  if (!selected) { g.globalAlpha = 0.62; try { g.filter = 'saturate(0.5)'; } catch (_) { /* filter tidak wajib */ } }
  else { g.shadowColor = MOOD_MC[v]; g.shadowBlur = 18; g.shadowOffsetY = 2; }
  const grad = g.createRadialGradient(32 - 0.15 * 64, 32 - 0.22 * 64, 0, 32, 32, 0.95 * 64); grad.addColorStop(0, f.c1); grad.addColorStop(1, f.c2);
  g.beginPath(); g.arc(32, 32, 30, 0, Math.PI * 2); g.fillStyle = grad; g.fill();
  g.shadowColor = 'transparent'; g.shadowBlur = 0; g.shadowOffsetY = 0;
  g.save(); g.globalAlpha *= 0.3; g.fillStyle = '#fff'; g.beginPath(); g.ellipse(23, 15, 13, 6.5, -20 * Math.PI / 180, 0, Math.PI * 2); g.fill(); g.restore();
  const base = g.globalAlpha;
  for (const op of f.ops) {
    g.globalAlpha = base * (op.a == null ? 1 : op.a);
    if (op.t === 's') { g.strokeStyle = MOOD_INK; g.lineWidth = op.w; g.lineCap = 'round'; g.lineJoin = 'round'; g.stroke(new Path2D(op.d)); }
    else if (op.t === 'f') { g.fillStyle = op.c; g.fill(new Path2D(op.d)); }
    else { g.fillStyle = op.c || MOOD_INK; g.beginPath(); g.ellipse(op.x, op.y, op.rx, op.ry, 0, 0, Math.PI * 2); g.fill(); }
  }
  g.restore();
}
function drawMoodCard(g, l, y, th, o) {
  const gm = moodGeom(o.size, l.msize, o.width - o.padX * 2), mc = MOOD_MC[l.v], x = l.x, w = l.w, h = l.lh;
  g.save();
  const grad = g.createLinearGradient(x, y, x + w * 0.6, y + h); grad.addColorStop(0, mixHex(th.bg, mc, 0.26)); grad.addColorStop(1, mixHex(th.bg, mc, 0.07));
  roundRect(g, x, y, w, h, gm.s * 0.72); g.fillStyle = grad; g.fill();
  g.lineWidth = Math.max(2, gm.s * 0.05); g.strokeStyle = mixHex(th.bg, mc, 0.55); g.stroke();
  const tx = x + gm.pad;
  g.textBaseline = 'alphabetic'; g.textAlign = 'left';
  g.font = '700 ' + gm.labelS + 'px ' + FONT; g.fillStyle = th.mut;
  try { g.letterSpacing = Math.round(gm.labelS * 0.18) + 'px'; } catch (_) { /* tidak wajib */ }
  g.fillText('SUASANA HATI', tx, y + gm.labelY);
  try { g.letterSpacing = '0px'; } catch (_) { /* tidak wajib */ }
  g.font = '800 ' + gm.titleS + 'px ' + FONT; g.fillStyle = mixHex(mc, th.ink, 0.38);
  g.fillText(l.label, tx, y + gm.titleY);
  const cy = y + gm.faceCy, left = x + gm.pad + gm.R * 1.25, right = x + w - gm.pad - gm.R * 1.25;
  const tg = g.createLinearGradient(left, 0, right, 0); MOOD_MC.forEach((c, i) => tg.addColorStop(i / 4, c));
  g.globalAlpha = 0.4; g.fillStyle = tg; roundRect(g, left, cy - gm.s * 0.05, right - left, gm.s * 0.1, gm.s * 0.05); g.fill(); g.globalAlpha = 1;
  const step = (right - left) / 4;
  for (let i = 0; i < 5; i++) if (i !== l.v) drawMoodFace(g, left + step * i, cy, gm.R * 0.8, i, false);
  drawMoodFace(g, left + step * l.v, cy, gm.R * 1.2, l.v, true);
  g.restore();
}
// Rev 89: kartu Tanggal / Waktu / Hitung mundur digambar seperti kartu Suasana hati (gradasi lembut, garis tepi, ikon bulat).
const CARD_COL = { date: ['#4F8CF5', '#6E78F2'], time: ['#8B6FE3', '#C26AD9'], cd: ['#FF8A5C', '#EE4F85'], today: ['#2DB88C', '#2A9FD0'], past: ['#8C95AB', '#6F7890'] };
function cardFrame(g, x, y, w, h, r, a, b, th, dashed) {
  const grad = g.createLinearGradient(x, y, x + w * 0.7, y + h);
  grad.addColorStop(0, mixHex(th.bg, a, 0.22)); grad.addColorStop(1, mixHex(th.bg, b, 0.07));
  roundRect(g, x, y, w, h, r); g.fillStyle = grad; g.fill();
  g.lineWidth = Math.max(2, r * 0.07); g.strokeStyle = mixHex(th.bg, a, 0.5);
  if (dashed) g.setLineDash([r * 0.3, r * 0.22]);
  g.stroke(); g.setLineDash([]);
}
function iconBox(g, x, y, sz, a, b, draw) {
  const grad = g.createLinearGradient(x, y, x + sz, y + sz); grad.addColorStop(0, a); grad.addColorStop(1, b);
  roundRect(g, x, y, sz, sz, sz * 0.32); g.fillStyle = grad; g.fill();
  g.save(); g.translate(x + sz / 2, y + sz / 2); g.scale(sz * 0.56 / 24, sz * 0.56 / 24); g.translate(-12, -12);
  g.strokeStyle = '#fff'; g.lineWidth = 1.9; g.lineCap = 'round'; g.lineJoin = 'round'; draw(g); g.restore();
}
function drawCard(g, l, y, th, o) {
  const c = l.card, inner = o.width - o.padX * 2, gm = cardGeom(o.size, c, inner), x = l.x, h = l.lh;
  g.save(); g.textBaseline = 'alphabetic'; g.textAlign = 'left';
  if (c.type === 'cd') {
    const col = CARD_COL[c.state === 'today' ? 'today' : c.state === 'past' ? 'past' : 'cd'], w = gm.w;
    cardFrame(g, x, y, w, h, gm.s * 0.8, col[0], col[1], th, c.state === 'past');
    // lencana kalender (bulan berwarna di atas, tanggal di bawah)
    const bx = x + gm.pad, by = y + (h - gm.bh) / 2, br = gm.s * 0.36;
    g.save(); roundRect(g, bx, by, gm.bw, gm.bh, br); g.clip();
    g.fillStyle = mixHex(th.bg, th.ink, 0.06); g.fillRect(bx, by, gm.bw, gm.bh);
    const mh = gm.bh * 0.3, mg = g.createLinearGradient(bx, by, bx + gm.bw, by + mh); mg.addColorStop(0, col[0]); mg.addColorStop(1, col[1]);
    g.fillStyle = mg; g.fillRect(bx, by, gm.bw, mh);
    g.fillStyle = '#fff'; g.textAlign = 'center'; g.font = '800 ' + gm.s * 0.27 + 'px ' + FONT;
    try { g.letterSpacing = Math.round(gm.s * 0.04) + 'px'; } catch (_) { /* tidak wajib */ }
    g.fillText(c.month, bx + gm.bw / 2, by + mh * 0.7);
    try { g.letterSpacing = '0px'; } catch (_) { /* tidak wajib */ }
    g.fillStyle = th.ink; g.font = '800 ' + gm.s * 0.95 + 'px ' + FONT;
    g.fillText(c.day, bx + gm.bw / 2, by + mh + (gm.bh - mh) * 0.5 + gm.s * 0.33);
    g.restore();
    g.strokeStyle = mixHex(th.bg, col[0], 0.5); g.lineWidth = Math.max(2, gm.s * 0.04); roundRect(g, bx, by, gm.bw, gm.bh, br); g.stroke();
    // teks kanan: judul kecil kapital, sisa hari besar, tanggal
    const tx = bx + gm.bw + gm.pad, maxW = x + w - gm.pad - tx;
    let y0 = y + (h - (gm.labelS + gm.remS * 1.15 + gm.dateS * 1.25)) / 2;
    const fit = (txt, font, max) => { g.font = font; if (g.measureText(txt).width <= max) return txt; let t = txt; while (t.length > 1 && g.measureText(t + '…').width > max) t = t.slice(0, -1); return t + '…'; };
    g.textAlign = 'left'; g.fillStyle = mixHex(col[0], th.ink, 0.35);
    try { g.letterSpacing = Math.round(gm.labelS * 0.14) + 'px'; } catch (_) { /* tidak wajib */ }
    g.fillText(fit((c.title || 'Apa yang Anda nantikan?').toUpperCase(), '800 ' + gm.labelS + 'px ' + FONT, maxW), tx, y0 + gm.labelS);
    try { g.letterSpacing = '0px'; } catch (_) { /* tidak wajib */ }
    g.fillStyle = c.state === 'past' ? th.mut : mixHex(col[0], th.ink, 0.12);
    g.fillText(fit(c.remain, '800 ' + gm.remS + 'px ' + FONT, maxW), tx, y0 + gm.labelS + gm.remS * 1.15);
    g.fillStyle = th.mut;
    g.fillText(fit(c.dateLine, '600 ' + gm.dateS + 'px ' + FONT, maxW), tx, y0 + gm.labelS + gm.remS * 1.15 + gm.dateS * 1.3);
    g.restore(); return;
  }
  const col = CARD_COL[c.type], isTime = c.type === 'time';
  const label = isTime ? 'WAKTU' : 'TANGGAL';
  g.font = '800 ' + gm.valS + 'px ' + FONT; const vw = g.measureText(c.value).width;
  const w = Math.min(inner, gm.pad * 2 + gm.ic + gm.pad * 0.9 + Math.max(vw, gm.labelS * 7) + gm.pad * 0.6);
  cardFrame(g, x, y, w, h, gm.s * 0.62, col[0], col[1], th, false);
  const ix = x + gm.pad, iy = y + (h - gm.ic) / 2;
  iconBox(g, ix, iy, gm.ic, col[0], col[1], isTime
    ? (q) => { q.beginPath(); q.arc(12, 12, 8.5, 0, Math.PI * 2); q.stroke(); q.beginPath(); q.moveTo(12, 7); q.lineTo(12, 12); q.lineTo(15.5, 14); q.stroke(); }
    : (q) => { roundRect(q, 4, 5.5, 16, 15, 2.5); q.stroke(); q.beginPath(); q.moveTo(8, 3.5); q.lineTo(8, 7.5); q.moveTo(16, 3.5); q.lineTo(16, 7.5); q.moveTo(4, 10); q.lineTo(20, 10); q.moveTo(8, 14); q.lineTo(10, 14); q.moveTo(14, 14); q.lineTo(16, 14); q.moveTo(8, 17); q.lineTo(10, 17); q.stroke(); });
  const tx = ix + gm.ic + gm.pad * 0.9, blockH = gm.labelS + gm.valS * 1.25, ty = y + (h - blockH) / 2;
  g.fillStyle = mixHex(col[0], th.ink, 0.35);
  try { g.letterSpacing = Math.round(gm.labelS * 0.16) + 'px'; } catch (_) { /* tidak wajib */ }
  g.font = '800 ' + gm.labelS + 'px ' + FONT; g.fillText(label, tx, ty + gm.labelS);
  try { g.letterSpacing = '0px'; } catch (_) { /* tidak wajib */ }
  g.fillStyle = th.ink; g.font = '800 ' + gm.valS + 'px ' + FONT; g.fillText(c.value, tx, ty + gm.labelS + gm.valS * 1.2);
  g.restore();
}
// Rev 161 / U10c-3b: diagram lembar kerja (SVG putih berdiri sendiri) digambar lewat Image + data URL. Gagal memuat = kotak "[diagram]" (ekspor tidak dibatalkan).
const loadSvgImage = (svg) => new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('diagram gagal dimuat')); im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); });
async function drawChart(g, l, y, th, o) {
  try {
    const im = await loadSvgImage(l.svg);
    g.save(); g.fillStyle = '#FFFFFF'; g.fillRect(l.x, y, l.w, l.h); g.restore();
    g.drawImage(im, l.x, y, l.w, l.h);
    g.save(); g.globalAlpha = 0.35; g.strokeStyle = th.mut; g.lineWidth = Math.max(1, o.size / 28); g.strokeRect(l.x, y, l.w, l.h); g.restore();
  } catch (_) {
    g.save(); g.globalAlpha = 0.5; g.strokeStyle = th.mut; g.lineWidth = 2; g.strokeRect(l.x, y, l.w, l.h);
    g.fillStyle = th.mut; g.font = fontOf({}, Math.max(18, o.size * 0.75)); g.textAlign = 'center';
    g.fillText('[diagram]', l.x + l.w / 2, y + l.h / 2 + o.size * 0.25); g.textAlign = 'left'; g.restore();
  }
}

export async function drawPage(g, page, o, th, H, num, total, images = null) {
  g.fillStyle = th.bg; g.fillRect(0, 0, o.width, H);
  g.textBaseline = 'alphabetic';
  const drawRuns = (segs, x0, base, force) => { // Rev 268: force = warna teks eksplisit (sel berisian warna pilihan; kontras sudah dijamin terhadap isian, bukan terhadap kertas)
    for (const s of segs) {
      g.font = fontOf(s, s.size);
      // Warna teks pilihan pengguna dipakai selama terbaca di atas latar catatan; kalau tidak, pakai warna teks biasa.
      const col = force && HEX.test(force) ? force : s.color && HEX.test(s.color) && contrastRatio(s.color, th.bg) >= 3 ? s.color : th.ink;
      g.fillStyle = col; const x = x0 + s.x; g.fillText(s.t, x, base);
      if (s.s || s.u) { const w = g.measureText(s.t).width, t = Math.max(2, s.size / 16); if (s.s) g.fillRect(x, base - s.size * 0.3, w, t); if (s.u) g.fillRect(x, base + s.size * 0.1, w, t); }
    }
  };
  const drawLine = async (l, y) => {
    if (l.kind === 'float') {
      await drawLine(l.img, y);
      let yy = y;
      for (const s of l.lines) { await drawLine(s, yy); yy += s.lh; }
    } else if (l.kind === 'chart') { await drawChart(g, l, y, th, o);
    } else if (l.kind === 'mood') { drawMoodCard(g, l, y, th, o);
    } else if (l.kind === 'card') { drawCard(g, l, y, th, o);
    } else if (l.kind === 'rule') { g.globalAlpha = 0.35; g.fillStyle = th.mut; g.fillRect(l.x, y + l.lh / 2 - 1.5, l.w, 3); g.globalAlpha = 1; }
    else if (l.kind === 'tableRow') {
      // Setiap baris tabel adalah satu unit paginasi; kolom proporsional dan teks sudah dibungkus oleh export.js.
      for (const c of l.cells) {
        const x = l.x + c.x;
        if (c.bg && HEX.test(c.bg)) { g.fillStyle = c.bg; g.fillRect(x, y, c.w, l.lh); } // Rev 268 / V2b: isian warna pilihan
        else if (c.header) { g.globalAlpha = 0.075; g.fillStyle = th.ink; g.fillRect(x, y, c.w, l.lh); g.globalAlpha = 1; }
        c.lines.forEach((segs, i) => {
          const base = y + c.padY + i * l.lineH + o.size * 0.8;
          // Rev 76: rata teks sel (data-a): kiri = bawaan; tengah/kanan menggeser baris sesuai lebar teks
          let off = 0;
          if (c.a && segs.length) { const last = segs[segs.length - 1]; g.font = fontOf(last, last.size); const lw = last.x + g.measureText(String(last.t).replace(/\s+$/, '')).width, avail = c.w - c.padX * 2; off = c.a === 'c' ? Math.max(0, (avail - lw) / 2) : Math.max(0, avail - lw); }
          drawRuns(segs, x + c.padX + off, base, c.bg ? c.fg : undefined);
        });
      }
      g.save(); g.globalAlpha = 0.55; g.strokeStyle = th.mut; g.lineWidth = Math.max(1, o.size / 28);
      if (l.cells.some((c) => c.vu || c.vd)) { // Rev 155 / U10b-4: gabungan tegak = tanpa garis atas (vu) / bawah (vd) pada sel itu
        const seg = (x1, y1, x2, y2) => { g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); };
        seg(l.x, y, l.x, y + l.lh); seg(l.x + l.w, y, l.x + l.w, y + l.lh);
        for (const c of l.cells) { const x0 = l.x + c.x; if (!c.vu) seg(x0, y, x0 + c.w, y); if (!c.vd) seg(x0, y + l.lh, x0 + c.w, y + l.lh); }
      } else g.strokeRect(l.x, y, l.w, l.lh);
      let x = l.x;
      for (const c of l.cells.slice(0, -1)) { x += c.w; g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + l.lh); g.stroke(); }
      g.restore();
    } else if (l.kind === 'image') {
      // Titik sambung G3: bila share.js nanti memuat bitmap berdasar ID, gambar asli digambar di kotak ini.
      // Di Rev 28 belum ada berkas gambar di catatan; placeholder menjaga tata letak/paginasi tetap teruji.
      const source = images && (typeof images.get === 'function' ? images.get(l.id) : images[l.id]);
      if (source) {
        if (typeof createImageBitmap !== 'function') throw new Error('Perangkat belum mendukung gambar untuk PDF/JPG.');
        const img = await createImageBitmap(source); try { g.drawImage(img, l.x, y, l.w, l.h); } finally { try { img.close(); } catch (_) {} }
      } else {
        g.save(); g.globalAlpha = 0.5; g.strokeStyle = th.mut; g.lineWidth = 2; g.strokeRect(l.x, y, l.w, l.h);
        g.fillStyle = th.mut; g.font = fontOf({}, Math.max(18, o.size * 0.75)); g.textAlign = 'center';
        g.fillText('[gambar]', l.x + l.w / 2, y + l.h / 2 + o.size * 0.25); g.textAlign = 'left'; g.restore();
      }
    } else if (l.kind === 'text') {
      const base = y + (l.lh - l.size) / 2 + l.size * 0.8;
      const m = l.mark;
      if (m) {
        g.fillStyle = th.ink; g.strokeStyle = th.ink;
        if (m.type === 'quote') { g.strokeStyle = th.ink; g.lineWidth = Math.max(2, l.size * 0.16); g.lineCap = 'round'; g.beginPath(); g.moveTo(m.x + l.size * 0.12, y + 2); g.lineTo(m.x + l.size * 0.12, y + l.lh - 2); g.stroke(); }
        else if (m.type === 'bullet') { g.beginPath(); g.arc(m.x + l.size * 0.3, base - l.size * 0.3, l.size * 0.15, 0, Math.PI * 2); g.fill(); }
        else if (m.type === 'fold') { // Rev 110 / U6b: panah bagian lipat (selalu terbuka di ekspor) = chevron ke bawah
          const fx = m.x + l.size * 0.32, fy = base - l.size * 0.34, fw = l.size * 0.2;
          g.lineWidth = Math.max(2.5, l.size * 0.1); g.lineCap = 'round'; g.lineJoin = 'round';
          g.beginPath(); g.moveTo(fx - fw, fy - fw * 0.5); g.lineTo(fx, fy + fw * 0.6); g.lineTo(fx + fw, fy - fw * 0.5); g.stroke();
        }
        else if (m.type === 'num') { g.font = fontOf({}, l.size); g.fillText(m.label, m.x, base); }
        else {
          const bs = l.size * 0.72, bx = m.x, by = y + (l.lh - bs) / 2;
          g.lineWidth = Math.max(2, l.size * 0.07);
          roundRect(g, bx, by, bs, bs, bs * 0.22);
          if (m.checked) {
            g.fill(); g.strokeStyle = th.bg; g.lineWidth = Math.max(2.5, l.size * 0.09); g.lineCap = 'round'; g.lineJoin = 'round';
            g.beginPath(); g.moveTo(bx + bs * 0.22, by + bs * 0.52); g.lineTo(bx + bs * 0.43, by + bs * 0.72); g.lineTo(bx + bs * 0.78, by + bs * 0.3); g.stroke();
          } else g.stroke();
        }
      }
      drawRuns(l.segs, 0, base);
    }
  };
  let y = o.padTop;
  for (const l of page.lines) { await drawLine(l, y); y += l.lh; }
  if (total > 1) { g.font = fontOf({}, Math.round(o.size * 0.7)); g.fillStyle = th.mut; g.textAlign = 'center'; g.fillText(num + ' / ' + total, o.width / 2, H - Math.round(o.padBottom * 0.35)); g.textAlign = 'left'; }
}
// Menghasilkan halaman JPEG: [{ jpeg: Uint8Array, w, h }]. fixedH = true -> tinggi halaman tetap (PDF); false -> dipangkas sesuai isi (JPG).
export async function renderPages(n, o, fixedH, maxPages, isAlive, images = null) {
  const mc = document.createElement('canvas').getContext('2d');
  if (!mc) throw new Error('Canvas tidak tersedia');
  const measure = (t, st) => { mc.font = fontOf(st, st.size); return mc.measureText(t).width; };
  const lines = layoutDoc({ title: n.title, blocks: blocksOf(n, o.sheet, true) }, { ...o, measure });
  const pages = paginate(lines, o);
  if (pages.length > maxPages) throw new Error('Catatan terlalu panjang (' + pages.length + ' halaman)');
  const th = themeOf(n), out = [];
  for (let i = 0; i < pages.length; i++) {
    if (!isAlive()) return out;
    const H = fixedH ? o.pageH : Math.min(o.pageH, Math.max(560, Math.ceil(pages[i].used + o.padTop + o.padBottom)));
    const cv = document.createElement('canvas'); cv.width = o.width; cv.height = H;
    const g = cv.getContext('2d'); if (!g) throw new Error('Canvas tidak tersedia');
    await drawPage(g, pages[i], o, th, H, i + 1, pages.length, images);
    const url = cv.toDataURL('image/jpeg', 0.9);
    cv.width = 0; cv.height = 0; // lepas memori canvas
    const k = url.indexOf('base64,');
    if (!url.startsWith('data:image/jpeg') || k < 0) throw new Error('Gambar gagal dibuat (catatan mungkin terlalu panjang)');
    out.push({ jpeg: b64ToBytes(url.slice(k + 7)), w: o.width, h: H });
    await tick();
  }
  return out;
}

const SAVE_DIR = 'NotesKelimaa/Ekspor'; // di Dokumen (folder induk yang sama dengan cadangan otomatis)
const isText = (f) => typeof f.text === 'string';
const browserDownload = (files) => files.forEach((f, i) => setTimeout(() => {
  const url = URL.createObjectURL(new Blob([isText(f) ? f.text : f.bytes], { type: f.mime }));
  const a = h('a', { href: url, download: f.name }); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}, i * 300));
// Bagikan lewat menu Bagikan Android: berkas dititipkan ke CACHE lalu dikirim.
export async function sendFiles(files, title) {
  if (!isNative()) { browserDownload(files); return; }
  const FS = nativePlugin('Filesystem'), SH = nativePlugin('Share'); const uris = [], names = [];
  for (const f of files) {
    const r = await FS.writeFile(isText(f) ? { path: f.name, data: f.text, directory: 'CACHE', encoding: 'utf8' } : { path: f.name, data: bytesToB64(f.bytes), directory: 'CACHE' }); // tanpa encoding = base64
    uris.push(r.uri); names.push(f.name);
  }
  try { await SH.share({ title: title || 'Catatan', files: uris, dialogTitle: 'Bagikan catatan' }); }
  finally { setTimeout(() => { for (const nm of names) FS.deleteFile({ path: nm, directory: 'CACHE' }).catch(() => {}); }, 120000); }
}
// Simpan ke perangkat (Rev 59): langsung ke Dokumen/NotesKelimaa/Ekspor, tanpa memilih aplikasi tujuan. Jalur tulisnya sama dengan cadangan otomatis.
export async function saveFiles(files) { // Rev 141: diekspor agar lembar kerja (Unduh CSV/TSV) memakai jalur simpan yang sama
  if (!isNative()) { browserDownload(files); return 'Diunduh oleh peramban'; }
  const FS = nativePlugin('Filesystem');
  try { if (typeof FS.checkPermissions === 'function') { const p = await FS.checkPermissions(); if (p && p.publicStorage && p.publicStorage !== 'granted' && typeof FS.requestPermissions === 'function') await FS.requestPermissions(); } } catch (_) { /* HP baru biasanya tidak perlu; lanjut menulis */ }
  for (const f of files) await FS.writeFile(isText(f)
    ? { path: SAVE_DIR + '/' + f.name, data: f.text, directory: 'DOCUMENTS', encoding: 'utf8', recursive: true }
    : { path: SAVE_DIR + '/' + f.name, data: bytesToB64(f.bytes), directory: 'DOCUMENTS', recursive: true });
  return 'Dokumen/' + SAVE_DIR;
}
// Rev 403 / K4: kartu bagikan. Memakai jembatan native (KelimaaNative) bila ada; APK lama tanpa jembatan jatuh ke jalur lama (Dokumen / menu Bagikan).
const kb = (m) => { for (const N of [globalThis.AndroidAPI, globalThis.KelimaaNative]) if (N && typeof N[m] === 'function') return N; return null; };
export const bisaGaleri = () => isNative() && !!kb('saveImageToGallery');
export const bisaWhatsApp = () => isNative() && !!kb('sendImageToWhatsApp');
export async function simpanGaleri(f) { // -> { where, galeri, alasan }; galeri=false berarti disimpan ke Dokumen (jalur lama)
  let alasan = '';
  if (bisaGaleri()) {
    try { alasan = String(kb('saveImageToGallery').saveImageToGallery(bytesToB64(f.bytes), f.name)); } catch (e) { console.error('simpan galeri gagal:', e); alasan = 'error'; }
    if (alasan === 'ok') return { where: 'galeri, album NotesKelimaa', galeri: true, alasan: '' };
  }
  return { where: await saveFiles([f]), galeri: false, alasan };
}
export async function kirimWhatsApp(f) {
  const N = isNative() ? kb('sendImageToWhatsApp') : null;
  if (!N) throw new Error('Kirim langsung ke WhatsApp perlu aplikasi versi terbaru. Pakai tombol Bagikan dulu.');
  const FS = nativePlugin('Filesystem'), w = await FS.writeFile({ path: f.name, data: bytesToB64(f.bytes), directory: 'CACHE' });
  let r = 'error'; try { r = String(N.sendImageToWhatsApp(w.uri)); } catch (e) { console.error('kirim WhatsApp gagal:', e); }
  setTimeout(() => { FS.deleteFile({ path: f.name, directory: 'CACHE' }).catch(() => {}); }, 600000); // WhatsApp menyalin saat kirim; berkas sementara dibersihkan
  if (r !== 'ok') throw new Error(r === 'tidak_ada' ? 'WhatsApp belum terpasang di HP ini.' : 'WhatsApp tidak bisa dibuka. Coba tombol Bagikan.');
}
async function sendText(n) {
  if (/data-sheet/.test(n.html || '')) await loadEngine().catch(() => {}); // Rev 192b: hasil rumus ikut teks (mesin dimuat bila catatan memuat lembar kerja)
  const text = noteText(n), title = n.title || 'Catatan';
  if (isNative()) { await nativePlugin('Share').share({ title, text, dialogTitle: 'Bagikan catatan' }); return; }
  if (navigator.share) { await navigator.share({ title, text }); return; }
  await navigator.clipboard.writeText(text); tOk('Teks catatan disalin.');
}
async function copyText(n) {
  if (/data-sheet/.test(n.html || '')) await loadEngine().catch(() => {}); // Rev 192b
  const text = noteText(n);
  try { await navigator.clipboard.writeText(text); }
  catch (_) { const ta = h('textarea', { style: 'position:fixed;opacity:0;left:-999px' }); ta.value = text; document.body.append(ta); ta.select(); try { document.execCommand('copy'); } finally { ta.remove(); } }
  tOk('Teks catatan disalin.');
}

let lastMode = 'share'; // 'share' = Bagikan ke aplikasi lain, 'save' = Simpan ke perangkat (diingat selama aplikasi terbuka)
// Tiap format (txt, md, pdf, jpg) menghasilkan berkas: { name, mime, text | bytes }.
async function makeFiles(fmt, n, now, alive) {
  if (fmt === 'txt') return [{ name: shareFileName(n.title, 'txt', now), mime: 'text/plain', text: noteText(n) }];
  if (fmt === 'md') return [{ name: shareFileName(n.title, 'md', now), mime: 'text/markdown', text: noteMarkdown(n) }];
  const images = await loadShareImages(n);
  try {
    if (fmt === 'pdf') {
      const pages = await renderPages(n, PDF, true, MAX_PDF_PAGES, alive, images); if (!alive()) return null;
      return [{ name: shareFileName(n.title, 'pdf', now), mime: 'application/pdf', bytes: buildPdf(pages, { title: n.title || 'Catatan' }) }];
    }
    const pages = await renderPages(n, JPG, false, MAX_JPG_PARTS, alive, images); if (!alive()) return null;
    return pages.map((p, i) => ({ name: shareFileName(n.title, 'jpg', now, pages.length > 1 ? i + 1 : 0), mime: 'image/jpeg', bytes: p.jpeg }));
  } finally { closeShareImages(images); }
}

export function openShare(ctx, n) {
  setSheetsSource(() => ctx.data.sheets); // Rev 123: bagikan dari daftar (editor belum dibuka) tetap tahu isi lembar kerja
  if (!(n.title || n.text || n.html)) { tWarn('Catatan masih kosong.'); return; }
  let busy = false, mode = lastMode;
  const ov = h('div', { class: 'ov pickov shareov', onclick: (e) => { if (e.target === ov && !busy) ov.remove(); } });
  const hint = () => (mode === 'save' ? 'Berkas disimpan di Dokumen/' + SAVE_DIR + '.' : 'Pilih bentuk berkas, lalu pilih aplikasi tujuannya.');
  const info = h('p', { class: 'sub' }, hint());
  const alive = () => ov.isConnected;
  const lock = (on) => ov.querySelectorAll('button').forEach((b) => { b.disabled = on; });
  const run = async (label, fmt) => {
    if (busy) return; busy = true; info.textContent = 'Membuat ' + label + '...'; lock(true);
    const now = new Date();
    try {
      if (sheetsHaveFx(ctx.data.sheets)) await loadEngine(); // Rev 192b: hasil rumus di ekspor harus lengkap (gagal muat = ekspor gagal, tidak diam-diam kosong)
      const files = await makeFiles(fmt, n, now, alive); if (!files || !alive()) return;
      if (mode === 'save') {
        // Nama berkas diberi jam-menit agar ekspor kedua di hari yang sama tidak menimpa yang pertama.
        const hm = String(now.getHours()).padStart(2, '0') + String(now.getMinutes()).padStart(2, '0');
        for (const f of files) f.name = f.name.replace(/-(\d{8})(-\d+)?\.(\w+)$/, (m, date, part, ext) => '-' + date + '-' + hm + (part || '') + '.' + ext);
        const where = await saveFiles(files);
        ov.remove(); toast(files.length > 1 ? files.length + ' berkas disimpan di ' + where : 'Tersimpan di ' + where + '/' + files[0].name);
      } else { await sendFiles(files, n.title); if (alive()) ov.remove(); }
    } catch (e) {
      const m = msgOf(e);
      if (/cancel/i.test(m)) { busy = false; if (alive()) { info.textContent = hint(); lock(false); } return; }
      console.error('ekspor gagal:', e); if (alive()) ov.remove();
      if (fmt === 'txt' || fmt === 'md') toast('Gagal: ' + m);
      else dlg({ title: 'Gagal membuat ' + label, msg: m + '. Mau dibagikan sebagai teks saja?', yes: 'Bagikan teks', ok: () => sendText(n).catch((x) => { if (!/cancel/i.test(msgOf(x))) toast('Gagal membagikan: ' + msgOf(x)); }) });
    }
  };
  const opt = (label, sub, fmt) => h('button', { type: 'button', class: 'shr', onclick: () => run(label, fmt) }, h('b', {}, label), h('small', {}, sub));
  const seg = h('div', { class: 'seg shrseg', role: 'tablist' });
  const paintSeg = () => seg.querySelectorAll('button').forEach((b) => { b.classList.toggle('on', b.dataset.m === mode); b.setAttribute('aria-selected', b.dataset.m === mode ? 'true' : 'false'); });
  for (const [m, t] of [['share', 'Bagikan'], ['save', 'Simpan ke perangkat']]) seg.append(h('button', { type: 'button', role: 'tab', 'data-m': m, onclick: () => { if (busy) return; mode = lastMode = m; info.textContent = hint(); paintSeg(); } }, t));
  paintSeg();
  ov.append(h('div', { class: 'sheet', role: 'dialog', 'aria-label': 'Bagikan catatan' },
    h('h3', {}, 'Bagikan catatan'), seg, info,
    opt('PDF', 'Dokumen siap cetak dan kirim, tampilan sama seperti catatan. Teksnya tidak bisa disalin.', 'pdf'),
    opt('Gambar JPG', 'Tampilan catatan sebagai gambar. Catatan panjang dipecah jadi beberapa gambar.', 'jpg'),
    h('button', { type: 'button', class: 'shr', onclick: () => { if (busy) return; ov.remove(); import('./kartu-ui.js').then((m) => m.bukaKartu(ctx, n)).catch(() => tErr('Gambar kartu gagal dibuka.')); } }, h('b', {}, 'Gambar kartu'), h('small', {}, 'Satu gambar berwarna yang rapi, enak dikirim lewat chat. Catatan panjang dipotong.')),
    opt('Teks (.txt)', 'Judul dan isi sebagai teks biasa. Bisa dibuka di aplikasi mana pun.', 'txt'),
    opt('Markdown (.md)', 'Teks dengan tanda format (tebal, daftar, centang). Cocok untuk Notion, Obsidian, dan sejenisnya.', 'md'),
    h('button', { type: 'button', class: 'shr', onclick: () => { if (busy) return; copyText(n).then(() => { if (alive()) ov.remove(); }).catch((e) => toast('Gagal menyalin: ' + msgOf(e))); } }, h('b', {}, 'Salin teks'), h('small', {}, 'Salin ke papan klip untuk ditempel di aplikasi lain.')),
    h('button', { type: 'button', class: 'btn line', onclick: () => { if (!busy) ov.remove(); } }, 'Batal')));
  document.body.append(ov);
}
