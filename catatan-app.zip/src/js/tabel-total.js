// Rev 99 / U4d: baris Total tabel (DOM). Mesin angka ada di tabel-hitung.js (murni).
// Bentuk tersimpan: <tr class="tt"> di akhir tabel; tiap sel <td contenteditable="false" data-f="sum|avg|cnt|min|max"> (kosong bila kolom tanpa total).
// Teks sel (mis. "Jumlah: 1.250") SELALU dihitung ulang oleh refreshTotals (juga di sanitize), jadi yang dipercaya hanya data-f.
import { columnTotal, isTotalFunc, TOTAL_FUNCS } from './tabel-hitung.js';

export const isTotalRow = (row) => !!row && row.classList && row.classList.contains('tt');
// Baris selain baris Total (baris data + baris header).
export const dataRowsOf = (table) => [...table.rows].filter((r) => !isTotalRow(r));
export const totalRowOf = (table) => [...table.rows].find(isTotalRow) || null;
export const totalLabel = (fn) => (TOTAL_FUNCS.find((f) => f.id === fn) || { label: '' }).label;

const colCount = (table) => dataRowsOf(table).reduce((m, r) => Math.max(m, r.cells.length), 0);

// Teks sel yang ikut dihitung di kolom `c`: hanya TD pada baris non-header (baris header = baris pertama bila semuanya TH; sel TH kolom header dilewati).
export function columnCells(table, c) {
  const rows = dataRowsOf(table);
  const first = rows[0];
  const headRow = !!first && first.cells.length > 0 && [...first.cells].every((x) => x.tagName === 'TH');
  const out = [];
  rows.forEach((r, i) => {
    if (headRow && i === 0) return;
    const cell = r.cells[c];
    if (cell && cell.tagName === 'TD') out.push(cell.textContent || '');
  });
  return out;
}

export function totalFuncOf(table, c) {
  const tt = totalRowOf(table);
  const cell = tt && tt.cells[c];
  const f = cell ? cell.getAttribute('data-f') : '';
  return isTotalFunc(f) ? f : '';
}

// Menyusun ulang baris Total: tepat satu, paling akhir, jumlah sel = jumlah kolom, sel hanya TD non-editable dengan data-f valid dan nilai terhitung.
// Tanpa satu pun data-f valid, baris Total dibuang (tabel kembali seperti semula). Mengembalikan true bila baris Total masih ada.
export function refreshTotals(table) {
  const all = [...table.querySelectorAll('tr.tt')];
  if (!all.length) return false;
  const tt = all[0];
  all.slice(1).forEach((r) => r.remove());
  const cols = colCount(table);
  const old = [...tt.cells].map((x) => ({ f: x.getAttribute('data-f'), a: x.getAttribute('data-a') }));
  const fns = Array.from({ length: cols }, (_, c) => (old[c] && isTotalFunc(old[c].f) ? old[c].f : ''));
  if (!cols || !fns.some(Boolean)) { tt.remove(); return false; }
  const body = table.tBodies[table.tBodies.length - 1] || tt.parentElement;
  const cells = fns.map((f, c) => {
    const td = document.createElement('td');
    td.setAttribute('contenteditable', 'false');
    if (old[c] && /^[cr]$/.test(old[c].a || '')) td.setAttribute('data-a', old[c].a);
    if (f) { td.setAttribute('data-f', f); td.textContent = totalLabel(f) + ': ' + columnTotal(columnCells(table, c), f).text; }
    return td;
  });
  tt.replaceChildren(...cells);
  tt.className = 'tt';
  for (const a of [...tt.attributes]) if (a.name !== 'class') tt.removeAttribute(a.name);
  if (tt.parentElement !== body || body.lastElementChild !== tt) body.append(tt);
  return true;
}

// Pasang/ganti/buang total kolom `c`. fn kosong/tidak dikenal = tanpa total. Membuat baris Total bila belum ada. Mengembalikan sel total kolom itu (atau null).
export function setColumnTotal(table, c, fn) {
  const cols = colCount(table);
  if (c < 0 || c >= cols) return null;
  let tt = totalRowOf(table);
  if (!tt) {
    if (!isTotalFunc(fn)) return null;
    const body = table.tBodies[table.tBodies.length - 1] || table.createTBody();
    tt = document.createElement('tr'); tt.className = 'tt';
    for (let i = 0; i < cols; i++) { const td = document.createElement('td'); td.setAttribute('contenteditable', 'false'); tt.append(td); }
    body.append(tt);
  }
  while (tt.cells.length < cols) { const td = document.createElement('td'); td.setAttribute('contenteditable', 'false'); tt.append(td); }
  const cell = tt.cells[c];
  if (isTotalFunc(fn)) cell.setAttribute('data-f', fn); else cell.removeAttribute('data-f');
  return refreshTotals(table) ? totalRowOf(table).cells[c] : null;
}
