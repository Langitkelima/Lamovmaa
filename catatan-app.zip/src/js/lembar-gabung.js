// Rev 151 / U10b-1: GABUNG SEL per tab lembar kerja (MURNI: tanpa DOM, penyimpanan, native, eval, dan TANPA mengimpor modul lain).
// Bentuk: tab.merges = [{ r1, c1, r2, c2 }] = ID baris/kolom sudut KIRI-ATAS (r1, c1) dan KANAN-BAWAH (r2, c2) menurut urutan saat disimpan; maks. 20 per tab.
// Sel kiri-atas = JANGKAR (satu-satunya yang berisi/berumus/bergaya); sel lain di dalam gabungan KOSONG. Persegi dihitung dari urutan baris/kolom SAAT INI,
// jadi menyisipkan baris/kolom di dalamnya memperbesar gabungan, menghapus baris/kolom di dalamnya memperkecilnya, dan menghapus sudutnya melepas gabungan (pruneMerges).
// Tanpa UI (U10b-2). Mengurutkan baris (lembar-alat sortTab) TIDAK boleh dijalankan pada tab bergabungan: wajib dijaga di U10b-2.
export const MAX_MERGES = 20;
const at = (arr, id) => { for (let i = 0; i < arr.length; i++) if (arr[i].id === id) return i; return -1; };
const label = (ri, ci) => String.fromCharCode(65 + ci) + (ri + 1);

// Persegi (indeks) dari satu entri; null bila sudut hilang atau hanya satu sel.
export function rectOf(tab, m) {
  if (!m || !tab) return null;
  const a = at(tab.rows, m.r1), b = at(tab.rows, m.r2), c = at(tab.cols, m.c1), d = at(tab.cols, m.c2);
  if (a < 0 || b < 0 || c < 0 || d < 0) return null;
  const r1 = Math.min(a, b), r2 = Math.max(a, b), c1 = Math.min(c, d), c2 = Math.max(c, d);
  if (r1 === r2 && c1 === c2) return null;
  return { r1, c1, r2, c2 };
}
const overlap = (p, q) => p.r1 <= q.r2 && q.r1 <= p.r2 && p.c1 <= q.c2 && q.c1 <= p.c2;

// Bersihkan daftar mentah terhadap rows/cols: ID harus ada, bukan satu sel, tidak tumpang tindih (yang pertama menang), maks. MAX_MERGES.
export function cleanMerges(raw, rows, cols) {
  const out = [], rects = [], tab = { rows, cols };
  for (const m of Array.isArray(raw) ? raw : []) {
    if (out.length >= MAX_MERGES) break;
    if (!m || typeof m !== 'object') continue;
    const r = rectOf(tab, m); if (!r || rects.some((q) => overlap(q, r))) continue;
    rects.push(r); out.push({ r1: rows[r.r1].id, c1: cols[r.c1].id, r2: rows[r.r2].id, c2: cols[r.c2].id });
  }
  return out;
}
// Semua gabungan yang sah, sebagai persegi indeks + sel jangkar (ID). Kosong tanpa biaya bila tab tanpa gabungan.
export function mergeList(tab) {
  if (!tab || !Array.isArray(tab.merges) || !tab.merges.length) return [];
  const out = [];
  for (const m of tab.merges) { const r = rectOf(tab, m); if (r) out.push({ ...r, ar: tab.rows[r.r1].id, ac: tab.cols[r.c1].id, ref: label(r.r1, r.c1) + ':' + label(r.r2, r.c2) }); }
  return out;
}
export const mergeAt = (tab, ri, ci) => mergeList(tab).find((r) => ri >= r.r1 && ri <= r.r2 && ci >= r.c1 && ci <= r.c2) || null;
export const isCovered = (tab, ri, ci) => { const m = mergeAt(tab, ri, ci); return !!m && !(m.r1 === ri && m.c1 === ci); };
// Peta "i,j" -> gabungannya untuk SEMUA sel (jangkar ikut); dihitung sekali per gambar ulang.
export function mergeMap(tab) { const map = new Map(); for (const m of mergeList(tab)) for (let i = m.r1; i <= m.r2; i++) for (let j = m.c1; j <= m.c2; j++) map.set(i + ',' + j, m); return map; }

// Rev 178: gabungan di bawah FILTER BARIS (sementara). ord = indeks baris asli yang TAMPIL, urut (null = tanpa filter = semua baris).
// Baris tampil milik satu gabungan selalu berurutan di ord (gabungan = rentang baris yang berdampingan), jadi gabungan digambar membentang
// sebanyak baris yang tampil saja, mulai dari baris tampil PERTAMA (first). Isinya tetap dari sel jangkar (r1, c1) walau baris jangkar tersembunyi.
// Gabungan yang semua barisnya tersembunyi tidak ada di hasil. Hasil: { list: [{...rect, ref, first, pos, count}], map: "i,j" -> entri }.
// first = indeks baris asli baris tampil pertama; pos = urutan tampilnya; count = jumlah baris tampil. Tanpa gabungan = list dan map kosong.
export function mergeView(tab, ord) {
  const list = [], map = new Map(); const base = mergeList(tab); if (!base.length) return { list, map };
  let posOf = null; if (Array.isArray(ord)) { posOf = new Map(); ord.forEach((r, k) => posOf.set(r, k)); }
  for (const m of base) {
    let first = -1, pos = -1, count = 0;
    for (let r = m.r1; r <= m.r2; r++) { const k = posOf ? posOf.get(r) : r; if (k === undefined) continue; if (first < 0) { first = r; pos = k; } count++; }
    if (count === 0) continue;
    const e = { ...m, first, pos, count }; list.push(e);
    for (let i = m.r1; i <= m.r2; i++) for (let j = m.c1; j <= m.c2; j++) map.set(i + ',' + j, e);
  }
  return { list, map };
}

const filled = (cell) => !!cell && (cell.v !== undefined && cell.v !== null && cell.v !== '' || typeof cell.fx === 'string');
// Rencana gabung (tanpa mengubah apa pun): { ok, reason: 'kecil'|'batas'|'tumpang'|'rentang', rect, filled: jumlah sel terisi selain jangkar }.
export function planMerge(tab, ri1, ci1, ri2, ci2) {
  const n = (v) => Number.isInteger(v) ? v : -1;
  const a = n(ri1), b = n(ri2), c = n(ci1), d = n(ci2);
  if (a < 0 || b < 0 || c < 0 || d < 0 || Math.max(a, b) >= tab.rows.length || Math.max(c, d) >= tab.cols.length) return { ok: false, reason: 'rentang' };
  const rect = { r1: Math.min(a, b), c1: Math.min(c, d), r2: Math.max(a, b), c2: Math.max(c, d) };
  if (rect.r1 === rect.r2 && rect.c1 === rect.c2) return { ok: false, reason: 'kecil', rect };
  const list = mergeList(tab);
  if (list.some((q) => overlap(q, rect))) return { ok: false, reason: 'tumpang', rect };
  if (Array.isArray(tab.merges) && tab.merges.length >= MAX_MERGES) return { ok: false, reason: 'batas', rect };
  let nf = 0;
  for (let i = rect.r1; i <= rect.r2; i++) for (let j = rect.c1; j <= rect.c2; j++) { if (i === rect.r1 && j === rect.c1) continue; if (filled(tab.rows[i].cells[tab.cols[j].id])) nf++; }
  return { ok: true, rect, filled: nf };
}
// Gabungkan. Bila ada sel terisi selain jangkar, dibutuhkan opts.clear === true (isi sel lain DIKOSONGKAN); tanpa itu tidak ada yang berubah.
// Mengembalikan { ok, reason?, cleared }.
export function addMerge(tab, ri1, ci1, ri2, ci2, opts = {}) {
  const p = planMerge(tab, ri1, ci1, ri2, ci2); if (!p.ok) return { ok: false, reason: p.reason, cleared: 0 };
  if (p.filled > 0 && opts.clear !== true) return { ok: false, reason: 'isi', filled: p.filled, cleared: 0 };
  const { r1, c1, r2, c2 } = p.rect; let cleared = 0;
  for (let i = r1; i <= r2; i++) for (let j = c1; j <= c2; j++) { if (i === r1 && j === c1) continue; const id = tab.cols[j].id; if (tab.rows[i].cells[id]) { if (filled(tab.rows[i].cells[id])) cleared++; delete tab.rows[i].cells[id]; } }
  if (!Array.isArray(tab.merges)) tab.merges = [];
  tab.merges.push({ r1: tab.rows[r1].id, c1: tab.cols[c1].id, r2: tab.rows[r2].id, c2: tab.cols[c2].id });
  return { ok: true, cleared };
}
// Pisahkan gabungan yang memuat sel (ri, ci). Sel lain tetap kosong. true bila ada yang dipisah.
export function removeMerge(tab, ri, ci) {
  if (!Array.isArray(tab.merges)) return false;
  const m = mergeAt(tab, ri, ci); if (!m) return false;
  const k = tab.merges.findIndex((x) => x.r1 === tab.rows[m.r1].id && x.c1 === tab.cols[m.c1].id && x.r2 === tab.rows[m.r2].id && x.c2 === tab.cols[m.c2].id) ;
  const j = k >= 0 ? k : tab.merges.findIndex((x) => { const r = rectOf(tab, x); return r && r.r1 === m.r1 && r.c1 === m.c1 && r.r2 === m.r2 && r.c2 === m.c2; });
  if (j < 0) return false; tab.merges.splice(j, 1); if (!tab.merges.length) delete tab.merges; return true;
}
// Buang gabungan yang sudah tidak sah (sudut terhapus / menyusut jadi satu sel / tumpang tindih). Dipanggil sesudah hapus baris/kolom. true bila berubah.
export function pruneMerges(tab) {
  if (!Array.isArray(tab.merges)) return false;
  const before = JSON.stringify(tab.merges), next = cleanMerges(tab.merges, tab.rows, tab.cols);
  if (next.length) tab.merges = next; else delete tab.merges;
  return JSON.stringify(tab.merges || []) !== (before === '[]' ? '[]' : before);
}
