// Rev 398 / PART M3 (Rev 399 / M4: gambar ikut diimpor, dikecilkan ke kualitas Hemat): pemilih berkas + konfirmasi Impor Markdown (dimuat MALAS dari Setelan). Hasil selalu catatan biasa.
import { h, dlg, tOk, tInfo, tErr } from './ui.js';
import { sanitize } from './notes.js';
import { newId } from './logic.js';
import { readZipIndex, readZipEntry, isZipBytes, utf8 } from './zip.js';
import { planMarkdownImport, commitMarkdownImport, materializeImages, importSummary, isImageName, IMPOR_MAX_FILES, IMPOR_MAX_FILE_CHARS } from './impor-md.js';

const msgOf = (e) => String((e && e.message) || e || 'gagal').slice(0, 120);
const MAX_ZIP_BYTES = 50 * 1024 * 1024;

// Rev 406: ZIP dibaca SEKALI ke memori (maks 50 MB, sudah dijaga) lalu diiris di memori. Dulu tiap isi memakai dua pembacaan terpisah dari berkas pilihan Android yang lambat = jeda beberapa detik sebelum dialog muncul.
export async function zipDiMemori(f) {
  const all = await f.arrayBuffer();
  return { size: all.byteLength, slice: (a, b) => ({ arrayBuffer: async () => all.slice(a, b) }) };
}
const napas = () => new Promise((r) => setTimeout(r, 0));

// Membaca daftar berkas pilihan menjadi [{ name, text }]; ZIP dibuka per isi (ukuran dibatasi sebelum dibaca).
export async function readPicked(fileList, notes = [], imgs = []) { // imgs (Rev 399): diisi [{ name, size, read() }] untuk gambar; tidak ikut ke daftar teks
  const out = [];
  for (const f of fileList) {
    if (isImageName(f.name)) { imgs.push({ name: f.name, size: f.size, read: async () => new Uint8Array(await f.arrayBuffer()) }); continue; }
    const head = new Uint8Array(await f.slice(0, 4).arrayBuffer());
    if (isZipBytes(head)) {
      if (f.size > MAX_ZIP_BYTES) { notes.push({ name: f.name, reason: 'ZIP terlalu besar (maksimal 50 MB)' }); continue; }
      const mem = await zipDiMemori(f);
      const idx = await readZipIndex(mem); let n = 0, k = 0;
      for (const e of idx) {
        if (++k % 25 === 0) { tInfo('Membaca ZIP ' + k + ' dari ' + idx.length + '...'); await napas(); }
        if (/\/$/.test(e.name)) continue;
        if (isImageName(e.name)) { if (imgs.length < 1000) imgs.push({ name: e.name, size: e.size, read: () => readZipEntry(mem, e) }); continue; }
        if (!/\.(md|markdown|txt)$/i.test(e.name)) { out.push({ name: e.name, text: '' }); continue; } // jenis lain: perencana yang menolak dengan alasan
        if (++n > IMPOR_MAX_FILES + 50) { notes.push({ name: e.name, reason: 'melebihi batas jumlah berkas' }); continue; }
        if (e.size > IMPOR_MAX_FILE_CHARS * 4) { out.push({ name: e.name, text: 'x'.repeat(IMPOR_MAX_FILE_CHARS + 1) }); continue; } // terlalu besar: biarkan perencana menolaknya dengan alasan
        out.push({ name: e.name, text: utf8.decode(await readZipEntry(mem, e)) });
      }
    } else if (f.size > IMPOR_MAX_FILE_CHARS * 4) out.push({ name: f.name, text: 'x'.repeat(IMPOR_MAX_FILE_CHARS + 1) });
    else out.push({ name: f.name, text: await f.text() });
  }
  return out;
}

export function bukaImporMd(ctx) {
  const inp = h('input', { type: 'file', multiple: 'true', accept: '.md,.markdown,.txt,.png,.jpg,.jpeg,.webp,text/markdown,text/plain,image/png,image/jpeg,image/webp,application/zip,application/x-zip-compressed,.zip' });
  inp.onchange = async () => {
    const list = [...(inp.files || [])]; if (!list.length) return;
    try {
      tInfo('Membaca berkas...');
      const pre = [], imgs = []; const files = await readPicked(list, pre, imgs);
      const plan = planMarkdownImport(files, ctx.data.settings.labels, imgs);
      for (const p of pre) plan.skipped.push(p);
      if (!plan.items.length) { tInfo('Tidak ada catatan yang bisa diimpor. ' + (plan.skipped.length ? importSummary(plan).replace(/^0 catatan akan ditambahkan\. ?/, '') : 'Pilih berkas .md, .txt, atau ZIP berisi berkas itu.')); return; }
      dlg({ title: 'Impor ' + plan.items.length + ' catatan?', msg: importSummary(plan) + ' Semuanya masuk sebagai catatan biasa, bukan Catatan Privat. Catatan yang sudah ada tidak diubah.', yes: 'Impor',
        ok: async () => {
          try {
            let use = plan, note = '';
            if (plan.imageCount) { const r = await bawaGambar(plan); use = r.plan; note = r.note; }
            const r = commitMarkdownImport(ctx.data, use, { sanitize, newId });
            ctx.persist(); ctx.render();
            tOk(r.added + ' catatan diimpor' + (r.labelsAdded ? ', ' + r.labelsAdded + ' label baru' : '') + '.' + note);
          } catch (e) { console.error('impor markdown gagal:', e); tErr('Gagal mengimpor: ' + msgOf(e)); }
        } });
    } catch (e) { console.error('baca impor gagal:', e); tErr('Gagal membaca berkas: ' + msgOf(e)); }
  };
  inp.click();
}

// Gambar: modul gambar-app dimuat malas (hanya bila ada gambar yang ikut). Tanpa Filesystem (peramban), gambar jadi penanda teks dan pengguna diberi tahu.
async function bawaGambar(plan) {
  let app, FS;
  try { app = await import('./gambar-app.js'); FS = app.imageFS(); } catch (_) { FS = null; }
  if (!FS || !app) {
    const r = await materializeImages(plan, { read: async () => { throw new Error('penyimpanan gambar tidak tersedia'); }, compress: async () => null, write: async () => {} });
    return { plan: r.plan, note: ' Gambar tidak ikut karena penyimpanan gambar tidak tersedia di sini.' };
  }
  const r = await materializeImages(plan, {
    read: (e) => e.read(), compress: (file, preset) => app.compressImage(file, preset), write: (ref, blob) => app.writeImage(FS, ref, blob),
    onProgress: (n, t) => tInfo('Memproses gambar ' + n + ' dari ' + t + '...'),
  });
  let note = r.done ? ' ' + r.done + ' gambar ikut.' : '';
  if (r.failed.length) note += ' ' + r.failed.length + ' gambar gagal dan diganti penanda teks (' + r.failed.slice(0, 2).map((f) => f.name + ': ' + f.reason).join('; ') + (r.failed.length > 2 ? '; ...' : '') + ').';
  return { plan: r.plan, note };
}
