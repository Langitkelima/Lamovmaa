// Keluar dari aplikasi: peringatan dulu, lalu aplikasi dihentikan TOTAL (proses dimatikan, tidak jalan di latar belakang).
// Penghentian dilakukan kode native kecil (MainActivity, dipasang scripts/apply-native.mjs) lewat window.KelimaaNative.exit().
import { h, dlg, tWarn } from './ui.js';
import { closeEditor } from './notes.js';
import { isNative } from './native.js';

export function nativeExit(g = globalThis) {
  const N = g.KelimaaNative;
  if (!N || typeof N.exit !== 'function') return false;
  try { N.exit(); return true; } catch (e) { console.error('keluar gagal:', e); return false; }
}

// Simpan semua sebelum keluar lewat tombol Kembali (tanpa dialog, tanpa layar "Menutup...").
export function prepareExit(ctx) {
  closeEditor();      // menyimpan catatan yang sedang terbuka
  ctx.persist();
}

export function doExit(ctx, g = globalThis) {
  prepareExit(ctx);
  const ov = h('div', { class: 'ov dlgov exiting', role: 'status' }, h('div', { class: 'sheet dlg' }, h('h3', {}, 'Menutup aplikasi...')));
  document.body.append(ov);
  if (!nativeExit(g)) {
    ov.remove();
    tWarn('Tidak bisa menutup otomatis di HP ini. Tutup lewat daftar aplikasi terbaru.');
  }
}

export function askExit(ctx) {
  if (document.querySelector('.exitdlg')) return;
  dlg({ title: 'Keluar dari Notes Kelimaa?', msg: 'Aplikasi akan ditutup total dan tidak berjalan di latar belakang. Catatan privat terkunci lagi.',
    yes: 'Keluar', cls: 'exitdlg', ok: () => doExit(ctx) });
}

// ---- Rev 14: dialog "Keluar dari aplikasi?" saat Kembali ditekan di layar utama ----
const APP_NAME = 'Notes Kelimaa';

// Keluar lewat dialog Kembali. Di aplikasi: alur native yang sudah teruji (doExit). Di peramban: window.close(), lalu about:blank.
// Jika terdeteksi aplikasi Capacitor tetapi jembatan hilang, JANGAN mengosongkan halaman: tetap lewat doExit (yang memberi pesan).
export function exitApp(ctx, g = globalThis) {
  if (g.KelimaaNative || isNative()) return doExit(ctx, g);
  prepareExit(ctx);
  g.__kelimaaLeaving = true; // popstate tidak boleh menjebak lagi
  try { g.close(); } catch (e) { /* peramban menolak */ }
  setTimeout(() => { try { g.location.replace('about:blank'); } catch (e) { /* abaikan */ } }, 150);
}

// Dialog konfirmasi. Memakai kelas dialog yang sudah ada (ov dlgov / sheet dlg / dlgb), jadi tema terang-gelap ikut otomatis
// dan closeDialog() (Kembali saat dialog terbuka) menutupnya lewat tombol "Batal" (.line).
export function askExitBack(ctx) {
  if (document.querySelector('.exitq')) return;
  const prev = document.activeElement;
  const ov = h('div', { class: 'ov dlgov exitq' });
  const onKey = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key === 'Tab') { // fokus tidak lari ke belakang dialog
      const bs = [...ov.querySelectorAll('button')], i = bs.indexOf(document.activeElement);
      e.preventDefault(); bs[(i + (e.shiftKey ? bs.length - 1 : 1)) % bs.length].focus();
    }
  };
  function close() {
    document.removeEventListener('keydown', onKey, true); ov.remove();
    try { if (prev && prev.focus) prev.focus(); } catch (e) { /* abaikan */ }
  }
  const bNo = h('button', { type: 'button', class: 'btn line', onclick: close }, 'Batal');
  const bYes = h('button', { type: 'button', class: 'btn', onclick: () => { close(); exitApp(ctx); } }, 'Keluar');
  ov.addEventListener('click', (e) => { if (e.target === ov) close(); }); // ketuk di luar dialog
  ov.append(h('div', { class: 'sheet dlg', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'exitq-t', 'aria-describedby': 'exitq-d' },
    h('img', { class: 'ql', src: 'img/logo-keluar.png', alt: '', draggable: 'false' }),
    h('h3', { id: 'exitq-t' }, 'Keluar dari aplikasi?'),
    h('p', { class: 'sub', id: 'exitq-d' }, 'Yakin ingin menutup ' + APP_NAME + '?'),
    h('div', { class: 'dlgb' }, bNo, bYes)));
  document.body.append(ov);
  document.addEventListener('keydown', onKey, true);
  bNo.focus(); // fokus awal di Batal
}

// Cadangan untuk peramban (tanpa jembatan native): tangkap Kembali lewat history.pushState + popstate.
// Di HP (jembatan/Capacitor ada) TIDAK dipasang: trik ini terbukti tidak bekerja di WebView (Rev 10), Kembali ditangani native.
export function installBrowserBack(onBack, g = globalThis) {
  if (g.KelimaaNative || isNative()) return false;
  try {
    const guard = () => g.history.pushState({ kelimaaGuard: 1 }, '');
    guard();
    g.addEventListener('popstate', () => { if (g.__kelimaaLeaving) return; onBack(); guard(); });
    return true;
  } catch (e) { return false; }
}
