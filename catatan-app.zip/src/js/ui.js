// Helper tampilan bersama. Teks pengguna selalu lewat textContent (anti-XSS).
export const $ = (s) => document.querySelector(s);

export function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === false || v == null) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat(Infinity)) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}
// Judul layar berupa gambar SVG (Rev 372: gaya Titik Waktu, huruf Adventor Tebal+ sudah jadi path, glow per tema ada DI DALAM berkas).
// Dua gambar per judul: `-t` (tema terang) dan `-g` (tema gelap); CSS menampilkan salah satunya mengikuti tema. Teks asli ada di atribut alt.
// [teks, nama berkas di img/judul/, lebar tampil px]; dibuat oleh tools/buat_judul_svg.py (semua judul memakai skala yang sama).
export const JUDUL = {
  catatan: ['Catatan', 'catatan', 282], privat: ['Catatan Private', 'privat', 273], habit: ['Kebiasaan Harian', 'kebiasaan', 283],
  hari: ['Fokus Hari Ini', 'fokus', 259], minggu: ['Target Mingguan', 'target', 319], bulan: ['Rencana Bulanan', 'rencana', 300], kelimaa: ['Kelimaa AI', 'kelimaa', 199],
};
export function judul(key) {
  const [alt, berkas, lebar] = JUDUL[key];
  const gambar = (tema) => h('img', { class: 'jdl-' + tema, src: `img/judul/${berkas}-${tema}.svg`, alt, draggable: 'false', style: `width:${lebar}px` });
  return h('h1', { class: 'jdl' + (key === 'privat' ? ' mid' : '') }, gambar('t'), gambar('g'));
}
export function ico(d) {
  const ns = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(ns, 'svg'); s.setAttribute('viewBox', '0 0 24 24');
  const p = document.createElementNS(ns, 'path'); p.setAttribute('d', d); s.append(p);
  return s;
}
// Rev 310a: icoMenu = tiga garis (B1), jadi silang lewat CSS.
export const svgEl = (tag, attrs) => { const e = document.createElementNS('http://www.w3.org/2000/svg', tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };
export function icoMenu() { const s = svgEl('svg', { viewBox: '0 0 24 24', 'aria-hidden': 'true' }); [7, 12, 17].forEach((y, i) => s.append(svgEl('line', { class: 'mh' + (i + 1), x1: 5, y1: y, x2: 19, y2: y }))); return s; }
export const PATH = {
  moveUp: 'M12 19V5M6 11l6-6 6 6',
  moveDown: 'M12 5v14M6 13l6 6 6-6',
  flow: 'M4 5h7v7H4zM14 6h6M14 10h6M4 16h16M4 20h10',
  proyek: 'M3 7V5h6l2 2h10v12H3zM3 11h18',
  expand: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5',
  photo: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M15.5 9.5h.01',
  alignL: 'M4 6h16M4 10h10M4 14h16M4 18h10',
  alignC: 'M4 6h16M7 10h10M4 14h16M7 18h10',
  alignR: 'M4 6h16M10 10h10M4 14h16M10 18h10',
  lock: 'M5 11h14v10H5zM8 11V8a4 4 0 018 0v3',
  unlock: 'M5 11h14v10H5zM8 11V8a4 4 0 017.5-2',
  bin: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
  tugas: 'M5 12l4 4 10-10',
  tugasNav: 'M12 21a9 9 0 100-18 9 9 0 000 18zM8 12.5l3 3 5-6',
  catatan: 'M6 3h9l4 4v14H6zM9 12h7M9 16h5',
  privat: 'M5 11h14v10H5zM8 11V8a4 4 0 018 0v3',
  lainnya: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z',
  // Rev 43: pushpin miring (kepala di kanan atas, jarum ke kiri bawah), lebih estetik dari pin tegak lama
  pin: 'M15.2 3.3L19.6 6.8L15.3 11.3L16 15.9L15.1 17.2L6.2 10.3L7.2 9L11.9 8.6ZM10.6 13.7L6.2 19.4',
  alarm: 'M12 21a7.5 7.5 0 100-15 7.5 7.5 0 000 15zM12 9.5v3.8l2.4 1.4M4 6.5L7 3.5M20 6.5l-3-3',
  grid: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',
  rows: 'M4 6h16M4 12h16M4 18h16',
  back: 'M15 5l-7 7 7 7',
  // Rev 42: pensil miring dengan ujung runcing, garis pemisah di kepala, dan garis alas (lebih jelas dan estetik dari versi lama)
  edit: 'M4.2 19.8l1-4.3L16.4 4.3a2.2 2.2 0 013.1 3.1L8.3 18.6zM14.2 6.5l3.3 3.3M12.5 20.2H20',
  sun: 'M12 16.5a4.5 4.5 0 100-9 4.5 4.5 0 000 9zM12 2.5v2.2M12 19.3v2.2M4.9 4.9l1.6 1.6M17.5 17.5l1.6 1.6M2.5 12h2.2M19.3 12h2.2M4.9 19.1l1.6-1.6M17.5 6.5l1.6-1.6',
  auto: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 3v18M15.5 5.6v12.8M19 9.5v5',
  undo: 'M9 14L4 9l5-5M4 9h10.5a5.5 5.5 0 010 11H11',
  redo: 'M15 14l5-5-5-5M20 9H9.5a5.5 5.5 0 000 11H13',
  palette: 'M12 3a9 9 0 100 18c1.3 0 1.9-.9 1.5-1.9-.4-1 .3-2.1 1.4-2.1H17a4 4 0 004-4c0-5-4-10-9-10zM7.5 11.5h.01M10 7.5h.01M14.5 7.5h.01M17 11h.01',
  more: 'M12 5h.01M12 12h.01M12 19h.01',
  chevDown: 'M5 9l7 7 7-7',
  clock: 'M12 20a8 8 0 100-16 8 8 0 000 16zM12 8v4.2l2.8 1.8',
  close: 'M6 6l12 12M18 6L6 18',
  star: 'M12 2.5c.7 5.4 4.1 8.8 9.5 9.5-5.4.7-8.8 4.1-9.5 9.5-.7-5.4-4.1-8.8-9.5-9.5 5.4-.7 8.8-4.1 9.5-9.5z',
  copy: 'M9 9h11v11H9zM5 15V4h11',
  chev: 'M9 5l7 7-7 7',
  down: 'M12 4v11M7 11l5 5 5-5M5 20h14',
  up: 'M12 20V9M7 13l5-5 5 5M5 4h14',
  moon: 'M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z',
  cal: 'M5 5h14v15H5zM5 10h14M9 3v4M15 3v4',
  del: 'M21 5H9l-6 7 6 7h12zM12 9l5 5M17 9l-5 5',
  tag: 'M3 12V4h8l9 9-8 8zM7.5 8h.01',
  power: 'M12 3v8M7.2 6.6a8 8 0 109.6 0',
  share: 'M4 12v7a1 1 0 001 1h14a1 1 0 001-1v-7M16 6l-4-4-4 4M12 2v13',
  link: 'M8 8V6.5A2.5 2.5 0 0110.5 4h7A2.5 2.5 0 0120 6.5v7a2.5 2.5 0 01-2.5 2.5H16M6.5 8h7a2.5 2.5 0 012.5 2.5v7a2.5 2.5 0 01-2.5 2.5h-7A2.5 2.5 0 014 17.5v-7A2.5 2.5 0 016.5 8zM7.5 14h5',
  // Rev 64: ikon ruang TWO POCKETS
  refresh: 'M20 12a8 8 0 11-2.34-5.66M20 4v5h-5',
  wallet: 'M4 7.5A2.5 2.5 0 016.5 5H17v3M4 7.5V17a2 2 0 002 2h13V8H6.5A2.5 2.5 0 014 7.5zM16 13.5h1.5',
  receipt: 'M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6',
  tool: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z',
};
// Rev 311a: toast bernada.
export function toastTone(msg) {
  const m = String(msg);
  if (/gagal|salah|error|rusak|tidak valid/i.test(m)) return 'err';
  if (/tidak bisa|tidak dapat|terlalu|maks|harus|belum|pilih |ditolak|dibatasi|minimal|sudah ada|penuh|lewat|\bdulu\b(?!, lalu)|(?<!yang )tidak sah|tidak boleh|masih kosong|tidak ikut|hanya (bisa|jalan)|berubah\.|^(isi|tunggu) |berkas kosong|sudah tidak ada/i.test(m)) return 'warn'; // Rev 312b: + pola "dulu", "tidak sah", "masih kosong", dst.
  if (/^(tersimpan|disalin|tersalin|dipulihkan|selesai|berhasil|diekspor|dihapus|dipindah)|\b(ditambahkan|dihapus|diatur|disalin|dibuat|disimpan|digabung|diganti|dibersihkan|dilepas|dipindah)\b|tidak ada data yang tidak sah/i.test(m)) return 'ok';
  return 'info';
}
export function toastMs(msg, tone, undo) {
  const base = tone === 'err' ? 8000 : tone === 'warn' ? 6500 : 4500;
  return Math.min(14000, Math.max(undo ? 6000 : base, base + Math.max(0, String(msg).length - 40) * 60));
}
export const TONE_ICO = { ok: 'M5 12.5l4.5 4.5L19 7.5', warn: 'M12 7v6M12 16.5h.01', err: 'M7 7l10 10M17 7L7 17', info: 'M12 11v5.5M12 7.5h.01' };
// Rev 331 / TC (pilihan pengguna: varian A + garis waktu): kapsul warna penuh, TUMPUK maks. 2 (yang baru di dasar, bernomor id=toast; yang lama naik lewat --ty), garis waktu .tpg, geser kiri/kanan untuk tutup, jeda saat disentuh.
let tAtasOn = false; // Rev 386: diset oleh tWarnAtas saja (tanda tangan toast tidak berubah)
export function toast(msg, undo, after, label = 'Urungkan', tone) {
  tone = tone || toastTone(msg);
  const atas = tAtasOn, ms = toastMs(msg, tone, undo), cur = atas ? null : $('#toast'); // atas = toast di bagian atas layar: tidak ikut tumpukan bawah
  let left = ms, t0 = 0, tm = 0, x0 = null, dx = 0;
  if (cur) { const o2 = $('.toast.tko'); if (o2) o2.remove(); cur.removeAttribute('id'); cur.classList.add('tko'); }
  const gone = () => {
    clearTimeout(tm); const front = t.id === 'toast'; t.remove();
    const o = front && $('.toast.tko'); if (o) { o.id = 'toast'; o.classList.remove('tko'); o.style.removeProperty('--ty'); }
  };
  const run = () => { t0 = Date.now(); tm = setTimeout(gone, left); };
  const pg = h('i', { class: 'tpg', style: 'animation-duration:' + ms + 'ms' });
  const t = h('div', Object.assign({ class: 'toast tn-' + tone + (atas ? ' ttop' : ''), role: tone === 'err' || tone === 'warn' ? 'alert' : 'status', 'aria-live': tone === 'err' ? 'assertive' : 'polite', 'aria-atomic': 'true' }, atas ? {} : { id: 'toast' }), // Rev 333 / TE: err = assertive; warn/ok/info = polite
    h('span', { class: 'tic' }, ico(TONE_ICO[tone])), h('span', { class: 'tmsg' }, msg));
  if (undo) t.append(h('button', { type: 'button', class: 'tact', onclick: () => { undo(); gone(); if (after) after(); } }, label));
  t.append(h('button', { type: 'button', class: 'tx', 'aria-label': 'Tutup', onclick: gone }, ico(PATH.close)), pg);
  t.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button')) return;
    x0 = e.clientX; dx = 0; clearTimeout(tm); left -= Date.now() - t0; pg.style.animationPlayState = 'paused'; t.classList.add('tkh');
    try { t.setPointerCapture(e.pointerId); } catch (_) {}
  });
  t.addEventListener('pointermove', (e) => { if (x0 === null) return; dx = e.clientX - x0; t.style.setProperty('--dx', dx + 'px'); t.style.opacity = Math.max(0.2, 1 - Math.abs(dx) / 220); });
  const up = () => {
    if (x0 === null) return; x0 = null; t.classList.remove('tkh');
    if (Math.abs(dx) > 70) { t.style.setProperty('--dx', (dx > 0 ? 500 : -500) + 'px'); t.style.opacity = 0; setTimeout(gone, 200); return; }
    t.style.setProperty('--dx', '0px'); t.style.opacity = ''; pg.style.animationPlayState = 'running'; left = Math.max(1500, left); run();
  };
  t.addEventListener('pointerup', up); t.addEventListener('pointercancel', up);
  const vv = typeof window !== 'undefined' ? window.visualViewport : 0, kb = vv ? Math.round(window.innerHeight - vv.height - vv.offsetTop) : 0;
  if (kb > 80 && !atas) t.style.bottom = (kb + 12) + 'px';
  document.body.append(t);
  if (cur) cur.style.setProperty('--ty', -(t.offsetHeight + 6) + 'px');
  run();
}
// Rev 330 / TB: pembantu nada eksplisit (pesan literal tidak lagi menebak nada dari kata). Dinamis tetap boleh memakai fungsi toast biasa (cadangan toastTone).
const toastN = (n) => (m, u, a, l) => toast(m, u, a, l, n);
export const tOk = toastN('ok'), tWarn = toastN('warn'), tErr = toastN('err'), tInfo = toastN('info');
// Rev 386: peringatan di ATAS layar (lembar bawah dan kartu pilihannya tetap terlihat). Tidak ikut tumpukan toast bawah dan tidak memakai id=toast.
export const tWarnAtas = (m) => { tAtasOn = true; try { toast(m, undefined, undefined, undefined, 'warn'); } finally { tAtasOn = false; } };
// Rev 311a: dialog info dimuat malas.
export const infoDlg = (d) => import('./ui-info.js').then((m) => m.infoDlg(d));
export const infoKey = (k, ...a) => import('./tolak-msg.js').then((m) => infoDlg(m.M[k](...a)));
export const infoPast = (t, who, extra) => import('./ui-info.js').then((m) => m.infoPast(t, who, extra));
// Dialog konfirmasi. Teks lewat textContent. reverse=true menukar posisi tombol (hindari ketukan ganda tak sengaja).
export function dlg({ title, msg, yes, no, ok, red, reverse, cls }) {
  const ov = h('div', { class: 'ov dlgov' });
  const bNo = h('button', { type: 'button', class: 'btn line', onclick: () => { ov.remove(); if (no) no(); } }, 'Batal');
  const bYes = h('button', { type: 'button', class: 'btn' + (red ? ' red' : ''), onclick: () => { ov.remove(); ok(); } }, yes);
  ov.append(h('div', { class: 'sheet dlg' + (cls ? ' ' + cls : '') }, h('h3', {}, title), h('p', { class: 'sub' }, msg), h('div', { class: 'dlgb' + (reverse ? ' rev' : '') }, bNo, bYes)));
  document.body.append(ov);
}
// Tombol Kembali HP: menutup dialog paling atas (sama dengan menekan Batal). true jika ada dialog yang ditangani.
export function closeDialog(root = document) {
  const all = [...root.querySelectorAll('.dlgov')];
  if (!all.length) return false;
  const b = all[all.length - 1].querySelector('.dlgb button.line,.dlgb button[data-close]');
  if (b) b.click();
  return true;
}

// Ilustrasi gembok sederhana (vektor) untuk layar Catatan Privat. Warna lewat token CSS.
function sv(tag, attrs = {}) {
  const e = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  return e;
}
export function lockArt() {
  const root = sv('svg', { viewBox: '0 0 120 120', class: 'artsvg', 'aria-hidden': 'true' });
  root.append(
    sv('circle', { cx: 60, cy: 60, r: 54, style: 'fill:var(--acs);stroke:none' }),
    sv('path', { d: 'M14 84c11-1 20-9 22-22 7 8 7 21-1 30-7 0-15-3-21-8z', style: 'fill:var(--ac2);stroke:none' }),
    sv('path', { d: 'M106 84c-11-1-20-9-22-22-7 8-7 21 1 30 7 0 15-3 21-8z', style: 'fill:var(--ac2);stroke:none' }),
    sv('path', { d: 'M46 56V46a14 14 0 0128 0v10', style: 'fill:none;stroke:var(--ac);stroke-width:6;stroke-linecap:round' }),
    sv('rect', { x: 36, y: 54, width: 48, height: 38, rx: 10, style: 'fill:var(--ac);stroke:none' }),
    sv('circle', { cx: 60, cy: 70, r: 5, style: 'fill:var(--onac);stroke:none' }),
    sv('rect', { x: 58, y: 72, width: 4, height: 10, rx: 2, style: 'fill:var(--onac);stroke:none' }));
  return h('div', { class: 'art' }, root);
}

// Rev 198: lapisan "Hapus" di belakang kartu/baris yang digeser. Dua sisi: .swl tampil saat geser ke kanan, .swr saat geser ke kiri (diatur data-dir pada pembungkus).
export function swbgEl() {
  return h('div', { class: 'swbg' }, h('span', { class: 'swl' }, ico(PATH.bin), h('span', {}, 'Hapus')), h('span', { class: 'swr' }, ico(PATH.bin), h('span', {}, 'Hapus')));
}

// Rev 198: geser kartu ke KIRI atau KANAN = hapus (hanya daftar Catatan; Tugas/Kebiasaan memakai tombol tempat sampah). arahGeser/arahTampil murni (bisa dites di Node).
export const GESER_HAPUS_PX = 100, GESER_GERAK_PX = 8;
export function arahGeser(dx) { return typeof dx !== 'number' || !isFinite(dx) ? '' : dx < -GESER_HAPUS_PX ? 'kiri' : dx > GESER_HAPUS_PX ? 'kanan' : ''; }
export function arahTampil(dx) { return typeof dx !== 'number' || !isFinite(dx) || Math.abs(dx) <= GESER_GERAK_PX ? '' : dx < 0 ? 'kiri' : 'kanan'; }
