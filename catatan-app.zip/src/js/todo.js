// Menyisipkan baris kotak centang BARU di bawah baris tempat kursor berada.
// Tidak pernah memasukkannya ke dalam baris centang lain (itu yang membuat dua kotak berderet satu baris).
export function insertTodo(ed, node, doc = document) {
  let blk = node;
  while (blk && blk.parentNode !== ed) blk = blk.parentNode; // anak langsung editor yang memuat kursor
  const row = doc.createElement('div'); row.className = 'todo';
  const cb = doc.createElement('input'); cb.setAttribute('type', 'checkbox');
  row.append(cb, '\u00a0');
  if (!blk) { ed.append(row); return row; }
  const plainEmpty = (blk.tagName === 'DIV' || blk.tagName === 'P') && blk.className !== 'todo' && !String(blk.textContent || '').trim();
  if (plainEmpty) { ed.insertBefore(row, blk); ed.removeChild(blk); } // baris kosong biasa diganti, bukan ditambah
  else ed.insertBefore(row, blk.nextSibling);
  return row;
}

// Rev 107: kursor dan teks TIDAK boleh berada di kiri kotak centang. div.todo = flex berisi <input> + teks; di contenteditable
// ketukan di ruang kiri kotak (atau panah kiri) menaruh kursor sebelum <input>, lalu ketikan jadi item flex di KIRI kotak.
// Fungsi di bawah murni (hanya API DOM dasar) supaya bisa dites tanpa peramban.
export function boxOf(row) {
  for (let c = row && row.firstChild; c; c = c.nextSibling) if (c.nodeType === 1 && c.tagName === 'INPUT') return c;
  return null;
}
// Pindahkan semua simpul di kiri kotak ke kanannya (urutan tetap, sebelum teks yang sudah ada). Mengembalikan jumlah simpul yang dipindah.
export function healTodoRow(row) {
  const cb = boxOf(row); if (!cb) return 0;
  const pre = [];
  for (let c = row.firstChild; c && c !== cb; c = c.nextSibling) pre.push(c);
  if (!pre.length) return 0;
  const ref = cb.nextSibling;
  for (const c of pre) row.insertBefore(c, ref);
  return pre.length;
}
// Apakah titik kursor (node, offset) berada di kiri atau tepat sebelum kotak centang baris ini?
export function caretLeftOfBox(row, node, offset) {
  const cb = boxOf(row); if (!cb) return false;
  const kids = Array.prototype.slice.call(row.childNodes); const ci = kids.indexOf(cb);
  if (node === row) return offset <= ci;
  let c = node; while (c && c.parentNode !== row) c = c.parentNode;
  if (!c) return false;
  const i = kids.indexOf(c); return i >= 0 && i < ci;
}
// Titik kursor yang benar: awal teks tepat di kanan kotak (setelah nbsp pembuka bila ada). Tidak mengubah DOM.
export function caretAfterBox(row) {
  const cb = boxOf(row); if (!cb) return null;
  const nx = cb.nextSibling;
  if (nx && nx.nodeType === 3) return { node: nx, offset: String(nx.data || '').charAt(0) === '\u00a0' ? 1 : 0 };
  return { node: row, offset: Array.prototype.indexOf.call(row.childNodes, cb) + 1 };
}

// ===== Rev 108: sistem kotak centang dirapikan (Enter, Backspace, Delete, penyembuhan struktur) =====
// Akar masalah (terbukti di Chromium): menekan Enter di dalam <div class="todo"> membuat <div class="todo"> BARU TANPA kotak centang
// (Chrome menyalin kelasnya, bukan isinya). Baris yatim itu tetap punya lonceng (CSS ::after) dan teksnya nempel di kiri, sehingga
// lonceng bertumpuk dan "kotak hilang". Aturan tetap (invarian): setiap div.todo punya TEPAT SATU kotak, dan kotak itu anak pertamanya.
const BLANK_RE = /[\s ​]/g;
function nodeBlank(c) {
  if (c.nodeType === 3) return !String(c.data || '').replace(BLANK_RE, '');
  if (c.nodeType !== 1) return true;
  if (c.tagName === 'BR' || c.tagName === 'INPUT') return true;
  if (c.tagName === 'IMG' || c.tagName === 'FIGURE' || c.tagName === 'TABLE') return false;
  for (let k = c.firstChild; k; k = k.nextSibling) if (!nodeBlank(k)) return false;
  return true;
}
// Baris tanpa isi selain kotak (hanya spasi/nbsp/<br>)?
export function isTodoBlank(row) {
  for (let c = row && row.firstChild; c; c = c.nextSibling) if (!nodeBlank(c)) return false;
  return true;
}
export function newTodoRow(doc = document) {
  const row = doc.createElement('div'); row.className = 'todo';
  const cb = doc.createElement('input'); cb.setAttribute('type', 'checkbox');
  row.insertBefore(cb, null); row.insertBefore(doc.createTextNode(' '), null);
  return row;
}
// Pulihkan invarian satu baris. Mengembalikan jumlah perbaikan (0 = sudah benar). Idempoten.
export function healTodoStructure(row, doc = document) {
  let n = healTodoRow(row);
  let cb = boxOf(row);
  if (!cb) { // baris yatim (salinan Enter dari Chrome / catatan lama): beri kotak BARU yang belum dicentang
    cb = doc.createElement('input'); cb.setAttribute('type', 'checkbox');
    if (isTodoBlank(row)) {
      while (row.firstChild) row.removeChild(row.firstChild);
      row.insertBefore(cb, null); row.insertBefore(doc.createTextNode(' '), null);
    } else {
      row.insertBefore(cb, row.firstChild);
      const f = cb.nextSibling; // spasi pembuka sama seperti baris normal supaya teks sejajar
      if (!(f && f.nodeType === 3 && String(f.data).charAt(0) === '\u00a0')) row.insertBefore(doc.createTextNode('\u00a0'), f);
    }
    return n + 1;
  }
  for (let c = cb.nextSibling; c;) { // kotak kedua dst. di baris yang sama dibuang (teksnya tetap)
    const nx = c.nextSibling;
    if (c.nodeType === 1 && c.tagName === 'INPUT') { row.removeChild(c); n++; }
    c = nx;
  }
  return n;
}
// Baris centang -> baris biasa (Backspace di awal teks, atau Enter di baris kosong): kotak dibuang, teks tetap.
export function todoToPlain(row, doc = document) {
  const cb = boxOf(row); if (cb) row.removeChild(cb);
  const f = row.firstChild;
  if (f && f.nodeType === 3 && String(f.data).charAt(0) === ' ') { if (f.data.length === 1) row.removeChild(f); else f.data = f.data.slice(1); }
  if (isTodoBlank(row)) { while (row.firstChild) row.removeChild(row.firstChild); row.insertBefore(doc.createElement('br'), null); }
  for (const a of ['class', 'data-cid', 'data-rem']) if (row.removeAttribute) row.removeAttribute(a);
  if (!row.removeAttribute) row.className = ''; // DOM mini (tes); di peramban atribut class dibuang penuh, tanpa class="" sisa
  return row;
}
// Delete di akhir baris centang: isi baris centang berikutnya digabung ke baris ini (kotaknya dibuang, bukan nyelip di tengah teks).
export function mergeNextTodo(row, next) {
  const cb = boxOf(next);
  let c = next.firstChild;
  while (c) { const nx = c.nextSibling; if (c !== cb) { if (!(c.nodeType === 1 && c.tagName === 'BR')) row.insertBefore(c, null); } c = nx; }
  if (next.parentNode) next.parentNode.removeChild(next);
  return row;
}

// Rev 347 / R2: penyembuhan cid item daftar (bullet/bernomor). `els` = elemen ber-data-cid (li dan div.todo) menurut urutan dokumen.
// li dengan cid kembar (Enter membelah item) = yang KEDUA dan seterusnya dibersihkan; li tanpa teks sendiri tidak boleh memegang cid. Mengembalikan jumlah atribut yang dibuang.
export function healListCids(els) {
  const seen = new Set(); let n = 0;
  for (const el of els) {
    const cid = el.getAttribute && el.getAttribute('data-cid'); if (!cid) continue;
    if (el.tagName === 'LI') {
      let own = ''; for (let c = el.firstChild; c; c = c.nextSibling) { if (c.nodeType === 3) own += c.data; else if (c.nodeType === 1 && c.tagName !== 'UL' && c.tagName !== 'OL') own += c.textContent || ''; }
      if (!own.replace(/[\s\u00a0]+/g, '') || seen.has(cid)) { el.removeAttribute('data-cid'); n++; continue; }
    } else if (seen.has(cid)) continue; // div.todo kembar ditangani sanitize (cid baru)
    seen.add(cid);
  }
  return n;
}

// Rev 416: tempel banyak baris sekaligus (mis. teks Google Keep "[ ] a\n[X] b") di bawah blok tempat kursor berada. lines = [{ todo, done, text }].
// Baris centang memakai bentuk SAMA dengan insertTodo; baris biasa jadi <div>. Blok biasa yang kosong diganti, bukan ditambah. Mengembalikan baris terakhir yang dibuat.
export function insertTodoLines(ed, node, lines, doc = document) {
  let blk = node;
  while (blk && blk.parentNode !== ed) blk = blk.parentNode;
  const plainEmpty = !!blk && (blk.tagName === 'DIV' || blk.tagName === 'P') && !blk.classList.contains('todo') && !String(blk.textContent || '').trim();
  let ref = !blk ? null : plainEmpty ? blk.nextSibling : blk.nextSibling;
  const made = [];
  for (const l of lines) {
    const row = doc.createElement('div');
    if (l.todo) {
      row.className = 'todo';
      const cb = doc.createElement('input'); cb.setAttribute('type', 'checkbox'); if (l.done) cb.setAttribute('checked', '');
      row.append(cb, '\u00a0' + l.text);
    } else if (l.text) row.textContent = l.text; else row.append(doc.createElement('br'));
    ed.insertBefore(row, ref); made.push(row);
  }
  if (plainEmpty) ed.removeChild(blk);
  return made.length ? made[made.length - 1] : null;
}
