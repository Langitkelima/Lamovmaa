// Rev 420 / PART SY3a (Paket SY): PENGHUBUNG JARINGAN + PENJALAN SINKRON. Tanpa DOM, tanpa UI. Dimuat MALAS (import dinamis oleh SY3b) dan BELUM dipanggil siapa pun.
// Tugasnya menyambungkan mesin murni `sync.js` (SY2) ke Worker lewat alamat + passcode yang SUDAH ADA (Setelan > Kelimaa AI, kunci `kelimaa_ai_conn`):
//   1) makeSyncCall(conn, http): membuat call(body) untuk runSync (POST {key, ...body}, jawaban JSON, galat jadi pesan awam).
//   2) jalankanSinkron(opts): SATU putaran penuh = baca keadaan -> runSync -> simpan data + keadaan -> kabari pemanggil. Tidak pernah melempar galat.
//   3) statusSinkron / pengaturan (sakelar Otomatis, hasil terakhir) / putusSinkron untuk layar SY3b.
// Passcode TIDAK disalin ke mana pun: dibaca dari `kelimaa_ai_conn`, dipakai di badan permintaan, tidak masuk keadaan sinkron, pengaturan, atau hasil.
import { runSync, describeSync, loadSyncState, saveSyncState, clearSyncState, dirtyCount } from './sync.js';
import { cleanUrl, cleanPass, loadConn, nativeHttp, explainWorkerError } from './ai/sambungan.js';
import { newId as defaultNewId } from './logic.js';

export const SYNC_CFG_KEY = 'catatan_app_sync_cfg';
export const SYNC_TIMEOUT = 45000; // satu putaran bisa membawa ratusan ribu huruf: lebih longgar daripada chat/ping (20 dtk)

// ---- Pengaturan sinkron (kunci terpisah dari data aplikasi: tidak ikut cadangan, tidak ikut ekspor).
export function emptySyncCfg() { return { v: 1, auto: false, lastTryAt: 0, lastOkAt: 0, lastMsg: '', lastErr: '' }; }
export function cleanSyncCfg(raw) {
  const c = emptySyncCfg();
  if (!raw || typeof raw !== 'object') return c;
  c.auto = raw.auto === true;
  for (const k of ['lastTryAt', 'lastOkAt']) if (Number.isFinite(raw[k]) && raw[k] > 0) c[k] = Math.floor(raw[k]);
  for (const k of ['lastMsg', 'lastErr']) if (typeof raw[k] === 'string') c[k] = raw[k].slice(0, 300);
  return c;
}
export function loadSyncCfg(store = globalThis.localStorage) {
  try { const r = store.getItem(SYNC_CFG_KEY); return cleanSyncCfg(r ? JSON.parse(r) : null); } catch (_) { return emptySyncCfg(); }
}
export function saveSyncCfg(cfg, store = globalThis.localStorage) {
  try { store.setItem(SYNC_CFG_KEY, JSON.stringify(cleanSyncCfg(cfg))); return true; } catch (_) { return false; }
}
export function setAutoSync(on, store = globalThis.localStorage) { const c = loadSyncCfg(store); c.auto = on === true; return saveSyncCfg(c, store) ? c : null; }
// "Keluar" dari sinkron: hanya melupakan keadaan + pengaturan di HP ini. Catatan di HP dan di server TIDAK dihapus.
// Masuk lagi nanti = semua catatan HP dikirim sebagai "belum pernah terlihat" (isi sama dengan server = tidak ada tulis; isi beda = salinan "(konflik)").
export function putusSinkron(store = globalThis.localStorage) {
  clearSyncState(store);
  try { store.removeItem(SYNC_CFG_KEY); } catch (_) { /* abaikan */ }
}

// ---- Pesan galat dalam bahasa awam.
export function jelaskanGalatSinkron(status, errText) {
  const e = String(errText || '').slice(0, 160);
  if (status === 401) return 'Passcode salah atau sudah berubah di Worker. Buka Setelan > Kelimaa AI, ketik ulang passcode, lalu Tes sambungan.';
  if (/aksi tidak dikenal/i.test(e)) return 'Kode Worker belum yang terbaru (belum mengenal sinkron): tempel ulang worker.mjs di Cloudflare lalu Deploy.';
  if (status === 413) return 'Permintaan terlalu besar untuk Worker. Coba lagi; bila terus gagal, ada catatan yang terlalu besar.';
  if (/kv/i.test(e) && /(belum|tidak)/i.test(e)) return 'Penyimpanan KV di Worker belum terpasang. Ikuti PANDUAN_WORKER.md bagian sync.';
  if (status === 429 || status === 503) return explainWorkerError(status, e);
  return e || 'Ditolak oleh Worker (kode ' + status + ').';
}
function netMessage(e) {
  const m = String((e && e.message) || e || '').slice(0, 120);
  return /timeout|timed out|abort/i.test(m) ? 'Waktu habis: Worker tidak menjawab. Cek internet, lalu coba lagi.' : 'Tidak ada internet atau Worker tidak terjangkau' + (m ? ' (' + m + ')' : '') + '.';
}

// ---- Saluran ke Worker untuk runSync. Melempar Error{message, status}; runSync yang menangkapnya jadi `summary.error`.
// http: pengirim (bawaan nativeHttp: CapacitorHttp di aplikasi, fetch di peramban). Dapat diganti untuk tes.
export function makeSyncCall(conn, http = nativeHttp) {
  const u = cleanUrl(conn && conn.url), k = cleanPass(conn && conn.key);
  if (!u.ok || !k.ok) { const m = (!u.ok ? u : k).msg; return async () => { throw Object.assign(new Error(m), { status: 0 }); }; }
  return async function call(body) {
    let r;
    try { r = await http({ method: 'POST', url: u.value + '/', body: JSON.stringify({ ...body, key: k.value }), timeout: SYNC_TIMEOUT }); }
    catch (e) { throw Object.assign(new Error(netMessage(e)), { status: 0 }); }
    const st = (r && r.status) || 0; let j = null;
    try { const o = JSON.parse(String((r && r.text) || '')); j = o && typeof o === 'object' ? o : null; } catch (_) { j = null; }
    if (j && j.ok === true && st >= 200 && st < 300) return j;
    if (j) throw Object.assign(new Error(jelaskanGalatSinkron(st, j.error)), { status: st, raw: String(j.error || '').slice(0, 160) });
    throw Object.assign(new Error('Jawaban Worker tidak dikenali (kode ' + st + '). Cek alamat Worker di Setelan > Kelimaa AI.'), { status: st });
  };
}

// ---- Status untuk layar SY3b. kode: belum (tanpa sambungan) | jalan | galat | tunggu | ok. Murni.
export function statusSinkron({ data, state, conn, cfg, busy, now = Date.now() }) {
  const c = cleanSyncCfg(cfg);
  if (!conn) return { kode: 'belum', dirty: 0, label: 'Belum tersambung' };
  const dirty = data && state ? dirtyCount(data, state, now) : 0;
  if (busy) return { kode: 'jalan', dirty, label: 'Menyinkronkan\u2026' };
  if (c.lastErr) return { kode: 'galat', dirty, label: 'Gagal: ' + c.lastErr };
  if (dirty > 0) return { kode: 'tunggu', dirty, label: dirty + ' perubahan menunggu dikirim' };
  return { kode: 'ok', dirty: 0, label: c.lastOkAt ? 'Tersinkron' : 'Siap, belum pernah disinkronkan' };
}
export const sedangSinkron = () => running;
// Rev 421 / SY3b: satu pintu untuk layar Sync. Urutan: belum > jalan > off (tanpa internet) > galat > tunggu > ok. Murni terhadap `store`.
export function bacaStatus({ data, store = globalThis.localStorage, busy = false, online = true, now = Date.now() } = {}) {
  const conn = loadConn(store), cfg = loadSyncCfg(store), state = loadSyncState(store);
  const s = statusSinkron({ data, state, conn, cfg, busy, now });
  if (s.kode !== 'belum' && s.kode !== 'jalan' && online === false) { s.kode = 'off'; s.label = 'Offline'; }
  return { ...s, cfg, conn: !!conn, notes: data && Array.isArray(data.notes) ? data.notes.length : 0 };
}

// Nada hasil untuk toast: 'galat' | 'peringatan' | 'sukses'. Murni.
export function nadaHasil(res) {
  if (!res || res.ok === false) return 'galat';
  const s = res.summary;
  return s && (s.rejected.length || s.skipped.length || s.held || s.conflicts || s.truncated) ? 'peringatan' : 'sukses';
}

let running = false;
// Satu putaran penuh. opts: { data, persist, sanitize, afterApply?, store?, http?, conn?, now?, newId?, allowMassDelete? }.
//  - data/persist/sanitize WAJIB (persist = fungsi menyimpan data aplikasi; boleh mengembalikan {ok:false,msg}; sanitize = notes.sanitize, seperti impor Markdown).
//  - afterApply(touched, summary): dipanggil bila ada catatan ditambah/diubah/dihapus dari server (SY3b: jadwal ulang pengingat + segarkan tampilan). Galat di dalamnya DITELAN.
// Hasil: { ok, msg, summary, held, status, passcode?, workerLama?, needConn?, busy?, saveFailed? }. Tidak pernah melempar.
export async function jalankanSinkron(opts = {}) {
  const o = opts || {}, store = o.store || globalThis.localStorage, now = Number(o.now) || Date.now();
  if (running) return { ok: false, busy: true, msg: 'Sinkron sedang berjalan.', summary: null, held: null, status: 0 };
  if (!o.data || typeof o.persist !== 'function' || typeof o.sanitize !== 'function') return { ok: false, msg: 'Sinkron tidak bisa dimulai: data atau penyimpanan belum disiapkan.', summary: null, held: null, status: 0 };
  const conn = o.conn || loadConn(store);
  if (!conn) return { ok: false, needConn: true, msg: 'Belum tersambung. Isi alamat Worker dan passcode di Setelan > Kelimaa AI dulu.', summary: null, held: null, status: 0 };
  running = true;
  try {
    const state = loadSyncState(store); let sum;
    try { sum = await runSync(o.data, state, makeSyncCall(conn, o.http), { sanitize: o.sanitize, newId: o.newId || defaultNewId, now }, { allowMassDelete: o.allowMassDelete === true }); }
    catch (e) { const m = 'Sinkron berhenti: ' + String((e && e.message) || e).slice(0, 160); return endCfg(store, now, { ok: false, msg: m, errText: m, summary: null, held: null, status: 0 }); }
    const t = sum.touched, changed = t.added.length + t.updated.length + t.removed.length;
    // Simpan data DULU; keadaan sinkron baru disimpan bila data berhasil tersimpan (bila tidak, putaran berikutnya aman mengulang: kiriman isi sama dijawab ok).
    let saveFailed = '';
    if (changed || sum.pushed || sum.deleted) { try { const r = o.persist(); if (r && r.ok === false) saveFailed = String(r.msg || 'Gagal menyimpan.'); } catch (e) { saveFailed = 'Gagal menyimpan.'; } }
    if (!saveFailed) saveSyncState(state, store);
    if (changed && typeof o.afterApply === 'function') { try { o.afterApply(t, sum); } catch (_) { /* tampilan/pengingat tidak boleh menggagalkan sinkron */ } }
    const err = sum.error ? describeSync(sum) : saveFailed ? 'Sinkron berhasil tetapi data gagal disimpan di HP: ' + saveFailed : '';
    const res = { ok: !err, msg: err || describeSync(sum), summary: sum, held: sum.held || null, status: sum.error ? sum.error.status : 0 };
    if (err) res.errText = sum.error ? sum.error.message : err;
    if (saveFailed) res.saveFailed = saveFailed;
    if (sum.error && sum.error.status === 401) res.passcode = true;
    if (sum.error && /belum yang terbaru/.test(sum.error.message)) res.workerLama = true;
    return endCfg(store, now, res);
  } finally { running = false; }
}
function endCfg(store, now, res) {
  const c = loadSyncCfg(store); c.lastTryAt = now;
  if (res.ok) { c.lastOkAt = now; c.lastMsg = res.msg; c.lastErr = ''; } else c.lastErr = res.errText || res.msg;
  saveSyncCfg(c, store);
  return res;
}
