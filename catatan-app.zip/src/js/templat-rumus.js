// Rev 288 / T3: kelompok templat "Rumus" bagian 1 (data murni, tanpa impor): Hitung dasar + Statistik. Bentuk: lihat lembar-templat.js.
// Teks rumus yang dipamerkan ditulis TANPA "=" di depan (D-T2); kolom Hasil berisi rumus hidup, kolom Gunanya menjelaskan.
const RED = { bg: '#FEE2E2', fg: '#991B1B' }, GRN = { bg: '#DCFCE7', fg: '#166534' };
const DASAR = {
  id: 'rumus-dasar', name: 'Rumus · Hitung dasar', desc: 'Tambah, kurang, kali, bagi, persen, pembulatan: contoh hidup dan kegunaannya.',
  tab: 'Hitung dasar', w: [130, 80, 80, 100, 170, 330], head: true, nfc: ['', 'num', 'num', 'num', '', ''],
  rows: [
    ['Operasi', 'Angka A', 'Angka B', 'Hasil', 'Rumus', 'Gunanya'],
    ['Tambah', 120, 30, '=B2+C2', 'B2+C2', 'Menjumlahkan dua angka, mis. dua pemasukan.'],
    ['Kurang', 120, 30, '=B3-C3', 'B3-C3', 'Selisih, mis. pemasukan dikurangi pengeluaran.'],
    ['Kali', 12, 8, '=B4*C4', 'B4*C4', 'Harga satuan x jumlah barang.'],
    ['Bagi (aman)', 100, 8, '=IFERROR(B5/C5;0)', 'IFERROR(B5/C5;0)', 'Bagi; kalau pembaginya 0, hasilnya 0 (bukan galat).'],
    ['Sisa bagi', 17, 5, '=MOD(B6;C6)', 'MOD(B6;C6)', 'Sisa pembagian, mis. sisa barang saat dibagi rata.'],
    ['Pangkat', 2, 10, '=POWER(B7;C7)', 'POWER(B7;C7)', 'A pangkat B (sama dengan A^B).'],
    ['Akar kuadrat', 144, '', '=SQRT(B8)', 'SQRT(B8)', 'Akar kuadrat; angka negatif jadi #NUM!.'],
    ['Persen dari', 45, 60, { v: '=IFERROR(B9/C9;0)', nf: 'pct' }, 'IFERROR(B9/C9;0)', 'A itu berapa persen dari B (capaian, kehadiran).'],
    ['Naik/turun persen', 80000, 100000, { v: '=IFERROR((C10-B10)/B10;0)', nf: 'pct' }, 'IFERROR((C10-B10)/B10;0)', 'Perubahan harga lama (A) ke baru (B); minus = turun.'],
    ['Tambah persen', 200000, { v: 0.11, nf: 'pct' }, '=B11*(1+C11)', 'B11*(1+C11)', 'Harga plus pajak atau biaya persen, mis. PPN 11%.'],
    ['Kurangi persen', 150000, { v: 0.2, nf: 'pct' }, '=B12*(1-C12)', 'B12*(1-C12)', 'Harga sesudah diskon persen.'],
    ['Bulatkan', 2.789, 1, '=ROUND(B13;C13)', 'ROUND(B13;C13)', 'Dibulatkan ke B desimal (terdekat).'],
    ['Bulatkan ke atas', 2.231, 1, '=ROUNDUP(B14;C14)', 'ROUNDUP(B14;C14)', 'Selalu dibulatkan ke atas, mis. hitung jumlah kardus.'],
    ['Bulatkan ke bawah', 2.789, 1, '=ROUNDDOWN(B15;C15)', 'ROUNDDOWN(B15;C15)', 'Selalu dibulatkan ke bawah.'],
    ['Buang desimal', 7.9, '', '=INT(B16)', 'INT(B16)', 'Ambil bilangan bulatnya saja (7,9 jadi 7).'],
    ['Nilai mutlak', -45, '', '=ABS(B17)', 'ABS(B17)', 'Buang tanda minus, mis. selisih tanpa arah.'],
  ],
  guide: [
    ['Apa ini?', 'Daftar hitungan dasar yang paling sering dipakai, tiap baris satu contoh yang hidup.'],
    ['Cara memakai', 'Ubah angka di kolom Angka A dan Angka B. Kolom Hasil langsung ikut berubah.'],
    ['Memakai rumusnya', 'Kolom Rumus hanya teks contoh. Di selmu sendiri ketik tanda = lalu rumusnya, mis. =B2+C2.'],
    ['Pemisah', 'Antar bagian dalam rumus dipisah titik koma (;), bukan koma.'],
    ['Persen', 'Sel berformat persen: ketik 11% atau 0,11 untuk 11 persen.'],
  ],
};

const NAMA = ['Ani', 'Budi', 'Cici', 'Dedi', 'Eka', 'Fajar', 'Gita', 'Hadi'], NILAI = [85, 70, 92, 60, 78, 92, 55, 88];
const ukur = (nama, fx, guna) => [nama, fx, fx.slice(1), guna];
const FN = [
  ukur('Jumlah (SUM)', '=SUM(B2:B9)', 'Menjumlahkan semua nilai.'),
  ukur('Rata-rata (AVERAGE)', '=AVERAGE(B2:B9)', 'Jumlah dibagi banyaknya angka.'),
  ukur('Terkecil (MIN)', '=MIN(B2:B9)', 'Nilai paling rendah.'),
  ukur('Terbesar (MAX)', '=MAX(B2:B9)', 'Nilai paling tinggi.'),
  ukur('Banyak angka (COUNT)', '=COUNT(B2:B9)', 'Mencacah sel yang berisi ANGKA saja.'),
  ukur('Banyak terisi (COUNTA)', '=COUNTA(A2:A9)', 'Mencacah semua sel yang terisi, teks juga.'),
  ukur('Nilai tengah (MEDIAN)', '=MEDIAN(B2:B9)', 'Nilai di tengah setelah diurutkan.'),
  ukur('Terbesar ke-3 (LARGE)', '=LARGE(B2:B9;3)', 'Nilai terbesar urutan ke-k, di sini k = 3.'),
  ukur('Terkecil ke-2 (SMALL)', '=SMALL(B2:B9;2)', 'Nilai terkecil urutan ke-k, di sini k = 2.'),
  ukur('Peringkat Ani (RANK)', '=RANK(B2;$B$2:$B$9)', 'Urutan nilai Ani dari semua (1 = tertinggi).'),
];
const STAT = {
  id: 'rumus-statistik', name: 'Rumus · Statistik', desc: 'Jumlah, rata-rata, terkecil, terbesar, median, peringkat: dari data nilai kecil.',
  tab: 'Statistik', w: [90, 70, 24, 170, 90, 190, 320], head: true, nfc: ['', 'num', '', '', 'num', '', ''],
  rows: [
    ['Nama', 'Nilai', '', 'Ukuran', 'Hasil', 'Rumus', 'Gunanya'],
    ...NAMA.map((n, i) => [n, NILAI[i], '', ...(FN[i] ? [FN[i][0], FN[i][1], FN[i][2], FN[i][3]] : [])]),
    ['', '', '', ...FN[8]],
    ['', '', '', ...FN[9]],
  ],
  rules: [{ c: 'B', op: 'gte', a: 90, ...GRN }, { c: 'B', op: 'lt', a: 60, ...RED }],
  guide: [
    ['Apa ini?', 'Delapan nilai contoh di kiri, sepuluh hitungan statistik yang sering dipakai di kanan.'],
    ['Cara memakai', 'Ganti nilai di kolom Nilai (sampai baris 9) atau tambah barisnya. Kolom Hasil ikut berubah.'],
    ['Menambah data', 'Kalau datanya lebih panjang, ubah rentang di rumus, mis. B2:B9 jadi B2:B20.'],
    ['COUNT atau COUNTA?', 'COUNT hanya mencacah angka. COUNTA mencacah semua yang terisi, termasuk nama.'],
    ['Warna di kolom Nilai', '90 ke atas hijau, di bawah 60 merah. Ubah lewat Lainnya > Warna bersyarat.'],
    ['Rumus', 'Kolom Rumus hanya teks contoh. Di selmu sendiri ketik tanda = lalu rumusnya.'],
  ],
};

export const RUMUS = [DASAR, STAT];
