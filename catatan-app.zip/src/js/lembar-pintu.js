// Rev 192 / P2a: PINTU lembar kerja = satu-satunya jalan main.js, notes.js, dan settings.js ke layar lembar kerja (lembar-ui.js)
// dan ke daftar templat (lembar-templat.js). Kedua modul besar itu (sekitar 120 KB mentah, plus lembar-alat, rumus-bantu,
// lembar-filter, lembar-rentang, lembar-baris yang hanya dipakai lembar-ui) dimuat SAAT DIBUTUHKAN lewat import() dinamis,
// bukan saat aplikasi dibuka. Modul ini kecil, TANPA impor statis, dan tidak menyentuh data: ia hanya meneruskan.
// Aturan keras: closeSheet()/isSheetOpen() SINKRON (dipanggil handleBack di main.js, tombol Kembali native menunggu jawabannya).
let mod = null, loading = null, tpl = null, tplLoading = null;
let seq = 0, pendingTok = 0; // pendingTok > 0 = ada permintaan buka yang masih menunggu modul

function load(spec) { return spec === 'ui' ? import('./lembar-ui.js') : import('./lembar-templat.js'); }

// Muat layar lembar kerja (ber-cache). Gagal muat = cache dikosongkan supaya ketukan berikutnya mencoba lagi.
export function loadSheetUI() {
  if (mod) return Promise.resolve(mod);
  if (!loading) loading = load('ui').then((m) => { mod = m; return m; }, (e) => { loading = null; throw e; });
  return loading;
}
// Muat daftar templat (ber-cache), dipakai dialog Buat dari templat.
export function loadTemplates() {
  if (tpl) return Promise.resolve(tpl);
  if (!tplLoading) tplLoading = load('tpl').then((m) => { tpl = m; return m; }, (e) => { tplLoading = null; throw e; });
  return tplLoading;
}

export const sheetUILoaded = () => !!mod;
// Rev 192d / P2c: pemuatan awal DIAM-DIAM (dipanggil main.js saat idle sesudah gambar pertama). Gagal = diabaikan; ketukan nanti mencoba lagi.
export const warmSheetUI = () => { loadSheetUI().catch(() => {}); };
// Penanda singkat: ketukan buka yang masih menunggu modul sesudah 150 ms memanggil fungsi pasangan main.js (toast); hasilnya (fungsi) dipanggil untuk menutup penanda.
let notice = null; export const setSlowNotice = (fn) => { notice = typeof fn === 'function' ? fn : null; };
export const isSheetOpen = () => !!pendingTok || !!(mod && mod.isSheetOpen());

// Tombol Kembali HP. Sinkron. Bila modul belum datang dan ketukan buka masih menunggu, Kembali MEMBATALKAN bukaan itu
// (layar tidak muncul sesudahnya); bila layar terbuka, ditutup lewat modulnya; selain itu false (tidak ada yang ditangani).
export function closeSheet() {
  if (pendingTok) { pendingTok = 0; return true; }
  return mod ? mod.closeSheet() : false;
}

// Buka layar lembar kerja. Mengembalikan Promise<boolean>: true = layar dibuka, false = dibatalkan/diganti ketukan lebih baru/lembar tak sah.
// Gagal memuat modul = Promise ditolak (pemanggil menampilkan toast "Lembar kerja gagal dibuka.").
export function openSheet(opts) {
  const tok = ++seq; pendingTok = tok;
  let tm = 0, end = null;
  const done = () => { clearTimeout(tm); try { if (end) end(); } catch (_) { /* hanya penanda */ } end = null; };
  if (!mod) tm = setTimeout(() => { if (pendingTok === tok && notice) { try { end = notice(); } catch (_) { /* hanya penanda */ } } }, 150);
  return loadSheetUI().then((m) => {
    done();
    if (pendingTok !== tok) return false; // Kembali ditekan, atau ketukan yang lebih baru menggantikan
    pendingTok = 0;
    return m.openSheet(opts);
  }, (e) => { done(); if (pendingTok === tok) pendingTok = 0; throw e; });
}
