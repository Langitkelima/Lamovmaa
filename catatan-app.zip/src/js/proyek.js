// Rev 234 / Tahap 7a (SCHEMA 19): model data PROYEK, murni (tanpa DOM, tanpa impor). BELUM ada UI dan BELUM terhubung ke AI.
// Bentuk: data.projects = [{ id, name, desc, status, at, due?, tasks: [idTugas], notes: [idCatatan] }].
// Modul INI dimuat saat startup (dipakai normalize()); alat untuk UI ada di proyek-alat.js (dimuat malas, Rev 234).
// Batas: maks. 30 proyek, nama 60 huruf, deskripsi 500 huruf, maks. 100 tugas dan 100 catatan per proyek.
// Catatan Privat TIDAK PERNAH boleh ditautkan (pruneProjectLinks hanya menerima id dari data.notes).
export const MAX_PROJECTS = 30, MAX_NAME = 60, MAX_DESC = 500, MAX_LINKS = 100;
export const STATUSES = ['aktif', 'selesai', 'arsip'];
const pos = (x) => (typeof x === 'number' && Number.isFinite(x) && x > 0 ? Math.trunc(x) : 0);
const ids = (a) => {
  const out = [], seen = new Set();
  for (const v of Array.isArray(a) ? a : []) {
    if (typeof v !== 'string' || !v || v.length > 60 || seen.has(v)) continue;
    seen.add(v); out.push(v); if (out.length >= MAX_LINKS) break;
  }
  return out;
};
// Satu proyek bersih, atau null bila rusak (bukan objek, id/nama kosong). Tidak pernah melempar.
export function cleanProject(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const id = typeof raw.id === 'string' ? raw.id.trim() : '';
  const name = typeof raw.name === 'string' ? raw.name.trim().slice(0, MAX_NAME) : '';
  if (!id || id.length > 60 || !name) return null;
  const p = {
    id, name,
    desc: typeof raw.desc === 'string' ? raw.desc.trim().slice(0, MAX_DESC) : '',
    status: STATUSES.includes(raw.status) ? raw.status : 'aktif',
    at: pos(raw.at),
    tasks: ids(raw.tasks), notes: ids(raw.notes),
  };
  const due = pos(raw.due); if (due) p.due = due;
  return p;
}
// Daftar bersih: bukan larik = kosong; id ganda dan entri rusak dibuang; maks. MAX_PROJECTS.
export function cleanProjects(raw) {
  const out = [], seen = new Set();
  for (const r of Array.isArray(raw) ? raw : []) {
    const p = cleanProject(r);
    if (!p || seen.has(p.id)) continue;
    seen.add(p.id); out.push(p); if (out.length >= MAX_PROJECTS) break;
  }
  return out;
}
// Buang tautan ke tugas/catatan yang sudah tidak ada. Catatan hanya dari data.notes (bukan Privat, bukan Tempat sampah).
export function pruneProjectLinks(data) {
  if (!data || !Array.isArray(data.projects)) return;
  const t = new Set((Array.isArray(data.tasks) ? data.tasks : []).filter((x) => x && typeof x.id === 'string').map((x) => x.id));
  const n = new Set((Array.isArray(data.notes) ? data.notes : []).filter((x) => x && typeof x.id === 'string').map((x) => x.id));
  for (const p of data.projects) { p.tasks = p.tasks.filter((id) => t.has(id)); p.notes = p.notes.filter((id) => n.has(id)); }
}
