// ZIP murni (Rev 44, tahap G2 gambar): metode "store" (tanpa kompresi) + CRC32, tanpa pustaka. Tanpa DOM, dites di Node.
// Gambar sudah terkompres (WebP/JPEG), jadi menyimpannya apa adanya tidak merugikan. Batas: tanpa ZIP64 (maks. 4 GB, jauh di atas kebutuhan).

let TABLE = null;
function table() {
  if (TABLE) return TABLE;
  TABLE = new Uint32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; TABLE[n] = c >>> 0; }
  return TABLE;
}
export function crc32(bytes, start = 0) {
  const t = table(); let c = (start ^ 0xFFFFFFFF) >>> 0;
  for (let i = 0; i < bytes.length; i++) c = t[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

const SIG_LOCAL = 0x04034b50, SIG_CENTRAL = 0x02014b50, SIG_END = 0x06054b50;
const enc = new TextEncoder(), dec = new TextDecoder('utf-8');
const dosTime = (d) => ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF;
const dosDate = (d) => (Math.max(0, d.getFullYear() - 1980) << 9 | (d.getMonth() + 1) << 5 | d.getDate()) & 0xFFFF;

export const isZipBytes = (b) => !!b && b.length >= 4 && b[0] === 0x50 && b[1] === 0x4B && b[2] === 0x03 && b[3] === 0x04;

// Perakit bertahap: add(nama, byte) mengembalikan potongan (header + isi) untuk ditulis SEGERA, lalu byte boleh dilepas;
// finish() mengembalikan daftar pusat + penutup. Hanya metadata kecil yang disimpan di memori.
export function zipWriter(now = new Date()) {
  const entries = []; let offset = 0; let done = false;
  const time = dosTime(now), date = dosDate(now);
  return {
    add(name, data) {
      if (done) throw new Error('ZIP sudah ditutup');
      const nameB = enc.encode(String(name)), crc = crc32(data), size = data.length;
      if (size >= 0xFFFFFFFF || nameB.length > 0xFFFF) throw new Error('Berkas terlalu besar untuk ZIP');
      const head = new Uint8Array(30 + nameB.length), v = new DataView(head.buffer);
      v.setUint32(0, SIG_LOCAL, true); v.setUint16(4, 20, true); v.setUint16(6, 0x0800, true); v.setUint16(8, 0, true);
      v.setUint16(10, time, true); v.setUint16(12, date, true); v.setUint32(14, crc, true); v.setUint32(18, size, true); v.setUint32(22, size, true);
      v.setUint16(26, nameB.length, true); v.setUint16(28, 0, true); head.set(nameB, 30);
      entries.push({ nameB, crc, size, offset });
      offset += head.length + size;
      return [head, data];
    },
    finish() {
      if (done) throw new Error('ZIP sudah ditutup'); done = true;
      const parts = []; let cdSize = 0;
      for (const e of entries) {
        const c = new Uint8Array(46 + e.nameB.length), v = new DataView(c.buffer);
        v.setUint32(0, SIG_CENTRAL, true); v.setUint16(4, 20, true); v.setUint16(6, 20, true); v.setUint16(8, 0x0800, true); v.setUint16(10, 0, true);
        v.setUint16(12, time, true); v.setUint16(14, date, true); v.setUint32(16, e.crc, true); v.setUint32(20, e.size, true); v.setUint32(24, e.size, true);
        v.setUint16(28, e.nameB.length, true); v.setUint32(42, e.offset, true); c.set(e.nameB, 46);
        parts.push(c); cdSize += c.length;
      }
      const end = new Uint8Array(22), v = new DataView(end.buffer);
      v.setUint32(0, SIG_END, true); v.setUint16(8, entries.length, true); v.setUint16(10, entries.length, true); v.setUint32(12, cdSize, true); v.setUint32(16, offset, true);
      parts.push(end);
      return parts;
    },
  };
}
// Bantu untuk tes dan berkas kecil: rakit seluruh ZIP sekaligus.
export function buildZip(files, now) {
  const w = zipWriter(now), parts = [];
  for (const f of files) parts.push(...w.add(f.name, f.data));
  parts.push(...w.finish());
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0)); let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}

const bufOf = async (blob, a, b) => new Uint8Array(await blob.slice(a, b).arrayBuffer());

// Baca daftar isi dari "blob" (File/Blob atau objek serupa dengan size dan slice(a,b).arrayBuffer()). Tidak memuat seluruh berkas.
// Mengembalikan [{ name, crc, size, start }] (start = posisi byte isi). Melempar Error berpesan jelas bila rusak/tidak didukung.
export async function readZipIndex(blob) {
  const size = Number(blob && blob.size);
  if (!Number.isFinite(size) || size < 22) throw new Error('Berkas ZIP rusak atau kosong.');
  const tailLen = Math.min(size, 65557), tailStart = size - tailLen;
  const tail = await bufOf(blob, tailStart, size);
  let e = -1;
  for (let i = tail.length - 22; i >= 0; i--) { if (tail[i] === 0x50 && tail[i + 1] === 0x4B && tail[i + 2] === 0x05 && tail[i + 3] === 0x06) { e = i; break; } }
  if (e < 0) throw new Error('Berkas ZIP rusak (penutup tidak ditemukan).');
  const ev = new DataView(tail.buffer, tail.byteOffset + e, 22);
  const count = ev.getUint16(10, true), cdSize = ev.getUint32(12, true), cdOff = ev.getUint32(16, true);
  if (count === 0xFFFF || cdSize === 0xFFFFFFFF || cdOff === 0xFFFFFFFF) throw new Error('ZIP64 tidak didukung.');
  if (cdOff + cdSize > size) throw new Error('Berkas ZIP rusak (daftar isi di luar berkas).');
  const cd = await bufOf(blob, cdOff, cdOff + cdSize), cv = new DataView(cd.buffer, cd.byteOffset, cd.length);
  const out = []; let p = 0;
  for (let n = 0; n < count; n++) {
    if (p + 46 > cd.length || cv.getUint32(p, true) !== SIG_CENTRAL) throw new Error('Berkas ZIP rusak (daftar isi).');
    const method = cv.getUint16(p + 10, true), crc = cv.getUint32(p + 16, true), csize = cv.getUint32(p + 20, true), usize = cv.getUint32(p + 24, true);
    const nl = cv.getUint16(p + 28, true), xl = cv.getUint16(p + 30, true), cl = cv.getUint16(p + 32, true), lo = cv.getUint32(p + 42, true);
    if (p + 46 + nl > cd.length) throw new Error('Berkas ZIP rusak (nama).');
    const name = dec.decode(cd.subarray(p + 46, p + 46 + nl));
    p += 46 + nl + xl + cl;
    if (method !== 0 || csize !== usize) throw new Error('ZIP ini memakai kompresi. Hanya cadangan ZIP dari Notes Kelimaa yang didukung.');
    if (lo + 30 > size) throw new Error('Berkas ZIP rusak (posisi isi).');
    const lh = await bufOf(blob, lo, lo + 30), lv = new DataView(lh.buffer, lh.byteOffset, 30);
    if (lv.getUint32(0, true) !== SIG_LOCAL) throw new Error('Berkas ZIP rusak (header isi).');
    const start = lo + 30 + lv.getUint16(26, true) + lv.getUint16(28, true);
    if (start + usize > size) throw new Error('Berkas ZIP terpotong.');
    out.push({ name, crc, size: usize, start });
  }
  return out;
}
// Baca satu isi dan cek CRC. Melempar bila tidak cocok (berkas rusak).
export async function readZipEntry(blob, entry) {
  const b = await bufOf(blob, entry.start, entry.start + entry.size);
  if (b.length !== entry.size || crc32(b) !== entry.crc) throw new Error('Isi ZIP rusak (' + entry.name + ').');
  return b;
}
export const utf8 = { encode: (s) => enc.encode(String(s)), decode: (b) => dec.decode(b) };

// Base64 <-> byte, dipotong per bagian supaya tidak membuat string raksasa sekaligus.
export function bytesToBase64(b) {
  let s = ''; const step = 0x8000;
  for (let i = 0; i < b.length; i += step) s += String.fromCharCode.apply(null, b.subarray(i, i + step));
  return btoa(s);
}
export function base64ToBytes(str) {
  const s = atob(String(str).replace(/^data:[^,]*,/, '')); const b = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
  return b;
}
