// Rev 300a: ALAT BEKUKAN BARIS/KOLOM (MURNI: tanpa DOM/penyimpanan/native/eval). Dimuat MALAS (hanya lembar-ui dan lembar-alat); model dasar (fz, cleanFreeze, geser saat sisip/hapus) ada di lembar.js.
// tab.fz = { r, c } = JUMLAH baris teratas dan kolom paling kiri yang dibekukan; hanya ada bila dipakai. Batas: 5 baris, 3 kolom, selalu menyisakan 1 baris + 1 kolom bebas.
import { MAX_FZ_ROWS, MAX_FZ_COLS, cleanFreeze } from './lembar.js';
export { MAX_FZ_ROWS, MAX_FZ_COLS };
// Baca saja: { r, c } sah untuk ukuran tab (nol = tidak beku).
export const getFreeze = (tab) => (tab && Array.isArray(tab.rows) && Array.isArray(tab.cols) && cleanFreeze(tab.fz, tab.rows, tab.cols)) || { r: 0, c: 0 };
export const isFrozen = (tab) => { const f = getFreeze(tab); return f.r > 0 || f.c > 0; };
// Ganti jumlah beku. patch = { r?, c? } (yang tidak disebut tetap). Nilai di luar batas DIPOTONG ke batas. Mengembalikan true bila berubah.
export function setFreeze(tab, patch = {}) {
  if (!tab || !Array.isArray(tab.rows) || !Array.isArray(tab.cols)) return false;
  const cur = getFreeze(tab), p = patch && typeof patch === 'object' ? patch : {};
  const next = cleanFreeze({ r: 'r' in p ? p.r : cur.r, c: 'c' in p ? p.c : cur.c }, tab.rows, tab.cols);
  const before = JSON.stringify(tab.fz || null);
  if (next) tab.fz = next; else delete tab.fz;
  return JSON.stringify(tab.fz || null) !== before;
}
// Satu langkah dari menu: mode 'none' | 'row1' | 'row2' | 'col1' | 'rows' (sampai baris terpilih) | 'cols' (sampai kolom terpilih) | 'both'.
// ri/ci = INDEKS baris/kolom sel terpilih. Mengembalikan { changed, r, c }.
export function freezeBy(tab, mode, ri, ci) {
  const okI = (v) => Number.isInteger(v) && v >= 0; let p = null;
  if (mode === 'none') p = { r: 0, c: 0 }; else if (mode === 'row1') p = { r: 1 }; else if (mode === 'row2') p = { r: 2 }; else if (mode === 'col1') p = { c: 1 };
  else if (mode === 'rows' && okI(ri)) p = { r: ri + 1 }; else if (mode === 'cols' && okI(ci)) p = { c: ci + 1 }; else if (mode === 'both' && okI(ri) && okI(ci)) p = { r: ri + 1, c: ci + 1 };
  const changed = p ? setFreeze(tab, p) : false, now = getFreeze(tab);
  return { changed, r: now.r, c: now.c };
}
// Ringkasan untuk teks menu / toast: "2 baris + 1 kolom", "1 baris", "tidak ada".
export function freezeLabel(tab) {
  const f = getFreeze(tab), a = [];
  if (f.r) a.push(f.r + ' baris'); if (f.c) a.push(f.c + ' kolom');
  return a.length ? a.join(' + ') : 'tidak ada';
}
// Rev 304a: KOLOM BEKU MENYEMPIT SEMENTARA saat lembar digeser ke kanan (hanya tampilan; lebar kolom di data TIDAK berubah).
// W = lebar penuh kolom beku (px), x = scrollLeft, cap = lebar beku maksimal di layar (px). Faktor 1 (normal) di posisi awal; makin digeser makin kecil
// SEJALAN dengan geseran (tepi kanan kolom beku bertemu kolom berikutnya tanpa celah) sampai batas cap/W. W <= cap = selalu 1.
export function fzScale(W, x, cap) {
  if (!(W > 0) || !(cap > 0) || W <= cap) return 1; const s = (W - Math.max(0, Number(x) || 0)) / W; return Math.min(1, Math.max(cap / W, s));
}
// Terlalu lebar sekalipun disempitkan penuh: faktor terkecil < 0,4 (kolom beku > 2,5 x cap).
export const fzTooWide = (W, cap) => W > cap * 2.5;
