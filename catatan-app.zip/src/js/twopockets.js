// Rev 52: UJI KECIL sambungan ke Two Pockets (aplikasi keuangan berdua, Google Apps Script).
// Hanya MENANYAKAN dua hal: "apakah ini benar Two Pockets?" dan "siapa pemilik passcode ini?".
// Tidak ada isi catatan/tugas yang dikirim. Alamat + passcode disimpan di kunci localStorage TERPISAH
// (bukan di data aplikasi), jadi TIDAK ikut ekspor cadangan JSON/ZIP maupun cadangan otomatis.
import { isNative, nativePlugin } from './native.js';

export const CONN_KEY = 'kelimaa_twopockets';
const TIMEOUT = 20000; // Apps Script bisa lambat saat "dingin"; beri waktu lebih lama daripada pratinjau tautan.
const URL_RE = /^https:\/\/script\.google\.com\/(?:a\/macros\/[A-Za-z0-9._-]+\/|macros\/)s\/[A-Za-z0-9_-]+\/exec$/;

// Mengembalikan { ok, value } atau { ok:false, msg }. Query (?...) dan spasi dibuang.
export function cleanUrl(raw) {
  const v = String(raw == null ? '' : raw).trim().split(/[?#]/)[0].replace(/\/+$/, '');
  if (!v) return { ok: false, msg: 'Alamat belum diisi.' };
  if (!URL_RE.test(v)) return { ok: false, msg: 'Alamat harus berbentuk https://script.google.com/macros/s/…/exec (alamat "Aplikasi web" dari Apps Script).' };
  return { ok: true, value: v };
}

export function cleanKey(raw) {
  const v = String(raw == null ? '' : raw).trim();
  if (!v) return { ok: false, msg: 'Passcode belum diisi.' };
  if (v.length > 64 || /[\u0000-\u001f]/.test(v)) return { ok: false, msg: 'Passcode tidak valid.' };
  return { ok: true, value: v };
}

export function loadConn(store = globalThis.localStorage) {
  try {
    const o = JSON.parse(store.getItem(CONN_KEY) || 'null');
    if (!o || typeof o !== 'object') return null;
    const u = cleanUrl(o.url), k = cleanKey(o.key);
    if (!u.ok || !k.ok) return null;
    return { url: u.value, key: k.value, me: typeof o.me === 'string' ? o.me.slice(0, 20) : '', testedAt: Number(o.testedAt) || 0 };
  } catch (_) { return null; }
}
export function saveConn(conn, store = globalThis.localStorage) {
  const u = cleanUrl(conn && conn.url), k = cleanKey(conn && conn.key);
  if (!u.ok) return u;
  if (!k.ok) return k;
  try {
    store.setItem(CONN_KEY, JSON.stringify({ url: u.value, key: k.value, me: String((conn && conn.me) || '').slice(0, 20), testedAt: Number(conn && conn.testedAt) || 0 }));
    return { ok: true };
  } catch (e) { return { ok: false, msg: 'Gagal menyimpan di HP.' }; }
}
export function clearConn(store = globalThis.localStorage) { try { store.removeItem(CONN_KEY); } catch (_) { /* abaikan */ } }

// Pengirim HTTP: di aplikasi lewat CapacitorHttp (bebas aturan CORS, mengikuti pengalihan Apps Script);
// di peramban lewat fetch (kemungkinan terhalang CORS, hanya untuk pengembangan).
async function nativeHttp({ method, url, body }) {
  if (isNative()) {
    const r = await nativePlugin('CapacitorHttp').request({
      url, method, responseType: 'text', connectTimeout: TIMEOUT, readTimeout: TIMEOUT,
      headers: method === 'POST' ? { 'Content-Type': 'text/plain;charset=utf-8' } : {},
      data: method === 'POST' ? body : undefined,
    });
    return { status: r && r.status, text: typeof (r && r.data) === 'string' ? r.data : JSON.stringify((r && r.data) || '') };
  }
  const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), TIMEOUT);
  try {
    const r = await fetch(url, { method, body, signal: ctl.signal, headers: method === 'POST' ? { 'Content-Type': 'text/plain;charset=utf-8' } : {} });
    return { status: r.status, text: await r.text() };
  } finally { clearTimeout(tm); }
}

function parseJson(text) {
  try { const o = JSON.parse(String(text || '')); return o && typeof o === 'object' ? o : null; } catch (_) { return null; }
}
function netMsg(e) {
  const m = String((e && e.message) || e || '').slice(0, 120);
  return /timeout|timed out|abort/i.test(m) ? 'Waktu habis (Apps Script tidak menjawab dalam 20 detik).' : 'Tidak tersambung: ' + (m || 'tanpa keterangan') + '. Cek internet.';
}

// Dua langkah terpisah supaya jelas bagian mana yang bermasalah:
//  1) GET  alamat?ping=1            -> apakah alamat benar, bisa dijangkau, dan pengalihan Apps Script diikuti
//  2) POST {key, action:'whoami'}   -> apakah passcode benar + POST juga lolos pengalihan
// Mengembalikan { ok, me, steps:[{id, ok, msg}] }. Tidak pernah melempar error.
export async function testConnection(conn, http = nativeHttp) {
  const u = cleanUrl(conn && conn.url), k = cleanKey(conn && conn.key);
  if (!u.ok) return { ok: false, me: '', steps: [{ id: 'input', ok: false, msg: u.msg }] };
  if (!k.ok) return { ok: false, me: '', steps: [{ id: 'input', ok: false, msg: k.msg }] };
  const steps = [];

  // Langkah 1: ping tanpa passcode
  try {
    const r = await http({ method: 'GET', url: u.value + '?ping=1' });
    const j = parseJson(r && r.text);
    if (r && r.status >= 200 && r.status < 300 && j && j.ok === true && j.app === 'TWO POCKETS') steps.push({ id: 'ping', ok: true, msg: 'Alamat benar, Two Pockets menjawab.' });
    else if (r && r.status >= 200 && r.status < 300 && !j) steps.push({ id: 'ping', ok: false, msg: 'Menjawab, tetapi bukan jawaban Two Pockets (mungkin halaman masuk Google). Pastikan akses "Aplikasi web" diatur ke "Siapa saja" dan alamat memakai versi terbaru.' });
    else if (r && r.status && (r.status < 200 || r.status >= 300)) steps.push({ id: 'ping', ok: false, msg: 'Server membalas kode ' + r.status + '. Cek alamat /exec.' });
    else steps.push({ id: 'ping', ok: false, msg: 'Jawaban tidak dikenali. Cek alamat dan versi Two Pockets yang sudah di-deploy.' });
  } catch (e) { steps.push({ id: 'ping', ok: false, msg: netMsg(e) }); }
  if (!steps[0].ok) return { ok: false, me: '', steps };

  // Langkah 2: periksa passcode (tidak menyentuh Google Sheets)
  try {
    const r = await http({ method: 'POST', url: u.value, body: JSON.stringify({ key: k.value, action: 'whoami' }) });
    const j = parseJson(r && r.text);
    if (j && j.ok === true && typeof j.me === 'string' && j.me) { steps.push({ id: 'whoami', ok: true, msg: 'Passcode benar. Terhubung sebagai ' + j.me + '.' }); return { ok: true, me: j.me, steps }; }
    if (j && j.ok === false) {
      const e = String(j.error || '');
      steps.push({ id: 'whoami', ok: false, msg: /aksi tidak dikenal/i.test(e) ? 'Two Pockets belum diperbarui: pasang Code.gs terbaru lalu Deploy > New version.' : e.slice(0, 140) || 'Ditolak oleh Two Pockets.' });
    } else steps.push({ id: 'whoami', ok: false, msg: 'Kirim passcode tidak berhasil: jawaban tidak dikenali (kode ' + (r && r.status) + '). Langkah 1 berhasil tetapi POST gagal; kabari ini ke pembuat aplikasi.' });
  } catch (e) { steps.push({ id: 'whoami', ok: false, msg: netMsg(e) }); }
  return { ok: false, me: '', steps };
}

// ===== Rev 57: daftar jatuh tempo servis & pajak (aksi dueList di Code.gs, HANYA BACA) =====
// Hasilnya disimpan di kunci localStorage TERPISAH (sama seperti sambungan), jadi tidak ikut cadangan.
export const DUE_KEY = 'kelimaa_twopockets_due';
const DUE_STATUS = ['terlambat', 'segera', 'aman', 'belum'];
const BILL_STATUS = ['terlambat', 'segera', 'aman'];
const ID_OK = /^[A-Za-z0-9_-]{1,40}$/;
const DATE_OK = /^\d{4}-\d{2}-\d{2}$/;
const toInt = (v) => (v === null || v === undefined || v === '' || !Number.isFinite(Number(v)) ? null : Math.trunc(Number(v)));

// Bentuk jawaban Code.gs: { today, items:[{ id, vehicle, name, kind, dueDate, dueKm, daysLeft, kmLeft, status }] }.
// Semua isian dibersihkan: jawaban dari luar tidak dipercaya mentah-mentah.
export function normalizeDue(raw) {
  const src = raw && Array.isArray(raw.items) ? raw.items : [];
  const items = [];
  for (const r of src.slice(0, 100)) {
    if (!r || typeof r !== 'object' || !ID_OK.test(String(r.id || ''))) continue;
    items.push({
      id: String(r.id),
      vehicle: String(r.vehicle == null ? '' : r.vehicle).slice(0, 40),
      name: String(r.name == null ? '' : r.name).slice(0, 60),
      kind: r.kind === 'pajak' ? 'pajak' : 'servis',
      dueDate: DATE_OK.test(String(r.dueDate || '')) ? String(r.dueDate) : '',
      dueKm: Math.max(0, toInt(r.dueKm) || 0),
      daysLeft: toInt(r.daysLeft),
      kmLeft: toInt(r.kmLeft),
      status: DUE_STATUS.includes(r.status) ? r.status : 'belum',
    });
  }
  return { today: DATE_OK.test(String((raw && raw.today) || '')) ? String(raw.today) : '', items };
}

// Rev 62: data tagihan dibersihkan terpisah dari item servis/pajak.
const TIME_OK = /^(?:[01]\d|2[0-3]):[0-5]\d$/;
export function normalizeBills(raw) {
  const src = raw && Array.isArray(raw.bills) ? raw.bills : [];
  const bills = [];
  for (const r of src.slice(0, 100)) {
    if (!r || typeof r !== 'object' || !ID_OK.test(String(r.id || '')) || !DATE_OK.test(String(r.nextDue || ''))) continue;
    const remind = [];
    if (Array.isArray(r.remind)) for (const x of r.remind.slice(0, 4)) {
      const d = toInt(x && x.d), t = String((x && x.t) || '');
      if (d !== null && d >= 0 && d <= 30 && TIME_OK.test(t) && !remind.some(y => y.d === d && y.t === t)) remind.push({ d, t });
    }
    bills.push({ id: String(r.id), name: String(r.name || 'Tagihan').slice(0, 60), amount: Math.max(0, toInt(r.amount) || 0), repeat: ['monthly','yearly','once'].includes(r.repeat) ? r.repeat : 'once', nextDue: String(r.nextDue), daysLeft: toInt(r.daysLeft), status: BILL_STATUS.includes(r.status) ? r.status : 'aman', remind });
  }
  return bills;
}

// Rev 63: utang & piutang berjatuh tempo (Code.gs dueList_ -> due.debts). HANYA BACA.
// id dibatasi 34 karakter karena kunci pengaturan alarmnya 'dbt_' + id harus lolos ID_OK (maks. 40).
export function normalizeDebts(raw) {
  const src = raw && Array.isArray(raw.debts) ? raw.debts : [];
  const debts = [];
  for (const r of src.slice(0, 100)) {
    if (!r || typeof r !== 'object' || !/^[A-Za-z0-9_-]{1,34}$/.test(String(r.id || '')) || !DATE_OK.test(String(r.due || ''))) continue;
    if (r.kind !== 'utang' && r.kind !== 'piutang') continue;
    debts.push({
      id: String(r.id), kind: r.kind, person: String(r.person == null ? '' : r.person).slice(0, 40) || '(tanpa nama)',
      left: Math.max(0, toInt(r.left) || 0), due: String(r.due), daysLeft: toInt(r.daysLeft),
      status: BILL_STATUS.includes(r.status) ? r.status : 'aman',
    });
  }
  return debts;
}

// Mengembalikan { ok, me, due } atau { ok:false, msg }. Tidak pernah melempar error.
export async function fetchDue(conn, http = nativeHttp) {
  const u = cleanUrl(conn && conn.url), k = cleanKey(conn && conn.key);
  if (!u.ok) return { ok: false, msg: u.msg };
  if (!k.ok) return { ok: false, msg: k.msg };
  try {
    const r = await http({ method: 'POST', url: u.value, body: JSON.stringify({ key: k.value, action: 'dueList' }) });
    const j = parseJson(r && r.text);
    if (j && j.ok === true && j.due && typeof j.due === 'object') return { ok: true, me: typeof j.me === 'string' ? j.me.slice(0, 20) : '', due: { ...normalizeDue(j.due), bills: normalizeBills(j.due), debts: normalizeDebts(j.due) } };
    if (j && j.ok === false) {
      const e = String(j.error || '');
      return { ok: false, msg: /aksi tidak dikenal/i.test(e) ? 'Two Pockets belum diperbarui: pasang Code.gs terbaru lalu Deploy > New version.' : e.slice(0, 140) || 'Ditolak oleh Two Pockets.' };
    }
    return { ok: false, msg: 'Jawaban Two Pockets tidak dikenali (kode ' + (r && r.status) + ').' };
  } catch (e) { return { ok: false, msg: netMsg(e) }; }
}

// Cache: { fetchedAt, today, items, sched:[id alarm yang dipasang], alarm:true/false }
export function loadDueCache(store = globalThis.localStorage) {
  try {
    const o = JSON.parse(store.getItem(DUE_KEY) || 'null');
    if (!o || typeof o !== 'object') return null;
    const d = normalizeDue({ today: o.today, items: o.items });
    const bills = normalizeBills({ bills: o.bills });
    const debts = normalizeDebts({ debts: o.debts });
    return {
      fetchedAt: Number(o.fetchedAt) || 0, today: d.today, items: d.items, bills, debts,
      sched: Array.isArray(o.sched) ? o.sched.filter((s) => typeof s === 'string' && s.length > 0 && s.length <= 80).slice(0, 300) : [],
      alarm: o.alarm !== false,
    };
  } catch (_) { return null; }
}
export function saveDueCache(c, store = globalThis.localStorage) {
  try {
    store.setItem(DUE_KEY, JSON.stringify({ fetchedAt: Number(c && c.fetchedAt) || 0, today: (c && c.today) || '', items: (c && c.items) || [], bills: (c && c.bills) || [], debts: (c && c.debts) || [], sched: (c && c.sched) || [], alarm: !(c && c.alarm === false) }));
    return true;
  } catch (_) { return false; }
}
export function clearDueCache(store = globalThis.localStorage) { try { store.removeItem(DUE_KEY); } catch (_) { /* abaikan */ } }

// ===== Rev 61: pengaturan alarm PER ITEM (jam, berapa hari sebelum, ingatkan bila terlambat, nyala/mati) =====
// Disimpan di kunci localStorage TERPISAH (bukan di cache daftar, karena cache diganti tiap dimuat ulang). Tidak ikut cadangan.
export const CFG_KEY = 'kelimaa_twopockets_alarmcfg';
export const DEFAULT_CFG = { on: true, hour: 8, min: 0, before: [7, 0], late: true };
export const BEFORE_CHOICES = [30, 14, 7, 3, 2, 1, 0]; // 0 = tepat hari jatuh tempo
const intIn = (v, lo, hi, d) => { const n = Number(v); return Number.isInteger(n) && n >= lo && n <= hi ? n : d; };
export function cleanCfg(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  const before = Array.isArray(r.before)
    ? [...new Set(r.before.map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 365))].sort((a, b) => b - a).slice(0, 8)
    : DEFAULT_CFG.before.slice();
  const out = { on: r.on !== false, hour: intIn(r.hour, 0, 23, DEFAULT_CFG.hour), min: intIn(r.min, 0, 59, DEFAULT_CFG.min), before, late: r.late !== false };
  if (r.mode === 'alarm') out.mode = 'alarm'; // Rev 378 / AL2b: `mode` hanya ada bila 'alarm' (bentuk lama utuh)
  return out;
}
export function isDefaultCfg(c) {
  const a = cleanCfg(c);
  return a.on && a.hour === DEFAULT_CFG.hour && a.min === DEFAULT_CFG.min && a.late && a.before.join(',') === DEFAULT_CFG.before.join(',') && a.mode !== 'alarm'; // Rev 378 / AL2b: pilihan alarm TIDAK boleh dianggap bawaan (setItemCfg menghapus yang bawaan)
}
export function loadAlarmCfg(store = globalThis.localStorage) {
  try {
    const o = JSON.parse(store.getItem(CFG_KEY) || 'null');
    if (!o || typeof o !== 'object' || Array.isArray(o)) return {};
    const out = {};
    for (const id of Object.keys(o).slice(0, 200)) if (ID_OK.test(id)) out[id] = cleanCfg(o[id]);
    return out;
  } catch (_) { return {}; }
}
export function saveAlarmCfg(all, store = globalThis.localStorage) {
  try { store.setItem(CFG_KEY, JSON.stringify(all || {})); return true; } catch (_) { return false; }
}
export function clearAlarmCfg(store = globalThis.localStorage) { try { store.removeItem(CFG_KEY); } catch (_) { /* abaikan */ } }
