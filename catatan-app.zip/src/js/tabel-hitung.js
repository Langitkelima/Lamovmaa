// Rev 98 / U4c: mesin angka tabel (MURNI: tanpa DOM, tanpa Intl; dites di Node). Belum dipanggil UI (baris Total menyusul di U4d).
// Format Indonesia: titik = pemisah ribuan, koma = desimal. Teks kosong atau bukan angka DIABAIKAN (bukan dihitung 0).

export const DASH = '—';
// Fungsi total (nilai `data-f` di U4d) dan labelnya.
export const TOTAL_FUNCS = [
  { id: 'sum', label: 'Jumlah' },
  { id: 'avg', label: 'Rata-rata' },
  { id: 'cnt', label: 'Hitung' },
  { id: 'min', label: 'Min' },
  { id: 'max', label: 'Maks' },
];
export const isTotalFunc = (f) => TOTAL_FUNCS.some((x) => x.id === f);

// Mengubah teks sel menjadi angka, atau null bila bukan angka.
// Diterima: "1.234,5", "Rp 12.000", "Rp. 1.500,25", "-Rp 5.000", "Rp -5.000", "50%", "-3", "+4", "1234", "0,5", " 7 ".
// Ditolak (null): "", "abc", "12 kg", "1e5", "1.2.3", "1,2,3", "1,234.5" (gaya Inggris campur), "--3", "Rp".
// Asumsi (belum dikonfirmasi pengguna): satu titik yang BUKAN kelompok ribuan ("3.14", "1.5") dibaca desimal; "50%" bernilai 50.
export function parseNum(text) {
  if (typeof text === 'number') return Number.isFinite(text) ? text : null;
  if (typeof text !== 'string') return null;
  let t = text.replace(/[\u00a0\u2009\u202f\s]+/g, ' ').trim();
  if (!t) return null;
  let neg = false;
  const sign = () => { const m = /^([+\-\u2212])\s*/.exec(t); if (m) { if (m[1] !== '+') neg = !neg; t = t.slice(m[0].length); return true; } return false; };
  sign();
  const rp = /^rp\.?\s*/i.exec(t); if (rp) { t = t.slice(rp[0].length); sign(); }
  if (/^[+\-\u2212]/.test(t)) return null; // tanda ganda
  t = t.replace(/\s*%$/, '').trim();
  if (!t || !/^[0-9][0-9.,]*$/.test(t)) return null;
  const commas = (t.match(/,/g) || []).length, dots = (t.match(/\./g) || []).length;
  let intPart, frac = '';
  if (commas > 1) return null;
  if (commas === 1) {
    const [a, b] = t.split(',');
    if (!b || /\./.test(b)) return null; // "1,234.5" atau "1,"
    if (dots && !/^\d{1,3}(\.\d{3})+$/.test(a)) return null;
    intPart = a.replace(/\./g, ''); frac = b;
  } else if (dots === 0) {
    intPart = t;
  } else if (/^\d{1,3}(\.\d{3})+$/.test(t)) {
    intPart = t.replace(/\./g, ''); // ribuan
  } else if (dots === 1 && /^\d+\.\d+$/.test(t)) {
    const [a, b] = t.split('.'); intPart = a; frac = b; // "3.14" = desimal
  } else return null;
  if (!/^\d+$/.test(intPart) || (frac && !/^\d+$/.test(frac))) return null;
  const n = Number(intPart + (frac ? '.' + frac : ''));
  if (!Number.isFinite(n)) return null;
  return neg && n !== 0 ? -n : n;
}

// Format hasil: pemisah ribuan titik, desimal koma, maksimal 2 desimal (dibulatkan, nol di belakang dibuang), tanpa "-0".
export function formatNum(n) {
  if (typeof n !== 'number' || !Number.isFinite(n)) return DASH;
  let r = Math.round((Math.abs(n) + Number.EPSILON * Math.abs(n)) * 100) / 100;
  if (r === 0) return '0';
  const [i, f = ''] = r.toFixed(2).split('.');
  const grouped = i.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  const dec = f.replace(/0+$/, '');
  return (n < 0 ? '-' : '') + grouped + (dec ? ',' + dec : '');
}

// Total satu kolom. `cells` = teks sel (baris data saja; pemanggil membuang baris header dan baris total).
// Mengembalikan { fn, count, value, text }: value = angka atau null; text = tampilan.
// Tanpa satu pun angka: jumlah/rata-rata/min/maks = "—" (value null), hitung = "0".
export function columnTotal(cells, fn) {
  const f = isTotalFunc(fn) ? fn : 'sum';
  const nums = [];
  for (const c of Array.isArray(cells) ? cells : []) { const n = parseNum(c); if (n !== null) nums.push(n); }
  const count = nums.length;
  if (f === 'cnt') return { fn: f, count, value: count, text: String(count) };
  if (!count) return { fn: f, count, value: null, text: DASH };
  let value;
  if (f === 'sum') value = nums.reduce((a, b) => a + b, 0);
  else if (f === 'avg') value = nums.reduce((a, b) => a + b, 0) / count;
  else if (f === 'min') value = Math.min(...nums);
  else value = Math.max(...nums);
  return { fn: f, count, value, text: formatNum(value) };
}
