// Rev 191 (P1): pembantu waktu buka. MURNI (tanpa DOM, dites di Node). Tanpa impor apa pun.
// mark: tanda waktu (performance.mark) berawalan "kelimaa:"; dibaca skrip ukur di tools/ (bukan fitur pengguna). Gagal = diabaikan.
export function mark(name, perf = globalThis.performance) {
  try { if (perf && typeof perf.mark === 'function') perf.mark('kelimaa:' + name); } catch (_) { /* hanya pengukuran */ }
}
// afterFirstPaint: jalankan fn SEKALI, sesudah gambar pertama (rAF lalu setTimeout 0). Cadangan: setelah maxWait ms bila rAF tidak pernah
// dipanggil (WebView yang dibuka dalam keadaan tersembunyi menahan rAF). Kesalahan di fn tidak menjatuhkan aplikasi tetapi tetap dicatat.
export function afterFirstPaint(fn, env = globalThis, maxWait = 1200) {
  let done = false;
  const run = () => {
    if (done) return false;
    done = true;
    try { fn(); } catch (e) { try { console.error('Tugas tertunda gagal:', e); } catch (_) { /* abaikan */ } }
    return true;
  };
  const st = env.setTimeout.bind(env), raf = env.requestAnimationFrame;
  if (typeof raf === 'function') raf.call(env, () => st(run, 0)); else st(run, 0);
  st(run, maxWait);
  return run;
}
