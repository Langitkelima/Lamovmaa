// Cadangan yang membawa gambar (Rev 44, tahap G2). Semua akses penyimpanan lewat objek FS (plugin Filesystem) yang DISUNTIKKAN,
// jadi bisa dites di Node dengan FS palsu. Aturan emas: bila catatan tidak punya gambar, tidak ada satu pun fungsi di sini yang dipanggil
// jalur cadangan lama (JSON biasa) tetap persis seperti sebelumnya.
import { refsOfData, imagePath, imageFileName, IMAGE_DIR, ID_RE, parseRefs, buildFigure, newImageId, checkSource, MAX_IMAGES_PER_NOTE, MAX_SOURCE_BYTES } from './gambar.js';
export { parseRefs, imagePath, imageFileName, IMAGE_DIR, buildFigure, newImageId, checkSource, MAX_IMAGES_PER_NOTE, MAX_SOURCE_BYTES }; // Rev 397: jalur resmi bagi modul ekspor (gambar.js hanya boleh diimpor modul yang terdaftar di tests/gambar.test.mjs)
import { zipWriter, readZipIndex, readZipEntry, isZipBytes, bytesToBase64, base64ToBytes, utf8 } from './zip.js';
import { BACKUP_BASE_DIR } from './logic.js';

export const IMG_DIRECTORY = 'DATA'; // berkas gambar: Directory.Data/gambar/ID.ext
export const ZIP_JSON = 'data.json';
export const MAX_JSON_BYTES = 20 * 1024 * 1024;
export const MAX_ZIP_BYTES = 400 * 1024 * 1024;
export const MAX_ENTRY_BYTES = 8 * 1024 * 1024; // satu gambar terkompres ~250 KB; 8 MB sudah sangat longgar
const FLUSH_BYTES = 768 * 1024;
const IMG_NAME_RE = /^gambar\/([A-Za-z0-9]{10,40})\.(webp|jpg|png)$/;
const msgOf = (e) => String((e && e.message) || e || 'gagal').slice(0, 120);

// Rujukan gambar UNIK (per ID) di seluruh data: catatan, privat, dan Tempat sampah.
export function uniqueRefs(data) {
  const seen = new Map();
  for (const r of refsOfData(data)) if (!seen.has(r.id)) seen.set(r.id, r);
  return [...seen.values()];
}

// ---------- Ekspor manual: ZIP ditulis bertahap ke CACHE ----------
// Mengembalikan { uri, included, missing: [id...] }. Gambar yang berkasnya hilang dilewati (dicatat di missing), bukan menggagalkan ekspor.
export async function writeZipToCache(FS, data, jsonText, name, now = new Date()) {
  const refs = uniqueRefs(data), w = zipWriter(now);
  let buf = [], size = 0, first = true, uri = '';
  const flush = async (force) => {
    if (!size || (!force && size < FLUSH_BYTES)) return;
    const all = new Uint8Array(size); let o = 0; for (const p of buf) { all.set(p, o); o += p.length; }
    buf = []; size = 0;
    const b64 = bytesToBase64(all);
    if (first) { const r = await FS.writeFile({ path: name, data: b64, directory: 'CACHE' }); uri = (r && r.uri) || ''; first = false; }
    else await FS.appendFile({ path: name, data: b64, directory: 'CACHE' });
  };
  const push = async (parts) => { for (const p of parts) { buf.push(p); size += p.length; } await flush(false); };
  const missing = []; let included = 0;
  try {
    await push(w.add(ZIP_JSON, utf8.encode(jsonText)));
    for (const ref of refs) {
      let bytes = null;
      try { const r = await FS.readFile({ path: imagePath(ref), directory: IMG_DIRECTORY }); if (r && typeof r.data === 'string') bytes = base64ToBytes(r.data); } catch (_) { /* hilang */ }
      if (!bytes || !bytes.length) { missing.push(ref.id); continue; }
      await push(w.add(IMAGE_DIR + '/' + imageFileName(ref), bytes)); included++;
    }
    await push(w.finish()); await flush(true);
  } catch (e) {
    try { await FS.deleteFile({ path: name, directory: 'CACHE' }); } catch (_) { /* abaikan */ }
    throw e;
  }
  return { uri, included, missing };
}

// ---------- Cadangan otomatis: salin berkas gambar ke <folder>/gambar/ (hanya yang belum ada) ----------
export async function copyImagesToBackupFolder(FS, refs, b) {
  const directory = BACKUP_BASE_DIR[b.base] || BACKUP_BASE_DIR.documents, destDir = b.folder + '/' + IMAGE_DIR;
  const out = { copied: 0, skipped: 0, failed: 0 };
  try { await FS.mkdir({ path: destDir, directory, recursive: true }); } catch (_) { /* sudah ada */ }
  for (const ref of refs) {
    const to = destDir + '/' + imageFileName(ref);
    let exists = false;
    try { await FS.stat({ path: to, directory }); exists = true; } catch (_) { /* belum ada */ }
    if (exists) { out.skipped++; continue; }
    try { await FS.copy({ from: imagePath(ref), directory: IMG_DIRECTORY, to, toDirectory: directory }); out.copied++; } catch (_) { out.failed++; }
  }
  return out;
}
export function imagesNote(g) {
  if (!g) return '';
  const p = [];
  if (g.copied) p.push(g.copied + ' gambar disalin');
  if (g.skipped) p.push(g.skipped + ' sudah ada');
  if (g.failed) p.push(g.failed + ' gagal');
  return p.length ? ' (gambar: ' + p.join(', ') + ')' : '';
}

// ---------- Pulihkan ----------
// Baca berkas cadangan yang dipilih. JSON lama -> { kind:'json', text, images:[] }. ZIP -> { kind:'zip', text, images:[entri] }.
// Melempar Error berpesan jelas (aman ditampilkan). Tidak menulis apa pun.
export async function readBackupFile(file) {
  const head = new Uint8Array(await file.slice(0, 4).arrayBuffer());
  if (!isZipBytes(head)) {
    if (file.size > MAX_JSON_BYTES) throw new Error('Berkas terlalu besar.');
    return { kind: 'json', text: await file.text(), images: [] };
  }
  if (file.size > MAX_ZIP_BYTES) throw new Error('Berkas ZIP terlalu besar.');
  const index = await readZipIndex(file);
  const j = index.find((e) => e.name === ZIP_JSON);
  if (!j) throw new Error('ZIP ini bukan cadangan Notes Kelimaa (data.json tidak ada).');
  if (j.size > MAX_JSON_BYTES) throw new Error('Isi data di dalam ZIP terlalu besar.');
  const text = utf8.decode(await readZipEntry(file, j));
  // Hanya nama gambar yang sah diterima (mencegah nama aneh/penunjuk folder); entri lain diabaikan.
  const images = index.filter((e) => IMG_NAME_RE.test(e.name));
  for (const e of images) if (e.size > MAX_ENTRY_BYTES) throw new Error('Ada gambar di dalam ZIP yang terlalu besar.');
  return { kind: 'zip', text, images };
}
// Tulis semua gambar dari ZIP ke Directory.Data/gambar/, satu per satu, dengan cek CRC. Dipanggil SEBELUM data diganti: bila gagal,
// data aplikasi belum tersentuh. Berkas yang sudah tertulis tidak berbahaya (nama acak, isi sah).
export async function writeBackupImages(FS, file, entries, onProgress) {
  let n = 0;
  for (const e of entries) {
    const bytes = await readZipEntry(file, e);
    await FS.writeFile({ path: e.name, data: bytesToBase64(bytes), directory: IMG_DIRECTORY, recursive: true });
    n++; if (onProgress) onProgress(n, entries.length);
  }
  return n;
}
// Rujukan di data yang gambarnya TIDAK ada di ZIP (cadangan dibuat saat berkas gambar hilang).
export function idsMissingFromZip(data, entries) {
  const have = new Set(entries.map((e) => { const m = IMG_NAME_RE.exec(e.name); return m && m[1]; }));
  return uniqueRefs(data).filter((r) => !have.has(r.id)).map((r) => r.id);
}
// Usaha terbaik setelah memulihkan dari JSON (tanpa berkas gambar): cari gambar di <folder cadangan>/gambar/ lalu salin balik.
// Bisa gagal (mis. Android membatasi akses ke berkas dari pemasangan lama); kegagalan hanya dihitung. Tidak pernah melempar.
export async function restoreImagesFromBackupFolder(FS, data) {
  const out = { restored: 0, present: 0, missing: 0 };
  const refs = uniqueRefs(data); if (!refs.length) return out;
  const b = data.settings && data.settings.backup;
  const dir = b && BACKUP_BASE_DIR[b.base], folder = b && typeof b.folder === 'string' ? b.folder : '';
  try { await FS.mkdir({ path: IMAGE_DIR, directory: IMG_DIRECTORY, recursive: true }); } catch (_) { /* sudah ada */ }
  for (const ref of refs) {
    try { await FS.stat({ path: imagePath(ref), directory: IMG_DIRECTORY }); out.present++; continue; } catch (_) { /* belum ada */ }
    if (!dir || !folder) { out.missing++; continue; }
    try { await FS.copy({ from: folder + '/' + IMAGE_DIR + '/' + imageFileName(ref), directory: dir, to: imagePath(ref), toDirectory: IMG_DIRECTORY }); out.restored++; }
    catch (_) { out.missing++; }
  }
  return out;
}
export { msgOf, ID_RE };
