// Rev 344 / PART I5: catatan "Panduan ketikan cepat". Modul MALAS (dimuat lewat import() dari Setelan), bukan jalur buka.
// Dibuat SEKALI atas permintaan pengguna (bukan otomatis); bila catatannya sudah ada, yang ada dibuka (tanpa salinan kedua).
// Isi panduan hanya memuat pemicu yang BENAR-BENAR terpasang: tests/rev344.test.mjs mengunci tiap contoh `ketik` ke mesin pemicu.
import { newId, sharedToHtml } from './logic.js';
import { openEditor, closeEditor, sanitize } from './notes.js';

export const PANDUAN_JUDUL = 'Panduan ketikan cepat';

// kind = jenis pemicu mesin ketikan (dikunci tes); ketik = contoh persis yang diketik; hasil = yang terjadi.
export const PANDUAN = [
  { kind: 'slash', nama: 'Menu cepat', ketik: '/tab', hasil: 'Muncul menu: Daftar, Nomor, Kotak centang, Tabel, Kutipan, Tanggal, Suasana hati, Hitung mundur, Lembar kerja. Ketik beberapa huruf untuk menyaring, ketuk satu untuk menyisipkannya.' },
  { kind: 'checkbox', nama: 'Kotak centang', ketik: '[] ', hasil: 'Ketik [] lalu spasi di awal baris: baris jadi kotak centang. Backspace sekali langsung membatalkan.' },
  { kind: 'numbered', nama: 'Daftar bernomor', ketik: '1. ', hasil: 'Ketik 1. lalu spasi di awal baris: baris jadi daftar bernomor. Enter melanjutkan, Enter di nomor kosong keluar dari daftar.' },
  { kind: 'bullet', nama: 'Daftar bullet', ketik: '- ', hasil: 'Ketik - (strip) lalu spasi di awal baris: baris jadi daftar bullet. Enter melanjutkan, Enter di bullet kosong keluar dari daftar. Backspace sekali langsung membatalkan.' },
  { kind: 'calc', nama: 'Hitung cepat', ketik: '2jt*3=', hasil: 'Muncul kapsul HASIL 6.000.000. Ketuk untuk menyisipkannya sesudah tanda =. Paham rb, jt, persen (%), dan pangkat (^).' },
  { kind: 'tag', nama: 'Label cepat', ketik: '#kerja ', hasil: 'Ketik #kerja lalu spasi: muncul tawaran memasang (atau membuat) label kerja. Tulisan #kerja tetap di catatan.' },
  { kind: 'wiki', nama: 'Tautan antarcatatan', ketik: '[[rap', hasil: 'Muncul judul catatan yang cocok. Ketuk satu untuk menyisipkan tautan; ketuk tautan di isi catatan untuk membukanya.' },
  { kind: 'remind', nama: 'Pengingat', ketik: '!besok 9', hasil: 'Hanya di baris kotak centang. Muncul kapsul Ingatkan; ketuk untuk membuka lembar Ingatkan saya dengan waktu terisi (belum terjadwal sebelum Simpan). Contoh lain: !jam 9, !jumat 14.30, !15 des.' },
];

// Rev 365 / W5: format gaya WhatsApp BUKAN pemicu (tanpa kapsul), jadi daftarnya terpisah dari PANDUAN (yang dikunci ke TRIGGER_KINDS).
// tests/rev365.test.mjs menjalankan tiap `ketik` lewat mesin format-wa.js dan mengunci hasilnya.
export const PANDUAN_FORMAT = [
  { nama: 'Tebal', ketik: '*halo* ', hasil: 'Ketik *halo* lalu spasi (atau titik, koma, Enter): halo jadi tebal dan kedua bintang hilang. Backspace sekali langsung membatalkan.' },
  { nama: 'Miring', ketik: '_halo_ ', hasil: 'Ketik _halo_ lalu spasi: halo jadi miring. Gabungan *_halo_* jadi tebal dan miring. Garis bawah di dalam kata (snake_case) dan 2*3*4 tidak diubah.' },
];

export const PANDUAN_CATATAN = 'Ketik pemicu di bawah ini di catatan biasa, lalu ketuk saran yang muncul di atas bilah format. Tidak berlaku di Catatan Privat, sel tabel, dan mode Baca. Tulis AI: tahan ikon ✦ di bilah editor sampai muncul kapsul Tulis AI, lalu ketuk kapsulnya.';

export function panduanText() {
  const out = [PANDUAN_CATATAN, ''];
  for (const p of [...PANDUAN, ...PANDUAN_FORMAT]) out.push(p.nama, 'Ketik: ' + p.ketik.replace(/ $/, ' (spasi)'), p.hasil, '');
  out.pop();
  return out.join('\n');
}

export function cariPanduan(data) {
  return (data.notes || []).find((n) => n && n.title === PANDUAN_JUDUL) || null;
}

// Buat catatan biasa berisi panduan lalu buka (tanpa keyboard); bila sudah ada, buka yang ada. Mengembalikan { id, baru }.
export function bukaPanduan(ctx) {
  const { data, ui } = ctx;
  closeEditor();
  document.querySelectorAll('.ov').forEach((x) => x.remove());
  ui.tab = 'catatan'; ui.moreView = 'main'; ui.q = ''; ui.lf = '';
  let n = cariPanduan(data), baru = false;
  if (!n) {
    const text = panduanText();
    n = { id: newId(), title: PANDUAN_JUDUL, text, html: sanitize(sharedToHtml(text)), col: '', pin: false, updated: Date.now() };
    data.notes.push(n); baru = true;
    ctx.persist();
  }
  ctx.render();
  openEditor(ctx, n.id, 'note', false, true);
  return { id: n.id, baru };
}
