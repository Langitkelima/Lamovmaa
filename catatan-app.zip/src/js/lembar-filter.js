// Rev 149 / U9b-1: FILTER BARIS SEMENTARA lembar kerja (MURNI: tanpa DOM, penyimpanan, native, eval, dan TANPA mengimpor lembar.js / rumus.js).
// Filter hanya menyembunyikan baris di tampilan grid; TIDAK disimpan, tidak mengubah data, tidak memengaruhi rumus/ekspor/pulau/cadangan. Hilang saat layar lembar kerja ditutup.
// Bentuk: { c: ID kolom, k: jenis, a: nilai }. Pencocokan memakai teks TAMPIL (hasil rumus + format ikut); gt/lt memakai angka (hasil mentah, atau teks berkoma desimal).
export const FILTER_KINDS = ['contains', 'eq', 'ne', 'gt', 'lt', 'nonempty', 'empty'];
export const FILTER_LABELS = { contains: 'Berisi teks', eq: 'Sama dengan', ne: 'Bukan', gt: 'Lebih dari', lt: 'Kurang dari', nonempty: 'Tidak kosong', empty: 'Kosong' };
export const filterNeedsValue = (k) => k === 'contains' || k === 'eq' || k === 'ne' || k === 'gt' || k === 'lt';
const norm = (s) => String(s === undefined || s === null ? '' : s).trim().toLowerCase();
const toNum = (raw, text) => {
  if (typeof raw === 'number' && Number.isFinite(raw)) return raw;
  const t = String(text === undefined || text === null ? '' : text).trim().replace(/\s/g, '').replace(',', '.'); if (!t) return NaN;
  const n = Number(t); return Number.isFinite(n) ? n : NaN;
};
// Filter dibersihkan; null bila tidak sah (jenis asing, kolom hilang, nilai wajib kosong, angka tidak valid).
export function cleanFilter(raw, cols) {
  if (!raw || typeof raw !== 'object' || !FILTER_KINDS.includes(raw.k) || typeof raw.c !== 'string') return null;
  if (!Array.isArray(cols) || !cols.some((c) => c && c.id === raw.c)) return null;
  if (!filterNeedsValue(raw.k)) return { c: raw.c, k: raw.k, a: '' };
  const a = String(raw.a === undefined || raw.a === null ? '' : raw.a).trim().slice(0, 60); if (!a) return null;
  if ((raw.k === 'gt' || raw.k === 'lt') && !Number.isFinite(toNum(undefined, a))) return null;
  return { c: raw.c, k: raw.k, a };
}
// Apakah satu sel lolos? raw = nilai mentah/hasil rumus, text = teks tampil.
export function matches(flt, raw, text) {
  const t = norm(text);
  switch (flt.k) {
    case 'contains': return t.includes(norm(flt.a));
    case 'eq': return t === norm(flt.a);
    case 'ne': return t !== norm(flt.a);
    case 'nonempty': return t !== '';
    case 'empty': return t === '';
    case 'gt': { const n = toNum(raw, text), b = toNum(undefined, flt.a); return Number.isFinite(n) && Number.isFinite(b) && n > b; }
    case 'lt': { const n = toNum(raw, text), b = toNum(undefined, flt.a); return Number.isFinite(n) && Number.isFinite(b) && n < b; }
    default: return true;
  }
}
// filterRows(tab, flt, d) -> array indeks baris yang LOLOS (urutan asli). d = { raw(i,j), text(i,j) } (mis. makeDisplay). flt tidak sah = semua baris.
export function filterRows(tab, flt, d) {
  const n = tab && Array.isArray(tab.rows) ? tab.rows.length : 0, all = Array.from({ length: n }, (_, i) => i);
  const f = tab ? cleanFilter(flt, tab.cols) : null; if (!f || !d) return all;
  const j = tab.cols.findIndex((c) => c.id === f.c); if (j < 0) return all;
  const out = [];
  for (let i = 0; i < n; i++) { let raw, text; try { raw = d.raw(i, j); text = d.text(i, j); } catch (_) { raw = undefined; text = ''; } if (matches(f, raw, text)) out.push(i); }
  return out;
}
export function filterText(flt, colName) {
  if (!flt) return ''; const k = FILTER_LABELS[flt.k] || ''; return (colName ? 'Kolom ' + colName + ': ' : '') + k.toLowerCase() + (filterNeedsValue(flt.k) ? ' “' + flt.a + '”' : '');
}
