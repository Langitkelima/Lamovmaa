// Rev 126 / U8a-1: MESIN RUMUS lembar kerja (murni: tanpa DOM, penyimpanan, native, Intl, eval, impor). BELUM dipanggil UI dan BELUM disimpan di model sel.
// Bentuk SIMPAN (`cell.fx`, dipakai U8a-2): '=' + rumus dengan rujukan berbasis ID `[r2.cB]`, rentang `[r2.cB:r5.cB]`, mutlak `[$r2.$cB]`, pemisah argumen `,`, desimal `.`.
// Bentuk TAMPIL (A1): `=SUM(B2:B5;C2)`, pemisah argumen `;`, desimal `,` (juga `.`). Konversi dua arah: a1ToStored / storedToA1 (sisip/hapus baris-kolom tidak merusak rumus karena yang disimpan adalah ID).
// Fungsi tahap 1 (Q10, default): SUM AVERAGE MIN MAX COUNT COUNTA IF AND OR NOT ROUND ABS SUMIF COUNTIF TODAY NOW.
// Fungsi tahap 2 (Rev 138, saran minimal dokumen; pengguna meminta lanjut Q10 tanpa memilih daftar sendiri): IFERROR SUMIFS COUNTIFS ROUNDUP ROUNDDOWN MEDIAN. Rev 162: kelompok ANGKA (INT MOD POWER SQRT AVERAGEIF LARGE SMALL RANK) dan TEKS (CONCAT LEFT RIGHT MID LEN UPPER LOWER TRIM VALUE). Sisa usulan tahap 2 (TEXT, DATE dst., VLOOKUP dst.) BELUM.
// Galat: #DIV/0! #REF! #NAME? #VALUE! #N/A #NUM! #CIRC! (menjalar ke sel yang bergantung). Urutan hitung = topologis iteratif (tanpa rekursi antar sel), lingkaran terdeteksi.
const LIM_COLS = 26, LIM_ROWS = 500; // sama dengan MAX_COLS/MAX_ROWS di lembar.js (dikunci tes rev126; modul ini sengaja berdiri sendiri)
export const MAX_FX = 500, MAX_DEPTH = 32, MAX_ARGS = 64;

const ERR = (e) => Object.freeze({ e });
export const E = { DIV0: ERR('#DIV/0!'), REF: ERR('#REF!'), NAME: ERR('#NAME?'), VALUE: ERR('#VALUE!'), NA: ERR('#N/A'), NUM: ERR('#NUM!'), CIRC: ERR('#CIRC!') };
export const isErr = (v) => v !== null && typeof v === 'object' && typeof v.e === 'string';
const isRng = (v) => v !== null && typeof v === 'object' && v.rng === true;
class Syn extends Error {}

// ---------------------------------------------------------------- nilai & koersi
const NUMTXT = /^\s*[+-]?(?:\d+(?:[.,]\d+)?|[.,]\d+)(?:[eE][+-]?\d+)?\s*$/;
export function numToText(n) { if (!Number.isFinite(n)) return ''; const t = String(Number(n.toPrecision(15))); return t === '-0' ? '0' : t; }
function num(v) {
  if (isErr(v)) return v; if (isRng(v)) return E.VALUE;
  if (typeof v === 'number') return v; if (v === null || v === undefined) return 0; if (typeof v === 'boolean') return v ? 1 : 0;
  if (typeof v === 'string') { if (!NUMTXT.test(v)) return E.VALUE; const n = Number(v.trim().replace(',', '.')); return Number.isFinite(n) ? n : E.VALUE; }
  return E.VALUE;
}
function bool(v) {
  if (isErr(v)) return v; if (isRng(v)) return E.VALUE;
  if (typeof v === 'boolean') return v; if (typeof v === 'number') return v !== 0; if (v === null || v === undefined) return false;
  if (typeof v === 'string') { const u = v.trim().toUpperCase(); if (u === 'TRUE') return true; if (u === 'FALSE') return false; }
  return E.VALUE;
}
const text = (v) => (v === null || v === undefined ? '' : typeof v === 'boolean' ? (v ? 'TRUE' : 'FALSE') : typeof v === 'number' ? numToText(v) : String(v));
const rank = (v) => (typeof v === 'number' ? 0 : typeof v === 'string' ? 1 : 2);
function compare(a, b) {
  if (a === null || a === undefined) a = b === null || b === undefined ? 0 : typeof b === 'string' ? '' : typeof b === 'boolean' ? false : 0;
  if (b === null || b === undefined) b = typeof a === 'string' ? '' : typeof a === 'boolean' ? false : 0;
  const ra = rank(a), rb = rank(b); if (ra !== rb) return ra < rb ? -1 : 1;
  if (ra === 1) { const x = a.toLowerCase(), y = b.toLowerCase(); return x < y ? -1 : x > y ? 1 : 0; }
  if (ra === 0) { a = Number(a.toPrecision(15)); b = Number(b.toPrecision(15)); } // seperti Excel: banding 15 digit signifikan (0,1+0,2 = 0,3)
  return a < b ? -1 : a > b ? 1 : 0;
}
// Format hasil untuk layar: desimal koma bila comma = true (bawaan). Galat tampil apa adanya, kosong = ''.
export function valueToText(v, { comma = true } = {}) { if (isErr(v)) return v.e; const t = text(v); return typeof v === 'number' && comma ? t.replace('.', ',') : t; }
export const serialOf = (ms) => { const d = new Date(ms); return Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(1899, 11, 30)) / 86400000); }; // nomor seri gaya Excel (1 Jan 1900 = 1)
const nowSerial = (ms) => { const d = new Date(ms); return serialOf(ms) + (d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds() + d.getMilliseconds() / 1000) / 86400; };
function roundDir(x, d, up) { const f = 10 ** Math.abs(d); let v = d >= 0 ? Math.abs(x) * f : Math.abs(x) / f; v = Number(v.toPrecision(15)); v = up ? Math.ceil(v) : Math.floor(v); v = d >= 0 ? v / f : v * f; return x < 0 && v !== 0 ? -v : v; } // Rev 138: ROUNDUP (menjauhi nol) / ROUNDDOWN (menuju nol); toPrecision(15) agar 1,15*100 tidak jadi 114,99999999999999
function roundHalfAway(x, d) { const f = 10 ** Math.abs(d); let v = d >= 0 ? Math.abs(x) * f : Math.abs(x) / f; v = Math.floor(Number(v.toPrecision(15)) + 0.5); v = d >= 0 ? v / f : v * f; return x < 0 && v !== 0 ? -v : v; }

// ---------------------------------------------------------------- tokenizer
const ID_REF = /\[(\$?)(r[A-Za-z0-9]{1,23})\.(\$?)([cx][A-Za-z0-9]{1,23})(?::(\$?)(r[A-Za-z0-9]{1,23})\.(\$?)([cx][A-Za-z0-9]{1,23}))?\]/y;
const A1_REF = /(\$?)([A-Za-z]{1,3})(\$?)(\d{1,4})(?![A-Za-z0-9_.(])/y;
const NUM_ID = /(?:\d+(?:\.\d+)?|\.\d+)(?:[eE][+-]?\d+)?/y, NUM_A1 = /(?:\d+(?:[.,]\d+)?|\.\d+)(?:[eE][+-]?\d+)?/y;
const IDENT = /[A-Za-z_][A-Za-z0-9_.]*/y;
function a1Ref(m) { const col = m[2].length === 1 ? m[2].toUpperCase().charCodeAt(0) - 65 : -1, row = Number(m[4]) - 1; return { r: row, c: col, ar: !!m[3], ac: !!m[1], bad: col < 0 || col >= LIM_COLS || row < 0 || row >= LIM_ROWS }; }
function tokenize(src, mode) {
  const A1 = mode === 'a1', out = [], n = src.length; let i = 0;
  while (i < n) {
    const c = src[i];
    if (c === ' ' || c === '\t' || c === '\n' || c === '\r') { i++; continue; }
    if (c === '"') {
      let j = i + 1, s = '';
      for (;;) { if (j >= n) return { error: 'Tanda kutip belum ditutup' }; if (src[j] === '"') { if (src[j + 1] === '"') { s += '"'; j += 2; continue; } break; } s += src[j++]; }
      out.push({ t: 'str', v: s }); i = j + 1; continue;
    }
    if (c === '#') { if (src.startsWith('#REF!', i)) { out.push({ t: 'referr' }); i += 5; continue; } return { error: 'Karakter # tidak dikenal' }; }
    if (!A1 && c === '[') {
      ID_REF.lastIndex = i; const m = ID_REF.exec(src); if (!m) return { error: 'Rujukan sel tidak valid' };
      const t = { t: 'ref', a: { r: m[2], c: m[4], ar: !!m[3], ac: !!m[1] } }; if (m[6]) t.b = { r: m[6], c: m[8], ar: !!m[7], ac: !!m[5] };
      out.push(t); i += m[0].length; continue;
    }
    if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(src[i + 1] || ''))) {
      const re = A1 ? NUM_A1 : NUM_ID; re.lastIndex = i; const m = re.exec(src); const v = Number(m[0].replace(',', '.'));
      if (!Number.isFinite(v)) return { error: 'Angka terlalu besar' };
      out.push({ t: 'num', v }); i += m[0].length; continue;
    }
    if (A1 && (c === '$' || /[A-Za-z]/.test(c))) {
      A1_REF.lastIndex = i; const m = A1_REF.exec(src);
      if (m) {
        const t = { t: 'ref', a: a1Ref(m) }; i += m[0].length;
        if (src[i] === ':') { A1_REF.lastIndex = i + 1; const m2 = A1_REF.exec(src); if (!m2) return { error: 'Rentang sel tidak valid' }; t.b = a1Ref(m2); i += 1 + m2[0].length; }
        if (t.a.bad || (t.b && t.b.bad)) t.bad = true;
        out.push(t); continue;
      }
    }
    if (/[A-Za-z_]/.test(c)) {
      IDENT.lastIndex = i; const m = IDENT.exec(src); const name = m[0].toUpperCase(); i += m[0].length;
      let k = i; while (k < n && (src[k] === ' ' || src[k] === '\t')) k++;
      if (src[k] === '(') out.push({ t: 'fn', v: name });
      else if (name === 'TRUE' || name === 'FALSE') out.push({ t: 'bool', v: name === 'TRUE' });
      else out.push({ t: 'name', v: m[0] });
      continue;
    }
    if (c === '(' || c === ')') { out.push({ t: c }); i++; continue; }
    if (c === ';' ) { if (!A1) return { error: 'Pemisah argumen harus koma di bentuk simpan' }; out.push({ t: 'sep' }); i++; continue; }
    if (c === ',') { out.push({ t: 'sep' }); i++; continue; }
    if (c === ':') return { error: 'Titik dua hanya untuk rentang sel' };
    const two = src.substr(i, 2);
    if (two === '<>' || two === '<=' || two === '>=') { out.push({ t: 'op', v: two }); i += 2; continue; }
    if ('+-*/^&=<>%'.includes(c)) { out.push({ t: 'op', v: c }); i++; continue; }
    return { error: 'Karakter tidak dikenal: ' + c };
  }
  return { tokens: out };
}

// ---------------------------------------------------------------- parser (prioritas Excel: perbandingan < & < + - < * / < ^ < minus unair < %)
export function parseFormula(src, mode = 'stored') {
  const s = String(src == null ? '' : src).trim();
  if (s[0] !== '=') return { ok: false, error: 'Rumus harus diawali =' };
  if (s.length > MAX_FX) return { ok: false, error: 'Rumus terlalu panjang (maks. ' + MAX_FX + ' karakter)' };
  const tk = tokenize(s.slice(1), mode === 'a1' ? 'a1' : 'stored'); if (tk.error) return { ok: false, error: tk.error };
  const toks = tk.tokens; let p = 0, depth = 0;
  const fail = (m) => { throw new Syn(m); };
  const peek = () => toks[p];
  const isOp = (t, ...v) => !!t && t.t === 'op' && v.includes(t.v);
  const enter = () => { if (++depth > MAX_DEPTH) fail('Rumus terlalu bersarang'); };
  const leave = () => { depth--; };
  const bin = (sub, ...ops) => () => { let l = sub(); while (isOp(peek(), ...ops)) { const op = toks[p++].v; l = { k: 'bin', op, l, r: sub() }; } return l; };
  function primary() {
    const t = toks[p++]; if (!t) fail('Rumus tidak lengkap');
    switch (t.t) {
      case 'num': return { k: 'num', v: t.v };
      case 'str': return { k: 'str', v: t.v };
      case 'bool': return { k: 'bool', v: t.v };
      case 'name': return { k: 'name', v: t.v };
      case 'referr': return { k: 'referr' };
      case 'ref': return t.bad ? { k: 'referr' } : { k: 'ref', a: t.a, b: t.b };
      case '(': { enter(); const x = cmp(); const e = toks[p++]; if (!e || e.t !== ')') fail('Tanda kurung belum ditutup'); leave(); return x; }
      case 'fn': {
        const o = toks[p++]; if (!o || o.t !== '(') fail('Tanda kurung buka hilang'); enter(); const args = [];
        if (toks[p] && toks[p].t === ')') p++;
        else for (;;) {
          const nx = toks[p]; if (!nx) fail('Tanda kurung belum ditutup');
          args.push(nx.t === 'sep' || nx.t === ')' ? { k: 'blank' } : cmp());
          const e = toks[p++]; if (!e) fail('Tanda kurung belum ditutup'); if (e.t === ')') break; if (e.t !== 'sep') fail('Pemisah argumen tidak valid');
        }
        leave(); if (args.length > MAX_ARGS) fail('Terlalu banyak argumen'); return { k: 'fn', name: t.v, args };
      }
      default: return fail('Rumus tidak valid dekat "' + (t.t === 'op' ? t.v : t.t === 'sep' ? 'pemisah' : t.t) + '"');
    }
  }
  function post() { let x = primary(); while (isOp(peek(), '%')) { p++; x = { k: 'pct', x }; } return x; }
  function unary() { if (isOp(peek(), '-', '+')) { const op = toks[p++].v; enter(); const x = unary(); leave(); return { k: 'un', op, x }; } return post(); }
  const pow = bin(unary, '^'), mul = bin(pow, '*', '/'), add = bin(mul, '+', '-'), concat = bin(add, '&');
  const cmp = bin(concat, '=', '<>', '<', '>', '<=', '>=');
  try {
    const ast = cmp(); if (p < toks.length) fail('Bagian rumus tidak dikenali'); return { ok: true, ast, tokens: toks };
  } catch (e) { if (e instanceof Syn) return { ok: false, error: e.message }; throw e; }
}

// ---------------------------------------------------------------- kriteria SUMIF/COUNTIF (pencocok wildcard iteratif, bukan RegExp: tanpa risiko ReDoS)
function wildParts(p) { const o = []; for (let i = 0; i < p.length; i++) { const c = p[i]; if (c === '~' && (p[i + 1] === '*' || p[i + 1] === '?' || p[i + 1] === '~')) { o.push({ l: p[++i] }); } else if (c === '*') { if (!o.length || o[o.length - 1].star !== true) o.push({ star: true }); } else if (c === '?') o.push({ any: true }); else o.push({ l: c }); } return o; }
function wildMatch(parts, str) {
  let pi = 0, si = 0, star = -1, mark = 0;
  while (si < str.length) {
    const q = parts[pi];
    if (q && !q.star && (q.any || q.l === str[si])) { pi++; si++; } else if (q && q.star) { star = pi++; mark = si; } else if (star >= 0) { pi = star + 1; si = ++mark; } else return false;
  }
  while (parts[pi] && parts[pi].star) pi++;
  return pi === parts.length;
}
function makeCrit(c) {
  if (isErr(c)) return c; if (c === null || c === undefined) c = 0;
  if (typeof c === 'number') return (v) => (typeof v === 'number' && v === c) || (typeof v === 'string' && NUMTXT.test(v) && Number(v.trim().replace(',', '.')) === c); // seperti Excel: 10 cocok dengan angka 10 dan teks "10"
  if (typeof c === 'boolean') return (v) => typeof v === 'boolean' && v === c;
  const m = /^(<=|>=|<>|=|<|>)?([\s\S]*)$/.exec(String(c)); const op = m[1] || '=', t = m[2];
  const isNum = NUMTXT.test(t) ? Number(t.trim().replace(',', '.')) : null, up = t.trim().toUpperCase();
  let eq;
  if (isNum !== null && Number.isFinite(isNum)) eq = (v) => (typeof v === 'number' && v === isNum) || (typeof v === 'string' && NUMTXT.test(v) && Number(v.trim().replace(',', '.')) === isNum);
  else if (up === 'TRUE' || up === 'FALSE') eq = (v) => typeof v === 'boolean' && v === (up === 'TRUE');
  else if (t === '') eq = (v) => v === null || v === undefined || v === '';
  else { const parts = wildParts(t.toLowerCase()); eq = (v) => typeof v === 'string' && wildMatch(parts, v.toLowerCase()); }
  if (op === '=') return eq; if (op === '<>') return (v) => !eq(v);
  if (isNum !== null && Number.isFinite(isNum)) return (v) => typeof v === 'number' && (op === '<' ? v < isNum : op === '>' ? v > isNum : op === '<=' ? v <= isNum : v >= isNum);
  const lt = t.toLowerCase(); return (v) => typeof v === 'string' && (op === '<' ? v.toLowerCase() < lt : op === '>' ? v.toLowerCase() > lt : op === '<=' ? v.toLowerCase() <= lt : v.toLowerCase() >= lt);
}

// ---------------------------------------------------------------- fungsi
const sc = (x) => (isRng(x) ? (x.h === 1 && x.w === 1 ? x.vals[0] : E.VALUE) : x);
function gather(items) { // untuk SUM/AVERAGE/MIN/MAX: rujukan hanya angka; argumen langsung dikoersi (teks angka, TRUE/FALSE ikut)
  const nums = [];
  for (const it of items) {
    if (isRng(it)) { for (const v of it.vals) { if (isErr(v)) return { err: v }; if (typeof v === 'number') nums.push(v); } }
    else { if (isErr(it)) return { err: it }; const n = num(it); if (isErr(n)) return { err: n }; nums.push(n); }
  }
  return { nums };
}
function logical(items, isAnd) {
  let seen = false, res = isAnd;
  const feed = (b) => { seen = true; res = isAnd ? res && b : res || b; };
  for (const it of items) {
    if (isRng(it)) { for (const v of it.vals) { if (isErr(v)) return v; if (typeof v === 'boolean') feed(v); else if (typeof v === 'number') feed(v !== 0); } }
    else { if (isErr(it)) return it; const b = bool(it); if (isErr(b)) return b; feed(b); }
  }
  return seen ? res : E.VALUE;
}
// Rev 138: SUMIFS/COUNTIFS. Semua rentang HARUS berukuran sama (seperti Excel; beda = #VALUE!). Sel dihitung bila lolos SEMUA kriteria; sel galat di rentang jumlah menjalar, galat di rentang kriteria dianggap tidak cocok.
function multiCrit(sumR, pairs, isSum) {
  if (isSum) { if (isErr(sumR)) return sumR; if (!isRng(sumR)) return E.VALUE; }
  const crs = [], rs = [];
  for (let i = 0; i < pairs.length; i += 2) {
    const R = pairs[i]; if (isErr(R)) return R; if (!isRng(R)) return E.VALUE;
    const c = makeCrit(sc(pairs[i + 1])); if (isErr(c)) return c;
    if (isSum ? (R.h !== sumR.h || R.w !== sumR.w) : (rs.length && (R.h !== rs[0].h || R.w !== rs[0].w))) return E.VALUE;
    rs.push(R); crs.push(c);
  }
  const n = rs[0].h * rs[0].w; let acc = 0;
  for (let k = 0; k < n; k++) {
    let ok = true;
    for (let q = 0; q < rs.length && ok; q++) { const v = rs[q].vals[k]; if (isErr(v) || !crs[q](v)) ok = false; }
    if (!ok) continue;
    if (isSum) { const v = sumR.vals[k]; if (isErr(v)) return v; if (typeof v === 'number') acc += v; } else acc++;
  }
  return acc;
}
// Rev 162: bantuan kelompok Angka dan Teks. Teks hasil dibatasi TEXT_MAX (sama dengan MAX_CELL lembar.js = 2000; lebih dari itu = #VALUE!).
const TEXT_MAX = 2000;
const tx = (v) => { v = sc(v); return isErr(v) ? v : text(v); }; // argumen teks: rentang >1 sel = #VALUE!; galat menjalar
const cps = (t) => Array.from(t); // per titik kode (emoji = 1 karakter)
const intArg = (v, min) => { const n = num(sc(v)); if (isErr(n)) return n; const k = Math.trunc(n); return k < min ? E.VALUE : k; };
function numsOf(a0) { // LARGE/SMALL/RANK: angka dari rentang (galat menjalar) atau satu nilai
  if (isErr(a0)) return { err: a0 }; if (!isRng(a0)) { const n = num(a0); return isErr(n) ? { err: n } : { nums: [n] }; }
  const nums = []; for (const v of a0.vals) { if (isErr(v)) return { err: v }; if (typeof v === 'number') nums.push(v); } return { nums };
}
function pick(a, small) { const g = numsOf(a[0]); if (g.err) return g.err; const k = num(sc(a[1])); if (isErr(k)) return k; const n = Math.trunc(k); if (n < 1 || n > g.nums.length) return E.NUM; const v = [...g.nums].sort((x, y) => (small ? x - y : y - x)); return v[n - 1]; }
function avgIf(a, cx) {
  if (isErr(a[0])) return a[0]; if (!isRng(a[0])) return E.VALUE; const cr = makeCrit(sc(a[1])); if (isErr(cr)) return cr; if (a[2] !== undefined && !isRng(a[2])) return isErr(a[2]) ? a[2] : E.VALUE;
  const R = a[0], S = a[2] || R; let sum = 0, k = 0;
  for (let i = 0; i < R.h; i++) for (let j = 0; j < R.w; j++) {
    if (!cr(R.vals[i * R.w + j])) continue; const v = S === R ? R.vals[i * R.w + j] : cx.at(S.r0 + i, S.c0 + j);
    if (isErr(v)) return v; if (typeof v === 'number') { sum += v; k++; }
  }
  return k ? sum / k : E.DIV0;
}
// Rev 163 / Q10 tahap 2: kelompok TANGGAL. Nomor seri gaya Excel (sama dengan serialOf/formatDate); hanya hari utuh 1..2958465 yang sah.
const SER_MAX = 2958465, DAY_MS = 86400000, SER0 = Date.UTC(1899, 11, 30);
function serArg(v) { const n = num(sc(v)); if (isErr(n)) return n; const f = Math.floor(Number(n.toPrecision(15))); return f < 1 || f > SER_MAX ? E.NUM : f; } // satu nilai nomor seri -> hari utuh, di luar jangkauan = #NUM!
const ymd = (ser) => { const d = new Date(SER0 + ser * DAY_MS); return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate() }; };
function dayMs(y, m, d) { const t = new Date(0); t.setUTCFullYear(y, m - 1, d); t.setUTCHours(0, 0, 0, 0); return t.getTime(); } // setUTCFullYear: tahun 0-99 tidak diubah jadi 1900+
const daysIn = (y, m) => (m === 2 ? ((y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 29 : 28) : [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1]);
function timeSecs(v) { const n = num(sc(v)); if (isErr(n)) return n; if (n < 0 || n >= SER_MAX + 1) return E.NUM; const f = Number((n - Math.floor(n)).toPrecision(12)); return Math.round(f * 86400) % 86400; } // detik dalam sehari (0..86399); 0,99999999 dibulatkan ke 00:00 hari berikutnya seperti Excel
function dateFn(a) {
  let y = num(sc(a[0])); if (isErr(y)) return y; const m = num(sc(a[1])); if (isErr(m)) return m; const d = num(sc(a[2])); if (isErr(d)) return d;
  y = Math.trunc(y); const mo = Math.trunc(m), dy = Math.trunc(d); if (y < 0 || y > 9999) return E.NUM; if (y < 1900) y += 1900; // tahun 0..1899 ditambah 1900 (aturan Excel)
  if (Math.abs(mo) > 120000 || Math.abs(dy) > 3700000) return E.NUM; const ms = dayMs(y, mo, dy), ser = Math.round((ms - SER0) / DAY_MS);
  return !Number.isFinite(ser) || ser < 1 || ser > SER_MAX ? E.NUM : ser;
}
// Rev 169 / Q10 tahap 2: DATEVALUE(teks) = teks tanggal jadi nomor seri (tanpa jam). Urutan Indonesia: hari/bulan/tahun. Dikenali: dd/mm/yyyy, dd-mm-yyyy, dd.mm.yyyy (tahun 2 digit: 00-29 = 2000-2029, 30-99 = 1930-1999), yyyy-mm-dd (juga / dan .), dan "10 Nov 2026" / "10 November 2026" (nama bulan Indonesia atau Inggris, lengkap atau tiga huruf).
// Jam di belakang tanggal (mis. " 14:30" atau "T14:30:00") boleh ada dan diabaikan. Hari/bulan tidak sah (31/02/2026, bulan 13), tahun < 1900, angka, boolean, atau teks lain = #VALUE!.
const BLN_EN = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
function datevalueFn(a) {
  let t = tx(a[0]); if (isErr(t)) return t; t = t.trim().replace(/[ T]+(\d{1,2}):(\d{2})(?::(\d{2}))?(\s*[AaPp][Mm])?$/, (m0, h, mi, se) => (Number(h) > 23 || Number(mi) > 59 || (se !== undefined && Number(se) > 59) ? '\u0000' : ''));
  let y, mo, d, m;
  if ((m = /^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/.exec(t))) { y = +m[1]; mo = +m[2]; d = +m[3]; }
  else if ((m = /^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{2}|\d{4})$/.exec(t))) { d = +m[1]; mo = +m[2]; y = m[3].length === 2 ? (+m[3] < 30 ? 2000 + +m[3] : 1900 + +m[3]) : +m[3]; }
  else if ((m = /^(\d{1,2})[ -]+([A-Za-z]{3,9})\.?[ -]+(\d{2}|\d{4})$/.exec(t))) {
    const w = m[2].toLowerCase(); mo = 0; for (let i = 0; i < 12; i++) if (BLN[i].toLowerCase() === w || BLN3[i].toLowerCase() === w || BLN_EN[i] === w || BLN_EN[i].slice(0, 3) === w) { mo = i + 1; break; }
    d = +m[1]; y = m[3].length === 2 ? (+m[3] < 30 ? 2000 + +m[3] : 1900 + +m[3]) : +m[3];
  } else return E.VALUE;
  if (!mo || mo > 12 || d < 1 || d > 31 || y < 1900 || y > 9999) return E.VALUE;
  const ser = Math.round((dayMs(y, mo, d) - SER0) / DAY_MS); if (!Number.isFinite(ser) || ser < 1 || ser > SER_MAX) return E.VALUE;
  const c = ymd(ser); return c.y === y && c.m === mo && c.d === d ? ser : E.VALUE; // hari yang tidak ada di bulan itu ditolak (tidak bergulir)
}
function weekdayFn(a) {
  const s = serArg(a[0]); if (isErr(s)) return s; let t = 1; if (a[1] !== undefined) { const x = num(sc(a[1])); if (isErr(x)) return x; t = Math.trunc(x); }
  const w = new Date(SER0 + s * DAY_MS).getUTCDay(); // 0 = Minggu
  return t === 1 ? w + 1 : t === 2 ? ((w + 6) % 7) + 1 : t === 3 ? (w + 6) % 7 : E.NUM;
}
function datedifFn(a) {
  const s1 = serArg(a[0]); if (isErr(s1)) return s1; const s2 = serArg(a[1]); if (isErr(s2)) return s2; const u = tx(a[2]); if (isErr(u)) return u;
  if (s1 > s2) return E.NUM; const A = ymd(s1), B = ymd(s2), unit = u.trim().toUpperCase(), before = B.d < A.d;
  if (unit === 'D') return s2 - s1;
  if (unit === 'M') return (B.y - A.y) * 12 + (B.m - A.m) - (before ? 1 : 0);
  if (unit === 'Y') return B.y - A.y - (B.m < A.m || (B.m === A.m && before) ? 1 : 0);
  if (unit === 'YM') return (((B.m - A.m - (before ? 1 : 0)) % 12) + 12) % 12;
  if (unit === 'MD') { if (!before) return B.d - A.d; const pm = B.m === 1 ? 12 : B.m - 1, py = B.m === 1 ? B.y - 1 : B.y; return daysIn(py, pm) - A.d + B.d; } // hari sisa; bila tanggal akhir < tanggal awal, pinjam panjang bulan sebelum bulan akhir
  if (unit === 'YD') { let a = Math.round((dayMs(B.y, A.m, A.d) - SER0) / DAY_MS); if (a > s2) a = Math.round((dayMs(B.y - 1, A.m, A.d) - SER0) / DAY_MS); return s2 - a; } // 29 Feb di tahun bukan kabisat = 1 Mar
  return E.NUM;
}
// Rev 164 / Q10 tahap 2: TEXT(nilai; format). Format gaya Indonesia: "." ribuan, "," desimal. Tanggal/jam: yyyy yy mmmm mmm mm m dddd ddd dd d hh h mm(menit) ss (nama bulan/hari Indonesia). Angka: 0 # . , % (mis. "0", "0,00", "#.##0", "0%", boleh awalan/akhiran seperti "Rp "). Format Inggris "#,##0" TIDAK didukung (koma = desimal).
const BLN = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'], BLN3 = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const HARI = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'], HARI3 = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
const pad2 = (n) => (n < 10 ? '0' : '') + n;
function dateText(v, f) {
  if (typeof v === 'boolean') return E.VALUE; let n = num(v); if (isErr(n)) return E.VALUE; n = Number(n.toPrecision(15)); if (n < 0 || n >= SER_MAX + 1) return E.VALUE;
  const toks = []; for (let i = 0; i < f.length;) { const lc = f[i].toLowerCase(); if ('ydmhs'.includes(lc)) { let j = i; while (j < f.length && f[j].toLowerCase() === lc) j++; toks.push({ t: lc, n: j - i }); i = j; } else { toks.push({ lit: f[i] }); i++; } }
  const near = (k, d) => { for (let i = k + d; i >= 0 && i < toks.length; i += d) if (!toks[i].lit) return toks[i].t; return ''; };
  toks.forEach((tk, k) => { if (tk.t === 'm' && (near(k, -1) === 'h' || near(k, 1) === 's')) tk.t = 'min'; }); // mm sesudah jam / sebelum detik = menit
  const total = Math.round(n * 86400), ser = Math.floor(total / 86400), secs = total % 86400, hasDate = toks.some((x) => x.t === 'y' || x.t === 'm' || x.t === 'd');
  if (hasDate && (ser < 1 || ser > SER_MAX)) return E.VALUE;
  const dt = ser >= 1 ? ymd(ser) : { y: 1899, m: 12, d: 30 }, wd = new Date(SER0 + ser * DAY_MS).getUTCDay(); let out = '';
  for (const tk of toks) {
    if (tk.lit !== undefined) { out += tk.lit; continue; }
    switch (tk.t) {
      case 'y': out += tk.n >= 3 ? String(dt.y).padStart(4, '0') : pad2(dt.y % 100); break;
      case 'm': out += tk.n === 1 ? dt.m : tk.n === 2 ? pad2(dt.m) : tk.n === 3 ? BLN3[dt.m - 1] : BLN[dt.m - 1]; break;
      case 'd': out += tk.n === 1 ? dt.d : tk.n === 2 ? pad2(dt.d) : tk.n === 3 ? HARI3[wd] : HARI[wd]; break;
      case 'h': { const h = Math.floor(secs / 3600); out += tk.n === 1 ? h : pad2(h); break; }
      case 'min': { const m = Math.floor((secs % 3600) / 60); out += tk.n === 1 ? m : pad2(m); break; }
      default: { const x = secs % 60; out += tk.n === 1 ? x : pad2(x); }
    }
  }
  return out;
}
function numText(v, f) {
  if (typeof v === 'boolean') return E.VALUE; if (typeof v === 'string' && !NUMTXT.test(v)) return v; // teks biasa lewat apa adanya (seperti Excel)
  const x0 = num(v); if (isErr(x0)) return x0; const st = f.search(/[#0]/); if (st < 0) return f; // tanpa penanda angka = format dikembalikan apa adanya
  let en = st; while (en < f.length && '#0.,'.includes(f[en])) en++;
  const prefix = f.slice(0, st), core = f.slice(st, en), pct = f[en] === '%', suffix = f.slice(pct ? en + 1 : en), ci = core.indexOf(',');
  if (core.split(',').length > 2) return E.VALUE; const ip = ci < 0 ? core : core.slice(0, ci), dp = ci < 0 ? '' : core.slice(ci + 1); if (dp.includes('.') || /^\.|\.$/.test(ip) || /\.\./.test(ip)) return E.VALUE;
  const group = ip.includes('.'), minInt = (ip.match(/0/g) || []).length, D = dp.length, minDec = (dp.match(/0/g) || []).length; if (D > 15) return E.VALUE;
  let x = pct ? Number((x0 * 100).toPrecision(15)) : x0; const neg = x < 0; x = Math.abs(x); if (!(x < 1e15)) return E.NUM;
  const r = Number(Math.round(Number(x + 'e' + D)) + 'e-' + D), t = (Number.isFinite(r) ? r : x).toFixed(D).split('.'); let ints = t[0], dec = t[1] || '';
  while (dec.length > minDec && dec.endsWith('0')) dec = dec.slice(0, -1);
  if (ints === '0' && minInt === 0 && dec) ints = ''; if (ints.length < minInt) ints = ints.padStart(minInt, '0'); if (ints === '' && !dec) ints = '0';
  const body = (group ? ints.replace(/\B(?=(\d{3})+(?!\d))/g, '.') : ints) + (dec ? ',' + dec : '');
  return (neg && /[1-9]/.test(body) ? '-' : '') + prefix + body + (pct ? '%' : '') + suffix;
}
function textFn(a) { const v = sc(a[0]); if (isErr(v)) return v; const f = tx(a[1]); if (isErr(f)) return f; if (f === '') return ''; return /[ydmhs]/i.test(f) ? dateText(v, f) : numText(v, f); }
// Format tampilan otomatis dari BENTUK rumus (hanya bila sel tidak punya format sendiri): DATE(...) / TODAY() dan tanggal +/- angka = Tanggal. NOW() sengaja tidak (jamnya akan hilang).
const dateLike = (n) => { if (!n) return false; if (n.k === 'fn') return n.name === 'DATE' || n.name === 'TODAY' || n.name === 'DATEVALUE'; if (n.k === 'bin' && (n.op === '+' || n.op === '-')) { const l = dateLike(n.l), r = dateLike(n.r); return n.op === '+' ? l !== r : l && !r; } return false; };
const AUTO_CACHE = new Map();
export function fxAutoNf(fx) {
  if (typeof fx !== 'string') return null; if (AUTO_CACHE.has(fx)) return AUTO_CACHE.get(fx);
  let out = null; try { const ps = parseFormula(fx, 'stored'); if (ps.ok && dateLike(ps.ast)) out = { k: 'date', p: 'short' }; } catch (_) { out = null; }
  if (AUTO_CACHE.size > 800) AUTO_CACHE.clear(); AUTO_CACHE.set(fx, out); return out;
}
// Rev 165 / Q10 tahap 2 (Cari data, bagian 1): MATCH(nilai; rentang; [tipe]). Rentang SATU dimensi (satu baris atau satu kolom; selain itu #N/A); posisi mulai dari 1.
// tipe 0 = sama persis (teks: huruf besar/kecil diabaikan, boleh * dan ?; teks "10" TIDAK sama dengan angka 10, seperti Excel); 1 (bawaan) = nilai terbesar yang <= nilai, 'tipe' > 0; -1 = nilai terkecil yang >= nilai, 'tipe' < 0. Hanya sel BERJENIS SAMA yang dibandingkan; sel kosong dan galat dilewati.
// Tipe 1/-1 mengandaikan data terurut (naik / turun); pada data tak terurut hasilnya = posisi TERAKHIR yang memenuhi (Excel memakai pencarian biner sehingga bisa lain). Tidak ketemu = #N/A.
function lookupPos(x, vs, t) { // posisi (indeks 0) di daftar nilai vs, atau -1; dipakai MATCH dan VLOOKUP (Rev 167)
  if (t === 0) {
    let eq; if (typeof x === 'string') { const lo = x.toLowerCase(); if (/[*?]/.test(lo)) { const parts = wildParts(lo); eq = (v) => typeof v === 'string' && wildMatch(parts, v.toLowerCase()); } else eq = (v) => typeof v === 'string' && v.toLowerCase() === lo; } else eq = (v) => v !== null && v !== undefined && !isErr(v) && rank(v) === rank(x) && compare(v, x) === 0;
    for (let i = 0; i < vs.length; i++) if (eq(vs[i])) return i; return -1;
  }
  let best = -1; for (let i = 0; i < vs.length; i++) { const v = vs[i]; if (v === null || v === undefined || isErr(v) || rank(v) !== rank(x)) continue; const c = compare(v, x); if (t > 0 ? c <= 0 : c >= 0) best = i; }
  return best;
}
function matchFn(a) {
  let x = sc(a[0]); if (isErr(x)) return x; if (x === null || x === undefined) x = 0; let R = a[1]; if (isErr(R)) return R;
  if (!isRng(R)) R = { rng: true, h: 1, w: 1, vals: [R] }; if (R.h !== 1 && R.w !== 1) return E.NA;
  let t = 1; if (a[2] !== undefined) { const n = num(sc(a[2])); if (isErr(n)) return n; t = n === 0 ? 0 : n > 0 ? 1 : -1; }
  const i = lookupPos(x, R.vals, t); return i < 0 ? E.NA : i + 1;
}
// Rev 167 / Q10 tahap 2 (Cari data, bagian 3): VLOOKUP(nilai; rentang; kolom; [cocok]). Mencari nilai di KOLOM PERTAMA rentang lalu mengambil sel di kolom ke-'kolom' (1 = kolom pertama) pada baris yang sama.
// cocok = FALSE/0/kosong -> sama persis (aturan teks/wildcard sama dengan MATCH tipe 0); cocok = TRUE/angka bukan 0 (bawaan bila argumen dihilangkan) -> nilai terbesar yang <= nilai (kolom pertama harus terurut naik; data tak terurut = baris TERAKHIR yang memenuhi). Tidak ketemu = #N/A; kolom < 1 = #VALUE!; kolom > lebar rentang = #REF!.
function vlookupFn(a) {
  let x = sc(a[0]); if (isErr(x)) return x; if (x === null || x === undefined) x = 0; let R = a[1]; if (isErr(R)) return R; if (!isRng(R)) R = { rng: true, h: 1, w: 1, vals: [R] };
  const k = num(sc(a[2])); if (isErr(k)) return k; const col = Math.trunc(k); if (col < 1) return E.VALUE; if (col > R.w) return E.REF;
  let approx = true; if (a[3] !== undefined) { const b = bool(sc(a[3])); if (isErr(b)) return b; approx = b; }
  const first = []; for (let i = 0; i < R.h; i++) first.push(R.vals[i * R.w]);
  const i = lookupPos(x, first, approx ? 1 : 0); return i < 0 ? E.NA : R.vals[i * R.w + (col - 1)];
}
// Rev 168 / Q10 tahap 2 (Cari data, bagian 4): HLOOKUP(nilai; rentang; baris; [cocok]) = VLOOKUP versi MENDATAR. Mencari nilai di BARIS PERTAMA rentang lalu mengambil sel di baris ke-'baris' (1 = baris pertama) pada kolom yang sama.
// cocok sama dengan VLOOKUP (FALSE/0/kosong = sama persis; TRUE/angka bukan 0/dihilangkan = terbesar yang <= nilai, baris pertama terurut naik). Tidak ketemu = #N/A; baris < 1 = #VALUE!; baris > tinggi rentang = #REF!. Logika cari dipakai bersama lewat lookupPos.
function hlookupFn(a) {
  let x = sc(a[0]); if (isErr(x)) return x; if (x === null || x === undefined) x = 0; let R = a[1]; if (isErr(R)) return R; if (!isRng(R)) R = { rng: true, h: 1, w: 1, vals: [R] };
  const k = num(sc(a[2])); if (isErr(k)) return k; const row = Math.trunc(k); if (row < 1) return E.VALUE; if (row > R.h) return E.REF;
  let approx = true; if (a[3] !== undefined) { const b = bool(sc(a[3])); if (isErr(b)) return b; approx = b; }
  const first = R.vals.slice(0, R.w);
  const i = lookupPos(x, first, approx ? 1 : 0); return i < 0 ? E.NA : R.vals[(row - 1) * R.w + i];
}
// Rev 166 / Q10 tahap 2 (Cari data, bagian 2): INDEX(rentang; baris; [kolom]) = nilai SATU sel di dalam rentang (posisi mulai dari 1). Rentang satu baris: argumen kedua = urutan kolom; rentang satu kolom: = urutan baris; rentang dua dimensi: baris DAN kolom wajib.
// Baris/kolom 0 (= seluruh baris/kolom) tidak didukung = #VALUE! (hasil hanya satu nilai); negatif = #VALUE!; di luar rentang = #REF!. Pecahan dipotong. Sel kosong menjadi 0 (seperti Excel); galat di sel yang diambil menjalar.
function indexFn(a) {
  let R = a[0]; if (isErr(R)) return R; if (!isRng(R)) R = { rng: true, h: 1, w: 1, vals: [R] };
  const p = (v) => { const n = num(sc(v)); return isErr(n) ? n : Math.trunc(n); };
  const i1 = p(a[1]); if (isErr(i1)) return i1; let i2 = 1; const has2 = a[2] !== undefined; if (has2) { i2 = p(a[2]); if (isErr(i2)) return i2; }
  let r, c;
  if (R.w === 1 && !has2) { r = i1; c = 1; } else if (R.h === 1 && !has2) { r = 1; c = i1; } else if (!has2) return E.VALUE; else { r = i1; c = i2; }
  if (r < 0 || c < 0 || r === 0 || c === 0) return E.VALUE; if (r > R.h || c > R.w) return E.REF;
  return R.vals[(r - 1) * R.w + (c - 1)];
}
const FUNCS = {
  SUM: { min: 1, max: MAX_ARGS, sig: 'SUM(nilai1; [nilai2; …])', ket: 'Menjumlahkan angka.', fn: (a) => { const g = gather(a); return g.err || g.nums.reduce((s, x) => s + x, 0); } },
  AVERAGE: { min: 1, max: MAX_ARGS, sig: 'AVERAGE(nilai1; [nilai2; …])', ket: 'Rata-rata angka.', fn: (a) => { const g = gather(a); return g.err || (g.nums.length ? g.nums.reduce((s, x) => s + x, 0) / g.nums.length : E.DIV0); } },
  MIN: { min: 1, max: MAX_ARGS, sig: 'MIN(nilai1; [nilai2; …])', ket: 'Angka terkecil.', fn: (a) => { const g = gather(a); return g.err || (g.nums.length ? Math.min(...g.nums) : 0); } },
  MAX: { min: 1, max: MAX_ARGS, sig: 'MAX(nilai1; [nilai2; …])', ket: 'Angka terbesar.', fn: (a) => { const g = gather(a); return g.err || (g.nums.length ? Math.max(...g.nums) : 0); } },
  COUNT: { min: 1, max: MAX_ARGS, sig: 'COUNT(nilai1; [nilai2; …])', ket: 'Menghitung sel berisi angka.', fn: (a) => { let k = 0; for (const it of a) { if (isRng(it)) { for (const v of it.vals) if (typeof v === 'number') k++; } else if (!isErr(it) && it !== null && !isErr(num(it)) && (typeof it !== 'string' || NUMTXT.test(it))) k++; } return k; } },
  COUNTA: { min: 1, max: MAX_ARGS, sig: 'COUNTA(nilai1; [nilai2; …])', ket: 'Menghitung sel yang tidak kosong.', fn: (a) => { let k = 0; for (const it of a) { if (isRng(it)) { for (const v of it.vals) if (v !== null && v !== undefined) k++; } else if (it !== null && it !== undefined) k++; } return k; } },
  IF: { min: 2, max: 3, lazy: true, sig: 'IF(syarat; jika_benar; [jika_salah])', ket: 'Memilih nilai sesuai syarat.' },
  AND: { min: 1, max: MAX_ARGS, sig: 'AND(syarat1; [syarat2; …])', ket: 'BENAR bila semua syarat benar.', fn: (a) => logical(a, true) },
  OR: { min: 1, max: MAX_ARGS, sig: 'OR(syarat1; [syarat2; …])', ket: 'BENAR bila salah satu syarat benar.', fn: (a) => logical(a, false) },
  NOT: { min: 1, max: 1, sig: 'NOT(syarat)', ket: 'Membalik BENAR/SALAH.', fn: (a) => { const b = bool(sc(a[0])); return isErr(b) ? b : !b; } },
  ROUND: { min: 2, max: 2, sig: 'ROUND(angka; digit)', ket: 'Membulatkan angka ke jumlah digit.', fn: (a) => { const x = num(sc(a[0])); if (isErr(x)) return x; const d = num(sc(a[1])); if (isErr(d)) return d; const k = Math.trunc(d); return k > 15 || k < -15 ? E.NUM : roundHalfAway(x, k); } },
  ABS: { min: 1, max: 1, sig: 'ABS(angka)', ket: 'Nilai mutlak angka.', fn: (a) => { const x = num(sc(a[0])); return isErr(x) ? x : Math.abs(x); } },
  SUMIF: { min: 2, max: 3, sig: 'SUMIF(rentang; kriteria; [rentang_jumlah])', ket: 'Menjumlahkan sel yang memenuhi kriteria.', fn: (a, cx) => {
    if (isErr(a[0])) return a[0]; if (!isRng(a[0])) return E.VALUE; const cr = makeCrit(sc(a[1])); if (isErr(cr)) return cr; if (a[2] !== undefined && !isRng(a[2])) return isErr(a[2]) ? a[2] : E.VALUE;
    const R = a[0], S = a[2] || R; let sum = 0;
    for (let i = 0; i < R.h; i++) for (let j = 0; j < R.w; j++) {
      if (!cr(R.vals[i * R.w + j])) continue; const v = S === R ? R.vals[i * R.w + j] : cx.at(S.r0 + i, S.c0 + j);
      if (isErr(v)) return v; if (typeof v === 'number') sum += v;
    }
    return sum; } },
  COUNTIF: { min: 2, max: 2, sig: 'COUNTIF(rentang; kriteria)', ket: 'Menghitung sel yang memenuhi kriteria.', fn: (a) => { if (isErr(a[0])) return a[0]; if (!isRng(a[0])) return E.VALUE; const cr = makeCrit(sc(a[1])); if (isErr(cr)) return cr; let k = 0; for (const v of a[0].vals) if (!isErr(v) && cr(v)) k++; return k; } },
  SUMIFS: { min: 3, max: MAX_ARGS, par: 1, sig: 'SUMIFS(rentang_jumlah; rentang1; kriteria1; [rentang2; kriteria2; …])', ket: 'Menjumlahkan sel yang memenuhi SEMUA kriteria.', fn: (a) => multiCrit(a[0], a.slice(1), true) },
  COUNTIFS: { min: 2, max: MAX_ARGS, par: 0, sig: 'COUNTIFS(rentang1; kriteria1; [rentang2; kriteria2; …])', ket: 'Menghitung sel yang memenuhi SEMUA kriteria.', fn: (a) => multiCrit(null, a, false) },
  IFERROR: { min: 2, max: 2, lazy: true, sig: 'IFERROR(nilai; jika_galat)', ket: 'Memakai nilai lain bila nilai pertama galat.' },
  ROUNDUP: { min: 2, max: 2, sig: 'ROUNDUP(angka; digit)', ket: 'Membulatkan ke atas (menjauhi nol).', fn: (a) => { const x = num(sc(a[0])); if (isErr(x)) return x; const d = num(sc(a[1])); if (isErr(d)) return d; const k = Math.trunc(d); return k > 15 || k < -15 ? E.NUM : roundDir(x, k, true); } },
  ROUNDDOWN: { min: 2, max: 2, sig: 'ROUNDDOWN(angka; digit)', ket: 'Membulatkan ke bawah (menuju nol).', fn: (a) => { const x = num(sc(a[0])); if (isErr(x)) return x; const d = num(sc(a[1])); if (isErr(d)) return d; const k = Math.trunc(d); return k > 15 || k < -15 ? E.NUM : roundDir(x, k, false); } },
  MEDIAN: { min: 1, max: MAX_ARGS, sig: 'MEDIAN(nilai1; [nilai2; …])', ket: 'Nilai tengah dari angka.', fn: (a) => { const g = gather(a); if (g.err) return g.err; if (!g.nums.length) return E.NUM; const v = [...g.nums].sort((x, y) => x - y), m = v.length >> 1; return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2; } },
  INT: { min: 1, max: 1, sig: 'INT(angka)', ket: 'Membulatkan ke bawah ke bilangan bulat terdekat.', fn: (a) => { const x = num(sc(a[0])); return isErr(x) ? x : Math.floor(Number(x.toPrecision(15))); } },
  MOD: { min: 2, max: 2, sig: 'MOD(angka; pembagi)', ket: 'Sisa bagi (bertanda sama dengan pembagi).', fn: (a) => { const x = num(sc(a[0])); if (isErr(x)) return x; const d = num(sc(a[1])); if (isErr(d)) return d; if (d === 0) return E.DIV0; const r = x - d * Math.floor(x / d); return Number(r.toPrecision(15)) + 0; } },
  POWER: { min: 2, max: 2, sig: 'POWER(angka; pangkat)', ket: 'Angka dipangkatkan (sama dengan ^).', fn: (a) => arith('^', sc(a[0]), sc(a[1])) },
  SQRT: { min: 1, max: 1, sig: 'SQRT(angka)', ket: 'Akar kuadrat (angka negatif = #NUM!).', fn: (a) => { const x = num(sc(a[0])); return isErr(x) ? x : x < 0 ? E.NUM : Math.sqrt(x); } },
  AVERAGEIF: { min: 2, max: 3, sig: 'AVERAGEIF(rentang; kriteria; [rentang_rata2])', ket: 'Rata-rata sel yang memenuhi kriteria.', fn: avgIf },
  LARGE: { min: 2, max: 2, sig: 'LARGE(rentang; k)', ket: 'Angka terbesar ke-k.', fn: (a) => pick(a, false) },
  SMALL: { min: 2, max: 2, sig: 'SMALL(rentang; k)', ket: 'Angka terkecil ke-k.', fn: (a) => pick(a, true) },
  RANK: { min: 2, max: 3, sig: 'RANK(angka; rentang; [urutan])', ket: 'Peringkat angka di rentang (urutan 0/kosong = terbesar dulu).', fn: (a) => {
    const x = num(sc(a[0])); if (isErr(x)) return x; if (isErr(a[1])) return a[1]; if (!isRng(a[1])) return E.VALUE;
    let asc = false; if (a[2] !== undefined) { const o = num(sc(a[2])); if (isErr(o)) return o; asc = o !== 0; }
    const g = numsOf(a[1]); if (g.err) return g.err; const key = (n) => Number(n.toPrecision(15)), xv = key(x); let found = false, ahead = 0;
    for (const n of g.nums) { const v = key(n); if (v === xv) found = true; else if (asc ? v < xv : v > xv) ahead++; }
    return found ? ahead + 1 : E.NA; } },
  CONCAT: { min: 1, max: MAX_ARGS, sig: 'CONCAT(teks1; [teks2; …])', ket: 'Menggabung teks (rentang digabung sel demi sel).', fn: (a) => {
    let out = ''; for (const it of a) { if (isRng(it)) { for (const v of it.vals) { if (isErr(v)) return v; out += text(v); if (out.length > TEXT_MAX) return E.VALUE; } } else { if (isErr(it)) return it; out += text(it); } if (out.length > TEXT_MAX) return E.VALUE; }
    return out; } },
  LEFT: { min: 1, max: 2, sig: 'LEFT(teks; [jumlah])', ket: 'Karakter paling kiri (bawaan 1).', fn: (a) => { const t = tx(a[0]); if (isErr(t)) return t; const n = a[1] === undefined ? 1 : intArg(a[1], 0); return isErr(n) ? n : cps(t).slice(0, n).join(''); } },
  RIGHT: { min: 1, max: 2, sig: 'RIGHT(teks; [jumlah])', ket: 'Karakter paling kanan (bawaan 1).', fn: (a) => { const t = tx(a[0]); if (isErr(t)) return t; const n = a[1] === undefined ? 1 : intArg(a[1], 0); if (isErr(n)) return n; const c = cps(t); return n === 0 ? '' : c.slice(Math.max(0, c.length - n)).join(''); } },
  MID: { min: 3, max: 3, sig: 'MID(teks; mulai; jumlah)', ket: 'Karakter dari posisi mulai (posisi pertama = 1).', fn: (a) => { const t = tx(a[0]); if (isErr(t)) return t; const st = intArg(a[1], 1); if (isErr(st)) return st; const n = intArg(a[2], 0); return isErr(n) ? n : cps(t).slice(st - 1, st - 1 + n).join(''); } },
  LEN: { min: 1, max: 1, sig: 'LEN(teks)', ket: 'Jumlah karakter.', fn: (a) => { const t = tx(a[0]); return isErr(t) ? t : cps(t).length; } },
  UPPER: { min: 1, max: 1, sig: 'UPPER(teks)', ket: 'Mengubah ke huruf besar.', fn: (a) => { const t = tx(a[0]); return isErr(t) ? t : t.toUpperCase(); } },
  LOWER: { min: 1, max: 1, sig: 'LOWER(teks)', ket: 'Mengubah ke huruf kecil.', fn: (a) => { const t = tx(a[0]); return isErr(t) ? t : t.toLowerCase(); } },
  TRIM: { min: 1, max: 1, sig: 'TRIM(teks)', ket: 'Membuang spasi di ujung dan merapatkan spasi ganda.', fn: (a) => { const t = tx(a[0]); return isErr(t) ? t : t.replace(/ +/g, ' ').replace(/^ | $/g, ''); } },
  VALUE: { min: 1, max: 1, sig: 'VALUE(teks)', ket: 'Mengubah teks angka (boleh berakhiran %) jadi angka.', fn: (a) => {
    const v = sc(a[0]); if (isErr(v)) return v; if (typeof v === 'boolean') return E.VALUE; if (typeof v === 'string') { const m = /^(\s*[^%]*?)\s*%\s*$/.exec(v); if (m && NUMTXT.test(m[1])) return Number(m[1].trim().replace(',', '.')) / 100; }
    return num(v); } },
  TODAY: { min: 0, max: 0, sig: 'TODAY()', ket: 'Tanggal hari ini (nomor seri).', fn: (a, cx) => serialOf(cx.now) },
  NOW: { min: 0, max: 0, sig: 'NOW()', ket: 'Tanggal dan jam sekarang (nomor seri).', fn: (a, cx) => nowSerial(cx.now) },
  DATE: { min: 3, max: 3, sig: 'DATE(tahun; bulan; tanggal)', ket: 'Membuat tanggal (nomor seri); bulan/hari berlebih ikut bergulir.', fn: dateFn },
  YEAR: { min: 1, max: 1, sig: 'YEAR(tanggal)', ket: 'Tahun dari tanggal (nomor seri).', fn: (a) => { const s = serArg(a[0]); return isErr(s) ? s : ymd(s).y; } },
  MONTH: { min: 1, max: 1, sig: 'MONTH(tanggal)', ket: 'Bulan (1-12) dari tanggal.', fn: (a) => { const s = serArg(a[0]); return isErr(s) ? s : ymd(s).m; } },
  DAY: { min: 1, max: 1, sig: 'DAY(tanggal)', ket: 'Hari dalam bulan (1-31) dari tanggal.', fn: (a) => { const s = serArg(a[0]); return isErr(s) ? s : ymd(s).d; } },
  HOUR: { min: 1, max: 1, sig: 'HOUR(waktu)', ket: 'Jam (0-23) dari nomor seri berjam, mis. NOW().', fn: (a) => { const t = timeSecs(a[0]); return isErr(t) ? t : Math.floor(t / 3600); } },
  MINUTE: { min: 1, max: 1, sig: 'MINUTE(waktu)', ket: 'Menit (0-59) dari nomor seri berjam.', fn: (a) => { const t = timeSecs(a[0]); return isErr(t) ? t : Math.floor((t % 3600) / 60); } },
  WEEKDAY: { min: 1, max: 2, sig: 'WEEKDAY(tanggal; [tipe])', ket: 'Nomor hari: tipe 1 (bawaan) Minggu=1…Sabtu=7; 2 Senin=1…Minggu=7; 3 Senin=0…Minggu=6.', fn: weekdayFn },
  DATEDIF: { min: 3, max: 3, sig: 'DATEDIF(mulai; akhir; satuan)', ket: 'Selisih dua tanggal. Satuan "Y" tahun, "M" bulan, "D" hari, "YM", "MD", "YD" sisa.', fn: datedifFn },
  DATEVALUE: { min: 1, max: 1, sig: 'DATEVALUE(teks)', ket: 'Teks tanggal jadi nomor seri: "10/11/2026", "2026-11-10", "10 Nov 2026" (hari dulu, lalu bulan). Jam di belakangnya diabaikan.', fn: datevalueFn },
  TEXT: { min: 2, max: 2, sig: 'TEXT(nilai; format)', ket: 'Angka/tanggal jadi teks berformat: "dd/mm/yyyy", "dd mmmm yyyy", "0,00", "#.##0", "0%".', fn: textFn },
  VLOOKUP: { min: 3, max: 4, sig: 'VLOOKUP(nilai; rentang; kolom; [cocok])', ket: 'Cari nilai di kolom pertama rentang, ambil sel di kolom ke-n pada baris yang sama. cocok FALSE/0 = sama persis; TRUE (bawaan) = terbesar yang <= nilai (kolom pertama terurut naik).', fn: vlookupFn },
  HLOOKUP: { min: 3, max: 4, sig: 'HLOOKUP(nilai; rentang; baris; [cocok])', ket: 'Cari nilai di baris pertama rentang, ambil sel di baris ke-n pada kolom yang sama. cocok FALSE/0 = sama persis; TRUE (bawaan) = terbesar yang <= nilai (baris pertama terurut naik).', fn: hlookupFn },
  MATCH: { min: 2, max: 3, sig: 'MATCH(nilai; rentang; [tipe])', ket: 'Posisi nilai di satu baris/kolom. Tipe 0 = sama persis; 1 (bawaan) = terbesar yang <= nilai (data naik); -1 = terkecil yang >= nilai (data turun).', fn: matchFn },
  INDEX: { min: 2, max: 3, sig: 'INDEX(rentang; baris; [kolom])', ket: 'Nilai sel pada baris/kolom ke-n di rentang. Rentang satu baris/kolom cukup satu nomor; rentang dua dimensi butuh baris dan kolom.', fn: indexFn },
};
export const FUNCTION_LIST = Object.keys(FUNCS).sort().map((name) => ({ name, sig: FUNCS[name].sig, ket: FUNCS[name].ket }));
export const suggestFunctions = (prefix, limit = 6) => { const p = String(prefix || '').toUpperCase(); return FUNCTION_LIST.filter((f) => f.name.startsWith(p)).slice(0, limit); };

// ---------------------------------------------------------------- evaluator
function rectOf(n, cx) {
  const a = cx.pos(n.a); if (!a) return null; const b = n.b ? cx.pos(n.b) : a; if (!b) return null;
  return { r0: Math.min(a.r, b.r), c0: Math.min(a.c, b.c), h: Math.abs(a.r - b.r) + 1, w: Math.abs(a.c - b.c) + 1 };
}
function rngOf(n, cx) { const r = rectOf(n, cx); if (!r) return E.REF; const vals = []; for (let i = 0; i < r.h; i++) for (let j = 0; j < r.w; j++) vals.push(cx.at(r.r0 + i, r.c0 + j)); return { rng: true, ...r, vals }; }
const evalArg = (n, cx) => (n.k === 'ref' ? rngOf(n, cx) : evalNode(n, cx));
function arith(op, a, b) {
  if (isErr(a)) return a; if (isErr(b)) return b; const x = num(a); if (isErr(x)) return x; const y = num(b); if (isErr(y)) return y; let r;
  switch (op) {
    case '+': r = x + y; break; case '-': r = x - y; break; case '*': r = x * y; break;
    case '/': if (y === 0) return E.DIV0; r = x / y; break;
    default: if (x === 0 && y === 0) return E.NUM; if (x === 0 && y < 0) return E.DIV0; r = Math.pow(x, y);
  }
  return Number.isFinite(r) ? r : E.NUM;
}
function evalNode(n, cx) {
  switch (n.k) {
    case 'num': case 'str': case 'bool': return n.v;
    case 'blank': return null;
    case 'name': return E.NAME;
    case 'referr': return E.REF;
    case 'ref': { const r = rectOf(n, cx); if (!r) return E.REF; return r.h === 1 && r.w === 1 ? cx.at(r.r0, r.c0) : E.VALUE; }
    case 'un': { const v = num(evalNode(n.x, cx)); return isErr(v) ? v : n.op === '-' ? (v === 0 ? 0 : -v) : v; }
    case 'pct': { const v = num(evalNode(n.x, cx)); return isErr(v) ? v : v / 100; }
    case 'bin': {
      const a = evalNode(n.l, cx), b = evalNode(n.r, cx);
      if (n.op === '+' || n.op === '-' || n.op === '*' || n.op === '/' || n.op === '^') return arith(n.op, a, b);
      if (isErr(a)) return a; if (isErr(b)) return b;
      if (n.op === '&') return text(a) + text(b);
      const c = compare(a, b);
      switch (n.op) { case '=': return c === 0; case '<>': return c !== 0; case '<': return c < 0; case '>': return c > 0; case '<=': return c <= 0; default: return c >= 0; }
    }
    case 'fn': {
      const f = FUNCS[n.name]; if (!f) return E.NAME; if (n.args.length < f.min || n.args.length > f.max || (f.par !== undefined && n.args.length % 2 !== f.par)) return E.VALUE;
      if (n.name === 'IFERROR') { const v = evalNode(n.args[0], cx); return isErr(v) && v !== E.CIRC ? evalNode(n.args[1], cx) : v; } // Rev 138: galat lingkaran (#CIRC!) TIDAK ditelan supaya lingkaran tetap terlihat
      if (f.lazy) { // IF: hanya cabang terpilih yang dihitung
        const c = bool(evalNode(n.args[0], cx)); if (isErr(c)) return c;
        if (c) return evalNode(n.args[1], cx); return n.args.length > 2 ? evalNode(n.args[2], cx) : false;
      }
      const args = n.args.map((x) => evalArg(x, cx));
      const r = f.fn(args, cx); return typeof r === 'number' && !Number.isFinite(r) ? E.NUM : r;
    }
    default: return E.VALUE;
  }
}

// ---------------------------------------------------------------- ketergantungan
function rectsOf(ast, cx, out) { // rentang yang dibaca rumus (untuk urutan hitung); SUMIF: rentang_jumlah ikut diperluas ke ukuran rentang pertama
  const walk = (n) => {
    if (!n) return;
    if (n.k === 'ref') { const r = rectOf(n, cx); if (r) out.push(r); return; }
    if (n.k === 'bin') { walk(n.l); walk(n.r); return; } if (n.k === 'un' || n.k === 'pct') { walk(n.x); return; }
    if (n.k === 'fn') {
      for (const a of n.args) walk(a);
      if ((n.name === 'SUMIF' || n.name === 'AVERAGEIF') && n.args.length === 3 && n.args[0].k === 'ref' && n.args[2].k === 'ref') { const r1 = rectOf(n.args[0], cx), r3 = rectOf(n.args[2], cx); if (r1 && r3) out.push({ r0: r3.r0, c0: r3.c0, h: r1.h, w: r1.w }); }
    }
  };
  walk(ast);
}

// Hitung SEMUA sel berumus pada satu tab. Mengembalikan { get(rowId, colId) -> nilai|undefined, values: Map('rowId.colId' -> nilai), count, circular, evalExpr(fx) }.
export function computeTab(tab, opts = {}) {
  const now = Number.isFinite(opts.now) ? opts.now : Date.now();
  const rows = (tab && tab.rows) || [], cols = (tab && tab.cols) || [];
  const rowIdx = new Map(rows.map((r, i) => [r.id, i])), colIdx = new Map(cols.map((c, i) => [c.id, i]));
  const K = (ri, ci) => ri * 1024 + ci, out = new Map(), fcells = new Map();
  const cx = {
    now,
    pos: (ref) => { const r = rowIdx.get(ref.r), c = colIdx.get(ref.c); return r === undefined || c === undefined ? null : { r, c }; },
    at: (ri, ci) => {
      if (ri < 0 || ci < 0 || ri >= rows.length || ci >= cols.length) return null;
      const k = K(ri, ci); if (fcells.has(k)) { const v = out.get(k); return v === undefined ? E.CIRC : v; }
      const cell = rows[ri].cells && rows[ri].cells[cols[ci].id]; const v = cell ? cell.v : undefined; return v === undefined ? null : v;
    },
  };
  for (let ri = 0; ri < rows.length; ri++) {
    const cells = rows[ri].cells || {};
    for (const colId of Object.keys(cells)) { const ci = colIdx.get(colId), cell = cells[colId]; if (ci !== undefined && cell && typeof cell.fx === 'string' && cell.fx[0] === '=') fcells.set(K(ri, ci), { ri, ci, rowId: rows[ri].id, colId, fx: cell.fx }); }
  }
  const indeg = new Map(), dependents = new Map(), asts = new Map(); let circular = 0;
  for (const [k, f] of fcells) {
    const ps = parseFormula(f.fx, 'stored'); indeg.set(k, 0); if (!ps.ok) { asts.set(k, null); continue; } asts.set(k, ps.ast);
  }
  const fl = [...fcells.keys()];
  for (const [k, ast] of asts) {
    if (!ast) continue; const rects = []; rectsOf(ast, cx, rects); const seen = new Set();
    for (const r of rects) {
      const add = (g) => { if (!seen.has(g)) { seen.add(g); (dependents.get(g) || dependents.set(g, []).get(g)).push(k); indeg.set(k, indeg.get(k) + 1); } };
      if (r.h * r.w <= fl.length) { for (let i = 0; i < r.h; i++) for (let j = 0; j < r.w; j++) { const g = K(r.r0 + i, r.c0 + j); if (fcells.has(g)) add(g); } }
      else for (const g of fl) { const ri = Math.floor(g / 1024), ci = g % 1024; if (ri >= r.r0 && ri < r.r0 + r.h && ci >= r.c0 && ci < r.c0 + r.w) add(g); }
    }
  }
  const queue = []; for (const [k, d] of indeg) if (d === 0) queue.push(k);
  const finish = (k, v) => { if (isRng(v)) v = E.VALUE; out.set(k, v === null || v === undefined ? 0 : v); };
  for (let q = 0; q < queue.length; q++) {
    const k = queue[q], ast = asts.get(k); finish(k, ast ? evalNode(ast, cx) : E.NAME);
    for (const d of dependents.get(k) || []) { const left = indeg.get(d) - 1; indeg.set(d, left); if (left === 0) queue.push(d); }
  }
  for (const k of fl) if (!out.has(k)) { out.set(k, E.CIRC); circular++; }
  const values = new Map(); for (const [k, f] of fcells) values.set(f.rowId + '.' + f.colId, out.get(k));
  return {
    values, count: fcells.size, circular,
    get: (rowId, colId) => values.get(rowId + '.' + colId),
    evalExpr: (fx) => { const ps = parseFormula(fx, 'stored'); if (!ps.ok) return E.NAME; const v = evalNode(ps.ast, cx); return isRng(v) ? E.VALUE : v === null || v === undefined ? 0 : v; },
  };
}

// ---------------------------------------------------------------- konversi A1 <-> simpan (berbasis token; spasi dirapikan)
function emit(tokens, to, tab) {
  const rows = (tab && tab.rows) || [], cols = (tab && tab.cols) || []; let s = '=';
  const rowI = (id) => rows.findIndex((r) => r.id === id), colI = (id) => cols.findIndex((c) => c.id === id);
  for (const t of tokens) {
    switch (t.t) {
      case 'num': s += to === 'a1' ? numToText(t.v).replace('.', ',') : numToText(t.v); break;
      case 'str': s += '"' + t.v.replace(/"/g, '""') + '"'; break;
      case 'bool': s += t.v ? 'TRUE' : 'FALSE'; break;
      case 'name': s += t.v; break; case 'fn': s += t.v; break; case 'referr': s += '#REF!'; break;
      case 'op': s += t.v; break; case '(': case ')': s += t.t; break;
      case 'sep': s += to === 'a1' ? ';' : ','; break;
      case 'ref': {
        const parts = [t.a, t.b].filter(Boolean).map((x) => {
          if (to === 'stored') { const r = rows[x.r], c = cols[x.c]; return r && c ? (x.ar ? '$' : '') + r.id + '.' + (x.ac ? '$' : '') + c.id : null; }
          const ri = rowI(x.r), ci = colI(x.c); return ri < 0 || ci < 0 || ci >= LIM_COLS ? null : (x.ac ? '$' : '') + String.fromCharCode(65 + ci) + (x.ar ? '$' : '') + (ri + 1);
        });
        if (parts.includes(null)) { s += '#REF!'; break; }
        s += to === 'stored' ? '[' + parts.join(':') + ']' : parts.join(':'); break;
      }
      default: break;
    }
  }
  return s;
}
function checkAst(n) { // fungsi tak dikenal, jumlah argumen, nama tak dikenal
  if (!n) return null;
  if (n.k === 'name') return 'Nama tidak dikenal: ' + n.v;
  if (n.k === 'bin') return checkAst(n.l) || checkAst(n.r); if (n.k === 'un' || n.k === 'pct') return checkAst(n.x);
  if (n.k === 'fn') {
    const f = FUNCS[n.name]; if (!f) return 'Fungsi tidak dikenal: ' + n.name;
    if (n.args.length < f.min || n.args.length > f.max || (f.par !== undefined && n.args.length % 2 !== f.par)) return 'Jumlah argumen ' + n.name + ' salah. Bentuk: ' + f.sig;
    for (const a of n.args) { const e = checkAst(a); if (e) return e; }
  }
  return null;
}
// Teks yang diketik pengguna (A1) -> bentuk simpan. Menolak sintaks salah, fungsi/nama tak dikenal, jumlah argumen salah, dan rujukan di luar tab (baris belum ada).
export function a1ToStored(text, tab) {
  const ps = parseFormula(text, 'a1'); if (!ps.ok) return ps;
  const bad = ps.tokens.find((t) => t.t === 'ref' && (t.bad || [t.a, t.b].some((x) => x && (!tab.rows[x.r] || !tab.cols[x.c]))));
  if (bad) return { ok: false, error: bad.bad ? 'Rujukan di luar lembar (kolom A-Z, baris 1-' + LIM_ROWS + ')' : 'Baris atau kolom yang dirujuk belum ada' };
  const e = checkAst(ps.ast); if (e) return { ok: false, error: e };
  const fx = emit(ps.tokens, 'stored', tab); if (fx.length > MAX_FX + 200) return { ok: false, error: 'Rumus terlalu panjang' };
  return { ok: true, fx };
}
// Bentuk simpan -> teks A1 untuk layar (ID yang sudah tidak ada jadi #REF!). Rumus rusak dikembalikan apa adanya.
export function storedToA1(fx, tab) { const ps = parseFormula(fx, 'stored'); return ps.ok ? emit(ps.tokens, 'a1', tab) : String(fx); }
// Rev 170: SALIN rumus ke sel lain dengan menggeser rujukan RELATIF (dr baris, dc kolom); rujukan bertanda $ tetap (seperti Excel). Rujukan yang jatuh di luar lembar menjadi #REF! dan dilaporkan (lost). Murni; rumus rusak = null.
export function shiftFx(fx, tab, dr, dc) {
  const a1 = storedToA1(fx, tab); const ps = /^=/.test(a1) ? parseFormula(a1, 'a1') : null; if (!ps || !ps.ok) return null;
  const nr = tab.rows.length, nc = tab.cols.length; let lost = false;
  const inside = (x) => !x || (x.r >= 0 && x.r < nr && x.c >= 0 && x.c < nc);
  const toks = ps.tokens.map((t) => {
    if (t.t !== 'ref' || t.bad) return t;
    const mv = (x) => (x ? { ...x, r: x.ar ? x.r : x.r + dr, c: x.ac ? x.c : x.c + dc } : x);
    const a = mv(t.a), b = mv(t.b); if (!inside(a) || !inside(b)) lost = true; return { ...t, a, b };
  });
  const out = emit(toks, 'stored', tab); return out.length > MAX_FX + 200 ? null : { fx: out, lost };
}
