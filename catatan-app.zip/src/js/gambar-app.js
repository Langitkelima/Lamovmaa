// Rev 45 / G3: import, kompres, penyimpanan berkas, pemuatan malas, dan pembersihan gambar.
import * as G from './gambar.js';
import { isNative, nativePlugin } from './native.js';
import { wasLoadFailure } from './storage.js';

const DIR = 'DATA';
const b64 = (bytes) => {
  let out = ''; const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) out += String.fromCharCode(...bytes.subarray(i, i + step));
  return btoa(out);
};
const fromB64 = (s) => {
  const raw = atob(s), out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
};
export const imageFS = () => nativePlugin('Filesystem');

function canvasBlob(canvas, mime, quality) {
  return new Promise((resolve, reject) => canvas.toBlob((b) => b ? resolve(b) : reject(new Error('Kompres gambar gagal.')), mime, quality));
}
export async function sourceDimensions(file) {
  const a = new Uint8Array(await file.slice(0, Math.min(file.size, 512 * 1024)).arrayBuffer());
  // PNG: IHDR
  if (a.length >= 24 && a[0] === 137 && a[1] === 80 && a[2] === 78 && a[3] === 71) {
    const v = new DataView(a.buffer, a.byteOffset, a.byteLength); return { w: v.getUint32(16), h: v.getUint32(20) };
  }
  // JPEG: cari marker SOF tanpa mendekode piksel.
  if (a.length >= 4 && a[0] === 255 && a[1] === 216) {
    let i = 2;
    while (i + 9 < a.length) {
      if (a[i] !== 255) { i++; continue; }
      while (a[i] === 255) i++;
      const marker = a[i++]; if (marker === 0xD9 || marker === 0xDA) break;
      if (marker >= 0xD0 && marker <= 0xD7) continue;
      const len = (a[i] << 8) | a[i + 1]; if (len < 2 || i + len > a.length) break;
      if ([0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF].includes(marker)) return { h: (a[i + 3] << 8) | a[i + 4], w: (a[i + 5] << 8) | a[i + 6] };
      i += len;
    }
  }
  // WebP VP8X/VP8L: dimensi tersimpan di header RIFF.
  if (a.length >= 30 && String.fromCharCode(...a.slice(0, 4)) === 'RIFF' && String.fromCharCode(...a.slice(8, 12)) === 'WEBP') {
    const tag = String.fromCharCode(...a.slice(12, 16));
    if (tag === 'VP8X') return { w: 1 + a[24] + (a[25] << 8) + (a[26] << 16), h: 1 + a[27] + (a[28] << 8) + (a[29] << 16) };
    if (tag === 'VP8 ' && a[23] === 0x9D && a[24] === 0x01 && a[25] === 0x2A) return { w: ((a[27] << 8) | a[26]) & 0x3FFF, h: ((a[29] << 8) | a[28]) & 0x3FFF };
    if (tag === 'VP8L' && a[20] === 0x2F) { const b1=a[21],b2=a[22],b3=a[23],b4=a[24]; return { w: 1 + (((b2 & 0x3F) << 8) | b1), h: 1 + (((b4 & 0x0F) << 10) | (b3 << 2) | ((b2 & 0xC0) >> 6)) }; }
  }
  throw new Error('Ukuran gambar tidak terbaca. Gunakan JPG, PNG, atau WebP.');
}
export async function compressImage(file, preset = G.DEFAULT_PRESET) {
  const check = G.checkSource(file);
  if (!check.ok) throw new Error(check.msg);
  if (typeof createImageBitmap !== 'function') throw new Error('Perangkat belum mendukung pemrosesan gambar.');
  const dims = await sourceDimensions(file), plan = G.planCompress(dims, preset);
  if (!plan.ok) throw new Error(plan.msg);
  let bitmap;
  try {
    // Resize dilakukan SAAT decode untuk mencegah foto 108 MP masuk RAM sebagai bitmap penuh.
    const decodeOpts = dims.w >= dims.h
      ? (dims.w > plan.width ? { resizeWidth: plan.width, resizeQuality: 'high' } : undefined)
      : (dims.h > plan.height ? { resizeHeight: plan.height, resizeQuality: 'high' } : undefined);
    bitmap = decodeOpts ? await createImageBitmap(file, decodeOpts) : await createImageBitmap(file);
  } catch (_) { throw new Error('Gambar tidak bisa dibuka. Gunakan JPG, PNG, atau WebP.'); }
  try {
    const alpha = /png|webp/i.test(file.type || '');
    const canvas = document.createElement('canvas'), ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) throw new Error('Canvas gambar tidak tersedia.');
    let result = null, width = plan.width, height = plan.height;
    for (const st of plan.steps) {
      width = st.width; height = st.height;
      canvas.width = width; canvas.height = height; ctx.clearRect(0, 0, width, height);
      ctx.drawImage(bitmap, 0, 0, width, height);
      let blob = await canvasBlob(canvas, 'image/webp', st.quality);
      if (blob.type !== 'image/webp') blob = await canvasBlob(canvas, alpha ? 'image/png' : 'image/jpeg', st.quality);
      result = blob;
      if (blob.size <= plan.maxBytes) break;
    }
    if (!result) throw new Error('Gambar gagal dikompres.');
    if (result.size > plan.maxBytes) throw new Error('Gambar masih terlalu besar setelah dikompres. Pilih foto yang lebih kecil.');
    const ext = result.type === 'image/webp' ? 'webp' : result.type === 'image/png' ? 'png' : 'jpg';
    return { blob: result, w: width, h: height, b: result.size, x: ext };
  } finally { try { bitmap.close(); } catch (_) {} }
}
export async function writeImage(FS, ref, blob) {
  try { await FS.mkdir({ path: G.IMAGE_DIR, directory: DIR, recursive: true }); } catch (_) {}
  const bytes = new Uint8Array(await blob.arrayBuffer());
  await FS.writeFile({ path: G.imagePath(ref), directory: DIR, data: b64(bytes) });
}
export async function readImageBlob(FS, ref) {
  const r = await FS.readFile({ path: G.imagePath(ref), directory: DIR });
  const bytes = typeof r.data === 'string' ? fromB64(r.data) : new Uint8Array(await r.data.arrayBuffer());
  const mime = ref.x === 'jpg' ? 'image/jpeg' : 'image/' + ref.x;
  return new Blob([bytes], { type: mime });
}

// Rev 430: tanda gagal-muat TIDAK ditulis sebagai teks di dalam <figure> (sanitize() menyimpan teks di dalam figure ke HTML catatan,
// jadi pesan ikut tersimpan/tersinkron). Pesan = atribut `data-pesan` yang digambar CSS (::after); atribut itu tidak ada di daftar
// putih sanitize(), jadi tidak pernah tersimpan.
export function markImageFailed(fig, native = isNative()) {
  fig.dataset.loaded = 'error'; fig.dataset.pesan = G.pesanGambarGagal(native); fig.replaceChildren();
}
// Versi web/laptop: tidak ada Filesystem native, jadi semua gambar yang belum termuat ditandai "hanya ada di HP".
export function markImagesUnavailable(root, native = isNative()) {
  for (const fig of root.querySelectorAll('figure.ki[data-kimg]')) if (fig.dataset.loaded !== '1') markImageFailed(fig, native);
}

// figure tetap ringan dalam HTML. Hanya gambar dekat viewport yang dibaca dari Filesystem.
export function hydrateImages(root, FS, urlSet, onError = () => {}) {
  const figures = [...root.querySelectorAll('figure.ki[data-kimg]')];
  const load = async (fig) => {
    if (!fig.isConnected || fig.dataset.loaded === '1') return;
    fig.dataset.loaded = '1';
    const ref = { id: fig.dataset.kimg, x: fig.dataset.x || 'webp' };
    try {
      const blob = await readImageBlob(FS, ref);
      if (!fig.isConnected) return;
      const url = URL.createObjectURL(blob); urlSet.add(url);
      const img = document.createElement('img'); img.alt = 'Gambar catatan'; img.loading = 'lazy'; img.decoding = 'async';
      img.width = Number(fig.dataset.w) || 1; img.height = Number(fig.dataset.h) || 1; img.src = url;
      fig.replaceChildren(img);
    } catch (e) { markImageFailed(fig); onError(e); }
  };
  let observer;
  if ('IntersectionObserver' in globalThis) {
    observer = new IntersectionObserver((entries) => { for (const e of entries) if (e.isIntersecting) { observer.unobserve(e.target); load(e.target); } }, { root, rootMargin: '240px 0px' });
    figures.forEach((f) => observer.observe(f));
  } else figures.forEach(load);
  return () => { if (observer) observer.disconnect(); };
}

export async function cleanupOrphanImages(data, now = Date.now()) {
  if (wasLoadFailure()) return { removed: 0 }; // Rev 295 / 4-1
  try {
    const FS = imageFS();
    let listing;
    try { listing = await FS.readdir({ path: G.IMAGE_DIR, directory: DIR }); } catch (_) { return { removed: 0 }; }
    const refs = G.refsOfData(data);
    const files = [];
    for (const f of listing.files || []) {
      if (!f || typeof f.name !== 'string') continue;
      let mtime = 0;
      try { const st = await FS.stat({ path: G.IMAGE_DIR + '/' + f.name, directory: DIR }); mtime = st.mtime ? new Date(st.mtime).getTime() : Number(st.mtime || st.ctime || 0); } catch (_) {}
      files.push({ name: f.name, mtime });
    }
    const orphan = G.findOrphans(files, refs, now);
    let removed = 0;
    for (const name of orphan) { try { await FS.deleteFile({ path: G.IMAGE_DIR + '/' + name, directory: DIR }); removed++; } catch (_) {} }
    return { removed };
  } catch (_) { return { removed: 0 }; }
}

// ---- Rev 60 (G4): pemakaian dan pembersihan manual (Setelan > Gambar) ----
async function listImageFiles(FS) {
  let listing;
  try { listing = await FS.readdir({ path: G.IMAGE_DIR, directory: DIR }); } catch (_) { return []; }
  const files = [];
  for (const f of listing.files || []) {
    if (!f || typeof f.name !== 'string') continue;
    let mtime = 0, size = Number(f.size) || 0;
    try {
      const st = await FS.stat({ path: G.IMAGE_DIR + '/' + f.name, directory: DIR });
      mtime = st.mtime ? new Date(st.mtime).getTime() : Number(st.mtime || st.ctime || 0);
      if (Number.isFinite(Number(st.size)) && Number(st.size) > 0) size = Number(st.size);
    } catch (_) {}
    files.push({ name: f.name, size, mtime });
  }
  return files;
}
// Ringkasan: dipakai catatan (dari data) + berkas nyata di HP + yang tak terpakai. Hanya membaca, tidak mengubah apa pun.
export async function scanImages(data, now = Date.now(), FS = imageFS()) {
  const files = await listImageFiles(FS);
  return G.summarizeImages(G.refsOfData(data), files, now, G.MANUAL_GRACE_MS);
}
// Hapus berkas yang tidak dirujuk catatan mana pun (Catatan, Privat, Tempat sampah). Yang ditulis < 5 menit lalu dilewati.
export async function clearUnusedImages(data, now = Date.now(), FS = imageFS()) {
  if (wasLoadFailure()) return { removed: 0, freed: 0 };
  const sum = await scanImages(data, now, FS);
  const sizeOf = new Map((await listImageFiles(FS)).map((f) => [f.name, f.size]));
  let removed = 0, freed = 0;
  for (const name of sum.orphans) {
    try { await FS.deleteFile({ path: G.IMAGE_DIR + '/' + name, directory: DIR }); removed++; freed += sizeOf.get(name) || 0; } catch (_) {}
  }
  return { removed, freed };
}
