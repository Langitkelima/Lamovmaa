// Warna seleksi teks kustom: roda warna (HSV) yang dipanggil lewat tekan lama logo di Setelan.
// Disimpan di settings.selColor ('' = ikut warna bawaan tema). Diterapkan lewat variabel CSS --sel dan --selfg.
import { h } from './ui.js';
import { applySelColor } from './settings.js';

export const SEL_RE = /^#[0-9a-f]{6}$/i;
export const cleanSelColor = (v) => (typeof v === 'string' && SEL_RE.test(v.trim()) ? v.trim().toLowerCase() : '');

function hsv2rgb(hh, s, v) {
  const f = (n) => { const k = (n + hh / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
  return [f(5), f(3), f(1)].map((x) => Math.round(x * 255));
}
function rgb2hsv(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let hh = 0;
  if (d) hh = mx === r ? ((g - b) / d + 6) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return [hh * 60, mx ? d / mx : 0, mx];
}
const toHex = (rgb) => '#' + rgb.map((x) => x.toString(16).padStart(2, '0')).join('');
const fromHex = (x) => [1, 3, 5].map((i) => parseInt(x.slice(i, i + 2), 16));
// Teks di atas seleksi: gelap bila warna terang, terang bila warna gelap (supaya tetap terbaca).
const textOn = (hex) => { const [r, g, b] = fromHex(hex); return (0.299 * r + 0.587 * g + 0.114 * b) > 150 ? '#10162b' : '#ffffff'; };

// Buka dialog roda warna. onSave(hex|'') dipanggil saat Simpan / Setel ulang.
const CSS = `.selpick{text-align:center}
.selbox{position:relative;width:220px;height:220px;margin:12px auto 10px;touch-action:none}
.selwheel{display:block;width:220px;height:220px;border-radius:50%;touch-action:none;box-shadow:0 2px 12px rgba(0,0,0,.18)}
.seldot{position:absolute;width:24px;height:24px;margin:-12px 0 0 -12px;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 1.5px rgba(0,0,0,.45),0 2px 6px rgba(0,0,0,.4);pointer-events:none}
.selval{-webkit-appearance:none;appearance:none;display:block;width:220px;height:16px;margin:6px auto 12px;border-radius:10px;outline:none}
.selval::-webkit-slider-thumb{-webkit-appearance:none;width:24px;height:24px;border-radius:50%;background:#fff;border:2px solid rgba(0,0,0,.4);box-shadow:0 2px 6px rgba(0,0,0,.35)}
.selrow{display:flex;justify-content:center;margin-bottom:8px}
.selhex{width:110px;text-align:center;font:600 15px/1 monospace;padding:9px 10px;border-radius:12px;border:1px solid var(--ln);background:var(--sf);color:var(--ink)}
.selsample{margin:6px 4px 14px;color:var(--ink);font-size:14px}
.selsample mark{background:var(--sel);color:var(--selfg);border-radius:3px;padding:1px 2px}
.selpick .dlgb{gap:8px}`;
function injectCss() { if (document.getElementById('selpick-css')) return; const st = document.createElement('style'); st.id = 'selpick-css'; st.textContent = CSS; document.head.append(st); }

export function openSelColorPicker(current, onSave) {
  injectCss();
  const start = cleanSelColor(current) || '#6a86f2';
  let [H, S, V] = rgb2hsv(...fromHex(start));
  const SIZE = 220, R = SIZE / 2;
  const cv = h('canvas', { width: SIZE, height: SIZE, class: 'selwheel', 'aria-label': 'Roda warna' });
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(SIZE, SIZE);
  const draw = () => {
    for (let y = 0; y < SIZE; y++) for (let x = 0; x < SIZE; x++) {
      const dx = x - R + 0.5, dy = y - R + 0.5, d = Math.hypot(dx, dy), i = (y * SIZE + x) * 4;
      if (d > R) { img.data[i + 3] = 0; continue; }
      const hue = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360;
      const [r, g, b] = hsv2rgb(hue, d / R, V);
      img.data[i] = r; img.data[i + 1] = g; img.data[i + 2] = b;
      img.data[i + 3] = d > R - 1 ? Math.round((R - d) * 255) : 255;
    }
    ctx.putImageData(img, 0, 0);
  };
  const dot = h('i', { class: 'seldot' });
  const hexIn = h('input', { class: 'selhex', type: 'text', maxlength: 7, spellcheck: 'false', autocapitalize: 'off', 'aria-label': 'Kode warna' });
  const slider = h('input', { type: 'range', min: 0, max: 100, class: 'selval', 'aria-label': 'Terang' });
  const sample = h('p', { class: 'selsample' }, 'Contoh teks yang ', h('mark', {}, 'sedang dipilih'), ' ada di sini.');
  const cur = () => toHex(hsv2rgb(H, S, V));
  const sync = (fromInput) => {
    const hex = cur();
    const a = H * Math.PI / 180;
    dot.style.left = (R + Math.cos(a) * S * R) + 'px'; dot.style.top = (R + Math.sin(a) * S * R) + 'px';
    dot.style.background = hex;
    slider.style.background = `linear-gradient(90deg,#000,${toHex(hsv2rgb(H, S, 1))})`;
    slider.value = Math.round(V * 100);
    if (!fromInput) hexIn.value = hex;
    sample.style.setProperty('--sel', hex); sample.style.setProperty('--selfg', textOn(hex));
    applySelColor(hex); // pratinjau langsung di seluruh aplikasi
  };
  let lastV = -1;
  const pick = (e) => {
    const r = cv.getBoundingClientRect(), dx = (e.clientX - r.left) * SIZE / r.width - R, dy = (e.clientY - r.top) * SIZE / r.height - R;
    H = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360; S = Math.min(1, Math.hypot(dx, dy) / R);
    sync();
  };
  let drag = false;
  cv.addEventListener('pointerdown', (e) => { drag = true; cv.setPointerCapture(e.pointerId); pick(e); });
  cv.addEventListener('pointermove', (e) => { if (drag) pick(e); });
  cv.addEventListener('pointerup', () => { drag = false; });
  cv.addEventListener('pointercancel', () => { drag = false; });
  slider.addEventListener('input', () => { V = slider.value / 100; if (V !== lastV) { lastV = V; draw(); } sync(); });
  hexIn.addEventListener('input', () => {
    let t = hexIn.value.trim(); if (t && t[0] !== '#') t = '#' + t;
    if (SEL_RE.test(t)) { [H, S, V] = rgb2hsv(...fromHex(t)); draw(); sync(true); }
  });

  const prev = cleanSelColor(current);
  const ov = h('div', { class: 'ov dlgov' });
  const close = () => { ov.remove(); };
  const cancel = () => { applySelColor(prev); close(); };
  ov.append(h('div', { class: 'sheet dlg selpick' },
    h('h3', {}, 'Warna seleksi teks'),
    h('p', { class: 'sub' }, 'Geser di roda untuk memilih warna. Berlaku untuk tema terang dan gelap.'),
    h('div', { class: 'selbox' }, cv, dot),
    slider,
    h('div', { class: 'selrow' }, hexIn),
    sample,
    h('div', { class: 'dlgb' },
      h('button', { type: 'button', class: 'btn line', onclick: cancel }, 'Batal'),
      h('button', { type: 'button', class: 'btn line', onclick: () => { applySelColor(''); close(); onSave(''); } }, 'Bawaan'),
      h('button', { type: 'button', class: 'btn', onclick: () => { const c = cur(); close(); onSave(c); } }, 'Simpan'))));
  document.body.append(ov);
  draw(); sync();
}
