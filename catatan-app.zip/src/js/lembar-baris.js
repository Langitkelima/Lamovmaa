// Rev 184b / U10e-2: hitung TINGGI BARIS BEBAS untuk grid lembar kerja (MURNI: tanpa DOM, tanpa penyimpanan).
// Data tinggi (`row.h`) ada di lembar.js (Rev 184a). Di sini hanya hitungan posisi, jendela gulir, dan batas seret.
// Pagar teknis (BUKAN batas per baris): tinggi TOTAL grid dibatasi GRID_MAX_H karena elemen setinggi puluhan juta piksel tidak bisa digambar WebView.
export const GRID_MAX_H = 16000000, ROW_MIN = 16, ROW_DEF = 40, HEAD = 32, SNAP = 3;

// heights = tinggi tiap baris TAMPIL (urutan tampil). Mengembalikan { tops, eff }: tops[k] = posisi atas baris k (tops[n] = total), eff[k] = tinggi yang dipakai menggambar.
// Bila jumlah melewati cap, baris belakang dipersempit (minimal ROW_MIN) supaya total tidak melewati cap; data tidak diubah.
export function rowTops(heights, cap = GRID_MAX_H, min = ROW_MIN) {
  const n = Array.isArray(heights) ? heights.length : 0, tops = new Array(n + 1), eff = new Array(n);
  let y = 0; tops[0] = 0;
  for (let k = 0; k < n; k++) {
    const h0 = Number(heights[k]), h = Number.isFinite(h0) && h0 >= min ? Math.round(h0) : min;
    const room = Math.max(min, cap - y - (n - k - 1) * min); // sisakan ruang minimal untuk baris sesudahnya
    const e = Math.min(h, room); eff[k] = e; y += e; tops[k + 1] = y;
  }
  return { tops, eff };
}

// Jendela baris yang perlu digambar: { from, to } (to eksklusif) di [0, n]. Pencarian biner pada tops; buffer = baris tambahan di atas dan bawah.
export function visibleRangeH(tops, scrollTop, viewH, buffer = 6) {
  const n = Array.isArray(tops) ? tops.length - 1 : 0; if (n <= 0) return { from: 0, to: 0 };
  const st = Math.max(0, Number(scrollTop) || 0), vh = Math.max(0, Number(viewH) || 0), end = st + vh;
  const lastLE = (v) => { let lo = 0, hi = n - 1, a = 0; while (lo <= hi) { const m = (lo + hi) >> 1; if (tops[m] <= v) { a = m; lo = m + 1; } else hi = m - 1; } return a; }; // baris terakhir yang atasnya <= v
  const first = lastLE(st), last = lastLE(end);
  const from = Math.max(0, first - buffer), to = Math.min(n, Math.max(from, last + 1 + buffer));
  return { from, to };
}

// Tinggi baru saat garis diseret: tinggi awal + geseran vertikal (px), dibulatkan, minimal ROW_MIN, dan dijaga agar total grid (baris lain = others) tidak melewati cap.
// Dekat tinggi bawaan (40 +- SNAP) menempel ke 40 supaya mudah kembali ke bawaan. Masukan rusak = tinggi awal.
export function dragRowHeight(startH, dy, others = 0, cap = GRID_MAX_H, min = ROW_MIN) { return dragRowHeightN(startH, dy, 1, others, cap, min); }

// Rev 253 / S4: sama seperti dragRowHeight tetapi untuk `count` baris yang diubah SAMA besar sekaligus (seleksi baris). `others` = jumlah tinggi baris yang TIDAK ikut berubah;
// pagar total: others + count * tinggi <= cap - HEAD. count < 1 / rusak dianggap 1.
export function dragRowHeightN(startH, dy, count = 1, others = 0, cap = GRID_MAX_H, min = ROW_MIN) {
  const s = Number(startH), d = Number(dy), o = Math.max(0, Number(others) || 0), cn = Math.max(1, Math.floor(Number(count)) || 1);
  const base = Number.isFinite(s) ? s : ROW_DEF; let n = Math.round(base + (Number.isFinite(d) ? d : 0));
  const maxAllowed = Math.max(min, Math.floor((cap - HEAD - o) / cn)); n = Math.max(min, Math.min(n, maxAllowed));
  if (Math.abs(n - ROW_DEF) <= SNAP && ROW_DEF <= maxAllowed) n = ROW_DEF;
  return n;
}
