// Rev 129 / U8a-4a: pembantu MURNI untuk mengetik rumus di bilah isian lembar kerja (tanpa DOM, penyimpanan, native, eval).
// formulaContext: dari teks isian + posisi kursor -> awalan nama fungsi yang sedang diketik, fungsi pembungkus terdalam, dan nomor argumen.
// argHint: petunjuk argumen dari FUNCTION_LIST[].sig. applySuggestion: ganti awalan dengan NAMA( (atau NAMA() bila tanpa argumen).
// Pemisah argumen di bentuk A1 = ';' (',' juga diterima mesin, tetapi 'angka,angka' dibaca desimal seperti di tokenizer rumus.js).
import { FUNCTION_LIST, suggestFunctions } from './rumus.js';

const byName = (n) => FUNCTION_LIST.find((f) => f.name === String(n || '').toUpperCase()) || null;
const clampCaret = (s, caret) => { const n = Number(caret); return Math.max(0, Math.min(s.length, Number.isFinite(n) ? Math.floor(n) : s.length)); };

// Koma di posisi i = desimal (bukan pemisah) bila didahului angka murni (bukan bagian rujukan sel seperti A1) dan diikuti angka.
function commaIsDecimal(s, i) {
  if (!/\d/.test(s[i + 1] || '')) return false;
  let j = i - 1; while (j >= 0 && /[\d.]/.test(s[j])) j--;
  if (j === i - 1) return false; // tidak ada angka sebelum koma
  return !/[A-Za-z$\]]/.test(s[j] || '');
}

// null bila teks bukan rumus. Selain itu { prefix, start, fn, arg, depth }:
//  prefix = huruf nama fungsi yang sedang diketik tepat di kursor ('' bila tidak ada), start = indeks awal prefix di teks,
//  fn = nama fungsi terdalam yang kurungnya masih terbuka (huruf besar; null bila di luar kurung / kurung biasa), arg = nomor argumen (mulai 0), depth = kedalaman kurung.
export function formulaContext(text, caret) {
  const s = String(text == null ? '' : text), c = clampCaret(s, caret), head = s.slice(0, c);
  if (!/^\s*=/.test(head)) return null;
  const eq = head.indexOf('=');
  const stack = []; let inStr = false;
  for (let i = eq + 1; i < head.length; i++) {
    const ch = head[i];
    if (inStr) { if (ch === '"') inStr = false; continue; }
    if (ch === '"') { inStr = true; continue; }
    if (ch === '(') { const m = /([A-Za-z][A-Za-z0-9]*)\s*$/.exec(head.slice(eq + 1, i)); stack.push({ name: m ? m[1].toUpperCase() : null, arg: 0 }); continue; }
    if (ch === ')') { stack.pop(); continue; }
    if (ch === ';' || (ch === ',' && !commaIsDecimal(s, i))) { if (stack.length) stack[stack.length - 1].arg++; }
  }
  const top = stack.length ? stack[stack.length - 1] : null;
  let prefix = '', start = c;
  if (!inStr) { const m = /(?:^|[^A-Za-z0-9_.$:\]\[])([A-Za-z]+)$/.exec(head.slice(eq + 1)); if (m) { prefix = m[1]; start = c - prefix.length; } }
  return { prefix, start, fn: top && top.name && byName(top.name) ? top.name : null, arg: top ? top.arg : 0, depth: stack.length };
}

// Petunjuk argumen untuk fungsi `name` dan nomor argumen `argIndex`. null bila fungsi tidak dikenal.
// { name, sig, ket, parts: [teks argumen], active } ; active = indeks argumen yang disorot (-1 bila fungsi tanpa argumen); melewati batas = argumen terakhir.
export function argHint(name, argIndex = 0) {
  const f = byName(name); if (!f) return null;
  const m = /\((.*)\)\s*$/.exec(f.sig), inner = m ? m[1].trim() : '';
  const parts = inner ? inner.split(';').map((p) => p.trim()).filter(Boolean) : [];
  if (parts.length > 1 && /^…/.test(parts[parts.length - 1])) { const last = parts.pop(); parts[parts.length - 1] += '; ' + last; } // '[nilai2; …]' = satu bagian (argumen berulang)
  const k = Math.max(0, Math.floor(Number(argIndex)) || 0);
  return { name: f.name, sig: f.sig, ket: f.ket, parts, active: parts.length ? Math.min(k, parts.length - 1) : -1 };
}

// Saran fungsi untuk konteks (maks `limit`). Kosong bila belum ada huruf yang diketik atau tidak di dalam rumus.
export function suggestionsFor(ctx, limit = 6) { return ctx && ctx.prefix ? suggestFunctions(ctx.prefix, limit) : []; }

// Ganti awalan di [ctx.start, caret) dengan NAMA( ; fungsi tanpa argumen -> NAMA() dengan kursor sesudah ')'. Tanda '(' yang sudah ada tepat di kursor tidak digandakan.
export function applySuggestion(text, caret, name) {
  const s = String(text == null ? '' : text), c = clampCaret(s, caret), ctx = formulaContext(s, c), f = byName(name);
  if (!ctx || !f) return { text: s, caret: c };
  const noArg = /\(\s*\)\s*$/.test(f.sig), after = s.slice(c), hasParen = after[0] === '(';
  const ins = f.name + (hasParen ? '' : noArg ? '()' : '(');
  const out = s.slice(0, ctx.start) + ins + after, pos = ctx.start + f.name.length + (hasParen ? 1 : noArg ? 2 : 1);
  return { text: out, caret: pos };
}

// Rev 130 / U8a-4b: tebakan tombol Σ (seperti AutoSum). MURNI. Dari sel (r, c): angka yang berurutan LANGSUNG di atasnya (satu kolom); bila tidak ada,
// angka berurutan LANGSUNG di kirinya (satu baris). Sel angka = v bertipe number, atau sel berumus (fx). Teks/kosong menghentikan deretan.
// -> { text: '=SUM(A1:A2)', dir: 'up'|'left' } atau null bila tidak ada deretan (UI lalu menyisipkan '=SUM(' saja).
const colName = (i) => String.fromCharCode(65 + i);
const isNumCell = (cell) => !!cell && (typeof cell.fx === 'string' || (typeof cell.v === 'number' && Number.isFinite(cell.v)));
export function sumGuess(tab, r, c) {
  if (!tab || !Array.isArray(tab.rows) || !Array.isArray(tab.cols) || !Number.isInteger(r) || !Number.isInteger(c) || r < 0 || c < 0 || r >= tab.rows.length || c >= tab.cols.length) return null;
  const at = (rr, cc) => { const row = tab.rows[rr], col = tab.cols[cc]; return row && col && row.cells ? row.cells[col.id] || null : null; };
  let a = r - 1; while (a >= 0 && isNumCell(at(a, c))) a--;
  if (a < r - 1) { const top = a + 1, from = colName(c) + (top + 1), to = colName(c) + r; return { text: top === r - 1 ? '=SUM(' + from + ')' : '=SUM(' + from + ':' + to + ')', dir: 'up' }; }
  let b = c - 1; while (b >= 0 && isNumCell(at(r, b))) b--;
  if (b < c - 1) { const left = b + 1, from = colName(left) + (r + 1), to = colName(c - 1) + (r + 1); return { text: left === c - 1 ? '=SUM(' + from + ')' : '=SUM(' + from + ':' + to + ')', dir: 'left' }; }
  return null;
}

// Rev 131 / U8a-4c: ketuk sel saat mengetik rumus = SISIP RUJUKAN. MURNI.
// refSlot(text, caret) -> null | { start, end, kind }: bagian teks [start, end) yang diganti rujukan baru.
//  'new'      = kursor tepat sesudah '=', '(', ';', ',' atau operator (+ - * / ^ & < > =): rujukan disisipkan di kursor.
//  'ref'      = kursor tepat sesudah satu rujukan (mis. 'B2'): diganti (ketuk sel lain = menunjuk ulang); boleh dijadikan rentang lewat extendRange.
//  'rangeEnd' = kursor sesudah 'B2:' atau 'B2:C3': hanya ujung rentang yang diganti.
// Di dalam tanda kutip, sesudah ')' / angka / huruf nama fungsi, atau bukan rumus = null (ketuk sel memilih sel seperti biasa).
const REF1 = '\\$?[A-Za-z]\\$?\\d{1,3}';
export function refSlot(text, caret) {
  if (!formulaContext(text, caret)) return null;
  const s = String(text == null ? '' : text), c = clampCaret(s, caret), head = s.slice(0, c), eq = head.indexOf('='), body = head.slice(eq + 1);
  if (((body.match(/"/g) || []).length % 2) === 1) return null;
  let m = new RegExp('(?:^|[^A-Za-z0-9_.$])' + REF1 + ':(' + REF1 + ')?$').exec(body);
  if (m) return { start: c - (m[1] ? m[1].length : 0), end: c, kind: 'rangeEnd' };
  m = new RegExp('(?:^|[^A-Za-z0-9_.$:])(' + REF1 + ')$').exec(body);
  if (m) return { start: c - m[1].length, end: c, kind: 'ref' };
  if (/[=(;,+\-*\/^&<>]\s*$/.test(head)) return { start: c, end: c, kind: 'new' };
  return null;
}
// Sisipkan `ref` ('B2' atau 'B2:C3') di slot. Tanpa slot = teks tidak berubah. Kursor ditaruh sesudah rujukan.
export function insertRef(text, caret, ref) {
  const s = String(text == null ? '' : text), c = clampCaret(s, caret), slot = refSlot(s, c), r = String(ref == null ? '' : ref);
  if (!slot || !new RegExp('^' + REF1 + '(:' + REF1 + ')?$').test(r)) return { text: s, caret: c };
  return { text: s.slice(0, slot.start) + r + s.slice(slot.end), caret: slot.start + r.length };
}
// Tambah ':' sesudah rujukan tunggal supaya ketukan berikut menjadi ujung rentang. Bukan 'ref' = tidak berubah.
export function extendRange(text, caret) {
  const s = String(text == null ? '' : text), c = clampCaret(s, caret), slot = refSlot(s, c);
  if (!slot || slot.kind !== 'ref') return { text: s, caret: c };
  return { text: s.slice(0, c) + ':' + s.slice(c), caret: c + 1 };
}
