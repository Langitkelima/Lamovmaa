// Rev 30: operasi ukuran huruf pada seleksi DOM. Tidak bergantung pada UI.
export const MIN_FONT_SCALE = 70;
export const MAX_FONT_SCALE = 250;
export const FONT_SCALE_STEP = 10;
export function clampFontScale(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 100;
  return Math.max(MIN_FONT_SCALE, Math.min(MAX_FONT_SCALE,
    Math.round(n / FONT_SCALE_STEP) * FONT_SCALE_STEP));
}
function unwrapFontScale(root) {
  for (const el of [...root.querySelectorAll('[data-fs]')]) {
    const p = el.parentNode;
    while (el.firstChild) p.insertBefore(el.firstChild, el);
    el.remove();
  }
}
// Rev 30c: 4 titik ukuran (wajar, tidak berlebihan). Nilai lama di luar daftar tetap terbaca (70-250).
export const FONT_LEVELS = [80, 100, 130, 160];
export const FONT_LEVEL_NAMES = ['Kecil', 'Normal', 'Besar', 'Jumbo'];
export function nearestFontLevel(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 1;
  let best = 0;
  FONT_LEVELS.forEach((l, i) => { if (Math.abs(l - n) < Math.abs(FONT_LEVELS[best] - n)) best = i; });
  return best;
}
// Persentase tidak boleh saling dikalikan: span ukuran tidak pernah bersarang di dalam span ukuran lain.
// Catatan lama yang sudah bersarang dirapikan (span dalam dilepas, nilai luar dipakai).
export function flattenFontScale(root) {
  for (const el of [...root.querySelectorAll('[data-fs] [data-fs]')]) {
    const p = el.parentNode; if (!p) continue;
    while (el.firstChild) p.insertBefore(el.firstChild, el);
    el.remove();
  }
}
const hasContent = (n) => !!((n.textContent || '').length || (n.querySelector && n.querySelector('input,br')));
function outermostScale(node, root) {
  let el = node.nodeType === 1 ? node : node.parentElement, found = null;
  while (el && el !== root && root.contains(el)) { if (el.dataset && el.dataset.fs) found = el; el = el.parentElement; }
  return found;
}
// Mengganti hanya teks yang dipilih; format lain (tebal/warna/dll.) tetap melekat.
// Mengembalikan Range baru yang melingkupi teks hasil format.
export function applyFontScale(root, range, value) {
  if (!root || !range || range.collapsed || !root.contains(range.startContainer) || !root.contains(range.endContainer)) return null;
  const pct = clampFontScale(value);
  const fragment = range.extractContents();
  unwrapFontScale(fragment);
  const span = document.createElement('span');
  if (pct !== 100) { span.dataset.fs = String(pct); span.style.fontSize = pct + '%'; }
  span.append(fragment);
  const host = outermostScale(range.startContainer, root);
  if (host) {
    // Seluruh pilihan ada di dalam span ukuran lama: belah span lama, taruh span baru DI LUAR (sejajar), bukan di dalam.
    const after = document.createRange();
    after.setStart(range.startContainer, range.startOffset);
    after.setEnd(host, host.childNodes.length);
    const tail = host.cloneNode(false); tail.append(after.extractContents());
    host.after(span);
    if (hasContent(tail)) span.after(tail);
    if (!hasContent(host)) host.remove();
  } else range.insertNode(span);
  const next = document.createRange();
  next.selectNodeContents(span);
  const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(next);
  return next;
}
