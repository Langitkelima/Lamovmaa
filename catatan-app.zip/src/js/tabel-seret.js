// Rev 319 / U2a: pegangan seret lebar kolom tabel (DOM, dimuat MALAS saat tabel pertama kali aktif; BUKAN jalur buka).
// Pegangan = lapisan tetap di luar isi catatan (tidak ikut tersimpan), satu per kolom di tepi kanan sel baris pertama. Area sentuh 28 px,
// garis tampak tipis. Seret = ubah data-w lewat writeTableWidths (lebar kolom lain tidak bergeser); lepas jari = satu langkah Undo.
import { COL_W_COLS } from './tabel.js';
import { readTableWidths, writeTableWidths, setWidthAt, dragWidth } from './tabel-lebar.js';
export { shiftTableWidths } from './tabel-lebar.js'; // dipakai notes.js untuk tambah/hapus kolom (modul ini satu-satunya pintu malas)

export function createColResizer({ h, bounds, onStart, onCommit }) {
  const layer = h('div', { class: 'col-rs', style: 'display:none' });
  let table = null, drag = null, raf = 0;
  const handles = [];
  const hideAll = () => { for (const el of handles) el.style.display = 'none'; };
  const place = () => {
    if (!table || !table.isConnected) { hideAll(); return; }
    const row = table.rows[0];
    if (!row) { hideAll(); return; }
    const cells = [...row.cells].slice(0, COL_W_COLS), wr = (table.closest('.tbl-wrap') || table).getBoundingClientRect(), b = bounds(), rr = row.getBoundingClientRect();
    const top = Math.max(rr.top, b.top), bottom = Math.min(rr.bottom, b.bottom), show = bottom - top > 12;
    while (handles.length < cells.length) {
      const el = h('div', { class: 'col-rs-h', role: 'slider', 'data-i': String(handles.length) }); handles.push(el); layer.append(el);
    }
    handles.forEach((el, i) => {
      const c = cells[i], r = c && c.getBoundingClientRect();
      if (!show || !r || r.right < wr.left - 1 || r.right > wr.right + 1) { el.style.display = 'none'; return; }
      el.setAttribute('aria-label', 'Seret untuk mengubah lebar kolom ' + (i + 1));
      el.style.cssText = `display:block;left:${Math.round(Math.min(innerWidth - 14, r.right) - 14)}px;top:${Math.round(top)}px;height:${Math.round(bottom - top)}px`;
    });
  };
  const apply = () => {
    raf = 0;
    if (!drag || !table || !table.isConnected) return;
    writeTableWidths(table, setWidthAt(drag.list, drag.i, drag.w, drag.list.length));
    place();
  };
  layer.addEventListener('pointerdown', (e) => {
    const el = e.target && e.target.closest ? e.target.closest('.col-rs-h') : null;
    if (!el || !table || drag) return;
    e.preventDefault(); e.stopPropagation(); // tidak mencuri fokus/keyboard dari editor
    const i = Number(el.getAttribute('data-i')), cell = table.rows[0] && table.rows[0].cells[i];
    if (!cell) return;
    drag = { id: e.pointerId, i, x0: e.clientX, w0: cell.getBoundingClientRect().width, w: 0, list: readTableWidths(table), moved: false, el };
    try { el.setPointerCapture(e.pointerId); } catch (_) {}
    el.classList.add('on');
  });
  layer.addEventListener('pointermove', (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    e.preventDefault();
    const dx = e.clientX - drag.x0;
    if (!drag.moved) { if (Math.abs(dx) < 3) return; drag.moved = true; onStart(); }
    drag.w = dragWidth(drag.w0, dx);
    if (!raf) raf = requestAnimationFrame(apply);
  });
  const end = (e) => {
    if (!drag || (e && e.pointerId !== drag.id)) return;
    const d = drag; drag = null;
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    d.el.classList.remove('on'); try { d.el.releasePointerCapture(d.id); } catch (_) {}
    if (d.moved && table && table.isConnected) {
      drag = d; apply(); drag = null; // terapkan lebar terakhir sebelum disimpan
      onCommit();
    }
    place();
  };
  layer.addEventListener('pointerup', end); layer.addEventListener('pointercancel', end);
  return {
    el: layer, place,
    show(t) { table = t; layer.style.display = 'block'; place(); },
    hide() { if (drag) end(); table = null; layer.style.display = 'none'; hideAll(); },
    isDragging: () => !!drag,
  };
}
