// Pure-Node mirror of kJsBootstrap + wrapProviderSource + wrapExtractorSource.
// Lets provider/extractor contracts be tested without Flutter/QuickJS.
import fs from 'node:fs';
import nodeCrypto from 'node:crypto';

globalThis.__providers = globalThis.__providers || {};
globalThis.__extractors = globalThis.__extractors || {};

globalThis.__fetch = async function (src, u, opts) {
  opts = opts || {};
  const headers = Object.assign(
    { 'User-Agent': 'Mozilla/5.0 Chrome/120.0', Accept: '*/*' },
    opts.headers || {});
  const init = { method: opts.method || 'GET', headers, body: opts.body };
  if (opts.followRedirects === false) init.redirect = 'manual';
  const r = await fetch(u, init);
  const text = await r.text();
  const hdrs = Object.fromEntries(r.headers.entries());
  // undici hides multiple Set-Cookie from entries(); surface them explicitly.
  const sc = typeof r.headers.getSetCookie === 'function'
    ? r.headers.getSetCookie()
    : null;
  if (sc && sc.length) hdrs['set-cookie'] = sc.join(', ');
  else { const one = r.headers.get('set-cookie'); if (one) hdrs['set-cookie'] = one; }
  return {
    ok: r.ok, status: r.status, statusText: r.statusText,
    headers: hdrs, url: r.url, body: text,
    text: async () => text, json: async () => JSON.parse(text),
  };
};

globalThis.__console = function (src, level, args) {
  const parts = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    parts.push(typeof a === 'string' ? a : JSON.stringify(a));
  }
  console.log('[' + src + '/js ' + level + ']', parts.join(' '));
};

// Mirrors globalThis.htmlText in js_bootstrap.dart: strips tags, decodes the
// numeric/hex character references providers actually hit (&#8212; &#x2014;)
// and the named ones, then collapses runs of whitespace.
globalThis.htmlText = function (html) {
  if (!html) return '';
  return String(html)
    .replace(/<[^>]*>/g, '')
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(parseInt(d, 10)))
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
};

// Mirrors globalThis.absUrl in js_bootstrap.dart. A base the host regex can't
// match (protocol-relative, scheme-less) yields the href unchanged there, so it
// must not throw here either.
globalThis.absUrl = function (href, base) {
  if (!href) return '';
  if (/^https?:\/\//i.test(href)) return href;
  if (href.startsWith('//')) return 'https:' + href;
  if (!base) return href;
  if (href.startsWith('/')) {
    const m = base.match(/^(https?:\/\/[^/]+)/i);
    return m ? m[1] + href : href;
  }
  return base.replace(/\/$/, '') + '/' + href;
};

// Dean-Edwards p,a,c,k,e,d unpacker (in the packer's own base, up to 62), no
// eval. Returns input unchanged if not packed. Mirrors globalThis.unpackJs in
// js_bootstrap.dart.
globalThis.unpackJs = function (source) {
  const s = String(source);
  // Same marker checks as kJsBootstrap — see the comment there.
  const open = s.indexOf("}('");
  const close = s.indexOf(".split('|'),0,{}))");
  if (open === -1 || close <= open) return s;
  const body = s.slice(open + 3, close);
  // Same escaped-quote handling as kJsBootstrap — see the comment there.
  let end = 0;
  while (end < body.length && body.charAt(end) !== "'") {
    end += body.charAt(end) === '\\' ? 2 : 1;
  }
  if (body.charAt(end + 1) !== ',') return s;
  const payload = body.slice(0, end).replace(/\\'/g, "'");
  const tail = body.slice(end + 2);
  let radix = parseInt(tail, 10);
  if (!(radix >= 2 && radix <= 62)) radix = 62;
  const dictStart = tail.indexOf("'");
  const dictEnd = tail.lastIndexOf("'");
  if (dictStart === -1 || dictEnd <= dictStart) return s;
  const dict = tail.slice(dictStart + 1, dictEnd).split('|');
  const unbase = (t) => {
    let a = 0;
    for (const c of t) {
      const d = c <= '9' ? c.charCodeAt(0) - 48 : c >= 'a' ? c.charCodeAt(0) - 87 : c.charCodeAt(0) - 29;
      if (d >= radix) return -1;
      a = a * radix + d;
    }
    return a;
  };
  return payload.replace(/[0-9A-Za-z]+/g, (k) => {
    const i = unbase(k);
    return i >= 0 && i < dict.length && dict[i] !== '' ? dict[i] : k;
  });
};

globalThis.sha256Hex = async function (message) {
  return nodeCrypto.createHash('sha256').update(String(message)).digest('hex');
};
globalThis.aesCtrDecrypt = async function (opts) {
  const key = Buffer.from(opts.keyHex, 'hex');
  const ctr = Buffer.from(opts.counterHex, 'hex');
  const data = Buffer.from(opts.dataB64, 'base64');
  const d = nodeCrypto.createDecipheriv('aes-256-ctr', key, ctr);
  return Buffer.concat([d.update(data), d.final()]).toString('utf8');
};
globalThis.base64ToBytes = (b64) => Array.from(Buffer.from(String(b64), 'base64'));
globalThis.bytesToHex = (bytes) => Buffer.from(bytes).toString('hex');
globalThis.bytesToB64 = (bytes) => Buffer.from(bytes).toString('base64');

// Shared extractor dispatcher (mirrors the runtime helper). Parses the host
// from `embedUrl` and routes to the registered extractor.
globalThis.extractVideo = function (embedUrl, opts) {
  const m = String(embedUrl).match(/^https?:\/\/([^/]+)/i);
  const host = m ? m[1].toLowerCase().replace(/^www\./, '') : '';
  const ex = globalThis.__extractors[host];
  if (!ex) return Promise.reject('No extractor for host: ' + host);
  return Promise.resolve(ex.extract(embedUrl, opts || {}));
};

globalThis.__callProvider = function (sourceId, method, argsJson) {
  let args;
  try { args = JSON.parse(argsJson || '[]'); } catch (e) { return Promise.reject('bad args'); }
  const ns = globalThis.__providers[sourceId];
  if (!ns) return Promise.reject('not loaded: ' + sourceId);
  const fn = ns[method];
  if (typeof fn !== 'function') return Promise.reject('missing method: ' + method);
  try { return Promise.resolve(fn.apply(null, args)).then((v) => JSON.stringify(v == null ? null : v)); }
  catch (e) { return Promise.reject(String(e.message || e)); }
};

function wrapProvider(sourceId, src) {
  return `(function(){
    var __SOURCE_ID='${sourceId}';
    var fetch=function(u,o){return globalThis.__fetch(__SOURCE_ID,u,o);};
    var extractVideo=function(u,o){return globalThis.extractVideo(u,o);};
    var console={log:function(){globalThis.__console(__SOURCE_ID,'log',arguments);},
      warn:function(){globalThis.__console(__SOURCE_ID,'warn',arguments);},
      error:function(){globalThis.__console(__SOURCE_ID,'error',arguments);}};
    ${src}
    globalThis.__providers['${sourceId}']={
      getInfo:typeof getInfo==='function'?getInfo:null,
      getHome:typeof getHome==='function'?getHome:null,
      getHomePage:typeof getHomePage==='function'?getHomePage:null,
      search:typeof search==='function'?search:null,
      popular:typeof popular==='function'?popular:null,
      getDetail:typeof getDetail==='function'?getDetail:null,
      getEpisodes:typeof getEpisodes==='function'?getEpisodes:null,
      getVideoSources:typeof getVideoSources==='function'?getVideoSources:null,
      getSettings:typeof getSettings==='function'?getSettings:null
    };
  })();`;
}

function wrapExtractor(src) {
  return `(function(){
    var fetch=function(u,o){return globalThis.__fetch('extractor',u,o);};
    var console={log:function(){globalThis.__console('extractor','log',arguments);},
      warn:function(){globalThis.__console('extractor','warn',arguments);},
      error:function(){globalThis.__console('extractor','error',arguments);}};
    ${src}
    var __info=getInfo();
    var __hosts=(__info.hosts||[]).slice();
    for (var i=0;i<__hosts.length;i++){
      globalThis.__extractors[String(__hosts[i]).toLowerCase().replace(/^www\\./,'')]=
        { info:__info, extract:extract };
    }
  })();`;
}

export function loadProvider(sourceId, fileUrl) {
  const src = fs.readFileSync(fileUrl, 'utf8');
  (0, eval)(wrapProvider(sourceId, src));
}

export function loadExtractor(fileUrl) {
  const src = fs.readFileSync(fileUrl, 'utf8');
  (0, eval)(wrapExtractor(src));
}

export function callProvider(sourceId, method, args) {
  return globalThis.__callProvider(sourceId, method, JSON.stringify(args));
}
