import { test } from 'node:test';
import assert from 'node:assert/strict';
import { loadProvider, callProvider, loadExtractor } from './host.mjs';

loadProvider('example', new URL('../providers/example.js', import.meta.url));
loadExtractor(new URL('../extractors/example_embed.js', import.meta.url));

test('getInfo reports an anime provider', async () => {
  const info = JSON.parse(await callProvider('example', 'getInfo', []));
  assert.equal(info.type, 'anime');
  assert.equal(info.name, 'Example Anime');
});

test('search returns MediaItem rows', async () => {
  const rows = JSON.parse(await callProvider('example', 'search', ['one', 1, {}]));
  assert.ok(Array.isArray(rows) && rows.length > 0);
  assert.equal(rows[0].type, 'anime');
  assert.ok(rows[0].id && rows[0].url && rows[0].title);
});

test('getHome returns named sections of MediaItem rows', async () => {
  const sections = JSON.parse(await callProvider('example', 'getHome', [{}]));
  assert.ok(Array.isArray(sections) && sections.length >= 1, 'expected sections');
  assert.ok(sections[0].title && sections[0].title.length > 0, 'section has a title');
  assert.ok(Array.isArray(sections[0].items) && sections[0].items.length > 0, 'section has items');
  assert.ok(sections[0].items[0].id && sections[0].items[0].url, 'items are MediaItem-shaped');
});

test('getHome rows can opt into paging via id + getHomePage', async () => {
  const sections = JSON.parse(await callProvider('example', 'getHome', [{}]));
  assert.equal(sections[0].id, 'trending');
  const page = JSON.parse(
    await callProvider('example', 'getHomePage', ['trending', 2, {}]));
  assert.ok(Array.isArray(page) && page.length === 1);
  assert.equal(page[0].id, 'paged-1');
});

test('getDetail returns episodes', async () => {
  const detail = JSON.parse(
    await callProvider('example', 'getDetail', ['https://example.test/anime/one-piece']));
  assert.equal(detail.status, 'ongoing');
  assert.ok(detail.episodes.length >= 1);
  assert.equal(detail.episodes[0].id, 'ep-1');
});

test('getEpisodes returns the same episode list shape', async () => {
  const eps = JSON.parse(
    await callProvider('example', 'getEpisodes', ['https://example.test/anime/one-piece']));
  assert.ok(Array.isArray(eps));
  assert.equal(eps[0].number, 1);
});

test('extractVideo resolves an embed host to VideoSources', async () => {
  const sources = await globalThis.extractVideo('https://embed.test/e/1', {
    headers: { Referer: 'https://example.test/' },
  });
  assert.ok(Array.isArray(sources) && sources.length > 0);
  assert.equal(sources[0].container, 'hls');
  assert.equal(sources[0].kind, 'sub');
  assert.match(sources[0].url, /\.m3u8$/);
});

test('provider.getVideoSources flows through extractVideo end-to-end', async () => {
  const sources = JSON.parse(
    await callProvider('example', 'getVideoSources', ['https://example.test/watch/one-piece/1']));
  assert.ok(sources.length > 0);
  assert.equal(sources[0].kind, 'sub');
  assert.equal(sources[0].headers.Referer, 'https://example.test/');
  assert.ok(sources[0].subtitles.length >= 1);
});
