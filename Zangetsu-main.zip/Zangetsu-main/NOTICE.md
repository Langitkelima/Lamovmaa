Zangetsu
Copyright (C) 2026 Krishna Vishwakarma (https://github.com/Spyou)

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License version 3.0 (GPL-3.0) as published
by the Free Software Foundation. See the LICENSE file for the full text.

The vast majority of this project is original work. The notices below cover the
third-party code it incorporates, and the licenses that apply to those parts.

────────────────────────────────────────────────────────────────────────────
Third-party components
────────────────────────────────────────────────────────────────────────────

AndroidX Jetpack Compose
  https://developer.android.com/jetpack/compose
  License: Apache-2.0
  Compose UI, Material 3, and Activity integration provide runtime support for
  Android extension settings screens.

CloudStream (recloudstream)
  https://github.com/recloudstream/cloudstream
  License: GPL-3.0
  Zangetsu bundles the CloudStream `library` artifact and includes app-internal
  compatibility classes under the `com.lagradost.cloudstream3` namespace so that
  CloudStream `.cs3` extensions load and run against it. Because CloudStream is
  licensed under GPL-3.0 (copyleft), Zangetsu as a combined work is likewise
  licensed under GPL-3.0.

Aniyomi / Tachiyomi
  https://github.com/aniyomiorg/aniyomi
  https://github.com/tachiyomiorg/tachiyomi
  https://github.com/quickdesh/Animiru        (extensions-lib v17 API files)
  https://github.com/mihonapp/mihon           (Mihon manga-source runtime)
  License: Apache-2.0
  Portions of the Android extension-loading code (files under
  android/app/src/main/kotlin/com/spyou/watch_app/aniyomi/) are derived from
  Aniyomi/Tachiyomi and retain their original Apache-2.0 headers.

  The vendored extension runtime under
  android/app/src/main/kotlin/eu/kanade/tachiyomi/ is likewise derived from
  Aniyomi/Tachiyomi and Mihon. Its extensions-lib v16 baseline comes from
  itsmechinmoy/Dantotsu, and the extensions-lib v17 API files added on top of
  it are copied verbatim from quickdesh/Animiru branch animiru-new-main, path
  source-api/, pinned at commit 662e889c9cc8d4be7990f5c130767fc32f182318:
  animesource/model/{AnimeRelation, SAnimeEpisodeUpdate, SAnimeSeasonUpdate,
  ThumbnailInfo}.kt and util/JsonExtensions.kt.

  Two v17 files are not vendored (HttpServer, VideoInfo) and AnimeSource.kt
  carries deliberate deviations, so the vendored surface is v17 minus HttpServer
  rather than a verbatim v17. See the "Deviations" section of the full
  attribution for the reasoning and for a known runtime limitation that follows
  from the missing HttpServer. The full attribution, per-file provenance, and
  the commit pins for every vendored tree, are in
  docs/licenses/aniyomi-extensions-lib-NOTICE.md. The full Apache License 2.0
  text is included as LICENSE-Apache-2.0.txt.

  The Mihon manga-source runtime, which lives under that same
  eu/kanade/tachiyomi/ path, is a separate ecosystem on a separate version
  line and was not touched by this change.

Other dependencies (Flutter/Dart packages and Android libraries) are used under
their respective open-source licenses; refer to each package for details.

Liquid Glass Widgets
  https://pub.dev/packages/liquid_glass_widgets
  License: MIT
  Used for the optional phone navigation style.

KLIPY proxy (server-side Python dependencies)
  PyJWT 2.15.1 — MIT
  https://github.com/jpadilla/pyjwt
  cryptography 50.0.2 — Apache-2.0 OR BSD-3-Clause
  https://github.com/pyca/cryptography
  cffi 2.1.1 — MIT-0
  https://github.com/python-cffi/cffi
  pycparser 3.12 — BSD-3-Clause
  https://github.com/eliben/pycparser
  Pinned versions are listed in server/sync/requirements-klipy.txt.

Mozilla CA certificate bundle
  https://curl.se/docs/caextract.html
  Source: Mozilla NSS certdata, extracted by curl's mk-ca-bundle.
  License: Mozilla Public License 2.0 (https://www.mozilla.org/MPL/2.0/).
  The dated, unmodified PEM is bundled at
  android/app/src/main/res/raw/trusted_roots.pem for Android/Dart HTTPS trust.

Runtime-loaded profile teaser GIF (not bundled)
  Source: https://custom-doodle.com/wp-content/uploads/doodle/auto-draft/one-piece-dancing-roronoa-zoro-doodle.gif
  Loaded from Custom Doodle when the profile screen is shown and cached on the
  device. The GIF is not included in the repository or app package.

Runtime-loaded voice-search GIF (not bundled)
  Source: https://media.tenor.com/EjowFmPUajMAAAAj/death-note-l-lawliet.gif
  L Lawliet voice-search animation hosted by Tenor, fetched when phone voice
  search opens and cached on the device. Not included in the repository or APK.

Runtime-loaded Zoro voice-search GIF (not bundled)
  Source: https://media1.tenor.com/m/9Y5b3kVpNzsAAAAC/zoro-baron-omatsuri.gif
  Transparent redraw hosted at:
  https://avatars.zangetsu.online/voice-search/zoro-hearing-bf88c2298404.gif
  Fetched when selected for phone voice search and cached on the device.
  Not included in the repository or app package.

────────────────────────────────────────────────────────────────────────────
Keeping this file current
────────────────────────────────────────────────────────────────────────────

Any pull request that adds a new third-party dependency, incorporates code
derived from another project, or bundles another project's assets must update
this file in the same PR — see CONTRIBUTING.md. This file is treated as the
authoritative record of what's bundled and under what terms; if it's out of
date, that's considered a bug, not a formality.

────────────────────────────────────────────────────────────────────────────
Reporting a concern
────────────────────────────────────────────────────────────────────────────

If you believe this project incorporates third-party code, assets, or content
without proper attribution or in violation of its license, please open an
issue or contact Spyou directly (https://github.com/Spyou) so it can be
corrected or removed.

Lucide dock icons
  https://lucide.dev
  Six dock icons are rendered from Lucide SVGs with a 1.8 stroke.
  Licenses: ISC (Lucide) and MIT (Feather-derived icons).
  Full notices: assets/icons/lucide/LICENSE

Local Authentication (Flutter)
  https://pub.dev/packages/local_auth
  License: BSD-3-Clause
  Used for optional device-local profile unlock with biometrics.

Contains data from IntroDB (introdb.app), available under the ODbL.
