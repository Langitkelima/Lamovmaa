package com.spyou.watch_app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SoundEffectConstants
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager
import androidx.media3.exoplayer.drm.FrameworkMediaDrm
import androidx.media3.exoplayer.drm.LocalMediaDrmCallback
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.TimeBar
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import io.flutter.plugin.common.MethodChannel
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory

/**
 * Fully-native TV video player. The SAME ExoPlayer + [PlayerView] as the legacy
 * [ExoPlayerView], but hosted directly in a real Activity window (SurfaceView →
 * straight to the display, no Flutter compositing layer that can black out the
 * picture). This is the CloudStream model.
 *
 * The control overlay ([R.layout.tv_player]) is fully custom and key-driven:
 *  - OK (tap)      → play / pause
 *  - OK (hold)     → 2× fast-forward while held
 *  - ◀ / ▶         → seek ∓10 s
 *  - ▼             → focus the button row (Episodes / Audio & Subs / Next);
 *                    ◀ ▶ then move along it, OK activates, ▲ / Back leaves it
 *  - Back          → leave the row, else exit (returning the position to Flutter)
 *
 * Phase 1 features (resume, Continue-Watching) are preserved; the button-row
 * actions are wired in later phases via a native→Dart resolution bridge.
 */
@UnstableApi
class TvPlayerActivity : Activity() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_HEADERS = "headers"        // flat String[]: k,v,k,v
        const val EXTRA_TITLE = "title"
        const val EXTRA_EP_LABEL = "episodeLabel"
        const val EXTRA_POSITION = "positionMs"    // start (resume) position
        const val EXTRA_MIME = "mimeType"
        const val EXTRA_DRM_KID = "drmKid"          // clearkey key id (base64url)
        const val EXTRA_DRM_KEY = "drmKey"          // clearkey key (base64url)
        const val EXTRA_SUB_URLS = "subUrls"
        const val EXTRA_SUB_LANGS = "subLangs"
        const val EXTRA_SUB_LABELS = "subLabels"
        const val EXTRA_DECODER_MODE = "decoderMode"
        const val DECODER_MODE_HARDWARE_ONLY = 0
        const val DECODER_MODE_HARDWARE_FIRST = 1
        const val DECODER_MODE_SOFTWARE_FIRST = 2
        const val EXTRA_ACCENT = "accentColor"
        // Buffer presets from Settings, bounded to the device heap in loadControl().
        const val EXTRA_BUF_MIN_MS = "minBufferMs"
        const val EXTRA_BUF_MAX_MS = "maxBufferMs"
        const val EXTRA_BUF_BYTES = "targetBufferBytes"
        const val EXTRA_BUF_BACK_MS = "backBufferMs"
        const val EXTRA_SPEED = "defaultSpeed"
        const val EXTRA_VOLUME = "volumeBoost"
        const val EXTRA_SUB_SCALE = "subtitleScale"
        const val EXTRA_SUB_FG = "subtitleFgColor"
        const val EXTRA_SUB_BG_COLOR = "subtitleBgColor"
        const val EXTRA_SUB_EDGE = "subtitleEdge"
        const val EXTRA_SUB_EDGE_TYPE = "subtitleEdgeType"
        const val EXTRA_SUB_COLOR_HEX = "subtitleColorHex"
        const val EXTRA_SUB_OUTLINE_TYPE = "subtitleOutlineType"
        const val EXTRA_SUB_FONT_FAMILY = "subtitleFontFamily"
        const val EXTRA_SUB_POS_PREF = "subtitlePositionPref"
        const val EXTRA_SUB_BG_OPACITY = "subtitleBgOpacity"
        const val EXTRA_SUB_FONT = "subtitleFontPath"
        const val EXTRA_SUB_HAS_KEY = "subtitleApiKeySet"
        const val EXTRA_EP_LABELS = "episodeLabels"
        const val EXTRA_EP_COUNT = "episodeCount"
        const val EXTRA_START_INDEX = "startIndex"
        const val EXTRA_CATEGORY = "category"
        const val EXTRA_AVAIL_CATS = "availableCategories"
        const val EXTRA_MEGASKIP = "megaSkip"
        const val EXTRA_MEGASKIP_SECS = "megaSkipSeconds"
        const val EXTRA_SKIP_INTRO = "skipIntro"
        const val EXTRA_AUTO_SKIP_OP = "autoSkipOp"
        const val EXTRA_AUTO_SKIP_ED = "autoSkipEd"
        const val EXTRA_AUTO_SKIP_RECAP = "autoSkipRecap"
        const val EXTRA_AUTO_SKIP_FILLER = "autoSkipFiller"
        const val EXTRA_FILLER_FLAGS = "fillerFlags"
        const val ENABLE_SEEK_BUTTONS = "enableSeekButtons"
        const val SEEK_BUTTON_DURATION = "seekButtonDuration"
        // Result extras read back in MainActivity.onActivityResult.
        const val RESULT_POSITION = "positionMs"
        const val RESULT_DURATION = "durationMs"
        const val RESULT_EP_INDEX = "episodeIndex"
        const val RESULT_PLAYBACK_ERROR = "playbackError"
        private const val TAG = "TvPlayer"
        private const val SEEK_MS = 10_000L
        private const val AUTO_HIDE_MS = 4_000L
        private const val HOLD_MS = 500L
        private const val DEFAULT_ACCENT = 0xFFFF4D5E.toInt()
        private const val UNFOCUSED_PILL = 0x59101014 // subtle dark glass (premium)
        /** CloudStream-style chunk size — matches Dart [kEpisodeRangeChunk]. */
        private const val EPISODE_RANGE_CHUNK = 50
        private const val RANGE_CHIP_SURFACE = 0xFF2A2A32.toInt()

        /** Foreground native player, so Dart can push late filler info. */
        @JvmStatic
        @Volatile
        var active: TvPlayerActivity? = null
    }

    // Aspect Ratio Stuffs
    private val aspectRatios = listOf(
        Triple("Fit", R.drawable.ic_aspect_ratio_fit, AspectRatioFrameLayout.RESIZE_MODE_FIT),
        Triple("Fill", R.drawable.ic_aspect_ratio_fill, AspectRatioFrameLayout.RESIZE_MODE_FILL),
        Triple("Zoom", R.drawable.ic_aspect_ratio_zoom, AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    )
    private var currentAspectRatio = 0
    private var lastVideoRatio: Float? = null

    private var player: ExoPlayer? = null
    private var reported = false
    private var accent = DEFAULT_ACCENT

    private var currentIndex = 0
    private var episodeCount = 1
    private var episodeLabels: Array<String> = emptyArray()
    private var category = "sub"
    private var availableCategories: List<String> = emptyList()
    private var episodeSources: List<Map<String, Any?>> = emptyList() // mirrors for the Server picker
    private var currentUrl: String? = null
    // Cached loadStream args so an online-searched subtitle can be added by
    // reloading the SAME stream at the current position (reuses loadStream, the
    // proven episode-switch path). Only the new search feature reads these.
    private var currentHeaders: Map<String, String>? = null
    private var currentMime: String? = null
    private var currentDrmKid: String? = null
    private var currentDrmKey: String? = null
    private val currentSubs = mutableListOf<MediaItem.SubtitleConfiguration>()
    private var subtitleApiKeySet = false
    private var seekButtonsEnabled = true
    private var seekButtonDurationMs = 10_000L
    private var switching = false // guards against overlapping episode switches

    private data class Skip(val start: Long, val end: Long, val type: String)
    private var skipIntervals: List<Skip> = emptyList()
    private var skipsFetchedFor = -1 // episode index skips were fetched for
    private var timingReportedFor = -1 // episode index Dart was told duration for
    private var userPaused = false // true only after an explicit pause press
    private var activeSkipEnd = -1L  // end of the interval currently offered

    private lateinit var root: View
    private lateinit var playerView: PlayerView
    private lateinit var loading: View
    private lateinit var controls: View
    private lateinit var timeBar: DefaultTimeBar
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var centerIcon: ImageView
    private lateinit var seekIndicator: TextView
    private lateinit var speedBadge: TextView
    private lateinit var skipButton: TextView
    private lateinit var buttonRow: View
    private lateinit var btnEpisodes: TextView
    private lateinit var btnQuality: TextView
    private lateinit var btnSources: TextView
    private lateinit var btnAudioSubs: TextView
    private lateinit var btnNext: TextView
    private lateinit var btnAspectRatio: TextView
    private lateinit var btnMegaskip: TextView
    private lateinit var btnSpeed: TextView
    // ±N s seek pills on the bottom row (Settings toggle + duration).
    private lateinit var btnSeekBackward: TextView
    private lateinit var btnSeekForward: TextView
    // MegaSkip jump size in seconds (read from the launch extras).
    private var megaSkipSecs = 85
    // Whether the AniSkip "Skip intro/ending" pill may show (Settings toggle).
    private var skipIntroEnabled = true
    // Jump past the OP/ED without a press (Settings toggles, both off by default).
    private var autoSkipOp = false
    private var autoSkipEd = false
    private var autoSkipRecap = false
    // Auto-skip filler episodes on binge advance (Settings toggle).
    private var autoSkipFiller = false
    // Per-index filler flags from Jikan (via Dart). Empty until launch / update.
    private var fillerFlags: BooleanArray = BooleanArray(0)
    // Interval starts already auto-skipped for the current episode, so seeking
    // back into an opening you meant to watch doesn't bounce you out again.
    private val autoSkipped = HashSet<Long>()
    // Live subtitle size multiplier (seeded from prefs; changeable in-player).
    private var subScale = 1f
    private var subFg = android.graphics.Color.WHITE
    private var subBgColor = android.graphics.Color.TRANSPARENT
    private var subEdgeType = CaptionStyleCompat.EDGE_TYPE_OUTLINE
    private var subFontPath: String? = null
    private var subTypeface = android.graphics.Typeface.DEFAULT
    private var subFontFamily = ""
    private var subBgOpacity = 0f
    private var subOutlineId = "outline"
    private var subColorHex = "#FFFFFFFF"
    private var subPositionPref = 95
    private lateinit var fillerBadge: TextView

    private lateinit var menuPanel: View
    private lateinit var menuContent: android.widget.LinearLayout

    /** Drill-in pages for the Audio & Subs Settings panel. */
    private enum class AvPage {
        ROOT, AUDIO, SUBS, CAPTION_STYLE, SIZE, COLOR, EDGE, BG, FONT, POS, VOLUME
    }
    private val avStack = ArrayDeque<AvPage>()
    private var avMenuActive = false
    /**
     * Optimistic subtitle selection for the Settings UI. ExoPlayer's
     * [Tracks.Group.isTrackSelected] often lags one interaction behind when we
     * rebuild the menu, so the checkmark would land on the *previous* pick.
     * [textUiForcedOff] = Off; [textUiLabel] non-null = that track; both clear → trust Exo.
     */
    private var textUiForcedOff = false
    private var textUiLabel: String? = null

    private var controlsVisible = false
    private var focusZone = 0 // 0 = none (OK=play/pause, ◀▶=seek), 1 = top actions, 2 = bottom
    private val rowFocused get() = focusZone != 0
    /** True while the user is dragging the time bar — blocks auto-hide + progress fight. */
    private var scrubbing = false
    private var speedEngaged = false
    private var menuOpen = false
    private var episodeRangeIndex = 0 // 50-ep chunk in the Episodes panel
    private var menuOpener: View? = null // the row button that opened the panel
    // Land focus on the option the user last picked (else the current selection,
    // else the first row) when a menu (re)opens — not always the first row.
    private var firstSelectedRow: View? = null
    private var focusTarget: View? = null
    private var lastFocusLabel: String? = null
    private var speed = 1f
    private var volumePercent = 100
    private var loudness: android.media.audiofx.LoudnessEnhancer? = null
    // While seeking, the accumulating target position (−1 = not seeking). Lets a
    // burst of ◀▶ presses add up (and the bar/preview jump instantly) instead of
    // each press re-reading the not-yet-updated player position.
    private var seekTarget = -1L

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { hideControls() }
    private val engage2x = Runnable { engageSpeed() }
    private val hideSeekIndicator = Runnable { seekIndicator.visibility = View.GONE }
    // Commit the accumulated seek once the user stops pressing (debounced), so a
    // fast burst becomes one seek instead of a storm.
    private val commitSeek = Runnable {
        val t = seekTarget
        seekTarget = -1L
        if (t >= 0) {
            player?.seekTo(t)
            reportTiming(positionMs = t)
        }
    }
    private var lastTrackingAt = 0L
    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            updateSkip()
            // Slow heartbeat: keeps the live tracker's progress moving during
            // continuous playback (event reports alone only cover the start).
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastTrackingAt >= 10_000L) {
                lastTrackingAt = now
                val p = player
                if (p != null && p.isPlaying && p.duration > 0) {
                    MainActivity.tvBridge?.invokeMethod(
                        "trackingTick",
                        mapOf(
                            "index" to currentIndex,
                            "positionMs" to p.currentPosition.coerceAtLeast(0L),
                            "durationMs" to p.duration,
                            "playing" to true,
                        ),
                    )
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        goImmersive()

        val url = intent.getStringExtra(EXTRA_URL)
        if (url.isNullOrEmpty()) { finish(); return }
        accent = intent.getIntExtra(EXTRA_ACCENT, DEFAULT_ACCENT)
        episodeCount = intent.getIntExtra(EXTRA_EP_COUNT, 1)
        currentIndex = intent.getIntExtra(EXTRA_START_INDEX, 0)
        episodeLabels = intent.getStringArrayExtra(EXTRA_EP_LABELS) ?: emptyArray()
        category = intent.getStringExtra(EXTRA_CATEGORY) ?: "sub"
        availableCategories = intent.getStringArrayExtra(EXTRA_AVAIL_CATS)?.toList() ?: emptyList()
        skipIntroEnabled = intent.getBooleanExtra(EXTRA_SKIP_INTRO, true)
        autoSkipOp = intent.getBooleanExtra(EXTRA_AUTO_SKIP_OP, false)
        autoSkipEd = intent.getBooleanExtra(EXTRA_AUTO_SKIP_ED, false)
        autoSkipRecap = intent.getBooleanExtra(EXTRA_AUTO_SKIP_RECAP, false)
        autoSkipFiller = intent.getBooleanExtra(EXTRA_AUTO_SKIP_FILLER, false)
        fillerFlags = intent.getBooleanArrayExtra(EXTRA_FILLER_FLAGS) ?: BooleanArray(0)
        seekButtonsEnabled = intent.getBooleanExtra(ENABLE_SEEK_BUTTONS, true)
        seekButtonDurationMs = intent.getLongExtra(SEEK_BUTTON_DURATION, 10L) * 1000L
            .coerceAtLeast(1_000L)
        subScale = intent.getFloatExtra(EXTRA_SUB_SCALE, 1f)
        subFg = intent.getIntExtra(EXTRA_SUB_FG, android.graphics.Color.WHITE)
        subBgColor = intent.getIntExtra(EXTRA_SUB_BG_COLOR, android.graphics.Color.TRANSPARENT)
        subEdgeType = intent.getIntExtra(
            EXTRA_SUB_EDGE_TYPE,
            if (intent.getBooleanExtra(EXTRA_SUB_EDGE, true)) {
                CaptionStyleCompat.EDGE_TYPE_OUTLINE
            } else {
                CaptionStyleCompat.EDGE_TYPE_NONE
            },
        )
        subOutlineId = intent.getStringExtra(EXTRA_SUB_OUTLINE_TYPE) ?: when (subEdgeType) {
            CaptionStyleCompat.EDGE_TYPE_NONE -> "none"
            CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW -> "shadow"
            CaptionStyleCompat.EDGE_TYPE_RAISED -> "raised"
            CaptionStyleCompat.EDGE_TYPE_DEPRESSED -> "depressed"
            else -> "outline"
        }
        subPositionPref = intent.getIntExtra(EXTRA_SUB_POS_PREF, 95).coerceIn(0, 100)
        subBgOpacity = intent.getFloatExtra(EXTRA_SUB_BG_OPACITY, ((subBgColor ushr 24) and 0xFF) / 255f)
        subColorHex = intent.getStringExtra(EXTRA_SUB_COLOR_HEX) ?: "#FFFFFFFF"
        subFontPath = intent.getStringExtra(EXTRA_SUB_FONT)
        subFontFamily = intent.getStringExtra(EXTRA_SUB_FONT_FAMILY) ?: ""
        subtitleApiKeySet = intent.getBooleanExtra(EXTRA_SUB_HAS_KEY, false)

        setContentView(R.layout.tv_player)
        bindViews()
        styleControls()
        active = this
        // Android 13+ (the tester's Bravia) routes Back through the predictive-back
        // dispatcher — the app opts in app-wide via enableOnBackInvokedCallback=true
        // — which finishes this Activity WITHOUT ever calling dispatchKeyEvent or
        // onBackPressed. Register a callback so Back runs our own hierarchy
        // (close menu → hide controls → exit) instead of blindly exiting.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                android.window.OnBackInvokedCallback { handleBack() },
            )
        }
        updateEpisodeUi()

        playerView.useController = false
        // keepScreenOn is managed by syncKeepScreenOn() — on while playing or
        // buffering, released on pause — not pinned on for the whole session.

        val exo = ExoPlayer.Builder(this, renderersFactory())
            .setLoadControl(loadControl())
            .build()
        player = exo
        playerView.player = exo

        // Apply saved defaults: playback speed, volume boost, subtitle style.
        speed = intent.getFloatExtra(EXTRA_SPEED, 1f)
        exo.playbackParameters = PlaybackParameters(speed)
        applyVolume(intent.getIntExtra(EXTRA_VOLUME, 100))
        applySubtitleStyleLive()

        exo.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                lastVideoRatio = (videoSize.width * videoSize.pixelWidthHeightRatio) / videoSize.height
                updateAspectRatioButtonVisibility()
            }

            override fun onRenderedFirstFrame() {
                Log.i(TAG, "onRenderedFirstFrame — native surface is showing video")
            }
            override fun onPlayerError(error: PlaybackException) {
                Log.e(TAG, "onPlayerError: ${error.errorCodeName} — ${error.message}", error)
                android.widget.Toast.makeText(
                    this@TvPlayerActivity,
                    "Playback error: ${error.errorCodeName}",
                    android.widget.Toast.LENGTH_LONG,
                ).show()
                try {
                    MainActivity.tvBridge?.invokeMethod(
                        "playbackError",
                        mapOf(
                            "errorCode" to (error.errorCodeName ?: ""),
                            "message" to (error.message ?: ""),
                            "index" to currentIndex,
                        ),
                    )
                } catch (_: Exception) {}
                // The stream is dead — stop the frozen player and hand the
                // result back so Dart can offer Try Next Source / Select Source.
                if (!switching) {
                    reportAndFinish(true)
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                syncKeepScreenOn()
                updatePlayPauseIcon()
                // Keep the controls (and the pause glyph) on screen while paused so
                // it's obvious playback is stopped; resume re-arms the auto-hide.
                if (isPlaying) bumpControls() else { showControls(); cancelAutoHide() }
            }
            override fun onPlaybackStateChanged(state: Int) {
                syncKeepScreenOn()
                updatePlayPauseIcon()
                if (!switching) {
                    loading.visibility =
                        if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                }
                // Duration is known once ready → fetch AniSkip for this episode.
                if (state == Player.STATE_READY && skipsFetchedFor != currentIndex) fetchSkips()
                if (state == Player.STATE_READY) reportTimingIfNeeded()
                // Autoplay the next episode when this one finishes. Honour
                // auto-skip filler the same way the Flutter player does.
                if (state == Player.STATE_ENDED && !switching && currentIndex < episodeCount - 1) {
                    loadEpisode(nextAutoplayIndex())
                }
            }
            // PlayerView also writes cues; we register after it so this wins and
            // can force vertical position (embedded cue lines ignore bottom pad).
            override fun onCues(cueGroup: CueGroup) {
                playerView.subtitleView?.setCues(repositionCues(cueGroup.cues))
            }
        })

        playerView.addOnLayoutChangeListener { _, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom ->
            if (right - left != oldRight - oldLeft || bottom - top != oldBottom - oldTop) {
                updateAspectRatioButtonVisibility()
                player?.currentCues?.let { playerView.subtitleView?.setCues(repositionCues(it.cues)) }
            }
        }

        // First episode: stream data comes straight from the intent (Dart resolved
        // it before launching). Later switches come from the bridge.
        loadStream(
            url,
            headersFromIntent(),
            subtitleConfigs(),
            intent.getStringExtra(EXTRA_MIME),
            intent.getLongExtra(EXTRA_POSITION, 0L),
            intent.getStringExtra(EXTRA_DRM_KID),
            intent.getStringExtra(EXTRA_DRM_KEY),
        )
        fetchSources() // populate the Server picker for the current episode

        handler.post(ticker)
        bumpControls()
    }

    /** Loads a resolved stream into the current player and starts it. Reused for
     *  the first episode and every switch. */
    private fun loadStream(
        url: String,
        headers: Map<String, String>?,
        subs: List<MediaItem.SubtitleConfiguration>?,
        mime: String?,
        positionMs: Long,
        drmKid: String? = null,
        drmKey: String? = null,
    ) {
        val p = player ?: return
        userPaused = false
        clearTextUiOverride() // new stream → trust Exo again
        currentUrl = url
        currentHeaders = headers
        currentMime = mime
        currentDrmKid = drmKid
        currentDrmKey = drmKey
        currentSubs.clear()
        if (subs != null) currentSubs.addAll(subs)
        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
        if (!headers.isNullOrEmpty()) httpFactory.setDefaultRequestProperties(headers)
        val builder = MediaItem.Builder().setUri(url)
        if (!mime.isNullOrEmpty()) builder.setMimeType(mime)
        if (subs != null) builder.setSubtitleConfigurations(subs)
        seekTarget = -1L
        // DefaultDataSource picks the reader off the URI scheme: file paths and
        // content:// (downloads, incl. a custom SAF folder) go to the local
        // readers, everything else falls through to httpFactory — so streaming
        // keeps the same headers and redirect handling it always had.
        val sourceFactory =
            DefaultMediaSourceFactory(DefaultDataSource.Factory(this, httpFactory))
        // ClearKey DRM (CENC/DASH — CNC/PlayzTV live channels). Non-DRM streams
        // pass null keys → this block is skipped and playback is unchanged.
        if (!drmKid.isNullOrEmpty() && !drmKey.isNullOrEmpty()) {
            val json =
                "{\"keys\":[{\"kty\":\"oct\",\"k\":\"$drmKey\",\"kid\":\"$drmKid\"}]," +
                        "\"type\":\"temporary\"}"
            val drmManager = DefaultDrmSessionManager.Builder()
                .setUuidAndExoMediaDrmProvider(C.CLEARKEY_UUID, FrameworkMediaDrm.DEFAULT_PROVIDER)
                .setMultiSession(false)
                .build(LocalMediaDrmCallback(json.toByteArray(Charsets.UTF_8)))
            sourceFactory.setDrmSessionManagerProvider { drmManager }
        }
        p.setMediaSource(sourceFactory.createMediaSource(builder.build()))
        if (positionMs > 0) p.seekTo(positionMs)
        p.prepare()
        p.playWhenReady = true
    }

    // ── Episode switching (via the native→Dart bridge) ───────────────────────
    private fun loadEpisode(index: Int) {
        if (index < 0 || index >= episodeCount || switching) return
        val bridge = MainActivity.tvBridge ?: return
        // Persist the outgoing episode before leaving it.
        val p = player
        if (p != null && p.duration > 0) {
            bridge.invokeMethod(
                "saveProgress",
                mapOf(
                    "index" to currentIndex,
                    "positionMs" to p.currentPosition,
                    "durationMs" to p.duration,
                ),
            )
        }
        p?.pause() // don't keep the old episode running under the spinner
        switching = true
        loading.visibility = View.VISIBLE
        bridge.invokeMethod(
            "resolveEpisode",
            mapOf("index" to index, "category" to category),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    @Suppress("UNCHECKED_CAST")
                    val m = result as? Map<String, Any?>
                    if (m == null) { switching = false; loading.visibility = View.GONE; toastFail() }
                    else applyResolved(index, m)
                }
                override fun error(code: String, msg: String?, details: Any?) {
                    switching = false; loading.visibility = View.GONE; toastFail()
                }
                override fun notImplemented() {
                    switching = false; loading.visibility = View.GONE; toastFail()
                }
            },
        )
    }

    private fun updateAspectRatioButtonVisibility() {
        val videoRatio = lastVideoRatio ?: run {
            btnAspectRatio.isVisible = false // no video size known yet
            return
        }

        val containerWidth = playerView.width
        val containerHeight = playerView.height
        if (containerWidth == 0 || containerHeight == 0) return // not laid out yet

        val containerRatio = containerWidth.toFloat() / containerHeight
        val ratiosMatch = kotlin.math.abs(videoRatio - containerRatio) < 0.01f

        btnAspectRatio.isVisible = !ratiosMatch
    }

    private fun changeAspectRatio() {
        currentAspectRatio = (++currentAspectRatio) % aspectRatios.size

        val currentValue = aspectRatios[currentAspectRatio]
        playerView.resizeMode = currentValue.third
        btnAspectRatio.text = currentValue.first
        val drawable = ContextCompat.getDrawable(this, currentValue.second)
        btnAspectRatio.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null, null)
    }

    private fun applyResolved(index: Int, m: Map<String, Any?>) {
        val url = m["url"] as? String
        if (url.isNullOrEmpty()) { switching = false; loading.visibility = View.GONE; toastFail(); return }
        @Suppress("UNCHECKED_CAST")
        val headers = m["headers"] as? Map<String, String>
        val mime = m["mimeType"] as? String
        val positionMs = (m["positionMs"] as? Number)?.toLong() ?: 0L
        currentIndex = index
        skipIntervals = emptyList()
        skipsFetchedFor = -1
        timingReportedFor = -1
        autoSkipped.clear() // new episode → its OP/ED may auto-skip again
        hideSkip()
        loadStream(
            url, headers, subsFromMap(m["subtitles"]), mime, positionMs,
            m["drmKid"] as? String, m["drmKey"] as? String,
        )
        updateEpisodeUi()
        fetchSources() // refresh the Server picker for the new episode/category
        bumpControls()
        switching = false // new media's buffering now drives the spinner
        // Refresh Audio/Subs checkmarks for the newly loaded cut.
        if (avMenuActive) rebuildAvMenuDeferred()
    }

    private fun subsFromMap(raw: Any?): List<MediaItem.SubtitleConfiguration>? {
        @Suppress("UNCHECKED_CAST")
        val list = raw as? List<Map<String, Any?>> ?: return null
        if (list.isEmpty()) return null
        return list.mapNotNull { s ->
            val u = s["url"] as? String ?: return@mapNotNull null
            MediaItem.SubtitleConfiguration.Builder(android.net.Uri.parse(u))
                .setMimeType(if (u.lowercase().contains(".srt")) MimeTypes.APPLICATION_SUBRIP else MimeTypes.TEXT_VTT)
                .setLanguage(s["lang"] as? String)
                .setLabel(s["label"] as? String)
                .build()
        }
    }

    private fun updateEpisodeUi() {
        val label = episodeLabels.getOrNull(currentIndex) ?: ""
        findViewById<TextView>(R.id.episode_label).apply {
            text = label
            visibility = if (label.isBlank()) View.GONE else View.VISIBLE
        }
        val isFiller = currentIndex < fillerFlags.size && fillerFlags[currentIndex]
        fillerBadge.visibility = if (isFiller) View.VISIBLE else View.GONE
        val hasNext = currentIndex < episodeCount - 1
        btnNext.isEnabled = hasNext
        btnNext.isFocusable = hasNext
        btnNext.alpha = if (hasNext) 1f else 0.35f
    }

    /** Late filler info from Dart (Jikan fetch finished after launch). */
    fun applyFillerInfo(flags: BooleanArray?, autoSkip: Boolean?) {
        runOnUiThread {
            if (flags != null) fillerFlags = flags
            if (autoSkip != null) autoSkipFiller = autoSkip
            updateEpisodeUi()
        }
    }

    /**
     * Next index when advancing (autoplay or Next button). When
     * [autoSkipFiller] is on, jumps past consecutive fillers — but never
     * strands the user (if everything left is filler, returns immediate next).
     * Mirrors Dart [nextAutoplayIndex].
     */
    private fun nextAutoplayIndex(): Int {
        val immediate = currentIndex + 1
        if (immediate >= episodeCount) return immediate
        if (!autoSkipFiller || fillerFlags.isEmpty()) return immediate
        var target = immediate
        while (target < episodeCount &&
            target < fillerFlags.size &&
            fillerFlags[target]
        ) {
            target++
        }
        if (target >= episodeCount) return immediate
        return target
    }

    /** Push position+duration to Dart (Discord bar + resume). */
    private fun reportTiming(
        positionMs: Long? = null,
        playing: Boolean? = null,
        onlyOncePerEpisode: Boolean = false,
    ) {
        val p = player ?: return
        if (p.duration <= 0) return
        if (onlyOncePerEpisode && timingReportedFor == currentIndex) return
        timingReportedFor = currentIndex
        MainActivity.tvBridge?.invokeMethod(
            "saveProgress",
            mapOf(
                "index" to currentIndex,
                "positionMs" to (positionMs ?: p.currentPosition).coerceAtLeast(0L),
                "durationMs" to p.duration,
                "playing" to (playing ?: !userPaused),
            ),
        )
    }

    /** First time this episode is ready — Discord needs an end timestamp. */
    private fun reportTimingIfNeeded() = reportTiming(onlyOncePerEpisode = true)

    private fun toastFail() = android.widget.Toast.makeText(
        this, "Couldn't load that episode", android.widget.Toast.LENGTH_SHORT,
    ).show()

    /** Cache the current episode's mirror list for the Server picker. */
    private fun fetchSources(onReady: (() -> Unit)? = null) {
        val bridge = MainActivity.tvBridge ?: run { onReady?.invoke(); return }
        bridge.invokeMethod(
            "sourcesFor",
            mapOf("index" to currentIndex, "category" to category),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    @Suppress("UNCHECKED_CAST")
                    episodeSources = (result as? List<Map<String, Any?>>) ?: emptyList()
                    onReady?.invoke()
                }
                override fun error(code: String, msg: String?, details: Any?) { onReady?.invoke() }
                override fun notImplemented() { onReady?.invoke() }
            },
        )
    }

    /** Fetch skip intervals for the current episode. */
    private fun fetchSkips() {
        val bridge = MainActivity.tvBridge ?: return
        val p = player ?: return
        val index = currentIndex
        skipsFetchedFor = index
        bridge.invokeMethod(
            "skipsFor",
            mapOf("index" to index, "durationMs" to p.duration.coerceAtLeast(0)),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    if (currentIndex != index || player !== p) return
                    @Suppress("UNCHECKED_CAST")
                    val list = result as? List<Map<String, Any?>> ?: emptyList()
                    skipIntervals = list.mapNotNull {
                        val s = (it["start"] as? Number)?.toLong() ?: return@mapNotNull null
                        val e = (it["end"] as? Number)?.toLong() ?: return@mapNotNull null
                        Skip(s, e, (it["type"] as? String) ?: "op")
                    }
                }
                override fun error(code: String, msg: String?, details: Any?) {}
                override fun notImplemented() {}
            },
        )
    }

    /** Show/hide the Skip pill based on the current position (called each tick). */
    /**
     * Jump past the opening / ending without a press, when the user opted in.
     * Returns true when a skip fired, so the caller stops before flashing the
     * pill for the interval we just left.
     */
    private fun maybeAutoSkip(p: ExoPlayer): Boolean {
        if (skipIntervals.isEmpty() || switching) return false
        if (!autoSkipOp && !autoSkipEd && !autoSkipRecap) return false
        val pos = p.currentPosition
        val iv = skipIntervals.firstOrNull {
            // "recap" is checked first: it doesn't end in "ed", so without its
            // own branch it would ride on the opening toggle.
            val on = when {
                it.type == "recap" -> autoSkipRecap
                it.type.endsWith("ed") -> autoSkipEd
                else -> autoSkipOp
            }
            // Leave the last second alone — skipping there saves nothing.
            on && it.start !in autoSkipped && pos >= it.start && pos < it.end - 1000L
        } ?: return false
        autoSkipped.add(iv.start)
        hideSkip()
        p.seekTo(iv.end)
        reportTiming(positionMs = iv.end)
        return true
    }

    private fun updateSkip() {
        val p = player ?: return
        // Auto-skip is its own feature — it runs even with the pill toggled off.
        if (maybeAutoSkip(p)) return
        // Respect the Settings "Skip intro button" toggle.
        if (!skipIntroEnabled) {
            if (skipButton.visibility == View.VISIBLE) hideSkip()
            return
        }
        if (menuOpen || switching) {
            if (skipButton.visibility == View.VISIBLE) skipButton.visibility = View.GONE
            return
        }
        val pos = p.currentPosition
        val iv = skipIntervals.firstOrNull { pos >= it.start && pos < it.end }
        if (iv == null) {
            if (skipButton.visibility == View.VISIBLE) hideSkip()
            return
        }
        activeSkipEnd = iv.end
        skipButton.text = when {
            iv.type == "recap" -> "Skip Recap"
            iv.type.endsWith("ed") -> "Skip Ending"
            else -> "Skip Intro"
        }
        if (skipButton.visibility != View.VISIBLE) {
            skipButton.visibility = View.VISIBLE
            // Auto-focus once so OK skips immediately. The D-pad can then move off it
            // and back — ▼ from the video reaches it, ▲ from the button row too.
            if (!rowFocused && !menuOpen) skipButton.requestFocus()
        }
    }

    private fun hideSkip() {
        val wasFocused = skipButton.isFocused
        skipButton.visibility = View.GONE
        activeSkipEnd = -1L
        if (wasFocused) root.requestFocus()
    }

    private fun isTorrentUrl(url: String): Boolean {
        val u = url.lowercase()
        return u.startsWith("magnet:") || u.endsWith(".torrent") || u.contains(".torrent?")
    }

    /** Switch to a different mirror for the current episode, keeping position. A
     *  magnet/.torrent is streamed via Dart (TorrentService → local URL) first. */
    private fun loadSource(i: Int) {
        val s = episodeSources.getOrNull(i) ?: return
        val url = s["url"] as? String ?: return
        @Suppress("UNCHECKED_CAST")
        val headers = s["headers"] as? Map<String, String>
        val subs = subsFromMap(s["subtitles"])
        val mime = s["mimeType"] as? String
        val pos = player?.currentPosition ?: 0L
        val kid = s["drmKid"] as? String
        val key = s["drmKey"] as? String
        if (!isTorrentUrl(url)) { loadStream(url, headers, subs, mime, pos, kid, key); return }
        loading.visibility = View.VISIBLE
        MainActivity.tvBridge?.invokeMethod(
            "resolveTorrent",
            mapOf("url" to url),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    val local = result as? String
                    if (local == null) { loading.visibility = View.GONE; toastFail() }
                    else loadStream(local, headers, subs, mime, pos)
                }
                override fun error(code: String, msg: String?, details: Any?) {
                    loading.visibility = View.GONE; toastFail()
                }
                override fun notImplemented() {
                    loading.visibility = View.GONE; toastFail()
                }
            },
        )
    }

    /** Sub ⇄ Dub: re-resolve the current episode in the other category. */
    private fun switchCategory(cat: String) {
        if (cat == category || switching) return
        val bridge = MainActivity.tvBridge ?: return
        val p = player
        if (p != null && p.duration > 0) {
            bridge.invokeMethod(
                "saveProgress",
                mapOf("index" to currentIndex, "positionMs" to p.currentPosition, "durationMs" to p.duration),
            )
        }
        p?.pause()
        switching = true
        loading.visibility = View.VISIBLE
        category = cat
        // Optimistic checkmark — menu used to stay on the previous pick until
        // a full rebuild happened for another reason (looked like Sub never
        // selected / Dub kept the tick).
        lastFocusLabel = if (cat == "dub") "Dub" else "Sub"
        if (avMenuActive) rebuildAvMenuDeferred()
        // Persist cut, then resolve. Chaining avoids racing setCategory's
        // episode-list refresh against resolveEpisode (opaque Sub/Dub urls).
        bridge.invokeMethod(
            "setCategory",
            mapOf("category" to cat),
            object : MethodChannel.Result {
                override fun success(result: Any?) = resolveAfterCategory(cat)
                override fun error(code: String, msg: String?, details: Any?) =
                    resolveAfterCategory(cat)
                override fun notImplemented() = resolveAfterCategory(cat)
            },
        )
    }

    private fun resolveAfterCategory(cat: String) {
        val bridge = MainActivity.tvBridge ?: run {
            switching = false
            loading.visibility = View.GONE
            toastFail()
            return
        }
        bridge.invokeMethod(
            "resolveEpisode",
            mapOf("index" to currentIndex, "category" to cat),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    @Suppress("UNCHECKED_CAST")
                    val m = result as? Map<String, Any?>
                    if (m == null) { switching = false; loading.visibility = View.GONE; toastFail() }
                    else applyResolved(currentIndex, m)
                }
                override fun error(code: String, msg: String?, details: Any?) {
                    switching = false; loading.visibility = View.GONE; toastFail()
                }
                override fun notImplemented() {
                    switching = false; loading.visibility = View.GONE; toastFail()
                }
            },
        )
    }

    // ── Options menu (Quality / Audio / Subtitles / Speed / Volume) ───────────
    private fun resetMenuPanelLayout() {
        val scroll = menuPanel as? LockedScrollView ?: return
        scroll.scrollLocked = false
        scroll.isFillViewport = false
        menuContent.layoutParams = menuContent.layoutParams.apply {
            height = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        }
    }

    /** Header + range rail stay fixed; only the inner episode list scrolls. */
    private fun prepareEpisodesPanelLayout() {
        val scroll = menuPanel as? LockedScrollView ?: return
        scroll.scrollLocked = true
        scroll.isFillViewport = true
        scroll.scrollTo(0, 0)
        menuContent.layoutParams = menuContent.layoutParams.apply {
            height = android.view.ViewGroup.LayoutParams.MATCH_PARENT
        }
    }

    private fun episodeListScroll(): android.widget.ScrollView =
        android.widget.ScrollView(this).apply {
            tag = "episode-list-scroll"
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f,
            )
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }

    private fun showPanel() {
        // Hide the transport controls so the panel reads cleanly over the video.
        controls.visibility = View.GONE
        controlsVisible = false
        cancelAutoHide()
        menuPanel.visibility = View.VISIBLE
        menuPanel.scrollTo(0, 0)
        menuPanel.alpha = 0f
        menuPanel.animate().alpha(1f).setDuration(150).start()
        menuOpen = true
    }

    /** Builds the menu content and shows the panel, landing focus on the last
     *  chosen / currently-selected option instead of always the first row. */
    private fun showMenu(opener: View, build: () -> Unit) {
        menuOpener = opener
        firstSelectedRow = null
        focusTarget = null
        // Quality / Sources / Episodes are flat menus — not the AV stack.
        if (opener !== btnAudioSubs) {
            avMenuActive = false
            avStack.clear()
        }
        resetMenuPanelLayout()
        menuContent.removeAllViews()
        build()
        showPanel()
        menuContent.post {
            (focusTarget ?: firstSelectedRow ?: firstFocusable(menuContent))?.requestFocus()
        }
    }

    /** Quality — HLS variants or the distinct per-source resolutions. */
    private fun openQualityMenu() = showMenu(btnQuality) { buildQualityMenu() }

    /** Sources — the full resolved stream/mirror list. */
    private fun openSourcesMenu() = fetchSources {
        if (!isFinishing && !isDestroyed) showMenu(btnSources) { buildSourcesMenu() }
    }

    /** The "Episodes" list — jump to any episode via the same bridge switch. */
    private fun openEpisodes() {
        menuOpener = btnEpisodes
        firstSelectedRow = null
        focusTarget = null
        avMenuActive = false
        avStack.clear()
        episodeRangeIndex = if (episodeCount > 0) currentIndex / EPISODE_RANGE_CHUNK else 0
        buildEpisodesPanel()
        showPanel()
        menuContent.post { focusEpisodeMenuTarget() }
    }

    private fun episodeRangeCount(): Int =
        if (episodeCount <= 0) 0
        else (episodeCount + EPISODE_RANGE_CHUNK - 1) / EPISODE_RANGE_CHUNK

    private fun episodeDisplayNumber(index: Int): Int {
        val label = episodeLabels.getOrNull(index) ?: return index + 1
        val m = Regex("""Episode\s+(\d+)""", RegexOption.IGNORE_CASE).find(label)
        return m?.groupValues?.get(1)?.toIntOrNull() ?: (index + 1)
    }

    private fun episodeRangeLabel(rangeIndex: Int): String {
        if (episodeCount == 0) return ""
        val startIdx = (rangeIndex * EPISODE_RANGE_CHUNK).coerceIn(0, episodeCount - 1)
        val endIdx = ((rangeIndex + 1) * EPISODE_RANGE_CHUNK - 1).coerceIn(0, episodeCount - 1)
        return "${episodeDisplayNumber(startIdx)}–${episodeDisplayNumber(endIdx)}"
    }

    private fun buildEpisodesPanel() {
        menuContent.removeAllViews()
        resetMenuPanelLayout()
        prepareEpisodesPanelLayout()
        sectionHeader("Episodes")
        val rangeCount = episodeRangeCount()
        if (rangeCount <= 1) {
            val listScroll = episodeListScroll()
            val list = android.widget.LinearLayout(this).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                )
            }
            addEpisodeRows(0, episodeCount, list)
            listScroll.addView(list)
            menuContent.addView(listScroll)
            return
        }
        episodeRangeIndex = episodeRangeIndex.coerceIn(0, rangeCount - 1)
        val start = episodeRangeIndex * EPISODE_RANGE_CHUNK
        val end = minOf(start + EPISODE_RANGE_CHUNK, episodeCount)

        // Pin the range rail on the left; only the episode list scrolls.
        val body = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f,
            )
        }

        val rail = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            layoutParams = android.widget.LinearLayout.LayoutParams(
                dp(96),
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply {
                marginEnd = dp(12)
                gravity = Gravity.TOP
            }
        }
        for (r in 0 until rangeCount) {
            rail.addView(
                rangeChip(
                    rangeIndex = r,
                    label = episodeRangeLabel(r),
                    selected = r == episodeRangeIndex,
                ) {
                    if (r != episodeRangeIndex) {
                        episodeRangeIndex = r
                        firstSelectedRow = null
                        focusTarget = null
                        buildEpisodesPanel()
                        menuContent.post { focusEpisodeMenuTarget(preferRange = true) }
                    }
                },
            )
            if (r < rangeCount - 1) {
                rail.addView(
                    View(this).apply {
                        layoutParams = android.widget.LinearLayout.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            dp(8),
                        )
                    },
                )
            }
        }

        // Many ranges (>~700 eps): rail gets its own locked scroll — stays put
        // while browsing episodes; unlock only when a chip holds focus.
        val railContainer: View = if (rangeCount > 14) {
            LockedScrollView(this).apply {
                tag = "range-rail-scroll"
                scrollLocked = true
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    dp(96),
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                ).apply { marginEnd = dp(12) }
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                isFocusable = false
                addView(
                    rail.apply {
                        layoutParams = android.widget.FrameLayout.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                        )
                    },
                )
            }
        } else {
            rail
        }
        body.addView(railContainer)

        val listScroll = episodeListScroll().apply {
            layoutParams = android.widget.LinearLayout.LayoutParams(
                0,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                1f,
            )
        }
        val list = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            )
        }
        addEpisodeRows(start, end, list)
        listScroll.addView(list)
        body.addView(listScroll)
        menuContent.addView(body)
        scrollRangeRailToSelected()
    }

    private fun rangeRailScroll(): LockedScrollView? =
        menuContent.findViewWithTag("range-rail-scroll") as? LockedScrollView

    private fun setRangeRailLocked(locked: Boolean) {
        rangeRailScroll()?.scrollLocked = locked
    }

    private fun scrollRangeRailToSelected() {
        val scroll = rangeRailScroll() ?: return
        val chip = menuContent.findViewWithTag<View>("range-$episodeRangeIndex") ?: return
        scroll.post { scroll.scrollToIgnoringLock(0, chip.top.coerceAtLeast(0)) }
    }

    private fun addEpisodeRows(
        from: Int,
        until: Int,
        parent: android.widget.LinearLayout,
    ) {
        for (i in from until until) {
            val label = episodeLabels.getOrNull(i) ?: "Episode ${i + 1}"
            val isFiller = i < fillerFlags.size && fillerFlags[i]
            val rowLabel = if (isFiller) "$label  · FILLER" else label
            episodeOption(parent, i, rowLabel, selected = i == currentIndex) {
                if (i != currentIndex) loadEpisode(i)
            }
        }
    }

    private fun rangeChip(
        rangeIndex: Int,
        label: String,
        selected: Boolean,
        onSelect: () -> Unit,
    ): TextView {
        return TextView(this).apply {
            tag = "range-$rangeIndex"
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            isFocusable = true
            isFocusableInTouchMode = true
            minHeight = dp(32)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setTextColor(if (selected) android.graphics.Color.WHITE else 0xFFE8E8EC.toInt())
            if (selected) setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = rangeChipBg(selected, focused = false)
            onFocusChangeListener = View.OnFocusChangeListener { v, has ->
                if (has) setRangeRailLocked(false)
                v.background = rangeChipBg(selected, has)
                (v as TextView).setTextColor(
                    if (has || selected) android.graphics.Color.WHITE else 0xFFE8E8EC.toInt(),
                )
            }
            bindSingleTapActivate { onSelect() }
            setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    focusEpisodeFromRangeChip()
                    true
                } else false
            }
        }
    }

    private fun focusSelectedRangeChip() {
        menuContent.findViewWithTag<View>("range-$episodeRangeIndex")?.requestFocus()
    }

    private fun focusEpisodeFromRangeChip() {
        val rangeStart = episodeRangeIndex * EPISODE_RANGE_CHUNK
        val rangeEnd = minOf(rangeStart + EPISODE_RANGE_CHUNK, episodeCount)
        val target = if (currentIndex in rangeStart until rangeEnd) {
            currentIndex
        } else {
            rangeStart
        }
        val row = menuContent.findViewWithTag<View>("ep-$target")
        row?.requestFocus()
        row?.let { scrollEpisodeIntoView(it) }
    }

    private fun rangeChipBg(selected: Boolean, focused: Boolean): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(if (selected) accent else RANGE_CHIP_SURFACE)
            if (focused) setStroke(dp(2), android.graphics.Color.WHITE)
        }
    }

    private fun episodeOption(
        parent: android.widget.LinearLayout,
        index: Int,
        label: String,
        selected: Boolean,
        onSelect: () -> Unit,
    ) {
        val row = TextView(this).apply {
            tag = "ep-$index"
            text = (if (selected) "✓   " else "     ") + label
            setTextColor(if (selected) android.graphics.Color.WHITE else 0xFFB6B6C0.toInt())
            textSize = 16.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            if (selected) setTypeface(typeface, android.graphics.Typeface.BOLD)
            isFocusable = true
            setPadding(dp(16), dp(11), dp(16), dp(11))
            background = pillBg(0x00000000)
            onFocusChangeListener = View.OnFocusChangeListener { v, has ->
                if (has) setRangeRailLocked(true)
                v.background = pillBg(if (has) accent else 0x00000000)
                (v as TextView).setTextColor(
                    if (has) android.graphics.Color.WHITE
                    else if (selected) android.graphics.Color.WHITE else 0xFFB6B6C0.toInt(),
                )
            }
            bindSingleTapActivate {
                lastFocusLabel = label
                onSelect()
                closeMenu()
            }
            setOnKeyListener { _, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT &&
                    episodeRangeCount() > 1
                ) {
                    focusSelectedRangeChip()
                    true
                } else false
            }
        }
        if (selected && firstSelectedRow == null) firstSelectedRow = row
        if (label == lastFocusLabel) focusTarget = row
        parent.addView(
            row,
            android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
    }

    private fun focusEpisodeMenuTarget(preferRange: Boolean = false) {
        if (preferRange) {
            menuContent.findViewWithTag<TextView>("range-$episodeRangeIndex")?.requestFocus()
            return
        }
        val target = menuContent.findViewWithTag<View>("ep-$currentIndex")
        target?.requestFocus()
        target?.let { scrollEpisodeIntoView(it) }
            ?: firstSelectedRow?.requestFocus()
            ?: firstFocusable(menuContent)?.requestFocus()
    }

    private fun scrollEpisodeIntoView(row: View) {
        var parent = row.parent
        while (parent != null) {
            if (parent is android.widget.ScrollView && parent.tag == "episode-list-scroll") {
                val scroll = parent
                scroll.post { scroll.smoothScrollTo(0, row.top) }
                return
            }
            parent = (parent as? View)?.parent
        }
    }

    private fun closeMenu() {
        menuOpen = false
        avMenuActive = false
        avStack.clear()
        menuPanel.visibility = View.GONE
        menuContent.removeAllViews()
        resetMenuPanelLayout()
        bumpControls()
        (menuOpener ?: root).requestFocus()
    }

    private fun firstFocusable(group: android.view.ViewGroup): View? {
        for (i in 0 until group.childCount) {
            val c = group.getChildAt(i)
            if (c.isFocusable) return c
        }
        return null
    }

    /** Quality menu — mirrors the phone: the renditions of the stream that is
     *  playing (an adaptive HLS/DASH master's video tracks), else the single
     *  resolution it decodes at. Never other sources' labels. */
    private fun buildQualityMenu() {
        val p = player ?: return
        val groups = p.currentTracks.groups
        val video = groups.filter { it.type == C.TRACK_TYPE_VIDEO && it.isSupported }
        val videoTracks = video.flatMap { g -> (0 until g.length).map { g to it } }
            .filter { (g, i) -> g.isTrackSupported(i) }

        if (videoTracks.size > 1) {
            val overridden = p.trackSelectionParameters.overrides.keys.any {
                video.any { g -> g.mediaTrackGroup == it }
            }
            sectionHeader("Quality")
            option("Auto", selected = !overridden) {
                p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO).build()
            }
            for ((g, i) in videoTracks.sortedByDescending { (g, i) -> g.getTrackFormat(i).height }) {
                val h = g.getTrackFormat(i).height
                option(if (h > 0) "${h}p" else "Track ${i + 1}",
                    selected = overridden && g.isTrackSelected(i)) {
                    applyOverride(C.TRACK_TYPE_VIDEO, g, i)
                }
            }
        } else {
            // One video track: nothing to switch inside this stream. Show what
            // is actually playing, measured from the decoded format rather than
            // whatever the provider claimed. The other resolved sources are
            // separate files on separate servers and live under Sources — this
            // menu used to list them by quality label, which meant picking
            // "720p" jumped to some other mirror's file, audio and subtitles.
            val h = p.videoFormat?.height ?: 0
            sectionHeader("Quality")
            option(if (h > 0) "${h}p" else "Auto", selected = true) {}
        }
    }

    /** Sources menu — the full resolved stream/mirror list (mobile's Sources). */
    private fun buildSourcesMenu() {
        if (episodeSources.size > 1) {
            sectionHeader("Sources")
            episodeSources.forEachIndexed { i, s ->
                val label = (s["label"] as? String) ?: "Source ${i + 1}"
                option(label, selected = (s["url"] as? String) == currentUrl) { loadSource(i) }
            }
        } else {
            sectionHeader("Sources")
            option(episodeSources.firstOrNull()?.get("label") as? String ?: "Default", selected = true) {}
        }
    }

    /** Audio / Subtitles / Captions Styling / Volume — Crunchyroll-style Settings. */
    private fun openAvMenu() {
        avMenuActive = true
        avStack.clear()
        showMenu(btnAudioSubs) { buildAvPage(AvPage.ROOT) }
    }

    private fun pushAv(page: AvPage) {
        avStack.addLast(page)
        rebuildAvMenuDeferred()
    }

    private fun popAvOrClose() {
        if (avStack.isNotEmpty()) {
            avStack.removeLast()
            rebuildAvMenuDeferred()
        } else {
            closeMenu()
        }
    }

    private fun rebuildAvMenu() {
        firstSelectedRow = null
        focusTarget = null
        menuContent.removeAllViews()
        val page = avStack.lastOrNull() ?: AvPage.ROOT
        buildAvPage(page)
        menuContent.post {
            (focusTarget ?: firstSelectedRow ?: firstFocusable(menuContent))?.requestFocus()
        }
    }

    /** Rebuild after the current click/key event finishes. Rebuilding the menu
     *  hierarchy mid-click lets the event fall through to the row below — which
     *  showed up as "I selected English but Spanish got the checkmark". */
    private fun rebuildAvMenuDeferred() {
        menuContent.post { rebuildAvMenu() }
    }

    private fun buildAvPage(page: AvPage) {
        when (page) {
            AvPage.ROOT -> buildAvRoot()
            AvPage.AUDIO -> buildAvAudio()
            AvPage.SUBS -> buildAvSubs()
            AvPage.CAPTION_STYLE -> buildCaptionStyleRoot()
            AvPage.SIZE -> buildCaptionSize()
            AvPage.COLOR -> buildCaptionColor()
            AvPage.EDGE -> buildCaptionEdge()
            AvPage.BG -> buildCaptionBg()
            AvPage.FONT -> buildCaptionFont()
            AvPage.POS -> buildCaptionPos()
            AvPage.VOLUME -> buildAvVolume()
        }
    }

    private fun menuTitle(title: String) {
        menuContent.addView(TextView(this).apply {
            text = title
            setTextColor(android.graphics.Color.WHITE)
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(4), dp(2), 0, dp(18))
        })
    }

    private fun buildAvRoot() {
        val p = player ?: return
        menuTitle("Settings")
        val groups = p.currentTracks.groups

        val audioLabel = selectedTrackLabel(groups, C.TRACK_TYPE_AUDIO)
            ?: if (category == "dub") "Dub" else "Sub"
        navRow("Audio", audioLabel) { pushAv(AvPage.AUDIO) }

        val textDisabled = p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        navRow("Subtitles/CC", subtitleTrailingLabel(groups, textDisabled)) { pushAv(AvPage.SUBS) }

        navRow("Captions Styling", null) { pushAv(AvPage.CAPTION_STYLE) }

        val volLabel = if (volumePercent == 100) "100%" else "$volumePercent%"
        navRow("Volume", volLabel) { pushAv(AvPage.VOLUME) }
    }

    private fun selectedTrackLabel(groups: List<Tracks.Group>, type: Int): String? {
        val gs = groups.filter { it.type == type && it.isSupported }
        for (g in gs) {
            for (i in 0 until g.length) {
                if (!g.isTrackSelected(i)) continue
                val f = g.getTrackFormat(i)
                // Ignore embedded CEA CC in the trailing label — same filter as the picker.
                if (type == C.TRACK_TYPE_TEXT && isEmbeddedCea(f)) continue
                return f.label ?: langName(f.language) ?: "Track ${i + 1}"
            }
        }
        return null
    }

    /** In-band CEA-608/708 often has no label/language (shows as "Subtitle 1") and
     *  selecting it does nothing useful for anime softsubs — hide from the picker. */
    private fun isEmbeddedCea(f: androidx.media3.common.Format): Boolean {
        val mime = f.sampleMimeType ?: return false
        return mime == MimeTypes.APPLICATION_CEA608 || mime == MimeTypes.APPLICATION_CEA708
    }

    private fun textTrackChoices(groups: List<Tracks.Group>): List<Pair<Tracks.Group, Int>> {
        return groups
            .filter { it.type == C.TRACK_TYPE_TEXT }
            .flatMap { g -> (0 until g.length).map { g to it } }
            .filter { (g, i) ->
                g.isTrackSupported(i) && !isEmbeddedCea(g.getTrackFormat(i))
            }
    }

    private fun subtitleTrackLabel(f: androidx.media3.common.Format, index: Int): String {
        f.label?.takeIf { it.isNotBlank() }?.let { return it }
        langName(f.language)?.let { return it }
        return "Subtitle ${index + 1}"
    }

    private fun buildAvAudio() {
        menuTitle("Audio")
        val p = player ?: return
        val groups = p.currentTracks.groups
        if (availableCategories.size > 1) {
            for (c in availableCategories) {
                option(if (c == "dub") "Dub" else "Sub", selected = c == category, closeOnSelect = false) {
                    switchCategory(c)
                }
            }
        }
        // Always list audio tracks — even a single track — so the submenu is never
        // blank when Version isn't available (addTrackSection used to skip size<=1).
        val gs = groups.filter { it.type == C.TRACK_TYPE_AUDIO && it.isSupported }
        val tracks = gs.flatMap { g -> (0 until g.length).map { g to it } }
        if (tracks.isEmpty()) {
            option("Default", selected = true, closeOnSelect = false) {}
        } else {
            for ((g, i) in tracks) {
                val f = g.getTrackFormat(i)
                val label = f.label ?: langName(f.language) ?: "Audio ${i + 1}"
                val group = g
                val trackIndex = i
                option(label, selected = g.isTrackSelected(i), closeOnSelect = false) {
                    applyOverride(C.TRACK_TYPE_AUDIO, group, trackIndex)
                    rebuildAvMenuDeferred()
                }
            }
        }
    }

    private fun subtitleTrailingLabel(groups: List<Tracks.Group>, textDisabled: Boolean): String {
        if (textUiForcedOff) return "Off"
        textUiLabel?.let { return it }
        val selectedSub = selectedTrackLabel(groups, C.TRACK_TYPE_TEXT)
        // Exo often leaves TEXT enabled with nothing selected — that's Off, not "On".
        return if (textDisabled || selectedSub == null) "Off" else selectedSub
    }

    private fun clearTextUiOverride() {
        textUiForcedOff = false
        textUiLabel = null
    }

    private fun buildAvSubs() {
        menuTitle("Subtitles/CC")
        val p = player ?: return
        val groups = p.currentTracks.groups
        val textTracks = textTrackChoices(groups)
        val textDisabled = p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        val exoSelected = textTracks.any { (g, i) -> g.isTrackSelected(i) }
        // Prefer optimistic UI state — Exo's isTrackSelected lags the menu rebuild.
        val subsOff = when {
            textUiForcedOff -> true
            textUiLabel != null -> false
            else -> textDisabled || !exoSelected
        }
        option("Off", selected = subsOff, closeOnSelect = false) {
            textUiForcedOff = true
            textUiLabel = "Off"
            lastFocusLabel = "Off"
            p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
            rebuildAvMenuDeferred()
        }
        textTracks.forEachIndexed { index, (g, i) ->
            val f = g.getTrackFormat(i)
            val label = subtitleTrackLabel(f, index)
            val group = g
            val trackIndex = i
            // Match by label — TrackGroup identity can churn after applyOverride.
            val isSelected = when {
                textUiForcedOff -> false
                textUiLabel != null -> textUiLabel == label
                else -> !subsOff && g.isTrackSelected(i)
            }
            option(label, selected = isSelected, closeOnSelect = false) {
                textUiForcedOff = false
                textUiLabel = label
                lastFocusLabel = label
                applyOverride(C.TRACK_TYPE_TEXT, group, trackIndex)
                rebuildAvMenuDeferred()
            }
        }
        if (subtitleApiKeySet) {
            navRow("Search online…", null) { searchSubtitlesOnline() }
        }
    }

    private fun buildCaptionStyleRoot() {
        menuTitle("Captions Styling")
        navRow("Font Size", captionSizeLabel(subScale)) { pushAv(AvPage.SIZE) }
        navRow("Text Color", captionColorLabel(subColorHex)) { pushAv(AvPage.COLOR) }
        navRow("Edge Style", captionEdgeLabel(subOutlineId)) { pushAv(AvPage.EDGE) }
        navRow("Background", captionBgLabel(subBgOpacity)) { pushAv(AvPage.BG) }
        navRow("Font", if (subFontFamily.isEmpty()) "Default" else subFontFamily) { pushAv(AvPage.FONT) }
        navRow("Position", captionPosLabel(subPositionPref)) { pushAv(AvPage.POS) }
    }

    private fun buildCaptionSize() {
        menuTitle("Font Size")
        val sizes = listOf("Small" to 0.8f, "Medium" to 1.0f, "Large" to 1.3f)
        val nearest = sizes.minByOrNull { kotlin.math.abs(it.second - subScale) }?.second
        for ((label, s) in sizes) {
            option(label, selected = s == nearest, closeOnSelect = false) {
                subScale = s
                applySubtitleStyleLive()
                MainActivity.tvBridge?.invokeMethod("setSubtitleScale", mapOf("scale" to s.toDouble()))
                rebuildAvMenuDeferred()
            }
        }
    }

    private fun buildCaptionColor() {
        menuTitle("Text Color")
        val colors = listOf(
            "#FFFFFFFF" to "White",
            "#FFFF00FF" to "Yellow",
            "#00E5FFFF" to "Cyan",
            "#7CFC00FF" to "Green",
            "#FF6B6BFF" to "Red",
            "#000000FF" to "Black",
        )
        for ((hex, label) in colors) {
            option(label, selected = subColorHex.equals(hex, ignoreCase = true), closeOnSelect = false) {
                subColorHex = hex
                subFg = parseColorHex(hex)
                applySubtitleStyleLive()
                MainActivity.tvBridge?.invokeMethod("setSubtitleColorHex", mapOf("hex" to hex))
                rebuildAvMenuDeferred()
            }
        }
    }

    private fun buildCaptionEdge() {
        menuTitle("Edge Style")
        val edges = listOf(
            "none" to ("None" to CaptionStyleCompat.EDGE_TYPE_NONE),
            "outline" to ("Outline" to CaptionStyleCompat.EDGE_TYPE_OUTLINE),
            "shadow" to ("Drop Shadow" to CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW),
            "raised" to ("Raised" to CaptionStyleCompat.EDGE_TYPE_RAISED),
            "depressed" to ("Depressed" to CaptionStyleCompat.EDGE_TYPE_DEPRESSED),
        )
        for ((id, pair) in edges) {
            val (label, type) = pair
            option(label, selected = subEdgeType == type, closeOnSelect = false) {
                subOutlineId = id
                subEdgeType = type
                applySubtitleStyleLive()
                MainActivity.tvBridge?.invokeMethod("setSubtitleOutlineType", mapOf("type" to id))
                rebuildAvMenuDeferred()
            }
        }
    }

    private fun buildCaptionBg() {
        menuTitle("Background")
        val bgs = listOf("Off" to 0f, "Light" to 0.25f, "Medium" to 0.5f, "Strong" to 0.75f)
        val nearest = bgs.minByOrNull { kotlin.math.abs(it.second - subBgOpacity) }?.second
        for ((label, o) in bgs) {
            option(label, selected = o == nearest, closeOnSelect = false) {
                subBgOpacity = o
                subBgColor = ((o * 255).toInt() shl 24)
                applySubtitleStyleLive()
                MainActivity.tvBridge?.invokeMethod("setSubtitleBgOpacity", mapOf("opacity" to o.toDouble()))
                rebuildAvMenuDeferred()
            }
        }
    }

    private fun buildCaptionFont() {
        menuTitle("Font")
        val fonts = listOf(
            "" to "Default",
            "Inter" to "Inter",
            "Poppins" to "Poppins",
            "Roboto" to "Roboto",
            "Open Sans" to "Open Sans",
            "Lato" to "Lato",
            "Montserrat" to "Montserrat",
            "Nunito" to "Nunito",
            "Rubik" to "Rubik",
            "Noto Sans" to "Noto Sans",
            "Source Sans 3" to "Source Sans 3",
        )
        for ((family, label) in fonts) {
            option(label, selected = subFontFamily == family, closeOnSelect = false) {
                applyCaptionFont(family)
            }
        }
    }

    /** Persist + stage the bundled font, then re-apply CaptionStyleCompat. */
    private fun applyCaptionFont(family: String) {
        subFontFamily = family
        MainActivity.tvBridge?.invokeMethod("setSubtitleFont", mapOf("font" to family))
        if (family.isEmpty()) {
            subFontPath = null
            applySubtitleStyleLive()
            rebuildAvMenuDeferred()
            return
        }
        val bridge = MainActivity.tvBridge
        if (bridge == null) {
            applySubtitleStyleLive()
            rebuildAvMenuDeferred()
            return
        }
        bridge.invokeMethod(
            "stageSubtitleFont",
            mapOf("font" to family),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    val path = result as? String
                    runOnUiThread {
                        subFontPath = path
                        applySubtitleStyleLive()
                        rebuildAvMenuDeferred()
                        if (path == null) toast("Could not load font")
                    }
                }
                override fun error(code: String, msg: String?, details: Any?) {
                    runOnUiThread {
                        toast(msg ?: "Could not load font")
                        rebuildAvMenuDeferred()
                    }
                }
                override fun notImplemented() {
                    runOnUiThread { rebuildAvMenuDeferred() }
                }
            },
        )
    }

    private fun applySubtitleStyleLive() {
        // Custom font first, system behind it — otherwise a font without
        // Arabic glyphs renders boxes (see subtitleTypeface).
        val tf = subtitleTypeface(subFontPath.takeUnless { it.isNullOrBlank() })
        subTypeface = tf
        playerView.subtitleView?.apply {
            setApplyEmbeddedStyles(false)
            setApplyEmbeddedFontSizes(false)
            setStyle(
                CaptionStyleCompat(
                    subFg,
                    subBgColor,
                    android.graphics.Color.TRANSPARENT,
                    subEdgeType,
                    android.graphics.Color.BLACK,
                    tf,
                ),
            )
            setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * subScale)
            // Position is applied by remapping cue lines (see repositionCues) —
            // bottom padding alone is ignored when cues already set a line.
            setBottomPaddingFraction(0.02f)
            invalidate()
        }
        // Re-apply current cues so a Position change takes effect immediately.
        player?.currentCues?.let { playerView.subtitleView?.setCues(repositionCues(it.cues)) }
    }

    /**
     * Force each cue onto the user's vertical preference (0=top … 100=bottom),
     * keeping simultaneous cues on separate rows. Media3's
     * [SubtitleView.setBottomPaddingFraction] only shifts cues that leave line
     * unset — most VTT/SRT/ASS cues set their own line, so without this remapping
     * Low/Middle/High look identical. See [TvSubtitleCuePositioning].
     */
    private fun repositionCues(cues: List<Cue>): List<Cue> {
        val view = playerView.subtitleView ?: return cues
        return TvSubtitleCuePositioning.position(
            cues,
            positionPercent = subPositionPref,
            textSizeFraction = SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * subScale,
            width = view.width - view.paddingLeft - view.paddingRight,
            height = view.height - view.paddingTop - view.paddingBottom,
            typeface = subTypeface,
        )
    }

    private fun buildCaptionPos() {
        menuTitle("Position")
        val positions = listOf("Low" to 95, "Middle" to 70, "High" to 40)
        val nearest = positions.minByOrNull { kotlin.math.abs(it.second - subPositionPref) }?.second
        for ((label, pos) in positions) {
            option(label, selected = pos == nearest, closeOnSelect = false) {
                subPositionPref = pos
                applySubtitleStyleLive()
                MainActivity.tvBridge?.invokeMethod("setSubtitlePosition", mapOf("position" to pos))
                rebuildAvMenuDeferred()
            }
        }
    }

    private fun buildAvVolume() {
        menuTitle("Volume")
        for (v in listOf(100, 125, 150, 175, 200)) {
            option(if (v == 100) "100% (normal)" else "$v%", selected = volumePercent == v, closeOnSelect = false) {
                applyVolume(v)
                rebuildAvMenuDeferred()
            }
        }
    }

    private fun captionSizeLabel(scale: Float): String {
        val sizes = listOf("Small" to 0.8f, "Medium" to 1.0f, "Large" to 1.3f)
        return sizes.minByOrNull { kotlin.math.abs(it.second - scale) }?.first ?: "Medium"
    }

    private fun captionColorLabel(hex: String): String {
        val colors = listOf(
            "#FFFFFFFF" to "White", "#FFFF00FF" to "Yellow", "#00E5FFFF" to "Cyan",
            "#7CFC00FF" to "Green", "#FF6B6BFF" to "Red", "#000000FF" to "Black",
        )
        return colors.firstOrNull { it.first.equals(hex, ignoreCase = true) }?.second ?: "Custom"
    }

    private fun captionEdgeLabel(id: String): String = when (id) {
        "none" -> "None"
        "shadow" -> "Drop Shadow"
        "raised" -> "Raised"
        "depressed" -> "Depressed"
        else -> "Outline"
    }

    private fun captionBgLabel(opacity: Float): String {
        val bgs = listOf("Off" to 0f, "Light" to 0.25f, "Medium" to 0.5f, "Strong" to 0.75f)
        return bgs.minByOrNull { kotlin.math.abs(it.second - opacity) }?.first ?: "Off"
    }

    private fun captionPosLabel(pos: Int): String {
        val positions = listOf("Low" to 95, "Middle" to 70, "High" to 40)
        return positions.minByOrNull { kotlin.math.abs(it.second - pos) }?.first ?: "Low"
    }

    private fun parseColorHex(hex: String): Int {
        var h = hex.removePrefix("#").trim()
        if (h.length == 6) h = h + "FF"
        if (h.length != 8) return android.graphics.Color.WHITE
        return try {
            val rgb = h.substring(0, 6)
            val a = h.substring(6, 8)
            android.graphics.Color.parseColor("#$a$rgb")
        } catch (_: Exception) {
            android.graphics.Color.WHITE
        }
    }

    private fun addTrackSection(
        title: String,
        groups: List<Tracks.Group>,
        type: Int,
        closeOnSelect: Boolean = true,
        label: (androidx.media3.common.Format, Int) -> String,
    ) {
        val gs = groups.filter { it.type == type && it.isSupported }
        val tracks = gs.flatMap { g -> (0 until g.length).map { g to it } }
        if (tracks.size <= 1) return
        // When already under a page title (Audio), skip the redundant section header.
        if (closeOnSelect) sectionHeader(title)
        for ((g, i) in tracks) {
            val group = g
            val trackIndex = i
            option(label(g.getTrackFormat(i), i), selected = g.isTrackSelected(i), closeOnSelect = closeOnSelect) {
                applyOverride(type, group, trackIndex)
                if (!closeOnSelect) rebuildAvMenuDeferred()
            }
        }
    }

    private fun applyOverride(type: Int, g: Tracks.Group, trackIndex: Int) {
        val p = player ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, trackIndex))
            .build()
    }

    // ── Online subtitle search (OpenSubtitles, via the native→Dart bridge) ────
    private fun searchSubtitlesOnline() {
        val bridge = MainActivity.tvBridge ?: return
        toast("Searching subtitles…")
        bridge.invokeMethod(
            "searchSubtitles",
            emptyMap<String, Any?>(),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    @Suppress("UNCHECKED_CAST")
                    val list = result as? List<Map<String, Any?>> ?: emptyList()
                    runOnUiThread { showSubtitleResults(list) }
                }
                override fun error(code: String, msg: String?, details: Any?) {
                    runOnUiThread { toast(msg ?: "Subtitle search failed") }
                }
                override fun notImplemented() {}
            },
        )
    }

    private fun showSubtitleResults(results: List<Map<String, Any?>>) {
        if (results.isEmpty()) { toast("No subtitles found"); return }
        showMenu(btnAudioSubs) {
            sectionHeader("Search results")
            results.forEachIndexed { i, r ->
                val name = r["name"] as? String ?: "Subtitle ${i + 1}"
                val lang = r["language"] as? String
                val label = if (lang.isNullOrBlank()) name else "$name  ·  ${langName(lang) ?: lang}"
                option(label, selected = false) { downloadSubtitle(i) }
            }
        }
    }

    private fun downloadSubtitle(index: Int) {
        val bridge = MainActivity.tvBridge ?: return
        toast("Downloading subtitle…")
        bridge.invokeMethod(
            "downloadSubtitle",
            mapOf("index" to index),
            object : MethodChannel.Result {
                override fun success(result: Any?) {
                    @Suppress("UNCHECKED_CAST")
                    val m = result as? Map<String, Any?>
                    val path = m?.get("path") as? String
                    if (path == null) { runOnUiThread { toast("Couldn't download subtitle") }; return }
                    runOnUiThread {
                        addDownloadedSubtitle(
                            path,
                            m["language"] as? String,
                            m["name"] as? String,
                            m["format"] as? String,
                        )
                    }
                }
                override fun error(code: String, msg: String?, details: Any?) {
                    runOnUiThread { toast(msg ?: "Couldn't download subtitle") }
                }
                override fun notImplemented() {}
            },
        )
    }

    /** Add a downloaded subtitle to the current stream and reload it in place
     *  (same position). SELECTION_FLAG_DEFAULT makes ExoPlayer show it at once. */
    private fun addDownloadedSubtitle(path: String, lang: String?, label: String?, format: String?) {
        val uri = android.net.Uri.fromFile(java.io.File(path))
        val isSrt = (format ?: "").contains("srt", true) || path.lowercase().endsWith(".srt")
        val cfg = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(if (isSrt) MimeTypes.APPLICATION_SUBRIP else MimeTypes.TEXT_VTT)
            .setLanguage(lang)
            .setLabel(label ?: "OpenSubtitles")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        currentSubs.add(cfg)
        val url = currentUrl ?: return
        val pos = player?.currentPosition ?: 0L
        loadStream(url, currentHeaders, currentSubs.toList(), currentMime, pos,
            currentDrmKid, currentDrmKey)
        toast("Subtitle added")
    }

    private fun toast(msg: String) {
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun applyVolume(percent: Int) {
        volumePercent = percent.coerceIn(100, 200)
        val gainMb = (((volumePercent - 100) / 100f) * 600f).toInt()
        try {
            if (loudness == null) loudness = android.media.audiofx.LoudnessEnhancer(player!!.audioSessionId)
            loudness?.setTargetGain(gainMb)
            loudness?.enabled = gainMb > 0
        } catch (_: Exception) { /* effect unavailable on this device */ }
    }

    private fun langName(code: String?): String? {
        if (code.isNullOrBlank() || code == "und") return null
        return try {
            java.util.Locale(code).displayLanguage.ifBlank { code }
        } catch (_: Exception) { code }
    }

    private fun sectionHeader(title: String) {
        menuContent.addView(TextView(this).apply {
            text = title.uppercase()
            setTextColor(accent)
            textSize = 12.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            letterSpacing = 0.09f
            val t = if (menuContent.childCount == 0) dp(2) else dp(22)
            setPadding(dp(4), t, 0, dp(8))
        })
    }

    /** Summary / nav row: label left, optional trailing value right, no check. */
    private fun navRow(label: String, trailing: String?, onSelect: () -> Unit) {
        val row = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            isFocusable = true
            isFocusableInTouchMode = true
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = pillBg(0x00000000)
            addView(TextView(this@TvPlayerActivity).apply {
                text = label
                setTextColor(android.graphics.Color.WHITE)
                textSize = 16.5f
                layoutParams = android.widget.LinearLayout.LayoutParams(
                    0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f,
                )
            })
            if (trailing != null) {
                addView(TextView(this@TvPlayerActivity).apply {
                    text = trailing
                    setTextColor(0x8CFFFFFF.toInt())
                    textSize = 15f
                    tag = "trailing"
                })
            }
            onFocusChangeListener = View.OnFocusChangeListener { v, has ->
                v.background = pillBg(if (has) accent else 0x00000000)
                val trail = (v as android.widget.LinearLayout).findViewWithTag<TextView>("trailing")
                trail?.setTextColor(if (has) android.graphics.Color.WHITE else 0x8CFFFFFF.toInt())
            }
            bindSingleTapActivate {
                lastFocusLabel = label
                onSelect()
            }
        }
        if (label == lastFocusLabel) focusTarget = row
        menuContent.addView(
            row,
            android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
    }

    private fun option(
        label: String,
        selected: Boolean,
        closeOnSelect: Boolean = true,
        onSelect: () -> Unit,
    ) {
        val row = TextView(this).apply {
            text = (if (selected) "✓   " else "     ") + label
            setTextColor(if (selected) android.graphics.Color.WHITE else 0xFFB6B6C0.toInt())
            textSize = 16.5f
            if (selected) setTypeface(typeface, android.graphics.Typeface.BOLD)
            isFocusable = true
            setPadding(dp(16), dp(11), dp(16), dp(11))
            background = pillBg(0x00000000)
            onFocusChangeListener = View.OnFocusChangeListener { v, has ->
                v.background = pillBg(if (has) accent else 0x00000000)
                (v as TextView).setTextColor(
                    if (has) android.graphics.Color.WHITE
                    else if (selected) android.graphics.Color.WHITE else 0xFFB6B6C0.toInt()
                )
            }
            bindSingleTapActivate {
                lastFocusLabel = label
                onSelect()
                if (closeOnSelect) closeMenu()
            }
        }
        if (selected && firstSelectedRow == null) firstSelectedRow = row
        if (label == lastFocusLabel) focusTarget = row
        menuContent.addView(
            row,
            android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            ),
        )
    }

    private fun pillBg(color: Int) = android.graphics.drawable.GradientDrawable().apply {
        cornerRadius = dp(12).toFloat()
        setColor(color)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bindViews() {
        root = findViewById(R.id.player_root)
        playerView = findViewById(R.id.player_view)
        playerView.keepSubtitlesInViewport()
        loading = findViewById(R.id.loading)
        skipButton = findViewById(R.id.skip_button)
        menuPanel = findViewById(R.id.menu_panel)
        menuContent = findViewById(R.id.menu_content)
        controls = findViewById(R.id.controls)
        timeBar = findViewById(R.id.time_bar)
        positionText = findViewById(R.id.position)
        durationText = findViewById(R.id.duration)
        centerIcon = findViewById(R.id.center_icon)
        seekIndicator = findViewById(R.id.seek_indicator)
        speedBadge = findViewById(R.id.speed_badge)
        buttonRow = findViewById(R.id.button_row)
        btnEpisodes = findViewById(R.id.btn_episodes)
        btnQuality = findViewById(R.id.btn_quality)
        btnSources = findViewById(R.id.btn_sources)
        btnAudioSubs = findViewById(R.id.btn_audio_subs)
        btnNext = findViewById(R.id.btn_next)
        btnAspectRatio = findViewById(R.id.btn_ratio)
        btnMegaskip = findViewById(R.id.btn_megaskip)
        btnSpeed = findViewById(R.id.btn_speed)
        btnSeekBackward = findViewById(R.id.btn_seek_backward)
        btnSeekForward = findViewById(R.id.btn_seek_forward)
        fillerBadge = findViewById(R.id.filler_badge)
        // MegaSkip pill: label + visibility from the megaSkip prefs (launch extras).
        megaSkipSecs = intent.getIntExtra(EXTRA_MEGASKIP_SECS, 85)
        btnMegaskip.text = "+${megaSkipSecs}s"
        btnMegaskip.visibility =
            if (intent.getBooleanExtra(EXTRA_MEGASKIP, true)) View.VISIBLE else View.GONE

        // Seek ±N s pills — wired for D-pad focus highlight + OK (layout alone
        // leaves them focusable but visually inert and with no click handler).
        val seekSecs = (seekButtonDurationMs / 1000L).coerceAtLeast(1L)
        val seekLabel = "${seekSecs}s"
        btnSeekBackward.text = seekLabel
        btnSeekForward.text = seekLabel
        btnSeekBackward.contentDescription = "Seek back $seekLabel"
        btnSeekForward.contentDescription = "Seek forward $seekLabel"
        val seekVis = if (seekButtonsEnabled) View.VISIBLE else View.GONE
        btnSeekBackward.visibility = seekVis
        btnSeekForward.visibility = seekVis

        findViewById<TextView>(R.id.title).text = intent.getStringExtra(EXTRA_TITLE) ?: ""
        // episode_label / filler badge are set by updateEpisodeUi.
    }

    private fun styleControls() {
        timeBar.setPlayedColor(accent)
        timeBar.setScrubberColor(accent)
        // Accent-tinted, clean loading spinner (premium, not the grey default).
        (loading as? android.widget.ProgressBar)?.indeterminateTintList =
            android.content.res.ColorStateList.valueOf(accent)
        // Not D-pad focusable (◀▶ keys still seek) but touch-scrubbable below.
        timeBar.isFocusable = false
        timeBar.addListener(object : TimeBar.OnScrubListener {
            override fun onScrubStart(bar: TimeBar, position: Long) {
                scrubbing = true
                seekTarget = -1L
                handler.removeCallbacks(commitSeek)
                cancelAutoHide()
                showControls()
                positionText.text = fmt(position)
            }

            override fun onScrubMove(bar: TimeBar, position: Long) {
                positionText.text = fmt(position)
            }

            override fun onScrubStop(bar: TimeBar, position: Long, canceled: Boolean) {
                scrubbing = false
                if (!canceled) {
                    seekTarget = -1L
                    player?.seekTo(position)
                    reportTiming(positionMs = position)
                }
                bumpControls()
            }
        })

        for (b in listOf(
            btnEpisodes,
            btnQuality,
            btnSources,
            btnAudioSubs,
            btnNext,
            btnAspectRatio,
            btnMegaskip,
            btnSpeed,
            btnSeekBackward,
            btnSeekForward,
        )) {
            // Focusable even in touch mode so requestFocus() works on emulators
            // (real TVs are always in D-pad/non-touch mode anyway).
            applyPillFocus(b, false)
            b.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
                applyPillFocus(v as TextView, hasFocus)
                if (hasFocus) {
                    // Keep zone in sync for touch focus (D-pad uses enterZone).
                    focusZone = when (v.id) {
                        R.id.btn_quality, R.id.btn_sources, R.id.btn_audio_subs -> 1
                        else -> 2 // episodes / seek / next / megaskip / speed bottom row
                    }
                    cancelAutoHide()
                }
            }
        }
        // Single-tap on touchscreens: highlight + fire (focusableInTouchMode alone
        // would eat the first tap for focus only). Next uses nextAutoplayIndex so
        // autoSkipFiller applies to the button as well as binge autoplay.
        btnEpisodes.bindSingleTapActivate { openEpisodes() }
        btnQuality.bindSingleTapActivate { openQualityMenu() }
        btnSources.bindSingleTapActivate { openSourcesMenu() }
        btnAudioSubs.bindSingleTapActivate { openAvMenu() }
        btnNext.bindSingleTapActivate { loadEpisode(nextAutoplayIndex()) }
        btnAspectRatio.bindSingleTapActivate { changeAspectRatio() }
        btnSeekBackward.bindSingleTapActivate { seekBy(-seekButtonDurationMs) }
        btnSeekForward.bindSingleTapActivate { seekBy(seekButtonDurationMs) }
        btnMegaskip.bindSingleTapActivate { seekBy(megaSkipSecs * 1000L) }
        btnSpeed.bindSingleTapActivate { openSpeedMenu() }
        updateSpeedPillLabel()

        applyPillFocus(skipButton, false)
        skipButton.onFocusChangeListener =
            View.OnFocusChangeListener { v, has -> applyPillFocus(v as TextView, has) }
        skipButton.bindSingleTapActivate {
            if (activeSkipEnd > 0) {
                val end = activeSkipEnd
                player?.seekTo(end)
                seekTarget = -1L
                reportTiming(positionMs = end)
            }
            hideSkip()
        }

        // Touchscreen TVs: tap empty video / chrome to show or hide controls.
        // Wired on playerView (controls GONE) and controls (controls VISIBLE) so
        // we never attach a click listener to the focusable root — that would
        // collide with D-pad OK play/pause.
        playerView.setOnClickListener { toggleControlsFromTouch() }
        controls.isFocusable = false
        controls.setOnClickListener { toggleControlsFromTouch() }
    }

    /**
     * focusableInTouchMode + OnClickListener normally needs two taps on a
     * touchscreen (1st focuses, 2nd clicks). Consume the touch and on UP both
     * request focus (pill highlight) and performClick so one tap does both.
     * D-pad OK still goes through the normal click / key path.
     */
    private fun View.bindSingleTapActivate(onActivate: () -> Unit) {
        isClickable = true
        isFocusable = true
        isFocusableInTouchMode = true
        setOnClickListener { onActivate() }
        setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> true
                MotionEvent.ACTION_CANCEL -> true
                MotionEvent.ACTION_UP -> {
                    if (event.x >= 0f && event.x < v.width &&
                        event.y >= 0f && event.y < v.height
                    ) {
                        v.requestFocus()
                        v.playSoundEffect(SoundEffectConstants.CLICK)
                        v.performClick()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun applyPillFocus(b: TextView, focused: Boolean) {
        // Minimal glass pill: subtle dark when idle, clean accent fill on focus,
        // gentle scale — reads premium on a TV instead of chunky.
        b.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 100f * resources.displayMetrics.density // fully rounded ends
            setColor(if (focused) accent else UNFOCUSED_PILL)
        }
        b.alpha = if (focused) 1f else 0.92f
        val scale = if (focused) 1.07f else 1f
        b.animate().scaleX(scale).scaleY(scale).setDuration(140).start()
    }

    // ── Controls visibility ──────────────────────────────────────────────────
    private fun showControls() {
        if (menuOpen) return // never draw the transport controls over an open menu
        controls.visibility = View.VISIBLE
        controlsVisible = true
    }

    private fun hideControls() {
        if (rowFocused || scrubbing) return // never yank chrome mid-row / mid-scrub
        controls.visibility = View.GONE
        controlsVisible = false
    }

    /** Show controls and (re)arm the auto-hide — but only while actually playing
     *  and not navigating the button row, so a paused player keeps its controls
     *  (and the pause glyph) on screen. */
    private fun bumpControls() {
        if (menuOpen) return
        showControls()
        handler.removeCallbacks(hideRunnable)
        if (!rowFocused && !scrubbing && player?.isPlaying == true) {
            handler.postDelayed(hideRunnable, AUTO_HIDE_MS)
        }
    }

    /** Touch on empty video/chrome:
     *  - side menu open → dismiss the menu
     *  - controls visible → play/pause (same as remote OK; shows center glyph)
     *  - controls hidden → show controls
     *  Menu rows / control pills still consume their own taps. */
    private fun toggleControlsFromTouch() {
        if (menuOpen) {
            closeMenu()
            return
        }
        if (controls.visibility == View.VISIBLE) {
            togglePlayPause()
        } else {
            bumpControls()
        }
    }

    private fun cancelAutoHide() = handler.removeCallbacks(hideRunnable)

    // Some TV remotes/HDMI-CEC send Back as ESCAPE (or another code) instead of
    // KEYCODE_BACK — the OLD Flutter player handled goBack AND escape for exactly
    // this reason. Treat all back-like keycodes as Back.
    private fun isBack(kc: Int) =
        kc == KeyEvent.KEYCODE_BACK || kc == KeyEvent.KEYCODE_ESCAPE

    private fun updateProgress() {
        val p = player ?: return
        val dur = if (p.duration > 0) p.duration else 0L
        // While a seek is pending, show the target so the bar/time don't snap back
        // to the old position between presses and the commit.
        val pos = if (seekTarget >= 0) seekTarget else p.currentPosition.coerceAtLeast(0)
        timeBar.setDuration(dur)
        // Don't fight the finger — DefaultTimeBar owns position while scrubbing.
        if (!scrubbing) {
            timeBar.setPosition(pos)
            positionText.text = fmt(pos)
        }
        timeBar.setBufferedPosition(p.bufferedPosition.coerceAtLeast(0))
        durationText.text = fmt(dur)
    }

    // Keep the screen on only while actively playing or buffering, released on
    // pause — matching CloudStream — instead of pinning it on for the whole
    // session. On a TV this lets the screensaver return when you pause and walk
    // away, while never letting it kick in mid-episode.
    private fun syncKeepScreenOn() {
        val p = player
        playerView.keepScreenOn = p != null && p.playWhenReady &&
                (p.playbackState == Player.STATE_READY ||
                        p.playbackState == Player.STATE_BUFFERING)
    }

    private fun updatePlayPauseIcon() {
        val playing = player?.isPlaying == true
        if (playing) {
            if (centerIcon.visibility == View.VISIBLE) {
                centerIcon.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(160)
                    .withEndAction { centerIcon.visibility = View.GONE }.start()
            }
        } else if (centerIcon.visibility != View.VISIBLE) {
            centerIcon.visibility = View.VISIBLE
            centerIcon.alpha = 0f
            centerIcon.scaleX = 0.6f
            centerIcon.scaleY = 0.6f
            centerIcon.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
                .setInterpolator(android.view.animation.OvershootInterpolator(2f)).start()
        }
    }

    // ── Playback actions ─────────────────────────────────────────────────────
    private fun togglePlayPause() {
        val p = player ?: return
        if (p.playWhenReady) {
            p.pause()
            userPaused = true
            reportTiming(playing = false)
        } else {
            p.play()
            userPaused = false
            reportTiming(playing = true)
        }
        bumpControls()
    }

    /** Accelerating step: single taps jump 10s; holding ◀▶ ramps to 30s then 60s
     *  so you can scrub across a long video quickly (repeatCount rises while held). */
    private fun seekStep(repeat: Int): Long = when {
        repeat < 3 -> seekButtonDurationMs
        repeat < 10 -> seekButtonDurationMs * 3
        else -> seekButtonDurationMs * 6
    }

    private fun seekBy(deltaMs: Long) {
        if (!seekButtonsEnabled) return
        val p = player ?: return
        val dur = if (p.duration > 0) p.duration else Long.MAX_VALUE
        val base = if (seekTarget >= 0) seekTarget else p.currentPosition
        seekTarget = (base + deltaMs).coerceIn(0, dur)
        // Jump the bar + times to the target immediately (updateProgress keeps
        // showing seekTarget until the debounced seek commits), so it feels live.
        updateProgress()
        seekIndicator.text = fmt(seekTarget)
        seekIndicator.visibility = View.VISIBLE
        handler.removeCallbacks(hideSeekIndicator)
        handler.postDelayed(hideSeekIndicator, 900)
        handler.removeCallbacks(commitSeek)
        handler.postDelayed(commitSeek, 260)
        bumpControls()
    }

    private fun engageSpeed() {
        val p = player ?: return
        speedEngaged = true
        p.playbackParameters = PlaybackParameters(2f)
        speedBadge.visibility = View.VISIBLE
        cancelAutoHide()
        showControls()
    }

    private fun disengageSpeed() {
        speedEngaged = false
        player?.playbackParameters = PlaybackParameters(speed) // back to the chosen speed
        speedBadge.visibility = View.GONE
        bumpControls()
    }

    private fun updateSpeedPillLabel() {
        btnSpeed.text = if (kotlin.math.abs(speed - 1f) < 0.001f) "1×" else "${speed}×"
    }

    /** Playback speed — same right-side panel as Quality / Audio & Subs. */
    private fun openSpeedMenu() = showMenu(btnSpeed) { buildSpeedMenu() }

    private fun buildSpeedMenu() {
        menuTitle("Speed")
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        for (s in speeds) {
            option(
                if (s == 1.0f) "Normal" else "${s}×",
                selected = kotlin.math.abs(speed - s) < 0.001f,
            ) {
                speed = s
                player?.playbackParameters = PlaybackParameters(s)
                updateSpeedPillLabel()
                MainActivity.tvBridge?.invokeMethod(
                    "setDefaultSpeed", mapOf("speed" to s.toDouble()),
                )
            }
        }
    }

    // ── Button-row focus (zone 1 = top-right actions, zone 2 = bottom) ────────
    private fun enterZone(zone: Int) {
        showControls()
        focusZone = zone
        cancelAutoHide()
        (if (zone == 1) btnQuality else btnEpisodes).requestFocus()
    }

    private fun exitRow() {
        focusZone = 0
        root.requestFocus()
        bumpControls()
    }

    // ── Key handling ─────────────────────────────────────────────────────────
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Options menu open → native focus drives the D-pad. Back closes the menu
        // RIGHT HERE (consuming it).
        if (menuOpen) {
            if (isBack(event.keyCode)) {
                if (event.action == KeyEvent.ACTION_UP) handleBack()
                return true
            }
            return super.dispatchKeyEvent(event)
        }
        // Skip pill focused: OK jumps past the interval; anything else leaves it
        // and is handled normally (so seeking/controls still work).
        if (skipButton.isFocused) {
            val a = event.action
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BUTTON_A ->
                    return super.dispatchKeyEvent(event) // OK performs the skip
                KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                    if (a == KeyEvent.ACTION_UP) root.requestFocus()
                    return true
                }
                // Navigate OFF the pill (no focus-stealing): ▼ → button row,
                // ▲ → video, ◀ ▶ → seek. The pill stays reachable via ▼/▲ below.
                KeyEvent.KEYCODE_DPAD_DOWN -> { if (a == KeyEvent.ACTION_DOWN) enterZone(2); return true }
                KeyEvent.KEYCODE_DPAD_UP -> { if (a == KeyEvent.ACTION_DOWN) { focusZone = 0; root.requestFocus(); bumpControls() }; return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> { if (a == KeyEvent.ACTION_DOWN) { focusZone = 0; root.requestFocus(); seekBy(-seekStep(event.repeatCount)) }; return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> { if (a == KeyEvent.ACTION_DOWN) { focusZone = 0; root.requestFocus(); seekBy(seekStep(event.repeatCount)) }; return true }
                else -> if (a == KeyEvent.ACTION_DOWN) root.requestFocus()
            }
        }
        val down = event.action == KeyEvent.ACTION_DOWN
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_BUTTON_A -> {
                if (rowFocused) return super.dispatchKeyEvent(event) // let the button fire
                if (down) {
                    if (event.repeatCount == 0) {
                        bumpControls()
                        handler.postDelayed(engage2x, HOLD_MS) // hold → 2×
                    }
                    return true
                }
                // ACTION_UP
                handler.removeCallbacks(engage2x)
                if (speedEngaged) disengageSpeed() else togglePlayPause()
                return true
            }

            KeyEvent.KEYCODE_DPAD_LEFT ->
                if (!rowFocused) { if (down) seekBy(-seekStep(event.repeatCount)); return true }

            KeyEvent.KEYCODE_DPAD_RIGHT ->
                if (!rowFocused) { if (down) seekBy(seekStep(event.repeatCount)); return true }

            // ▼ : video → Skip pill (if up) else bottom row · top row → video.
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (down) when (focusZone) {
                    0 -> if (skipButton.visibility == View.VISIBLE) skipButton.requestFocus() else enterZone(2)
                    1 -> exitRow()
                }
                return true
            }
            // ▲ : video → top row · bottom row → Skip pill (if up) else video.
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (down) when (focusZone) {
                    0 -> enterZone(1)
                    2 -> if (skipButton.visibility == View.VISIBLE) { focusZone = 0; skipButton.requestFocus() } else exitRow()
                }
                return true
            }

            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ->
            { if (down) togglePlayPause(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { if (down) { player?.play(); bumpControls() }; return true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { if (down) { player?.pause(); bumpControls() }; return true }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { if (down) seekBy(SEEK_MS); return true }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { if (down) seekBy(-SEEK_MS); return true }

            // Back: handled HERE (the path proven on the tester's TV), consumed so
            // the framework never exits on its own. One press hides the controls —
            // whatever button is focused — by reading the ACTUAL view visibility;
            // with nothing on screen it exits.
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                if (event.action == KeyEvent.ACTION_UP) handleBack()
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** Flat k,v,k,v String[] → header map (same encoding MainActivity uses). */
    private fun headersFromIntent(): Map<String, String>? {
        val flat = intent.getStringArrayExtra(EXTRA_HEADERS) ?: return null
        if (flat.size < 2) return null
        val map = HashMap<String, String>()
        var i = 0
        while (i + 1 < flat.size) { map[flat[i]] = flat[i + 1]; i += 2 }
        return map.ifEmpty { null }
    }

    private fun subtitleConfigs(): List<MediaItem.SubtitleConfiguration>? {
        val urls = intent.getStringArrayExtra(EXTRA_SUB_URLS) ?: return null
        val langs = intent.getStringArrayExtra(EXTRA_SUB_LANGS)
        val labels = intent.getStringArrayExtra(EXTRA_SUB_LABELS)
        if (urls.isEmpty()) return null
        return urls.mapIndexed { i, u ->
            MediaItem.SubtitleConfiguration.Builder(android.net.Uri.parse(u))
                .setMimeType(if (u.lowercase().contains(".srt")) MimeTypes.APPLICATION_SUBRIP else MimeTypes.TEXT_VTT)
                .setLanguage(langs?.getOrNull(i))
                .setLabel(labels?.getOrNull(i))
                .build()
        }
    }

    private fun loadControl() = BufferPresets.loadControl(
        intent.getIntExtra(EXTRA_BUF_MIN_MS, 0),
        intent.getIntExtra(EXTRA_BUF_MAX_MS, 0),
        intent.getIntExtra(EXTRA_BUF_BYTES, 0),
        intent.getIntExtra(EXTRA_BUF_BACK_MS, 0),
        maxHeapBytes = Runtime.getRuntime().maxMemory(),
    )

    /** Hardware-first by default; explicit TV decoder choices keep their priority. */
    private fun renderersFactory(): RenderersFactory =
        when (intent.getIntExtra(EXTRA_DECODER_MODE, DECODER_MODE_HARDWARE_FIRST)) {
            DECODER_MODE_HARDWARE_FIRST -> NextRenderersFactory(this)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(true)

            DECODER_MODE_SOFTWARE_FIRST -> NextRenderersFactory(this)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
                .setEnableDecoderFallback(true)

            else -> DefaultRenderersFactory(this)
        }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "0:00"
        val total = ms / 1000
        val s = total % 60
        val m = (total / 60) % 60
        val h = total / 3600
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s)
        else String.format("%d:%02d", m, s)
    }

    private fun goImmersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
    }

    /** Hand the final position back so Flutter saves resume + Continue Watching. */
    private fun reportAndFinish(playbackError: Boolean = false) {
        if (!reported) {
            reported = true
            val p = player
            val data = Intent()
                .putExtra(RESULT_POSITION, p?.currentPosition ?: 0L)
                .putExtra(RESULT_DURATION, (p?.duration ?: 0L).coerceAtLeast(0L))
                .putExtra(RESULT_EP_INDEX, currentIndex)
                .putExtra(RESULT_PLAYBACK_ERROR, playbackError)
            setResult(RESULT_OK, data)
        }
        finish()
    }

    // Single source of truth for Back. The framework routes every Back press
    // here, so ALL of it is handled here — dispatchKeyEvent no longer intercepts
    // Back (its ACTION_UP gate lost the race to this callback on the tester's TV,
    // so Back exited even with a menu/controls open). Dismiss in priority order;
    // only the bare player (nothing on screen) actually exits.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Legacy (< API 33) path; on Android 13+ the predictive-back callback runs
        // instead. Both funnel into handleBack().
        handleBack()
    }

    // Single Back hierarchy — shared by the predictive-back callback (API 33+),
    // onBackPressed (legacy), and the Back-key path. One invocation = one step:
    // close an open menu, else hide the controls, else exit the player.
    private fun handleBack() {
        when {
            menuPanel.visibility == View.VISIBLE && avMenuActive && avStack.isNotEmpty() -> popAvOrClose()
            menuPanel.visibility == View.VISIBLE -> closeMenu()
            controls.visibility == View.VISIBLE -> {
                cancelAutoHide()
                focusZone = 0
                root.requestFocus()
                controls.visibility = View.GONE
                controlsVisible = false
            }
            else -> reportAndFinish()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !isFinishing) reportAndFinish()
        player?.pause()
    }

    override fun onDestroy() {
        if (active === this) active = null
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        try { loudness?.release() } catch (_: Exception) {}
        loudness = null
        player?.release()
        player = null
    }
}
