package com.lagradost.cloudstream3.network

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.lagradost.cloudstream3.CloudStreamApp
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * Clean-room `CloudflareKiller` — the WebView-based Cloudflare solver that lets
 * CF-gated sources (AnimePahe, …) work, mirroring CloudStream's approach.
 *
 * When a response is the Cloudflare "Just a moment…" challenge, it loads the URL
 * in a hidden WebView so Cloudflare's JS runs, harvests the `cf_clearance`
 * cookie (+ the WebView's User-Agent), then replays the request with them.
 * Solved cookies are reused per-host until they expire (a later challenge
 * re-solves). Safe by design: for any NON-challenge response it returns the
 * response untouched, and every step is guarded — a failure just yields the
 * original (blocked) response, exactly like before.
 */
class CloudflareKiller : Interceptor {
    // Kept for binary compat with plugins that read it; we manage cookies below.
    val savedCookies: MutableMap<String, Map<String, String>> = mutableMapOf()

    // Per-instance: only carries a just-solved cookie into the retry within the
    // SAME intercept() call. Cross-CALL cookie reuse is the shared WebView cookie
    // store's job (WebkitCookieJar) + the persisted CfClearance.userAgent — not
    // this map. Kept per-instance on purpose: a static cookie map would wedge a
    // rotated/expired cf_clearance until app restart. The negative cache + per-host
    // lock ARE shared (companion) — with a fresh instance per request, a
    // per-instance backoff was lost, re-popping a 30s "verifying" on every click.
    private val cookieByHost = ConcurrentHashMap<String, String>()

    /**
     * Cookie headers for [url]'s host — the Cloudflare cookies (cf_clearance, …)
     * from the shared WebView store plus the User-Agent the challenge was solved
     * with. Some plugins (e.g. FaselHD) call `CloudflareKiller().getCookieHeaders(url)`
     * to authenticate their own requests; without this method they hit
     * NoSuchMethodError in loadLinks and return zero sources ("no source playable").
     * ADDITIVE — no existing code path calls it, so it can't change current
     * behaviour for any other plugin.
     */
    fun getCookieHeaders(url: String): okhttp3.Headers {
        val builder = okhttp3.Headers.Builder()
        com.spyou.watch_app.cloudstream.CfClearance.userAgent
            ?.let { builder.add("User-Agent", it) }
        runCatching { CookieManager.getInstance().getCookie(url) }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?.let { builder.add("Cookie", it) }
        return builder.build()
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val host = request.url.host

        val response = chain.proceed(applySaved(request, host))
        if (!isCloudflareChallenge(response)) return response

        // During a provider search, NEVER pop the WebView solver (CloudStream
        // doesn't either): return the challenge unsolved so this source simply
        // yields no search hits. An already-cached clearance was applied above,
        // so CF sources solved earlier (on open/play) still search silently.
        if (com.spyou.watch_app.cloudstream.CfClearance.searchDepth.get() > 0) return response

        // The URL that actually produced the challenge — AFTER any redirects
        // (e.g. animepahe.com → animepahe.pw). The clearance cookie belongs to
        // THIS host, and we retry against THIS url so okhttp can't strip the
        // cookie across a cross-domain redirect.
        val finalUrl = response.request.url
        val finalHost = finalUrl.host
        synchronized(locks.getOrPut(finalHost) { Any() }) {
            if (!cookieByHost.containsKey(finalHost)) {
                // Negative cache: a host whose solve just failed isn't retried
                // (no solver popup) for ~30 min — just return the challenge.
                val until = failedUntil[finalHost]
                if (until != null && System.currentTimeMillis() < until) return response
                val solved = CfWebViewSolver.solve(finalUrl.toString())
                if (solved == null) {
                    failedUntil[finalHost] = System.currentTimeMillis() + 30 * 60 * 1000L
                    return response // give back the (unconsumed) challenge
                }
                failedUntil.remove(finalHost) // solved → clear any backoff
                cookieByHost[finalHost] = solved.cookie
                com.spyou.watch_app.cloudstream.CfClearance.userAgent = solved.userAgent
            }
        }
        response.close()
        val cookie = cookieByHost[finalHost]
        val retried = request.newBuilder()
            .url(finalUrl)
            .apply {
                if (cookie != null) {
                    val existing = request.header("Cookie")
                    header("Cookie", if (existing.isNullOrBlank()) cookie else "$existing; $cookie")
                }
                com.spyou.watch_app.cloudstream.CfClearance.userAgent?.let { header("User-Agent", it) }
            }
            .build()
        return chain.proceed(retried)
    }

    /** Attach the harvested clearance cookie (+ the solving UA it's bound to) for
     *  [host], if this instance solved it in-call. Only touches requests we have a
     *  cookie for, so non-CF traffic keeps its own UA. */
    private fun applySaved(request: Request, host: String): Request {
        val cookie = cookieByHost[host] ?: return request
        val b = request.newBuilder()
        val existing = request.header("Cookie")
        b.header("Cookie", if (existing.isNullOrBlank()) cookie else "$existing; $cookie")
        com.spyou.watch_app.cloudstream.CfClearance.userAgent?.let { b.header("User-Agent", it) }
        return b.build()
    }

    /** True when [response] is a Cloudflare interstitial challenge page. Only
     * peeks HTML-ish bodies so JSON/media responses are cheap. */
    private fun isCloudflareChallenge(response: Response): Boolean {
        val server = response.header("Server").orEmpty().lowercase()
        val cfMitigated = response.header("cf-mitigated") != null
        val statusFlag = response.code in intArrayOf(403, 503, 429) &&
            server.contains("cloudflare")
        val ct = response.header("Content-Type").orEmpty().lowercase()
        val htmlish = ct.contains("text/html") || ct.isEmpty()
        if (!htmlish && !cfMitigated && !statusFlag) return false
        val body = try {
            response.peekBody(20_000L).string() // peek doesn't consume the body
        } catch (_: Exception) {
            return cfMitigated || statusFlag
        }
        return cfMitigated || statusFlag ||
            body.contains("Just a moment", ignoreCase = true) ||
            body.contains("challenge-platform") ||
            body.contains("challenges.cloudflare.com") ||
            body.contains("_cf_chl_opt") ||
            body.contains("cf-browser-verification")
    }

    companion object {
        // Shared across every CloudflareKiller instance (plugins make a fresh one
        // per request). host -> epoch-ms until which we won't re-attempt a solve:
        // a CF host we can't clear (e.g. an interactive challenge) would otherwise
        // pop a 30s "verifying" on EVERY request. The per-host lock is shared too so
        // concurrent requests for one host don't each launch a solver.
        private val failedUntil = ConcurrentHashMap<String, Long>()
        private val locks = ConcurrentHashMap<String, Any>()
    }
}

/** Loads a URL in a hidden WebView and waits for Cloudflare's `cf_clearance`
 * cookie. WebView work runs on the main thread; the (background) caller blocks
 * on a latch with a timeout. */
object CfWebViewSolver {
    data class Result(val cookie: String, val userAgent: String)

    /** How long to let a self-clearing challenge finish before we start asking
     *  the page whether it actually wants a person. Long enough that a plain JS
     *  challenge is never seen by anyone. */
    private const val REVEAL_AFTER_MS = 4_000L

    /** Is there something on this page for a HUMAN to tap?
     *
     *  The cover used to come off on this timer alone, which was right for a
     *  captcha and wrong for everything else: a host that is merely slow or dead
     *  never shows a checkbox, so all the reveal did was put the raw site over
     *  the app for the rest of the wait — the user could tap through to it, and
     *  tapping extended the wait. So ask the page first, and only uncover for a
     *  challenge that is really waiting on someone. */
    private const val CHALLENGE_PROBE_JS =
        "(function(){try{" +
            "if(document.querySelector('#challenge-stage,#challenge-form," +
            "#challenge-stage input[type=checkbox],.cf-turnstile," +
            "iframe[src*=\"challenges.cloudflare.com\"]" +
            "'))return '1';" +
            "var t=(document.body&&document.body.innerText||'').toLowerCase();" +
            "return (t.indexOf('verify you are human')>-1" +
            "||t.indexOf('are you a robot')>-1" +
            "||t.indexOf('confirm you are human')>-1)?'1':'0';" +
        "}catch(e){return '0'}})()"

    /** Total wait when nobody is interacting — unchanged from before, because a
     *  provider typically spreads work over SEVERAL hosts (CNC Verse alone uses
     *  net22.cc, net52.cc, netmirror.gg, imgcdn.kim) and each one that challenges
     *  gets its own solver in turn. Making every failure wait longer multiplies
     *  straight through that list. */
    private const val SOLVE_TIMEOUT_SECONDS = 30L

    /** Extended wait, allowed ONLY once the challenge has actually been touched.
     *  Someone working through a captcha needs longer than a script; someone who
     *  isn't looking shouldn't be made to wait for one. */
    private const val INTERACTED_TIMEOUT_SECONDS = 90L

    fun solve(url: String): Result? {
        // OWNER-DISABLED 2026-10-03: visible solver off (owner request). Every
        // caller already handles null as "no clearance" (native replies
        // success(null), Dart marks the host failed and falls back, plugins
        // use their own fallback), so challenged hosts simply fail instead of
        // opening the overlay. To re-enable, delete this return.
        android.util.Log.i("CfSolver", "solve() disabled, host=${runCatching { android.net.Uri.parse(url).host }.getOrNull()}")
        return null
        // (original body below, kept for a one-undo revert)
        // One solve per host at a time: concurrent triggers (prefetch + play,
        // two mirrors at once) used to stack a "Verifying…" screen per caller,
        // each eating all touches — it read as a frozen app. The second caller
        // now waits for the first solve's result (bounded below) and shares it;
        // clearance cookies are per-host, so the shared result is the right one.
        val host = runCatching { android.net.Uri.parse(url).host }.getOrNull()
            ?: return solveNow(url)
        val mine = CompletableFuture<Result?>()
        val ongoing = inFlight.putIfAbsent(host, mine)
        if (ongoing != null) {
            return try {
                ongoing.get(SOLVE_TIMEOUT_SECONDS + 5, TimeUnit.SECONDS)
            } catch (_: Exception) {
                null
            }
        }
        return try {
            val result = solveNow(url)
            mine.complete(result)
            result
        } finally {
            inFlight.remove(host, mine)
        }
    }

    /** Solves in flight by host. Removed as each solve settles. */
    private val inFlight = ConcurrentHashMap<String, CompletableFuture<Result?>>()

    private fun solveNow(url: String): Result? {
        android.util.Log.i("CfSolver", "solve() host=${runCatching { android.net.Uri.parse(url).host }.getOrNull()}")
        // Prefer the foreground Activity: the solver WebView must be attached to
        // a real window and rendered, or Cloudflare's JS challenge never runs.
        val activity = com.spyou.watch_app.MainActivity.current?.get()
        val context = activity ?: CloudStreamApp.getContext() ?: return null
        val latch = CountDownLatch(1)
        val ref = AtomicReference<Result?>()
        val main = Handler(Looper.getMainLooper())
        val webViewRef = AtomicReference<WebView?>()
        // The WebView must render full-size for Cloudflare's JS challenge to run,
        // but we don't want the user staring at the raw challenge/ad page. So we
        // wrap it in a container and lay a branded "Verifying…" overlay ON TOP —
        // CF's JS still executes underneath; the user just sees a clean screen.
        val containerRef = AtomicReference<android.view.View?>()
        // The "Verifying…" cover, kept so it can be REMOVED if the challenge
        // turns out to need a person (see below).
        val overlayRef = AtomicReference<android.view.View?>()
        // Set once the revealed challenge is touched — see the two timeouts.
        val touched = java.util.concurrent.atomic.AtomicBoolean(false)
        // Whether the cover actually came off, i.e. there IS a challenge to work
        // through. A touch only counts while this is true.
        val revealed = java.util.concurrent.atomic.AtomicBoolean(false)
        // Shown with the challenge so a full-screen third-party page is never
        // mistaken for the app itself.
        val bannerRef = AtomicReference<android.view.View?>()

        fun captureIfReady() {
            CookieManager.getInstance().flush()
            val wv = webViewRef.get()
            val curUrl = wv?.url ?: url
            val cookieCur = CookieManager.getInstance().getCookie(curUrl)
            val cookieOrig = CookieManager.getInstance().getCookie(url)
            val cookie = listOfNotNull(cookieCur, cookieOrig)
                .firstOrNull { it.contains("cf_clearance") }
            if (cookie != null) {
                val ua = wv?.settings?.userAgentString ?: ""
                // Publish the solving UA so plain (interceptor-less) NiceHttp
                // requests carrying cf_clearance present the matching UA.
                if (ua.isNotEmpty()) com.spyou.watch_app.cloudstream.CfClearance.userAgent = ua
                if (ref.compareAndSet(null, Result(cookie, ua))) latch.countDown()
            }
        }

        val startedAt = android.os.SystemClock.uptimeMillis()
        val poll = object : Runnable {
            override fun run() {
                captureIfReady()
                if (ref.get() != null) return
                // A plain JS challenge clears itself in a second or two. Anything
                // still unsolved after this needs a PERSON — Cloudflare's
                // "Verify you are human" checkbox — and the cover we put over the
                // WebView makes that impossible: it's opaque AND swallows taps,
                // so the challenge was invisible and unclickable and every such
                // host simply failed. Take the cover away and let them tap it.
                // netmirror.gg (CNC Verse's Hotstar/Disney) is exactly this: it
                // hands an unverified client a placeholder video rather than an
                // error, so the blocked solve looked like anything but a captcha.
                if (android.os.SystemClock.uptimeMillis() - startedAt > REVEAL_AFTER_MS &&
                    overlayRef.get() != null
                ) {
                    webViewRef.get()?.evaluateJavascript(CHALLENGE_PROBE_JS) { r ->
                        // Only a page that is genuinely waiting on a person earns
                        // the reveal. Anything else keeps the cover, so a slow or
                        // dead host is never handed the screen.
                        if (r != null && r.contains("1")) {
                            overlayRef.getAndSet(null)?.let { ov ->
                                (ov.parent as? android.view.ViewGroup)?.removeView(ov)
                                revealed.set(true)
                                bannerRef.get()?.visibility = android.view.View.VISIBLE
                            }
                        }
                    }
                }
                main.postDelayed(this, 300)
            }
        }

        main.post {
            try {
                @SuppressLint("SetJavaScriptEnabled")
                val wv = WebView(context)
                webViewRef.set(wv)
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                wv.settings.databaseEnabled = true
                // Make the solver WebView's UA indistinguishable from desktop/mobile
                // Chrome. Stricter Cloudflare configs (e.g. gdflix) flag the WebView
                // tells — the "; wv" marker AND the WebView-only "Version/x.y" token,
                // which real Chrome never sends — and refuse to issue cf_clearance.
                // The cf_clearance is bound to whatever UA solved it, and we publish
                // that UA for the replay, so rewriting it here is self-consistent.
                wv.settings.userAgentString = wv.settings.userAgentString
                    .replace("; wv", "") // drop the WebView marker some CF checks flag
                    .replace(Regex("Version/\\d+\\.\\d+ "), "") // and the WebView-only token
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
                // Touching the challenge means a person is working on it, so the
                // wait may be extended past the unattended timeout.
                wv.setOnTouchListener { v, _ ->
                    // Only while a real challenge is on show. Otherwise a stray
                    // tap on a covered solve tripled the wait for nothing.
                    if (revealed.get()) touched.set(true)
                    v.performClick()
                    false
                }
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                        captureIfReady()
                    }
                }
                // Attach the WebView to the window so it actually renders —
                // required for the challenge JS to execute. Removed after solve.
                if (activity != null) {
                    try {
                        // Must be full-size + genuinely VISIBLE for Cloudflare's
                        // JS challenge to run (occluded/1px/alpha-0 WebViews don't
                        // render → no solve), so the WebView stays full-size, but
                        // a branded opaque overlay sits on top so the user sees a
                        // clean "Verifying…" screen instead of the raw CF/ad page.
                        // Solved once per host, cached (~30min) → next loads skip it.
                        val mp = android.view.ViewGroup.LayoutParams.MATCH_PARENT
                        val container = android.widget.FrameLayout(context)
                        container.addView(
                            wv,
                            android.widget.FrameLayout.LayoutParams(mp, mp),
                        )
                        val overlay = buildVerifyingOverlay(context)
                        overlayRef.set(overlay)
                        container.addView(
                            overlay,
                            android.widget.FrameLayout.LayoutParams(mp, mp),
                        )
                        // Sits above the overlay so it survives the reveal, and
                        // stays hidden until then.
                        val banner = buildChallengeBanner(context)
                        banner.visibility = android.view.View.GONE
                        bannerRef.set(banner)
                        container.addView(
                            banner,
                            android.widget.FrameLayout.LayoutParams(
                                mp,
                                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                            ),
                        )
                        containerRef.set(container)
                        activity.addContentView(
                            container,
                            android.view.ViewGroup.LayoutParams(mp, mp),
                        )
                    } catch (_: Throwable) {
                    }
                }
                wv.loadUrl(url)
                // Start polling early (CF often sets the cookie in well under a
                // second on a cached/managed challenge); a slow challenge just
                // keeps polling at 300ms up to the 30s latch, same as before.
                main.postDelayed(poll, 400)
            } catch (_: Throwable) {
                latch.countDown()
            }
        }

        val solved = try {
            latch.await(SOLVE_TIMEOUT_SECONDS, TimeUnit.SECONDS) ||
                // Still going and someone is tapping at it — give them the rest
                // of the long window rather than yanking it away mid-captcha.
                (
                    touched.get() &&
                        latch.await(
                            INTERACTED_TIMEOUT_SECONDS - SOLVE_TIMEOUT_SECONDS,
                            TimeUnit.SECONDS,
                        )
                    )
        } catch (_: InterruptedException) {
            false
        }

        // Tear the WebView down on the main thread regardless of outcome.
        main.post {
            main.removeCallbacks(poll)
            try {
                // Remove the whole container (WebView + overlay) from the window,
                // then tear the WebView down.
                containerRef.get()?.let { c ->
                    (c.parent as? android.view.ViewGroup)?.removeView(c)
                }
                webViewRef.get()?.let { w ->
                    (w.parent as? android.view.ViewGroup)?.removeView(w)
                    w.stopLoading()
                    w.destroy()
                }
            } catch (_: Throwable) {
            }
        }
        return if (solved) ref.get() else null
    }

    /// A clean app-bg screen with a small centered CHIP — "Verifying protected
    /// source…" with a spinner — laid over the solver WebView. The WebView must
    /// still render full-size behind it to satisfy Cloudflare's JS challenge, so
    /// we can't show only a chip over the live screen; but the chip tells the
    /// user exactly what's happening (a protected source being verified) instead
    /// of a bare spinner that reads like a freeze/bug. The chip only appears if
    /// the solve is slow — a quick/cached path tears down before it shows.
    /** Strip shown across the top once a challenge is revealed.
     *
     *  Without it the user is looking at a full-screen third-party page with no
     *  explanation, which is how "the app opened a website" gets reported. */
    private fun buildChallengeBanner(context: android.content.Context): android.view.View {
        val d = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val bar = android.widget.LinearLayout(context)
        bar.orientation = android.widget.LinearLayout.VERTICAL
        bar.setBackgroundColor(0xF20B0B0F.toInt())
        bar.setPadding(dp(16), dp(14), dp(16), dp(14))
        // Swallow taps: the checkbox is lower down, and a tap up here would
        // otherwise reach the page behind.
        bar.isClickable = true

        val title = android.widget.TextView(context)
        title.text = "This source needs a quick check"
        title.setTextColor(0xFFFFFFFF.toInt())
        title.textSize = 15f
        title.setTypeface(null, android.graphics.Typeface.BOLD)
        bar.addView(title)

        val body = android.widget.TextView(context)
        body.text = "Tap the box below to prove you are not a robot. " +
            "This is the source's own page, not Zangetsu."
        body.setTextColor(0xFFA7A7B2.toInt())
        body.textSize = 13f
        val blp = android.widget.LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
        )
        blp.topMargin = dp(3)
        bar.addView(body, blp)
        return bar
    }

    private fun buildVerifyingOverlay(context: android.content.Context): android.view.View {
        val d = context.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = android.widget.FrameLayout(context)
        root.setBackgroundColor(0xFF0B0B0F.toInt()) // app background
        root.isClickable = true // swallow taps so they don't reach the WebView

        val chip = android.widget.LinearLayout(context)
        chip.orientation = android.widget.LinearLayout.HORIZONTAL
        chip.gravity = android.view.Gravity.CENTER_VERTICAL
        chip.setPadding(dp(16), dp(12), dp(20), dp(12))
        val bg = android.graphics.drawable.GradientDrawable()
        bg.cornerRadius = dp(26).toFloat()
        bg.setColor(0xFF17171C.toInt()) // surface
        bg.setStroke(dp(1), 0x22FFFFFF)
        chip.background = bg

        val spinner = android.widget.ProgressBar(context)
        spinner.indeterminateTintList =
            android.content.res.ColorStateList.valueOf(0xFFFF4D57.toInt()) // accent
        val slp = android.widget.LinearLayout.LayoutParams(dp(18), dp(18))
        slp.marginEnd = dp(12)
        chip.addView(spinner, slp)

        val label = android.widget.TextView(context)
        // Worded as an instruction, not a status: the old "Verifying…." read
        // as a frozen app and viewers closed it mid-solve — which kills the
        // clearance and the playback behind it.
        label.text = "Checking source — don't close"
        label.setTextColor(0xFFFFFFFF.toInt())
        label.textSize = 14f
        chip.addView(label)

        // Don't flash the chip for a quick solve — keep it a plain app-bg blank
        // and only reveal the chip if the challenge is still running after a
        // moment. Most cached/fast paths tear down before this fires.
        chip.visibility = android.view.View.INVISIBLE
        chip.postDelayed({ chip.visibility = android.view.View.VISIBLE }, 700)

        val lp = android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
            android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
        )
        lp.gravity = android.view.Gravity.CENTER
        root.addView(chip, lp)
        return root
    }
}
