/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Adapted from the Aniyomi project (https://github.com/aniyomiorg/aniyomi)
 * for host-side MethodChannel bridging in the Zangetsu app.
 */
package com.spyou.watch_app.aniyomi

import android.content.Context
import android.content.Intent
import com.spyou.watch_app.SourcePrefsCodec
import eu.kanade.tachiyomi.animesource.AnimeCatalogueSource
import eu.kanade.tachiyomi.animesource.ConfigurableAnimeSource
import eu.kanade.tachiyomi.animesource.model.AnimeFilterList
import eu.kanade.tachiyomi.animesource.model.SAnimeImpl
import eu.kanade.tachiyomi.animesource.model.SEpisodeImpl
import eu.kanade.tachiyomi.animesource.online.AnimeHttpSource
import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.network.interceptor.CloudflareRequiredException
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Exposes Aniyomi extension capabilities to the Flutter layer via a
 * [MethodChannel] named "zangetsu/aniyomi".
 *
 * The bridge is intentionally stateless — all mutable state lives in
 * [AniyomiSourceManager] and [AniyomiExtensionLoader]. Handlers that need
 * network work should be extended in later tasks using [scope] for suspend
 * coroutines; the current operations (load/list) are synchronous.
 *
 * Supported methods:
 *  - `installExtension` {apkPath:String} — loads and registers an APK.
 *  - `loadInstalled`    {dir:String}     — loads every `*.apk` in a directory.
 *  - `listSources`                       — returns a JSON array string.
 *
 * Later tasks add data methods (`getPopular`, `getDetails`, etc.) inside the
 * same `when(call.method)` block to keep the handler extensible.
 */
class AniyomiBridge(
    private val context: Context,
    @Suppress("unused") private val scope: CoroutineScope,
) {

    /**
     * Attaches this bridge to [channel] by registering a [MethodChannel.MethodCallHandler].
     *
     * Call this once from [MainActivity.configureFlutterEngine].
     */
    fun attach(channel: MethodChannel) {
        channel.setMethodCallHandler { call, result ->
            when (call.method) {

                // Load a single extension APK and register it. DexClassLoad +
                // instantiate is heavy — run OFF the platform main thread (calling
                // it inline froze the splash on boot re-load).
                "installExtension" -> {
                    val apkPath = call.argument<String>("apkPath")
                    if (apkPath.isNullOrBlank()) {
                        result.error("BAD_ARGS", "apkPath is required", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        val r = AniyomiExtensionLoader.load(context, File(apkPath))
                        r.getOrNull()?.let(AniyomiSourceManager::register)
                        withContext(Dispatchers.Main) {
                            r.fold(
                                onSuccess = { result.success(true) },
                                onFailure = { err ->
                                    // newInstance() wraps the real failure in an
                                    // InvocationTargetException (message == null) and the
                                    // cause was being dropped, so every load failure showed
                                    // "No source loaded" with nothing to go on. Log the full
                                    // chain and surface the root cause.
                                    android.util.Log.e("AniyomiLoad", "extension load failed", err)
                                    val root = generateSequence(err as Throwable) { it.cause }.last()
                                    val detail = "${err::class.java.simpleName}: ${err.message}" +
                                        if (root !== err) {
                                            " | cause: ${root::class.java.simpleName}: ${root.message}"
                                        } else ""
                                    result.error("LOAD", detail, null)
                                },
                            )
                        }
                    }
                }

                // Load every *.apk found in a directory and register them. Runs on
                // IO — this is what the guarded boot re-load calls, and doing the
                // DexClassLoads on the main thread froze the splash.
                "loadInstalled" -> {
                    val dir = call.argument<String>("dir")
                    if (dir.isNullOrBlank()) {
                        result.error("BAD_ARGS", "dir is required", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        File(dir).listFiles { f -> f.extension == "apk" }?.forEach { apkFile ->
                            AniyomiExtensionLoader.load(context, apkFile)
                                .getOrNull()
                                ?.let(AniyomiSourceManager::register)
                        }
                        withContext(Dispatchers.Main) { result.success(true) }
                    }
                }

                // Return a JSON array of all registered sources.
                "listSources" -> result.success(sourcesJson())

                // ------------------------------------------------------------------
                // Data methods — each runs on the bridge IO scope and marshals the
                // result back to the platform main thread before calling result.*.
                // ------------------------------------------------------------------

                "getPopular" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val page = call.argument<Int>("page") ?: 1
                    val src = AniyomiSourceManager.get(sourceId) as? AnimeCatalogueSource ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found or not a catalogue source", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val page2 = src.getPopularAnime(page)
                            AniyomiJson.animesToJson(page2.animes)
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "POPULAR") } },
                        )
                    }
                }

                "getLatest" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val page = call.argument<Int>("page") ?: 1
                    val src = AniyomiSourceManager.get(sourceId) as? AnimeCatalogueSource ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found or not a catalogue source", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val page2 = src.getLatestUpdates(page)
                            AniyomiJson.animesToJson(page2.animes)
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "LATEST") } },
                        )
                    }
                }

                "getFilterList" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val src = AniyomiSourceManager.get(sourceId) as? AnimeCatalogueSource ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found or not a catalogue source", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            AniyomiFilterJson.filterListToJson(src.getFilterList())
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "FILTERS") } },
                        )
                    }
                }

                "search" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val query = call.argument<String>("query") ?: ""
                    val page = call.argument<Int>("page") ?: 1
                    val filtersJson = call.argument<String>("filters")
                    val src = AniyomiSourceManager.get(sourceId) as? AnimeCatalogueSource ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found or not a catalogue source", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val fl = if (!filtersJson.isNullOrBlank()) {
                                src.getFilterList().also { AniyomiFilterJson.applySelectionJson(it, filtersJson) }
                            } else {
                                AnimeFilterList()
                            }
                            val page2 = src.getSearchAnime(page, query, fl)
                            AniyomiJson.animesToJson(page2.animes)
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "SEARCH") } },
                        )
                    }
                }

                "getDetails" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val url = call.argument<String>("url") ?: run {
                        result.error("BAD_ARGS", "url required", null); return@setMethodCallHandler
                    }
                    val src = AniyomiSourceManager.get(sourceId) ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val stub = SAnimeImpl().apply { this.url = url }
                            val details = src.getAnimeDetails(stub)
                            // getAnimeDetails() usually returns metadata without
                            // re-setting url — carry the known input url so Dart
                            // keeps a valid detail/episode key.
                            AniyomiJson.animeToJson(details).apply { put("url", url) }.toString()
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "DETAILS") } },
                        )
                    }
                }

                "getEpisodes" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val url = call.argument<String>("url") ?: run {
                        result.error("BAD_ARGS", "url required", null); return@setMethodCallHandler
                    }
                    val src = AniyomiSourceManager.get(sourceId) ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val stub = SAnimeImpl().apply { this.url = url }
                            val episodes = src.getEpisodeList(stub)
                            AniyomiJson.episodesToJson(episodes)
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "EPISODES") } },
                        )
                    }
                }

                // extensions-lib 17: ask a source what changed for one anime and forward
                // the answer to Dart. Kept separate from "getEpisodes" so the two calls stay
                // distinguishable. The cost: the v17 signature takes the existing episode
                // list as a parameter, so the host has to read it first — and for most
                // sources that read is the whole-page fetch, so this path costs one extra
                // list fetch on top of whatever the source does internally.
                "getAnimeEpisodeUpdate" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val url = call.argument<String>("url") ?: run {
                        result.error("BAD_ARGS", "url required", null); return@setMethodCallHandler
                    }
                    val fetchDetails = call.argument<Boolean>("fetchDetails") ?: true
                    val fetchEpisodes = call.argument<Boolean>("fetchEpisodes") ?: true
                    val src = AniyomiSourceManager.get(sourceId) ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val stub = SAnimeImpl().apply { this.url = url }
                            // Reading the *existing* list is best-effort: many sources throw
                            // from getEpisodeList, and failing the whole update because the
                            // prior state was unreadable would be the wrong trade.
                            val existing = runCatching { src.getEpisodeList(stub) }.getOrDefault(emptyList())
                            // Sources that do not implement the v17 method fall back to the v16
                            // default, which throws. That is an optional capability probe, not a
                            // fault, so degrade quietly to the same empty update a source with
                            // nothing to report produces. Only UnsupportedOperationException is
                            // absorbed: a real network failure still surfaces as EPISODE_UPDATE.
                            try {
                                AniyomiJson.episodeUpdateToJson(
                                    src.getAnimeEpisodeUpdate(stub, existing, fetchDetails, fetchEpisodes),
                                )
                            } catch (_: UnsupportedOperationException) {
                                AniyomiJson.episodesToJson(emptyList())
                            }
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "EPISODE_UPDATE") } },
                        )
                    }
                }

                // extensions-lib 17: the season-list counterpart of the above.
                "getAnimeSeasonUpdate" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val url = call.argument<String>("url") ?: run {
                        result.error("BAD_ARGS", "url required", null); return@setMethodCallHandler
                    }
                    val fetchDetails = call.argument<Boolean>("fetchDetails") ?: true
                    val fetchSeasons = call.argument<Boolean>("fetchSeasons") ?: true
                    val src = AniyomiSourceManager.get(sourceId) ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val stub = SAnimeImpl().apply { this.url = url }
                            val existing = runCatching { src.getSeasonList(stub) }.getOrDefault(listOf(stub))
                            // As above: the v16 default throws for a source with no v17 season
                            // update, and that quietens to an empty season list rather than an
                            // error. Anything else still surfaces as SEASON_UPDATE.
                            try {
                                AniyomiJson.seasonUpdateToJson(
                                    src.getAnimeSeasonUpdate(stub, existing, fetchDetails, fetchSeasons),
                                )
                            } catch (_: UnsupportedOperationException) {
                                AniyomiJson.animesToJson(emptyList())
                            }
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "SEASON_UPDATE") } },
                        )
                    }
                }

                "getVideoList" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    // Dart sends this under the key "url" (see AniyomiProvider.getVideoSources).
                    val episodeUrl = call.argument<String>("url") ?: run {
                        result.error("BAD_ARGS", "url required", null); return@setMethodCallHandler
                    }
                    val src = AniyomiSourceManager.get(sourceId) ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val ep = SEpisodeImpl().apply {
                                this.url = episodeUrl
                                this.name = ""
                            }
                            // Legacy path first — covers sources like animeixin that override
                            // getVideoList(episode) / fetchVideoList. runCatching absorbs any
                            // IllegalStateException from sources that don't implement this path.
                            val legacyVideos = runCatching { src.getVideoList(ep) }.getOrElse { emptyList() }
                            val videos = if (legacyVideos.isNotEmpty()) {
                                legacyVideos
                            } else {
                                // Hoster path (lib-16): getHosterList → flatMap getVideoList(hoster).
                                // runCatching absorbs IllegalStateException from sources that
                                // don't implement this path either.
                                runCatching {
                                    val hosters = src.getHosterList(ep)
                                    hosters.flatMap { hoster ->
                                        runCatching { src.getVideoList(hoster) }.getOrElse { emptyList() }
                                    }
                                }.getOrElse { emptyList() }
                            }
                            // ONE clean entry per quality: the DIRECT url (mpv streams straight
                            // from the CDN with the video's headers — fast, native-like, exactly
                            // like Aniyomi), PLUS a hidden `proxyUrl`. The player uses the direct
                            // url first and only swaps to `proxyUrl` if a Cloudflare-walled stream
                            // won't start — no duplicate "· proxy" entries in the picker.
                            val arr = JSONArray()
                            videos.forEach { v ->
                                val rawUrl = v.videoUrl ?: v.url
                                val headersMap: Map<String, String> = buildMap {
                                    v.headers?.let { h ->
                                        for (i in 0 until h.size) put(h.name(i), h.value(i))
                                    }
                                }
                                val proxiedUrl = AniyomiVideoProxy.proxyUrl(sourceId, rawUrl, headersMap)
                                val json = AniyomiJson.videoToJson(v) // direct url + headers
                                json.put("proxyUrl", proxiedUrl)
                                arr.put(json)
                            }
                            arr.toString()
                        }.fold(
                            onSuccess = { json -> withContext(Dispatchers.Main) { result.success(json) } },
                            onFailure = { err -> withContext(Dispatchers.Main) { result.failWith(err, "VIDEO_LIST") } },
                        )
                    }
                }

                // Fetch image bytes through the source's own OkHttpClient so that
                // any CF session cookies / custom headers carried by that client are
                // used — Flutter's cached_network_image cannot pass Cloudflare.
                // Flutter receives a Uint8List; on failure result.error is called.
                "getImage" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null); return@setMethodCallHandler
                    }).toLong()
                    val url = call.argument<String>("url") ?: run {
                        result.error("BAD_ARGS", "url required", null); return@setMethodCallHandler
                    }
                    val src = AniyomiSourceManager.get(sourceId) as? AnimeHttpSource ?: run {
                        result.error("NO_SOURCE", "Source $sourceId not found or not an HTTP source", null)
                        return@setMethodCallHandler
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            val response = src.client.newCall(GET(url, src.headers)).execute()
                            val bytes = response.body?.bytes()
                                ?: throw IllegalStateException("empty body for $url")
                            bytes
                        }.fold(
                            onSuccess = { bytes ->
                                withContext(Dispatchers.Main) { result.success(bytes) }
                            },
                            onFailure = { err ->
                                withContext(Dispatchers.Main) {
                                    result.error("IMG_FETCH", "${err::class.java.simpleName}: ${err.message}", null)
                                }
                            },
                        )
                    }
                }

                "hasSourceSettings" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null)
                        return@setMethodCallHandler
                    }).toLong()
                    result.success(AniyomiSourceManager.get(sourceId) is ConfigurableAnimeSource)
                }

                "openSourceSettings" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null)
                        return@setMethodCallHandler
                    }).toLong()
                    val src = AniyomiSourceManager.get(sourceId)
                    if (src == null) {
                        result.error("NO_SOURCE", "Source $sourceId not found", null)
                        return@setMethodCallHandler
                    }
                    if (src !is ConfigurableAnimeSource) {
                        result.error("NO_SETTINGS", "Source $sourceId is not configurable", null)
                        return@setMethodCallHandler
                    }
                    val intent = Intent(context, AniyomiSettingsActivity::class.java)
                        .putExtra(AniyomiSettingsActivity.EXTRA_SOURCE_ID, sourceId)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    result.success(true)
                }

                // Read the source's own settings as plain data so the app can
                // draw them itself, instead of sending the user out to the
                // native screen (a second task in recents, themed by Android).
                "readSourceSettings" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null)
                        return@setMethodCallHandler
                    }).toLong()
                    val src = AniyomiSourceManager.get(sourceId)
                    if (src !is ConfigurableAnimeSource) {
                        result.success(emptyList<Map<String, Any?>>())
                        return@setMethodCallHandler
                    }
                    try {
                        val screen = SourcePrefsCodec.buildScreen(context, sourceId) {
                            src.setupPreferenceScreen(it)
                        }
                        result.success(SourcePrefsCodec.read(screen))
                    } catch (e: Throwable) {
                        // A source that throws while declaring its settings can
                        // still be shown by the native screen, so report the
                        // failure rather than pretending it has none.
                        result.error("PREFS_READ", "${e::class.java.simpleName}: ${e.message}", null)
                    }
                }

                "writeSourceSetting" -> {
                    val sourceId = (call.argument<Number>("sourceId") ?: run {
                        result.error("BAD_ARGS", "sourceId required", null)
                        return@setMethodCallHandler
                    }).toLong()
                    val key = call.argument<String>("key") ?: run {
                        result.error("BAD_ARGS", "key required", null)
                        return@setMethodCallHandler
                    }
                    val src = AniyomiSourceManager.get(sourceId)
                    if (src !is ConfigurableAnimeSource) {
                        result.success(false)
                        return@setMethodCallHandler
                    }
                    try {
                        val screen = SourcePrefsCodec.buildScreen(context, sourceId) {
                            src.setupPreferenceScreen(it)
                        }
                        result.success(
                            SourcePrefsCodec.write(screen, key, call.argument<Any>("value")),
                        )
                    } catch (e: Throwable) {
                        result.error("PREFS_WRITE", "${e::class.java.simpleName}: ${e.message}", null)
                    }
                }

                else -> result.notImplemented()
            }
        }
    }

    /**
     * Serialises all registered sources as a JSON array string.
     *
     * Each element is a JSON object with:
     *   id      — [AnimeSource.id] (Long, serialised as a JSON number)
     *   name    — [AnimeSource.name]
     *   lang    — [AnimeSource.lang]
     *   nsfw        — from the owning [LoadedExtension.nsfw]
     *   pkg         — from the owning [LoadedExtension.pkg]
     *   version     — from the owning [LoadedExtension.versionName]
     *   versionCode — from the owning [LoadedExtension.versionCode]
     *   baseUrl     — [AnimeHttpSource.baseUrl] when the source is an HTTP source; "" otherwise
     */
    private fun sourcesJson(): String {
        val arr = JSONArray()
        AniyomiSourceManager.installed().forEach { ext ->
            ext.sources.forEach { src ->
                arr.put(
                    JSONObject().apply {
                        put("id", src.id)
                        put("name", src.name)
                        put("lang", src.lang)
                        put("nsfw", ext.nsfw)
                        put("pkg", ext.pkg)
                        put("version", ext.versionName)
                        put("versionCode", ext.versionCode)
                        put("baseUrl", (src as? AnimeHttpSource)?.baseUrl ?: "")
                        // Source-level headers (Referer/User-Agent) needed by the Dart layer
                        // to fetch thumbnail images without 403 errors on strict image hosts.
                        put(
                            "headers",
                            (src as? AnimeHttpSource)
                                ?.let { AniyomiJson.headersToJsonObject(it.headers) }
                                ?: JSONObject(),
                        )
                    },
                )
            }
        }
        return arr.toString()
    }
}

/**
 * Reports [err] to Dart, mapping a Cloudflare challenge to a distinct
 * "CLOUDFLARE" code that carries the URL to solve.
 *
 * The headless WebView solver clears the automatic challenges, but Cloudflare
 * serves an interactive one (Turnstile) to networks it doesn't trust — and no
 * hidden WebView can click that. When it gives up, [CloudflareRequiredException]
 * comes back up the chain and the app can offer a visible solve instead of
 * showing an empty source. Anime and manga extensions share one HTTP stack, so
 * this mirrors what MihonBridge already does for manga.
 *
 * Walks the cause chain: sources and the suspend adapter both wrap exceptions.
 */
private fun MethodChannel.Result.failWith(err: Throwable, code: String) {
    val cf = generateSequence(err) { it.cause }
        .filterIsInstance<CloudflareRequiredException>()
        .firstOrNull()
    if (cf != null) {
        error("CLOUDFLARE", cf.url, null)
    } else {
        error(code, "${err::class.java.simpleName}: ${err.message}", null)
    }
}
