package com.spyou.watch_app

import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.storage.StorageManager
import android.speech.RecognizerIntent
import android.util.Log
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.spyou.watch_app.aniyomi.AniyomiBridge
import com.spyou.watch_app.cast.CastManager
import com.spyou.watch_app.cloudstream.CsPluginLoaderActivity
import com.spyou.watch_app.cloudstream.PluginHost
import com.spyou.watch_app.cloudstream.RepoManager
import com.spyou.watch_app.cloudstream.SubscriptionWorker
import com.spyou.watch_app.mihon.MihonBridge
import com.spyou.watch_app.tiles.TileBridge
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.appcompat.app.AppCompatActivity
import io.flutter.embedding.android.FlutterEngineConfigurator
import io.flutter.embedding.android.FlutterFragment
import io.flutter.embedding.engine.plugins.util.GeneratedPluginRegister
import java.util.concurrent.TimeUnit
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/// Hosts the "zangetsu/seek_preview" channel, which decodes a single video
/// frame at a given timestamp via [MediaMetadataRetriever] — the same technique
/// native players (CloudStream etc.) use for seek-bar thumbnails. No second
/// player, no video surface: just URL + time -> JPEG bytes.
class MainActivity : AppCompatActivity(), FlutterEngineConfigurator {

    // Flutter runs in a fragment rather than us extending FlutterActivity,
    // because this activity has to BE an androidx AppCompatActivity.
    //
    // CloudStream plugins are handed a Context in `load()`, cast it to
    // AppCompatActivity, keep it in a static field and later show their own
    // dialogs on it — CNC Verse's Cloudflare screen works exactly that way, and
    // so do its subscription/Telegram popups. FlutterActivity descends from
    // android.app.Activity, so that cast could never succeed; we used to load
    // such plugins against a throwaway AppCompatActivity that finished
    // immediately, which left them holding a DEAD activity. Every dialog they
    // tried to show then died on `BadTokenException` and was swallowed, so the
    // Cloudflare step silently never ran and the source served a placeholder
    // stream instead of the real one. CloudStream itself is plain
    // `MainActivity : AppCompatActivity()`, which is why it never had this
    // problem. Hosting Flutter in a fragment gets us the same thing: one real,
    // long-lived AppCompatActivity that plugins can safely hold on to.
    private lateinit var flutterFragment: FlutterFragment
    private val channelName = "zangetsu/seek_preview"
    private val executor = Executors.newSingleThreadExecutor()

    // CloudStream bridge. Mutating ops (install/load/delete repos) run on a
    // single thread [csExecutor] so plugin (un)registration stays serialized
    // and race-free. Read ops (getHome/search/load/loadLinks) run on a small
    // pool [csReadPool] so a slow or stale source request can't block the
    // active source's load — switching sources stays responsive.
    private val csExecutor = Executors.newSingleThreadExecutor()
    // Sized for search fan-out: a query hits every installed source at once, so
    // a few extra workers let results come back without one slow source choking
    // the rest (each call is also time-capped in PluginHost).
    private val csReadPool = Executors.newFixedThreadPool(8)
    // Playback's own lane: a stuck browse/search must never starve pressing
    // play. Only the fast (first-link) resolve runs here — same call, same
    // caps, just never queued behind the shared pool.
    private val csPlayPool = Executors.newFixedThreadPool(2)
    private val repo: RepoManager by lazy { RepoManager(applicationContext) }
    private val host: PluginHost by lazy { PluginHost(applicationContext) }

    /// Icon id (as Dart knows it) → the activity-alias that carries that icon.
    /// Keys are persisted in prefs and the alias names appear on users' home
    /// screens, so neither side may be renamed once shipped.
    private val ICON_ALIASES = linkedMapOf(
        "crescent" to "com.spyou.watch_app.MainActivityCrescent",
        "default" to "com.spyou.watch_app.MainActivityDefault",
        "classic" to "com.spyou.watch_app.MainActivityClassic",
    )

    /// The one alias carrying android:enabled="true". Named because two places
    /// below have to reason about "enabled because the manifest says so"
    /// separately from "enabled because the user chose it".
    private val MANIFEST_ICON = "crescent"

    /// The enabled alias, or "crescent" when nothing has been set. A component
    /// left at COMPONENT_ENABLED_STATE_DEFAULT takes the manifest's
    /// android:enabled, which is true only for the Crescent alias — so that is
    /// what an untouched install is really showing. Must match
    /// `AppIconService.defaultId` and the manifest.
    private fun currentIconAlias(): String {
        val pm = packageManager
        for ((id, cls) in ICON_ALIASES) {
            val state = pm.getComponentEnabledSetting(ComponentName(this, cls))
            if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED) return id
        }
        return "crescent"
    }

    /// Enables [id]'s alias and disables the others.
    ///
    /// Order matters: enable first, then disable. Disabling the live launcher
    /// component before another exists can leave the app with no launcher entry
    /// at all if the process is killed in between — which Android often does
    /// right here, since removing the running component tears down the task.
    /// DONT_KILL_APP asks it not to; launchers vary in whether they honour it,
    /// so the UI warns that the app may close.
    private fun applyIconAlias(id: String) {
        val pm = packageManager
        val target = ICON_ALIASES[id] ?: return
        pm.setComponentEnabledSetting(
            ComponentName(this, target),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP,
        )
        for ((other, cls) in ICON_ALIASES) {
            if (other == id) continue
            pm.setComponentEnabledSetting(
                ComponentName(this, cls),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    }

    /// Collapses the home screen back to ONE icon after an update that adds an
    /// alias.
    ///
    /// An alias the user explicitly picked stays explicitly enabled across an
    /// app update — that persistence is the entire reason the icon switcher
    /// works at all. A newly shipped alias, though, arrives untouched, so it
    /// takes the manifest's android:enabled, which is true for [MANIFEST_ICON].
    /// Both carry a LAUNCHER intent-filter, so on the update that introduced
    /// the crescent, everyone who had ever picked an icon got TWO Zangetsu
    /// entries on their home screen. (Verified on device: component overrides
    /// survive an upgrade, and an untouched alias is live from the manifest.)
    ///
    /// The one we keep is the one they just tapped. That is not only the least
    /// surprising answer, it is the only one that cannot kill the app —
    /// disabling the component a task was launched from tears that task down,
    /// and DONT_KILL_APP is a request launchers are free to ignore.
    ///
    /// Nothing happens unless there really are two, so a fresh install and an
    /// already-settled one both fall straight through. A launch that did not
    /// come from an icon (a share, a notification) leaves it for next time
    /// rather than guessing.
    private fun reconcileIconAliases() {
        val pm = packageManager
        val live = ICON_ALIASES.filter { (id, cls) ->
            when (pm.getComponentEnabledSetting(ComponentName(this, cls))) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> id == MANIFEST_ICON
                else -> false
            }
        }
        if (live.size < 2) return
        val launched = intent?.component?.className ?: return
        val keep = live.entries.firstOrNull { it.value == launched } ?: return
        Log.i(TAG, "Two launcher icons after update; keeping ${keep.key}")
        applyIconAlias(keep.key)
    }

    companion object {
        private const val TAG = "SeekPreview"
        private const val EXT_PLAYER_REQUEST = 7001
        private const val TAG_FLUTTER = "flutter_fragment"
        private const val NORMAL_THEME_META_DATA_KEY =
            "io.flutter.embedding.android.NormalTheme"
        private const val TV_PLAYER_REQUEST = 7002
        private const val VOICE_SEARCH_REQUEST = 7003
        // Bidirectional bridge to the native TV player: TvPlayerActivity invokes
        // resolveEpisode / saveProgress on Dart through this. Same process + a
        // live FlutterEngine (MainActivity is only paused while the player is up),
        // so a static handle is safe. Cleared in onDestroy.
        @JvmStatic
        var tvBridge: MethodChannel? = null

        /** The foreground activity, so the CloudStream CloudflareKiller can
         * attach its solver WebView to a real window (JS only runs when the
         * WebView renders). Weak ref; null while backgrounded. */
        @Volatile
        var current: java.lang.ref.WeakReference<android.app.Activity>? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // FlutterActivity did this for us, before its own super.onCreate: swap the
        // splash LaunchTheme for NormalTheme once the process is up, so the window
        // background behind Flutter is the flat app colour rather than the splash
        // drawable. Without it we'd sit on LaunchTheme forever and the splash art
        // would show through wherever Flutter doesn't paint (transitions, PiP).
        // The manifest meta-data is unchanged; we just have to read it ourselves.
        switchLaunchThemeForNormalTheme()
        super.onCreate(savedInstanceState)
        reconcileIconAliases()
        setContentView(R.layout.activity_main)
        // Survives configuration changes / process death: re-attaching a second
        // fragment would spin up a second FlutterEngine and run the app twice.
        val existing =
            supportFragmentManager.findFragmentByTag(TAG_FLUTTER) as? FlutterFragment
        flutterFragment = existing ?: FlutterFragment.withNewEngine()
            .shouldAttachEngineToActivity(true)
            // Flutter owns the back gesture, same as under FlutterActivity.
            .shouldAutomaticallyHandleOnBackPressed(true)
            .build<FlutterFragment>()
            .also {
                supportFragmentManager.beginTransaction()
                    .add(R.id.flutter_container, it, TAG_FLUTTER)
                    .commit()
            }
    }

    /** Mirrors FlutterActivity's own launch->normal theme swap, reading the same
     *  `io.flutter.embedding.android.NormalTheme` manifest meta-data. */
    private fun switchLaunchThemeForNormalTheme() {
        try {
            val activityInfo = packageManager.getActivityInfo(
                componentName,
                android.content.pm.PackageManager.GET_META_DATA,
            )
            val normalThemeRID =
                activityInfo.metaData?.getInt(NORMAL_THEME_META_DATA_KEY, -1) ?: -1
            if (normalThemeRID != -1) setTheme(normalThemeRID)
        } catch (e: Exception) {
            Log.w(TAG, "could not read NormalTheme meta-data: ${e.message}")
        }
    }

    // ── FlutterFragment lifecycle forwarding ────────────────────────────────
    // FlutterActivity did all of this internally. A fragment host has to pass
    // the callbacks down by hand, or Flutter misses them (PiP on home press,
    // permission results, plugin Activity results, low-memory trims).

    override fun onPostResume() {
        super.onPostResume()
        flutterFragment.onPostResume()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        flutterFragment.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        flutterFragment.onTrimMemory(level)
    }

    override fun onResume() {
        super.onResume()
        playerOrientationObserver?.enable()
        current = java.lang.ref.WeakReference(this)
        // CloudStream plugins that store their own settings grab a per-plugin
        // SharedPreferences via CommonActivity.getActivity().getSharedPreferences(name)
        // at load time (e.g. PlayzTV/Crickyfy live-TV category). Register the host
        // Activity here — before extensions load off the splash path — so that
        // returns a real Activity instead of null; otherwise those prefs are never
        // read back and the selection reverts on restart.
        com.lagradost.cloudstream3.CommonActivity.setActivityInstance(this)
    }

    override fun onPause() {
        playerOrientationObserver?.disable()
        phoneVoiceSearch?.cancelActive()
        if (current?.get() === this) current = null
        // Fail safe: never leave the volume rocker hijacked for an app that
        // isn't in front. Dart re-enables it when the reader resumes.
        volumeKeyPaging = false
        super.onPause()
    }

    // ── Volume-key paging (manga reader) ──────────────────────────────────
    // Android handles the volume keys at the window level, above the Flutter
    // view, so a Dart-side key handler never sees them — it has to be caught
    // here. OFF unless the reader explicitly turns it on, and forced off again
    // in onPause, because the failure mode (volume rocker does nothing, app-
    // wide, with no clue why) is far worse than the feature is valuable.
    private var volumeKeyPaging = false
    private var volumeKeyChannel: MethodChannel? = null

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (volumeKeyPaging) {
            val code = event.keyCode
            if (code == android.view.KeyEvent.KEYCODE_VOLUME_UP ||
                code == android.view.KeyEvent.KEYCODE_VOLUME_DOWN
            ) {
                // Act on the down (and its auto-repeat, so holding pages on),
                // and swallow the matching up so the system sees a clean pair
                // and never flashes its volume panel.
                if (event.action == android.view.KeyEvent.ACTION_DOWN) {
                    val dir = if (code == android.view.KeyEvent.KEYCODE_VOLUME_UP) {
                        "up"
                    } else {
                        "down"
                    }
                    volumeKeyChannel?.invokeMethod("volumeKey", dir)
                }
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // A "new episode" notification tapped while the app is already running:
    // forward its payload to Dart so it opens that show's Detail.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        flutterFragment.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra("notif_payload")?.let { payload ->
            notifChannel?.invokeMethod("openShow", payload)
            intent.removeExtra("notif_payload")
        }
    }

    // The in-flight external-player launch, completed in onActivityResult so the
    // Dart side learns whether the player actually played anything (for the
    // auto-fallback to the built-in player).
    private var pendingPlayerResult: MethodChannel.Result? = null
    // In-flight native TV-player launch, completed in onActivityResult with the
    // final position so Dart saves resume + Continue Watching.
    private var pendingTvResult: MethodChannel.Result? = null
    // In-flight TV voice-search dialog, completed in onActivityResult with the
    // recognised phrase (TV search fills the field + runs the query with it).
    private var pendingVoiceResult: MethodChannel.Result? = null
    private var phoneVoiceSearch: PhoneVoiceSearchBridge? = null

    // Cached retriever so rapid scrubbing on one title doesn't re-open the
    // source for every frame (setDataSource is expensive, esp. over network).
    private var retriever: MediaMetadataRetriever? = null
    private var currentUrl: String? = null

    // Auto Picture-in-Picture: armed by Dart while a video is on screen. On
    // Android 12+ we use the seamless setAutoEnterEnabled; on 8.0–11 (no
    // auto-enter API) we trigger PiP from onUserLeaveHint (home press).
    private var autoPipEnabled = false

    // Window actions, aspect ratio and enter animation — see PipController.
    private val pip by lazy { PipController(this) }

    // Set in configureFlutterEngine; used by onNewIntent to hand a tapped
    // "new episode" notification to Dart while the app is already running.
    private var notifChannel: MethodChannel? = null

    // Cast: wired in configureFlutterEngine; released in onDestroy.
    private var castManager: CastManager? = null

    // Stored so RepositoryManager (mega-repo plugins) can push added repos to
    // Dart. Set in configureFlutterEngine.
    private var csChannel: MethodChannel? = null

    /**
     * Scope for an extension bridge: a failure inside third-party extension code
     * must not take the app down with it.
     *
     * MANGA Plus proved this the hard way — its static initialiser threw
     * `ExceptionInInitializerError` while resolving a class we didn't ship, on a
     * coroutine our `runCatching` never saw, and the default handler killed the
     * process mid-search. Extensions are arbitrary third-party code; any of them
     * can reference something we don't have.
     *
     * SupervisorJob so one failed call doesn't cancel the rest of the bridge, and
     * a handler so an escaped throwable is logged instead of fatal. The call that
     * failed this way never delivers its result — that request just hangs rather
     * than answering — but one stuck source in a fan-out beats the whole app
     * dying, and the log says which one it was.
     */
    private fun extensionScope(tag: String): CoroutineScope = CoroutineScope(
        SupervisorJob() +
                Dispatchers.IO +
                CoroutineExceptionHandler { _, e ->
                    Log.e(TAG, "uncaught in $tag extension: ${e::class.java.name}: ${e.message}", e)
                },
    )

    /** Required by [FlutterEngineConfigurator]. Everything we register in
     *  [configureFlutterEngine] is torn down in onDestroy already, and the engine
     *  dies with this activity, so there is nothing extra to undo here. */
    override fun cleanUpFlutterEngine(flutterEngine: FlutterEngine) {}

    private var playerOrientationObserver: PhoneOrientationObserver? = null
    private var discordPresence: DiscordPresenceBridge? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        // FlutterActivity.configureFlutterEngine did this for us; FlutterFragment
        // only forwards to the host, and FlutterEngine registers nothing on its
        // own, so without this line NO plugin (shared_preferences, path_provider,
        // media_kit …) would be attached and the app would come up dead.
        GeneratedPluginRegister.registerGeneratedPlugins(flutterEngine)
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/player_orientation")
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                    playerOrientationObserver?.disable()
                    playerOrientationObserver = PhoneOrientationObserver(this@MainActivity) {
                        events.success(it)
                    }.also { it.enable() }
                }
                override fun onCancel(arguments: Any?) {
                    playerOrientationObserver?.disable()
                    playerOrientationObserver = null
                }
            })
        discordPresence = DiscordPresenceBridge(this, flutterEngine.dartExecutor.binaryMessenger)

        // Bridge mega-repo plugins → our repo list: when a plugin's load() calls
        // RepositoryManager.addRepository(...), forward each URL to Dart so it
        // goes through the real CloudStreamManager.addRepo(). Purely additive.
        com.lagradost.cloudstream3.plugins.RepositoryManager.onRepoAdded = { url ->
            runOnUiThread { csChannel?.invokeMethod("onRepoAdded", url) }
        }

        // Same idea for a Cloudflare challenge PluginHost's shared-client
        // interceptor sees (applyBaseClient): forward host + best-effort
        // source id so Dart can flag it in the same CfSolveNeeded latch the
        // JS-provider path uses. Static wiring — doesn't force `host` (the
        // lazy PluginHost) to construct here.
        PluginHost.onCfChallenge = { chHost, chUrl, sourceId ->
            runOnUiThread {
                csChannel?.invokeMethod(
                    "onCfChallenge",
                    mapOf("host" to chHost, "url" to chUrl, "sourceId" to sourceId),
                )
            }
        }

        // TV ExoPlayer spike (SP0) — register the SurfaceView PlatformView.
        flutterEngine.platformViewsController.registry.registerViewFactory(
            "zangetsu/exoplayer_view",
            ExoPlayerViewFactory(flutterEngine.dartExecutor.binaryMessenger),
        )

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "frame" -> {
                        val url = call.argument<String>("url")
                        val positionMs = (call.argument<Number>("positionMs") ?: 0).toLong()
                        val headers = call.argument<Map<String, String>>("headers")
                        val maxWidth = (call.argument<Number>("maxWidth") ?: 320).toInt()
                        if (url == null) {
                            result.success(null)
                            return@setMethodCallHandler
                        }
                        executor.execute {
                            val bytes = extractFrame(url, positionMs, headers, maxWidth)
                            runOnUiThread { result.success(bytes) }
                        }
                    }
                    "release" -> {
                        executor.execute {
                            releaseRetriever()
                            runOnUiThread { result.success(null) }
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        // Manga page OCR/offline translation. Kept on its own method channel so
        // the reader feature does not alter player or source bridge behavior.
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            "zangetsu/manga_translation",
        ).setMethodCallHandler(MangaTranslationBridge(applicationContext))

        // External-player channel: list installed players + hand a stream off to
        // one via ACTION_VIEW (URL + headers + subtitles + title).
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/external_player")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "getPlayers" -> result.success(installedPlayers())
                    "launch" -> launchExternal(call, result)
                    "proxyUrl" -> {
                        try {
                            val url = call.argument<String>("url")
                            @Suppress("UNCHECKED_CAST")
                            val headers = (call.argument<Map<String, String>>("headers"))
                                ?: emptyMap()
                            if (url.isNullOrEmpty()) {
                                result.success(null)
                            } else {
                                result.success(ExternalStreamProxy.proxyUrl(url, headers))
                            }
                        } catch (e: Exception) {
                            android.util.Log.w("ext-player", "proxyUrl failed: ${e.message}")
                            result.success(null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        // Unknown document providers return null rather than measuring a different drive.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/storage")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "freeBytes" -> {
                        try {
                            val destination = call.argument<String>("destination")
                            val privateStorage = call.argument<Boolean>("privateStorage") == true
                            val storagePath = when {
                                privateStorage -> applicationContext.filesDir.path
                                destination.isNullOrBlank() -> android.os.Environment.getExternalStorageDirectory().path
                                destination.startsWith("/") -> destination
                                destination.startsWith("content://") -> {
                                    val root = android.provider.DocumentsContract
                                        .getTreeDocumentId(Uri.parse(destination)).substringBefore(':')
                                    val sm = getSystemService(STORAGE_SERVICE) as StorageManager
                                    getExternalFilesDirs(null).firstOrNull { file ->
                                        if (file == null) false else {
                                            val volume = sm.getStorageVolume(file)
                                            if (root.equals("primary", ignoreCase = true)) volume?.isPrimary == true
                                            else volume?.uuid?.equals(root, ignoreCase = true) == true
                                        }
                                    }?.path
                                }
                                else -> null
                            }
                            result.success(storagePath?.let { android.os.StatFs(it).availableBytes })
                        } catch (e: Exception) {
                            android.util.Log.w("storage", "freeBytes failed: ${e.message}")
                            result.success(null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        // Volume-key paging: the reader turns this on while it's open and off
        // when it closes. Bidirectional — Dart sets the flag, native pushes
        // "volumeKey" back with the direction.
        volumeKeyChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            "zangetsu/volume_keys",
        ).apply {
            setMethodCallHandler { call, result ->
                when (call.method) {
                    "setEnabled" -> {
                        volumeKeyPaging = call.argument<Boolean>("enabled") ?: false
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
        }

        // Download channel: stream-copy remux of a concatenated-TS HLS download
        // into a real MP4 (MediaExtractor → MediaMuxer). Runs off the main thread;
        // returns false on any failure so Dart can fall back to a .ts file.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/download")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "remuxTsToMp4" -> {
                        val input = call.argument<String>("input")
                        val output = call.argument<String>("output")
                        if (input.isNullOrEmpty() || output.isNullOrEmpty()) {
                            result.error("BAD_ARGS", "input/output required", null)
                        } else {
                            Thread {
                                val ok = com.spyou.watch_app.download.TsRemuxer.remux(input, output)
                                runOnUiThread { result.success(ok) }
                            }.start()
                        }
                    }
                    // Detected storage volumes the app can write to WITHOUT the SAF
                    // picker (which Android TV usually lacks): internal + any SD/USB
                    // drive, as app-specific external dirs from getExternalFilesDirs.
                    // Each: {path, label, removable}. This is how CloudStream lets a
                    // TV pick a USB/SSD with just the D-pad.
                    "listDownloadVolumes" -> {
                        val out = ArrayList<Map<String, Any?>>()
                        try {
                            val sm = getSystemService(STORAGE_SERVICE) as StorageManager
                            getExternalFilesDirs(null).forEachIndexed { i, f ->
                                if (f == null) return@forEachIndexed
                                var label = if (i == 0) "Internal storage" else "Removable drive"
                                var removable = i > 0
                                try {
                                    val vol = sm.getStorageVolume(f)
                                    if (vol != null) {
                                        vol.getDescription(this)?.takeIf { it.isNotBlank() }?.let { label = it }
                                        removable = vol.isRemovable
                                    }
                                } catch (_: Exception) {}
                                out.add(mapOf(
                                    "path" to f.absolutePath,
                                    "label" to label,
                                    "removable" to removable,
                                ))
                            }
                        } catch (_: Exception) {}
                        result.success(out)
                    }
                    else -> result.notImplemented()
                }
            }

        // Native TV-player channel (bidirectional). Dart→native: launch. The same
        // channel is stored in tvBridge so TvPlayerActivity can call native→Dart
        // (resolveEpisode / saveProgress).
        tvBridge = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/tv_player")
            .also { ch ->
                ch.setMethodCallHandler { call, result ->
                    when (call.method) {
                        "launch" -> launchTvPlayer(call, result)
                        "setFillerInfo" -> {
                            val flags = call.argument<List<*>>("fillerFlags")
                                ?.map { it == true }?.toBooleanArray()
                            val auto = call.argument<Boolean>("autoSkipFiller")
                            TvPlayerActivity.active?.applyFillerInfo(flags, auto)
                            result.success(null)
                        }
                        else -> result.notImplemented()
                    }
                }
            }

        // Native phone-player channel; the object owns everything else.
        PhonePlayerBridge.register(flutterEngine, this)

        // Notifications channel: deliver the "new episode" notification a CS
        // worker posted (its launch intent carries notif_payload) to Dart so it
        // can open that show's Detail. getInitialNotification covers cold/back
        // launch; onNewIntent (below) covers a tap while the app is running.
        notifChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            "zangetsu/notifications",
        ).also { ch ->
            ch.setMethodCallHandler { call, result ->
                when (call.method) {
                    "getInitialNotification" -> {
                        val payload = intent?.getStringExtra("notif_payload")
                        intent?.removeExtra("notif_payload") // consume once
                        result.success(payload)
                    }
                    else -> result.notImplemented()
                }
            }
        }

        // PiP channel: Dart arms/disarms auto-PiP while the player is on screen.
        // Home-screen icon picker. Each choice is an <activity-alias> in the
        // manifest; switching means enabling one and disabling the rest.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/app_icon")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "current" -> result.success(currentIconAlias())
                    "set" -> {
                        val id = call.argument<String>("id")
                        if (id == null || !ICON_ALIASES.containsKey(id)) {
                            result.error("BAD_ARGS", "unknown icon id: $id", null)
                            return@setMethodCallHandler
                        }
                        try {
                            applyIconAlias(id)
                            result.success(true)
                        } catch (e: Exception) {
                            result.error("ICON", e.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        val pipChannel =
            MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/pip")
        // Same channel both ways now: Dart arms auto-PiP and pushes playback
        // state down it, and a tapped window button comes back up it.
        pip.onControl = { control -> pipChannel.invokeMethod(control, null) }
        pip.register()
        pipChannel.setMethodCallHandler { call, result ->
            when (call.method) {
                "setAutoPip" -> {
                    autoPipEnabled = (call.arguments as? Boolean) ?: false
                    // Android 12+ only; below that onUserLeaveHint covers it.
                    pip.autoEnter = autoPipEnabled
                    result.success(true)
                }
                // Playback state + video size, so the window can show the right
                // play/pause icon and size itself to the actual video instead
                // of a hardcoded 16:9.
                "setState" -> {
                    val a = call.arguments as? Map<*, *>
                    pip.setState(
                        (a?.get("playing") as? Boolean) ?: true,
                        (a?.get("width") as? Int) ?: 0,
                        (a?.get("height") as? Int) ?: 0,
                    )
                    result.success(true)
                }
                "enter" -> result.success(pip.enter(null))
                else -> result.notImplemented()
            }
        }

        phoneVoiceSearch?.dispose()
        phoneVoiceSearch = PhoneVoiceSearchBridge(this, flutterEngine.dartExecutor.binaryMessenger)

        // Voice search (TV): open the system speech dialog and hand the
        // recognised phrase back to Dart. Uses ACTION_RECOGNIZE_SPEECH so no
        // RECORD_AUDIO permission is needed — the recogniser records in its own
        // process. isAvailable gates the mic button so it never shows on a box
        // without a recogniser.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/voice_search")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "isAvailable" -> {
                        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        result.success(i.resolveActivity(packageManager) != null)
                    }
                    "listen" -> startVoiceSearch(call.argument<String>("prompt"), result)
                    else -> result.notImplemented()
                }
            }

        // Soft-IME force-show for TV text fields. Flutter's TextInput.show is
        // often cancelled on leanback (`PHASE_CLIENT_REPORT_REQUESTED_VISIBLE_TYPES`);
        // this retries via InputMethodManager + WindowInsetsController.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/ime")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "show" -> {
                        showImeForced()
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }

        // Torrent channel: native libtorrent4j streaming engine (Phase 1).
        // Inert until Dart calls startStream — only wires the channels here.
        TorrentEngine(applicationContext, flutterEngine.dartExecutor.binaryMessenger)

        // Torrent DOWNLOAD engine (Phase 2) — separate persistent session +
        // channels; inert until Dart calls enqueue.
        TorrentDownloadEngine(applicationContext, flutterEngine.dartExecutor.binaryMessenger)

        // CloudStream channel: install repos and drive `.cs3` plugins' search /
        // load / loadLinks. All handlers run on [csExecutor] (network + plugin
        // work is blocking) and post back via runOnUiThread; any failure is
        // surfaced to Dart as a "cs_error".
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/cloudstream")
            .also { csChannel = it }
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    // Solve Cloudflare for [url] in the WebView solver and hand back
                    // the clearance cookie + matching User-Agent, so the JS-provider
                    // fetch layer (Dart) can attach them to its own requests. Runs
                    // off the main thread (solve() blocks on a WebView latch).
                    "solveCloudflare" -> {
                        val url = call.argument<String>("url")
                        if (url.isNullOrBlank()) {
                            result.error("bad_args", "url required", null)
                            return@setMethodCallHandler
                        }
                        csExecutor.execute {
                            val solved = try {
                                com.lagradost.cloudstream3.network.CfWebViewSolver.solve(url)
                            } catch (e: Exception) {
                                null
                            }
                            runOnUiThread {
                                if (solved != null) {
                                    result.success(
                                        mapOf(
                                            "cookie" to solved.cookie,
                                            "userAgent" to solved.userAgent,
                                        ),
                                    )
                                } else {
                                    result.success(null)
                                }
                            }
                        }
                    }
                    // Add (or refresh) a repo: fetch its catalog only — does NOT
                    // download/install anything. The user installs plugins one by
                    // one via "installPlugin". Returns the repo name + its full
                    // advertised plugin list (the catalog).
                    "addRepo" -> {
                        val url = call.argument<String>("url")
                        csExecutor.execute {
                            try {
                                val (repoName, plugins) = repo.loadRepo(url ?: "")
                                val info = mapOf(
                                    "name" to repoName,
                                    "url" to (url ?: ""),
                                    "plugins" to plugins.map { it.toMap() },
                                )
                                runOnUiThread { result.success(info) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // Install ONE plugin (download its .cs3 + load it). Returns the
                    // updated installed-source list so Dart can rebuild.
                    "installPlugin" -> {
                        val cs3Url = call.argument<String>("url")
                        val internalName = call.argument<String>("internalName")
                        val version = call.argument<Int>("version") ?: 1
                        val repoUrl = call.argument<String>("repoUrl") ?: ""
                        csExecutor.execute {
                            try {
                                val file = repo.download(
                                    cs3Url ?: "",
                                    internalName ?: "",
                                    version,
                                    repoUrl,
                                )
                                // Surface a genuine load failure instead of a
                                // false "installed": some sources need a newer
                                // CloudStream API than this build provides.
                                var ok = host.loadPlugin(file)
                                // Plugins that cast the load context to an
                                // AppCompatActivity hard-fail above (we're a
                                // FlutterActivity). Retry them against a real
                                // AppCompatActivity, then re-check registration.
                                if (!ok) {
                                    loadPluginsViaActivity(host.pendingActivityLoads())
                                    ok = host.isLoaded(file)
                                }
                                if (ok) {
                                    runOnUiThread { result.success(host.installedApis()) }
                                } else {
                                    runOnUiThread {
                                        result.error(
                                            "cs_load_failed",
                                            "Couldn't load this source — it may need a newer app version.",
                                            null,
                                        )
                                    }
                                }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // Uninstall ONE plugin, repo-scoped by repoUrl (so two repos'
                    // same-named plugins uninstall independently). Falls back to
                    // the legacy by-internalName delete when no repoUrl is known.
                    "uninstallPlugin" -> {
                        val internalName = call.argument<String>("internalName") ?: ""
                        val repoUrl = call.argument<String>("repoUrl") ?: ""
                        csExecutor.execute {
                            try {
                                if (repoUrl.isNotEmpty()) {
                                    host.deleteByRepoPlugin(
                                        com.spyou.watch_app.cloudstream.RepoManager.repoTag(repoUrl),
                                        internalName,
                                    )
                                } else {
                                    host.deleteByInternalNames(setOf(internalName))
                                }
                                runOnUiThread { result.success(host.installedApis()) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    "listSources" -> {
                        csExecutor.execute {
                            try {
                                host.loadAll(repo.cachedFiles())
                                // Retry any that hard-failed on the AppCompatActivity
                                // cast against a real activity, so they survive a
                                // restart (loadAll runs every launch).
                                loadPluginsViaActivity(host.pendingActivityLoads())
                                // Plugins that defer registerMainAPI to
                                // afterPluginsLoadedEvent register now.
                                host.firePluginsLoaded()
                                val apis = host.installedApis()
                                runOnUiThread { result.success(apis) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // In-app DNS-over-HTTPS for CS sources (opt-in; 0 = Off).
                    "getDns" -> result.success(host.dnsChoice())
                    "setDns" -> {
                        val choice = call.argument<Int>("choice") ?: 0
                        csExecutor.execute {
                            runCatching { host.setDns(choice) }
                            runOnUiThread { result.success(true) }
                        }
                    }
                    // Mirror CS subscriptions to native + (re)schedule the periodic
                    // background "new episode" worker. Merges so the worker's
                    // advanced episode counts survive a re-sync from Dart.
                    "syncSubscriptions" -> {
                        @Suppress("UNCHECKED_CAST")
                        val incoming =
                            (call.argument<List<Map<String, Any?>>>("subs") ?: emptyList())
                        csExecutor.execute {
                            runCatching { mergeSubscriptions(incoming) }
                            runOnUiThread { result.success(true) }
                        }
                    }
                    // Run the CS subscription check once, now (e.g. "Check now").
                    "checkSubscriptionsNow" -> {
                        runCatching {
                            WorkManager.getInstance(applicationContext).enqueue(
                                OneTimeWorkRequestBuilder<SubscriptionWorker>()
                                    .setConstraints(
                                        Constraints.Builder()
                                            .setRequiredNetworkType(NetworkType.CONNECTED)
                                            .build(),
                                    )
                                    .build(),
                            )
                        }
                        result.success(true)
                    }
                    "deleteRepo" -> {
                        @Suppress("UNCHECKED_CAST")
                        val files = (call.argument<List<String>>("files") ?: emptyList())
                        csExecutor.execute {
                            try {
                                host.deleteByFiles(files.toSet())
                                val apis = host.installedApis()
                                runOnUiThread { result.success(apis) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // Check a repo for updates: re-fetch its catalog and re-install
                    // ONLY the plugins that are currently installed whose version
                    // changed (never auto-installs new ones). Returns fresh catalog
                    // + the updated source list.
                    "updateRepo" -> {
                        val url = call.argument<String>("url")
                        csExecutor.execute {
                            try {
                                val (repoName, plugins) = repo.loadRepo(url ?: "")
                                val installed = host.installedFileIds() // "name@ver[@tag]"
                                // Tag is per-REPO (the repo url the user added), so
                                // updating one repo never touches another repo's
                                // same-named plugin.
                                val tag = com.spyou.watch_app.cloudstream.RepoManager
                                    .repoTag(url ?: "")
                                var updated = 0 // plugins actually re-downloaded
                                for (plugin in plugins) {
                                    // Only update THIS repo's copy: its tagged file
                                    // or a legacy un-tagged one (1 '@').
                                    val mine = installed.any {
                                        it.substringBefore('@') == plugin.internalName &&
                                                (it.endsWith("@$tag") || it.count { c -> c == '@' } == 1)
                                    }
                                    if (!mine) continue
                                    val newId = "${plugin.internalName}@${plugin.version}@$tag"
                                    if (installed.contains(newId)) continue // already current
                                    try {
                                        host.deleteByRepoPlugin(tag, plugin.internalName)
                                        host.loadPlugin(repo.download(plugin))
                                        updated++
                                    } catch (_: Exception) { /* skip a bad plugin */ }
                                }
                                val info = mapOf(
                                    "name" to repoName,
                                    "url" to (url ?: ""),
                                    "plugins" to plugins.map { it.toMap() },
                                    "sources" to host.installedApis(),
                                    "updated" to updated,
                                )
                                runOnUiThread { result.success(info) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // READ-ONLY update check: re-fetch a repo's catalog and report
                    // which currently-installed plugins have a newer version online,
                    // WITHOUT downloading anything. Never mutates plugins/disk/state,
                    // so it can't affect playback or installed sources. Returns
                    // { url, outdated:[{internalName,name,url,installedVersion,onlineVersion}] }.
                    "checkRepoUpdates" -> {
                        val url = call.argument<String>("url")
                        csReadPool.execute {
                            try {
                                val (_, plugins) = repo.loadRepo(url ?: "")
                                val installed = host.installedFileIds() // "name@ver[@tag]"
                                val tag = com.spyou.watch_app.cloudstream.RepoManager
                                    .repoTag(url ?: "")
                                val outdated = mutableListOf<Map<String, Any?>>()
                                for (plugin in plugins) {
                                    // THIS repo's installed copy (tagged or legacy).
                                    // Use the HIGHEST installed version: an older `.cs3`
                                    // left on disk (stale/mismatched tag from a past
                                    // update) must NOT make a current plugin look
                                    // outdated. With firstOrNull the leftover old file
                                    // could win → a false, sticky "update available".
                                    val installedVersion = installed
                                        .filter {
                                            it.substringBefore('@') == plugin.internalName &&
                                                    (it.endsWith("@$tag") || it.count { c -> c == '@' } == 1)
                                        }
                                        .mapNotNull { it.split('@').getOrNull(1)?.toIntOrNull() }
                                        .maxOrNull() ?: continue
                                    if (plugin.version > installedVersion) {
                                        outdated.add(
                                            mapOf(
                                                "internalName" to plugin.internalName,
                                                "name" to plugin.name,
                                                "url" to plugin.url,
                                                "installedVersion" to installedVersion,
                                                "onlineVersion" to plugin.version,
                                            ),
                                        )
                                    }
                                }
                                val info = mapOf("url" to (url ?: ""), "outdated" to outdated)
                                runOnUiThread { result.success(info) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // Update ONE installed plugin to a specific version: drop its old
                    // cached `.cs3` (repo-scoped) and download + load the new one.
                    // Mirrors updateRepo's inner loop for a single plugin. Returns the
                    // refreshed source list.
                    "updatePlugin" -> {
                        val cs3Url = call.argument<String>("url") ?: ""
                        val internalName = call.argument<String>("internalName") ?: ""
                        val version = call.argument<Int>("version") ?: 1
                        val repoUrl = call.argument<String>("repoUrl") ?: ""
                        csExecutor.execute {
                            try {
                                val tag = com.spyou.watch_app.cloudstream.RepoManager
                                    .repoTag(repoUrl)
                                host.deleteByRepoPlugin(tag, internalName)
                                host.loadPlugin(
                                    repo.download(cs3Url, internalName, version, repoUrl),
                                )
                                val apis = host.installedApis()
                                runOnUiThread { result.success(apis) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    "getHome" -> {
                        val name = call.argument<String>("name")
                        csReadPool.execute {
                            try {
                                val res = host.getHome(name ?: "")
                                // Serialize on THIS background thread, not the UI
                                // thread. Handing Flutter a big nested List<Map>
                                // makes the platform-channel codec encode it on the
                                // main thread, which skips frames on large feeds
                                // (e.g. MovieBox). A single JSON string encodes
                                // cheaply on the main thread; Dart decodes it off
                                // the UI thread.
                                val json = org.json.JSONArray(res).toString()
                                runOnUiThread { result.success(json) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // One further page of a single mainPage category, for the
                    // "See all" browse grid's infinite scroll. Additive — returns
                    // a flat list of item maps (decoded like `search`).
                    "getMainPagePaged" -> {
                        val name = call.argument<String>("name")
                        val data = call.argument<String>("data")
                        val page = call.argument<Int>("page") ?: 1
                        val apiName = call.argument<String>("apiName")
                        csReadPool.execute {
                            try {
                                val res = host.getMainPagePaged(
                                    apiName ?: "",
                                    name ?: "",
                                    data ?: "",
                                    page,
                                )
                                runOnUiThread { result.success(res) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    "search" -> {
                        val name = call.argument<String>("name")
                        val query = call.argument<String>("query")
                        csReadPool.execute {
                            try {
                                val res = host.search(name ?: "", query ?: "")
                                runOnUiThread { result.success(res) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // Status-reporting search for the source-health feature:
                    // returns {items, error?} so callers can tell an honest empty
                    // result from a timed-out / broken source (plain `search`
                    // collapses both to []).
                    "searchStatus" -> {
                        val name = call.argument<String>("name")
                        val query = call.argument<String>("query")
                        csReadPool.execute {
                            try {
                                val res = host.searchWithStatus(name ?: "", query ?: "")
                                runOnUiThread { result.success(res) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    "load" -> {
                        val name = call.argument<String>("name")
                        val url = call.argument<String>("url")
                        val category = call.argument<String>("category") ?: "sub"
                        csReadPool.execute {
                            try {
                                val res = host.load(name ?: "", url ?: "", category)
                                runOnUiThread { result.success(res) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    "loadLinks" -> {
                        val name = call.argument<String>("name")
                        val data = call.argument<String>("data")
                        val fast = call.argument<Boolean>("fast") ?: false
                        // Playback (fast) gets its own lane so a pool clogged
                        // by dead servers can't starve pressing play.
                        val lane = if (fast) csPlayPool else csReadPool
                        lane.execute {
                            try {
                                val res = host.loadLinks(name ?: "", data ?: "", fast)
                                runOnUiThread { result.success(res) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // A hunt the viewer walked away from (back during "Finding…").
                    // Stops it natively instead of letting dead servers hold a
                    // pool thread to their cap.
                    "cancelLinks" -> {
                        val name = call.argument<String>("name")
                        val data = call.argument<String>("data")
                        csReadPool.execute {
                            try {
                                host.cancelSession(name ?: "", data ?: "")
                                runOnUiThread { result.success(null) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // Links gathered so far for an episode whose resolve is still
                    // running in the background (see PluginHost.polledLinks).
                    // Read-only and cheap — it never starts a resolve.
                    "pollLinks" -> {
                        val name = call.argument<String>("name")
                        val data = call.argument<String>("data")
                        csReadPool.execute {
                            try {
                                val res = host.polledLinks(name ?: "", data ?: "")
                                runOnUiThread { result.success(res) }
                            } catch (e: Exception) {
                                runOnUiThread { result.error("cs_error", e.message, null) }
                            }
                        }
                    }
                    // Does this source's plugin expose its own settings UI?
                    "hasPluginSettings" -> {
                        val name = call.argument<String>("name")
                        try {
                            result.success(host.hasSettings(name ?: ""))
                        } catch (e: Exception) {
                            result.error("cs_error", e.message, null)
                        }
                    }
                    // Open the plugin's own settings UI in a dedicated
                    // AppCompatActivity (plugins cast the Context to one).
                    "openPluginSettings" -> {
                        val name = call.argument<String>("name")
                        runOnUiThread {
                            try {
                                val intent = android.content.Intent(
                                    this,
                                    com.spyou.watch_app.cloudstream.CloudStreamSettingsActivity::class.java,
                                ).putExtra(
                                    com.spyou.watch_app.cloudstream.CloudStreamSettingsActivity.EXTRA_API_NAME,
                                    name,
                                )
                                startActivity(intent)
                                result.success(true)
                            } catch (e: Exception) {
                                result.error("cs_error", e.message, null)
                            }
                        }
                    }
                    // Clear this plugin's own DataStore-backed settings + its
                    // site's cookies — narrow reset when a plugin's saved
                    // state (login, chosen server, prefs) has gone stale.
                    // Never touches any other plugin or the shared cookie jar.
                    "resetPluginData" -> {
                        val name = call.argument<String>("name")
                        try {
                            result.success(host.resetPluginData(name ?: ""))
                        } catch (e: Exception) {
                            result.error("cs_error", e.message, null)
                        }
                    }
                    // The source's CURRENT mainUrl, read fresh off the loaded
                    // plugin rather than the value captured when sources were
                    // listed — see PluginHost.liveMainUrl. Used by the
                    // Cloudflare-solve action so it targets the domain the
                    // source actually uses right now.
                    "liveMainUrl" -> {
                        val name = call.argument<String>("name")
                        try {
                            result.success(host.liveMainUrl(name ?: ""))
                        } catch (e: Exception) {
                            result.error("cs_error", e.message, null)
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        // Aniyomi channel: load Aniyomi anime-extension APKs, register sources,
        // and expose them to the Flutter layer for browse/search/play. Mirrors the
        // CloudStream channel registration style above.
        val aniyomiChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/aniyomi")
        AniyomiBridge(applicationContext, extensionScope("aniyomi")).attach(aniyomiChannel)

        // Mihon channel: same idea for manga — load Mihon manga-extension APKs,
        // register sources, and expose them for browse/search/read. Separate
        // bridge and separate source registry from Aniyomi's; nothing shared.
        val mihonChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/mihon")
        MihonBridge(applicationContext, extensionScope("mihon")).attach(mihonChannel)

        // Tile channel: decodes just the visible region of a tall manga/manhwa
        // page (BitmapRegionDecoder) instead of the whole page, for the reader's
        // tiled-page path. Same registration shape as the two bridges above.
        val tileChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/tiles")
        TileBridge(extensionScope("tiles")).attach(tileChannel)

        // Novel-fetch channel: routes the LNReader plugin's HTTP requests
        // through native OkHttp (see NovelHttp.kt) instead of Dio/dart:io.
        // Android's platform TLS stack gets a Chrome-like fingerprint that
        // Cloudflare-gated novel hosts (webnovel.com) don't 403 — headers
        // alone don't clear that gate. Dart falls back to Dio itself if this
        // channel throws or is missing, so a bad response here never breaks
        // a working source.
        // The novel client must present the device's real WebView UA — see
        // NovelHttp.deviceUserAgent. Best-effort: this can throw while WebView
        // is being updated, and a null just leaves the old behaviour.
        if (NovelHttp.deviceUserAgent == null) {
            NovelHttp.deviceUserAgent = runCatching {
                android.webkit.WebSettings.getDefaultUserAgent(this)
                    .replace("; wv", "")
                    .takeIf { it.isNotBlank() }
            }.getOrNull()
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/novel_http")
            .setMethodCallHandler { call, result ->
                if (call.method != "request") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                val url = call.argument<String>("url")
                if (url.isNullOrBlank()) {
                    result.error("bad_args", "url required", null)
                    return@setMethodCallHandler
                }
                val method = call.argument<String>("method") ?: "GET"
                @Suppress("UNCHECKED_CAST")
                val headers = call.argument<Map<String, String>>("headers") ?: emptyMap()
                val body = call.argument<String>("body")
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val resp = NovelHttp.request(url, method, headers, body)
                        runOnUiThread {
                            result.success(
                                mapOf(
                                    "status" to resp.status,
                                    "body" to resp.body,
                                    "url" to resp.url,
                                    "headers" to resp.headers,
                                    "cloudflare" to resp.cloudflare,
                                ),
                            )
                        }
                    } catch (e: Exception) {
                        runOnUiThread { result.error("novel_http_failed", e.message, null) }
                    }
                }
            }

        // Device-class detection: lets Dart know if the app is running on an
        // Android TV / Leanback device. Returns false on phones/tablets so every
        // TV layout branch is a no-op on the phone build.
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.spyou.watch_app/device")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    // Use PackageManager's ABI-specific extraction directory,
                    // rather than relying on the device linker's basename search.
                    "mpvLibraryPath" -> {
                        val library = java.io.File(applicationInfo.nativeLibraryDir, "libmpv.so")
                        if (library.isFile) {
                            result.success(library.absolutePath)
                        } else {
                            result.error("native_library_missing",
                                "libmpv.so missing from ${library.parent}; ABIs=${android.os.Build.SUPPORTED_ABIS.joinToString()}", null)
                        }
                    }
                    "isTv" -> {
                        val uiModeManager = getSystemService(android.content.Context.UI_MODE_SERVICE) as android.app.UiModeManager
                        val isTv = uiModeManager.currentModeType == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION ||
                                packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK) ||
                                packageManager.hasSystemFeature("android.software.leanback_only")
                        result.success(isTv)
                    }
                    // Does a SAF content:// document still exist on disk? Used by
                    // the Downloads screen to prune entries whose file was deleted
                    // outside the app. On ANY uncertainty we return true so a valid
                    // download is never wrongly removed from the list.
                    "documentExists" -> {
                        val uriStr = call.argument<String>("uri")
                        if (uriStr.isNullOrEmpty()) {
                            result.success(true)
                            return@setMethodCallHandler
                        }
                        val exists = try {
                            androidx.documentfile.provider.DocumentFile
                                .fromSingleUri(applicationContext, android.net.Uri.parse(uriStr))
                                ?.exists() ?: true
                        } catch (e: Exception) {
                            true
                        }
                        result.success(exists)
                    }
                    // Byte size of a SAF content:// document (-1 if unknown) —
                    // lets the download content-guard reject a tiny stub (e.g. a
                    // DASH .mpd manifest MovieBox serves) that landed in a custom
                    // folder, same as it already does for default downloads.
                    "documentSize" -> {
                        val uriStr = call.argument<String>("uri")
                        if (uriStr.isNullOrEmpty()) {
                            result.success(-1L)
                            return@setMethodCallHandler
                        }
                        val size = try {
                            androidx.documentfile.provider.DocumentFile
                                .fromSingleUri(applicationContext, android.net.Uri.parse(uriStr))
                                ?.length() ?: -1L
                        } catch (e: Exception) {
                            -1L
                        }
                        result.success(size)
                    }
                    // Move a finished local file into a user-picked SAF tree
                    // folder (persisted permission → works without a foreground
                    // activity). Used by HLS downloads, whose background isolate
                    // can't do the SAF write. Returns the new content:// URI (or
                    // null on failure, so the caller keeps the local file).
                    "moveIntoTree" -> {
                        val localPath = call.argument<String>("localPath")
                        val treeUri = call.argument<String>("treeUri")
                        val filename = call.argument<String>("filename")
                        val mimeType = call.argument<String>("mimeType") ?: "video/mp4"
                        if (localPath.isNullOrEmpty() || treeUri.isNullOrEmpty() || filename.isNullOrEmpty()) {
                            result.success(null)
                            return@setMethodCallHandler
                        }
                        executor.execute {
                            val out: String? = try {
                                val tree = androidx.documentfile.provider.DocumentFile
                                    .fromTreeUri(applicationContext, android.net.Uri.parse(treeUri))
                                tree?.findFile(filename)?.delete() // replace an old copy
                                val doc = tree?.createFile(mimeType, filename)
                                if (doc != null) {
                                    applicationContext.contentResolver.openOutputStream(doc.uri)?.use { os ->
                                        java.io.File(localPath).inputStream().use { it.copyTo(os) }
                                    }
                                    java.io.File(localPath).delete()
                                    doc.uri.toString()
                                } else {
                                    null
                                }
                            } catch (e: Exception) {
                                null
                            }
                            runOnUiThread { result.success(out) }
                        }
                    }
                    else -> result.notImplemented()
                }
            }

        // Cast channel: load media onto a Chromecast + transport controls.
        // CastContext init is guarded in CastManager — safe on devices without Play Services.
        val cm = CastManager(this).also { castManager = it }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/cast")
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "init" -> result.success(cm.init())
                        "loadMedia" -> {
                            @Suppress("UNCHECKED_CAST")
                            val args = call.arguments as? Map<String, Any?> ?: emptyMap()
                            cm.loadMedia(args)
                            result.success(null)
                        }
                        "play" -> { cm.play(); result.success(null) }
                        "pause" -> { cm.pause(); result.success(null) }
                        "seek" -> {
                            val ms = (call.argument<Number>("ms") ?: 0).toInt()
                            cm.seek(ms)
                            result.success(null)
                        }
                        "stop" -> { cm.stop(); result.success(null) }
                        "pickDevice" -> { cm.pickDevice(); result.success(null) }
                        "startDiscovery" -> { cm.startDiscovery(); result.success(null) }
                        "stopDiscovery" -> { cm.stopDiscovery(); result.success(null) }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("cast_error", e.message, null)
                }
            }
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, "zangetsu/cast/events")
            .setStreamHandler(cm)
    }

    // Android 8.0–11 have no auto-enter API, so enter PiP here when the user
    // leaves via Home/Recents while a video is armed. Android 12+ is handled by
    // setAutoEnterEnabled above, so we skip it here to avoid a double trigger.
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        flutterFragment.onUserLeaveHint()
        if (autoPipEnabled &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S &&
            !isInPictureInPictureMode
        ) {
            pip.enter(null)
        }
    }

    // Re-push the params on entering, so the window opens with its actions
    // already attached rather than picking them up a frame later.
    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration,
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) pip.applyParams()
    }

    // Known external video players (package -> display label).
    private val knownPlayers = linkedMapOf(
        "com.mxtech.videoplayer.ad" to "MX Player",
        "com.mxtech.videoplayer.pro" to "MX Player Pro",
        "org.videolan.vlc" to "VLC",
        "is.xyz.mpv" to "mpv",
        "com.brouken.player" to "Just Player",
        "dev.anilbeesetti.nextplayer" to "Next Player",
        // SPlayer ships under two package ids (Play Store "All Video Player" and
        // the alt-store "Fast Video Player"); list both so whichever the user has
        // installed is detected. installedPlayers() filters to the present one.
        "com.young.simple.player" to "SPlayer",
        "com.ttee.leeplayer" to "SPlayer",
    )

    // The known players first, in the curated order above, then anything else on
    // the device that can open a video.
    //
    // The hardcoded list used to be the whole answer, which meant a player we'd
    // never heard of was invisible even when installed — the picker claimed the
    // user had nothing when they had Kodi or their OEM's player sitting right
    // there. Known players stay on top because their intent extras are known, so
    // subtitles and the resume position actually reach them; the rest play fine
    // but may ignore those extras, which is why they're flagged for the UI to
    // show under their own heading.
    private fun installedPlayers(): List<Map<String, String>> {
        val out = mutableListOf<Map<String, String>>()
        val seen = mutableSetOf<String>()
        for ((pkg, label) in knownPlayers) {
            try {
                packageManager.getPackageInfo(pkg, 0)
                if (seen.add(pkg)) {
                    out.add(mapOf("package" to pkg, "label" to label, "known" to "1"))
                }
            } catch (_: Exception) { /* not installed */ }
        }
        // Probed with an https URL because that's what we actually hand over —
        // an app that only claims content:// or file:// can't play our streams,
        // so leaving it out of the list is the correct answer, not a gap.
        for (mime in arrayOf("video/*", "application/x-mpegURL")) {
            try {
                val probe = Intent(Intent.ACTION_VIEW).setDataAndType(
                    Uri.parse("https://example.com/video.mp4"),
                    mime,
                )
                // MATCH_DEFAULT_ONLY: startActivity needs CATEGORY_DEFAULT on the
                // target filter, so anything without it would fail to launch.
                val hits = packageManager.queryIntentActivities(
                    probe,
                    PackageManager.MATCH_DEFAULT_ONLY,
                )
                for (ri in hits) {
                    val info = ri.activityInfo ?: continue
                    val pkg = info.packageName ?: continue
                    if (pkg == packageName || !seen.add(pkg)) continue
                    // The application label, not the activity's — activity labels
                    // are often "Open with …" or blank.
                    val label = info.applicationInfo
                        ?.let { packageManager.getApplicationLabel(it).toString() }
                        ?.takeIf { it.isNotBlank() }
                        ?: pkg
                    out.add(mapOf("package" to pkg, "label" to label, "known" to "0"))
                }
            } catch (e: Exception) {
                Log.w(TAG, "queryIntentActivities($mime) failed: ${e.message}")
            }
        }
        return out
    }

    /// A content:// URI another app may read for [path], or null when the
    /// file is outside the dirs res/xml/video_paths.xml covers (or is gone).
    ///
    /// Android 7+ throws FileUriExposedException for a file:// handed to
    /// another app, so a FileProvider is the only way to pass a downloaded
    /// episode to an external player.
    private fun sharableUri(path: String): android.net.Uri? = try {
        androidx.core.content.FileProvider.getUriForFile(
            this,
            "$packageName.videoprovider",
            java.io.File(path),
        )
    } catch (e: Exception) {
        Log.w(TAG, "no content uri for a downloaded file: ${e.message}")
        null
    }

    /// Downloaded sidecars live in private app_flutter storage, which the
    /// FileProvider intentionally does not expose. Copy only the subtitle file
    /// into its configured cache path, then hand the cache content URI to the
    /// external player. Cache files remain available after this activity
    /// returns and Android may evict them when storage is needed.
    private fun shareSubtitleFile(path: String): Uri? {
        val shared = stageSubtitleFile(path, cacheDir, ::sharableUri)
        if (shared == null) {
            Log.w(TAG, "could not stage subtitle for external playback: $path")
        }
        return shared
    }

    @Suppress("UNCHECKED_CAST")
    private fun launchExternal(call: MethodCall, result: MethodChannel.Result) {
        try {
            val url = call.argument<String>("url")
            if (url == null) { result.success(mapOf("launched" to false)); return }
            val pkg = call.argument<String>("package")
            val title = call.argument<String>("title")
            val headers = call.argument<Map<String, String>>("headers")
            val positionMs = (call.argument<Number>("positionMs") ?: 0).toLong()
            val subs = call.argument<List<Map<String, String>>>("subtitles")
            val lower = url.lowercase()
            val mime = when {
                lower.contains("m3u8") -> "application/x-mpegURL" // HLS (incl. ?token= URLs)
                lower.contains(".mpd") -> "application/dash+xml"  // MPEG-DASH
                else -> "video/*"
            }

            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(Uri.parse(url), mime)
            if (!pkg.isNullOrEmpty()) intent.setPackage(pkg)
            // No FLAG_ACTIVITY_NEW_TASK: it would break startActivityForResult,
            // and we need the result back to know if the player actually played.
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

            title?.let { intent.putExtra("title", it); intent.putExtra("name", it) }
            if (positionMs > 0) intent.putExtra("position", positionMs.toInt())

            // Headers: MX Player / Just Player read a flat String[] of k,v,k,v.
            if (!headers.isNullOrEmpty()) {
                val arr = ArrayList<String>()
                for ((k, v) in headers) { arr.add(k); arr.add(v) }
                intent.putExtra("headers", arr.toTypedArray())
                headers["User-Agent"]?.let { intent.putExtra("User-Agent", it) }
            }
            // Remote subtitle URLs keep their previous extras. Downloaded
            // sidecars are staged in the FileProvider cache and shared with a
            // temporary read grant so external apps can actually open them.
            val externalSubs = resolveExternalSubtitleTracks(subs, ::shareSubtitleFile)
            attachExternalSubtitles(intent, externalSubs)

            // Complete any stale pending launch defensively, then wait for this
            // one's result in onActivityResult.
            pendingPlayerResult?.let {
                try { it.success(mapOf("launched" to true, "played" to true)) } catch (_: Exception) {}
            }
            pendingPlayerResult = result
            try {
                startActivityForResult(intent, EXT_PLAYER_REQUEST)
            } catch (e: android.content.ActivityNotFoundException) {
                // A DOWNLOADED episode arrives as a bare filesystem path, which
                // is a URI with no scheme at all. Most players guess it is a
                // file; a strict one (com.ttee.leeplayer in the reports)
                // resolves nothing and dies right here — every launched=false
                // in the logs is a local .mp4, never a stream. Re-offer it as
                // content://, the only form Android has let us hand another app
                // since API 24. Streams are untouched: they already have a
                // scheme, so this branch skips them.
                val shared = if (Uri.parse(url).scheme == null) sharableUri(url) else null
                if (shared != null) {
                    Log.w(TAG, "no activity for a bare path in $pkg — retrying as content://")
                    intent.setDataAndType(shared, mime)
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    try {
                        startActivityForResult(intent, EXT_PLAYER_REQUEST)
                        return
                    } catch (_: android.content.ActivityNotFoundException) {
                        // Still nothing — fall through to the mime retry.
                    }
                }
                // The precise mime above is a hint, not a requirement: plenty of
                // players advertise video/* and nothing else, so an HLS stream
                // sent as application/x-mpegURL resolves to no activity and the
                // launch dies here — the app then falls back to the built-in
                // player and the chosen app looks like it was ignored. Retry
                // once as video/*, which is what every video app claims.
                if (mime == "video/*") throw e
                Log.w(TAG, "no activity for $mime in $pkg — retrying as video/*")
                intent.setDataAndType(Uri.parse(url), "video/*")
                startActivityForResult(intent, EXT_PLAYER_REQUEST)
            }
        } catch (e: Exception) {
            Log.w(TAG, "launchExternal failed: ${e.message}")
            pendingPlayerResult = null
            result.success(mapOf("launched" to false))
        }
    }

    // Load CloudStream plugins that cast the load context to an AppCompatActivity
    // (our host is a FlutterActivity) by handing them a real one:
    // CsPluginLoaderActivity loads them against itself. Called from csExecutor
    // (install / listSources); blocks that background thread until the loader
    // finishes. No-op when [paths] is empty (the normal case → zero overhead).
    private fun loadPluginsViaActivity(paths: List<String>) {
        if (paths.isEmpty()) return
        val latch = java.util.concurrent.CountDownLatch(1)
        CsPluginLoaderActivity.onComplete = { latch.countDown() }
        runOnUiThread {
            try {
                val intent = Intent(this, CsPluginLoaderActivity::class.java)
                intent.putExtra(CsPluginLoaderActivity.EXTRA_PATHS, paths.toTypedArray())
                startActivity(intent)
            } catch (e: Exception) {
                Log.w(TAG, "CsPluginLoaderActivity launch failed: ${e.message}")
                latch.countDown()
            }
        }
        runCatching { latch.await(25, java.util.concurrent.TimeUnit.SECONDS) }
        CsPluginLoaderActivity.onComplete = null
    }

    @Suppress("UNCHECKED_CAST")
    private fun launchTvPlayer(call: MethodCall, result: MethodChannel.Result) {
        try {
            val url = call.argument<String>("url")
            if (url.isNullOrEmpty()) { result.success(mapOf("launched" to false)); return }
            val intent = Intent(this, TvPlayerActivity::class.java)
            intent.putExtra(TvPlayerActivity.EXTRA_URL, url)
            call.argument<String>("title")?.let { intent.putExtra(TvPlayerActivity.EXTRA_TITLE, it) }
            call.argument<String>("episodeLabel")?.let { intent.putExtra(TvPlayerActivity.EXTRA_EP_LABEL, it) }
            call.argument<String>("mimeType")?.let { intent.putExtra(TvPlayerActivity.EXTRA_MIME, it) }
            call.argument<String>("drmKid")?.let { intent.putExtra(TvPlayerActivity.EXTRA_DRM_KID, it) }
            call.argument<String>("drmKey")?.let { intent.putExtra(TvPlayerActivity.EXTRA_DRM_KEY, it) }
            call.argument<Number>("accentColor")?.let { intent.putExtra(TvPlayerActivity.EXTRA_ACCENT, it.toInt()) }
            intent.putExtra(TvPlayerActivity.EXTRA_POSITION, (call.argument<Number>("positionMs") ?: 0).toLong())
            intent.putExtra(
                TvPlayerActivity.EXTRA_DECODER_MODE,
                (call.argument<Number>("decoderMode") ?: TvPlayerActivity.DECODER_MODE_HARDWARE_FIRST).toInt(),
            )
            intent.putExtra(TvPlayerActivity.EXTRA_EP_COUNT, (call.argument<Number>("episodeCount") ?: 1).toInt())
            intent.putExtra(TvPlayerActivity.EXTRA_START_INDEX, (call.argument<Number>("startIndex") ?: 0).toInt())
            call.argument<String>("category")?.let { intent.putExtra(TvPlayerActivity.EXTRA_CATEGORY, it) }
            call.argument<List<String>>("episodeLabels")?.let {
                intent.putExtra(TvPlayerActivity.EXTRA_EP_LABELS, it.toTypedArray())
            }
            call.argument<List<String>>("availableCategories")?.let {
                intent.putExtra(TvPlayerActivity.EXTRA_AVAIL_CATS, it.toTypedArray())
            }
            intent.putExtra(TvPlayerActivity.EXTRA_SPEED, (call.argument<Number>("defaultSpeed") ?: 1.0).toFloat())
            intent.putExtra(TvPlayerActivity.EXTRA_VOLUME, (call.argument<Number>("volumeBoost") ?: 100).toInt())
            // Buffer preset → ExoPlayer LoadControl. Defaulting to 0 leaves the
            // media3 defaults in place, so an older Dart caller behaves as before.
            intent.putExtra(TvPlayerActivity.EXTRA_BUF_MIN_MS, (call.argument<Number>("minBufferMs") ?: 0).toInt())
            intent.putExtra(TvPlayerActivity.EXTRA_BUF_MAX_MS, (call.argument<Number>("maxBufferMs") ?: 0).toInt())
            intent.putExtra(TvPlayerActivity.EXTRA_BUF_BYTES, (call.argument<Number>("targetBufferBytes") ?: 0).toInt())
            intent.putExtra(TvPlayerActivity.EXTRA_BUF_BACK_MS, (call.argument<Number>("backBufferMs") ?: 0).toInt())
            intent.putExtra(TvPlayerActivity.EXTRA_SUB_SCALE, (call.argument<Number>("subtitleScale") ?: 1.0).toFloat())
            // Subtitle style is pre-computed Dart-side (captionStyleFromPrefs) so
            // both TV players render identically — pass the finished values.
            intent.putExtra(TvPlayerActivity.EXTRA_SUB_FG, (call.argument<Number>("subtitleFgColor") ?: -1).toInt())
            intent.putExtra(TvPlayerActivity.EXTRA_SUB_BG_COLOR, (call.argument<Number>("subtitleBgColor") ?: 0).toInt())
            intent.putExtra(TvPlayerActivity.EXTRA_SUB_EDGE, call.argument<Boolean>("subtitleEdge") ?: true)
            val edgeTypeArg = call.argument<Number>("subtitleEdgeType")
            val edgeType = edgeTypeArg?.toInt()
                ?: if (call.argument<Boolean>("subtitleEdge") == true) 1 else 0
            intent.putExtra(TvPlayerActivity.EXTRA_SUB_EDGE_TYPE, edgeType)
            call.argument<String>("subtitleColorHex")?.let {
                intent.putExtra(TvPlayerActivity.EXTRA_SUB_COLOR_HEX, it)
            }
            call.argument<String>("subtitleOutlineType")?.let {
                intent.putExtra(TvPlayerActivity.EXTRA_SUB_OUTLINE_TYPE, it)
            }
            call.argument<String>("subtitleFontFamily")?.let {
                intent.putExtra(TvPlayerActivity.EXTRA_SUB_FONT_FAMILY, it)
            }
            intent.putExtra(
                TvPlayerActivity.EXTRA_SUB_POS_PREF,
                (call.argument<Number>("subtitlePositionPref") ?: 95).toInt(),
            )
            intent.putExtra(
                TvPlayerActivity.EXTRA_SUB_BG_OPACITY,
                (call.argument<Number>("subtitleBgOpacity") ?: 0.0).toFloat(),
            )
            call.argument<String>("subtitleFontPath")?.let { intent.putExtra(TvPlayerActivity.EXTRA_SUB_FONT, it) }
            intent.putExtra(TvPlayerActivity.EXTRA_SUB_HAS_KEY, call.argument<Boolean>("subtitleApiKeySet") ?: false)
            intent.putExtra(TvPlayerActivity.EXTRA_MEGASKIP, call.argument<Boolean>("megaSkip") ?: true)
            intent.putExtra(TvPlayerActivity.EXTRA_MEGASKIP_SECS, (call.argument<Number>("megaSkipSeconds") ?: 85).toInt())
            intent.putExtra(TvPlayerActivity.EXTRA_SKIP_INTRO, call.argument<Boolean>("skipIntro") ?: true)
            intent.putExtra(TvPlayerActivity.EXTRA_AUTO_SKIP_OP, call.argument<Boolean>("autoSkipOp") ?: false)
            intent.putExtra(TvPlayerActivity.EXTRA_AUTO_SKIP_RECAP, call.argument<Boolean>("autoSkipRecap") ?: false)
            intent.putExtra(TvPlayerActivity.EXTRA_AUTO_SKIP_ED, call.argument<Boolean>("autoSkipEd") ?: false)
            intent.putExtra(
                TvPlayerActivity.EXTRA_AUTO_SKIP_FILLER,
                call.argument<Boolean>("autoSkipFiller") ?: false,
            )
            call.argument<List<*>>("fillerFlags")?.let { raw ->
                intent.putExtra(
                    TvPlayerActivity.EXTRA_FILLER_FLAGS,
                    raw.map { it == true }.toBooleanArray(),
                )
            }

            // Seek Buttons
            intent.putExtra(TvPlayerActivity.ENABLE_SEEK_BUTTONS, call.argument<Boolean>(TvPlayerActivity.ENABLE_SEEK_BUTTONS) ?: true)
            intent.putExtra(TvPlayerActivity.SEEK_BUTTON_DURATION, (call.argument<Int>(TvPlayerActivity.SEEK_BUTTON_DURATION) ?: 10).toLong())

            val headers = call.argument<Map<String, String>>("headers")
            if (!headers.isNullOrEmpty()) {
                val arr = ArrayList<String>()
                for ((k, v) in headers) { arr.add(k); arr.add(v) }
                intent.putExtra(TvPlayerActivity.EXTRA_HEADERS, arr.toTypedArray())
            }
            val subs = call.argument<List<Map<String, String>>>("subtitles")
            if (!subs.isNullOrEmpty()) {
                intent.putExtra(TvPlayerActivity.EXTRA_SUB_URLS, subs.mapNotNull { it["url"] }.toTypedArray())
                intent.putExtra(TvPlayerActivity.EXTRA_SUB_LANGS, subs.map { it["lang"] ?: "" }.toTypedArray())
                intent.putExtra(TvPlayerActivity.EXTRA_SUB_LABELS, subs.map { it["label"] ?: "" }.toTypedArray())
            }

            pendingTvResult?.let { try { it.success(mapOf("launched" to true, "positionMs" to 0L)) } catch (_: Exception) {} }
            pendingTvResult = result
            startActivityForResult(intent, TV_PLAYER_REQUEST)
        } catch (e: Exception) {
            Log.w(TAG, "launchTvPlayer failed: ${e.message}")
            pendingTvResult = null
            result.success(mapOf("launched" to false))
        }
    }

    // Launch the system voice-recognition dialog for TV search. The result
    // (recognised phrase, or null on cancel/none) comes back in onActivityResult.
    private fun startVoiceSearch(prompt: String?, result: MethodChannel.Result) {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                )
                putExtra(RecognizerIntent.EXTRA_PROMPT, prompt ?: "Speak the title")
            }
            if (intent.resolveActivity(packageManager) == null) {
                result.error("voice_unavailable", "Voice search is unavailable", null)
                return
            }
            // Complete any stale pending dialog defensively, then wait for this one.
            pendingVoiceResult?.let { try { it.success(null) } catch (_: Exception) {} }
            pendingVoiceResult = result
            startActivityForResult(intent, VOICE_SEARCH_REQUEST)
        } catch (e: Exception) {
            Log.w(TAG, "startVoiceSearch failed: ${e.message}")
            pendingVoiceResult = null
            result.error("voice_failed", "Could not start voice search", null)
        }
    }

    /// Force the leanback / soft keyboard up. Flutter's TextInput.show alone is
    /// frequently cancelled on TV after a readOnly→editable upgrade; calling
    /// both IMM and the insets controller covers OEM differences. Must target
    /// the FlutterView that owns the InputConnection — decorView is ignored.
    private fun showImeForced() {
        try {
            val root = window?.decorView ?: return
            val view = findFlutterView(root) ?: root
            view.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            @Suppress("DEPRECATION")
            imm.showSoftInput(view, InputMethodManager.SHOW_FORCED)
            WindowCompat.getInsetsController(window, view)
                .show(WindowInsetsCompat.Type.ime())
        } catch (e: Exception) {
            Log.w(TAG, "showImeForced failed: ${e.message}")
        }
    }

    private fun findFlutterView(view: View): View? {
        if (view.javaClass.name.contains("FlutterView")) return view
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                findFlutterView(view.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    // Reads a position/duration extra whether the player stored it as Long or Int.
    private fun longExtra(data: Intent, vararg keys: String): Long {
        for (k in keys) {
            val v = data.extras?.get(k)
            if (v is Long) return v
            if (v is Int) return v.toLong()
        }
        return -1L
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // Flutter plugins (SAF folder picker, image picks) get their results
        // through the fragment; our own request codes are handled below.
        flutterFragment.onActivityResult(requestCode, resultCode, data)
        if (requestCode == TV_PLAYER_REQUEST) {
            val pos = if (data != null) longExtra(data, TvPlayerActivity.RESULT_POSITION) else -1L
            val dur = if (data != null) longExtra(data, TvPlayerActivity.RESULT_DURATION) else -1L
            val epIndex = data?.getIntExtra(TvPlayerActivity.RESULT_EP_INDEX, 0) ?: 0
            val playbackError = data?.getBooleanExtra(TvPlayerActivity.RESULT_PLAYBACK_ERROR, false) ?: false
            pendingTvResult?.let {
                try {
                    it.success(
                        mapOf(
                            "launched" to true,
                            "positionMs" to (if (pos > 0) pos else 0L),
                            "durationMs" to (if (dur > 0) dur else 0L),
                            "episodeIndex" to epIndex,
                            "playbackError" to playbackError,
                        ),
                    )
                } catch (_: Exception) {}
            }
            pendingTvResult = null
            return
        }
        if (requestCode == VOICE_SEARCH_REQUEST) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            pendingVoiceResult?.let {
                try {
                    when {
                        resultCode == RESULT_CANCELED -> it.success(null)
                        resultCode != RESULT_OK ->
                            it.error("voice_failed", "Voice recognition failed", null)
                        text.isNullOrBlank() ->
                            it.error("voice_no_match", "No title recognised", null)
                        else -> it.success(text)
                    }
                } catch (_: Exception) {}
            }
            pendingVoiceResult = null
            return
        }
        if (requestCode != EXT_PLAYER_REQUEST) return
        val pos = if (data != null) longExtra(data, "position", "extra_position") else -1L
        val dur = if (data != null) longExtra(data, "duration", "extra_duration") else -1L
        // "Played" = the player reported real progress or that it loaded the
        // media. Nothing reported → it failed / was dismissed → Dart falls back.
        val played = pos > 0 || dur > 0
        pendingPlayerResult?.let {
            try {
                it.success(
                    mapOf(
                        "launched" to true,
                        "played" to played,
                        "positionMs" to (if (pos > 0) pos else 0L),
                    ),
                )
            } catch (_: Exception) {}
        }
        pendingPlayerResult = null
    }

    private fun ensureRetriever(
        url: String,
        headers: Map<String, String>?,
    ): MediaMetadataRetriever? {
        if (retriever != null && currentUrl == url) return retriever
        releaseRetriever()
        val r = MediaMetadataRetriever()
        try {
            Log.d(TAG, "setDataSource url=$url headers=${headers?.keys}")
            when {
                url.startsWith("http") -> r.setDataSource(url, headers ?: emptyMap())
                url.startsWith("content://") -> r.setDataSource(this, Uri.parse(url))
                url.startsWith("file://") -> r.setDataSource(url.removePrefix("file://"))
                else -> r.setDataSource(url)
            }
            Log.d(TAG, "setDataSource OK")
        } catch (e: Exception) {
            Log.w(TAG, "setDataSource FAILED: ${e.message}")
            try { r.release() } catch (_: Exception) {}
            return null
        }
        retriever = r
        currentUrl = url
        return r
    }

    private fun extractFrame(
        url: String,
        positionMs: Long,
        headers: Map<String, String>?,
        maxWidth: Int,
    ): ByteArray? {
        return try {
            val r = ensureRetriever(url, headers) ?: return null
            val timeUs = positionMs * 1000L
            val bmp: Bitmap = (
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                        r.getScaledFrameAtTime(
                            timeUs,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                            maxWidth,
                            maxWidth,
                        )
                    } else {
                        r.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?.let { scaleDown(it, maxWidth) }
                    }
                    ) ?: run {
                Log.w(TAG, "frame NULL (decoder returned no bitmap) pos=${positionMs}ms")
                return null
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 70, out)
            bmp.recycle()
            val bytes = out.toByteArray()
            Log.d(TAG, "frame OK pos=${positionMs}ms bytes=${bytes.size}")
            bytes
        } catch (e: Exception) {
            Log.w(TAG, "frame FAILED pos=${positionMs}ms: ${e.message}")
            null
        }
    }

    private fun scaleDown(src: Bitmap, maxWidth: Int): Bitmap {
        if (src.width <= maxWidth) return src
        val ratio = src.height.toFloat() / src.width.toFloat()
        val h = (maxWidth * ratio).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(src, maxWidth, h, true)
        if (scaled != src) src.recycle()
        return scaled
    }

    private fun releaseRetriever() {
        try { retriever?.release() } catch (_: Exception) {}
        retriever = null
        currentUrl = null
    }

    override fun onDestroy() {
        playerOrientationObserver?.disable()
        playerOrientationObserver = null
        discordPresence?.dispose()
        discordPresence = null
        phoneVoiceSearch?.dispose()
        phoneVoiceSearch = null
        pip.unregister()
        releaseRetriever()
        executor.shutdown()
        csExecutor.shutdown()
        csReadPool.shutdown()
        csPlayPool.shutdown()
        castManager?.release()
        tvBridge = null
        PhonePlayerBridge.dispose()
        if (com.lagradost.cloudstream3.CommonActivity.activity === this) {
            com.lagradost.cloudstream3.CommonActivity.setActivityInstance(null)
        }
        super.onDestroy()
    }

    // ── Background "new episode" subscriptions (CloudStream-style) ─────────────

    /** Merge the CS subscriptions mirrored from Dart into the native store,
     *  PRESERVING the background worker's advanced episode counts (only brand-new
     *  subs take the incoming baseline), then (re)schedule the periodic worker. */
    private fun mergeSubscriptions(incoming: List<Map<String, Any?>>) {
        val prefs = getSharedPreferences("zangetsu_cs", android.content.Context.MODE_PRIVATE)
        val existing = runCatching {
            org.json.JSONArray(prefs.getString("subscriptions", "[]"))
        }.getOrDefault(org.json.JSONArray())
        val counts = HashMap<String, Int>()
        for (i in 0 until existing.length()) {
            val o = existing.getJSONObject(i)
            counts["${o.optString("apiName")}|${o.optString("url")}"] = o.optInt("lastCount", 0)
        }
        val merged = org.json.JSONArray()
        for (m in incoming) {
            val apiName = m["apiName"]?.toString() ?: continue
            val url = m["url"]?.toString() ?: continue
            if (apiName.isEmpty() || url.isEmpty()) continue
            val last = counts["$apiName|$url"] ?: ((m["lastCount"] as? Number)?.toInt() ?: 0)
            merged.put(
                org.json.JSONObject()
                    .put("apiName", apiName)
                    .put("url", url)
                    .put("title", m["title"]?.toString() ?: "")
                    .put("lastCount", last),
            )
        }
        prefs.edit().putString("subscriptions", merged.toString()).apply()
        scheduleSubscriptionWorker(merged.length() > 0)
    }

    private fun scheduleSubscriptionWorker(hasSubs: Boolean) {
        val wm = WorkManager.getInstance(applicationContext)
        if (!hasSubs) {
            wm.cancelUniqueWork("zangetsu_sub_check")
            return
        }
        val req = PeriodicWorkRequestBuilder<SubscriptionWorker>(6, TimeUnit.HOURS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
            .build()
        wm.enqueueUniquePeriodicWork(
            "zangetsu_sub_check",
            ExistingPeriodicWorkPolicy.KEEP,
            req,
        )
    }
}
