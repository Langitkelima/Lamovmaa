import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';

part 'video_source.g.dart';

/// Stream container. `unknown` lets a provider omit the hint; the player
/// then sniffs by URL extension.
enum SourceContainer {
  @JsonValue('hls')
  hls,
  @JsonValue('mp4')
  mp4,
  @JsonValue('torrent')
  torrent,
  @JsonValue('unknown')
  unknown,
}

/// Audio track intent for a source. Drives the sub/dub picker.
enum AudioKind {
  @JsonValue('sub')
  sub,
  @JsonValue('dub')
  dub,
  @JsonValue('raw')
  raw,
  @JsonValue('unknown')
  unknown,
}

@JsonSerializable()
class Subtitle extends Equatable {
  final String url;
  final String lang;
  final String? label;

  @JsonKey(includeIfNull: false)
  final String? providerName;

  /// `'vtt'` or `'srt'`. Free-form so a source can pass through anything
  /// the player accepts.
  final String? format;

  @JsonKey(name: 'default', defaultValue: false)
  final bool isDefault;

  const Subtitle({
    required this.url,
    required this.lang,
    this.label,
    this.format,
    this.providerName,
    this.isDefault = false,
  });

  factory Subtitle.fromJson(Map<String, dynamic> json) =>
      _$SubtitleFromJson(json);
  Map<String, dynamic> toJson() => _$SubtitleToJson(this);

  String get displayLabel => providerName?.trim().isNotEmpty == true
      ? '${label ?? lang} · $providerName'
      : label ?? lang;

  @override
  List<Object?> get props => [
    url,
    lang,
    label,
    format,
    isDefault,
    providerName,
  ];
}

/// A single playable stream for an episode. The video-native analogue of
/// Sozo Read's `PageContent`. A provider returns a LIST of these; the UI
/// filters by [kind]/[audioLang]/[quality].
@JsonSerializable(explicitToJson: true)
class VideoSource extends Equatable {
  final String url;
  final String? quality;

  /// Optional human-friendly name for this stream, shown in the player's
  /// Sources sheet (e.g. "4K HDHub · FSL Server [WEB-DL] [2GB]"). When absent
  /// the sheet falls back to the quality / container. Lets a provider that
  /// exposes many mirrors label each one distinctly instead of every row
  /// reading the same "2160p".
  final String? label;

  @JsonKey(
    unknownEnumValue: SourceContainer.unknown,
    defaultValue: SourceContainer.unknown,
  )
  final SourceContainer container;

  final Map<String, String>? headers;

  @JsonKey(unknownEnumValue: AudioKind.unknown, defaultValue: AudioKind.unknown)
  final AudioKind kind;

  final String? audioLang;

  @JsonKey(defaultValue: <Subtitle>[])
  final List<Subtitle> subtitles;

  /// Seconds to add to soft-subtitle cue times when the VTT pack's opening is
  /// shorter/longer than the playing video (MegaPlay cross-encode dub+sub).
  /// Measured from pack `intro`/`outro` markers — not a user preference.
  final double? subtitleSkewSeconds;

  /// Only cues with file start ≥ this (VTT-pack intro end) receive
  /// [subtitleSkewSeconds], so pre-OP dialogue stays aligned.
  final double? subtitleSkewAfterSeconds;

  /// Hidden local-proxy fallback URL (Aniyomi only): when the direct stream is
  /// Cloudflare-blocked and won't start, the player transparently re-opens this
  /// same quality via the proxy. Not serialized and NOT a separate picker entry —
  /// set only at resolution time. `@JsonKey(includeFromJson/ToJson: false)` keeps
  /// it out of the generated (de)serialization so no codegen change is needed.
  @JsonKey(includeFromJson: false, includeToJson: false)
  final String? proxyUrl;

  /// Explicit torrent file choice for a magnet built from a Stremio link.
  /// Runtime-only: never serialized, never inferred.
  @JsonKey(includeFromJson: false, includeToJson: false)
  final int? torrentFileIndex;

  /// Stremio `behaviorHints.bingeGroup` carried from the played link.
  /// Runtime-only: used to match the same release family on the next episode.
  @JsonKey(includeFromJson: false, includeToJson: false)
  final String? bingeGroup;

  /// ClearKey DRM key id + key (base64url, no padding — the exact JWK form
  /// ExoPlayer wants), set only for encrypted CENC/DASH sources (e.g. CNC/PlayzTV
  /// live channels). mpv can't decrypt DRM, so a source with these is routed to
  /// the native ExoPlayer player instead. Not serialized (resolution-time only).
  @JsonKey(includeFromJson: false, includeToJson: false)
  final String? drmKid;
  @JsonKey(includeFromJson: false, includeToJson: false)
  final String? drmKey;

  /// True when this is an encrypted source only ExoPlayer (not mpv) can play.
  bool get isDrm =>
      (drmKid?.isNotEmpty ?? false) && (drmKey?.isNotEmpty ?? false);

  const VideoSource({
    required this.url,
    this.quality,
    this.label,
    this.container = SourceContainer.unknown,
    this.headers,
    this.kind = AudioKind.unknown,
    this.audioLang,
    this.subtitles = const [],
    this.subtitleSkewSeconds,
    this.subtitleSkewAfterSeconds,
    this.proxyUrl,
    this.torrentFileIndex,
    this.bingeGroup,
    this.drmKid,
    this.drmKey,
  });

  VideoSource withSubtitles(List<Subtitle> tracks) => VideoSource(
    url: url,
    quality: quality,
    label: label,
    container: container,
    headers: headers,
    kind: kind,
    audioLang: audioLang,
    subtitles: tracks,
    subtitleSkewSeconds: subtitleSkewSeconds,
    subtitleSkewAfterSeconds: subtitleSkewAfterSeconds,
    proxyUrl: proxyUrl,
    torrentFileIndex: torrentFileIndex,
    bingeGroup: bingeGroup,
    drmKid: drmKid,
    drmKey: drmKey,
  );

  factory VideoSource.fromJson(Map<String, dynamic> json) =>
      _$VideoSourceFromJson(json);
  Map<String, dynamic> toJson() => _$VideoSourceToJson(this);

  @override
  List<Object?> get props => [
    url,
    quality,
    label,
    container,
    headers,
    kind,
    audioLang,
    subtitles,
    torrentFileIndex,
    bingeGroup,
    subtitleSkewSeconds,
    subtitleSkewAfterSeconds,
  ];
}
