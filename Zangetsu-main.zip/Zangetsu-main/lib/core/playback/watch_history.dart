import 'dart:convert';
import 'package:watch_app/core/hive/safe_box.dart';
import 'package:watch_app/core/hive/hive_key.dart';

import 'package:hive/hive.dart';
import 'package:supabase_flutter/supabase_flutter.dart'
    show PostgrestClient, PostgrestQueryBuilder;

import '../privacy/incognito_mode.dart';
import '../profiles/profile_scope.dart';
import '../supabase/cloud_postgrest.dart';
import '../supabase/supabase_service.dart';

class HistoryEntry {
  HistoryEntry({
    required this.sourceId,
    required this.showId,
    required this.showTitle,
    this.cover,
    this.coverHeaders,
    this.thumbnail,
    required this.showUrl,
    required this.category,
    required this.episodeId,
    required this.episodeNumber,
    required this.episodeUrl,
    required this.position,
    required this.duration,
    required this.updatedAt,
    this.malId,
  });
  final String sourceId,
      showId,
      showTitle,
      showUrl,
      category,
      episodeId,
      episodeUrl;
  final String? cover;
  final Map<String, String>? coverHeaders;

  /// Landscape episode thumbnail (16:9) for the Continue Watching card. Local
  /// only (not cloud-synced) — a resumed entry from another device falls back
  /// to [cover]. Null for older entries and sources without episode thumbnails.
  final String? thumbnail;
  final double? episodeNumber;

  /// MyAnimeList id (anime), carried so a resume from Continue Watching can
  /// still auto-scrobble to AniList.
  final int? malId;
  final Duration position, duration;
  final int updatedAt;
  bool get finished =>
      duration.inMilliseconds > 0 &&
      position.inMilliseconds >= duration.inMilliseconds * 0.92;
  double get progress => duration.inMilliseconds == 0
      ? 0
      : (position.inMilliseconds / duration.inMilliseconds).clamp(0.0, 1.0);
}

/// Thin transport seam over the cloud `history` table, injectable so
/// [WatchHistory]'s throttle/flush logic is unit-testable without a live
/// backend. When no VPS client is supplied, it uses Supabase for rollback builds.
class HistoryRemote {
  HistoryRemote(
    SupabaseService service, {
    PostgrestClient? vpsClient,
    String? Function()? accessToken,
  }) : _cloud = CloudPostgrest(
         service,
         vpsClient: vpsClient,
         accessToken: accessToken,
       );

  final CloudPostgrest _cloud;

  PostgrestQueryBuilder _from(String table) => _cloud.from(table);

  static const int pageSize = 200;
  static const int _seedPageSize = 1000;
  static const String _historyColumns =
      'source_id,show_id,show_title,cover,cover_headers,show_url,category,episode_id,episode_number,episode_url,position_ms,duration_ms,updated_at,mal_id';

  Future<void> upsert(Map<String, dynamic> row) async {
    final profileId = row['profile_id'] as String?;
    final table = profileId == null ? 'history' : 'profile_history';
    final conflict = profileId == null
        ? 'user_key,source_id,show_id'
        : 'user_key,profile_id,source_id,show_id';
    await _from(table).upsert(row, onConflict: conflict);
  }

  Future<Map<String, dynamic>?> getFor(
    String userKey, {
    String? profileId,
    required String sourceId,
    required String showId,
  }) async {
    final table = profileId == null ? 'history' : 'profile_history';
    var query = _from(table)
        .select(_historyColumns)
        .eq('user_key', userKey)
        .eq('source_id', sourceId)
        .eq('show_id', showId);
    if (profileId != null) query = query.eq('profile_id', profileId);
    final row = await query.maybeSingle();
    return (row as Map?)?.cast<String, dynamic>();
  }

  Future<void> deleteRow(
    String userKey,
    String sourceId,
    String showId, {
    String? profileId,
  }) async {
    final table = profileId == null ? 'history' : 'profile_history';
    await _from(table).delete().match({
      'user_key': userKey,
      'source_id': sourceId,
      'show_id': showId,
      'profile_id': ?profileId,
    });
  }

  /// Delete EVERY history row for [userKey] — used by "Clear history" so it
  /// can't sync back on the next pull.
  Future<void> deleteAllFor(String userKey, {String? profileId}) async {
    final table = profileId == null ? 'history' : 'profile_history';
    var query = _from(table).delete().eq('user_key', userKey);
    if (profileId != null) query = query.eq('profile_id', profileId);
    await query;
  }

  Future<List<Map<String, dynamic>>> listFor(
    String userKey, {
    String? profileId,
  }) async {
    final table = profileId == null ? 'history' : 'profile_history';
    final rows = <Map<String, dynamic>>[];
    var offset = 0;
    while (true) {
      var query = _from(
        table,
      ).select('source_id,show_id,updated_at').eq('user_key', userKey);
      if (profileId != null) query = query.eq('profile_id', profileId);
      final page =
          (await query
                      .order('source_id')
                      .order('show_id')
                      .range(offset, offset + _seedPageSize - 1)
                  as List)
              .cast<Map<String, dynamic>>();
      if (page.isEmpty) break;
      rows.addAll(page);
      offset += page.length;
      if (page.length < _seedPageSize) break;
    }
    return rows;
  }

  /// shortcut: offset pages may drift during concurrent cloud edits; switch to
  /// keyset cursors if users observe skipped rows while scrolling.
  Future<List<Map<String, dynamic>>> pageFor(
    String userKey, {
    String? profileId,
    required int offset,
  }) async {
    final table = profileId == null ? 'history' : 'profile_history';
    var query = _from(table).select(_historyColumns).eq('user_key', userKey);
    if (profileId != null) query = query.eq('profile_id', profileId);
    final page =
        (await query
                    .order('updated_at', ascending: false)
                    .order('source_id')
                    .order('show_id')
                    .range(offset, offset + pageSize - 1)
                as List)
            .cast<Map<String, dynamic>>();
    return page;
  }
}

/// Continue Watching, backed by Hive for instant local reads and synced to
/// Supabase when signed in. Cloud writes are throttled per show (the player
/// persists every ~5s) so we don't hammer the backend.
class WatchHistory {
  WatchHistory(
    SupabaseService service,
    this._currentUserId, {
    HistoryRemote? remote,
    String? Function()? currentProfileId,
    String backendNamespace = '',
  }) : _remote = remote ?? HistoryRemote(service),
       _currentProfileId = currentProfileId,
       _backendNamespace = backendNamespace;

  final HistoryRemote _remote;
  final String? Function() _currentUserId;
  final String? Function()? _currentProfileId;
  final String _backendNamespace;
  String _metadataKey(String key) =>
      _backendNamespace.isEmpty ? key : '${key}_$_backendNamespace';
  String get _profileId => _currentProfileId?.call() ?? kDefaultProfileId;
  String? _remoteProfileId(String id) => id == kDefaultProfileId ? null : id;

  static const String boxName = 'watch_history';
  // Cloud progress-sync throttle. The player calls [save] every ~1s during
  // playback, but each of those was a cloud write every 15s per show — ~96
  // writes for one 24-min episode, which blows through free-tier database
  // write quotas fast. Local saves stay instant (resume is unaffected); the
  // CLOUD push is throttled to 2 min, and forced on pause/stop/episode
  // change/close (see [save]'s `flush`) so the resume point stays accurate.
  static const int _cloudThrottleMs = 120000;

  /// Shared box holding the last successful cloud-pull timestamp (see
  /// [MyListStore.syncMetaBox]) so app-launch pulls can be throttled.
  static const String syncMetaBox = 'library_sync_meta';
  static const String _syncMetaKey = 'history_lastPullMs';
  static const String _cloudPagePrefix = 'watch_history_page:';
  static const String _pendingKey = 'watch_history_pending';

  static Future<void> init() async {
    if (!Hive.isBoxOpen(boxName)) {
      await openBoxSafely<Map>(boxName);
    }
    if (!Hive.isBoxOpen(syncMetaBox)) {
      await openBoxSafely(syncMetaBox);
    }
    // Same reasoning as MyListStore.init: an unreadable history box reopens
    // empty while the pull throttle in [syncMetaBox] survives, which would
    // skip the very pull that puts the history back. Drop it.
    if (quarantinedBoxes.contains(boxName) && Hive.isBoxOpen(syncMetaBox)) {
      final meta = Hive.box(syncMetaBox);
      await meta.delete(_syncMetaKey);
      for (final key in meta.keys.toList()) {
        final value = '$key';
        if (value.contains(_cloudPagePrefix) ||
            value.contains(_pendingKey) ||
            value.contains(_syncMetaKey)) {
          await meta.delete(key);
        }
      }
    }
  }

  Box<Map> get _box => Hive.box<Map>(boxName);
  String _key(String sourceId, String showId, [String? profileId]) =>
      profileScopedKey(profileId ?? _profileId, hiveKey('$sourceId::$showId'));

  String _cloudPageKey(String userId, String profileId) => profileScopedKey(
    profileId,
    '$_cloudPagePrefix${_backendNamespace.isEmpty ? '' : 'vps:'}${hiveKey(userId)}',
  );

  String _pendingMetaKey([String? profileId]) =>
      profileScopedKey(profileId ?? _profileId, _pendingKey);

  Set<String> pendingKeys([String? profileId]) {
    if (!Hive.isBoxOpen(syncMetaBox)) return <String>{};
    final raw = Hive.box(syncMetaBox).get(_pendingMetaKey(profileId));
    return raw is List ? raw.map((value) => '$value').toSet() : <String>{};
  }

  Future<void> _markPending(String key, String profileId) async {
    if (!Hive.isBoxOpen(syncMetaBox)) return;
    final pending = pendingKeys(profileId)..add(key);
    await Hive.box(
      syncMetaBox,
    ).put(_pendingMetaKey(profileId), pending.toList());
  }

  Future<void> _clearPending(String key, String profileId) async {
    if (!Hive.isBoxOpen(syncMetaBox)) return;
    final pending = pendingKeys(profileId);
    if (pending.remove(key)) {
      await Hive.box(
        syncMetaBox,
      ).put(_pendingMetaKey(profileId), pending.toList());
    }
  }

  Map _cloudPageState(String userId, String profileId) {
    if (!Hive.isBoxOpen(syncMetaBox)) return const {};
    final state = Hive.box(syncMetaBox).get(_cloudPageKey(userId, profileId));
    return state is Map ? state : const {};
  }

  bool hasMoreCloudPages({String? forProfileId}) {
    final uid = _currentUserId();
    if (uid == null) return false;
    final profileId = forProfileId ?? _profileId;
    return _cloudPageState(uid, profileId)['hasMore'] as bool? ?? true;
  }

  Future<void> _saveCloudPageState(
    String userId,
    String profileId, {
    required int offset,
    required bool hasMore,
  }) async {
    if (!Hive.isBoxOpen(syncMetaBox)) return;
    await Hive.box(syncMetaBox).put(_cloudPageKey(userId, profileId), {
      'offset': offset,
      'hasMore': hasMore,
    });
  }

  final Map<String, int> _lastCloudPush = {};

  /// Persist progress. The local write is ALWAYS immediate (instant resume);
  /// the cloud push is throttled unless [flush] is true, which forces it on the
  /// moments that matter for an accurate cross-device resume — pause, stop,
  /// episode change, and player close.
  Future<void> save(HistoryEntry e, {bool flush = false}) async {
    if (IncognitoMode.on) return; // incognito: don't record what's watched
    final profileId = _profileId;
    final key = _key(e.sourceId, e.showId, profileId);
    await _box.put(key, {
      'sourceId': e.sourceId,
      'showId': e.showId,
      'showTitle': e.showTitle,
      'cover': e.cover,
      'coverHeaders': e.coverHeaders,
      'thumbnail': e.thumbnail,
      'showUrl': e.showUrl,
      'category': e.category,
      'episodeId': e.episodeId,
      'episodeNumber': e.episodeNumber,
      'episodeUrl': e.episodeUrl,
      'positionMs': e.position.inMilliseconds,
      'durationMs': e.duration.inMilliseconds,
      'updatedAt': e.updatedAt,
      'malId': e.malId,
    });
    if (flush) {
      await _pushToCloud(key, e, profileId, force: true);
    } else {
      _pushToCloud(key, e, profileId);
    }
  }

  /// Throttled, best-effort cloud upsert. [force] bypasses the throttle for
  /// the flush moments (see [save]).
  Map<String, dynamic> _rowFor(String uid, HistoryEntry e, String profileId) =>
      {
        'user_key': uid,
        if (profileId != kDefaultProfileId) 'profile_id': profileId,
        'source_id': e.sourceId,
        'show_id': e.showId,
        'show_title': e.showTitle,
        'cover': e.cover,
        'cover_headers': e.coverHeaders,
        'show_url': e.showUrl,
        'category': e.category,
        'episode_id': e.episodeId,
        'episode_number': e.episodeNumber,
        'episode_url': e.episodeUrl,
        'position_ms': e.position.inMilliseconds,
        'duration_ms': e.duration.inMilliseconds,
        'updated_at': e.updatedAt,
        'mal_id': e.malId?.toString(),
      };

  Future<void> _pushToCloud(
    String key,
    HistoryEntry e,
    String profileId, {
    bool force = false,
  }) async {
    final uid = _currentUserId();
    if (uid == null) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    final last = _lastCloudPush[key] ?? 0;
    if (!force && now - last < _cloudThrottleMs) return;
    _lastCloudPush[key] = now;
    final pendingWrite = _markPending(key, profileId);
    try {
      await Future.wait([
        pendingWrite,
        _remote.upsert(_rowFor(uid, e, profileId)),
      ]);
      if (_matchesLocalEntry(key, e)) await _clearPending(key, profileId);
    } catch (_) {
      /* best-effort */
    }
  }

  bool _matchesLocalEntry(String key, HistoryEntry entry) {
    final raw = _box.get(key);
    return raw != null &&
        raw['updatedAt'] == entry.updatedAt &&
        raw['episodeId'] == entry.episodeId &&
        raw['positionMs'] == entry.position.inMilliseconds &&
        raw['durationMs'] == entry.duration.inMilliseconds;
  }

  /// Retry only rows whose last cloud upsert failed. The local Hive row is the
  /// payload source so repeated player saves collapse to the newest progress.
  Future<void> retryPending() async {
    final uid = _currentUserId();
    if (uid == null) return;
    final profileId = _profileId;
    for (final key in pendingKeys(profileId)) {
      final raw = _box.get(key);
      if (raw == null) {
        await _clearPending(key, profileId);
        continue;
      }
      try {
        final entry = _fromMap(raw);
        final cloud = await _remote.getFor(
          uid,
          profileId: _remoteProfileId(profileId),
          sourceId: entry.sourceId,
          showId: entry.showId,
        );
        final cloudUpdated = (cloud?['updated_at'] as num?)?.toInt() ?? -1;
        if (cloud != null && cloudUpdated > entry.updatedAt) {
          await _mergeCloudRows([cloud], profileId);
          final currentUpdated =
              (_box.get(key)?['updatedAt'] as num?)?.toInt() ?? -1;
          if (currentUpdated == cloudUpdated) {
            await _clearPending(key, profileId);
          }
          continue;
        }
        await _remote.upsert(_rowFor(uid, entry, profileId));
        if (_matchesLocalEntry(key, entry)) await _clearPending(key, profileId);
      } catch (_) {
        /* keep pending for a later attempt */
      }
    }
  }

  HistoryEntry _fromMap(Map raw) {
    final m = Map<String, dynamic>.from(raw);
    return HistoryEntry(
      sourceId: m['sourceId'] as String,
      showId: m['showId'] as String,
      showTitle: m['showTitle'] as String? ?? '',
      cover: m['cover'] as String?,
      coverHeaders: (m['coverHeaders'] as Map?)?.map(
        (k, v) => MapEntry('$k', '$v'),
      ),
      thumbnail: m['thumbnail'] as String?,
      showUrl: m['showUrl'] as String? ?? '',
      category: m['category'] as String? ?? 'sub',
      episodeId: m['episodeId'] as String? ?? '',
      episodeNumber: (m['episodeNumber'] as num?)?.toDouble(),
      episodeUrl: m['episodeUrl'] as String? ?? '',
      position: Duration(milliseconds: (m['positionMs'] as num?)?.toInt() ?? 0),
      duration: Duration(milliseconds: (m['durationMs'] as num?)?.toInt() ?? 0),
      updatedAt: (m['updatedAt'] as num?)?.toInt() ?? 0,
      malId: (m['malId'] as num?)?.toInt(),
    );
  }

  /// Newest-first, excluding finished episodes (the Continue Watching feed).
  List<HistoryEntry> recent({int limit = 20}) {
    final all = _entriesFor(_profileId).where((e) => !e.finished).toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return all.take(limit).toList();
  }

  /// Every watched show, newest-first, including finished ones — the full
  /// History screen (Continue Watching only surfaces the unfinished subset).
  List<HistoryEntry> all() {
    return _entriesFor(_profileId)
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  List<HistoryEntry> _entriesFor(String profileId) => [
    for (final key in _box.keys)
      if (profileOwnsKey(key, profileId)) _fromMap(_box.get(key)!),
  ];

  static const String _seedFlagPrefix = 'history_seeded_';

  /// Uploads local history to the cloud under the CURRENT account, newest-wins:
  /// a row is pushed only when the cloud lacks it or the local copy is newer, so
  /// this can never regress progress that another device saved more recently.
  /// Additive — deletes nothing. Used to seed a fresh device or backfill a
  /// library orphaned by the Appwrite→Supabase move (rows kept their old id, so
  /// a new login couldn't read them). Returns (pushed, failed): `failed` counts
  /// upserts that errored (or a cloud read that failed), so the caller can tell
  /// whether the push was complete.
  Future<({int pushed, int failed})> pushAllLocalToCloud() async {
    final uid = _currentUserId();
    if (uid == null) return (pushed: 0, failed: 0);
    final profileId = _profileId;
    // What the cloud already has, and how fresh — so we don't clobber newer.
    final cloudTimes = <String, int>{};
    var readOk = true;
    try {
      for (final m in await _remote.listFor(
        uid,
        profileId: _remoteProfileId(profileId),
      )) {
        cloudTimes[_key('${m['source_id']}', '${m['show_id']}', profileId)] =
            (m['updated_at'] as num?)?.toInt() ?? 0;
      }
    } catch (_) {
      readOk = false; // couldn't read cloud — treat as incomplete below
    }
    var pushed = 0, failed = 0;
    for (final e in _entriesFor(profileId)) {
      final key = _key(e.sourceId, e.showId, profileId);
      final cloudT = cloudTimes[key];
      if (cloudT != null && cloudT >= e.updatedAt) continue; // cloud same/newer
      try {
        await _remote.upsert(_rowFor(uid, e, profileId));
        pushed++;
        if (_matchesLocalEntry(key, e)) await _clearPending(key, profileId);
      } catch (_) {
        failed++;
      }
    }
    if (!readOk) failed++;
    return (pushed: pushed, failed: failed);
  }

  /// One-time-per-account backfill: push the local history up BEFORE the first
  /// (destructive) [pullFromCloud] can run, so a sparse/orphaned cloud can't
  /// wipe a device's local Continue Watching. Guarded by a per-account flag in
  /// [syncMetaBox]; the flag is only set once a push completes with no failures,
  /// so an offline attempt retries next launch. No-op after it succeeds once.
  Future<void> seedCloudIfNeeded() async {
    final uid = _currentUserId();
    if (uid == null || !Hive.isBoxOpen(syncMetaBox)) return;
    final box = Hive.box(syncMetaBox);
    final profileId = _profileId;
    final flag = profileScopedKey(
      profileId,
      _metadataKey('$_seedFlagPrefix$uid'),
    );
    if (box.get(flag) == true) return;
    final r = await pushAllLocalToCloud();
    if (r.failed == 0) await box.put(flag, true);
  }

  /// Merge the signed-in user's cloud history into the local cache, newest-wins.
  /// NON-destructive by design: a local-only row (not yet pushed to the cloud) is
  /// kept, and a cloud row only overwrites a local one when it's strictly newer.
  /// This is deliberately a MERGE, not a replace — an empty/sparse cloud (a fresh
  /// device, a not-yet-seeded library, a session that goes live mid-boot) must
  /// NEVER be able to wipe a device's Continue Watching. Deletions propagate
  /// through [remove]/[clearAll] deleting the cloud row directly, not through a
  /// pull observing an absence.
  Future<void> pullFromCloud({String? forProfileId}) async {
    final uid = _currentUserId();
    if (uid == null) return;
    final profileId = forProfileId ?? _profileId;
    try {
      final rows = await _remote.pageFor(
        uid,
        profileId: _remoteProfileId(profileId),
        offset: 0,
      );
      await _mergeCloudRows(rows, profileId);
      final pageState = _cloudPageState(uid, profileId);
      final oldOffset = pageState['offset'] as int? ?? 0;
      await _saveCloudPageState(
        uid,
        profileId,
        offset: oldOffset < rows.length ? rows.length : oldOffset,
        hasMore: rows.length == HistoryRemote.pageSize,
      );
      _markPulled(profileId);
    } catch (_) {
      /* keep local */
    }
  }

  Future<bool> loadMoreFromCloud({String? forProfileId}) async {
    final uid = _currentUserId();
    if (uid == null) return false;
    final profileId = forProfileId ?? _profileId;
    final state = _cloudPageState(uid, profileId);
    if (state['hasMore'] == false) return false;
    final offset = state['offset'] as int? ?? 0;
    try {
      final rows = await _remote.pageFor(
        uid,
        profileId: _remoteProfileId(profileId),
        offset: offset,
      );
      await _mergeCloudRows(rows, profileId);
      await _saveCloudPageState(
        uid,
        profileId,
        offset: offset + rows.length,
        hasMore: rows.length == HistoryRemote.pageSize,
      );
      return rows.length == HistoryRemote.pageSize;
    } catch (_) {
      return true; // Keep the same cursor so the next scroll can retry.
    }
  }

  Future<void> _mergeCloudRows(
    List<Map<String, dynamic>> rows,
    String profileId,
  ) async {
    for (final m in rows) {
      final key = _key('${m['source_id']}', '${m['show_id']}', profileId);
      final cloudUpdated = (m['updated_at'] as num?)?.toInt() ?? 0;
      final localUpdated = (_box.get(key)?['updatedAt'] as num?)?.toInt() ?? -1;
      if (cloudUpdated <= localUpdated) continue;
      final headers = m['cover_headers'];
      await _box.put(key, {
        'sourceId': m['source_id'],
        'showId': m['show_id'],
        'showTitle': m['show_title'],
        'cover': m['cover'],
        'coverHeaders': headers is String
            ? jsonDecode(headers)
            : headers is Map
            ? headers
            : null,
        'showUrl': m['show_url'],
        'category': m['category'],
        'episodeId': m['episode_id'],
        'episodeNumber': m['episode_number'],
        'episodeUrl': m['episode_url'],
        'positionMs': m['position_ms'],
        'durationMs': m['duration_ms'],
        'updatedAt': m['updated_at'],
        'malId': int.tryParse('${m['mal_id']}'),
      });
      await _clearPending(key, profileId);
    }
  }

  /// Remove a single show from Continue Watching, locally and (when signed in)
  /// from the cloud so it doesn't sync back. Best-effort on the cloud side.
  Future<void> remove(String sourceId, String showId) async {
    final profileId = _profileId;
    final key = _key(sourceId, showId, profileId);
    await _box.delete(key);
    _lastCloudPush.remove(key);
    await _clearPending(key, profileId);
    final uid = _currentUserId();
    if (uid == null) return;
    try {
      await _remote.deleteRow(
        uid,
        sourceId,
        showId,
        profileId: _remoteProfileId(profileId),
      );
    } catch (_) {
      /* best-effort */
    }
  }

  /// Pull from cloud only when the last successful pull is older than [maxAge]
  /// — see [MyListStore.pullFromCloudIfStale]. Keeps app launches from
  /// re-downloading Continue Watching that's already cached locally.
  Future<void> pullFromCloudIfStale({
    Duration maxAge = const Duration(hours: 12),
  }) async {
    if (_currentUserId() == null) return;
    final profileId = _profileId;
    int? last;
    if (Hive.isBoxOpen(syncMetaBox)) {
      last =
          Hive.box(
                syncMetaBox,
              ).get(profileScopedKey(profileId, _metadataKey(_syncMetaKey)))
              as int?;
    }
    if (last != null) {
      final age = DateTime.now().millisecondsSinceEpoch - last;
      if (age >= 0 && age < maxAge.inMilliseconds) return; // still fresh
    }
    await pullFromCloud(forProfileId: profileId);
  }

  void _markPulled(String profileId) {
    if (Hive.isBoxOpen(syncMetaBox)) {
      Hive.box(syncMetaBox).put(
        profileScopedKey(profileId, _metadataKey(_syncMetaKey)),
        DateTime.now().millisecondsSinceEpoch,
      );
    }
  }

  /// Drop the local cache only. Used on LOGOUT — the cloud copy is the user's
  /// data and MUST survive, so this must never touch the cloud.
  Future<void> clearLocal() async {
    await _box.clear();
    if (Hive.isBoxOpen(syncMetaBox)) {
      final meta = Hive.box(syncMetaBox);
      await meta.delete(_syncMetaKey);
      for (final key in meta.keys.toList()) {
        final value = '$key';
        if (value.startsWith('p:') ||
            value.contains(_cloudPagePrefix) ||
            value.contains(_pendingKey)) {
          await meta.delete(key);
        }
      }
    }
  }

  /// User-initiated "Clear history": wipe Continue Watching EVERYWHERE — local
  /// AND the cloud — so a later pull can't restore it. (This is the difference
  /// from [clearLocal], which deliberately keeps the cloud copy on logout.)
  /// Deletes the cloud rows first so even a racing pull sees nothing.
  Future<void> clearAll() async {
    final uid = _currentUserId();
    final profileId = _profileId;
    if (uid != null) {
      try {
        await _remote.deleteAllFor(uid, profileId: _remoteProfileId(profileId));
      } catch (_) {
        /* best-effort — local still clears */
      }
    }
    _lastCloudPush.clear();
    for (final key in _box.keys.toList()) {
      if (profileOwnsKey(key, profileId)) await _box.delete(key);
    }
    if (Hive.isBoxOpen(syncMetaBox)) {
      final meta = Hive.box(syncMetaBox);
      await meta.delete(
        profileScopedKey(profileId, _metadataKey(_syncMetaKey)),
      );
      await meta.delete(_pendingMetaKey(profileId));
      if (uid != null) {
        await meta.delete(_cloudPageKey(uid, profileId));
      }
    }
  }
}
