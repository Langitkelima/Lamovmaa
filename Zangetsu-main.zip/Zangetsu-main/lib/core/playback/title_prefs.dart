import 'dart:convert';

import 'package:crypto/crypto.dart';

import '../models/video_source.dart';
import '../privacy/incognito_mode.dart';
import 'subtitle_language.dart';
import 'package:hive/hive.dart';
import 'package:watch_app/core/hive/safe_box.dart';
import 'package:watch_app/core/hive/hive_key.dart';

/// Remembers per-title user choices (currently the sub/dub category), keyed by
/// `"<sourceId>::<showUrl>"`. Netflix-style "remember my choice for this title".
class TitlePrefsStore {
  static const String boxName = 'title_prefs';
  static Future<void> init() async {
    if (!Hive.isBoxOpen(boxName)) {
      await openBoxSafely<Map>(boxName);
    }
  }

  Box<Map> get _box => Hive.box<Map>(boxName);
  String _key(String sourceId, String showUrl) =>
      hiveKey('$sourceId::$showUrl');

  String? category(String sourceId, String showUrl) {
    final m = _box.get(_key(sourceId, showUrl));
    final c = m == null ? null : Map<String, dynamic>.from(m)['category'];
    return (c == 'sub' || c == 'dub') ? c as String : null;
  }

  Future<void> setCategory(
    String sourceId,
    String showUrl,
    String category,
  ) async {
    final k = _key(sourceId, showUrl);
    final m = _box.get(k) == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(_box.get(k)!);
    m['category'] = category;
    await _box.put(k, m);
  }

  /// The label of the source the user last picked for this title (e.g. a
  /// language/server name). Used to re-select the same source on reopen for
  /// providers that expose languages as separate sources (e.g. 4khdhub).
  String? sourceLabel(String sourceId, String showUrl) {
    final m = _box.get(_key(sourceId, showUrl));
    final v = m == null ? null : Map<String, dynamic>.from(m)['sourceLabel'];
    return (v is String && v.isNotEmpty) ? v : null;
  }

  Future<void> setSourceLabel(
    String sourceId,
    String showUrl,
    String label,
  ) async {
    final k = _key(sourceId, showUrl);
    final m = _box.get(k) == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(_box.get(k)!);
    m['sourceLabel'] = label;
    await _box.put(k, m);
  }

  VideoSource? preferredStremioLink(
    String episodeUrl,
    List<VideoSource> sources, {
    String? showUrl,
  }) {
    final saved = _box.get(_key('stremio', episodeUrl));
    if (saved != null) {
      for (final source in sources) {
        if (sha256.convert(utf8.encode(source.url)).toString() ==
            saved['linkHash']) {
          return source;
        }
      }
      final label = saved['linkLabel'];
      if (label is String && label.isNotEmpty) {
        for (final source in sources) {
          if (source.label == label) return source;
        }
      }
    }
    final group = showUrl == null ? null : stremioBingeGroup(showUrl);
    if (group != null) {
      for (final source in sources) {
        if (source.bingeGroup == group) return source;
      }
    }
    return null;
  }

  Future<void> rememberStremioLink(
    String episodeUrl,
    VideoSource source,
  ) async {
    final key = _key('stremio', episodeUrl);
    await _box.put(key, {
      ...?_box.get(key),
      'linkHash': sha256.convert(utf8.encode(source.url)).toString(),
      'linkLabel': source.label,
    });
  }

  /// The Stremio `behaviorHints.bingeGroup` of the link last played for this
  /// title. Same group = same release family, used to pick the matching
  /// stream on the next episode. Null when the played
  /// link carried no group or nothing was remembered yet.
  String? stremioBingeGroup(String showUrl) {
    final m = _box.get(_key('stremio', showUrl));
    final v = m == null ? null : Map<String, dynamic>.from(m)['bingeGroup'];
    return (v is String && v.isNotEmpty) ? v : null;
  }

  Future<void> rememberStremioBingeGroup(
    String showUrl,
    String? bingeGroup,
  ) async {
    if (bingeGroup == null || bingeGroup.isEmpty) return;
    final key = _key('stremio', showUrl);
    await _box.put(key, {...?_box.get(key), 'bingeGroup': bingeGroup});
  }

  /// The subtitle pick remembered for this title: a language code or 'off'.
  /// Beats the global preference when set — the show's own choice wins.
  /// Both Stremio and non-Stremio remember here, keyed by source+show.
  String? subtitleChoice(String sourceId, String showUrl) {
    final m = _box.get(_key(sourceId, showUrl));
    final v = m == null ? null : Map<String, dynamic>.from(m)['subtitleChoice'];
    if (v is! String || v.isEmpty) return null;
    return v == 'off' ? v : languageOfSource(v)?.iso1;
  }

  Future<void> setSubtitleChoice(
    String sourceId,
    String showUrl,
    String choice,
  ) async {
    if (IncognitoMode.on) return;
    final normalized = choice == 'off' || choice.isEmpty
        ? choice
        : languageOfSource(choice)?.iso1;
    if (normalized == null) return;
    final k = _key(sourceId, showUrl);
    final m = _box.get(k) == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(_box.get(k)!);
    m['subtitleChoice'] = normalized;
    await _box.put(k, m);
  }

  /// Remembered embedded audio-track choice for this title (language/label),
  /// e.g. 'hin'. Re-applied on reopen for multi-audio files (e.g. 4khdhub).
  String? audioTrack(String sourceId, String showUrl) {
    final m = _box.get(_key(sourceId, showUrl));
    final v = m == null ? null : Map<String, dynamic>.from(m)['audioTrack'];
    return (v is String && v.isNotEmpty) ? v : null;
  }

  Future<void> setAudioTrack(
    String sourceId,
    String showUrl,
    String pref,
  ) async {
    final k = _key(sourceId, showUrl);
    final m = _box.get(k) == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(_box.get(k)!);
    m['audioTrack'] = pref;
    await _box.put(k, m);
  }

  /// Remembered quality choice for this title (e.g. '1080p', '4K', 'highest',
  /// 'auto'). Applied on reopen, taking precedence over the global default.
  String? quality(String sourceId, String showUrl) {
    final m = _box.get(_key(sourceId, showUrl));
    final v = m == null ? null : Map<String, dynamic>.from(m)['quality'];
    return (v is String && v.isNotEmpty) ? v : null;
  }

  Future<void> setQuality(String sourceId, String showUrl, String pref) async {
    final k = _key(sourceId, showUrl);
    final m = _box.get(k) == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(_box.get(k)!);
    m['quality'] = pref;
    await _box.put(k, m);
  }

  /// Remembered playback-speed multiplier for this title (e.g. 1.25, 1.5).
  /// Applied on reopen, taking precedence over the global default.
  double? speed(String sourceId, String showUrl) {
    final m = _box.get(_key(sourceId, showUrl));
    final v = m == null ? null : Map<String, dynamic>.from(m)['speed'];
    return v is num ? v.toDouble() : null;
  }

  Future<void> setSpeed(String sourceId, String showUrl, double rate) async {
    final k = _key(sourceId, showUrl);
    final m = _box.get(k) == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(_box.get(k)!);
    m['speed'] = rate;
    await _box.put(k, m);
  }

  /// Whether this title is marked as a favorite. Keyed identically to the
  /// sub/dub choice so a title's UI prefs all travel together.
  bool isFavorite(String sourceId, String showUrl) {
    final m = _box.get(_key(sourceId, showUrl));
    if (m == null) return false;
    return Map<String, dynamic>.from(m)['favorite'] == true;
  }

  /// Flip the favorite flag and return the new value.
  Future<bool> toggleFavorite(String sourceId, String showUrl) async {
    final k = _key(sourceId, showUrl);
    final m = _box.get(k) == null
        ? <String, dynamic>{}
        : Map<String, dynamic>.from(_box.get(k)!);
    final next = !(m['favorite'] == true);
    m['favorite'] = next;
    await _box.put(k, m);
    return next;
  }
}
