import '../models/source_pref.dart';
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';

import '../aniyomi/aniyomi_repo.dart';
import '../provider/cf_solve_needed.dart';
import 'mihon_manager.dart';
import 'mihon_provider.dart';
import 'mihon_repo.dart';
import 'mihon_source_info.dart';
import 'mihon_update.dart';

export 'mihon_source_info.dart';

/// Dart-side wrapper around the `zangetsu/mihon` [MethodChannel].
///
/// Structural twin of `AniyomiExtensionService`
/// (`lib/core/aniyomi/aniyomi_extension_service.dart`) — deliberately
/// duplicated rather than shared (spec Decision 3). Covers 6 of the 13
/// methods `MihonBridge.attach()` exposes: `installExtension`,
/// `loadInstalled`, `listSources`, `getFilterList`, `hasSourceSettings`,
/// `openSourceSettings`. The other 7 (`getPopular`, `getLatest`, `search`,
/// `getDetails`, `getChapters`, `getPages`, `getImage`) are per-source data
/// calls that belong to `MihonProvider` (`mihon_provider.dart`) — out of
/// scope here. All methods below are thin channel invocations; no caching or
/// business logic lives here.
///
/// [AniyomiRepoEntry] (`lib/core/aniyomi/aniyomi_repo.dart`) is reused
/// UNMODIFIED as the entry type, but the index is read by [MihonRepo], not
/// `AniyomiRepo`: Mihon repos publish `index.json` in a different shape (see
/// `mihon_repo.dart`).
class MihonExtensionService {
  static const MethodChannel _channel = MethodChannel('zangetsu/mihon');

  /// Hive box name used to persist installed pkg → apk-path entries so they
  /// can be reloaded on a cold start without re-downloading. Deliberately
  /// separate from `AniyomiExtensionService.installedBoxName`
  /// (`'aniyomi_installed'`) so the two extension families never collide.
  static const String installedBoxName = 'mihon_installed';

  /// Uninstalls [pkg]: drops its installed-box entry, then deletes the APK
  /// from disk.
  ///
  /// Order matters. The native `loadInstalled` walks the mihon directory and
  /// loads *every* `*.apk` it finds — it never consults the box — so an APK
  /// left on disk comes back on the next cold start and the source reappears
  /// as if the uninstall had failed. Deleting the box entry first means a
  /// process death between the two steps leaves an orphaned APK (reloadable,
  /// visible, retryable) rather than an entry pointing at a missing file
  /// (invisible in the list, with no tile left to uninstall from).
  ///
  /// Returns null on success, or a short human-readable reason on failure.
  /// Never throws: a failed uninstall must still leave the source list
  /// consistent, and the caller reports the reason to the user.
  static Future<String?> uninstall(String pkg, {Directory? mihonDir}) async {
    String? apkPath;
    if (Hive.isBoxOpen(installedBoxName)) {
      final box = Hive.box<dynamic>(installedBoxName);
      apkPath = box.get(pkg) as String?;
      await box.delete(pkg);
    }
    // The box is only a convenience cache of the path, and it has been seen
    // empty for extensions that are demonstrably still installed and loading
    // (Hive boxes here get quarantined and reset on read errors). The APK name
    // is derived from the pkg at install time, so fall back to it rather than
    // reporting failure and leaving the file to resurrect the source.
    apkPath ??= await _conventionalApkPath(pkg, mihonDir);
    if (apkPath == null) {
      debugPrint('[mihon] uninstall $pkg: no apk found for pkg');
      return 'apk not found';
    }
    try {
      final f = File(apkPath);
      if (await f.exists()) await f.delete();
    } catch (e) {
      debugPrint('[mihon] uninstall $pkg: deleting $apkPath failed: $e');
      return '$e';
    }
    return null;
  }

  /// `<appSupport>/mihon/<pkg>.apk` — the same path [installFromRepo] writes,
  /// or null when no such file exists.
  static Future<String?> _conventionalApkPath(
    String pkg,
    Directory? mihonDir,
  ) async {
    try {
      final dir = mihonDir ??
          Directory('${(await getApplicationSupportDirectory()).path}/mihon');
      final f = File('${dir.path}/$pkg.apk');
      return await f.exists() ? f.path : null;
    } catch (_) {
      return null;
    }
  }

  /// Loads and registers a single extension APK located at [apkPath].
  ///
  /// Throws a [PlatformException] with code `"LOAD"` when the APK is not a
  /// valid Mihon manga extension or the lib version is out of range.
  Future<void> installExtension(String apkPath) async {
    await _channel.invokeMethod<void>('installExtension', {'apkPath': apkPath});
  }

  /// Loads every `*.apk` found in [dir] and registers them.
  Future<void> loadInstalled(String dir) async {
    await _channel.invokeMethod<void>('loadInstalled', {'dir': dir});
  }

  /// Returns all currently registered sources as a list of [MihonSourceInfo].
  ///
  /// The native bridge serialises the list as a JSON string; this method
  /// deserialises it. Returns an empty list on any decoding failure.
  Future<List<MihonSourceInfo>> listSources() async {
    final raw = await _channel.invokeMethod<String>('listSources');
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map((e) => MihonSourceInfo.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  /// Returns the source's filter-list schema JSON (see `MihonFilters`), or
  /// null when the source has no filters or any channel error occurs.
  Future<String?> getFilterList(int sourceId) async {
    try {
      return await _channel.invokeMethod<String>('getFilterList', {
        'sourceId': sourceId,
      });
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }

  /// The source's own web page for a chapter (or the manga, when
  /// [chapterUrl] is null) — asked of the extension instead of derived.
  ///
  /// Null when the source can't answer, so callers keep their existing
  /// baseUrl + url join as the fallback and nothing regresses if this fails.
  ///
  /// Worth the round trip because the stored url is not always the page: a
  /// source whose real slugs carry a rotating hash keeps a stable key instead
  /// and overrides the URL methods to build the real one. Joining by hand
  /// gives a 404 there.
  Future<String?> webUrl(
    int sourceId, {
    String? mangaUrl,
    String? chapterUrl,
  }) async {
    if ((mangaUrl == null || mangaUrl.isEmpty) &&
        (chapterUrl == null || chapterUrl.isEmpty)) {
      return null;
    }
    try {
      final result = await _channel.invokeMethod<String>('webUrl', {
        'sourceId': sourceId,
        'mangaUrl': mangaUrl,
        'chapterUrl': chapterUrl,
      });
      final u = result?.trim();
      // Only an http(s) page is useful to a browser, and this string comes
      // from a third-party extension — the same rule joinChapterUrl applies.
      if (u == null || !(u.startsWith('http://') || u.startsWith('https://'))) {
        return null;
      }
      return u;
    } on PlatformException {
      return null;
    } on MissingPluginException {
      return null;
    }
  }

  /// Returns true when the native source with [sourceId] implements
  /// ConfigurableSource and has settings to show.
  ///
  /// Returns false on any channel error (source not found, not configurable).
  Future<bool> hasSourceSettings(int sourceId) async {
    try {
      final result = await _channel.invokeMethod<bool>('hasSourceSettings', {
        'sourceId': sourceId,
      });
      return result ?? false;
    } on PlatformException {
      return false;
    }
  }

  /// Launches the native MihonSettingsActivity for the source with [sourceId].
  ///
  /// No-op (returns without error) when the source has no settings.
  Future<void> openSourceSettings(int sourceId) async {
    try {
      await _channel.invokeMethod<void>('openSourceSettings', {
        'sourceId': sourceId,
      });
    } on PlatformException catch (e) {
      debugPrint('[mihon] openSourceSettings($sourceId) failed: $e');
    }
  }

  /// Opens the native visible WebView (SourceWebViewActivity) so the user can
  /// complete a Cloudflare challenge for [url]. The `cf_clearance` cookie it
  /// captures is shared with the Mihon OkHttp client, so the source loads
  /// afterwards. Best-effort — a missing channel (non-Android) is a silent no-op.
  ///
  /// Also drops [url]'s host from [CfSolveNeeded] on the way out. Without that
  /// the latch set when the challenge was first seen never lifts, and the
  /// resolver and matcher keep skipping the very source the user just solved —
  /// the WebView passes, the cookie lands, and nothing ever gets to use it.
  /// (The JS-provider path clears its own in `_solveCfImpl`; this is the same
  /// thing for the native ecosystems, which all come through here.)
  ///
  /// The native call resolves when the screen CLOSES, not on a verified
  /// clearance, so this also clears when the user simply backed out. That is
  /// self-correcting: the next request hits the challenge and re-flags it.
  static Future<void> solveCloudflare(String url) async {
    try {
      await _channel.invokeMethod<void>('solveCloudflare', {'url': url});
      final host = Uri.tryParse(url)?.host;
      if (host != null && host.isNotEmpty) CfSolveNeeded.clear(host);
    } on PlatformException catch (e) {
      debugPrint('[mihon] solveCloudflare failed: $e');
    } on MissingPluginException {
      // Non-Android host — no native solver.
    }
  }

  /// Opens the native WebView on [url] and leaves it open.
  ///
  /// The Cloudflare solver shares this screen but dismisses itself the moment a
  /// clearance lands, which is exactly wrong for a sign-in — so this asks for
  /// the mode that waits for the user instead. Returns as soon as the screen is
  /// launched; nothing waits on the login finishing.
  static Future<void> openSourceWebView(String url, {String? title}) async {
    try {
      await _channel.invokeMethod<void>('openSourceWebView', {
        'url': url,
        'title': title,
      });
    } on PlatformException catch (e) {
      debugPrint('[mihon] openSourceWebView failed: $e');
    } on MissingPluginException {
      // Non-Android host — no native WebView.
    }
  }

  /// The source's own settings as data, so the app can draw them itself.
  ///
  /// Empty when the source has none. Never throws: a source that blows up while
  /// declaring its settings returns null, and the caller falls back to the
  /// native screen ([openSourceSettings]) rather than showing an empty page for
  /// a source that does have settings.
  Future<List<SourcePref>?> readSourceSettings(int sourceId) async {
    try {
      final raw = await _channel.invokeMethod<List<Object?>>(
        'readSourceSettings',
        {'sourceId': sourceId},
      );
      return SourcePref.listFrom(raw);
    } catch (e) {
      debugPrint('[mihon] readSourceSettings($sourceId) failed: $e');
      return null;
    }
  }

  /// Apply one setting. False when the source refused it or the key is gone.
  ///
  /// The write runs through the source's own change listener on the native
  /// side, so a source that reacts to a setting — a domain switcher, a language
  /// toggle — reacts exactly as it would on its own screen.
  Future<bool> writeSourceSetting(
    int sourceId,
    String key,
    Object? value,
  ) async {
    try {
      final ok = await _channel.invokeMethod<bool>('writeSourceSetting', {
        'sourceId': sourceId,
        'key': key,
        'value': value,
      });
      return ok ?? false;
    } catch (e) {
      debugPrint('[mihon] writeSourceSetting($key) failed: $e');
      return false;
    }
  }

  /// Downloads the extension APK from [entry.apkUrl], installs it, then
  /// builds a [MihonProvider] for every new source in the package.
  ///
  /// Steps:
  /// 1. Download the APK to `<app-support>/mihon/<pkg>.apk` (or
  ///    [apkDirectory] when supplied, which is useful in tests).
  /// 2. Call [installExtension] over the native channel.
  /// 3. Call [listSources] and filter to sources whose [MihonSourceInfo.pkg]
  ///    matches [entry.pkg].
  /// 4. Persist `pkg → apk path` in the `'mihon_installed'` Hive box so
  ///    [loadInstalled] can restore sources on the next cold start.
  /// 5. Register each new provider in the optional [manager] (falls back to
  ///    `GetIt.instance<MihonManager>()` when the type is registered there).
  ///
  /// Never throws — returns `[]` on any failure and logs the error.
  ///
  /// [downloader] lets callers (and tests) substitute the download step without
  /// a real network connection. When omitted the method calls `sl<Dio>().download`.
  Future<List<MihonProvider>> installFromRepo(
    AniyomiRepoEntry entry, {
    Dio? dio,
    Directory? apkDirectory,
    Future<void> Function(String url, String savePath)? downloader,
    MihonManager? manager,
  }) async {
    try {
      // 1. Resolve the APK save directory.
      final Directory apkDir;
      if (apkDirectory != null) {
        apkDir = apkDirectory;
      } else {
        final support = await getApplicationSupportDirectory();
        apkDir = Directory('${support.path}/mihon');
      }
      await apkDir.create(recursive: true);
      final apkPath = '${apkDir.path}/${entry.pkg}.apk';

      // A prior load marks the apk read-only (Android W^X), which would block
      // re-downloading over it — remove any stale copy first.
      final existingApk = File(apkPath);
      if (await existingApk.exists()) {
        try {
          await existingApk.delete();
        } catch (_) {}
      }

      // 2. Download the APK.
      if (downloader != null) {
        await downloader(entry.apkUrl, apkPath);
      } else {
        final effectiveDio = dio ?? GetIt.instance.get<Dio>();
        await _downloadApk(effectiveDio, entry.apkUrl, apkPath);
      }

      // 3. Install and list sources.
      await installExtension(apkPath);
      final allSources = await listSources();
      final providers = allSources
          .where((s) => s.pkg == entry.pkg)
          .map((s) => MihonProvider(info: s))
          .toList();

      // 4. Persist pkg → apk path so loadInstalled can restore on next boot.
      if (Hive.isBoxOpen(installedBoxName)) {
        await Hive.box<dynamic>(installedBoxName).put(entry.pkg, apkPath);
      }

      // 5. Register in the MihonManager.
      final effectiveManager =
          manager ??
          (GetIt.instance.isRegistered<MihonManager>()
              ? GetIt.instance.get<MihonManager>()
              : null);
      effectiveManager?.registerAll(providers);

      return providers;
    } catch (e, st) {
      debugPrint('[mihon] installFromRepo(${entry.pkg}) failed: $e\n$st');
      return [];
    }
  }

  /// Extension APKs are multi-MB, but the shared Dio is tuned for small API
  /// calls (8s receiveTimeout) — the #1 cause of "No source loaded" on the
  /// anime side was that timeout firing mid-download on slow connections (the
  /// tiny repo index still loads, so the list looks fine). Give the download a
  /// generous timeout, and if the direct raw.githubusercontent.com fetch fails
  /// (ISP blocks / rate limits), retry via a GitHub-raw mirror.
  static const Duration _apkDownloadTimeout = Duration(minutes: 3);

  /// The shared Dio connects in 8s, which is right for browsing — a search
  /// fans out across every source, so a host that won't answer should be
  /// dropped fast. It's wrong for an install: that's one deliberate tap the
  /// user is waiting on, and a repo whose APKs live off-site (Keiyoushi now
  /// redirects to GitHub Releases) makes the phone establish TWO connections,
  /// each rolling that dice on a weak signal.
  static const Duration _apkConnectTimeout = Duration(seconds: 30);

  Future<void> _downloadApk(Dio dio, String url, String savePath) async {
    final opts = Options(
      receiveTimeout: _apkDownloadTimeout,
      sendTimeout: _apkDownloadTimeout,
      connectTimeout: _apkConnectTimeout,
    );
    // Try the direct URL first, then every GitHub-raw mirror in turn. Some
    // phones/ISPs block raw.githubusercontent.com but can reach the CDNs/proxies,
    // and any single mirror can be missing a file, so we fall through the
    // whole list — same rationale as the anime download path.
    final urls = <String>[url, ...githubMirrors(url)];
    Object? lastError;
    for (final u in urls) {
      try {
        await dio.download(u, savePath, options: opts);
        return; // first success wins
      } on DioException catch (e) {
        lastError = e;
        debugPrint(
          '[mihon] download mirror failed '
          '(${e.response?.statusCode ?? e.type}): $u',
        );
      }
    }
    throw lastError ?? Exception('all download mirrors failed');
  }

  /// Read-only check: fetches [repoUrl]'s index and returns updates for every
  /// installed package whose repo `code` is newer than [installedCodes]. Never
  /// throws — a failed fetch degrades to an empty list. Does NOT download APKs.
  Future<List<MihonUpdate>> checkRepoForUpdates(
    String repoUrl,
    Map<String, int> installedCodes, {
    Future<List<AniyomiRepoEntry>> Function(String url)? fetchIndex,
  }) async {
    try {
      final fetch = fetchIndex ?? MihonRepo.fetchIndex;
      final entries = await fetch(repoUrl);
      final out = <MihonUpdate>[];
      for (final e in entries) {
        final installed = installedCodes[e.pkg];
        if (installed != null && e.code > installed) {
          out.add(
            MihonUpdate(
              pkg: e.pkg,
              name: e.name,
              installedCode: installed,
              availableCode: e.code,
              availableVersion: e.version,
              entry: e,
            ),
          );
        }
      }
      return out;
    } catch (e) {
      debugPrint('[mihon] checkRepoForUpdates($repoUrl) failed: $e');
      return const [];
    }
  }
}

/// GitHub-raw download mirrors, tried in order after the direct fetch fails
/// (some phones/ISPs block raw.githubusercontent.com but reach these). Returns
/// an empty list for non-GitHub-raw URLs. Structural twin of the anime path's
/// `githubMirrors()` in `aniyomi_extension_service.dart` — duplicated per spec
/// Decision 3, not imported, so the frozen anime file never has to change.
List<String> githubMirrors(String url) {
  final u = Uri.tryParse(url);
  if (u == null || u.host != 'raw.githubusercontent.com') return const [];
  final segs = u.pathSegments;
  if (segs.length < 4) return const [];
  final owner = segs[0];
  final repo = segs[1];
  final ref = segs[2];
  final path = segs.sublist(3).join('/');
  return [
    'https://cdn.jsdelivr.net/gh/$owner/$repo@$ref/$path',
    'https://gh-proxy.com/$url',
    'https://cdn.statically.io/gh/$owner/$repo/$ref/$path',
  ];
}
