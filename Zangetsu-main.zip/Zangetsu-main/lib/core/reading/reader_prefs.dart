import 'dart:ui' show Color;

import 'package:hive/hive.dart';
import 'package:watch_app/core/hive/safe_box.dart';

import 'manga_translation/manga_page_translation_models.dart';
import 'tap_zones.dart';

/// Persistent reader settings — the manga/novel analogue of PlaybackPrefs.
/// Backed by a tiny untyped Hive box read anywhere via `sl<ReaderPrefs>()`.
/// Values are read with defaults so a fresh install behaves sensibly; numbers
/// are coerced defensively since Hive may round-trip them as `int`/`double`/
/// `num`.
class ReaderPrefs {
  static const String boxName = 'reader_prefs';
  static const double defaultMangaTranslationFontSize = 14.0;
  static const Color defaultMangaTranslationTextColor = Color(0xFFFFFFFF);
  static const Color defaultMangaTranslationBackgroundColor = Color(0xFF000000);
  static const double defaultMangaTranslationBackgroundOpacity = 1.0;

  /// Opens the prefs box. Call once during app bootstrap before constructing.
  static Future<void> init() async {
    if (!Hive.isBoxOpen(boxName)) {
      await openBoxSafely(boxName);
    }
  }

  Box get _box => Hive.box(boxName);

  // ── Novel ───────────────────────────────────────────────────────────────
  /// Reader text size in logical pixels.
  double get fontSize =>
      (_box.get('fontSize', defaultValue: 16.0) as num).toDouble();
  Future<void> setFontSize(double value) => _box.put('fontSize', value);

  /// Line-height multiplier for reader body text.
  double get lineHeight =>
      (_box.get('lineHeight', defaultValue: 1.6) as num).toDouble();
  Future<void> setLineHeight(double value) => _box.put('lineHeight', value);

  /// Reader background/text theme: 'dark' | 'black' | 'sepia'.
  String get theme => _box.get('theme', defaultValue: 'dark') as String;
  Future<void> setTheme(String value) => _box.put('theme', value);

  /// Horizontal side margin (logical pixels) around reader text.
  double get marginWidth =>
      (_box.get('marginWidth', defaultValue: 20.0) as num).toDouble();
  Future<void> setMarginWidth(double value) => _box.put('marginWidth', value);

  // ── Manga ───────────────────────────────────────────────────────────────
  /// Page reading direction: 'ltr' | 'rtl' | 'vertical'. Kept working
  /// untouched — [readingMode] below is the new, wider enum and migrates
  /// from this key; the reader itself still reads `direction` directly.
  String get direction => _box.get('direction', defaultValue: 'ltr') as String;
  Future<void> setDirection(String value) => _box.put('direction', value);

  /// Reader background colour: 'black' | 'dark'. Kept working untouched —
  /// [mangaBackground] below is the new, wider enum and migrates from this
  /// key; the reader itself still reads `background` directly.
  String get background =>
      _box.get('background', defaultValue: 'black') as String;
  Future<void> setBackground(String value) => _box.put('background', value);

  /// Floating manga page counter shown while scrolling or turning pages.
  bool get showPageNumber =>
      _box.get('showPageNumber', defaultValue: true) as bool;
  Future<void> setShowPageNumber(bool value) =>
      _box.put('showPageNumber', value);

  /// Whether to keep the screen awake while reading. Shared by both readers
  /// via `ReaderComfortMixin`.
  bool get keepScreenOn => _box.get('keepScreenOn', defaultValue: true) as bool;
  Future<void> setKeepScreenOn(bool value) => _box.put('keepScreenOn', value);

  /// Hide the status and navigation bars while reading. Shared by both
  /// readers via `ReaderComfortMixin`.
  ///
  /// ON by default, matching every other reader: a page is the content, and
  /// a clock and three nav buttons sitting over it are not. `immersiveSticky`
  /// rather than plain `immersive`, so a swipe from either edge brings the
  /// bars back for a moment without leaving the page.
  bool get fullscreen => _box.get('fullscreen', defaultValue: true) as bool;
  Future<void> setFullscreen(bool value) => _box.put('fullscreen', value);

  /// Turn manga pages with the hardware volume keys.
  ///
  /// OFF by default, and deliberately so: this SWALLOWS the volume keys while
  /// the reader is open, so someone who never asked for it would find their
  /// volume dead with no explanation. Opt-in only.
  bool get volumeKeyPaging =>
      _box.get('volumeKeyPaging', defaultValue: false) as bool;
  Future<void> setVolumeKeyPaging(bool value) =>
      _box.put('volumeKeyPaging', value);

  /// Swap which volume key goes forward. Down-is-next matches how most readers
  /// ship; up-is-next suits holding the phone the other way round.
  bool get invertVolumeKeys =>
      _box.get('invertVolumeKeys', defaultValue: false) as bool;
  Future<void> setInvertVolumeKeys(bool value) =>
      _box.put('invertVolumeKeys', value);

  /// Pull past the end of a chapter to open the next one (and past the start
  /// for the previous). ON by default: it only triggers on a deliberate drag
  /// beyond the edge, where there is nothing else to do.
  bool get overscrollChapter =>
      _box.get('overscrollChapter', defaultValue: true) as bool;
  Future<void> setOverscrollChapter(bool value) =>
      _box.put('overscrollChapter', value);

  /// Extra space between letters, in logical pixels. 0 is the font's own.
  double get letterSpacing =>
      (_box.get('letterSpacing', defaultValue: 0.0) as num).toDouble();
  Future<void> setLetterSpacing(double value) =>
      _box.put('letterSpacing', value);

  /// Extra space between words, in logical pixels. 0 is the font's own.
  double get wordSpacing =>
      (_box.get('wordSpacing', defaultValue: 0.0) as num).toDouble();
  Future<void> setWordSpacing(double value) => _box.put('wordSpacing', value);

  /// Switch a long-strip chapter to vertical on its own, even when the
  /// direction pref says left-to-right. Manhwa is one tall image per page, so
  /// paged mode hands you sideways slices of it.
  ///
  /// On by default: someone reading a webtoon in paged mode gets a bad time
  /// and no clue why. A per-series direction override still wins — an explicit
  /// choice shouldn't be second-guessed.
  bool get autoWebtoon => _box.get('autoWebtoon', defaultValue: true) as bool;
  Future<void> setAutoWebtoon(bool value) => _box.put('autoWebtoon', value);

  /// Novel page background, 0 (black) to 1 (the theme's own colour).
  ///
  /// Lets you keep a theme's text colour while darkening the page behind it.
  /// Defaults to 1, which is exactly what the theme gives today.
  double get novelBgOpacity =>
      (_box.get('novelBgOpacity', defaultValue: 1.0) as num).toDouble();
  Future<void> setNovelBgOpacity(double value) =>
      _box.put('novelBgOpacity', value);

  /// Auto-scroll speed on a 1–10 feel scale, not pixels per second: how fast
  /// you like it is a feel, and "60 px/s" means nothing to anyone reading.
  /// [ReaderAutoScroll] maps it to a creep rate or a page dwell depending on
  /// the reading mode.
  ///
  /// Persisted, unlike auto-scroll itself: the speed is a lasting preference,
  /// whereas whether it's *running* belongs to the reading session — nobody
  /// wants to open a chapter and find it already scrolling away. Stored under
  /// a new key so the old pixels-per-second values (60–300) can't be read back
  /// as a 1–10 speed and pin everyone to maximum.
  double get autoScrollSpeed =>
      (_box.get('autoScrollSpeedScale', defaultValue: 3.0) as num).toDouble();
  Future<void> setAutoScrollSpeed(double value) =>
      _box.put('autoScrollSpeedScale', value);

  /// Keep a small floating play/pause button on the reader while auto-scroll
  /// is on. Without it, pausing means revealing the chrome first — which
  /// defeats the point of a hands-free mode. On by default for that reason.
  bool get autoScrollButton =>
      _box.get('autoScrollButton', defaultValue: true) as bool;
  Future<void> setAutoScrollButton(bool value) =>
      _box.put('autoScrollButton', value);

  /// Where the floating auto-scroll button sits, as a fraction of the screen
  /// (0–1 on each axis) rather than pixels — so it lands in the same place
  /// after a rotation or on a different device instead of off-screen.
  /// Defaults to the lower right, clear of the bottom chrome.
  double get autoScrollButtonX =>
      (_box.get('autoScrollButtonX', defaultValue: 0.88) as num).toDouble();
  double get autoScrollButtonY =>
      (_box.get('autoScrollButtonY', defaultValue: 0.74) as num).toDouble();
  Future<void> setAutoScrollButtonPos(double x, double y) async {
    await _box.put('autoScrollButtonX', x);
    await _box.put('autoScrollButtonY', y);
  }

  /// How many pages ahead the reader warms into the disk cache after landing
  /// on a page. Six rather than the three we started with: preloading only
  /// fetches bytes now, so the extra runway costs disk and network instead of
  /// the memory it used to.
  int get preloadCount =>
      (_box.get('preloadCount', defaultValue: 6) as num).toInt().clamp(1, 8);
  Future<void> setPreloadCount(int value) =>
      _box.put('preloadCount', value.clamp(1, 8));

  /// Reading mode: 'ltr' | 'rtl' | 'vertical_paged' | 'webtoon'. Migrate-on-
  /// read from the legacy `direction` key (ltr→ltr, rtl→rtl,
  /// vertical→webtoon) until this key is explicitly written, so a fresh
  /// install and an existing install both start out reading exactly as
  /// `direction` says today.
  String get readingMode {
    final v = _box.get('readingMode') as String?;
    if (v != null) return v;
    return switch (direction) {
      'rtl' => 'rtl',
      'vertical' => 'webtoon',
      _ => 'ltr',
    };
  }

  Future<void> setReadingMode(String value) => _box.put('readingMode', value);

  // ── Tap zones ───────────────────────────────────────────────────────────
  /// What tapping each part of the page does, per reading mode. Stored as JSON
  /// so the shape can change without a migration; anything unreadable falls
  /// back to the default rather than leaving a dead screen.
  TapZoneLayout tapZones(String layoutId) => TapZoneLayout.fromJsonString(
    _box.get('tapZones_$layoutId') as String?,
    layoutId,
  );

  /// The layout for the mode currently being read.
  TapZoneLayout tapZonesForMode(String readingMode) =>
      tapZones(TapZoneLayout.idForReadingMode(readingMode));

  Future<void> setTapZones(TapZoneLayout layout) =>
      _box.put('tapZones_${layout.id}', layout.toJsonString());

  Future<void> resetTapZones() async {
    for (final id in TapZoneLayout.ids) {
      await _box.delete('tapZones_$id');
    }
  }

  /// Page fit: 'contain' | 'width' | 'height' | 'original' | 'smart'.
  /// Default 'contain' renders identically to the reader's current hardcoded
  /// `BoxFit.contain`/`BoxFit.fitWidth`.
  String get fitMode => _box.get('fitMode', defaultValue: 'contain') as String;
  Future<void> setFitMode(String value) => _box.put('fitMode', value);

  /// Manga background: 'black' | 'white' | 'gray' | 'system'. Migrate-on-read
  /// from the legacy `background` key (black→black, dark→system, since
  /// 'dark' already renders the app's own theme background) until this key
  /// is explicitly written.
  String get mangaBackground {
    final v = _box.get('mangaBackground') as String?;
    if (v != null) return v;
    return background == 'black' ? 'black' : 'system';
  }

  Future<void> setMangaBackground(String value) =>
      _box.put('mangaBackground', value);

  /// Pair facing pages into a landscape double-page spread.
  bool get doublePageLandscape =>
      _box.get('doublePageLandscape', defaultValue: false) as bool;
  Future<void> setDoublePageLandscape(bool value) =>
      _box.put('doublePageLandscape', value);

  /// Trim near-uniform edge margins from a page.
  bool get cropBorders => _box.get('cropBorders', defaultValue: false) as bool;
  Future<void> setCropBorders(bool value) => _box.put('cropBorders', value);

  /// Gap in logical pixels between pages in webtoon (vertical) mode.
  double get webtoonPageGap =>
      (_box.get('webtoonPageGap', defaultValue: 0.0) as num).toDouble();
  Future<void> setWebtoonPageGap(double value) =>
      _box.put('webtoonPageGap', value);

  /// Reading colour filter: 'none' | 'grayscale' | 'invert' | 'sepia'.
  String get colorFilter =>
      _box.get('colorFilter', defaultValue: 'none') as String;
  Future<void> setColorFilter(String value) => _box.put('colorFilter', value);

  /// Mihon-style custom tint: when on, the page is wrapped in
  /// `ColorFilter.mode` with [customFilterColor] and [customFilterBlend]
  /// instead of the preset above.
  bool get customColorFilter =>
      _box.get('customColorFilter', defaultValue: false) as bool;
  Future<void> setCustomColorFilter(bool value) =>
      _box.put('customColorFilter', value);

  /// ARGB tint color for the custom filter. Defaults to a warm sepia-ish
  /// tint (R255 G186 B85, opaque) like the reference UI.
  int get customFilterColor =>
      _box.get('customFilterColor', defaultValue: 0xFFFFBA55) as int;
  Future<void> setCustomFilterColor(int value) =>
      _box.put('customFilterColor', value);

  /// Blend mode key for the custom filter: 'default' | 'multiply' |
  /// 'screen' | 'overlay' | 'dodge' | 'lighten'.
  String get customFilterBlend =>
      _box.get('customFilterBlend', defaultValue: 'multiply') as String;
  Future<void> setCustomFilterBlend(String value) =>
      _box.put('customFilterBlend', value);

  /// Source language used by manga page translation.
  String get mangaTranslationSourceLanguage =>
      _box.get('mangaTranslationSourceLanguage', defaultValue: 'ja') as String;
  Future<void> setMangaTranslationSourceLanguage(String value) =>
      _box.put('mangaTranslationSourceLanguage', value);

  /// Target language used by manga page translation.
  String get mangaTranslationTargetLanguage =>
      _box.get('mangaTranslationTargetLanguage', defaultValue: 'en') as String;
  Future<void> setMangaTranslationTargetLanguage(String value) =>
      _box.put('mangaTranslationTargetLanguage', value);

  /// Translation engine used for manga pages. Unknown stored values fall back
  /// to online so a future or corrupted preference remains usable.
  MangaTranslationEngine get mangaTranslationEngine {
    final stored =
        _box.get('mangaTranslationEngine', defaultValue: 'online') as String;
    return MangaTranslationEngine.values.firstWhere(
      (engine) => engine.name == stored,
      orElse: () => MangaTranslationEngine.online,
    );
  }

  Future<void> setMangaTranslationEngine(MangaTranslationEngine value) =>
      _box.put('mangaTranslationEngine', value.name);

  /// Preferred manga translation font size in logical pixels. Long text may
  /// still scale down to remain inside its detected OCR region.
  double get mangaTranslationFontSize =>
      (_box.get(
                'mangaTranslationFontSize',
                defaultValue: defaultMangaTranslationFontSize,
              )
              as num)
          .toDouble()
          .clamp(8.0, 32.0);
  Future<void> setMangaTranslationFontSize(double value) =>
      _box.put('mangaTranslationFontSize', value.clamp(8.0, 32.0));

  /// Text color used for translated manga page regions, stored as ARGB32.
  Color get mangaTranslationTextColor => Color(
    (_box.get(
              'mangaTranslationTextColor',
              defaultValue: defaultMangaTranslationTextColor.toARGB32(),
            )
            as num)
        .toInt(),
  );
  Future<void> setMangaTranslationTextColor(Color value) =>
      _box.put('mangaTranslationTextColor', value.toARGB32());

  /// Background color used behind translated manga page regions, stored as
  /// ARGB32. Background opacity is controlled independently.
  Color get mangaTranslationBackgroundColor => Color(
    (_box.get(
              'mangaTranslationBackgroundColor',
              defaultValue: defaultMangaTranslationBackgroundColor.toARGB32(),
            )
            as num)
        .toInt(),
  );
  Future<void> setMangaTranslationBackgroundColor(Color value) =>
      _box.put('mangaTranslationBackgroundColor', value.toARGB32());

  /// Opacity of the background behind translated manga page regions.
  double get mangaTranslationBackgroundOpacity =>
      (_box.get(
                'mangaTranslationBackgroundOpacity',
                defaultValue: defaultMangaTranslationBackgroundOpacity,
              )
              as num)
          .toDouble()
          .clamp(0.0, 1.0);
  Future<void> setMangaTranslationBackgroundOpacity(double value) =>
      _box.put('mangaTranslationBackgroundOpacity', value.clamp(0.0, 1.0));

  /// Online provider used for manga page translation.
  MangaOnlineTranslationProvider get mangaOnlineTranslationProvider {
    final stored =
        _box.get('mangaOnlineTranslationProvider', defaultValue: 'google')
            as String;
    return MangaOnlineTranslationProvider.values.firstWhere(
      (provider) => provider.name == stored,
      orElse: () => MangaOnlineTranslationProvider.google,
    );
  }

  Future<void> setMangaOnlineTranslationProvider(
    MangaOnlineTranslationProvider value,
  ) => _box.put('mangaOnlineTranslationProvider', value.name);

  // ── Shared comfort (both readers) ──────────────────────────────────────
  /// Screen brightness override, 0..1, or -1 for "system" — i.e. no
  /// override, matching the player's own default and today's reader
  /// behavior (the reader has never touched brightness before this).
  double get brightness => (_box.get('brightness', defaultValue: -1.0) as num)
      .toDouble()
      .clamp(-1.0, 1.0);
  Future<void> setBrightness(double value) =>
      _box.put('brightness', value.clamp(-1.0, 1.0));

  /// Orientation lock while reading: 'system' | 'portrait' | 'landscape'.
  /// Default 'system' applies no lock — today's behavior.
  String get orientation =>
      _box.get('orientation', defaultValue: 'system') as String;
  Future<void> setOrientation(String value) => _box.put('orientation', value);

  // ── Novel (typography) ─────────────────────────────────────────────────
  /// Body font family: 'inter' | 'serif' | 'system'.
  String get fontFamily =>
      _box.get('fontFamily', defaultValue: 'inter') as String;
  Future<void> setFontFamily(String value) => _box.put('fontFamily', value);

  /// Whether body text is justified instead of ragged-edge.
  bool get textAlignJustify =>
      _box.get('textAlignJustify', defaultValue: false) as bool;
  Future<void> setTextAlignJustify(bool value) =>
      _box.put('textAlignJustify', value);

  /// Extra spacing (logical pixels) between paragraphs.
  double get paragraphSpacing =>
      (_box.get('paragraphSpacing', defaultValue: 8.0) as num).toDouble();
  Future<void> setParagraphSpacing(double value) =>
      _box.put('paragraphSpacing', value);

  /// Whether the novel reader paginates into book-style pages instead of one
  /// continuous scroll.
  bool get novelPaginated =>
      _box.get('novelPaginated', defaultValue: false) as bool;
  Future<void> setNovelPaginated(bool value) =>
      _box.put('novelPaginated', value);

  /// Novel text direction: 'auto' | 'ltr' | 'rtl'. 'auto' detects RTL scripts
  /// (Arabic, Hebrew, ...) from the chapter text itself so Arabic novels read
  /// right-to-left without the user having to flip a setting per source.
  String get textDirection =>
      _box.get('textDirection', defaultValue: 'auto') as String;
  Future<void> setTextDirection(String value) =>
      _box.put('textDirection', value);
}
