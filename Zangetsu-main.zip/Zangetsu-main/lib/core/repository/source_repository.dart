import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart' show debugPrint;

import '../aniyomi/aniyomi_filters.dart';
import '../aniyomi/aniyomi_provider.dart';
import '../lnreader/lnreader_manager.dart';
import '../mangayomi/mangayomi_manager.dart';
import '../mangayomi/mangayomi_provider.dart';
import '../di/injector.dart';
import '../download/chapter_download.dart';
import '../download/chapter_download_store.dart';
import '../logging/app_logger.dart';
import '../mihon/mihon_filters.dart';
import '../mihon/mihon_manager.dart';
import '../mihon/mihon_provider.dart';
import '../models/episode.dart';
import '../models/home_section.dart';
import '../models/media_detail.dart';
import '../models/media_item.dart';
import '../models/page_content.dart';
import '../models/video_source.dart';
import '../playback/playback_prefs.dart';
import '../playback/source_health_store.dart';
import '../provider/base_provider.dart';
import '../i18n/source_languages.dart';
import '../prefs/source_lang_prefs.dart';
import '../provider/cf_solve_needed.dart';
import '../provider/cloudstream_provider.dart';
import '../provider/provider_manager.dart';
import '../provider/provider_registry.dart';
import '../provider/reading_provider.dart';
import '../state/active_source_cubit.dart';
import '../stremio/stremio_manager.dart';
import '../stremio/stremio_provider.dart';
import '../stremio/stremio_ref.dart';
import 'catalogue_repository.dart';
import 'source_domain_overrides.dart';

/// Facade over the active provider runtime for the UI layer.
/// The active source is driven by [activeSource] so callers can switch at
/// runtime without recreating the repository.
class SourceRepository implements CatalogueRepository {
  SourceRepository({
    required ProviderManager manager,
    required CloudStreamManager csManager,
    required AniyomiManager aniManager,
    required ActiveSourceCubit activeSource,
    required PlaybackPrefs prefs,
    MihonManager? mihonManager,
    LnReaderManager? lnrManager,
    MangayomiManager? mangayomiManager,
    // Optional so existing tests construct this unchanged; null simply means
    // "no language filtering", which is also the behaviour for a user who has
    // never picked a language set.
    MangaLangPrefs? mangaLangs,
    AnimeLangPrefs? animeLangs,
  }) : _mangaLangs = mangaLangs,
       _animeLangs = animeLangs,
       _manager = manager,
       _csManager = csManager,
       _aniManager = aniManager,
       _active = activeSource,
       _prefs = prefs,
       // Optional (not `required`) purely so adding manga wiring changes no
       // existing call site — omitting it yields an EMPTY registry, which is
       // exactly the right behaviour anywhere Mihon isn't wired (tests,
       // non-Android): `mihon:` ids simply never resolve, same as any other
       // unknown id. The injector always passes the real one.
       _mihonManager = mihonManager ?? MihonManager(),
       // Novel twin of the above, kept nullable rather than defaulted:
       // LnReaderManager has no cheap no-arg default the way MihonManager
       // does (it's a thin read-through over a Hive box that [init] must
       // open first), so every `_lnrManager` use below is `?.`-guarded
       // instead. Omitting it yields the same "EMPTY registry" behaviour —
       // `lnr:` ids simply never resolve. The injector always passes the
       // real one.
       _lnrManager = lnrManager,
       _mangayomiManager = mangayomiManager;

  final ProviderManager _manager;
  final CloudStreamManager _csManager;
  final AniyomiManager _aniManager;
  final MihonManager _mihonManager;
  final LnReaderManager? _lnrManager;
  final MangayomiManager? _mangayomiManager;
  final ActiveSourceCubit _active;
  final PlaybackPrefs _prefs;

  /// Prefetch cache: `sourceId|episodeUrl` → an in-flight/complete fast
  /// resolution started on the detail screen, so "tap Play" reuses work already
  /// done. Consumed once per key by the next fast [sources] call; never used by
  /// downloads (fast=false).
  final Map<String, ({DateTime at, Future<List<VideoSource>> future})>
  _prefetch = {};
  static const Duration _prefetchTtl = Duration(minutes: 2);

  /// Resolved-source cache: `sourceId|episodeUrl` → the fast-resolved sources +
  /// when they were resolved. Unlike [_prefetch] (consumed once), this PERSISTS,
  /// so re-opening a recently-played episode (Continue Watching, back-out then
  /// resume, a quality switch) replays instantly instead of re-scraping. Short
  /// TTL because stream URLs are signed/expiring — this mirrors CloudStream's
  /// 20-minute link cache. ONLY the fast (playback) path uses it; downloads
  /// (fast=false) always resolve fresh. Cleared by [invalidateSources] when
  /// every mirror stalls (the cached links are likely dead).
  final Map<String, ({DateTime at, List<VideoSource> sources})> _resolved = {};
  static const Duration _resolvedTtl = Duration(minutes: 20);

  /// Search result cache (opt-in via [searchStatus]'s `cache` flag) + in-flight
  /// dedup, so a repeat search or a scope/filter toggle doesn't re-hit every
  /// source. Keyed PER SOURCE (id + query + category + filters), so a newly
  /// added source is never in the cache — it's always searched live. A short TTL
  /// bounds staleness for an updated same-id source, and [syncSearchCache] wipes
  /// the whole cache the moment the loaded-source set changes (add/remove/
  /// enable/disable). Only successful outcomes (ok/empty) are cached — a
  /// transient error/timeout is never remembered, so a failed source retries.
  final Map<
    String,
    ({DateTime at, List<MediaItem> items, SourceOutcome outcome})
  >
  _searchCache = {};
  final Map<String, Future<({List<MediaItem> items, SourceOutcome outcome})>>
  _searchInflight = {};
  static const Duration _searchTtl = Duration(minutes: 3);
  String _searchSourcesSig = '';

  String _prefetchKey(String url, String? sourceId) =>
      '${sourceId ?? _active.state}|$url';

  String _searchKey(
    String sourceId,
    String query,
    String category,
    String? filtersJson,
    int page,
  ) =>
      '$sourceId|${query.trim().toLowerCase()}|$category|'
      '${filtersJson ?? ''}|$page';

  /// Drop the search cache when the set of loaded sources changed since the last
  /// call (a source was added, removed, or enabled/disabled) — so cached results
  /// never outlive a source-list change. Cheap; call once before a search batch.
  @override
  void syncSearchCache() {
    final sig = loadedSources.map((s) => s.id).join(',');
    if (sig != _searchSourcesSig) {
      _searchCache.clear();
      _searchInflight.clear();
      _searchSourcesSig = sig;
    }
  }

  /// True for CloudStream source ids (`cs:<name>`), which route to the native
  /// plugin host instead of the JS runtime.
  static bool _isCloudStream(String id) => id.startsWith('cs:');

  /// True for Aniyomi source ids (`ani:<sourceId>`).
  static bool _isAniyomi(String id) => id.startsWith('ani:');

  /// True for Mihon manga source ids (`mihon:<sourceId>`). A separate prefix
  /// from `ani:` on purpose (spec Decision 1) — `sourceTypeOf` hardcodes
  /// `ani:` to anime, so reusing it would type every manga source as anime.
  static bool _isMihon(String id) => id.startsWith('mihon:');

  /// True for LNReader novel source ids (`lnr:<pluginId>`). Novel twin of
  /// [_isMihon] — its own prefix so `sourceTypeOf` can type it novel without
  /// disturbing the `mihon:`/`ani:` lines.
  static bool _isLnReader(String id) => id.startsWith('lnr:');

  /// True for installed Mangayomi bridge sources (`mg:<stable-key>`).
  static bool _isMangayomi(String id) => id.startsWith('mg:');

  /// The one aggregator provider that owns every enabled Stremio addon.
  static bool _isStremio(String id) => id == stremioSourceId;

  /// The currently-active source identifier.
  @override
  String get sourceId => _active.state;

  /// All currently-loaded sources (id + display name), for cross-source search
  /// and source labelling. JS providers first (registry order), then any
  /// installed CloudStream sources, then Aniyomi sources.
  ///
  /// NSFW Aniyomi sources are excluded when
  /// [PlaybackPrefs.showNsfwAniyomi] is false; other NSFW extensions use
  /// [PlaybackPrefs.nsfwSources]. Toggling either preference is reflected here.
  /// Installed sources as `{id, name}`, with same-named entries disambiguated
  /// by language.
  ///
  /// Multi-language extensions install one source PER language, each carrying
  /// the same `info.name` — so MangaDex alone showed up as a dozen identical
  /// "MangaDex" chips, an unreadable picker, and a stack of identical result
  /// sections. Only names that actually collide get the suffix, so a
  /// single-language source reads exactly as before.
  /// Every installed, enabled, non-hidden source — including ones the language
  /// preference narrows out of [loadedSources]. For explicit per-title source
  /// pickers only; browse and search must keep using [loadedSources].
  ///
  /// On TV, the QuickJS runtime may be empty (loadAll is skipped to avoid
  /// freezing the boot), so we also pull enabled entries from the
  /// [ProviderRegistry] and merge them in. The registry is the source of
  /// truth for what's installed+enabled; the runtime is just a cache of
  /// what's currently loaded.
  /// Cached answer for [pickableSources], and the fingerprint it was built
  /// from. See the getter.
  List<({String id, String name})>? _pickableCache;
  int? _pickableKey;

  /// Everything [pickableSources] reads, in a form that is cheap to compute.
  ///
  /// Hashes the source IDS of each ecosystem, not their counts. Counts look
  /// tempting — they are already in memory — but disabling one CloudStream
  /// source and enabling another leaves the count identical while the list
  /// changes, and the cache would then hide a source until restart. Hashing
  /// ids walks the same lists without building records, running [_named] over
  /// 200+ entries, or touching the registry box.
  ///
  /// The registry is the exception: reading it means a Hive read plus a JSON
  /// parse per entry, which is the single most expensive part of the getter.
  /// It contributes its write revision instead — which catches enable/disable
  /// as well, since that is a write like any other.
  int get _pickableFingerprint => Object.hashAll([
    Object.hashAll(_manager.all.map((p) => p.sourceId)),
    Object.hashAll(_csManager.enabled.map((p) => p.sourceId)),
    Object.hashAll(_aniManager.all.map((p) => p.sourceId)),
    Object.hashAll(_mihonManager.all.map((p) => p.sourceId)),
    Object.hashAll(_lnrManager?.installedSources.map((s) => s.id) ?? const []),
    _mangayomiManager?.revision ?? 0,
    sl.isRegistered<StremioManager>() ? sl<StremioManager>().revision : 0,
    // Both NSFW prefs filter the list, so a toggle has to invalidate it.
    _prefs.showNsfwAniyomi,
    _prefs.nsfwSources,
    sl.isRegistered<ProviderRegistry>() ? sl<ProviderRegistry>().revision : 0,
  ]);

  List<({String id, String name})> get pickableSources {
    // Memoised because this is on the source matcher's hot path: it is called
    // once per candidate lookup, and a home reload (what the Cloudflare
    // "solve" button triggers) ran it TWELVE times inside one 30ms frame with
    // 214 sources installed — enumerating five ecosystems and re-reading the
    // registry box each time, all on the UI thread. That is the freeze.
    final key = _pickableFingerprint;
    final hit = _pickableCache;
    if (hit != null && key == _pickableKey) return hit;

    final raw = _rawSources(narrowByLang: false);

    // ── Registry supplement (TV: loadAll skipped, runtime empty) ──
    // One slot per sourceId in the JS runtime — two repos can both install
    // `hianime`, but only one can be live. Without dedupe the priority
    // screen (and anything else keyed on id) crashes on duplicate keys.
    final seenIds = raw.map((s) => s.id).toSet();
    final registryOnly = <({String id, String name, String? lang})>[];
    if (sl.isRegistered<ProviderRegistry>()) {
      for (final entry in sl<ProviderRegistry>().getAll()) {
        if (entry.enabled && seenIds.add(entry.name)) {
          registryOnly.add((
            id: entry.name,
            name: (entry.displayName.isNotEmpty
                ? entry.displayName
                : entry.name),
            lang: null,
          ));
        }
      }
    }

    final merged = [...raw, ...registryOnly];
    final named = _named(merged);
    debugPrint(
      '[source-repo] pickableSources · '
      'js=${_manager.all.length} cs=${_csManager.enabled.length} '
      'ani=${_aniManager.all.length} mihon=${_mihonManager.all.length} '
      'lnr=${_lnrManager?.installedSources.length ?? 0} '
      'registrySupplement=${registryOnly.length} '
      '→ ${named.length} pickable (rebuilt)',
    );
    _pickableKey = key;
    return _pickableCache = named;
  }

  @override
  List<({String id, String name})> get loadedSources =>
      _named(_rawLoadedSources);

  /// Disambiguates same-named sources by appending their language code.
  ///
  /// Also collapses duplicate ids (first wins). Multi-language Mihon/Aniyomi
  /// extensions use distinct ids per language, so those still all appear —
  /// this only drops true same-id collisions (two registry installs of one
  /// JS sourceId, etc.).
  List<({String id, String name})> _named(
    List<({String id, String name, String? lang})> raw,
  ) {
    final counts = <String, int>{};
    for (final s in raw) {
      counts[s.name] = (counts[s.name] ?? 0) + 1;
    }
    final seen = <String>{};
    return [
      for (final s in raw)
        if (seen.add(s.id))
          (
            id: s.id,
            name: (counts[s.name]! > 1 && (s.lang ?? '').isNotEmpty)
                ? '${s.name} (${s.lang!.toUpperCase()})'
                : s.name,
          ),
    ];
  }

  /// The user's enabled language codes for [T], or null when they've never
  /// configured them (or in tests where the prefs aren't registered). Null
  /// means "don't filter" — a language set is only ever applied because the
  /// user picked one, so an untouched install keeps every source it had.
  final MangaLangPrefs? _mangaLangs;
  final AnimeLangPrefs? _animeLangs;

  /// The language set to filter by, mirroring what the sources screens do
  /// (`mihon_repo_tab.dart`): an unset preference falls back to the DEFAULTS,
  /// not to "no filtering". Getting this wrong is why choosing English on the
  /// sources screen still returned Telugu and Hebrew in search — that screen
  /// was showing the default set while the repo filtered by nothing.
  ///
  /// Null only when the prefs object itself is absent (tests), which keeps
  /// every existing test's source list untouched.
  Set<String>? _langsFor(LangPrefs? prefs) {
    if (prefs == null) return null;
    final set = prefs.enabled;
    if (set != null) return set;
    try {
      return defaultSourceLangs();
    } catch (_) {
      // defaultSourceLangs reads the platform locale, which needs a binding.
      return const {'en'};
    }
  }

  /// True when a source declaring [lang] should be used at all, given [enabled].
  /// `sourceLangVisible` already lets blank/`all`/unknown codes through, so a
  /// source can never be hidden with no way to bring it back.
  bool _langOk(String? lang, Set<String>? enabled) =>
      enabled == null || sourceLangVisible(lang ?? '', enabled);

  List<({String id, String name, String? lang})> get _rawLoadedSources =>
      _rawSources(narrowByLang: true);

  /// [narrowByLang] false keeps sources the LANGUAGE preference would drop.
  /// Browse and search narrow by language so a multi-language extension does
  /// not fan a query across a dozen copies of itself. A per-title picker is
  /// the opposite situation: the user is choosing one source by hand, and an
  /// installed source missing from that list just reads as broken.
  List<({String id, String name, String? lang})> _rawSources({
    required bool narrowByLang,
  }) => [
    if (sl.isRegistered<StremioManager>() &&
        sl<StremioManager>().enabled.isNotEmpty)
      (id: stremioSourceId, name: 'Stremio', lang: null),
    ..._manager.all.map(
      (p) => (id: p.sourceId, name: p.displayName, lang: null),
    ),
    // Only ENABLED CloudStream sources — a disabled source shouldn't be
    // searched (and skipping them trims the search fan-out).
    ..._csManager.enabled.map(
      (p) => (id: p.sourceId, name: p.displayName, lang: null),
    ),
    // Aniyomi sources — NSFW entries filtered when the pref is off.
    ..._aniManager.all
        .where(
          (p) => aniyomiNsfwVisible(p, showNsfwAniyomi: _prefs.showNsfwAniyomi),
        )
        .map(
          (p) => (
            id: p.sourceId,
            name: p.displayName,
            lang: p is AniyomiProvider ? p.info.lang : null,
          ),
        )
        .where((s) => !narrowByLang || _langOk(s.lang, _langsFor(_animeLangs))),
    // Mihon manga sources. There is no Mihon-specific NSFW pref, so these
    // reuse the general "show NSFW sources" toggle rather than inventing a
    // third one — same default (off), so an 18+ manga source stays hidden
    // until the user opts in, exactly like every other NSFW source.
    ..._mihonManager.all
        .where((p) => !p.info.nsfw || _prefs.nsfwSources)
        .map((p) => (id: p.sourceId, name: p.displayName, lang: p.info.lang))
        // A multi-language extension installs one source PER language, so
        // installing MangaDex registered a dozen of them and search queried
        // every one — Hebrew results for a user who'd chosen English. The
        // sources screen already filtered its list this way; the source list
        // that actually gets searched never did.
        .where((s) => !narrowByLang || _langOk(s.lang, _langsFor(_mangaLangs))),
    // LNReader novel sources — already `{id, name}` shaped, straight from
    // stored plugin meta (no NSFW concept for these yet).
    if (_lnrManager != null)
      ..._lnrManager.installedSources.map(
        (s) => (id: s.id, name: s.name, lang: null),
      ),
    if (_mangayomiManager != null)
      ..._mangayomiManager.all
          .where((p) => !p.source.isNsfw || _prefs.nsfwSources)
          .map(
            (p) =>
                (id: p.sourceId, name: p.displayName, lang: p.source.language),
          ),
  ];

  /// Base site URL for a source. For Mihon/Aniyomi/LNReader this turns a
  /// RELATIVE item URL into an absolute web link. CloudStream/JS items are
  /// already absolute, so this is never prepended to one of THOSE — it only
  /// exists there so the Cloudflare-solve / open-in-browser actions (which
  /// need a URL, not an item) have one to work with. Both gate on
  /// `.isNotEmpty`, so a source with no known site simply hides the actions
  /// rather than offering a control that can't work.
  String baseUrlFor(String sourceId) {
    // A domain the user set by hand outranks whatever the extension reports —
    // that's the whole point of setting one (see [SourceDomainOverrides]).
    final override = _domainOverride(sourceId);
    if (override != null) return override;
    // Mihon stores `SManga.url` as a path for the same reason Aniyomi does
    // (the native side requests `baseUrl + manga.url`), so a manga item needs
    // the same relative→absolute treatment before it can be shared/opened.
    final m = _mihonManager.get(sourceId);
    if (m != null) return m.info.baseUrl;
    // LNReader chapter urls are paths too (resolved against the plugin's
    // `site`), same rationale as Mihon above.
    final l = _lnrManager?.get(sourceId);
    if (l != null) return l.site;
    final mg = _mangayomiManager?.get(sourceId);
    if (mg != null) return mg.source.baseUrl.toString();
    final a = _aniManager.get(sourceId);
    if (a is AniyomiProvider) return a.info.baseUrl;
    // CloudStream plugins declare their own site as `MainAPI.mainUrl`. Their
    // item urls are already absolute (unlike the three above), so this value
    // is used only for the Cloudflare/browser actions, never for turning an
    // item url into an absolute one.
    final c = _csManager.get(sourceId);
    return c is CloudStreamProvider ? c.mainUrl : '';
  }

  /// The url to actually TARGET when the user asks to solve Cloudflare for
  /// [sourceId] — [baseUrlFor] stays the synchronous, cached value the
  /// picker shield's sync visibility check and "open in browser" already
  /// depend on; this is the one callers should await right before opening
  /// the solve WebView.
  ///
  /// Order of preference:
  ///  1. A host [CfSolveNeeded] actually saw hit a challenge for this source
  ///     — the freshest signal there is.
  ///  2. For CloudStream, the plugin's CURRENT `MainAPI.mainUrl`, read fresh
  ///     off the loaded native provider (see [csPluginLiveMainUrl]). A
  ///     plugin rewrites `mainUrl` in place once it resolves its live domain
  ///     (e.g. by fetching a redirect list at runtime), so the snapshot a
  ///     [CloudStreamProvider] carries — captured once when the source was
  ///     listed — can point at a domain the plugin has already moved off.
  ///  3. [baseUrlFor]'s cached listing value — stale is still better than
  ///     nothing when the plugin isn't loaded right now.
  ///
  /// Null when none of those is usable — callers must hide the solve action
  /// rather than open a url that can't be solved.
  Future<String?> cfSolveTargetFor(String sourceId) async {
    // Ahead of every derived value: the user set this precisely because the
    // derived ones were wrong.
    final override = _domainOverride(sourceId);
    if (override != null) return override;
    final flagged = CfSolveNeeded.urlFor(sourceId);
    if (flagged != null && flagged.isNotEmpty) return flagged;
    final c = _csManager.get(sourceId);
    if (c is CloudStreamProvider) {
      final live = await csPluginLiveMainUrl(c.hostKey);
      if (live != null && live.isNotEmpty) return live;
    }
    final cached = baseUrlFor(sourceId);
    return cached.isEmpty ? null : cached;
  }

  /// The user's own domain for [sourceId], or null. Read through the locator
  /// rather than the constructor so the many `implements SourceRepository`
  /// fakes don't all have to grow a parameter; guarded on registration so a
  /// test that never registers the store behaves exactly as before.
  String? _domainOverride(String sourceId) =>
      sl.isRegistered<SourceDomainOverrides>()
      ? sl<SourceDomainOverrides>().get(sourceId)
      : null;

  /// Best-effort language code for a source (e.g. "en"), or null when the
  /// ecosystem doesn't report one. Only Aniyomi and Mihon carry a declared
  /// language today (mirrors [_rawSources] above, which does the same lang:
  /// null for CloudStream/JS/LNReader) — used for display only (the browse
  /// screen's identity tags), never for the language-filtering this class
  /// already does elsewhere.
  String? languageFor(String sourceId) {
    final a = _aniManager.get(sourceId);
    if (a is AniyomiProvider) return a.info.lang.isEmpty ? null : a.info.lang;
    final m = _mihonManager.get(sourceId);
    if (m != null) return m.info.lang.isEmpty ? null : m.info.lang;
    final mg = _mangayomiManager?.get(sourceId);
    if (mg != null) {
      return mg.source.language.isEmpty ? null : mg.source.language;
    }
    return null;
  }

  /// The ecosystem a source id belongs to, in the same words the picker uses.
  /// Null for the app's own JS providers — they are the unmarked default.
  static String? ecosystemTag(String id) {
    if (_isCloudStream(id)) return 'CS';
    if (_isAniyomi(id)) return 'Ani';
    if (_isMihon(id)) return 'Mihon';
    if (_isLnReader(id)) return 'LNReader';
    if (_isMangayomi(id)) return 'Mangayomi';
    return null;
  }

  /// Human-friendly name for a source id (falls back to the id itself).
  @override
  String displayName(String sourceId) {
    if (_isCloudStream(sourceId)) {
      return _csManager.get(sourceId)?.displayName ?? sourceId;
    }
    if (_isAniyomi(sourceId)) {
      return _aniManager.get(sourceId)?.displayName ?? sourceId;
    }
    if (_isMihon(sourceId)) {
      return _mihonManager.get(sourceId)?.displayName ?? sourceId;
    }
    if (_isLnReader(sourceId)) {
      return _lnrManager?.get(sourceId)?.displayName ?? sourceId;
    }
    if (_isMangayomi(sourceId)) {
      return _mangayomiManager?.get(sourceId)?.displayName ?? sourceId;
    }
    if (_isStremio(sourceId)) return 'Stremio';
    return _manager.get(sourceId)?.displayName ?? sourceId;
  }

  /// Returns true when [sourceId] resolves to an installed/enabled provider on
  /// this device. Read-only — does not affect resolution or health.
  /// CS ids use identity-compatible lookup ([resolveCompatible]); Aniyomi and JS
  /// ids use their respective manager registries.
  @override
  /// True when [sourceId] is installed and available for playback.
  ///
  /// On TV the QuickJS runtime may be empty (loadAll is skipped), so for JS
  /// providers we also check the [ProviderRegistry] — the registry is the
  /// source of truth for what's installed+enabled; the runtime is just a cache
  /// of what's currently loaded.
  bool hasSource(String sourceId) {
    if (_isCloudStream(sourceId)) {
      return _csManager.resolveCompatible(sourceId) != null;
    }
    if (_isAniyomi(sourceId)) {
      return _aniManager.get(sourceId) != null;
    }
    if (_isMihon(sourceId)) {
      return _mihonManager.get(sourceId) != null;
    }
    if (_isLnReader(sourceId)) {
      return _lnrManager?.get(sourceId) != null;
    }
    if (_isMangayomi(sourceId)) {
      return _mangayomiManager?.get(sourceId) != null;
    }
    if (_isStremio(sourceId)) {
      return sl.isRegistered<StremioProvider>() &&
          sl.isRegistered<StremioManager>() &&
          sl<StremioManager>().enabled.isNotEmpty;
    }
    // JS provider: check runtime first, then registry (TV: runtime may be
    // empty because loadAll was skipped).
    if (_manager.get(sourceId) != null) return true;
    if (sl.isRegistered<ProviderRegistry>()) {
      final entry = sl<ProviderRegistry>().entryFor(sourceId);
      if (entry != null && entry.enabled) return true;
    }
    return false;
  }

  /// Ensures a JS provider is loaded into the QuickJS runtime so it can be
  /// searched/resolved. On phone, providers are loaded at boot; on TV, loadAll
  /// is skipped and providers load on demand. Non-JS sources (CS/Aniyomi/etc.)
  /// are always available through their native managers.
  ///
  /// Returns true if the provider is now available (was already loaded or
  /// loaded successfully). Returns false on timeout or failure — callers
  /// should skip the source.
  Future<bool> ensureSourceLoaded(String sourceId) async {
    if (_isCloudStream(sourceId) ||
        _isAniyomi(sourceId) ||
        _isMihon(sourceId) ||
        _isLnReader(sourceId) ||
        _isMangayomi(sourceId) ||
        _isStremio(sourceId)) {
      return true; // non-JS sources are always available
    }
    if (_manager.get(sourceId) != null) return true; // already loaded
    if (!sl.isRegistered<ProviderRegistry>()) return false;
    try {
      return await sl<ProviderRegistry>().ensureRuntimeLoaded(sourceId);
    } catch (e) {
      debugPrint('[source-repo] ensureSourceLoaded failed for $sourceId: $e');
      return false;
    }
  }

  /// Resolves the provider for a per-call [id], falling back to the active
  /// source when [id] is null. Lets cross-source items (Continue Watching,
  /// My List, etc.) route to their OWN provider instead of the active one.
  /// CloudStream ids (`cs:<name>`) route to the native plugin host; Aniyomi
  /// ids (`ani:<id>`) route to the Aniyomi manager; all others go to the JS
  /// runtime.
  BaseProvider _providerFor(String? id) {
    final resolved = id ?? _active.state;
    // CloudStream ids carry a `@version@repoTag` suffix that differs between
    // installs, so resolve by provider IDENTITY (exact id first) — otherwise a
    // Watch Together room created on one device can't open on another that has
    // the same provider from a different repo/version.
    final BaseProvider? p;
    if (_isCloudStream(resolved)) {
      p = _csManager.resolveCompatible(resolved);
    } else if (_isAniyomi(resolved)) {
      p = _aniManager.get(resolved);
    } else if (_isMihon(resolved)) {
      p = _mihonManager.get(resolved);
    } else if (_isLnReader(resolved)) {
      p = _lnrManager?.get(resolved);
    } else if (_isMangayomi(resolved)) {
      p = _mangayomiManager?.get(resolved);
    } else if (_isStremio(resolved)) {
      p = sl.isRegistered<StremioProvider>() ? sl<StremioProvider>() : null;
    } else {
      p = _manager.get(resolved);
    }
    if (p == null) {
      throw StateError('Provider not loaded: $resolved');
    }
    return p;
  }

  /// [_providerFor], but gives a JS provider that is not in the runtime yet a
  /// chance to load before we give up on it.
  ///
  /// On phone every provider is loaded at boot, so this costs nothing —
  /// [ensureSourceLoaded] returns straight away for a provider already in the
  /// runtime and for every non-JS ecosystem. On TV `loadAll` is skipped and
  /// providers load on demand, so opening a title before anything else had
  /// touched its source (straight into a show from Continue Watching, rather
  /// than via the home rail) threw `Provider not loaded` for a source that was
  /// installed the whole time.
  ///
  /// A source that still will not load falls through to [_providerFor] and
  /// throws exactly as it did before.
  Future<BaseProvider> _providerReady(String? id) async {
    final resolved = id ?? _active.state;
    await ensureSourceLoaded(resolved);
    return _providerFor(resolved);
  }

  Future<List<MediaItem>> popular({
    String category = 'sub',
    int dateRange = 7,
    int page = 1,
    String? sourceId,
  }) async => (await _providerReady(
    sourceId,
  )).popular(category: category, dateRange: dateRange, page: page);

  /// CloudStream-style Home: the active provider's own named rows. When the
  /// provider defines `getHome` we render exactly what it returns (empty rows
  /// dropped). When it doesn't, we synthesize the legacy three rows from
  /// [popular] so older providers keep working. Each underlying fetch is
  /// fail-safe — one broken row never kills the others.
  @override
  Future<List<HomeSection>> home({
    String category = 'sub',
    String? sourceId,
  }) async {
    final provider = await _providerReady(sourceId);

    final sections = await provider.getHome(category: category);
    if (sections != null) {
      return sections.where((s) => s.items.isNotEmpty).toList();
    }

    // Fallback for providers without getHome.
    final results = await Future.wait([
      provider
          .popular(category: category, dateRange: 1)
          .catchError((_) => <MediaItem>[]),
      provider
          .popular(category: category, dateRange: 30)
          .catchError((_) => <MediaItem>[]),
      provider
          .popular(category: category, dateRange: 0)
          .catchError((_) => <MediaItem>[]),
    ]);
    final fallback = <HomeSection>[
      HomeSection(title: 'Trending Now', items: results[0]),
      HomeSection(title: 'Popular This Month', items: results[1]),
      HomeSection(title: 'All-Time Favorites', items: results[2]),
    ];
    return fallback.where((s) => s.items.isNotEmpty).toList();
  }

  /// Fetches the next [page] of a paginable Home row (the "See all" grid's
  /// infinite scroll), routing on [BrowseMore.kind]:
  ///   * `ani_popular` → the Aniyomi/JS provider's `popular(page:)`
  ///   * `ani_latest`  → the Aniyomi provider's `latest(page:)`
  ///   * `mihon_popular` → the Mihon manga provider's `popular(page:)`
  ///   * `mihon_latest`  → the Mihon manga provider's `latest(page:)`
  ///   * `lnr_popular` → the LNReader novel provider's `popular(page:)`
  ///   * `cs_mainpage` → the CloudStream provider's `browseMainPage(id, page)`
  ///   * `js_home`    → a JS provider's `getHomePage(rowId, page)`
  ///
  /// Never throws — any failure (unknown kind, wrong provider type, provider
  /// error) degrades to an empty list so the caller just stops the scroll.
  Future<List<MediaItem>> browseMore(BrowseMore more, int page) async {
    try {
      if (more.kind == 'stremio_catalog') {
        if (!sl.isRegistered<StremioProvider>()) return const [];
        final raw = more.categoryId;
        if (raw == null) return const [];
        final handle = jsonDecode(raw) as Map;
        return await sl<StremioProvider>().catalogPage(
          installationId: handle['i'] as String,
          type: handle['t'] as String,
          catalogId: handle['c'] as String,
          page: page,
        );
      }
      final p = await _providerReady(more.sourceId);
      switch (more.kind) {
        case 'ani_popular':
          return p.popular(page: page);
        case 'ani_latest':
          return p is AniyomiProvider ? p.latest(page: page) : const [];
        case 'mihon_popular':
          return p.popular(page: page);
        case 'mihon_latest':
          return p is MihonProvider ? p.latest(page: page) : const [];
        case 'lnr_popular':
          return p.popular(page: page);
        case 'mg_popular':
          return p.popular(page: page);
        case 'mg_latest':
          return p is MangayomiProvider ? p.latest(page: page) : const [];
        case 'cs_mainpage':
          return (p is CloudStreamProvider && more.categoryId != null)
              ? p.browseMainPage(more.categoryId!, page)
              : const [];
        case 'js_home':
          return (p is JsProvider && more.categoryId != null)
              ? p.getHomePage(more.categoryId!, page)
              : const [];
        default:
          return const [];
      }
    } catch (_) {
      return const [];
    }
  }

  @override
  Future<List<MediaItem>> search(
    String query, {
    String category = 'sub',
    String? sourceId,
  }) async =>
      (await _providerReady(sourceId)).search(query, 1, category: category);

  /// Status-reporting search for the source-health feature (search ordering +
  /// the "Test sources" screen). Unlike [search] it surfaces whether a source
  /// FAILED vs simply returned nothing, so the caller can record health
  /// correctly (empty-without-error is ALIVE, only error/timeout is dead).
  ///
  ///  - `outcome` is one of [SourceOutcome] (ok / empty / timeout / blocked /
  ///    error). It NEVER throws — failures are mapped to an outcome.
  ///  - For JS providers, [BaseProvider.search] throws on error (caught here);
  ///    an empty list is reported as [SourceOutcome.empty].
  ///  - For CloudStream sources it routes to [CloudStreamProvider.searchWithStatus]
  ///    (native `searchStatus`), which distinguishes timeout/error from empty.
  ///  - For Aniyomi sources, [filtersJson] (when non-null) is forwarded to the
  ///    provider so the native bridge can apply the user's filter selection.
  ///    CloudStream and JS paths never receive it.
  ///  - Mihon manga sources forward [filtersJson] the same way (their bridge
  ///    takes the identical `filters` argument).
  ///
  /// CF suppression is reused automatically: JS search goes through the
  /// provider-manager `search` path (suppresses the solver) and CS search goes
  /// through native `searchStatus` (bumps `CfClearance.searchDepth`).
  /// [cache] opts this call into the short-TTL search cache + in-flight dedup
  /// (see [_searchCache]). Off by default so probes/tests and filter-apply always
  /// hit the network fresh; the cross-source search fan-out passes `cache: true`.
  @override
  Future<({List<MediaItem> items, SourceOutcome outcome})> searchStatus(
    String query, {
    String category = 'sub',
    String? sourceId,
    String? filtersJson,
    bool cache = false,
    int page = 1,
  }) {
    final resolved = sourceId ?? _active.state;
    if (!cache) {
      return _searchStatusUncached(
        query,
        category: category,
        sourceId: resolved,
        filtersJson: filtersJson,
        page: page,
      );
    }
    final key = _searchKey(resolved, query, category, filtersJson, page);
    final hit = _searchCache[key];
    if (hit != null && DateTime.now().difference(hit.at) < _searchTtl) {
      return Future.value((items: hit.items, outcome: hit.outcome));
    }
    final inflight = _searchInflight[key];
    if (inflight != null) return inflight; // share an already-running fetch
    final future =
        _searchStatusUncached(
          query,
          category: category,
          sourceId: resolved,
          filtersJson: filtersJson,
          page: page,
        ).then((res) {
          // Cache only successful outcomes so a transient failure isn't remembered.
          if (res.outcome == SourceOutcome.ok ||
              res.outcome == SourceOutcome.empty) {
            _searchCache[key] = (
              at: DateTime.now(),
              items: res.items,
              outcome: res.outcome,
            );
          }
          return res;
        });
    _searchInflight[key] = future;
    future.whenComplete(() => _searchInflight.remove(key));
    return future;
  }

  Future<({List<MediaItem> items, SourceOutcome outcome})>
  _searchStatusUncached(
    String query, {
    String category = 'sub',
    String? sourceId,
    String? filtersJson,
    int page = 1,
  }) async {
    final resolved = sourceId ?? _active.state;
    try {
      if (_isCloudStream(resolved)) {
        final p = _csManager.get(resolved);
        if (p is! CloudStreamProvider) {
          return (items: const <MediaItem>[], outcome: SourceOutcome.error);
        }
        final r = await p.searchWithStatus(query);
        if (r.error != null) {
          return (items: r.items, outcome: _outcomeFromError(r.error!));
        }
        return (
          items: r.items,
          outcome: r.items.isEmpty ? SourceOutcome.empty : SourceOutcome.ok,
        );
      }
      final provider = await _providerReady(resolved);
      final items = (_isAniyomi(resolved) && provider is AniyomiProvider)
          ? await provider.search(
              query,
              page,
              category: category,
              filtersJson: filtersJson,
            )
          : (_isMihon(resolved) && provider is MihonProvider)
          ? await provider.search(
              query,
              page,
              category: category,
              filtersJson: filtersJson,
            )
          : (_isMangayomi(resolved) && provider is MangayomiProvider)
          ? await provider.search(
              query,
              page,
              category: category,
              filtersJson: filtersJson,
            )
          : await provider.search(query, page, category: category);
      return (
        items: items,
        outcome: items.isEmpty ? SourceOutcome.empty : SourceOutcome.ok,
      );
    } catch (e) {
      return (items: const <MediaItem>[], outcome: _outcomeFromError('$e'));
    }
  }

  /// Returns the typed Aniyomi filter schema for [sourceId], or an empty list
  /// for non-Aniyomi sources or when the source has no filters.
  Future<List<AniyomiFilter>> aniFilters(String sourceId) async {
    if (!_isAniyomi(sourceId)) return const [];
    final p = _providerFor(sourceId);
    return p is AniyomiProvider ? p.getFilters() : const [];
  }

  Future<List<Map<String, dynamic>>> mangayomiFilters(String sourceId) async {
    final provider = _mangayomiManager?.get(sourceId);
    if (provider == null) return const [];
    try {
      return await provider.getFilters();
    } catch (_) {
      return const [];
    }
  }

  /// Mihon twin of [aniFilters] — the typed manga filter schema for [sourceId],
  /// or an empty list for non-Mihon sources / sources with no filters. Separate
  /// method (and a separate `MihonFilter` type) rather than a shared one, per
  /// spec Decision 3: the anime path never changes for a manga change.
  Future<List<MihonFilter>> mihonFilters(String sourceId) async {
    if (!_isMihon(sourceId)) return const [];
    final p = _providerFor(sourceId);
    return p is MihonProvider ? p.getFilters() : const [];
  }

  /// Classifies a failure message into a [SourceOutcome]. Timeouts and CF/WAF
  /// blocks get their own reason; everything else is a generic error.
  static SourceOutcome _outcomeFromError(String message) {
    final m = message.toLowerCase();
    if (m.contains('timed out') ||
        m.contains('timeout') ||
        m.contains('deadline')) {
      return SourceOutcome.timeout;
    }
    if (m.contains('cloudflare') ||
        m.contains('cf_clearance') ||
        m.contains('challenge') ||
        m.contains('403') ||
        m.contains('forbidden') ||
        m.contains('blocked') ||
        m.contains('captcha')) {
      return SourceOutcome.blocked;
    }
    return SourceOutcome.error;
  }

  @override
  Future<MediaDetail> detail(
    String url, {
    String category = 'sub',
    String? sourceId,
    // A source detail arrives whole — there is no slow second half to skip
    // ahead of, so this is accepted for the interface and never called.
    void Function(MediaDetail partial)? onPartial,
    bool Function()? abandoned,
  }) async {
    final sw = Stopwatch()..start();
    final sid = sourceId ?? _active.state;
    AppLogger.instance.log(
      '[detail] source fetch start sourceId=$sid url=$url',
    );
    try {
      final p = await _providerReady(sourceId);
      // Only the JS providers share the serialized call queue this is meant to
      // unblock; the native ecosystems each run their own calls, so there is
      // nothing for them to wait behind and nothing to pass on.
      final d = p is JsProvider
          ? await p.getDetail(url, category: category, abandoned: abandoned)
          : await p.getDetail(url, category: category);
      AppLogger.instance.log(
        '[detail] source fetch done title="${d.title}" eps=${d.episodes.length} '
        '${sw.elapsedMilliseconds}ms',
      );
      // Providers disagree on order (Aniyomi/Tachiyomi extensions are
      // newest-first); the toggle only flips, so normalize here, once.
      final ordered = normalizeEpisodeOrder(d.episodes);
      return identical(ordered, d.episodes) ? d : d.copyWith(episodes: ordered);
    } catch (e, st) {
      AppLogger.instance.log(
        '[detail] source fetch failed ${sw.elapsedMilliseconds}ms: $e',
        level: 'E',
      );
      AppLogger.instance.logError(e, st);
      rethrow;
    }
  }

  /// Drop the native source HTTP cache (Mihon/Aniyomi) so a subsequent fetch is
  /// fresh — used by pull-to-refresh. No-op on platforms/sources without it.
  @override
  Future<void> clearHttpCache() => clearMihonHttpCache();

  @override
  Future<List<Episode>> episodes(
    String url, {
    String category = 'sub',
    String? sourceId,
  }) async => normalizeEpisodeOrder(
    await (await _providerReady(sourceId)).getEpisodes(url, category: category),
  );

  /// The links resolved SO FAR for [episodeUrl], plus whether more may arrive.
  ///
  /// A fast [sources] call returns on the first usable link while the native
  /// resolve keeps running, so mirrors needing an extra round-trip land shortly
  /// afterwards. This reads that growing set without starting any work.
  ///
  /// CloudStream sources only — every other provider resolves in one shot, so
  /// there is nothing to poll. Those (and any failure) report `done: true` with
  /// no sources, which tells a caller to simply stop asking.
  @override
  Future<({List<VideoSource> sources, bool done})> polledSources(
    String episodeUrl, {
    String? sourceId,
  }) async {
    final provider = _providerFor(sourceId);
    if (provider is! CloudStreamProvider) {
      return (sources: const <VideoSource>[], done: true);
    }
    try {
      return await provider.pollVideoSources(episodeUrl);
    } catch (_) {
      // Never surfaced: the caller already has a playable list.
      return (sources: const <VideoSource>[], done: true);
    }
  }

  /// Resolve playable sources. [fast] (playback) returns as soon as the first
  /// link(s) are ready; downloads leave it false to get every mirror. A fast
  /// call reuses a fresh [prefetch] for the same episode when one exists.
  @override
  Future<List<VideoSource>> sources(
    String episodeUrl, {
    String? sourceId,
    bool fast = false,
  }) async {
    if (fast) {
      final key = _prefetchKey(episodeUrl, sourceId);
      // 1. One-shot prefetch started on the detail screen.
      final entry = _prefetch.remove(key);
      if (entry != null && DateTime.now().difference(entry.at) < _prefetchTtl) {
        final cached = await entry.future;
        // Fall through to a fresh resolve only if the prefetch came back empty
        // (or had failed → []), so this is never worse than no prefetch.
        if (cached.isNotEmpty) {
          _resolved[key] = (at: DateTime.now(), sources: cached);
          return cached;
        }
      }
      // 2. Persistent TTL cache → instant re-open of a recent episode.
      final hit = _resolved[key];
      if (hit != null &&
          hit.sources.isNotEmpty &&
          DateTime.now().difference(hit.at) < _resolvedTtl) {
        return hit.sources;
      }
      // 3. Fresh resolve → cache it for the next re-open.
      final provider = await _providerReady(sourceId);
      final fresh = await provider.getVideoSources(episodeUrl, fast: true);
      if (fresh.isNotEmpty) {
        _resolved[key] = (at: DateTime.now(), sources: fresh);
      }
      return fresh;
    }
    return (await _providerReady(
      sourceId,
    )).getVideoSources(episodeUrl, fast: fast);
  }

  /// Manga leaf — ordered page images for [chapterUrl]. No expiry cache here:
  /// unlike stream links, page image URLs don't rot within a session, so this
  /// never touches [_prefetch]/[_resolved]. Throws [UnsupportedError] if the
  /// resolved source isn't a [ReadingProvider] (e.g. CloudStream/Aniyomi) —
  /// unreachable through mode-filtered UI, but a hard guard regardless.
  Future<List<PageImage>> pages(String chapterUrl, {String? sourceId}) async {
    // Saved chapter wins, so a download is actually worth having. Local paths
    // come back in `url` with no headers; the reader picks the file loader for
    // anything that isn't http.
    final local = await _localPages(chapterUrl, sourceId);
    if (local != null) return local;

    final key = '${sourceId ?? _active.state}|$chapterUrl';
    final hit = _pageListCache[key];
    if (hit != null && !hit.stale) return hit.pages;

    // Someone is already fetching this exact chapter — wait for THAT request
    // instead of starting a second one.
    //
    // Measured on a real source: a page list took 8-14 SECONDS to come back,
    // and warming the next chapter meant the reader then asked for the same
    // chapter again while the first request was still in the air. Both waited
    // the full time; one of them was pure waste. A finished-result cache can't
    // help here, because neither request has finished yet.
    // Resolved BEFORE the in-flight check on purpose: this can await (a TV
    // loads a provider on demand), and an await between that check and the
    // registration below would let a second caller slip past it and fetch the
    // same chapter twice — the exact waste the check exists to stop.
    final p = await _providerReady(sourceId);

    final inFlight = _pageFetches[key];
    if (inFlight != null) return inFlight;

    if (p is! ReadingProvider) {
      throw UnsupportedError('${p.sourceId} does not support reading content');
    }
    // ReadingProvider is deliberately unrelated to BaseProvider (Task 3), so
    // the `is!` check above doesn't statically promote — cast explicitly.
    final future = _fetchPages(p as ReadingProvider, key, chapterUrl);
    _pageFetches[key] = future;
    try {
      return await future;
    } finally {
      _pageFetches.remove(key);
    }
  }

  Future<List<PageImage>> _fetchPages(
    ReadingProvider p,
    String key,
    String chapterUrl,
  ) async {
    final started = DateTime.now();
    final fetched = await p.getPages(chapterUrl);
    final ms = DateTime.now().difference(started).inMilliseconds;
    // The reader shows a spinner for exactly this long, and until now nothing
    // recorded it — so "it was black for a few seconds" was unanswerable from
    // a shared log. Cheap, and the number is the whole diagnosis.
    debugPrint('[reader] ${fetched.length} pages in ${ms}ms · $chapterUrl');
    if (fetched.isNotEmpty) _rememberPages(key, fetched);
    return fetched;
  }

  /// Page fetches currently in the air, keyed like [_pageListCache]. Entries
  /// live only for the length of the request.
  final Map<String, Future<List<PageImage>>> _pageFetches = {};

  /// Page lists the reader has already fetched, so reopening the chapter you
  /// were just reading — or stepping back one — doesn't sit on a spinner
  /// waiting for a request whose answer hasn't changed.
  ///
  /// Deliberately in memory and deliberately short-lived. Plenty of sources
  /// hand back image URLs signed with a short-lived token; caching those to
  /// disk, or for an hour, would trade a spinner for broken pages. Ten minutes
  /// covers "flip forward, flip back" and nothing riskier, and the whole thing
  /// dies with the process.
  static const _pageCacheTtl = Duration(minutes: 10);
  static const _pageCacheMax = 12;
  final Map<String, _CachedPages> _pageListCache = {};

  void _rememberPages(String key, List<PageImage> pages) {
    _pageListCache.remove(key); // re-insert so the oldest key is first out
    _pageListCache[key] = _CachedPages(pages, DateTime.now());
    while (_pageListCache.length > _pageCacheMax) {
      _pageListCache.remove(_pageListCache.keys.first);
    }
  }

  /// Fetches a chapter's pages into the cache without returning them — the
  /// reader calls this for the NEXT chapter once you're most of the way
  /// through the current one, so tapping through lands on pages instead of a
  /// spinner. Silent on failure: this is a guess about what you'll read next,
  /// and a wrong guess must never surface as an error.
  Future<void> warmPages(String chapterUrl, {String? sourceId}) async {
    final key = '${sourceId ?? _active.state}|$chapterUrl';
    final hit = _pageListCache[key];
    if (hit != null && !hit.stale) return;
    try {
      await pages(chapterUrl, sourceId: sourceId);
    } catch (_) {}
  }

  /// Pages of a downloaded chapter, or null when it isn't saved. Resolved
  /// through the locator rather than a constructor field so the repository
  /// keeps working in tests that never register the store.
  Future<List<PageImage>?> _localPages(
    String chapterUrl,
    String? sourceId,
  ) async {
    if (!sl.isRegistered<ChapterDownloadStore>()) return null;
    try {
      final store = sl<ChapterDownloadStore>();
      final rec = store.get(
        ChapterDownload.idFor(sourceId ?? _active.state, chapterUrl),
      );
      if (rec == null || rec.status != ChapterDownloadStatus.done) return null;
      final paths = await store.localPages(rec);
      if (paths.isEmpty) return null;
      return [for (final path in paths) PageImage(url: path)];
    } catch (_) {
      return null; // a broken download must not stop the chapter opening
    }
  }

  /// Novel leaf — chapter text for [chapterUrl]. Same no-cache rationale and
  /// [ReadingProvider] guard as [pages].
  Future<ChapterText> chapterText(String chapterUrl, {String? sourceId}) async {
    if (sl.isRegistered<ChapterDownloadStore>()) {
      try {
        final store = sl<ChapterDownloadStore>();
        final rec = store.get(
          ChapterDownload.idFor(sourceId ?? _active.state, chapterUrl),
        );
        if (rec != null && rec.status == ChapterDownloadStatus.done) {
          final html = await store.localText(rec);
          if (html != null && html.isNotEmpty) {
            // The chapter's own folder on disk — a downloaded chapter's
            // images (if it has any) sit right next to text.html, and the
            // reader resolves their relative `src` against this.
            final folder = rec.textPath != null
                ? File(rec.textPath!).parent.path
                : (await store.dirFor(rec)).path;
            return ChapterText(html: html, folder: folder);
          }
        }
      } catch (_) {
        // fall through to the network
      }
    }
    final p = await _providerReady(sourceId);
    if (p is! ReadingProvider) {
      throw UnsupportedError('${p.sourceId} does not support reading content');
    }
    return (p as ReadingProvider).getText(chapterUrl);
  }

  /// Drop the cached fast-resolution for an episode so the next [sources] call
  /// re-scrapes fresh links. Called when every mirror stalls — the cached links
  /// have likely expired. No-op when the episode isn't cached (e.g. downloads).
  ///
  /// [includePrefetch] also drops an in-flight/complete prefetch for the same
  /// episode. Off by default: the stall path wants the prefetch kept, since it
  /// may be the thing about to succeed. A user asking to reload links wants it
  /// gone — the next fast call consumes the prefetch before it ever looks at
  /// [_resolved], so leaving it would hand back the same stale links and make
  /// the reload look like it did nothing.
  void invalidateSources(
    String episodeUrl, {
    String? sourceId,
    bool includePrefetch = false,
  }) {
    final key = _prefetchKey(episodeUrl, sourceId);
    final hadResolved = _resolved.remove(key) != null;
    final hadPrefetch = includePrefetch && _prefetch.remove(key) != null;
    // Logged because there is otherwise no way to tell a working reload from a
    // no-op: the caches are in-memory, and a reload that cleared nothing looks
    // exactly like one that cleared everything.
    AppLogger.instance.log(
      '[links] invalidate ${_short(episodeUrl)} '
      'resolved=${hadResolved ? "cleared" : "none"} '
      'prefetch=${hadPrefetch
          ? "cleared"
          : includePrefetch
          ? "none"
          : "kept"}',
    );
  }

  /// Tail of a URL — enough to tell two episodes apart in a log without
  /// printing signed query strings.
  static String _short(String url) {
    final path = url.split('?').first;
    return path.length <= 42 ? path : '…${path.substring(path.length - 42)}';
  }

  /// Fire-and-forget background resolution for [episodeUrl] (the episode the
  /// detail screen's Play will start) so the actual play is near-instant. Safe
  /// to call repeatedly — deduped within [_prefetchTtl], errors swallowed.
  void prefetch(String episodeUrl, {String? sourceId}) {
    final key = _prefetchKey(episodeUrl, sourceId);
    final existing = _prefetch[key];
    if (existing != null &&
        DateTime.now().difference(existing.at) < _prefetchTtl) {
      return;
    }
    final future = _providerFor(sourceId)
        .getVideoSources(episodeUrl, fast: true)
        .catchError((_) => <VideoSource>[]);
    _prefetch[key] = (at: DateTime.now(), future: future);
  }
}

/// [SourceRepository.displayName] with its ecosystem in front —
/// "Ani · AniKoto".
///
/// For anywhere a source is named ON ITS OWN, with no list around it to give
/// context: the active-source line, the detail page's source pill. Two
/// ecosystems can ship the same name — the app's own AniKoto and Aniyomi's —
/// and a bare name can't say which one you are actually on.
///
/// An extension rather than a method on the class, deliberately: the fakes in
/// the tests `implement SourceRepository` and answer everything else through
/// noSuchMethod, so a new instance method would throw in each of them for a
/// name they only ever wanted composed from displayName.
extension SourceNameTag on SourceRepository {
  String taggedName(String sourceId) {
    final name = displayName(sourceId);
    final tag = SourceRepository.ecosystemTag(sourceId);
    return tag == null ? name : '$tag · $name';
  }
}

/// Chronological episode order (1→N) regardless of which provider served the
/// list. Aniyomi/Tachiyomi extensions — and several other ecosystems — return
/// episodes newest-first (N→1); without this, a title opens "reversed" with
/// the reverse toggle off, identically on TV and phone (both share this
/// funnel — the toggle only flips, it never sorts).
///
/// Sorts by (season, number) when every episode is numbered (keeps
/// 12 → 12.5 → 13 and multi-season lists correct) and returns the list
/// untouched when already ordered. Unnumbered lists keep arrival order:
/// direction is unprovable there, and flipping blindly would break
/// oldest-first sources. ponytail: one funnel, not one fix per provider.
List<Episode> normalizeEpisodeOrder(List<Episode> eps) {
  if (eps.length < 2 || eps.any((e) => e.number == null)) return eps;
  var ordered = true;
  for (var i = 1; i < eps.length; i++) {
    final p = eps[i - 1];
    final c = eps[i];
    final ps = p.season ?? 0;
    final cs = c.season ?? 0;
    if (cs < ps || (cs == ps && c.number! < p.number!)) {
      ordered = false;
      break;
    }
  }
  if (ordered) return eps;
  return [...eps]..sort((a, b) {
    final s = (a.season ?? 0).compareTo(b.season ?? 0);
    return s != 0 ? s : a.number!.compareTo(b.number!);
  });
}

/// One chapter's page list plus when it was fetched — see
/// `SourceRepository._pageListCache` for why it expires.
class _CachedPages {
  const _CachedPages(this.pages, this.at);

  final List<PageImage> pages;
  final DateTime at;

  bool get stale =>
      DateTime.now().difference(at) > SourceRepository._pageCacheTtl;
}
