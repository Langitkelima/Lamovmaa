import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;

import 'package:flutter/foundation.dart';

import 'package:dio/dio.dart';
import 'package:flutter/services.dart';

import '../aniyomi/aniyomi_extension_service.dart';
import '../aniyomi/aniyomi_provider.dart';
import '../aniyomi/aniyomi_update.dart';
import '../error/exceptions.dart';
import '../models/episode.dart';
import '../models/home_section.dart';
import '../models/media_detail.dart';
import '../models/media_item.dart';
import '../models/page_content.dart';
import '../models/provider_info.dart';
import '../models/video_source.dart';
import '../platform/apple_tv.dart';
import 'base_provider.dart';
import 'cf_clearance_store.dart';
import 'cf_solve_needed.dart';
import 'crypto_ops.dart';
import 'js_bootstrap.dart';
import 'js_call_scheduler.dart';
import 'js_engine.dart';
import 'reading_provider.dart';

enum ProviderHealthStatus { healthy, degraded, broken }

class _ProviderHealth {
  _ProviderHealth({
    required this.failures,
    required this.lastError,
    required this.status,
  });
  final int failures;
  final String lastError;
  final ProviderHealthStatus status;
}

/// Single shared QuickJS runtime hosting every provider as
/// `__providers[sourceId]` and every extractor as `__extractors[host]`.
/// A Cloudflare **block** (error 1020), as opposed to a challenge.
///
/// The two look alike from the outside: both are a 403 served by Cloudflare, and
/// the block page even loads the same challenge-platform script, so the
/// challenge predicate says yes to both — and the app answers a block by opening
/// a solver that can never clear it. A block has no puzzle; the host refuses this
/// client outright, and kwik.cx refuses every HTTP/1.1 request whatever cookie it
/// carries. Only the wording separates them: a real challenge says "just a
/// moment", a block says it has blocked you.
bool looksLikeCloudflareBlock(int status, String body) {
  if (status != 403) return false;
  final b = body.toLowerCase();
  if (b.contains('just a moment') || b.contains('cf-chl')) return false;
  return b.contains('you have been blocked') || b.contains('error code: 1020');
}

/// Whether a JS-provider response is a Cloudflare challenge the WebView solver
/// could actually pass.
///
/// `server: cloudflare` used to be enough on its own. It is not evidence of
/// anything: Cloudflare fronts a large slice of the web and stamps that header
/// on every ordinary 403 it serves — a hotlink block on a stream CDN, a WAF
/// rule, an expired token. Each of those got latched as "needs a solve", which
/// made the resolver skip the source entirely and put up a button that opened
/// a WebView with no challenge in it, so the solve could never succeed. Across
/// 37 shared reports that was 22 sources flagged and not one solved; on the dev
/// phone it was `fetch.nexabloom.top` (403, `server: cloudflare`, no challenge
/// anywhere in the body) taking AniKoto out of every sweep.
///
/// So Cloudflare has to actually say it is challenging: the `cf-mitigated`
/// header it sets on a real one, or the interstitial's own markup.
///
/// Scope is deliberately the JS providers only. CloudStream keeps its own
/// predicate in PluginHost.kt, and Aniyomi/Mihon/LNReader theirs — none of
/// them route through here.
@visibleForTesting
bool looksLikeCfChallenge({
  required int status,
  required String body,
  String? cfMitigated,
}) {
  if (status != 403 && status != 503) return false;
  if ((cfMitigated ?? '').toLowerCase().contains('challenge')) return true;
  final b = body.toLowerCase();
  return b.contains('just a moment') ||
      b.contains('challenge-platform') ||
      b.contains('cf-chl') ||
      b.contains('checking your browser') ||
      b.contains('enable javascript and cookies');
}

/// Thrown instead of running a queued provider call whose caller has gone.
///
/// Its own type so a caller can tell "you left" apart from a real failure: a
/// screen that has closed must not record this against the source's health,
/// and must not show an error nobody is there to read.
class ProviderCallAbandoned implements Exception {
  const ProviderCallAbandoned();
  @override
  String toString() => 'Provider call abandoned — the caller had gone';
}

class _JsHost {
  /// Hard ceiling on any single provider fetch, whatever the source asked for.
  /// A source's patience must not become everyone else's stall.
  static const int maxProviderFetchTimeoutMs = 25000;

  /// Hard ceiling on a whole `call`, across every fetch it chains. The engine
  /// runs one call at a time, so this is what stops one slow source freezing
  /// the app instead of just its own screen.
  static const Duration maxProviderCallTimeout = Duration(seconds: 25);

  _JsHost({required this.dio}) {
    _engine = JsEngine(onChannel: _onChannel, polling: isAppleTv);
  }

  /// Everything the runtime asks Dart for. Deliberately all still on THIS
  /// isolate even when the engine is on its own: fetch needs Dio, the native
  /// Cloudflare solver, the Hive clearance store and [CfSolveNeeded]; console
  /// needs the app log. A port hop costs microseconds against an HTTP request,
  /// and this way none of that has to learn about isolates.
  void _onChannel(String channel, dynamic payload) {
    switch (channel) {
      case 'fetch':
        _onFetch(payload);
      case 'console':
        _onConsole(payload);
      case 'crypto':
        _onCrypto(payload);
      case 'timer':
        _onTimer(payload);
    }
  }

  final Dio dio;
  late final JsEngine _engine;
  final Map<String, JsProvider> providers = {};
  int _providerCallSeq = 0;

  // Serialize every provider call onto ONE queue. flutter_js/QuickJS is single-
  // threaded and non-reentrant; overlapping calls race its async FFI callback
  // ("Callback invoked after it has been deleted" → native SIGABRT, the frequent
  // crash). Running calls strictly one-at-a-time removes that race. The runtime's
  // OWN re-entrant resolves (__resolveFetch/__fireTimer/__resolveCrypto) do NOT
  // take this lock, so an in-flight call can still be fed while it pumps the JS
  // event loop — i.e. this can't deadlock.

  // Cloudflare bridge: JS providers opt into a CF-cleared request via
  // fetch(url, { browser: true }). We reuse the native WebView solver (the same
  // one the CloudStream side uses) over a MethodChannel and cache the solved
  // clearance cookie + matching User-Agent per host. Android-only; on platforms
  // without the handler the invoke throws and we fall back to a plain request.
  static const MethodChannel _cf = MethodChannel('zangetsu/cloudstream');

  /// The novel path's OkHttp lane — see [_retryOverNative].
  static const MethodChannel _novelHttp = MethodChannel('zangetsu/novel_http');
  final Map<String, String> _cfCookie = {}; // host -> cf_clearance cookie(s)
  final Map<String, String> _cfUa = {}; // host -> the solving User-Agent
  // Persists solved clearances across restarts so a JS source cleared once
  // doesn't re-pop the "Verifying…" solver every fresh session (the CS path gets
  // this for free via the CookieManager jar; the Dart Dio client does not).
  final CfClearanceStore _cfStore = CfClearanceStore();
  bool _cfRestored = false; // hydrate the in-memory maps from disk once, lazily
  // Negative cache: hosts where a solve just failed (e.g. a dead/parked domain
  // that never yields a clearance cookie). Without this, every browser:true
  // request re-runs the ~30s WebView solve and the app hangs for minutes. We
  // attempt at most once per host per [_cfFailTtlMs], then fall through to a
  // plain request so the provider fails fast instead of looping the solver.
  final Map<String, int> _cfFailedAt = {}; // host -> ms of last failed solve
  // 30 min: a source we can't clear (e.g. an interactive/Turnstile challenge)
  // must NOT re-pop the solver every couple of minutes — that's the "verifying
  // again and again" the user sees. One attempt, then leave it alone for a while.
  static const int _cfFailTtlMs = 1800000; // 30 min
  // In-flight solves keyed by host: concurrent requests (e.g. getHome fetching
  // several pages at once) share ONE 30s WebView solve instead of each spawning
  // its own — otherwise a single page load fires N parallel solvers.
  final Map<String, Future<void>> _cfInflight = {};

  // While a `search` runs, never pop the blocking CF WebView solver: search is
  // a passive multi-source sweep, so a background source's challenge must not
  // hijack the screen. Cached clearance is still applied; an unsolved CF source
  // just returns nothing for search. The solve happens later, when the user
  // actually opens/plays from that source.
  bool _suppressCfSolve = false;

  /// Held above zero while a PASSIVE survey runs — the "where to watch" probe,
  /// which asks every source whether it lists an episode.
  ///
  /// Same rule as `search`, for the same reason, but it cannot be inferred
  /// from the method name: a probe calls `getEpisodes`, which on a normal play
  /// absolutely should solve a challenge. Measured on device, a probe of one
  /// Cloudflare-protected source launched the blocking WebView solver in the
  /// background and stalled the app for twelve seconds — long after the probe
  /// itself had been abandoned at its five-second budget.
  ///
  /// A counter, not a bool, so overlapping surveys can't clear each other's
  /// suppression on the way out.
  int _passiveDepth = 0;

  /// Runs [body] with the blocking Cloudflare solver disabled. A challenged
  /// source simply answers "nothing" and is recorded via [CfSolveNeeded], so
  /// the UI can still offer a manual solve later.
  Future<T> asPassiveSweep<T>(Future<T> Function() body) async {
    _passiveDepth++;
    try {
      return await body();
    } finally {
      _passiveDepth--;
    }
  }

  final Map<String, _ProviderHealth> _health = {};

  ProviderHealthStatus healthFor(String sourceId) =>
      _health[sourceId]?.status ?? ProviderHealthStatus.healthy;
  String? lastErrorFor(String sourceId) => _health[sourceId]?.lastError;
  int failuresFor(String sourceId) => _health[sourceId]?.failures ?? 0;
  void resetHealth(String sourceId) => _health.remove(sourceId);

  /// Awaits the engine so a bootstrap failure surfaces here rather than as a
  /// pile of confusing per-call errors later.
  Future<void> loadProvider(String sourceId, String jsSource) async {
    await _engine.ready;
    final r = await _engine.eval(wrapProviderSource(sourceId, jsSource));
    if (r.isError) {
      throw JsRuntimeException(
        'Provider eval failed for $sourceId: ${r.value}',
      );
    }
  }

  Future<void> loadExtractor(String extractorId, String jsSource) async {
    await _engine.ready;
    final r = await _engine.eval(wrapExtractorSource(extractorId, jsSource));
    if (r.isError) {
      throw JsRuntimeException(
        'Extractor eval failed for $extractorId: ${r.value}',
      );
    }
  }

  void removeProvider(String sourceId) {
    _engine.post('delete globalThis.__providers[${jsonEncode(sourceId)}];');
  }

  /// Pushes [settings] into the JS runtime as `__settings[sourceId]`.
  /// Best-effort and never throws — the result is only read to log a failure.
  /// Replaces the slot entirely so cleared keys disappear from the JS side
  /// too. Providers read it as `__settings[__SOURCE_ID]` inside their wrapped
  /// closure.
  void setSettings(String sourceId, Map<String, dynamic> settings) {
    _engine
        .eval('__settings[${jsonEncode(sourceId)}] = ${jsonEncode(settings)};')
        .then((r) {
          if (r.isError) {
            debugPrint('[settings] push failed for $sourceId: ${r.value}');
          }
        })
        .catchError((Object e) {
          debugPrint('[settings] push failed for $sourceId: $e');
        });
  }

  final _scheduler = JsCallScheduler();

  /// Reads the zone the call was scheduled in. A zone rather than a parameter
  /// because the call chain is six layers deep and threading a lane flag
  /// through all of them is a diff nobody can review — so only the few
  /// fire-and-forget origins set it, and everything else stays interactive.
  CallLane _laneNow() => Zone.current[ProviderManager.backgroundKey] == true
      ? CallLane.background
      : CallLane.interactive;

  Future<String> call(
    String sourceId,
    String method,
    List<Object?> args, {
    Duration timeout = const Duration(seconds: 15),
    bool Function()? abandoned,
  }) async {
    try {
      final v = await _scheduler
          .enqueue<String>(
            sourceId,
            method,
            () => _runCall(sourceId, method, args, timeout),
            lane: _laneNow(),
            abandoned: abandoned,
          )
          // One call owns the shared engine, so a call that overruns holds
          // every other source hostage. `maxProviderFetchTimeoutMs` bounds a
          // single fetch, but a call is several fetches chained inside the
          // provider, so the total could still reach ~30s (measured: a
          // `fuckingfast.net` download ran 30306ms and 82 calls queued behind
          // it, each then burning the full queue wait). Bound the whole call
          // so one slow site costs its own search and nothing else.
          .timeout(maxProviderCallTimeout);
      _health.remove(sourceId);
      return v;
    } on ProviderCallAbandoned {
      // The viewer left. That says nothing about the source, so it must not
      // count towards the failure tally that marks one degraded or broken.
      rethrow;
    } catch (e) {
      final failures = (_health[sourceId]?.failures ?? 0) + 1;
      _health[sourceId] = _ProviderHealth(
        failures: failures,
        lastError: e.toString(),
        status: failures >= 3
            ? ProviderHealthStatus.broken
            : ProviderHealthStatus.degraded,
      );
      rethrow;
    }
  }

  Future<String> _runCall(
    String sourceId,
    String method,
    List<Object?> args,
    Duration timeout,
  ) async {
    final wasSuppress = _suppressCfSolve;
    _suppressCfSolve = _passiveDepth > 0 || method == 'search';
    try {
      final argsJson = jsonEncode(args);
      if (isAppleTv) {
        return await _runAppleTvCall(sourceId, method, argsJson, timeout);
      }
      // __callProviderT (not __callProvider): a JS-side deadline settles the
      // promise even if the source hangs, so flutter_js's promise poller stops
      // instead of spinning QuickJS forever. The .timeout() below stays as a
      // backstop for the rare case the JS timer never fires.
      final expr =
          '__callProviderT(${jsonEncode(sourceId)}, ${jsonEncode(method)}, ${jsonEncode(argsJson)}, ${timeout.inMilliseconds})';
      // The engine gets a little longer than we are willing to wait, so that
      // when a source really does hang it is THIS timeout the user sees rather
      // than a raw TimeoutException from the other side of the port. The inner
      // one still matters: it stops the engine pumping a call nobody wants.
      final resolved = await _engine
          .callAsync(expr, timeout + const Duration(seconds: 2))
          .timeout(
            timeout,
            onTimeout: () {
              throw JsRuntimeException(
                '$method timed out after ${timeout.inSeconds}s',
              );
            },
          );
      if (resolved.isError) {
        var msg = resolved.value;
        if (msg.startsWith('"') && msg.endsWith('"')) {
          try {
            final unq = jsonDecode(msg);
            if (unq is String) msg = unq;
          } catch (_) {}
        }
        throw JsRuntimeException(msg);
      }
      var s = resolved.value;
      if (s.isEmpty || s == 'null') {
        throw JsRuntimeException('$sourceId.$method returned null');
      }
      if (s.startsWith('"') && s.endsWith('"')) {
        try {
          final u = jsonDecode(s);
          if (u is String) s = u;
        } catch (_) {}
      }
      return s;
    } finally {
      _suppressCfSolve = wasSuppress;
    }
  }

  /// Physical tvOS cannot call Dart re-entrantly through JavaScriptCore's FFI
  /// sendMessage callback. JS queues native requests; Dart polls, services
  /// them, and injects their results back into the runtime.
  Future<String> _runAppleTvCall(
    String sourceId,
    String method,
    String argsJson,
    Duration timeout,
  ) async {
    final callId = 'p${++_providerCallSeq}';
    final expr =
        '''
(function() {
  __callProvider(
    ${jsonEncode(sourceId)},
    ${jsonEncode(method)},
    ${jsonEncode(argsJson)}
  ).then(
    function(value) {
      globalThis.__providerResults[${jsonEncode(callId)}] =
        { ok: true, value: value };
    },
    function(error) {
      globalThis.__providerResults[${jsonEncode(callId)}] =
        { ok: false, error: String(error) };
    }
  );
  return 'scheduled';
})()
''';
    final scheduled = await _engine.eval(expr);
    if (scheduled.isError || scheduled.value != 'scheduled') {
      throw JsRuntimeException(
        'Could not schedule $sourceId.$method: ${scheduled.value}',
      );
    }
    return _pumpAppleTvCall(callId, method, timeout);
  }

  Future<String> _pumpAppleTvCall(
    String callId,
    String method,
    Duration timeout,
  ) async {
    final deadline = DateTime.now().add(timeout);
    while (DateTime.now().isBefore(deadline)) {
      final requestsResult = await _engine.eval(
        'JSON.stringify(globalThis.__nativeRequests.splice(0))',
      );
      final decoded = jsonDecode(requestsResult.value);
      if (decoded is List) {
        for (final raw in decoded) {
          if (raw is! Map) continue;
          final request = Map<String, dynamic>.from(raw);
          final channel = request['channel'];
          final payload = request['payload'];
          if (channel == 'fetch') {
            await _onFetch(payload);
          } else if (channel == 'crypto') {
            _onCrypto(payload);
          } else if (channel == 'console') {
            _onConsole(payload);
          } else if (channel == 'timer') {
            _onTimer(payload);
          }
        }
      }

      final result = await _engine.eval('''
(function() {
  var value = globalThis.__providerResults[${jsonEncode(callId)}];
  if (!value) return '';
  delete globalThis.__providerResults[${jsonEncode(callId)}];
  return JSON.stringify(value);
})()
''');
      if (result.value.isNotEmpty) {
        final payload = jsonDecode(result.value) as Map<String, dynamic>;
        if (payload['ok'] == true) {
          return (payload['value'] ?? '').toString();
        }
        final error = (payload['error'] ?? 'unknown provider error').toString();
        throw JsRuntimeException(error);
      }
      await Future<void>.delayed(const Duration(milliseconds: 10));
    }
    throw JsRuntimeException('$method timed out after ${timeout.inSeconds}s');
  }

  Map<String, dynamic> _coerceMap(dynamic raw) {
    if (raw is String) return jsonDecode(raw) as Map<String, dynamic>;
    if (raw is Map) return Map<String, dynamic>.from(raw);
    throw FormatException(
      'Unexpected message payload type: ${raw.runtimeType}',
    );
  }

  Future<void> _onFetch(dynamic raw) async {
    String? id;
    try {
      final payload = _coerceMap(raw);
      id = payload['id'] as String;
      final url = payload['url'] as String;
      // The JS bootstrap tags every fetch with its caller's __src: a real
      // provider's sourceId, or 'ex:<extractorId>' for an extractor call —
      // the latter names no installed source, so it's not a useful key here.
      final src = (payload['__src'] as String?) ?? '';
      final srcId = (src.isEmpty || src.startsWith('ex:')) ? null : src;
      final method = (payload['method'] as String?) ?? 'GET';
      final headers =
          (payload['headers'] as Map?)?.cast<String, dynamic>() ?? {};
      final body = payload['body'];
      final tMs = (payload['timeoutMs'] as num?)?.toInt() ?? 0;
      final follow = payload['followRedirects'] != false;
      final wantCf = payload['browser'] == true || payload['cf'] == true;
      final host = Uri.parse(url).host;
      final hdr = headers.map((k, v) => MapEntry(k, v.toString()));
      // OWNER-DISABLED 2026-10-03: Zangetsu-provider Cloudflare handling is
      // off (owner request). The lines below used to attach a cached
      // clearance, retry protocol blocks over the native lane, and solve +
      // replay real challenges. With them off, a challenged host's raw
      // challenge page is handed to the provider as content. To re-enable,
      // uncomment the OWNER-DISABLED lines in this function.
      // _ensureCfRestored(); // reuse a clearance solved in a previous session
      // A cached clearance is attached; one is NOT solved for up front, even
      // when the provider asks via { browser: true }.
      //
      // That opt-in used to run the native solver BEFORE the first request to
      // a cold host, and the solver waits on a real WebView — up to
      // [solveTimeout]. JS providers run on the UI isolate, so that wait is an
      // app nobody can touch. AnimeKai set the flag, anikai.cc wasn't actually
      // challenging, and a tester's recording showed the UI unusable for the
      // whole stretch; on a device with the clearance already cached the same
      // build looked perfectly fine, which is what made it so easy to doubt.
      //
      // Nothing is given up. The challenge path below already solves and
      // replays when a response really is challenged — that is how every
      // provider WITHOUT the flag has always coped. The flag now only means
      // "this host may challenge", which the response answers better.
      //
      // [wantCf] is still read: it labels the request in the log, so a source
      // that expects Cloudflare is still identifiable when one misbehaves.
      // OWNER-DISABLED 2026-10-03 (see above): no clearance is attached.
      // _applyCf(host, hdr);
      // Did the original request carry a clearance? If so and it STILL gets
      // challenged below, that clearance is stale (e.g. a persisted cookie that
      // expired) and must be dropped rather than reused.
      // OWNER-DISABLED 2026-10-03 (see above): nothing is ever attached now.
      // final sentClearance = _cfCookie.containsKey(host);
      debugPrint('[fetch] $method $url${wantCf ? ' (cf)' : ''}');
      var resp = await _request(url, method, hdr, body, follow, tMs);
      // OWNER-DISABLED 2026-10-03 (see above): no blocked-lane retry, no
      // challenge solve + replay, no needs-solve recording. The raw response
      // goes straight to the provider.
      // if (Platform.isAndroid && follow && _looksLikeBlocked(resp)) {
      //   final viaNative = await _retryOverNative(url, method, hdr, body);
      //   if (viaNative != null && (viaNative.statusCode ?? 0) < 400) {
      //     debugPrint('[fetch] retried over native lane -> ${viaNative.statusCode}');
      //     resp = viaNative;
      //   }
      // }
      // if (_looksLikeCfChallenge(resp) && !_suppressCfSolve) {
      // OWNER-DISABLED 2026-10-03 (see above): whole challenge block off.
      //   A challenge despite a clearance WE sent means it's stale → forget it
      //   (memory + disk) so the solve re-runs. A cookie a concurrent fetch just
      //   solved (sentClearance == false) is fresh — keep it and just replay.
      // if (sentClearance && _cfCookie.containsKey(host)) {
      //   _cfCookie.remove(host);
      //   _cfStore.forget(host);
      // }
      // if (!_cfCookie.containsKey(host) && !_cfRecentlyFailed(host)) {
      //   await _solveCf(url, host);
      // }
      // if (_cfCookie.containsKey(host)) {
      //   _applyCf(host, hdr);
      //   resp = await _request(url, method, hdr, body, follow, tMs);
      // } else {
      //   // Challenged, and we finished without a clearance — the solve failed,
      //   // timed out, or is in its cool-off. Record it so the UI can offer a
      //   // manual solve; the automatic path used to fail silently, leaving the
      //   // source looking merely broken with nothing to press.
      //   CfSolveNeeded.needsSolve(host, url, sourceId: srcId);
      // }
      // } else if (_looksLikeCfChallenge(resp) && _suppressCfSolve) {
      //   // Same challenge, but this call is a `search` — the solve is
      //   // deliberately skipped (see [_suppressCfSolve]) rather than popping
      //   // the blocking WebView mid-sweep. Stash it so the UI can offer a
      //   // solve instead of the source just silently returning nothing.
      //   CfSolveNeeded.needsSolve(host, url, sourceId: srcId);
      // }
      debugPrint(
        '[fetch] <- ${resp.statusCode} ${(resp.data?.toString().length ?? 0)}B $url',
      );
      final responseHeaders = <String, String>{};
      resp.headers.forEach((k, v) => responseHeaders[k] = v.join(', '));
      final responseJson = jsonEncode({
        'status': resp.statusCode ?? 0,
        'statusText': resp.statusMessage ?? '',
        'headers': responseHeaders,
        'url': resp.realUri.toString(),
        'body': resp.data?.toString() ?? '',
      });
      _engine.post(
        '__resolveFetch(${jsonEncode(id)}, ${jsonEncode(responseJson)});',
      );
    } catch (e) {
      debugPrint('[fetch] FAILED $e');
      if (id != null) {
        _engine.post(
          '__rejectFetch(${jsonEncode(id)}, ${jsonEncode(e.toString())});',
        );
      }
    }
  }

  /// In-flight provider fetches, keyed by method + url + body. A second
  /// request for a URL already being fetched waits for that one instead of
  /// issuing a duplicate.
  ///
  /// Measured over one browsing session: 873 requests, 206 unique. The same
  /// domains.json 19 times, the same TMDB title search 16 times, individual
  /// hubcloud links 12 times each. Those duplicates saturate a phone's
  /// connection, so every real request queues behind copies of itself — which is
  /// what "stuck" looks like, and it was self-inflicted rather than slow
  /// sources.
  ///
  /// In-flight only, deliberately: this is not a cache. Sharing a future is
  /// free and obviously correct, whereas caching would change what a viewer
  /// sees when a source changes under a pinned link, and would need an
  /// invalidation story nobody asked for. The same pattern is already used for
  /// source sweeps in `SourceMatcher._inFlight`.
  final Map<String, Future<Response<dynamic>>> _inFlightFetches = {};

  Future<Response<dynamic>> _request(
    String url,
    String method,
    Map<String, String> headers,
    dynamic body,
    bool follow,
    int tMs,
  ) {
    final key = '$method\u0000$url\u0000${body ?? ''}';
    final running = _inFlightFetches[key];
    if (running != null) return running;
    final started = _requestUnshared(url, method, headers, body, follow, tMs);
    _inFlightFetches[key] = started;
    // Braces, NOT an arrow: Map.remove hands back the removed value, and
    // whenComplete awaits a returned Future — an arrow would await the very
    // future being completed and never finish.
    unawaited(
      started
          .whenComplete(() {
            _inFlightFetches.remove(key);
          })
          .then<void>((_) {}, onError: (Object _) {}),
    );
    return started;
  }

  Future<Response<dynamic>> _requestUnshared(
    String url,
    String method,
    Map<String, String> headers,
    dynamic body,
    bool follow,
    int tMs,
  ) {
    // `null` in Dio means "wait forever", which is what a provider fetch got
    // whenever the source didn't ask for a timeout — and WCCCNF shows the cost:
    // one title took 71.8s while every other request queued behind it. A
    // source's requested timeout is a FLOOR, not a ceiling: these sources ask
    // for 30s, and those 30s are spent inside one call that OWNS the shared JS
    // bridge, so a hostile host stalls every source in the app (5YD3QD:
    // `vegamovies.getDetail waited 20s in the queue`).
    //
    // 25s matches the hand-picked source's existing budget, so this changes
    // nothing about how long a source the viewer chose gets. It only stops
    // unbounded and 30s requests holding everyone else hostage. A request
    // asking for less still gets less.
    final ms = tMs > 0 && tMs < maxProviderFetchTimeoutMs
        ? tMs
        : maxProviderFetchTimeoutMs;
    return dio.requestUri<dynamic>(
      Uri.parse(url),
      data: body,
      // `null` here means "wait forever" in Dio, which is what a provider fetch
      // got whenever the source didn't ask for a timeout — and WCCCNF shows what
      // that costs: a title took 71.8s while every other request queued behind
      // it. A source's requested timeout is a FLOOR, not a ceiling: these
      // sources ask for 30s, and those 30s are spent inside one call that owns
      // the shared JS bridge, so a hostile host stalls every source in the app
      // (5YD3QD: `vegamovies.getDetail waited 20s in the queue`).
      //
      // 25s is the hand-picked source's existing budget, so this changes
      // nothing about how long a source the viewer chose gets; it only stops
      // unbounded and 30s requests from holding everyone else hostage. A
      // request asking for less still gets less.
      options: Options(
        method: method,
        headers: headers,
        responseType: ResponseType.plain,
        followRedirects: follow,
        maxRedirects: follow ? 5 : 0,
        validateStatus: (_) => true,
        receiveTimeout: Duration(milliseconds: ms),
        sendTimeout: Duration(milliseconds: ms),
      ),
    );
  }

  /// Solve Cloudflare for [host] via the native WebView solver and cache the
  /// clearance cookie + matching UA. Best-effort; silent on failure or on
  /// platforms without the native handler (the MethodChannel invoke throws).
  /// Solve CF for [host], deduping concurrent callers onto one in-flight solve.
  /// Ceiling for one native Cloudflare solve. The solver itself gives the
  /// challenge about 30s, so this only catches the case where it never comes
  /// back at all.
  static const Duration solveTimeout = Duration(seconds: 35);

  Future<void> _solveCf(String url, String host) {
    final existing = _cfInflight[host];
    if (existing != null) return existing; // a solve for this host is running
    final fut = _solveCfImpl(url, host).whenComplete(() {
      _cfInflight.remove(host);
    });
    _cfInflight[host] = fut;
    return fut;
  }

  /// UI-triggered solve for a host [CfSolveNeeded] flagged (the
  /// suppressed-during-search case) — reuses [_solveCf], so a manual solve
  /// gets the same in-flight de-dupe and cookie/UA storage an automatic one
  /// does. Returns true once a clearance is in hand.
  Future<bool> solveForUi(String host, String url) async {
    await _solveCf(url, host);
    return _cfCookie.containsKey(host);
  }

  Future<void> _solveCfImpl(String url, String host) async {
    try {
      // Bounded: the solver runs a real WebView against a real challenge, and
      // a challenge it cannot pass leaves this await hanging for good. Every
      // fetch waiting on it hangs with it, which is what turned one stubborn
      // host into a screen that span forever with nothing to act on.
      final res = await _cf
          .invokeMapMethod<String, dynamic>('solveCloudflare', {'url': url})
          .timeout(solveTimeout);
      final cookie = res?['cookie'] as String?;
      final ua = res?['userAgent'] as String?;
      if (cookie != null && cookie.isNotEmpty) {
        _cfCookie[host] = cookie;
        _cfFailedAt.remove(host); // solved → clear any negative-cache mark
        if (ua != null && ua.isNotEmpty) _cfUa[host] = ua;
        _cfStore.remember(host, cookie, ua); // reuse across restarts
        CfSolveNeeded.clear(host); // whatever needed the solve can retry now
        debugPrint('[cf] solved $host (ua=${(ua ?? '').split(')').first})');
      } else {
        // Solver returned no clearance (dead/parked host, or not a real CF
        // challenge) → mark failed so we don't re-run the 30s solve every call.
        _cfFailedAt[host] = DateTime.now().millisecondsSinceEpoch;
      }
    } catch (_) {
      // No native solver (iOS / not wired) or the invoke threw → also mark
      // failed; we fall back to a plain request.
      _cfFailedAt[host] = DateTime.now().millisecondsSinceEpoch;
    }
  }

  /// Hydrate the in-memory CF maps from the persistent store once, on first use.
  /// Restored clearances are optimistic: a stale one is dropped + re-solved by
  /// the fetch path, so this only saves a solve when a still-valid one exists.
  void _ensureCfRestored() {
    if (_cfRestored) return;
    _cfRestored = true;
    _cfStore.restore().forEach((host, e) {
      _cfCookie.putIfAbsent(host, () => e.cookie);
      final ua = e.ua;
      if (ua != null && ua.isNotEmpty) _cfUa.putIfAbsent(host, () => ua);
    });
  }

  /// True if a CF solve for [host] failed within the last [_cfFailTtlMs].
  bool _cfRecentlyFailed(String host) {
    final at = _cfFailedAt[host];
    if (at == null) return false;
    if (DateTime.now().millisecondsSinceEpoch - at < _cfFailTtlMs) return true;
    _cfFailedAt.remove(host); // TTL elapsed → allow a fresh attempt
    return false;
  }

  /// Merge the cached CF clearance into [hdr]. The cf_clearance cookie is bound
  /// to the EXACT User-Agent that solved it, so when we have one we must FORCE
  /// the solving UA — even over a UA the provider set — or Cloudflare 403s the
  /// mismatch. Without a CF cookie we leave the provider's UA untouched.
  void _applyCf(String host, Map<String, String> hdr) {
    final cookie = _cfCookie[host];
    final ua = _cfUa[host];
    if (cookie != null) {
      final existing = hdr['Cookie'] ?? hdr['cookie'];
      hdr['Cookie'] = (existing == null || existing.isEmpty)
          ? cookie
          : '$existing; $cookie';
      if (ua != null && ua.isNotEmpty) {
        // Force the solving UA: drop any provider-set variant, then set ours.
        hdr.remove('user-agent');
        hdr['User-Agent'] = ua;
      }
    } else if (ua != null &&
        hdr['User-Agent'] == null &&
        hdr['user-agent'] == null) {
      hdr['User-Agent'] = ua;
    }
  }

  /// True when a response is a Cloudflare interstitial rather than real content.
  bool _looksLikeBlocked(Response<dynamic> resp) => looksLikeCloudflareBlock(
    resp.statusCode ?? 0,
    resp.data?.toString() ?? '',
  );

  /// Repeat a blocked request on the native OkHttp lane, which speaks HTTP/2.
  ///
  /// Dio rides `dart:io HttpClient` (HTTP/1.1 only) and hosts like kwik.cx now
  /// refuse that protocol outright. The novel path already carries an OkHttp
  /// client for the same class of problem, so this borrows it rather than
  /// standing up a second stack. Android-only; null on any failure, and the
  /// caller then keeps the original response.
  Future<Response<dynamic>?> _retryOverNative(
    String url,
    String method,
    Map<String, String> headers,
    dynamic body,
  ) async {
    try {
      final res = await _novelHttp.invokeMapMethod<String, dynamic>('request', {
        'url': url,
        'method': method,
        'headers': headers,
        'body': body is String ? body : (body == null ? null : '$body'),
      });
      if (res == null) return null;
      final status = res['status'] as int? ?? 0;
      final rawHeaders = (res['headers'] as Map?) ?? const {};
      return Response<dynamic>(
        requestOptions: RequestOptions(path: url),
        statusCode: status,
        data: res['body'] as String? ?? '',
        headers: Headers.fromMap({
          for (final e in rawHeaders.entries) '${e.key}': ['${e.value}'],
        }),
      );
    } catch (_) {
      // No handler (iOS/desktop), or the lane failed. Keep what we had.
      return null;
    }
  }

  bool _looksLikeCfChallenge(Response<dynamic> resp) => looksLikeCfChallenge(
    status: resp.statusCode ?? 0,
    cfMitigated: resp.headers.value('cf-mitigated'),
    body: resp.data?.toString() ?? '',
  );

  void _onCrypto(dynamic raw) {
    String? id;
    try {
      final payload = _coerceMap(raw);
      id = payload['id'] as String;
      final op = payload['op'] as String;
      String result;
      if (op == 'sha256') {
        result = sha256Hex(payload['message'] as String);
      } else if (op == 'aesCtrDecrypt') {
        final data = base64Decode(payload['dataB64'] as String);
        result = aesCtrDecryptToString(
          keyHex: payload['keyHex'] as String,
          counterHex: payload['counterHex'] as String,
          data: Uint8List.fromList(data),
        );
      } else {
        throw FormatException('Unknown crypto op: $op');
      }
      _engine.post(
        '__resolveCrypto(${jsonEncode(id)}, ${jsonEncode(result)});',
      );
    } catch (e) {
      if (id != null) {
        _engine.post(
          '__rejectCrypto(${jsonEncode(id)}, ${jsonEncode(e.toString())});',
        );
      }
    }
  }

  void _onTimer(dynamic raw) {
    try {
      final payload = _coerceMap(raw);
      final id = payload['id'] as String;
      final ms = (payload['ms'] as num?)?.toInt() ?? 0;
      Future<void>.delayed(Duration(milliseconds: ms < 0 ? 0 : ms), () {
        _engine.post('__fireTimer(${jsonEncode(id)});');
      });
    } catch (_) {}
  }

  void _onConsole(dynamic raw) {
    try {
      final map = _coerceMap(raw);
      final src = (map['__src'] ?? '?').toString();
      final level = (map['level'] ?? 'log').toString();
      final message = (map['message'] ?? '').toString();
      debugPrint('[$src/js $level] $message');
    } catch (_) {}
  }

  void dispose() => _engine.dispose();
}

/// Thin per-source wrapper. Calls route through the shared _JsHost and
/// deserialize into the video models. Also implements [ReadingProvider]:
/// manga/novel JS sources export `getPages`/`getText` the same way video
/// sources export `getVideoSources` — there's no separate provider type.
class JsProvider implements BaseProvider, ReadingProvider {
  JsProvider._({
    required this.sourceId,
    required this.originRepoUrl,
    required this.displayName,
    required _JsHost host,
  }) : _host = host;

  @override
  final String sourceId;
  final String originRepoUrl;
  @override
  final String displayName;
  final _JsHost _host;

  ProviderHealthStatus get healthStatus => _host.healthFor(sourceId);
  String? get lastError => _host.lastErrorFor(sourceId);

  Future<String> _call(
    String method,
    List<Object?> args, {
    Duration timeout = const Duration(seconds: 15),
    bool Function()? abandoned,
  }) => _host.call(
    sourceId,
    method,
    args,
    timeout: timeout,
    abandoned: abandoned,
  );

  ProviderInfo? _infoCache;

  @override
  Future<ProviderInfo> getInfo() async {
    final cached = _infoCache;
    if (cached != null) return cached;
    final raw = await _call('getInfo', const []);
    final info = ProviderInfo.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    _infoCache = info;
    return info;
  }

  /// CloudStream-style home rows. Returns the provider's own named sections,
  /// or `null` when the JS file doesn't define `getHome` (the caller then
  /// synthesizes default rows from [popular]). Never returns partial garbage:
  /// items without the basics are dropped, empty/untitled sections are kept
  /// out. Given a generous timeout since it may fan out several listing calls.
  // Decode a provider's JSON off the UI thread when it's big — same trick the
  // CloudStream path uses. Small results decode inline (spinning up an isolate
  // isn't worth it); the big browse feeds are the ones that'd skip a frame
  // otherwise. Playback (getVideoSources) is small + timing-sensitive, so it
  // deliberately stays inline.
  static dynamic _decodeJson(String s) => jsonDecode(s);
  static Future<dynamic> _decodeBig(String s) async =>
      s.length > 20000 ? await compute(_decodeJson, s) : jsonDecode(s);

  @override
  Future<List<HomeSection>?> getHome({String category = 'sub'}) async {
    try {
      final raw = await _call('getHome', [
        {'category': category},
      ], timeout: const Duration(seconds: 30));
      final decoded = await _decodeBig(raw);
      if (decoded is! List) return null;
      return homeSectionsFromJson(decoded, sourceId);
    } catch (e) {
      final msg = e is JsRuntimeException ? e.message : e.toString();
      // The bootstrap signals an absent function with this exact phrase.
      if (msg.contains('missing method: getHome')) return null;
      rethrow;
    }
  }

  /// Pure parse of a JS `getHome()` payload. A row with an `id` opts into
  /// server-side paging via `getHomePage`; rows without one (every existing
  /// provider) get the client-side lazy fallback in See All.
  static List<HomeSection> homeSectionsFromJson(
    List<dynamic> decoded,
    String sourceId,
  ) {
    final out = <HomeSection>[];
    for (final s in decoded) {
      if (s is! Map) continue;
      final m = Map<String, dynamic>.from(s);
      final title = (m['title'] ?? '').toString().trim();
      if (title.isEmpty) continue;
      final rowId = (m['id'] ?? '').toString().trim();
      final rawItems = m['items'];
      final items = <MediaItem>[];
      if (rawItems is List) {
        for (final e in rawItems) {
          if (e is Map) {
            items.add(
              MediaItem.fromJson({
                ...Map<String, dynamic>.from(e),
                'sourceId': sourceId,
              }),
            );
          }
        }
      }
      out.add(
        HomeSection(
          title: title,
          items: items,
          lazyFallback: rowId.isEmpty,
          more: rowId.isEmpty
              ? null
              : BrowseMore(
                  sourceId: sourceId,
                  kind: 'js_home',
                  categoryId: rowId,
                ),
        ),
      );
    }
    return out;
  }

  Future<List<MediaItem>> getHomePage(
    String rowId,
    int page, {
    String category = 'sub',
  }) async {
    try {
      final raw = await _call('getHomePage', [
        rowId,
        page,
        {'category': category},
      ], timeout: const Duration(seconds: 20));
      final decoded = await _decodeBig(raw);
      final list = decoded is Map ? decoded['items'] : decoded;
      if (list is! List) return const [];
      final items = [
        for (final e in list)
          if (e is Map)
            MediaItem.fromJson({
              ...Map<String, dynamic>.from(e),
              'sourceId': sourceId,
            }),
      ];
      return items;
    } catch (_) {
      // Missing method, bad payload, provider error → no more items.
      return const [];
    }
  }

  @override
  Future<List<MediaItem>> popular({
    String category = 'sub',
    int dateRange = 7,
    int page = 1,
  }) async {
    final raw = await _call('popular', [
      {'category': category, 'dateRange': dateRange, 'page': page},
    ]);
    final list = (await _decodeBig(raw) as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
    return list
        .map((m) => MediaItem.fromJson({...m, 'sourceId': sourceId}))
        .toList();
  }

  @override
  Future<List<MediaItem>> search(
    String query,
    int page, {
    String category = '',
  }) async {
    final raw = await _call('search', [
      query,
      page,
      {'category': category},
    ]);
    final list = (await _decodeBig(raw) as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
    return list
        .map((m) => MediaItem.fromJson({...m, 'sourceId': sourceId}))
        .toList();
  }

  @override
  Future<MediaDetail> getDetail(
    String url, {
    String category = 'sub',
    // Adding an optional parameter is a valid override, so the interface and
    // every other provider stay exactly as they are.
    bool Function()? abandoned,
  }) async {
    // 30s: some providers enrich detail with extra metadata round-trips
    // (e.g. TMDB episode names/stills) on top of the page fetch.
    final raw = await _call(
      'getDetail',
      [
        url,
        {'category': category},
      ],
      timeout: const Duration(seconds: 30),
      abandoned: abandoned,
    );
    final map = jsonDecode(raw) as Map<String, dynamic>;
    // Sozo Read manga/novel detail payloads carry the chapter list under
    // `chapters`; Zangetsu's MediaDetail reads `episodes` (Task E4 compat
    // alias). Only fills in when `episodes` is absent, so a Zangetsu-shaped
    // payload's own `episodes` key always wins.
    if (!map.containsKey('episodes') && map.containsKey('chapters')) {
      map['episodes'] = map['chapters'];
    }
    return MediaDetail.fromJson({...map, 'sourceId': sourceId});
  }

  @override
  Future<List<Episode>> getEpisodes(
    String url, {
    String category = 'sub',
  }) async {
    final args = [
      url,
      {'category': category},
    ];
    String raw;
    try {
      raw = await _call('getEpisodes', args);
    } catch (e) {
      // Sozo Read manga/novel sources expose getChapters() instead of
      // getEpisodes() (Task E4 compat alias) — same chapter shape, different
      // name. Only fall back when the bootstrap reports the primary method
      // is absent; any other failure (network, parse, a real thrown Error
      // inside getEpisodes) must surface as-is, not get masked by a second
      // call. Promise rejections surface as a raw JsEvalResult rather than
      // JsRuntimeException — see `_JsHost._runCall` — so check both shapes,
      // same as the getHome/getSettings fallback checks above.
      final msg = e is JsRuntimeException ? e.message : e.toString();
      if (!msg.contains('missing method: getEpisodes')) rethrow;
      raw = await _call('getChapters', args);
    }
    final list = (await _decodeBig(raw) as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
    return list.map(Episode.fromJson).toList();
  }

  @override
  Future<List<VideoSource>> getVideoSources(
    String episodeUrl, {
    bool fast = false,
  }) async {
    // Video source resolution makes several network hops (decrypt + multiple
    // embed/clock resolves), so it needs a longer ceiling than the 15s default.
    // TorBox and similar debrid sources use [fast] to parallelize unlocks.
    final raw = await _call('getVideoSources', [
      episodeUrl,
      fast,
    ], timeout: const Duration(seconds: 60));
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    return list.map(VideoSource.fromJson).toList();
  }

  @override
  Future<List<PageImage>> getPages(String chapterUrl) async {
    final raw = await _call('getPages', [chapterUrl]);
    return PageImage.listFromJson(await _decodeBig(raw));
  }

  @override
  Future<ChapterText> getText(String chapterUrl) async {
    String raw;
    try {
      raw = await _call('getText', [chapterUrl]);
    } catch (e) {
      // Sozo Read novel sources expose getChapterContent() instead of
      // getText() (Task E4 compat alias) — same fallback rule as
      // getEpisodes() above: only on a genuine "method missing", never on a
      // real provider error.
      final msg = e is JsRuntimeException ? e.message : e.toString();
      if (!msg.contains('missing method: getText')) rethrow;
      raw = await _call('getChapterContent', [chapterUrl]);
    }
    // Chapter text/HTML can run long for novels, so route big payloads
    // through _decodeBig like the other listing calls rather than always
    // decoding inline on the UI thread.
    final decoded = await _decodeBig(raw);
    if (decoded is Map) return ChapterText.fromJson(decoded);
    return ChapterText(html: decoded?.toString() ?? '');
  }

  /// Returns the provider's raw settings schema (the JSON list returned
  /// by its `getSettings()`), or null if the JS file doesn't define
  /// `getSettings`. Never throws — the wrapped namespace sets the slot
  /// to `null` for providers without the function, which `__callProvider`
  /// reports as a "missing method" rejection; we treat that as "no
  /// schema". Parse the result with `ProviderSettingSchema.parseAll`.
  Future<List<dynamic>?> getSettingsSchema() async {
    try {
      final raw = await _call('getSettings', const []);
      final decoded = jsonDecode(raw);
      if (decoded is List) return decoded;
      return null;
    } catch (e) {
      final msg = e is JsRuntimeException ? e.message : e.toString();
      // The bootstrap signals an absent function with this exact prefix.
      if (msg.contains('missing method: getSettings')) return null;
      debugPrint('[settings] schema load failed for $sourceId: $msg');
      return null;
    }
  }
}

/// Minimal contract the [ProviderRegistry] needs from a runtime host.
/// Lets tests inject a no-op loader without spinning up native QuickJS.
abstract class ProviderRuntimeLoader {
  JsProvider? get(String id);

  /// Loads [jsSource] into the runtime under [sourceId]. Returns `Future<void>`
  /// here so test doubles needn't fabricate a [JsProvider]; the concrete
  /// [ProviderManager] still returns the loaded provider.
  ///
  /// Async because the runtime may be on another isolate — and because that
  /// finally makes [ProviderRegistry.loadAll]'s per-entry timeout real: a
  /// provider whose JS hangs used to block the boot regardless.
  Future<void> load({
    required String sourceId,
    required String jsSource,
    String originRepoUrl,
    String displayName,
  });

  /// Pushes per-source settings into the runtime as `__settings[sourceId]`.
  void setSettings(String sourceId, Map<String, dynamic> settings);

  void remove(String id);
}

/// Public manager. Owns the single shared QuickJS runtime + registered
/// providers and extractors.
class ProviderManager implements ProviderRuntimeLoader {
  /// Zone key marking a provider call as housekeeping nobody is waiting on.
  static final Object backgroundKey = Object();

  /// Runs [body] with every provider call it makes tagged background, so it
  /// queues behind the viewer's taps instead of competing with them.
  static Future<T> inBackground<T>(Future<T> Function() body) =>
      runZoned(body, zoneValues: {backgroundKey: true});

  ProviderManager({required Dio dio}) : _host = _JsHost(dio: dio);

  final _JsHost _host;

  /// Runs [body] with the blocking Cloudflare WebView solver disabled — see
  /// [_JsHost.asPassiveSweep].
  Future<T> asPassiveSweep<T>(Future<T> Function() body) =>
      _host.asPassiveSweep(body);

  Iterable<String> get installedIds => _host.providers.keys;
  List<JsProvider> get all => _host.providers.values.toList();
  @override
  JsProvider? get(String id) => _host.providers[id];

  /// Loads [jsSource] as a provider under [sourceId]. One provider per
  /// sourceId is live at a time; reloading replaces it.
  @override
  Future<JsProvider> load({
    required String sourceId,
    required String jsSource,
    String originRepoUrl = '',
    String displayName = '',
  }) async {
    await _host.loadProvider(sourceId, jsSource);
    final provider = JsProvider._(
      sourceId: sourceId,
      originRepoUrl: originRepoUrl,
      displayName: displayName,
      host: _host,
    );
    _host.providers[sourceId] = provider;
    return provider;
  }

  /// Loads [jsSource] as an extractor; it registers itself under each host
  /// in its getInfo().hosts list and is reachable via extractVideo().
  Future<void> loadExtractor({
    required String extractorId,
    required String jsSource,
  }) => _host.loadExtractor(extractorId, jsSource);

  /// Mirrors per-source settings into the JS runtime so subsequent
  /// provider calls can read them as `__settings[sourceId]`. Safe to
  /// call any time — the underlying eval is single-shot and best-effort.
  @override
  void setSettings(String sourceId, Map<String, dynamic> settings) =>
      _host.setSettings(sourceId, settings);

  @override
  void remove(String id) {
    _host.removeProvider(id);
    _host.providers.remove(id);
    _host.resetHealth(id);
  }

  /// Manually solve Cloudflare for [host] (opening [url] in the native
  /// solver) after the fetch path flagged it via `CfSolveNeeded` — the
  /// search-suppressed case. Distinct from [MihonExtensionService
  /// .solveCloudflare]: JS providers run on Dio, which has no jar reading
  /// Android's shared CookieManager, so the solved cookie has to land in
  /// THIS host's own cache, not just the system-wide one. Returns true once
  /// a clearance is obtained.
  Future<bool> solveCloudflareForHost(String host, String url) =>
      _host.solveForUi(host, url);

  void disposeAll() {
    _host.providers.clear();
    _host.dispose();
  }
}

// ── Aniyomi provider registry ────────────────────────────────────────────────

/// Holds all registered Aniyomi source providers — the counterpart to
/// [CloudStreamManager] for the native Aniyomi extension bridge.
///
/// Providers are added at install time via [registerAll] and reloaded on cold
/// start by the guarded boot step in [initDependencies]. All runtime state is
/// in-memory; the persistence record (pkg → apk path) lives in the
/// `'aniyomi_installed'` Hive box managed by [AniyomiExtensionService].
class AniyomiManager extends ChangeNotifier {
  final Map<String, BaseProvider> _providers = {};

  /// Available updates keyed by repo base URL. Mirrors CloudStreamManager._updates.
  final Map<String, List<AniyomiUpdate>> _updates = {};

  /// Overridable checker (test seam). Defaults to the real service fetch.
  Future<List<AniyomiUpdate>> Function(String url, Map<String, int> codes)?
  checkerOverride;

  DateTime? _lastUpdateCheck;
  static const Duration _updatesTtl = Duration(minutes: 30);

  /// Installed extension packages → versionCode, derived from registered
  /// Aniyomi providers (first source per pkg wins; all sources share a code).
  Map<String, int> get installedCodes {
    final m = <String, int>{};
    for (final p in _providers.values) {
      if (p is AniyomiProvider) {
        m.putIfAbsent(p.info.pkg, () => p.info.versionCode);
      }
    }
    return m;
  }

  /// Read-only update check for a single repo; stores + notifies. Never throws.
  Future<List<AniyomiUpdate>> checkRepoUpdates(String url) async {
    final checker =
        checkerOverride ??
        (u, codes) => AniyomiExtensionService().checkRepoForUpdates(u, codes);
    try {
      final list = await checker(url, installedCodes);
      if (list.isEmpty) {
        _updates.remove(url);
      } else {
        _updates[url] = list;
      }
      notifyListeners();
      return list;
    } catch (_) {
      return const [];
    }
  }

  List<AniyomiUpdate> updatesFor(String url) => _updates[url] ?? const [];

  /// The update for [pkg] across all repos, or null.
  AniyomiUpdate? updateFor(String pkg) {
    for (final list in _updates.values) {
      for (final u in list) {
        if (u.pkg == pkg) return u;
      }
    }
    return null;
  }

  int get updateCount => _updates.values.fold(0, (a, l) => a + l.length);

  /// Checks every repo URL. TTL-debounced (30 min) unless [force]. Returns the
  /// total update count. Never throws.
  Future<int> checkAllUpdates(
    List<String> repoUrls, {
    bool force = false,
  }) async {
    final last = _lastUpdateCheck;
    if (!force &&
        last != null &&
        DateTime.now().difference(last) < _updatesTtl) {
      return updateCount;
    }
    _lastUpdateCheck = DateTime.now();
    for (final url in repoUrls) {
      if (url.isNotEmpty) await checkRepoUpdates(url);
    }
    return updateCount;
  }

  /// Drops [pkg] from all repos' update lists (after a successful update).
  void clearUpdatesForPkg(String pkg) {
    var changed = false;
    for (final url in _updates.keys.toList()) {
      final filtered = _updates[url]!.where((u) => u.pkg != pkg).toList();
      if (filtered.length != _updates[url]!.length) changed = true;
      if (filtered.isEmpty) {
        _updates.remove(url);
      } else {
        _updates[url] = filtered;
      }
    }
    if (changed) notifyListeners();
  }

  /// All registered Aniyomi providers (`ani:*` source ids).
  List<BaseProvider> get all => _providers.values.toList();

  /// Resolves a provider by its `ani:<sourceId>` identifier, or null when not
  /// installed.
  BaseProvider? get(String sourceId) => _providers[sourceId];

  /// Register [provider] under its [BaseProvider.sourceId]. Replaces any
  /// existing entry with the same id.
  void register(BaseProvider provider) {
    _providers[provider.sourceId] = provider;
    notifyListeners();
  }

  /// Batch-register [providers]; notifies listeners once when non-empty.
  void registerAll(List<BaseProvider> providers) {
    for (final p in providers) {
      _providers[p.sourceId] = p;
    }
    if (providers.isNotEmpty) notifyListeners();
  }

  /// Removes all providers that match [predicate] and notifies listeners when
  /// at least one was removed.  Used by the uninstall flow to remove all
  /// sources that belong to a given extension package.
  void removeWhere(bool Function(BaseProvider provider) predicate) {
    final toRemove = _providers.entries
        .where((e) => predicate(e.value))
        .map((e) => e.key)
        .toList();
    for (final k in toRemove) {
      _providers.remove(k);
    }
    if (toRemove.isNotEmpty) notifyListeners();
  }
}
