import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:watch_app/features/player/player_tv_controls.dart';

// ── Minimal stub ──────────────────────────────────────────────────────────────

/// Minimal stub that records calls to [togglePlay] and [seekBy] without
/// bringing in any media_kit / DI infrastructure.
class _FakeController {
  int togglePlayCalls = 0;
  final List<Duration> seekByCalls = [];

  void togglePlay() => togglePlayCalls++;
  void seekBy(Duration d) => seekByCalls.add(d);
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/// Pump [PlayerTvControls] with [barVisible] forwarded to [onBarChange],
/// wired to the given [controller].  [onBack] records whether it was called.
Future<void> _pumpControls(
  WidgetTester tester, {
  required _FakeController controller,
  bool barVisible = false,
  required ValueNotifier<bool> barNotifier,
  required ValueNotifier<bool> backNotifier,
  Duration initialPosition = Duration.zero,
  Duration initialDuration = Duration.zero,
  // Null = don't override (matches the test host's default, which is
  // already `false`). Pass explicitly to prove the TalkBack gate's two
  // paths, mirroring how the other Layer-2 gate tests wrap their subject.
  bool? accessibleNavigation,
  VoidCallback? onInfo,
  bool showInfo = false,
}) async {
  // Player controls always render on a wide TV screen — size the test surface
  // accordingly so the bottom control row isn't cramped into an overflow.
  tester.view.physicalSize = const Size(1280, 720);
  tester.view.devicePixelRatio = 1.0;
  addTearDown(tester.view.reset);
  Widget body = ValueListenableBuilder<bool>(
    valueListenable: barNotifier,
    builder: (_, visible, _) => PlayerTvControls(
      onTogglePlay: controller.togglePlay,
      onSeekBy: controller.seekBy,
      onSpeed: () {},
      onAudioSubs: () {},
      onQuality: () {},
      onSources: () {},
      onFit: () {},
      onBack: () => backNotifier.value = true,
      onNext: null,
      onInfo: onInfo,
      showInfo: showInfo,
      playingStream: const Stream<bool>.empty(),
      initialPlaying: false,
      barVisible: visible,
      onBarChange: (v) => barNotifier.value = v,
      positionStream: const Stream<Duration>.empty(),
      durationStream: const Stream<Duration>.empty(),
      initialPosition: initialPosition,
      initialDuration: initialDuration,
      skipInfoFor: (_) => null,
    ),
  );
  if (accessibleNavigation != null) {
    body = MediaQuery(
      data: MediaQueryData(accessibleNavigation: accessibleNavigation),
      child: body,
    );
  }
  await tester.pumpWidget(
    MaterialApp(
      home: Scaffold(backgroundColor: Colors.black, body: body),
    ),
  );
  await tester.pumpAndSettle();
}

// ── Tests ─────────────────────────────────────────────────────────────────────

void main() {
  group('PlayerTvControls', () {
    late _FakeController controller;
    late ValueNotifier<bool> barNotifier;
    late ValueNotifier<bool> backNotifier;

    setUp(() {
      controller = _FakeController();
      barNotifier = ValueNotifier(false); // bar hidden by default
      backNotifier = ValueNotifier(false);
    });

    tearDown(() {
      barNotifier.dispose();
      backNotifier.dispose();
    });

    testWidgets('arrowRight calls seekBy(+10 s)', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
      await tester.pumpAndSettle();

      expect(controller.seekByCalls, contains(const Duration(seconds: 10)));
    });

    testWidgets('arrowLeft calls seekBy(-10 s)', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      await tester.sendKeyEvent(LogicalKeyboardKey.arrowLeft);
      await tester.pumpAndSettle();

      expect(controller.seekByCalls, contains(const Duration(seconds: -10)));
    });

    testWidgets('select calls togglePlay', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      await tester.sendKeyEvent(LogicalKeyboardKey.select);
      await tester.pumpAndSettle();

      expect(controller.togglePlayCalls, 1);
    });

    testWidgets('enter calls togglePlay', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      await tester.sendKeyEvent(LogicalKeyboardKey.enter);
      await tester.pumpAndSettle();

      expect(controller.togglePlayCalls, 1);
    });

    testWidgets('arrowRight also shows bar via onBarChange', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      expect(barNotifier.value, isFalse);
      await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
      await tester.pump(); // let the immediate callback fire
      expect(barNotifier.value, isTrue);
    });

    testWidgets('select shows bar via onBarChange', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      await tester.sendKeyEvent(LogicalKeyboardKey.select);
      await tester.pump();
      expect(barNotifier.value, isTrue);
    });

    testWidgets('arrowDown shows bar', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      await tester.sendKeyEvent(LogicalKeyboardKey.arrowDown);
      await tester.pump();
      expect(barNotifier.value, isTrue);
    });

    testWidgets('Escape hides bar when bar is visible', (tester) async {
      barNotifier.value = true;
      await _pumpControls(
        tester,
        controller: controller,
        barVisible: true,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      // LogicalKeyboardKey.goBack has no physical-key mapping in the test host
      // (desktop), so we use Escape which is also handled as "back".
      await tester.sendKeyEvent(LogicalKeyboardKey.escape);
      await tester.pump();
      expect(barNotifier.value, isFalse);
      expect(backNotifier.value, isFalse); // onBack NOT called
    });

    testWidgets('Escape calls onBack when bar is hidden', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barVisible: false,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      await tester.sendKeyEvent(LogicalKeyboardKey.escape);
      await tester.pump();
      expect(backNotifier.value, isTrue);
    });

    testWidgets('bar buttons are shown when barVisible is true', (
      tester,
    ) async {
      barNotifier.value = true;
      await _pumpControls(
        tester,
        controller: controller,
        barVisible: true,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      // Play/pause button (the primary control) — shows 'Play' when paused.
      expect(find.text('Play'), findsOneWidget);
      expect(find.text('Speed'), findsOneWidget);
      expect(find.text('Audio & subs'), findsOneWidget);
      expect(find.text('Quality'), findsOneWidget);
      expect(find.text('Sources'), findsOneWidget);
      expect(find.text('Fit'), findsOneWidget);
    });

    testWidgets('onNext button is absent when onNext is null', (tester) async {
      barNotifier.value = true;
      await _pumpControls(
        tester,
        controller: controller,
        barVisible: true,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
      );

      expect(find.text('Next'), findsNothing);
    });

    testWidgets('onNext button appears when onNext is provided', (
      tester,
    ) async {
      barNotifier.value = true;
      tester.view.physicalSize = const Size(1280, 720);
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.reset);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            backgroundColor: Colors.black,
            body: ValueListenableBuilder<bool>(
              valueListenable: barNotifier,
              builder: (_, visible, _) => PlayerTvControls(
                onTogglePlay: controller.togglePlay,
                onSeekBy: controller.seekBy,
                onSpeed: () {},
                onAudioSubs: () {},
                onQuality: () {},
                onSources: () {},
                onFit: () {},
                onBack: () {},
                onNext: () {}, // provided
                playingStream: const Stream<bool>.empty(),
                initialPlaying: false,
                barVisible: visible,
                onBarChange: (v) => barNotifier.value = v,
                positionStream: const Stream<Duration>.empty(),
                durationStream: const Stream<Duration>.empty(),
                initialPosition: Duration.zero,
                initialDuration: Duration.zero,
                skipInfoFor: (_) => null,
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      expect(find.text('Next'), findsOneWidget);
    });

    testWidgets(
      'seek bar shows formatted position and duration when bar is visible',
      (tester) async {
        const testPosition = Duration(minutes: 5, seconds: 30);
        const testDuration = Duration(minutes: 45);

        barNotifier.value = true;
        await _pumpControls(
          tester,
          controller: controller,
          barVisible: true,
          barNotifier: barNotifier,
          backNotifier: backNotifier,
          initialPosition: testPosition,
          initialDuration: testDuration,
        );

        // Position 5 m 30 s → '05:30', duration 45 m → '45:00'
        expect(find.text('05:30'), findsOneWidget);
        expect(find.text('45:00'), findsOneWidget);
      },
    );

    testWidgets(
      'seek bar announces a read-only label + value (not a focusable slider)',
      (tester) async {
        final handle = tester.ensureSemantics();
        const testPosition = Duration(minutes: 5, seconds: 30);
        const testDuration = Duration(minutes: 45);

        barNotifier.value = true;
        await _pumpControls(
          tester,
          controller: controller,
          barVisible: true,
          barNotifier: barNotifier,
          backNotifier: backNotifier,
          initialPosition: testPosition,
          initialDuration: testDuration,
        );

        final node = tester.getSemantics(find.bySemanticsLabel('Seek bar'));
        // All flag/action params default to false — this also proves the
        // node ISN'T a slider and ISN'T focusable (seeking stays the root
        // arrow handler's job, not TalkBack's).
        expect(
          node,
          matchesSemantics(label: 'Seek bar', value: '05:30 of 45:00'),
        );

        handle.dispose();
      },
    );

    testWidgets(
      'bar button caption is exposed once via semantics (no double-announce)',
      (tester) async {
        final handle = tester.ensureSemantics();
        barNotifier.value = true;
        await _pumpControls(
          tester,
          controller: controller,
          barVisible: true,
          barNotifier: barNotifier,
          backNotifier: backNotifier,
        );

        // The caption Text is still visible for sighted users...
        expect(find.text('Speed'), findsOneWidget);
        // ...but only the TvFocusable's semantics node carries the label —
        // the inner caption Text is ExcludeSemantics'd.
        expect(find.bySemanticsLabel('Speed'), findsOneWidget);

        handle.dispose();
      },
    );

    // ── D-pad stays live regardless of accessibleNavigation ────────────────
    //
    // Fire TV / onn falsely report accessibleNavigation=true after the native
    // player with no screen reader running, which used to dead-key the D-pad.
    // So _handleKey now processes OK/seek/arrows the same whether the flag is
    // on or off — the screen-reader-ON case mirrors the OFF case exactly.

    testWidgets(
      'accessibleNavigation OFF: select still calls togglePlay (sighted '
      'user, original behaviour)',
      (tester) async {
        await _pumpControls(
          tester,
          controller: controller,
          barNotifier: barNotifier,
          backNotifier: backNotifier,
          accessibleNavigation: false,
        );

        await tester.sendKeyEvent(LogicalKeyboardKey.select);
        await tester.pumpAndSettle();
        expect(controller.togglePlayCalls, 1);
      },
    );

    testWidgets(
      'accessibleNavigation OFF: arrowRight still seeks (sighted user, '
      'original behaviour)',
      (tester) async {
        await _pumpControls(
          tester,
          controller: controller,
          barNotifier: barNotifier,
          backNotifier: backNotifier,
          accessibleNavigation: false,
        );

        await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
        await tester.pumpAndSettle();
        expect(
          controller.seekByCalls,
          contains(const Duration(seconds: 10)),
        );
      },
    );

    testWidgets(
      'accessibleNavigation ON: select still calls togglePlay (D-pad stays '
      'live even when the TV falsely reports a screen reader)',
      (tester) async {
        await _pumpControls(
          tester,
          controller: controller,
          barNotifier: barNotifier,
          backNotifier: backNotifier,
          accessibleNavigation: true,
        );

        await tester.sendKeyEvent(LogicalKeyboardKey.select);
        await tester.pumpAndSettle();
        expect(controller.togglePlayCalls, 1);
        // _showBar() runs too — same path as the screen-reader-OFF case.
        expect(barNotifier.value, isTrue);
      },
    );

    testWidgets(
      'accessibleNavigation ON: arrowRight still seeks (D-pad stays live even '
      'when the TV falsely reports a screen reader)',
      (tester) async {
        await _pumpControls(
          tester,
          controller: controller,
          barNotifier: barNotifier,
          backNotifier: backNotifier,
          accessibleNavigation: true,
        );

        await tester.sendKeyEvent(LogicalKeyboardKey.arrowRight);
        await tester.pumpAndSettle();
        expect(
          controller.seekByCalls,
          contains(const Duration(seconds: 10)),
        );
        expect(barNotifier.value, isTrue);
      },
    );
    testWidgets('Info button hidden when no fields picked', (tester) async {
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
        barVisible: true,
      );
      barNotifier.value = true;
      await tester.pumpAndSettle();
      expect(find.text('Info'), findsNothing);
    });

    testWidgets('Info button toggles via onInfo when fields picked', (
      tester,
    ) async {
      var infoTaps = 0;
      await _pumpControls(
        tester,
        controller: controller,
        barNotifier: barNotifier,
        backNotifier: backNotifier,
        barVisible: true,
        onInfo: () => infoTaps++,
        showInfo: true,
      );
      barNotifier.value = true;
      await tester.pumpAndSettle();
      await tester.tap(find.text('Info'));
      expect(infoTaps, 1);
    });
  });
}
