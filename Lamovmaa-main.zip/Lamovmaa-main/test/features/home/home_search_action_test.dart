import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:watch_app/core/di/injector.dart';
import 'package:watch_app/core/ui/nav_prefs.dart';
import 'package:watch_app/core/zmode/zmode_prefs.dart';
import 'package:watch_app/features/home/home_screen.dart';
import 'package:watch_app/features/home/search_screen.dart';
import 'package:watch_app/features/shell/dock_icons.dart';

/// Search left the dock (task 17) — this header icon, beside
/// [HomeBrowseSourcesAction], is the primary way in now. Unlike the sources
/// icon it isn't gated on Z Mode: it must show either way, since Search
/// itself already switches between the metadata catalogue and the active
/// source depending on the toggle.
///
/// Records the push instead of letting it build — see
/// reading_detail_routing_test.dart's `_RecordingNavigatorObserver` doc:
/// `didPush` fires synchronously inside `Navigator.push`, before any
/// rebuild, so checking it right after `tester.tap()` (no follow-up
/// `pump()`) never actually mounts `SearchScreen`'s State, which needs a
/// dozen registered singletons that are beside the point here.
class _RecordingNavigatorObserver extends NavigatorObserver {
  final List<Route<dynamic>> pushed = [];

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    pushed.add(route);
  }
}

void main() {
  late Directory tempDir;

  setUp(() async {
    tempDir = await Directory.systemTemp.createTemp('home_search_action');
    Hive.init(tempDir.path);
    await ZModePrefs.init();
    // On by default since the Settings toggle was removed; these tests cover
    // both paths, so start from off and let each one opt in.
    await ZModePrefs.setEnabled(false);
  });

  tearDown(() async {
    await Hive.close();
    try {
      await tempDir.delete(recursive: true);
    } catch (_) {}
  });

  Future<_RecordingNavigatorObserver> pumpAction(
    WidgetTester tester, {
    String? fixedSourceId,
  }) async {
    final observer = _RecordingNavigatorObserver();
    await tester.pumpWidget(
      MaterialApp(
        navigatorObservers: [observer],
        home: Scaffold(body: HomeSearchAction(fixedSourceId: fixedSourceId)),
      ),
    );
    return observer;
  }

  testWidgets('Z Mode off: the search icon shows', (tester) async {
    expect(ZModePrefs.enabled, isFalse);
    await pumpAction(tester);
    expect(
      find.byWidgetPredicate(
        (w) => w is DockIcon && w.glyph == DockGlyph.search,
      ),
      findsOneWidget,
    );
  });

  testWidgets('Z Mode on: the search icon still shows', (tester) async {
    // A real Hive write never drains under the pump-driven testWidgets
    // binding without runAsync — same gotcha as home_browse_sources_action's.
    await tester.runAsync(() => ZModePrefs.setEnabled(true));
    await pumpAction(tester);
    expect(
      find.byWidgetPredicate(
        (w) => w is DockIcon && w.glyph == DockGlyph.search,
      ),
      findsOneWidget,
    );
  });

  testWidgets('tapping it pushes SearchScreen', (tester) async {
    final observer = await pumpAction(tester);
    // MaterialApp's own initial route already counts as one push.
    final before = observer.pushed.length;

    // No pump() after this tap on purpose — see _RecordingNavigatorObserver.
    await tester.tap(
      find.byWidgetPredicate(
        (w) => w is DockIcon && w.glyph == DockGlyph.search,
      ),
    );
    expect(observer.pushed.length, before + 1);

    final pushedRoute = observer.pushed.last as MaterialPageRoute;
    final pushedWidget = pushedRoute.builder(
      tester.element(find.byType(HomeSearchAction)),
    );
    expect(pushedWidget, isA<SearchScreen>());
  });

  testWidgets('passes the selected Home source to SearchScreen', (
    tester,
  ) async {
    final observer = await pumpAction(tester, fixedSourceId: 'cs:selected');
    final before = observer.pushed.length;

    await tester.tap(
      find.byWidgetPredicate(
        (w) => w is DockIcon && w.glyph == DockGlyph.search,
      ),
    );

    final pushedRoute = observer.pushed[before] as MaterialPageRoute;
    final pushedWidget =
        pushedRoute.builder(tester.element(find.byType(HomeSearchAction)))
            as SearchScreen;
    expect(pushedWidget.fixedSourceId, 'cs:selected');
  });

  testWidgets('hidden when Search is already a dock tab', (tester) async {
    final prefs = _SearchOnDockNavPrefs();
    await sl.reset();
    sl.registerSingleton<NavPrefs>(prefs);
    addTearDown(() async {
      await sl.reset();
    });

    await pumpAction(tester);
    expect(
      find.byWidgetPredicate(
        (w) => w is DockIcon && w.glyph == DockGlyph.search,
      ),
      findsNothing,
    );
  });
}

/// No Hive writes: the box-backed getter is bypassed so the test proves the
/// header reacts to the tab list, not the storage layer.
class _SearchOnDockNavPrefs extends NavPrefs {
  @override
  List<DockTab> get tabs => [DockTab.home, DockTab.search, DockTab.profile];
}
