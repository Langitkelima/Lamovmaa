import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:watch_app/core/download/download_manager.dart';
import 'package:watch_app/core/download/download_record.dart';
import 'package:watch_app/core/models/episode.dart';
import 'package:watch_app/core/models/video_source.dart';
import 'package:watch_app/core/tv/tv_focusable.dart';
import 'package:watch_app/features/downloads/downloads_screen.dart' show DownloadTile;
import 'package:watch_app/features/downloads/downloads_screen_tv.dart';

// ── Minimal fakes ─────────────────────────────────────────────────────────────

/// Stub [DownloadManager]: provides a fixed [byShow] map without requiring
/// Hive, background_downloader, or GetIt setup. Extends [ChangeNotifier] so
/// [ListenableBuilder] can register its listener; [implements DownloadManager]
/// so the concrete type is satisfied by [DownloadTile] and [_TileMenu].
/// [noSuchMethod] silences any unimplemented member calls at the type-system
/// level; none are invoked during widget rendering.
class _FakeDownloadManager extends ChangeNotifier implements DownloadManager {
  _FakeDownloadManager(this._byShow);

  final Map<String, List<DownloadRecord>> _byShow;

  @override
  Map<String, List<DownloadRecord>> get byShow => _byShow;

  @override
  List<DownloadRecord> get all =>
      _byShow.values.expand((l) => l).toList();

  @override
  DownloadRecord? recordFor(String sourceId, String showId, String episodeId) =>
      null;

  @override
  Future<DownloadRecord?> finishedForEpisode({
    required String sourceId,
    required String showId,
    required String episodeId,
    String? episodeUrl,
    int? malId,
    double? episodeNumber,
  }) async =>
      null;

  @override
  void setup() {}

  @override
  Future<void> enqueueEpisodes({
    required String sourceId,
    required String showId,
    required String showTitle,
    String? cover,
    Map<String, String>? coverHeaders,
    required String showUrl,
    required String category,
    required String quality,
    required List<Episode> episodes,
    required int nowMs,
    int? malId,
  }) async {}

  @override
  Future<void> enqueueSource({
    required String sourceId,
    required String showId,
    required String showTitle,
    String? cover,
    Map<String, String>? coverHeaders,
    required String showUrl,
    required String category,
    required Episode episode,
    required VideoSource source,
    required String qualityLabel,
    required int nowMs,
    int? malId,
    List<VideoSource> fallbacks = const [],
  }) async {}

  @override
  Future<void> pause(DownloadRecord r) async {}

  @override
  Future<void> resume(DownloadRecord r) async {}

  @override
  Future<void> cancel(DownloadRecord r) async {}

  @override
  Future<void> delete(DownloadRecord r) async {}

  // Any other DownloadManager member not called during widget rendering is
  // handled here without throwing so rendering remains side-effect-free.
  @override
  dynamic noSuchMethod(Invocation invocation) => null;
}

// ── Recording manager for action-dialog tests ──────────────────────────────
class _RecordingManager extends ChangeNotifier implements DownloadManager {
  DownloadRecord? paused, resumed, deleted;
  @override
  Future<void> pause(DownloadRecord r) async => paused = r;
  @override
  Future<void> resume(DownloadRecord r) async => resumed = r;
  @override
  Future<void> delete(DownloadRecord r) async => deleted = r;
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

DownloadRecord _rec(DownloadStatus status) => DownloadRecord(
      id: 'id1',
      sourceId: 'src',
      showId: 'aot',
      showTitle: 'Attack on Titan',
      showUrl: 'u',
      episodeId: 'ep1',
      episodeUrl: 'eu',
      episodeTitle: 'Ep 1',
      category: 'sub',
      quality: '1080p',
      status: status,
      createdAt: DateTime(2026, 1, 1).millisecondsSinceEpoch,
    );

// ── Helpers ───────────────────────────────────────────────────────────────────

DownloadRecord _doneRecord({
  required String showId,
  required String showTitle,
  required String episodeId,
  double? episodeNumber,
  String episodeTitle = '',
}) => DownloadRecord(
  id: '${showId}_$episodeId',
  sourceId: 'test',
  showId: showId,
  showTitle: showTitle,
  showUrl: '/show/$showId',
  episodeId: episodeId,
  episodeUrl: '/ep/$episodeId',
  episodeNumber: episodeNumber,
  episodeTitle: episodeTitle,
  category: 'sub',
  quality: 'best',
  status: DownloadStatus.done,
  filePath: '/fake/path.mp4',
  createdAt: 0,
);

DownloadRecord _downloadingRecord({
  required String showId,
  required String showTitle,
  required String episodeId,
}) => DownloadRecord(
  id: '${showId}_$episodeId',
  sourceId: 'test',
  showId: showId,
  showTitle: showTitle,
  showUrl: '/show/$showId',
  episodeId: episodeId,
  episodeUrl: '/ep/$episodeId',
  episodeNumber: 1,
  episodeTitle: '',
  category: 'sub',
  quality: 'best',
  status: DownloadStatus.downloading,
  progress: 0.5,
  createdAt: 0,
);

// ── Tests ─────────────────────────────────────────────────────────────────────

void main() {
  testWidgets(
    'DownloadsScreenTv renders episode tiles and first tile has autofocus',
    (tester) async {
      final rec1 = _doneRecord(
        showId: 'aot',
        showTitle: 'Attack on Titan',
        episodeId: 'ep1',
        episodeNumber: 1,
        episodeTitle: 'To You, 2000 Years Later',
      );
      final rec2 = _doneRecord(
        showId: 'aot',
        showTitle: 'Attack on Titan',
        episodeId: 'ep2',
        episodeNumber: 2,
        episodeTitle: 'That Day',
      );
      final manager = _FakeDownloadManager({
        'aot': [rec1, rec2],
      });
      addTearDown(manager.dispose);

      await tester.pumpWidget(
        MaterialApp(home: DownloadsScreenTv(manager: manager)),
      );
      await tester.pumpAndSettle();

      // Both episode labels are rendered.
      expect(find.text('E1 · To You, 2000 Years Later'), findsOneWidget);
      expect(find.text('E2 · That Day'), findsOneWidget);

      // Show title rendered in the group header.
      expect(find.text('Attack on Titan'), findsOneWidget);

      // Each show group renders a "Delete all episodes" header button plus one
      // focusable per episode tile.
      final focusables =
          tester.widgetList<TvFocusable>(find.byType(TvFocusable)).toList();
      expect(focusables.length, greaterThanOrEqualTo(2));

      // Episode tiles are the focusables wrapping a DownloadTile (the header
      // delete-all button wraps a plain Icon and is not one).
      final tiles = focusables.where((f) => f.child is DownloadTile).toList();
      expect(tiles, hasLength(2));

      // Exactly one focusable across the whole screen lands the D-pad, and it
      // is the first episode tile — not the header delete-all button.
      expect(focusables.where((f) => f.autofocus), hasLength(1));
      expect(tiles.first.autofocus, isTrue);
      expect(tiles.skip(1).any((f) => f.autofocus), isFalse);
    },
  );

  testWidgets(
    'DownloadsScreenTv shows empty state when manager has no downloads',
    (tester) async {
      final manager = _FakeDownloadManager({});
      addTearDown(manager.dispose);

      await tester.pumpWidget(
        MaterialApp(home: DownloadsScreenTv(manager: manager)),
      );
      await tester.pumpAndSettle();

      expect(
        find.text('Episodes you download appear here'),
        findsOneWidget,
      );
      // The download-location header ("Saving to … · Change") is always present
      // and focusable so it stays D-pad reachable even with no downloads — it's
      // the only focusable on an empty screen.
      expect(find.text('Saving to'), findsOneWidget);
      expect(find.byType(TvFocusable), findsOneWidget);
    },
  );

  testWidgets(
    'DownloadsScreenTv in-progress tile has onTap no-op (not autofocus beyond first)',
    (tester) async {
      final done = _doneRecord(
        showId: 'ds',
        showTitle: 'Demon Slayer',
        episodeId: 'ep1',
        episodeNumber: 1,
      );
      final inProgress = _downloadingRecord(
        showId: 'ds',
        showTitle: 'Demon Slayer',
        episodeId: 'ep2',
      );
      final manager = _FakeDownloadManager({
        'ds': [done, inProgress],
      });
      addTearDown(manager.dispose);

      await tester.pumpWidget(
        MaterialApp(home: DownloadsScreenTv(manager: manager)),
      );
      await tester.pumpAndSettle();

      // Episode tiles wrap a DownloadTile; the group's "Delete all" header
      // button is a separate focusable and is excluded here.
      final tiles = tester
          .widgetList<TvFocusable>(find.byType(TvFocusable))
          .where((f) => f.child is DownloadTile)
          .toList();

      // Two tiles: first (done) gets autofocus, second (in-progress) does not.
      expect(tiles.length, 2);
      expect(tiles[0].autofocus, isTrue);
      expect(tiles[1].autofocus, isFalse);
    },
  );

  // ── _TvDownloadActions ───────────────────────────────────────────────────
  group('_TvDownloadActions', () {
    testWidgets('downloading record shows Pause + Cancel + Delete (no Play/Resume)',
        (tester) async {
      final manager = _RecordingManager();
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: debugTvDownloadActions(
            record: _rec(DownloadStatus.downloading),
            manager: manager,
          ),
        ),
      ));
      expect(find.text('Pause'), findsOneWidget);
      expect(find.text('Cancel'), findsOneWidget);
      expect(find.text('Delete'), findsOneWidget);
      expect(find.text('Play'), findsNothing);
      expect(find.text('Resume'), findsNothing);
    });

    testWidgets('paused record shows Resume + Cancel + Delete', (tester) async {
      final manager = _RecordingManager();
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: debugTvDownloadActions(
            record: _rec(DownloadStatus.paused),
            manager: manager,
          ),
        ),
      ));
      expect(find.text('Resume'), findsOneWidget);
      expect(find.text('Cancel'), findsOneWidget);
      expect(find.text('Delete'), findsOneWidget);
      expect(find.text('Pause'), findsNothing);
    });

    testWidgets('done record shows Play + Delete (no Pause/Resume/Cancel)',
        (tester) async {
      final manager = _RecordingManager();
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(
          body: debugTvDownloadActions(
            record: _rec(DownloadStatus.done),
            manager: manager,
          ),
        ),
      ));
      expect(find.text('Play'), findsOneWidget);
      expect(find.text('Delete'), findsOneWidget);
      expect(find.text('Pause'), findsNothing);
      expect(find.text('Resume'), findsNothing);
      expect(find.text('Cancel'), findsNothing);
    });

    testWidgets('tapping Pause calls manager.pause', (tester) async {
      // TvFocusable is D-pad-driven (key-based), not tap-based — it wraps a
      // bare Focus with no GestureDetector — so this drives it the same way
      // every other TV test in this suite does: focus + the OK/select key.
      // See test/core/tv/tv_focusable_test.dart and tv_back_button_test.dart.
      final manager = _RecordingManager();
      final r = _rec(DownloadStatus.downloading);
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(body: debugTvDownloadActions(record: r, manager: manager)),
      ));
      await tester.pumpAndSettle();
      // Pause is the first action for a downloading record, so it already
      // holds autofocus — pressing OK activates it directly.
      await tester.sendKeyEvent(LogicalKeyboardKey.select);
      await tester.pump();
      expect(manager.paused, same(r));
    });

    testWidgets('tapping Delete calls manager.delete', (tester) async {
      final manager = _RecordingManager();
      final r = _rec(DownloadStatus.done);
      await tester.pumpWidget(MaterialApp(
        home: Scaffold(body: debugTvDownloadActions(record: r, manager: manager)),
      ));
      await tester.pumpAndSettle();
      // Delete is the second action for a done record (Play holds autofocus)
      // — move focus with Tab, the default Flutter focus-traversal key, then
      // press OK.
      await tester.sendKeyEvent(LogicalKeyboardKey.tab);
      await tester.pump();
      await tester.sendKeyEvent(LogicalKeyboardKey.select);
      await tester.pump();
      expect(manager.deleted, same(r));
    });
  });
}
