// ignore_for_file: invalid_use_of_protected_member

import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart';
import 'package:watch_app/core/ui/nav_prefs.dart';
import 'package:watch_app/features/home/home_catalogue_prefs.dart';
import 'package:watch_app/features/schedule/schedule_screen.dart';
import 'package:watch_app/features/home/search_screen.dart';
import 'package:watch_app/features/shell/mode_bar.dart';
import 'package:watch_app/core/ui/dock_visibility.dart';
import 'package:watch_app/core/ui/frosted_surface.dart';
import 'package:watch_app/core/anilist/anilist_service.dart';
import 'package:watch_app/core/announce/announcement.dart';
import 'package:watch_app/core/announce/announcement_service.dart';
import 'package:watch_app/core/app_mode.dart';
import 'package:watch_app/core/di/injector.dart';
import 'package:watch_app/core/download/download_manager.dart';
import 'package:watch_app/core/download/download_prefs.dart';
import 'package:watch_app/core/mode/content_mode.dart';
import 'package:watch_app/core/mode/content_mode_cubit.dart';
import 'package:watch_app/core/models/home_section.dart';
import 'package:watch_app/core/models/media_item.dart';
import 'package:watch_app/core/playback/list_status_store.dart';
import 'package:watch_app/core/playback/my_list.dart';
import 'package:watch_app/core/playback/playback_prefs.dart';
import 'package:watch_app/core/playback/search_history.dart';
import 'package:watch_app/core/playback/search_prefs.dart';
import 'package:watch_app/core/playback/search_source_prefs.dart';
import 'package:watch_app/core/profiles/profile_shell_scope.dart';
import 'package:watch_app/core/profiles/viewer_profile.dart';
import 'package:watch_app/features/profiles/viewer_profiles_screen.dart';
import 'package:watch_app/features/profiles/viewer_profile_home_screen.dart';
import 'package:watch_app/core/provider/cloudstream_provider.dart';
import 'package:watch_app/core/provider/provider_manager.dart';
import 'package:watch_app/core/provider/provider_registry.dart';
import 'package:watch_app/core/repository/catalogue_repository.dart';
import 'package:watch_app/core/repository/source_repository.dart';
import 'package:watch_app/core/schedule/airing_service.dart';
import 'package:watch_app/core/schedule/coming_soon_service.dart';
import 'package:watch_app/core/schedule/schedule_models.dart';
import 'package:watch_app/core/search/title_suggestion_service.dart';
import 'package:watch_app/core/state/active_source_cubit.dart';
import 'package:watch_app/core/supabase/supabase_service.dart';
import 'package:watch_app/core/theme/app_colors.dart';
import 'package:watch_app/core/theme/theme_controller.dart';
import 'package:watch_app/core/tracker/mal_service.dart';
import 'package:watch_app/core/tracker/simkl_service.dart';
import 'package:watch_app/core/tracker/tracker_hub.dart';
import 'package:watch_app/core/download/chapter_download_store.dart';
import 'package:watch_app/core/zmode/metadata_repository.dart';
import 'package:watch_app/core/zmode/zmode_prefs.dart';
import 'package:watch_app/features/auth/auth_cubit.dart';
import 'package:watch_app/features/home/cubit/home_cubit.dart';
import 'package:watch_app/features/home/home_screen.dart';
import 'package:watch_app/features/shell/root_shell.dart';
import 'package:watch_app/features/shell/root_shell_tv.dart';
import 'package:watch_app/features/settings/settings_screen.dart';

// ── Minimal fakes (same shape as root_shell_tv_test.dart's harness) ────────

class _FakeSourceRepository implements SourceRepository {
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  List<({String id, String name})> get pickableSources => loadedSources;

  @override
  Future<List<HomeSection>> home({
    String category = 'sub',
    String? sourceId,
  }) async =>
      throw UnimplementedError('_FakeSourceRepository.home — caught upstream');

  @override
  String displayName(String sourceId) => sourceId;

  @override
  String get sourceId => 'allanime';

  @override
  List<({String id, String name})> get loadedSources => const [];

  @override
  bool hasSource(String sourceId) => false;
}

class _FakeMyListStore implements MyListStore {
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  List<MediaItem> all() => const [];

  @override
  bool contains(MediaItem m) => false;

  @override
  final ValueNotifier<int> revision = ValueNotifier<int>(0);
}

class _FakeSearchHistory implements SearchHistory {
  _FakeSearchHistory([this.queries = const []]);
  List<String> queries;
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  List<String> recent() => queries;

  @override
  Future<void> clear() async => queries = [];
}

class _FakeSearchPrefs extends ChangeNotifier implements SearchPrefs {
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  SearchLayout get layout => SearchLayout.vertical;

  @override
  String? get contentFilterName => null;

  @override
  String? get audioFilterName => null;

  @override
  String? get statusFilterName => null;

  @override
  String? get sortName => null;

  @override
  String? get genre => null;

  @override
  int? get decade => null;

  @override
  bool get currentSourceOnly => true;
}

class _FakeSearchSourcePrefs extends ChangeNotifier
    implements SearchSourcePrefs {
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  Set<String> get excluded => const {};

  @override
  bool isIncluded(String id) => true;
}

class _FakeProviderRegistry implements ProviderRegistry {
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  List<ProviderRegistryEntry> getAll() => const [];

  @override
  ProviderRegistryEntry? entryFor(String sourceId) => null;

  @override
  Set<String> nsfwSourceIds() => const {};

  @override
  Map<String, String> typeMapOf() => const {};
  @override
  ({Map<String, String> types, Map<String, String> logos}) manifestMapsOf() =>
      (types: const {}, logos: const {});
}

class _FakeAniListService extends ChangeNotifier implements AniListService {
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  bool get isConnected => false;

  @override
  String get displayName => 'AniList';

  @override
  String? get viewerName => null;

  @override
  String? get viewerAvatar => null;
}

class _FakeMalService extends ChangeNotifier implements MalService {
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  bool get isConnected => false;

  @override
  String get displayName => 'MyAnimeList';

  @override
  String? get viewerName => null;

  @override
  String? get viewerAvatar => null;
}

class _FakeSimklService extends ChangeNotifier implements SimklService {
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;

  @override
  bool get isConnected => false;

  @override
  String get displayName => 'Simkl';

  @override
  String? get viewerName => null;

  @override
  String? get viewerAvatar => null;
}

class _FakeDownloadPrefs extends DownloadPrefs {
  @override
  String? get locationUri => null;

  @override
  String? get locationLabel => null;

  @override
  bool get keepPrivate => false;
}

/// [ScheduleScreen] (built eagerly by both shells' IndexedStack) creates a
/// ScheduleCubit that calls these on `..load()`. Override with immediate
/// empty results so no real Dio call happens — the nav test only cares that
/// the destination exists, not what it renders.
// Return one entry (not empty): the ScheduleCubit now retries with real
// backoff timers when a fetch comes back empty, and a pending timer would
// trip the "Timer still pending" teardown check. The nav test only cares
// that the destination exists, so any non-empty result is fine.
class _FakeAiringService extends AiringService {
  _FakeAiringService() : super(Dio());
  @override
  Future<List<AiringEntry>> weekAiring({DateTime? now}) async => [
    AiringEntry(
      malId: 1,
      title: 'x',
      coverUrl: null,
      episode: 1,
      airsAtLocal: DateTime(2026),
      format: 'TV',
    ),
  ];
}

class _FakeComingSoonService extends ComingSoonService {
  _FakeComingSoonService() : super(Dio());
  @override
  Future<List<ComingSoonEntry>> upcoming() async => const [
    ComingSoonEntry(
      tmdbId: 1,
      isTv: false,
      title: 'x',
      posterUrl: null,
      releaseDate: null,
    ),
  ];
}

/// [HomeScreen] fires a fire-and-forget announcement check on launch (see
/// [maybeShowAnnouncement]). Override to skip Dio + the Hive-backed
/// [AnnouncementStore] entirely — nav tests don't care about announcements.
class _FakeAnnouncementService extends AnnouncementService {
  _FakeAnnouncementService() : super(Dio(), AnnouncementStore());
  @override
  Future<List<Announcement>> check() async => const [];
}

// ── Test ─────────────────────────────────────────────────────────────────

void main() {
  late ActiveSourceCubit activeSource;
  late AuthCubit authCubit;
  late ContentModeCubit contentMode;

  setUpAll(() {
    TestWidgetsFlutterBinding.ensureInitialized();
  });

  setUp(() async {
    TestWidgetsFlutterBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/path_provider'),
          (call) async => Directory.systemTemp.path,
        );

    await sl.reset();

    // Home's launch sequence shows a one-time community sheet backed by the
    // 'app_flags' Hive box. Init Hive + mark it seen so that path no-ops
    // (mirrors production, where Hive is initialized before runApp).
    Hive.init('${Directory.systemTemp.path}/zangetsu_nav_test_hive');
    await ViewerProfileStore.init();
    final flags = await Hive.openBox('app_flags');
    await flags.put('communitySheetSeen', true);
    await Hive.openBox(ThemeController.boxName);
    // Home's initState fires a delayed (4s) source-update check that reads
    // PlaybackPrefs — pumpAndSettle fast-forwards fake time straight through
    // that delay, so it needs to be registered even though this test never
    // waits on it directly. MyListScreen's header similarly needs a TrackerHub
    // (IndexedStack builds every tab eagerly, TrackerHub included).
    await Hive.openBox(PlaybackPrefs.boxName);

    final dio = Dio();
    final fakeRepo = _FakeSourceRepository();
    activeSource = ActiveSourceCubit();
    authCubit = AuthCubit(SupabaseService());
    // This suite reuses a fixed on-disk Hive dir (not a fresh temp dir) across
    // runs, so a mode persisted by an earlier run would otherwise leak in here
    // and start tests in the wrong mode.
    await Hive.deleteBoxFromDisk('content_mode');
    contentMode = await ContentModeCubit.create(activeSource);
    // Same leak-prevention as content_mode above, so the toggle starts off
    // (its default) in every test regardless of run order.
    await Hive.deleteBoxFromDisk(ZModePrefs.boxName);
    await ZModePrefs.init();
    // Both paths are covered here, so start from off and let the Z Mode
    // cases opt in — it is on by default since the toggle was removed.
    await ZModePrefs.setEnabled(false);
    // The dock builds every tab's screen into an IndexedStack, and Downloads
    // is a default tab now — so DownloadsScreen is constructed by every test
    // here and needs its store, whether or not the test looks at it.
    await ChapterDownloadStore.init();
    if (!sl.isRegistered<ChapterDownloadStore>()) {
      sl.registerSingleton<ChapterDownloadStore>(ChapterDownloadStore());
    }

    sl.registerSingleton<HomeCubit>(HomeCubit(fakeRepo));
    sl.registerSingleton<ContentModeCubit>(contentMode);
    sl.registerSingleton<PlaybackPrefs>(PlaybackPrefs());
    sl.registerSingleton<TrackerHub>(TrackerHub(const []));
    sl.registerSingleton<SourceRepository>(fakeRepo);
    sl.registerSingleton<CatalogueRepository>(fakeRepo);
    sl.registerSingleton<MyListStore>(_FakeMyListStore());
    sl.registerSingleton<SearchHistory>(_FakeSearchHistory());
    sl.registerSingleton<SearchPrefs>(_FakeSearchPrefs());
    sl.registerSingleton<SearchSourcePrefs>(_FakeSearchSourcePrefs());
    sl.registerSingleton<ListStatusStore>(ListStatusStore());
    sl.registerSingleton<ViewerProfileStore>(ViewerProfileStore());
    sl.registerSingleton<DownloadManager>(DownloadManager(fakeRepo));
    sl.registerSingleton<ProviderRegistry>(_FakeProviderRegistry());
    sl.registerSingleton<CloudStreamManager>(CloudStreamManager());
    sl.registerSingleton<AniyomiManager>(AniyomiManager());
    sl.registerSingleton<AniListService>(_FakeAniListService());
    sl.registerSingleton<MalService>(_FakeMalService());
    sl.registerSingleton<SimklService>(_FakeSimklService());
    sl.registerSingleton<TitleSuggestionService>(TitleSuggestionService(dio));
    sl.registerSingleton<DownloadPrefs>(_FakeDownloadPrefs());
    sl.registerSingleton<AiringService>(_FakeAiringService());
    sl.registerSingleton<ComingSoonService>(_FakeComingSoonService());
    sl.registerSingleton<AnnouncementService>(_FakeAnnouncementService());
  });

  tearDown(() async {
    TestWidgetsFlutterBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          const MethodChannel('plugins.flutter.io/path_provider'),
          null,
        );
    await sl.reset();
    authCubit.close();
    activeSource.close();
    await contentMode.close();
    await Hive.close();
  });

  // Only supportsFilters is read while Home builds the card row.
  // (declared below main's helpers so the tests above stay readable)

  Widget wrap(Widget child) => MultiBlocProvider(
    providers: [
      BlocProvider<ActiveSourceCubit>.value(value: activeSource),
      BlocProvider<AuthCubit>.value(value: authCubit),
    ],
    child: MaterialApp(home: child),
  );

  // Home now has its own Schedule card (Anime mode only, same label as the
  // dock tab — task 11), so a bare `find.text('Schedule')` can match either
  // one while Home is the visible tab. The floating dock is the only widget
  // in this tree wrapped in `AnimatedSlide`, so scoping through it isolates
  // the dock tab specifically.
  Finder dockLabel(String label) => find.descendant(
    of: find.byType(AnimatedSlide),
    matching: find.text(label),
  );

  for (final style in NavBarStyle.values) {
    testWidgets('Stremio hides only the mode dock (${style.name})', (
      tester,
    ) async {
      sl.registerSingleton<AppMode>(const AppMode(isTv: false));
      final nav = NavPrefs();
      sl.registerSingleton<NavPrefs>(nav);
      await tester.runAsync(() async {
        await Hive.openBox(HomeCataloguePrefs.boxName);
        await HomeCataloguePrefs.setCatalogue(
          ContentMode.anime,
          HomeCatalogueKind.metadata,
        );
        await NavPrefs.init();
        await nav.setStyle(style);
        await nav.setKeepDockExpanded(false);
        await ZModePrefs.setEnabled(true);
      });
      await tester.pumpWidget(wrap(const RootShell()));
      await tester.pump();
      await tester.pump(const Duration(seconds: 5));
      final modes = style == NavBarStyle.liquid
          ? find.byType(GlassMenu)
          : find.byType(ModeFab);
      final navigation = style == NavBarStyle.liquid
          ? find.byType(GlassTabBar)
          : find.byKey(const ValueKey('dockPill'));
      expect(modes, findsOneWidget);
      expect(navigation, findsOneWidget);
      final expandedWidth = tester.getSize(navigation).width;
      double? collapsedWidth;
      if (style == NavBarStyle.liquid) {
        addTearDown(DockScrollCollapse.reset);
        dockCollapsedByScroll.value = true;
        await tester.pump();
        await tester.pump(const Duration(milliseconds: 500));
        collapsedWidth = tester.getSize(navigation).width;
        DockScrollCollapse.reset();
        await tester.pump();
        await tester.pump(const Duration(milliseconds: 500));
      }

      await tester.runAsync(
        () => HomeCataloguePrefs.setCatalogue(
          ContentMode.anime,
          HomeCatalogueKind.stremio,
        ),
      );
      await tester.pump();
      await tester.pump(const Duration(seconds: 5));
      expect(modes, findsNothing);
      expect(navigation, findsOneWidget);
      if (style == NavBarStyle.liquid) {
        expect(tester.getSize(navigation).width, closeTo(expandedWidth, 1));
        dockCollapsedByScroll.value = true;
        await tester.pump();
        await tester.pump(const Duration(milliseconds: 500));
        expect(tester.getSize(navigation).width, closeTo(collapsedWidth!, 1));
        DockScrollCollapse.reset();
        await tester.pump();
        await tester.pump(const Duration(milliseconds: 500));
      }

      await tester.runAsync(() => contentMode.setMode(ContentMode.manga));
      await tester.pump();
      await tester.pump(const Duration(seconds: 5));
      expect(modes, findsOneWidget);
      expect(navigation, findsOneWidget);

      await tester.runAsync(() => contentMode.setMode(ContentMode.anime));
      await tester.pump();
      await tester.pump(const Duration(seconds: 5));
      expect(modes, findsNothing);

      await tester.runAsync(
        () => HomeCataloguePrefs.setCatalogue(
          ContentMode.anime,
          HomeCatalogueKind.metadata,
        ),
      );
      await tester.pump();
      await tester.pump(const Duration(seconds: 5));
      expect(modes, findsOneWidget);
      expect(navigation, findsOneWidget);
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump(const Duration(seconds: 5));
    });
  }

  // Schedule left the dock for the card row on Home, beside the Manga/Novel
  // mode cards — two doors to one screen was the point of removing it — and
  // Sources took the slot it left, moved down from the Home header.
  testWidgets('the phone dock swapped Schedule for Sources', (tester) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await tester.pumpAndSettle();

    expect(dockLabel('Schedule'), findsNothing);
    expect(dockLabel('Sources'), findsOneWidget);
  });

  testWidgets('the phone Profile tab opens the viewer overview', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await tester.pumpAndSettle();

    await tester.tap(dockLabel('Profile'));
    await tester.pumpAndSettle();

    expect(find.byType(ViewerProfileHomeScreen), findsOneWidget);
    expect(find.byTooltip('Profile menu'), findsOneWidget);
    expect(find.text('About'), findsNothing);
  });

  testWidgets('double-tapping the phone Profile tab opens Settings', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await tester.pump(const Duration(milliseconds: 250));

    expect(find.byType(SettingsScreen), findsNothing);

    await tester.tap(dockLabel('Profile'));
    await tester.pump();
    expect(find.byType(ViewerProfileHomeScreen), findsOneWidget);
    expect(
      tester.state<NavigatorState>(find.byType(Navigator)).canPop(),
      isFalse,
    );
    await tester.tap(dockLabel('Profile'));
    await tester.pump(const Duration(milliseconds: 500));

    final settings = tester.element(
      find.byType(SettingsScreen, skipOffstage: false),
    );
    expect(ModalRoute.of(settings)?.isCurrent, isTrue);
  });

  testWidgets('profile launch gate hides the entire phone shell', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(
      wrap(const ProfileShellScope(deferContent: true, child: RootShell())),
    );

    expect(find.byType(Scaffold), findsNothing);
    expect(find.byKey(const ValueKey('dockPill')), findsNothing);
    expect(
      find.byWidgetPredicate(
        (widget) => widget is ColoredBox && widget.color == AppColors.bg,
      ),
      findsOneWidget,
    );
  });

  // The dock collapses to icons on scroll (DockScrollCollapse). Two things a
  // purely visual change quietly broke, and would break again:
  testWidgets('every dock tab keeps a tappable box and a name', (tester) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await tester.pumpAndSettle();

    // The dock keeps one clipped live blur behind its static frost surface.
    final dock = find.byKey(const ValueKey('dockPill'));
    expect(dock, findsOneWidget);
    final dockSurface = tester.widget<FakeFrost>(dock);
    expect(dockSurface.opacity, 0.55);
    expect(dockSurface.blur, isTrue);
    expect(dockSurface.blurSigma, 14);
    expect(
      find.descendant(of: dock, matching: find.byType(BackdropFilter)),
      findsOneWidget,
    );

    // A box worth aiming at — checked COLLAPSED, which is the state that
    // regressed. Open, the item is 44 on its own (icon + label) and proves
    // nothing; collapsed the label folds away and, without a minimum, the
    // target fell to ~27 sitting right over the gesture bar.
    final taps = find.descendant(of: dock, matching: find.byType(InkWell));
    expect(taps, findsWidgets);
    addTearDown(DockScrollCollapse.reset);
    dockCollapsedByScroll.value = true;
    await tester.pumpAndSettle();

    for (var i = 0; i < taps.evaluate().length; i++) {
      expect(
        tester.getSize(taps.at(i)).height,
        greaterThanOrEqualTo(48),
        reason: 'collapsed dock tab $i must stay at least 48 tall to hit',
      );
    }

    // A name a screen reader can read. The visible Text is excluded from
    // semantics and folds to zero height when the dock collapses, so the name
    // has to come from the item itself.
    for (final name in const ['Home', 'My List', 'Sources', 'Profile']) {
      expect(
        find.descendant(of: dock, matching: find.bySemanticsLabel(name)),
        findsWidgets,
        reason: '"$name" must be announced by the dock',
      );
    }
  });

  // Task 17: Search moved from the dock to the Home header (HomeSearchAction
  // — see home_search_action_test.dart). The dock itself should never offer
  // it, on the default tab set the app actually ships.
  testWidgets('the dock never offers a Search tab', (tester) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await tester.pumpAndSettle();

    expect(dockLabel('Search'), findsNothing);
  });

  testWidgets('long-pressing the Profile dock item switches viewer profiles', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    final profiles = _TestViewerProfileStore([
      const ViewerProfile(id: kDefaultProfileId, name: 'Home'),
      const ViewerProfile(id: 'kids', name: 'Kids', isKids: true),
    ]);
    await sl.unregister<ViewerProfileStore>();
    sl.registerSingleton<ViewerProfileStore>(profiles);

    await tester.pumpWidget(wrap(const RootShell()));
    await tester.pumpAndSettle();
    await tester.longPress(dockLabel('Profile'));
    await tester.pumpAndSettle();

    expect(
      find.byKey(const ValueKey('profile-switcher-sheet')),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('profile-switcher-active')),
      findsOneWidget,
    );
    await tester.tap(
      find.byKey(const ValueKey('profile-switcher-choice-kids')),
    );
    await tester.pumpAndSettle();

    expect(profiles.activeId, 'kids');
  });

  testWidgets('profile switcher brands the sheet and opens profile manager', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    final profiles = _TestViewerProfileStore([
      const ViewerProfile(id: kDefaultProfileId, name: 'Home'),
      const ViewerProfile(id: 'kids', name: 'Kids', isKids: true),
    ]);
    await sl.unregister<ViewerProfileStore>();
    sl.registerSingleton<ViewerProfileStore>(profiles);

    await tester.pumpWidget(wrap(const RootShell()));
    await tester.pumpAndSettle();
    await tester.longPress(dockLabel('Profile'));
    await tester.pumpAndSettle();

    final sheet = find.byKey(const ValueKey('profile-switcher-sheet'));
    final optionsCard = find.byKey(
      const ValueKey('profile-switcher-options-card'),
    );
    expect(optionsCard, findsOneWidget);
    final optionsMaterial = tester.widget<Material>(
      find.descendant(of: optionsCard, matching: find.byType(Material)),
    );
    expect(optionsMaterial.color, AppColors.surface);
    expect(
      (optionsMaterial.shape! as RoundedRectangleBorder).side.color,
      AppColors.hairline,
    );
    final activeTile = tester.widget<ListTile>(
      find.byKey(const ValueKey('profile-switcher-active')),
    );
    expect(activeTile.visualDensity, const VisualDensity(vertical: -1));
    expect(
      tester.getSize(find.byWidget(activeTile.leading!)),
      const Size(38, 38),
    );
    expect(
      find.descendant(
        of: optionsCard,
        matching: find.byKey(const ValueKey('profile-switcher-active')),
      ),
      findsOneWidget,
    );
    expect(
      find.descendant(
        of: optionsCard,
        matching: find.byKey(const ValueKey('profile-switcher-add')),
      ),
      findsOneWidget,
    );
    expect(
      find.byKey(const ValueKey('profile-switcher-brand-footer')),
      findsOneWidget,
    );
    expect(
      find.descendant(of: sheet, matching: find.text('Lamovmaa')),
      findsOneWidget,
    );
    expect(
      find.descendant(of: sheet, matching: find.text('Add profile')),
      findsOneWidget,
    );
    expect(
      find.descendant(of: sheet, matching: find.byType(Divider)),
      findsNothing,
    );

    await tester.tap(find.byKey(const ValueKey('profile-switcher-add')));
    await tester.pumpAndSettle();
    expect(find.byType(ViewerProfilesScreen), findsOneWidget);
  });

  testWidgets('TV shell keeps Downloads and gains a Schedule rail item', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: true));
    await tester.pumpWidget(wrap(const RootShellTv()));
    await tester.pumpAndSettle();

    // This fixture has zero loaded sources, so Home's initial focus lands on
    // its own "no sources yet" Browse button rather than the rail — the rail
    // only shows its text labels once expanded. LEFT from content opens it,
    // same bridge root_shell_tv_test.dart exercises directly.
    await tester.sendKeyEvent(LogicalKeyboardKey.arrowLeft);
    await tester.pumpAndSettle();

    expect(find.text('Downloads'), findsOneWidget);
    expect(find.text('Schedule'), findsOneWidget);
  });

  // Liquid navigation keeps animating, so advance transitions without waiting for idle.
  Future<void> pumpHomeAnimations(WidgetTester tester) async {
    await tester.pump();
    await tester.pump(const Duration(seconds: 2));
  }

  testWidgets('Search fits a short screen with the keyboard open', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(320, 600);
    tester.view.devicePixelRatio = 1;
    tester.view.viewInsets = const FakeViewPadding(bottom: 280);
    addTearDown(tester.view.reset);
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const SearchScreen(showBack: false)));
    await pumpHomeAnimations(tester);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Schedule sits below recents and keeps search history', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await sl.unregister<SearchHistory>();
    final history = _FakeSearchHistory(['Naruto', 'Bleach']);
    sl.registerSingleton<SearchHistory>(history);
    await tester.pumpWidget(wrap(const SearchScreen(showBack: false)));
    await pumpHomeAnimations(tester);
    final schedule = find.byKey(const ValueKey('search_schedule_action'));
    final scaffoldWidth = tester.getSize(find.byType(Scaffold).first).width;
    expect(tester.getRect(schedule).width, closeTo(scaffoldWidth - 32, 1));
    expect(
      tester.getTopLeft(schedule).dy,
      greaterThan(tester.getBottomLeft(find.text('Naruto')).dy),
    );
    final divider = find.byKey(const ValueKey('recent_search_divider'));
    expect(divider, findsOneWidget);
    expect(
      tester.getTopLeft(schedule).dy,
      greaterThan(tester.getBottomLeft(divider).dy),
    );
    await tester.tap(schedule);
    await pumpHomeAnimations(tester);
    expect(find.byType(ScheduleScreen), findsOneWidget);
    Navigator.of(tester.element(find.byType(ScheduleScreen))).pop();
    await pumpHomeAnimations(tester);
    expect(history.recent(), ['Naruto', 'Bleach']);
    await tester.tap(find.text('Clear'));
    await pumpHomeAnimations(tester);
    expect(
      find.byKey(const ValueKey('search_schedule_action')),
      findsOneWidget,
    );
    expect(history.recent(), isEmpty);
  });

  testWidgets('Schedule stays below the search field without recents', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const SearchScreen(showBack: false)));
    await pumpHomeAnimations(tester);
    final schedule = find.byKey(const ValueKey('search_schedule_action'));
    expect(schedule, findsOneWidget);
    expect(
      tester.getTopLeft(schedule).dy,
      greaterThan(tester.getBottomLeft(find.byType(TextField).first).dy),
    );
  });

  testWidgets('Home has no Schedule card or header button', (tester) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await pumpHomeAnimations(tester);
    expect(find.byKey(const ValueKey('home_schedule_card')), findsNothing);
    expect(find.byKey(const ValueKey('home_lists_hub_card')), findsNothing);
    expect(find.byTooltip('Schedule'), findsNothing);
  });

  // The remaining mode/genre cards still fit narrow screens.
  testWidgets('the card row survives a narrow phone', (tester) async {
    tester.view.physicalSize = const Size(320 * 3, 640 * 3);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.reset);

    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await pumpHomeAnimations(tester);

    expect(find.byKey(const ValueKey('home_schedule_card')), findsNothing);
    expect(tester.takeException(), isNull);
  });

  // The row above only ever holds one card, because no MetadataRepository is
  // registered so Genres is hidden. Two cards splitting 320dp is the case
  // that squeezes Schedule beside Genres.
  testWidgets('both cards fit side by side on a narrow phone', (tester) async {
    tester.view.physicalSize = const Size(320 * 3, 640 * 3);
    tester.view.devicePixelRatio = 3;
    addTearDown(tester.view.reset);

    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    sl.registerSingleton<MetadataRepository>(_FiltersRepo());
    await tester.pumpWidget(wrap(const RootShell()));
    await pumpHomeAnimations(tester);

    expect(find.byKey(const ValueKey('home_schedule_card')), findsNothing);
    expect(find.byKey(const ValueKey('home_genres_card')), findsNothing);
    // An overflow paints an exception rather than throwing, so this is what
    // catches the row getting too tight.
    expect(tester.takeException(), isNull);
  });

  // Nothing watched and nothing loaded: the last-resort fill. Pins that it is
  // tinted rather than the old surface2 -> surface grey, and that the two
  // cards do not land on the same tint (the "one wide slab" the accent was
  // added to avoid in the first place).
  testWidgets('Genres shortcut is disabled even when filtering is supported', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    sl.registerSingleton<MetadataRepository>(_FiltersRepo());
    await tester.pumpWidget(wrap(const RootShell()));
    await pumpHomeAnimations(tester);

    expect(find.byKey(const ValueKey('home_genres_card')), findsNothing);
  });

  testWidgets('no Genres card when the catalogue cannot filter', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    sl.registerSingleton<MetadataRepository>(_FiltersRepo(supports: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await pumpHomeAnimations(tester);

    expect(find.byKey(const ValueKey('home_schedule_card')), findsNothing);
    expect(find.byKey(const ValueKey('home_genres_card')), findsNothing);
  });

  testWidgets('Home keeps Schedule out of the card row in Z Mode', (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const RootShell()));
    await pumpHomeAnimations(tester);
    expect(find.byKey(const ValueKey('home_schedule_card')), findsNothing);

    await tester.runAsync(() => ZModePrefs.setEnabled(true));
    await pumpHomeAnimations(tester);
    expect(find.byKey(const ValueKey('home_schedule_card')), findsNothing);

    await tester.runAsync(() => ZModePrefs.setEnabled(false));
    await pumpHomeAnimations(tester);
  });

  // Task 11 added a full-width "Search" bar to Home while Z Mode was on
  // (Search having left the dock); task 17 replaced that with a header icon
  // instead (HomeBrowseSourcesAction's sibling, HomeSearchAction — covered by
  // home_search_action_test.dart), shown regardless of Z Mode. So this no
  // longer asserts the search icon is absent — that icon is legitimate now —
  // only that task 11's specific full-width caption bar never comes back.
  // Pumped as bare HomeScreen, not the full RootShell: the shell's
  // IndexedStack also mounts SearchScreen (offstage), whose SearchScope stays
  // reactive to ZModePrefs.revision even offstage and would need a real
  // MetadataRepository the moment Z Mode flips on — nothing this test cares
  // about.
  testWidgets("Home doesn't bring back the old full-width search bar", (
    tester,
  ) async {
    sl.registerSingleton<AppMode>(const AppMode(isTv: false));
    await tester.pumpWidget(wrap(const HomeScreen()));
    await tester.pumpAndSettle();

    await tester.runAsync(() => ZModePrefs.setEnabled(true));
    await tester.pumpAndSettle();

    // The old bar's tell was a caption reading "Search" beside its icon; the
    // header's icon-only action has a tooltip (not rendered as Text) instead.
    expect(find.text('Search'), findsNothing);
  });
}

/// Home reads only [MetadataRepository.supportsFilters] to decide whether the
/// Genres card belongs in the row; stubbing the rest would be fiction.
class _FiltersRepo implements MetadataRepository {
  _FiltersRepo({this.supports = true});
  final bool supports;
  @override
  bool get supportsFilters => supports;
  @override
  noSuchMethod(Invocation i) => super.noSuchMethod(i);
  // Added with the on-demand resolver: SourceMatcher now asks whether a JS
  // provider is loaded before searching it. These fakes are already "loaded".
  @override
  Future<bool> ensureSourceLoaded(String sourceId) async => true;
}

class _TestViewerProfileStore extends ViewerProfileStore {
  _TestViewerProfileStore(this._profiles) {
    active.value = _profiles.first;
  }

  final List<ViewerProfile> _profiles;

  @override
  List<ViewerProfile> get profiles => List.unmodifiable(_profiles);

  @override
  List<ViewerProfile> get recoverableProfiles => const [];

  @override
  bool get askOnLaunch => true;

  @override
  Future<void> switchTo(String profileId) async {
    active.value = _profiles.firstWhere((profile) => profile.id == profileId);
    revision.value++;
  }
}
