# Lamovmaa

Aplikasi nonton dan baca (anime, film/TV, manga, novel) untuk Android, berjalan lokal, dipakai pribadi.
**Lamovmaa adalah versi modifikasi tidak resmi (fork) dari [Zangetsu](https://github.com/Spyou/Zangetsu)** oleh Krishna Vishwakarma (Spyou), berlisensi GPL-3.0. Ini bukan proyek Zangetsu yang resmi dan tidak didukung atau disahkan oleh penulis aslinya.

## Atribusi dan lisensi
- Proyek asli: Zangetsu, https://github.com/Spyou/Zangetsu, hak cipta (C) 2026 Krishna Vishwakarma.
- Lisensi: GPL-3.0 beserta syarat tambahan Bagian 7 di berkas `LICENSE` (tidak diubah). Syarat itu melarang memakai nama, logo, atau ikon Zangetsu pada versi modifikasi; karena itu nama, ikon, dan logo di sini adalah milik Lamovmaa (sementara) dan seluruh aset logo asli sudah dihapus atau diganti.
- Pemberitahuan komponen pihak ketiga: lihat `NOTICE.md` (dipertahankan dan diberi catatan turunan di bagian atas).
- README asli disimpan sebagai `README.upstream.md`.

## Status
Tahap rebrand (PART 9): nama **Lamovmaa**, package `com.lamovmaa.app`, channel native `lamovmaa/*`, skema tautan `lamovmaa://`, ikon sementara. Fitur belum dipangkas; layanan dan alamat milik pemilik asli masih ada di kode dan akan dibuang pada tahap berikutnya. Belum diuji di perangkat.

## Build
Dibangun lewat GitHub Actions (Flutter 3.44.7, Java 17).
